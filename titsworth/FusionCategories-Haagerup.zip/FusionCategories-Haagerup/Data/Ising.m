BeginPackage["FusionCategories`Data`Ising`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[Ising] ^= {IsingCat1, IsingCat2}
 
Ising /: fusionCategory[Ising, 1] = IsingCat1
 
Ising /: fusionCategory[Ising, 2] = IsingCat2
 
nFunction[Ising] ^= IsingNFunction
 
noMultiplicities[Ising] ^= True
 
rank[Ising] ^= 3
 
ring[Ising] ^= Ising
balancedCategories[IsingCat1] ^= {IsingCat1Bal1, IsingCat1Bal2, 
    IsingCat1Bal3, IsingCat1Bal4, IsingCat1Bal5, IsingCat1Bal6, 
    IsingCat1Bal7, IsingCat1Bal8}
 
IsingCat1 /: balancedCategory[IsingCat1, 1] = IsingCat1Bal1
 
IsingCat1 /: balancedCategory[IsingCat1, 2] = IsingCat1Bal2
 
IsingCat1 /: balancedCategory[IsingCat1, 3] = IsingCat1Bal3
 
IsingCat1 /: balancedCategory[IsingCat1, 4] = IsingCat1Bal4
 
IsingCat1 /: balancedCategory[IsingCat1, 5] = IsingCat1Bal5
 
IsingCat1 /: balancedCategory[IsingCat1, 6] = IsingCat1Bal6
 
IsingCat1 /: balancedCategory[IsingCat1, 7] = IsingCat1Bal7
 
IsingCat1 /: balancedCategory[IsingCat1, 8] = IsingCat1Bal8
 
braidedCategories[IsingCat1] ^= {IsingCat1Brd1, IsingCat1Brd2, IsingCat1Brd3, 
    IsingCat1Brd4}
 
IsingCat1 /: braidedCategory[IsingCat1, 1] = IsingCat1Brd1
 
IsingCat1 /: braidedCategory[IsingCat1, 2] = IsingCat1Brd2
 
IsingCat1 /: braidedCategory[IsingCat1, 3] = IsingCat1Brd3
 
IsingCat1 /: braidedCategory[IsingCat1, 4] = IsingCat1Brd4
 
coeval[IsingCat1] ^= 1/sixJFunction[IsingCat1][#1, dual[ring[IsingCat1]][#1], 
      #1, #1, 0, 0] & 
 
eval[IsingCat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[IsingCat1] ^= IsingCat1FMatrixFunction
 
fusionCategory[IsingCat1] ^= IsingCat1
 
IsingCat1 /: modularCategory[IsingCat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[IsingCat1] ^= {IsingCat1Piv1, IsingCat1Piv2}
 
IsingCat1 /: pivotalCategory[IsingCat1, 1] = IsingCat1Piv1
 
IsingCat1 /: pivotalCategory[IsingCat1, 2] = IsingCat1Piv2
 
IsingCat1 /: pivotalCategory[IsingCat1, {1, 1, -1}] = IsingCat1Piv2
 
IsingCat1 /: pivotalCategory[IsingCat1, {1, 1, 1}] = IsingCat1Piv1
 
IsingCat1 /: ribbonCategory[IsingCat1, 1] = IsingCat1Bal1
 
IsingCat1 /: ribbonCategory[IsingCat1, 2] = IsingCat1Bal2
 
IsingCat1 /: ribbonCategory[IsingCat1, 3] = IsingCat1Bal3
 
IsingCat1 /: ribbonCategory[IsingCat1, 4] = IsingCat1Bal4
 
IsingCat1 /: ribbonCategory[IsingCat1, 5] = IsingCat1Bal5
 
IsingCat1 /: ribbonCategory[IsingCat1, 6] = IsingCat1Bal6
 
IsingCat1 /: ribbonCategory[IsingCat1, 7] = IsingCat1Bal7
 
IsingCat1 /: ribbonCategory[IsingCat1, 8] = IsingCat1Bal8
 
ring[IsingCat1] ^= Ising
 
IsingCat1 /: sphericalCategory[IsingCat1, 1] = IsingCat1Piv1
 
IsingCat1 /: sphericalCategory[IsingCat1, 2] = IsingCat1Piv2
 
fusionCategoryIndex[Ising][IsingCat1] ^= 1
balancedCategory[IsingCat1Bal1] ^= IsingCat1Bal1
 
braidedCategory[IsingCat1Bal1] ^= IsingCat1Brd1
 
fusionCategory[IsingCat1Bal1] ^= IsingCat1
 
pivotalCategory[IsingCat1Bal1] ^= IsingCat1Piv1
 
ribbonCategory[IsingCat1Bal1] ^= IsingCat1Bal1
 
ring[IsingCat1Bal1] ^= Ising
 
sphericalCategory[IsingCat1Bal1] ^= IsingCat1Piv1
 
(balancedCategoryIndex[braidedCategory[IsingCat1Brd1]][
      balancedCategory[#1]] & )[IsingCat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[IsingCat1]][balancedCategory[#1]] & )[
    IsingCat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[IsingCat1Piv1]][
      balancedCategory[#1]] & )[IsingCat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[IsingCat1Brd1]][ribbonCategory[#1]] & )[
    IsingCat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[IsingCat1]][ribbonCategory[#1]] & )[
    IsingCat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[IsingCat1Piv1]][
      ribbonCategory[#1]] & )[IsingCat1Bal1] ^= 1
balancedCategory[IsingCat1Bal2] ^= IsingCat1Bal2
 
braidedCategory[IsingCat1Bal2] ^= IsingCat1Brd1
 
fusionCategory[IsingCat1Bal2] ^= IsingCat1
 
pivotalCategory[IsingCat1Bal2] ^= IsingCat1Piv2
 
ribbonCategory[IsingCat1Bal2] ^= IsingCat1Bal2
 
ring[IsingCat1Bal2] ^= Ising
 
sphericalCategory[IsingCat1Bal2] ^= IsingCat1Piv2
 
(balancedCategoryIndex[braidedCategory[IsingCat1Brd1]][
      balancedCategory[#1]] & )[IsingCat1Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[IsingCat1]][balancedCategory[#1]] & )[
    IsingCat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[IsingCat1Piv2]][
      balancedCategory[#1]] & )[IsingCat1Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[IsingCat1Brd1]][ribbonCategory[#1]] & )[
    IsingCat1Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[IsingCat1]][ribbonCategory[#1]] & )[
    IsingCat1Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[IsingCat1Piv2]][
      ribbonCategory[#1]] & )[IsingCat1Bal2] ^= 1
balancedCategory[IsingCat1Bal3] ^= IsingCat1Bal3
 
braidedCategory[IsingCat1Bal3] ^= IsingCat1Brd2
 
fusionCategory[IsingCat1Bal3] ^= IsingCat1
 
pivotalCategory[IsingCat1Bal3] ^= IsingCat1Piv1
 
ribbonCategory[IsingCat1Bal3] ^= IsingCat1Bal3
 
ring[IsingCat1Bal3] ^= Ising
 
sphericalCategory[IsingCat1Bal3] ^= IsingCat1Piv1
 
(balancedCategoryIndex[braidedCategory[IsingCat1Brd2]][
      balancedCategory[#1]] & )[IsingCat1Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[IsingCat1]][balancedCategory[#1]] & )[
    IsingCat1Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[IsingCat1Piv1]][
      balancedCategory[#1]] & )[IsingCat1Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[IsingCat1Brd2]][ribbonCategory[#1]] & )[
    IsingCat1Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[IsingCat1]][ribbonCategory[#1]] & )[
    IsingCat1Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[IsingCat1Piv1]][
      ribbonCategory[#1]] & )[IsingCat1Bal3] ^= 2
balancedCategory[IsingCat1Bal4] ^= IsingCat1Bal4
 
braidedCategory[IsingCat1Bal4] ^= IsingCat1Brd2
 
fusionCategory[IsingCat1Bal4] ^= IsingCat1
 
pivotalCategory[IsingCat1Bal4] ^= IsingCat1Piv2
 
ribbonCategory[IsingCat1Bal4] ^= IsingCat1Bal4
 
ring[IsingCat1Bal4] ^= Ising
 
sphericalCategory[IsingCat1Bal4] ^= IsingCat1Piv2
 
(balancedCategoryIndex[braidedCategory[IsingCat1Brd2]][
      balancedCategory[#1]] & )[IsingCat1Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[IsingCat1]][balancedCategory[#1]] & )[
    IsingCat1Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[IsingCat1Piv2]][
      balancedCategory[#1]] & )[IsingCat1Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[IsingCat1Brd2]][ribbonCategory[#1]] & )[
    IsingCat1Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[IsingCat1]][ribbonCategory[#1]] & )[
    IsingCat1Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[IsingCat1Piv2]][
      ribbonCategory[#1]] & )[IsingCat1Bal4] ^= 2
balancedCategory[IsingCat1Bal5] ^= IsingCat1Bal5
 
braidedCategory[IsingCat1Bal5] ^= IsingCat1Brd3
 
fusionCategory[IsingCat1Bal5] ^= IsingCat1
 
pivotalCategory[IsingCat1Bal5] ^= IsingCat1Piv1
 
ribbonCategory[IsingCat1Bal5] ^= IsingCat1Bal5
 
ring[IsingCat1Bal5] ^= Ising
 
sphericalCategory[IsingCat1Bal5] ^= IsingCat1Piv1
 
(balancedCategoryIndex[braidedCategory[IsingCat1Brd3]][
      balancedCategory[#1]] & )[IsingCat1Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[IsingCat1]][balancedCategory[#1]] & )[
    IsingCat1Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[IsingCat1Piv1]][
      balancedCategory[#1]] & )[IsingCat1Bal5] ^= 3
 
(ribbonCategoryIndex[braidedCategory[IsingCat1Brd3]][ribbonCategory[#1]] & )[
    IsingCat1Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[IsingCat1]][ribbonCategory[#1]] & )[
    IsingCat1Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[IsingCat1Piv1]][
      ribbonCategory[#1]] & )[IsingCat1Bal5] ^= 3
balancedCategory[IsingCat1Bal6] ^= IsingCat1Bal6
 
braidedCategory[IsingCat1Bal6] ^= IsingCat1Brd3
 
fusionCategory[IsingCat1Bal6] ^= IsingCat1
 
pivotalCategory[IsingCat1Bal6] ^= IsingCat1Piv2
 
ribbonCategory[IsingCat1Bal6] ^= IsingCat1Bal6
 
ring[IsingCat1Bal6] ^= Ising
 
sphericalCategory[IsingCat1Bal6] ^= IsingCat1Piv2
 
(balancedCategoryIndex[braidedCategory[IsingCat1Brd3]][
      balancedCategory[#1]] & )[IsingCat1Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[IsingCat1]][balancedCategory[#1]] & )[
    IsingCat1Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[IsingCat1Piv2]][
      balancedCategory[#1]] & )[IsingCat1Bal6] ^= 3
 
(ribbonCategoryIndex[braidedCategory[IsingCat1Brd3]][ribbonCategory[#1]] & )[
    IsingCat1Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[IsingCat1]][ribbonCategory[#1]] & )[
    IsingCat1Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[IsingCat1Piv2]][
      ribbonCategory[#1]] & )[IsingCat1Bal6] ^= 3
balancedCategory[IsingCat1Bal7] ^= IsingCat1Bal7
 
braidedCategory[IsingCat1Bal7] ^= IsingCat1Brd4
 
fusionCategory[IsingCat1Bal7] ^= IsingCat1
 
pivotalCategory[IsingCat1Bal7] ^= IsingCat1Piv1
 
ribbonCategory[IsingCat1Bal7] ^= IsingCat1Bal7
 
ring[IsingCat1Bal7] ^= Ising
 
sphericalCategory[IsingCat1Bal7] ^= IsingCat1Piv1
 
(balancedCategoryIndex[braidedCategory[IsingCat1Brd4]][
      balancedCategory[#1]] & )[IsingCat1Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[IsingCat1]][balancedCategory[#1]] & )[
    IsingCat1Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[IsingCat1Piv1]][
      balancedCategory[#1]] & )[IsingCat1Bal7] ^= 4
 
(ribbonCategoryIndex[braidedCategory[IsingCat1Brd4]][ribbonCategory[#1]] & )[
    IsingCat1Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[IsingCat1]][ribbonCategory[#1]] & )[
    IsingCat1Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[IsingCat1Piv1]][
      ribbonCategory[#1]] & )[IsingCat1Bal7] ^= 4
balancedCategory[IsingCat1Bal8] ^= IsingCat1Bal8
 
braidedCategory[IsingCat1Bal8] ^= IsingCat1Brd4
 
fusionCategory[IsingCat1Bal8] ^= IsingCat1
 
pivotalCategory[IsingCat1Bal8] ^= IsingCat1Piv2
 
ribbonCategory[IsingCat1Bal8] ^= IsingCat1Bal8
 
ring[IsingCat1Bal8] ^= Ising
 
sphericalCategory[IsingCat1Bal8] ^= IsingCat1Piv2
 
(balancedCategoryIndex[braidedCategory[IsingCat1Brd4]][
      balancedCategory[#1]] & )[IsingCat1Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[IsingCat1]][balancedCategory[#1]] & )[
    IsingCat1Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[IsingCat1Piv2]][
      balancedCategory[#1]] & )[IsingCat1Bal8] ^= 4
 
(ribbonCategoryIndex[braidedCategory[IsingCat1Brd4]][ribbonCategory[#1]] & )[
    IsingCat1Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[IsingCat1]][ribbonCategory[#1]] & )[
    IsingCat1Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[IsingCat1Piv2]][
      ribbonCategory[#1]] & )[IsingCat1Bal8] ^= 4
balancedCategories[IsingCat1Brd1] ^= {IsingCat1Bal1, IsingCat1Bal2}
 
IsingCat1Brd1 /: balancedCategory[IsingCat1Brd1, 1] = IsingCat1Bal1
 
IsingCat1Brd1 /: balancedCategory[IsingCat1Brd1, 2] = IsingCat1Bal2
 
braidedCategory[IsingCat1Brd1] ^= IsingCat1Brd1
 
fusionCategory[IsingCat1Brd1] ^= IsingCat1
 
IsingCat1Brd1 /: modularCategory[IsingCat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
IsingCat1Brd1 /: ribbonCategory[IsingCat1Brd1, 1] = IsingCat1Bal1
 
IsingCat1Brd1 /: ribbonCategory[IsingCat1Brd1, 2] = IsingCat1Bal2
 
ring[IsingCat1Brd1] ^= Ising
 
rMatrixFunction[IsingCat1Brd1] ^= IsingCat1Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[IsingCat1]][braidedCategory[#1]] & )[
    IsingCat1Brd1] ^= 1
braidedCategory[IsingCat1Brd1RMatrixFunction] ^= IsingCat1Brd1
 
fusionCategory[IsingCat1Brd1RMatrixFunction] ^= IsingCat1
 
rMatrixFunction[IsingCat1Brd1RMatrixFunction] ^= IsingCat1Brd1RMatrixFunction
 
IsingCat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
IsingCat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
IsingCat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
IsingCat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
IsingCat1Brd1RMatrixFunction[1, 1, 0] = {{-1}}
 
IsingCat1Brd1RMatrixFunction[1, 2, 2] = {{I}}
 
IsingCat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
IsingCat1Brd1RMatrixFunction[2, 1, 2] = {{I}}
 
IsingCat1Brd1RMatrixFunction[2, 2, 0] = {{-(-1)^(3/8)}}
 
IsingCat1Brd1RMatrixFunction[2, 2, 1] = {{-(-1)^(7/8)}}
balancedCategories[IsingCat1Brd2] ^= {IsingCat1Bal3, IsingCat1Bal4}
 
IsingCat1Brd2 /: balancedCategory[IsingCat1Brd2, 1] = IsingCat1Bal3
 
IsingCat1Brd2 /: balancedCategory[IsingCat1Brd2, 2] = IsingCat1Bal4
 
braidedCategory[IsingCat1Brd2] ^= IsingCat1Brd2
 
fusionCategory[IsingCat1Brd2] ^= IsingCat1
 
IsingCat1Brd2 /: modularCategory[IsingCat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
IsingCat1Brd2 /: ribbonCategory[IsingCat1Brd2, 1] = IsingCat1Bal3
 
IsingCat1Brd2 /: ribbonCategory[IsingCat1Brd2, 2] = IsingCat1Bal4
 
ring[IsingCat1Brd2] ^= Ising
 
rMatrixFunction[IsingCat1Brd2] ^= IsingCat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[IsingCat1]][braidedCategory[#1]] & )[
    IsingCat1Brd2] ^= 2
braidedCategory[IsingCat1Brd2RMatrixFunction] ^= IsingCat1Brd2
 
fusionCategory[IsingCat1Brd2RMatrixFunction] ^= IsingCat1
 
rMatrixFunction[IsingCat1Brd2RMatrixFunction] ^= IsingCat1Brd2RMatrixFunction
 
IsingCat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
IsingCat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
IsingCat1Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
IsingCat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
IsingCat1Brd2RMatrixFunction[1, 1, 0] = {{-1}}
 
IsingCat1Brd2RMatrixFunction[1, 2, 2] = {{I}}
 
IsingCat1Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
IsingCat1Brd2RMatrixFunction[2, 1, 2] = {{I}}
 
IsingCat1Brd2RMatrixFunction[2, 2, 0] = {{(-1)^(3/8)}}
 
IsingCat1Brd2RMatrixFunction[2, 2, 1] = {{(-1)^(7/8)}}
balancedCategories[IsingCat1Brd3] ^= {IsingCat1Bal5, IsingCat1Bal6}
 
IsingCat1Brd3 /: balancedCategory[IsingCat1Brd3, 1] = IsingCat1Bal5
 
IsingCat1Brd3 /: balancedCategory[IsingCat1Brd3, 2] = IsingCat1Bal6
 
braidedCategory[IsingCat1Brd3] ^= IsingCat1Brd3
 
fusionCategory[IsingCat1Brd3] ^= IsingCat1
 
IsingCat1Brd3 /: modularCategory[IsingCat1Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
IsingCat1Brd3 /: ribbonCategory[IsingCat1Brd3, 1] = IsingCat1Bal5
 
IsingCat1Brd3 /: ribbonCategory[IsingCat1Brd3, 2] = IsingCat1Bal6
 
ring[IsingCat1Brd3] ^= Ising
 
rMatrixFunction[IsingCat1Brd3] ^= IsingCat1Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[IsingCat1]][braidedCategory[#1]] & )[
    IsingCat1Brd3] ^= 3
braidedCategory[IsingCat1Brd3RMatrixFunction] ^= IsingCat1Brd3
 
fusionCategory[IsingCat1Brd3RMatrixFunction] ^= IsingCat1
 
rMatrixFunction[IsingCat1Brd3RMatrixFunction] ^= IsingCat1Brd3RMatrixFunction
 
IsingCat1Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
IsingCat1Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
IsingCat1Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
IsingCat1Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
IsingCat1Brd3RMatrixFunction[1, 1, 0] = {{-1}}
 
IsingCat1Brd3RMatrixFunction[1, 2, 2] = {{-I}}
 
IsingCat1Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
IsingCat1Brd3RMatrixFunction[2, 1, 2] = {{-I}}
 
IsingCat1Brd3RMatrixFunction[2, 2, 0] = {{-(-1)^(5/8)}}
 
IsingCat1Brd3RMatrixFunction[2, 2, 1] = {{-(-1)^(1/8)}}
balancedCategories[IsingCat1Brd4] ^= {IsingCat1Bal7, IsingCat1Bal8}
 
IsingCat1Brd4 /: balancedCategory[IsingCat1Brd4, 1] = IsingCat1Bal7
 
IsingCat1Brd4 /: balancedCategory[IsingCat1Brd4, 2] = IsingCat1Bal8
 
braidedCategory[IsingCat1Brd4] ^= IsingCat1Brd4
 
fusionCategory[IsingCat1Brd4] ^= IsingCat1
 
IsingCat1Brd4 /: modularCategory[IsingCat1Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
IsingCat1Brd4 /: ribbonCategory[IsingCat1Brd4, 1] = IsingCat1Bal7
 
IsingCat1Brd4 /: ribbonCategory[IsingCat1Brd4, 2] = IsingCat1Bal8
 
ring[IsingCat1Brd4] ^= Ising
 
rMatrixFunction[IsingCat1Brd4] ^= IsingCat1Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[IsingCat1]][braidedCategory[#1]] & )[
    IsingCat1Brd4] ^= 4
braidedCategory[IsingCat1Brd4RMatrixFunction] ^= IsingCat1Brd4
 
fusionCategory[IsingCat1Brd4RMatrixFunction] ^= IsingCat1
 
rMatrixFunction[IsingCat1Brd4RMatrixFunction] ^= IsingCat1Brd4RMatrixFunction
 
IsingCat1Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
IsingCat1Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
IsingCat1Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
IsingCat1Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
IsingCat1Brd4RMatrixFunction[1, 1, 0] = {{-1}}
 
IsingCat1Brd4RMatrixFunction[1, 2, 2] = {{-I}}
 
IsingCat1Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
IsingCat1Brd4RMatrixFunction[2, 1, 2] = {{-I}}
 
IsingCat1Brd4RMatrixFunction[2, 2, 0] = {{(-1)^(5/8)}}
 
IsingCat1Brd4RMatrixFunction[2, 2, 1] = {{(-1)^(1/8)}}
fMatrixFunction[IsingCat1FMatrixFunction] ^= IsingCat1FMatrixFunction
 
fusionCategory[IsingCat1FMatrixFunction] ^= IsingCat1
 
ring[IsingCat1FMatrixFunction] ^= Ising
 
IsingCat1FMatrixFunction[1, 2, 1, 2] = {{-1}}
 
IsingCat1FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
IsingCat1FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
IsingCat1FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
IsingCat1FMatrixFunction[2, 2, 2, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
IsingCat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[IsingCat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
IsingCat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[IsingCat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[IsingCat1Piv1] ^= {IsingCat1Bal1, IsingCat1Bal3, 
    IsingCat1Bal5, IsingCat1Bal7}
 
IsingCat1Piv1 /: balancedCategory[IsingCat1Piv1, 1] = IsingCat1Bal1
 
IsingCat1Piv1 /: balancedCategory[IsingCat1Piv1, 2] = IsingCat1Bal3
 
IsingCat1Piv1 /: balancedCategory[IsingCat1Piv1, 3] = IsingCat1Bal5
 
IsingCat1Piv1 /: balancedCategory[IsingCat1Piv1, 4] = IsingCat1Bal7
 
fusionCategory[IsingCat1Piv1] ^= IsingCat1
 
IsingCat1Piv1 /: modularCategory[IsingCat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[IsingCat1Piv1] ^= IsingCat1Piv1
 
pivotalIsomorphism[IsingCat1Piv1] ^= IsingCat1Piv1PivotalIsomorphism
 
IsingCat1Piv1 /: ribbonCategory[IsingCat1Piv1, 1] = IsingCat1Bal1
 
IsingCat1Piv1 /: ribbonCategory[IsingCat1Piv1, 2] = IsingCat1Bal3
 
IsingCat1Piv1 /: ribbonCategory[IsingCat1Piv1, 3] = IsingCat1Bal5
 
IsingCat1Piv1 /: ribbonCategory[IsingCat1Piv1, 4] = IsingCat1Bal7
 
ring[IsingCat1Piv1] ^= Ising
 
sphericalCategory[IsingCat1Piv1] ^= IsingCat1Piv1
 
(pivotalCategoryIndex[fusionCategory[IsingCat1]][pivotalCategory[#1]] & )[
    IsingCat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[IsingCat1]][sphericalCategory[#1]] & )[
    IsingCat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[IsingCat1Piv1PivotalIsomorphism] ^= IsingCat1
 
pivotalCategory[IsingCat1Piv1PivotalIsomorphism] ^= IsingCat1Piv1
 
pivotalIsomorphism[IsingCat1Piv1PivotalIsomorphism] ^= 
   IsingCat1Piv1PivotalIsomorphism
 
IsingCat1Piv1PivotalIsomorphism[0] = 1
 
IsingCat1Piv1PivotalIsomorphism[1] = 1
 
IsingCat1Piv1PivotalIsomorphism[2] = 1
balancedCategories[IsingCat1Piv2] ^= {IsingCat1Bal2, IsingCat1Bal4, 
    IsingCat1Bal6, IsingCat1Bal8}
 
IsingCat1Piv2 /: balancedCategory[IsingCat1Piv2, 1] = IsingCat1Bal2
 
IsingCat1Piv2 /: balancedCategory[IsingCat1Piv2, 2] = IsingCat1Bal4
 
IsingCat1Piv2 /: balancedCategory[IsingCat1Piv2, 3] = IsingCat1Bal6
 
IsingCat1Piv2 /: balancedCategory[IsingCat1Piv2, 4] = IsingCat1Bal8
 
fusionCategory[IsingCat1Piv2] ^= IsingCat1
 
IsingCat1Piv2 /: modularCategory[IsingCat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[IsingCat1Piv2] ^= IsingCat1Piv2
 
pivotalIsomorphism[IsingCat1Piv2] ^= IsingCat1Piv2PivotalIsomorphism
 
IsingCat1Piv2 /: ribbonCategory[IsingCat1Piv2, 1] = IsingCat1Bal2
 
IsingCat1Piv2 /: ribbonCategory[IsingCat1Piv2, 2] = IsingCat1Bal4
 
IsingCat1Piv2 /: ribbonCategory[IsingCat1Piv2, 3] = IsingCat1Bal6
 
IsingCat1Piv2 /: ribbonCategory[IsingCat1Piv2, 4] = IsingCat1Bal8
 
ring[IsingCat1Piv2] ^= Ising
 
sphericalCategory[IsingCat1Piv2] ^= IsingCat1Piv2
 
(pivotalCategoryIndex[fusionCategory[IsingCat1]][pivotalCategory[#1]] & )[
    IsingCat1Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[IsingCat1]][sphericalCategory[#1]] & )[
    IsingCat1Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[IsingCat1Piv2PivotalIsomorphism] ^= IsingCat1
 
pivotalCategory[IsingCat1Piv2PivotalIsomorphism] ^= IsingCat1Piv2
 
pivotalIsomorphism[IsingCat1Piv2PivotalIsomorphism] ^= 
   IsingCat1Piv2PivotalIsomorphism
 
IsingCat1Piv2PivotalIsomorphism[0] = 1
 
IsingCat1Piv2PivotalIsomorphism[1] = 1
 
IsingCat1Piv2PivotalIsomorphism[2] = -1
balancedCategories[IsingCat2] ^= {IsingCat2Bal1, IsingCat2Bal2, 
    IsingCat2Bal3, IsingCat2Bal4, IsingCat2Bal5, IsingCat2Bal6, 
    IsingCat2Bal7, IsingCat2Bal8}
 
IsingCat2 /: balancedCategory[IsingCat2, 1] = IsingCat2Bal1
 
IsingCat2 /: balancedCategory[IsingCat2, 2] = IsingCat2Bal2
 
IsingCat2 /: balancedCategory[IsingCat2, 3] = IsingCat2Bal3
 
IsingCat2 /: balancedCategory[IsingCat2, 4] = IsingCat2Bal4
 
IsingCat2 /: balancedCategory[IsingCat2, 5] = IsingCat2Bal5
 
IsingCat2 /: balancedCategory[IsingCat2, 6] = IsingCat2Bal6
 
IsingCat2 /: balancedCategory[IsingCat2, 7] = IsingCat2Bal7
 
IsingCat2 /: balancedCategory[IsingCat2, 8] = IsingCat2Bal8
 
braidedCategories[IsingCat2] ^= {IsingCat2Brd1, IsingCat2Brd2, IsingCat2Brd3, 
    IsingCat2Brd4}
 
IsingCat2 /: braidedCategory[IsingCat2, 1] = IsingCat2Brd1
 
IsingCat2 /: braidedCategory[IsingCat2, 2] = IsingCat2Brd2
 
IsingCat2 /: braidedCategory[IsingCat2, 3] = IsingCat2Brd3
 
IsingCat2 /: braidedCategory[IsingCat2, 4] = IsingCat2Brd4
 
coeval[IsingCat2] ^= 1/sixJFunction[IsingCat2][#1, dual[ring[IsingCat2]][#1], 
      #1, #1, 0, 0] & 
 
eval[IsingCat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[IsingCat2] ^= IsingCat2FMatrixFunction
 
fusionCategory[IsingCat2] ^= IsingCat2
 
IsingCat2 /: modularCategory[IsingCat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[IsingCat2] ^= {IsingCat2Piv1, IsingCat2Piv2}
 
IsingCat2 /: pivotalCategory[IsingCat2, 1] = IsingCat2Piv1
 
IsingCat2 /: pivotalCategory[IsingCat2, 2] = IsingCat2Piv2
 
IsingCat2 /: pivotalCategory[IsingCat2, {1, 1, -1}] = IsingCat2Piv2
 
IsingCat2 /: pivotalCategory[IsingCat2, {1, 1, 1}] = IsingCat2Piv1
 
IsingCat2 /: ribbonCategory[IsingCat2, 1] = IsingCat2Bal1
 
IsingCat2 /: ribbonCategory[IsingCat2, 2] = IsingCat2Bal2
 
IsingCat2 /: ribbonCategory[IsingCat2, 3] = IsingCat2Bal3
 
IsingCat2 /: ribbonCategory[IsingCat2, 4] = IsingCat2Bal4
 
IsingCat2 /: ribbonCategory[IsingCat2, 5] = IsingCat2Bal5
 
IsingCat2 /: ribbonCategory[IsingCat2, 6] = IsingCat2Bal6
 
IsingCat2 /: ribbonCategory[IsingCat2, 7] = IsingCat2Bal7
 
IsingCat2 /: ribbonCategory[IsingCat2, 8] = IsingCat2Bal8
 
ring[IsingCat2] ^= Ising
 
IsingCat2 /: sphericalCategory[IsingCat2, 1] = IsingCat2Piv1
 
IsingCat2 /: sphericalCategory[IsingCat2, 2] = IsingCat2Piv2
 
fusionCategoryIndex[Ising][IsingCat2] ^= 2
balancedCategory[IsingCat2Bal1] ^= IsingCat2Bal1
 
braidedCategory[IsingCat2Bal1] ^= IsingCat2Brd1
 
fusionCategory[IsingCat2Bal1] ^= IsingCat2
 
pivotalCategory[IsingCat2Bal1] ^= IsingCat2Piv1
 
ribbonCategory[IsingCat2Bal1] ^= IsingCat2Bal1
 
ring[IsingCat2Bal1] ^= Ising
 
sphericalCategory[IsingCat2Bal1] ^= IsingCat2Piv1
 
(balancedCategoryIndex[braidedCategory[IsingCat2Brd1]][
      balancedCategory[#1]] & )[IsingCat2Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[IsingCat2]][balancedCategory[#1]] & )[
    IsingCat2Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[IsingCat2Piv1]][
      balancedCategory[#1]] & )[IsingCat2Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[IsingCat2Brd1]][ribbonCategory[#1]] & )[
    IsingCat2Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[IsingCat2]][ribbonCategory[#1]] & )[
    IsingCat2Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[IsingCat2Piv1]][
      ribbonCategory[#1]] & )[IsingCat2Bal1] ^= 1
balancedCategory[IsingCat2Bal2] ^= IsingCat2Bal2
 
braidedCategory[IsingCat2Bal2] ^= IsingCat2Brd1
 
fusionCategory[IsingCat2Bal2] ^= IsingCat2
 
pivotalCategory[IsingCat2Bal2] ^= IsingCat2Piv2
 
ribbonCategory[IsingCat2Bal2] ^= IsingCat2Bal2
 
ring[IsingCat2Bal2] ^= Ising
 
sphericalCategory[IsingCat2Bal2] ^= IsingCat2Piv2
 
(balancedCategoryIndex[braidedCategory[IsingCat2Brd1]][
      balancedCategory[#1]] & )[IsingCat2Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[IsingCat2]][balancedCategory[#1]] & )[
    IsingCat2Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[IsingCat2Piv2]][
      balancedCategory[#1]] & )[IsingCat2Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[IsingCat2Brd1]][ribbonCategory[#1]] & )[
    IsingCat2Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[IsingCat2]][ribbonCategory[#1]] & )[
    IsingCat2Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[IsingCat2Piv2]][
      ribbonCategory[#1]] & )[IsingCat2Bal2] ^= 1
balancedCategory[IsingCat2Bal3] ^= IsingCat2Bal3
 
braidedCategory[IsingCat2Bal3] ^= IsingCat2Brd2
 
fusionCategory[IsingCat2Bal3] ^= IsingCat2
 
pivotalCategory[IsingCat2Bal3] ^= IsingCat2Piv1
 
ribbonCategory[IsingCat2Bal3] ^= IsingCat2Bal3
 
ring[IsingCat2Bal3] ^= Ising
 
sphericalCategory[IsingCat2Bal3] ^= IsingCat2Piv1
 
(balancedCategoryIndex[braidedCategory[IsingCat2Brd2]][
      balancedCategory[#1]] & )[IsingCat2Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[IsingCat2]][balancedCategory[#1]] & )[
    IsingCat2Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[IsingCat2Piv1]][
      balancedCategory[#1]] & )[IsingCat2Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[IsingCat2Brd2]][ribbonCategory[#1]] & )[
    IsingCat2Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[IsingCat2]][ribbonCategory[#1]] & )[
    IsingCat2Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[IsingCat2Piv1]][
      ribbonCategory[#1]] & )[IsingCat2Bal3] ^= 2
balancedCategory[IsingCat2Bal4] ^= IsingCat2Bal4
 
braidedCategory[IsingCat2Bal4] ^= IsingCat2Brd2
 
fusionCategory[IsingCat2Bal4] ^= IsingCat2
 
pivotalCategory[IsingCat2Bal4] ^= IsingCat2Piv2
 
ribbonCategory[IsingCat2Bal4] ^= IsingCat2Bal4
 
ring[IsingCat2Bal4] ^= Ising
 
sphericalCategory[IsingCat2Bal4] ^= IsingCat2Piv2
 
(balancedCategoryIndex[braidedCategory[IsingCat2Brd2]][
      balancedCategory[#1]] & )[IsingCat2Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[IsingCat2]][balancedCategory[#1]] & )[
    IsingCat2Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[IsingCat2Piv2]][
      balancedCategory[#1]] & )[IsingCat2Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[IsingCat2Brd2]][ribbonCategory[#1]] & )[
    IsingCat2Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[IsingCat2]][ribbonCategory[#1]] & )[
    IsingCat2Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[IsingCat2Piv2]][
      ribbonCategory[#1]] & )[IsingCat2Bal4] ^= 2
balancedCategory[IsingCat2Bal5] ^= IsingCat2Bal5
 
braidedCategory[IsingCat2Bal5] ^= IsingCat2Brd3
 
fusionCategory[IsingCat2Bal5] ^= IsingCat2
 
pivotalCategory[IsingCat2Bal5] ^= IsingCat2Piv1
 
ribbonCategory[IsingCat2Bal5] ^= IsingCat2Bal5
 
ring[IsingCat2Bal5] ^= Ising
 
sphericalCategory[IsingCat2Bal5] ^= IsingCat2Piv1
 
(balancedCategoryIndex[braidedCategory[IsingCat2Brd3]][
      balancedCategory[#1]] & )[IsingCat2Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[IsingCat2]][balancedCategory[#1]] & )[
    IsingCat2Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[IsingCat2Piv1]][
      balancedCategory[#1]] & )[IsingCat2Bal5] ^= 3
 
(ribbonCategoryIndex[braidedCategory[IsingCat2Brd3]][ribbonCategory[#1]] & )[
    IsingCat2Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[IsingCat2]][ribbonCategory[#1]] & )[
    IsingCat2Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[IsingCat2Piv1]][
      ribbonCategory[#1]] & )[IsingCat2Bal5] ^= 3
balancedCategory[IsingCat2Bal6] ^= IsingCat2Bal6
 
braidedCategory[IsingCat2Bal6] ^= IsingCat2Brd3
 
fusionCategory[IsingCat2Bal6] ^= IsingCat2
 
pivotalCategory[IsingCat2Bal6] ^= IsingCat2Piv2
 
ribbonCategory[IsingCat2Bal6] ^= IsingCat2Bal6
 
ring[IsingCat2Bal6] ^= Ising
 
sphericalCategory[IsingCat2Bal6] ^= IsingCat2Piv2
 
(balancedCategoryIndex[braidedCategory[IsingCat2Brd3]][
      balancedCategory[#1]] & )[IsingCat2Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[IsingCat2]][balancedCategory[#1]] & )[
    IsingCat2Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[IsingCat2Piv2]][
      balancedCategory[#1]] & )[IsingCat2Bal6] ^= 3
 
(ribbonCategoryIndex[braidedCategory[IsingCat2Brd3]][ribbonCategory[#1]] & )[
    IsingCat2Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[IsingCat2]][ribbonCategory[#1]] & )[
    IsingCat2Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[IsingCat2Piv2]][
      ribbonCategory[#1]] & )[IsingCat2Bal6] ^= 3
balancedCategory[IsingCat2Bal7] ^= IsingCat2Bal7
 
braidedCategory[IsingCat2Bal7] ^= IsingCat2Brd4
 
fusionCategory[IsingCat2Bal7] ^= IsingCat2
 
pivotalCategory[IsingCat2Bal7] ^= IsingCat2Piv1
 
ribbonCategory[IsingCat2Bal7] ^= IsingCat2Bal7
 
ring[IsingCat2Bal7] ^= Ising
 
sphericalCategory[IsingCat2Bal7] ^= IsingCat2Piv1
 
(balancedCategoryIndex[braidedCategory[IsingCat2Brd4]][
      balancedCategory[#1]] & )[IsingCat2Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[IsingCat2]][balancedCategory[#1]] & )[
    IsingCat2Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[IsingCat2Piv1]][
      balancedCategory[#1]] & )[IsingCat2Bal7] ^= 4
 
(ribbonCategoryIndex[braidedCategory[IsingCat2Brd4]][ribbonCategory[#1]] & )[
    IsingCat2Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[IsingCat2]][ribbonCategory[#1]] & )[
    IsingCat2Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[IsingCat2Piv1]][
      ribbonCategory[#1]] & )[IsingCat2Bal7] ^= 4
balancedCategory[IsingCat2Bal8] ^= IsingCat2Bal8
 
braidedCategory[IsingCat2Bal8] ^= IsingCat2Brd4
 
fusionCategory[IsingCat2Bal8] ^= IsingCat2
 
pivotalCategory[IsingCat2Bal8] ^= IsingCat2Piv2
 
ribbonCategory[IsingCat2Bal8] ^= IsingCat2Bal8
 
ring[IsingCat2Bal8] ^= Ising
 
sphericalCategory[IsingCat2Bal8] ^= IsingCat2Piv2
 
(balancedCategoryIndex[braidedCategory[IsingCat2Brd4]][
      balancedCategory[#1]] & )[IsingCat2Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[IsingCat2]][balancedCategory[#1]] & )[
    IsingCat2Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[IsingCat2Piv2]][
      balancedCategory[#1]] & )[IsingCat2Bal8] ^= 4
 
(ribbonCategoryIndex[braidedCategory[IsingCat2Brd4]][ribbonCategory[#1]] & )[
    IsingCat2Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[IsingCat2]][ribbonCategory[#1]] & )[
    IsingCat2Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[IsingCat2Piv2]][
      ribbonCategory[#1]] & )[IsingCat2Bal8] ^= 4
balancedCategories[IsingCat2Brd1] ^= {IsingCat2Bal1, IsingCat2Bal2}
 
IsingCat2Brd1 /: balancedCategory[IsingCat2Brd1, 1] = IsingCat2Bal1
 
IsingCat2Brd1 /: balancedCategory[IsingCat2Brd1, 2] = IsingCat2Bal2
 
braidedCategory[IsingCat2Brd1] ^= IsingCat2Brd1
 
fusionCategory[IsingCat2Brd1] ^= IsingCat2
 
IsingCat2Brd1 /: modularCategory[IsingCat2Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
IsingCat2Brd1 /: ribbonCategory[IsingCat2Brd1, 1] = IsingCat2Bal1
 
IsingCat2Brd1 /: ribbonCategory[IsingCat2Brd1, 2] = IsingCat2Bal2
 
ring[IsingCat2Brd1] ^= Ising
 
rMatrixFunction[IsingCat2Brd1] ^= IsingCat2Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[IsingCat2]][braidedCategory[#1]] & )[
    IsingCat2Brd1] ^= 1
braidedCategory[IsingCat2Brd1RMatrixFunction] ^= IsingCat2Brd1
 
fusionCategory[IsingCat2Brd1RMatrixFunction] ^= IsingCat2
 
rMatrixFunction[IsingCat2Brd1RMatrixFunction] ^= IsingCat2Brd1RMatrixFunction
 
IsingCat2Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
IsingCat2Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
IsingCat2Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
IsingCat2Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
IsingCat2Brd1RMatrixFunction[1, 1, 0] = {{-1}}
 
IsingCat2Brd1RMatrixFunction[1, 2, 2] = {{-I}}
 
IsingCat2Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
IsingCat2Brd1RMatrixFunction[2, 1, 2] = {{-I}}
 
IsingCat2Brd1RMatrixFunction[2, 2, 0] = {{-(-1)^(1/8)}}
 
IsingCat2Brd1RMatrixFunction[2, 2, 1] = {{(-1)^(5/8)}}
balancedCategories[IsingCat2Brd2] ^= {IsingCat2Bal3, IsingCat2Bal4}
 
IsingCat2Brd2 /: balancedCategory[IsingCat2Brd2, 1] = IsingCat2Bal3
 
IsingCat2Brd2 /: balancedCategory[IsingCat2Brd2, 2] = IsingCat2Bal4
 
braidedCategory[IsingCat2Brd2] ^= IsingCat2Brd2
 
fusionCategory[IsingCat2Brd2] ^= IsingCat2
 
IsingCat2Brd2 /: modularCategory[IsingCat2Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
IsingCat2Brd2 /: ribbonCategory[IsingCat2Brd2, 1] = IsingCat2Bal3
 
IsingCat2Brd2 /: ribbonCategory[IsingCat2Brd2, 2] = IsingCat2Bal4
 
ring[IsingCat2Brd2] ^= Ising
 
rMatrixFunction[IsingCat2Brd2] ^= IsingCat2Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[IsingCat2]][braidedCategory[#1]] & )[
    IsingCat2Brd2] ^= 2
braidedCategory[IsingCat2Brd2RMatrixFunction] ^= IsingCat2Brd2
 
fusionCategory[IsingCat2Brd2RMatrixFunction] ^= IsingCat2
 
rMatrixFunction[IsingCat2Brd2RMatrixFunction] ^= IsingCat2Brd2RMatrixFunction
 
IsingCat2Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
IsingCat2Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
IsingCat2Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
IsingCat2Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
IsingCat2Brd2RMatrixFunction[1, 1, 0] = {{-1}}
 
IsingCat2Brd2RMatrixFunction[1, 2, 2] = {{-I}}
 
IsingCat2Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
IsingCat2Brd2RMatrixFunction[2, 1, 2] = {{-I}}
 
IsingCat2Brd2RMatrixFunction[2, 2, 0] = {{(-1)^(1/8)}}
 
IsingCat2Brd2RMatrixFunction[2, 2, 1] = {{-(-1)^(5/8)}}
balancedCategories[IsingCat2Brd3] ^= {IsingCat2Bal5, IsingCat2Bal6}
 
IsingCat2Brd3 /: balancedCategory[IsingCat2Brd3, 1] = IsingCat2Bal5
 
IsingCat2Brd3 /: balancedCategory[IsingCat2Brd3, 2] = IsingCat2Bal6
 
braidedCategory[IsingCat2Brd3] ^= IsingCat2Brd3
 
fusionCategory[IsingCat2Brd3] ^= IsingCat2
 
IsingCat2Brd3 /: modularCategory[IsingCat2Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
IsingCat2Brd3 /: ribbonCategory[IsingCat2Brd3, 1] = IsingCat2Bal5
 
IsingCat2Brd3 /: ribbonCategory[IsingCat2Brd3, 2] = IsingCat2Bal6
 
ring[IsingCat2Brd3] ^= Ising
 
rMatrixFunction[IsingCat2Brd3] ^= IsingCat2Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[IsingCat2]][braidedCategory[#1]] & )[
    IsingCat2Brd3] ^= 3
braidedCategory[IsingCat2Brd3RMatrixFunction] ^= IsingCat2Brd3
 
fusionCategory[IsingCat2Brd3RMatrixFunction] ^= IsingCat2
 
rMatrixFunction[IsingCat2Brd3RMatrixFunction] ^= IsingCat2Brd3RMatrixFunction
 
IsingCat2Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
IsingCat2Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
IsingCat2Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
IsingCat2Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
IsingCat2Brd3RMatrixFunction[1, 1, 0] = {{-1}}
 
IsingCat2Brd3RMatrixFunction[1, 2, 2] = {{I}}
 
IsingCat2Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
IsingCat2Brd3RMatrixFunction[2, 1, 2] = {{I}}
 
IsingCat2Brd3RMatrixFunction[2, 2, 0] = {{-(-1)^(7/8)}}
 
IsingCat2Brd3RMatrixFunction[2, 2, 1] = {{(-1)^(3/8)}}
balancedCategories[IsingCat2Brd4] ^= {IsingCat2Bal7, IsingCat2Bal8}
 
IsingCat2Brd4 /: balancedCategory[IsingCat2Brd4, 1] = IsingCat2Bal7
 
IsingCat2Brd4 /: balancedCategory[IsingCat2Brd4, 2] = IsingCat2Bal8
 
braidedCategory[IsingCat2Brd4] ^= IsingCat2Brd4
 
fusionCategory[IsingCat2Brd4] ^= IsingCat2
 
IsingCat2Brd4 /: modularCategory[IsingCat2Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
IsingCat2Brd4 /: ribbonCategory[IsingCat2Brd4, 1] = IsingCat2Bal7
 
IsingCat2Brd4 /: ribbonCategory[IsingCat2Brd4, 2] = IsingCat2Bal8
 
ring[IsingCat2Brd4] ^= Ising
 
rMatrixFunction[IsingCat2Brd4] ^= IsingCat2Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[IsingCat2]][braidedCategory[#1]] & )[
    IsingCat2Brd4] ^= 4
braidedCategory[IsingCat2Brd4RMatrixFunction] ^= IsingCat2Brd4
 
fusionCategory[IsingCat2Brd4RMatrixFunction] ^= IsingCat2
 
rMatrixFunction[IsingCat2Brd4RMatrixFunction] ^= IsingCat2Brd4RMatrixFunction
 
IsingCat2Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
IsingCat2Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
IsingCat2Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
IsingCat2Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
IsingCat2Brd4RMatrixFunction[1, 1, 0] = {{-1}}
 
IsingCat2Brd4RMatrixFunction[1, 2, 2] = {{I}}
 
IsingCat2Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
IsingCat2Brd4RMatrixFunction[2, 1, 2] = {{I}}
 
IsingCat2Brd4RMatrixFunction[2, 2, 0] = {{(-1)^(7/8)}}
 
IsingCat2Brd4RMatrixFunction[2, 2, 1] = {{-(-1)^(3/8)}}
fMatrixFunction[IsingCat2FMatrixFunction] ^= IsingCat2FMatrixFunction
 
fusionCategory[IsingCat2FMatrixFunction] ^= IsingCat2
 
ring[IsingCat2FMatrixFunction] ^= Ising
 
IsingCat2FMatrixFunction[1, 2, 1, 2] = {{-1}}
 
IsingCat2FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
IsingCat2FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
IsingCat2FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
IsingCat2FMatrixFunction[2, 2, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
IsingCat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[IsingCat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
IsingCat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[IsingCat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[IsingCat2Piv1] ^= {IsingCat2Bal1, IsingCat2Bal3, 
    IsingCat2Bal5, IsingCat2Bal7}
 
IsingCat2Piv1 /: balancedCategory[IsingCat2Piv1, 1] = IsingCat2Bal1
 
IsingCat2Piv1 /: balancedCategory[IsingCat2Piv1, 2] = IsingCat2Bal3
 
IsingCat2Piv1 /: balancedCategory[IsingCat2Piv1, 3] = IsingCat2Bal5
 
IsingCat2Piv1 /: balancedCategory[IsingCat2Piv1, 4] = IsingCat2Bal7
 
fusionCategory[IsingCat2Piv1] ^= IsingCat2
 
IsingCat2Piv1 /: modularCategory[IsingCat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[IsingCat2Piv1] ^= IsingCat2Piv1
 
pivotalIsomorphism[IsingCat2Piv1] ^= IsingCat2Piv1PivotalIsomorphism
 
IsingCat2Piv1 /: ribbonCategory[IsingCat2Piv1, 1] = IsingCat2Bal1
 
IsingCat2Piv1 /: ribbonCategory[IsingCat2Piv1, 2] = IsingCat2Bal3
 
IsingCat2Piv1 /: ribbonCategory[IsingCat2Piv1, 3] = IsingCat2Bal5
 
IsingCat2Piv1 /: ribbonCategory[IsingCat2Piv1, 4] = IsingCat2Bal7
 
ring[IsingCat2Piv1] ^= Ising
 
sphericalCategory[IsingCat2Piv1] ^= IsingCat2Piv1
 
(pivotalCategoryIndex[fusionCategory[IsingCat2]][pivotalCategory[#1]] & )[
    IsingCat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[IsingCat2]][sphericalCategory[#1]] & )[
    IsingCat2Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[IsingCat2Piv1PivotalIsomorphism] ^= IsingCat2
 
pivotalCategory[IsingCat2Piv1PivotalIsomorphism] ^= IsingCat2Piv1
 
pivotalIsomorphism[IsingCat2Piv1PivotalIsomorphism] ^= 
   IsingCat2Piv1PivotalIsomorphism
 
IsingCat2Piv1PivotalIsomorphism[0] = 1
 
IsingCat2Piv1PivotalIsomorphism[1] = 1
 
IsingCat2Piv1PivotalIsomorphism[2] = 1
balancedCategories[IsingCat2Piv2] ^= {IsingCat2Bal2, IsingCat2Bal4, 
    IsingCat2Bal6, IsingCat2Bal8}
 
IsingCat2Piv2 /: balancedCategory[IsingCat2Piv2, 1] = IsingCat2Bal2
 
IsingCat2Piv2 /: balancedCategory[IsingCat2Piv2, 2] = IsingCat2Bal4
 
IsingCat2Piv2 /: balancedCategory[IsingCat2Piv2, 3] = IsingCat2Bal6
 
IsingCat2Piv2 /: balancedCategory[IsingCat2Piv2, 4] = IsingCat2Bal8
 
fusionCategory[IsingCat2Piv2] ^= IsingCat2
 
IsingCat2Piv2 /: modularCategory[IsingCat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[IsingCat2Piv2] ^= IsingCat2Piv2
 
pivotalIsomorphism[IsingCat2Piv2] ^= IsingCat2Piv2PivotalIsomorphism
 
IsingCat2Piv2 /: ribbonCategory[IsingCat2Piv2, 1] = IsingCat2Bal2
 
IsingCat2Piv2 /: ribbonCategory[IsingCat2Piv2, 2] = IsingCat2Bal4
 
IsingCat2Piv2 /: ribbonCategory[IsingCat2Piv2, 3] = IsingCat2Bal6
 
IsingCat2Piv2 /: ribbonCategory[IsingCat2Piv2, 4] = IsingCat2Bal8
 
ring[IsingCat2Piv2] ^= Ising
 
sphericalCategory[IsingCat2Piv2] ^= IsingCat2Piv2
 
(pivotalCategoryIndex[fusionCategory[IsingCat2]][pivotalCategory[#1]] & )[
    IsingCat2Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[IsingCat2]][sphericalCategory[#1]] & )[
    IsingCat2Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[IsingCat2Piv2PivotalIsomorphism] ^= IsingCat2
 
pivotalCategory[IsingCat2Piv2PivotalIsomorphism] ^= IsingCat2Piv2
 
pivotalIsomorphism[IsingCat2Piv2PivotalIsomorphism] ^= 
   IsingCat2Piv2PivotalIsomorphism
 
IsingCat2Piv2PivotalIsomorphism[0] = 1
 
IsingCat2Piv2PivotalIsomorphism[1] = 1
 
IsingCat2Piv2PivotalIsomorphism[2] = -1
ring[IsingNFunction] ^= Ising
 
IsingNFunction[0, 0, 0] = 1
 
IsingNFunction[0, 0, 1] = 0
 
IsingNFunction[0, 0, 2] = 0
 
IsingNFunction[0, 1, 0] = 0
 
IsingNFunction[0, 1, 1] = 1
 
IsingNFunction[0, 1, 2] = 0
 
IsingNFunction[0, 2, 0] = 0
 
IsingNFunction[0, 2, 1] = 0
 
IsingNFunction[0, 2, 2] = 1
 
IsingNFunction[1, 0, 0] = 0
 
IsingNFunction[1, 0, 1] = 1
 
IsingNFunction[1, 0, 2] = 0
 
IsingNFunction[1, 1, 0] = 1
 
IsingNFunction[1, 1, 1] = 0
 
IsingNFunction[1, 1, 2] = 0
 
IsingNFunction[1, 2, 0] = 0
 
IsingNFunction[1, 2, 1] = 0
 
IsingNFunction[1, 2, 2] = 1
 
IsingNFunction[2, 0, 0] = 0
 
IsingNFunction[2, 0, 1] = 0
 
IsingNFunction[2, 0, 2] = 1
 
IsingNFunction[2, 1, 0] = 0
 
IsingNFunction[2, 1, 1] = 0
 
IsingNFunction[2, 1, 2] = 1
 
IsingNFunction[2, 2, 0] = 1
 
IsingNFunction[2, 2, 1] = 1
 
IsingNFunction[2, 2, 2] = 0
 
IsingNFunction[FusionCategories`Data`Ising`Private`a_, FusionCategories`Data`Ising`Private`b_, FusionCategories`Data`Ising`Private`c_] := 0


 EndPackage[]
