BeginPackage["FusionCategories`Data`Z2`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[Z2] ^= {Z2Cat1, Z2Cat2}
 
Z2 /: fusionCategory[Z2, 1] = Z2Cat1
 
Z2 /: fusionCategory[Z2, 2] = Z2Cat2
 
nFunction[Z2] ^= Z2NFunction
 
noMultiplicities[Z2] ^= True
 
rank[Z2] ^= 2
 
ring[Z2] ^= Z2
balancedCategories[Z2Cat1] ^= {Z2Cat1Bal1, Z2Cat1Bal2, Z2Cat1Bal3, Z2Cat1Bal4}
 
Z2Cat1 /: balancedCategory[Z2Cat1, 1] = Z2Cat1Bal1
 
Z2Cat1 /: balancedCategory[Z2Cat1, 2] = Z2Cat1Bal2
 
Z2Cat1 /: balancedCategory[Z2Cat1, 3] = Z2Cat1Bal3
 
Z2Cat1 /: balancedCategory[Z2Cat1, 4] = Z2Cat1Bal4
 
braidedCategories[Z2Cat1] ^= {Z2Cat1Brd1, Z2Cat1Brd2}
 
Z2Cat1 /: braidedCategory[Z2Cat1, 1] = Z2Cat1Brd1
 
Z2Cat1 /: braidedCategory[Z2Cat1, 2] = Z2Cat1Brd2
 
coeval[Z2Cat1] ^= 1/sixJFunction[Z2Cat1][#1, dual[ring[Z2Cat1]][#1], #1, #1, 
      0, 0] & 
 
eval[Z2Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[Z2Cat1] ^= Z2Cat1FMatrixFunction
 
fusionCategory[Z2Cat1] ^= Z2Cat1
 
Z2Cat1 /: modularCategory[Z2Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[Z2Cat1] ^= {Z2Cat1Piv1, Z2Cat1Piv2}
 
Z2Cat1 /: pivotalCategory[Z2Cat1, 1] = Z2Cat1Piv1
 
Z2Cat1 /: pivotalCategory[Z2Cat1, 2] = Z2Cat1Piv2
 
Z2Cat1 /: pivotalCategory[Z2Cat1, {1, -1}] = Z2Cat1Piv2
 
Z2Cat1 /: pivotalCategory[Z2Cat1, {1, 1}] = Z2Cat1Piv1
 
Z2Cat1 /: ribbonCategory[Z2Cat1, 1] = Z2Cat1Bal1
 
Z2Cat1 /: ribbonCategory[Z2Cat1, 2] = Z2Cat1Bal2
 
Z2Cat1 /: ribbonCategory[Z2Cat1, 3] = Z2Cat1Bal3
 
Z2Cat1 /: ribbonCategory[Z2Cat1, 4] = Z2Cat1Bal4
 
ring[Z2Cat1] ^= Z2
 
Z2Cat1 /: sphericalCategory[Z2Cat1, 1] = Z2Cat1Piv1
 
Z2Cat1 /: sphericalCategory[Z2Cat1, 2] = Z2Cat1Piv2
 
fusionCategoryIndex[Z2][Z2Cat1] ^= 1
balancedCategory[Z2Cat1Bal1] ^= Z2Cat1Bal1
 
braidedCategory[Z2Cat1Bal1] ^= Z2Cat1Brd1
 
fusionCategory[Z2Cat1Bal1] ^= Z2Cat1
 
pivotalCategory[Z2Cat1Bal1] ^= Z2Cat1Piv1
 
ribbonCategory[Z2Cat1Bal1] ^= Z2Cat1Bal1
 
ring[Z2Cat1Bal1] ^= Z2
 
sphericalCategory[Z2Cat1Bal1] ^= Z2Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[Z2Cat1Brd1]][balancedCategory[#1]] & )[
    Z2Cat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z2Cat1]][balancedCategory[#1]] & )[
    Z2Cat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[Z2Cat1Piv1]][balancedCategory[#1]] & )[
    Z2Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[Z2Cat1Brd1]][ribbonCategory[#1]] & )[
    Z2Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z2Cat1]][ribbonCategory[#1]] & )[
    Z2Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[Z2Cat1Piv1]][ribbonCategory[#1]] & )[
    Z2Cat1Bal1] ^= 1
balancedCategory[Z2Cat1Bal2] ^= Z2Cat1Bal2
 
braidedCategory[Z2Cat1Bal2] ^= Z2Cat1Brd1
 
fusionCategory[Z2Cat1Bal2] ^= Z2Cat1
 
pivotalCategory[Z2Cat1Bal2] ^= Z2Cat1Piv2
 
ribbonCategory[Z2Cat1Bal2] ^= Z2Cat1Bal2
 
ring[Z2Cat1Bal2] ^= Z2
 
sphericalCategory[Z2Cat1Bal2] ^= Z2Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[Z2Cat1Brd1]][balancedCategory[#1]] & )[
    Z2Cat1Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z2Cat1]][balancedCategory[#1]] & )[
    Z2Cat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[Z2Cat1Piv2]][balancedCategory[#1]] & )[
    Z2Cat1Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[Z2Cat1Brd1]][ribbonCategory[#1]] & )[
    Z2Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[Z2Cat1]][ribbonCategory[#1]] & )[
    Z2Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[Z2Cat1Piv2]][ribbonCategory[#1]] & )[
    Z2Cat1Bal2] ^= 1
balancedCategory[Z2Cat1Bal3] ^= Z2Cat1Bal3
 
braidedCategory[Z2Cat1Bal3] ^= Z2Cat1Brd2
 
fusionCategory[Z2Cat1Bal3] ^= Z2Cat1
 
pivotalCategory[Z2Cat1Bal3] ^= Z2Cat1Piv1
 
ribbonCategory[Z2Cat1Bal3] ^= Z2Cat1Bal3
 
ring[Z2Cat1Bal3] ^= Z2
 
sphericalCategory[Z2Cat1Bal3] ^= Z2Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[Z2Cat1Brd2]][balancedCategory[#1]] & )[
    Z2Cat1Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z2Cat1]][balancedCategory[#1]] & )[
    Z2Cat1Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[Z2Cat1Piv1]][balancedCategory[#1]] & )[
    Z2Cat1Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[Z2Cat1Brd2]][ribbonCategory[#1]] & )[
    Z2Cat1Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z2Cat1]][ribbonCategory[#1]] & )[
    Z2Cat1Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[Z2Cat1Piv1]][ribbonCategory[#1]] & )[
    Z2Cat1Bal3] ^= 2
balancedCategory[Z2Cat1Bal4] ^= Z2Cat1Bal4
 
braidedCategory[Z2Cat1Bal4] ^= Z2Cat1Brd2
 
fusionCategory[Z2Cat1Bal4] ^= Z2Cat1
 
pivotalCategory[Z2Cat1Bal4] ^= Z2Cat1Piv2
 
ribbonCategory[Z2Cat1Bal4] ^= Z2Cat1Bal4
 
ring[Z2Cat1Bal4] ^= Z2
 
sphericalCategory[Z2Cat1Bal4] ^= Z2Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[Z2Cat1Brd2]][balancedCategory[#1]] & )[
    Z2Cat1Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z2Cat1]][balancedCategory[#1]] & )[
    Z2Cat1Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[Z2Cat1Piv2]][balancedCategory[#1]] & )[
    Z2Cat1Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[Z2Cat1Brd2]][ribbonCategory[#1]] & )[
    Z2Cat1Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[Z2Cat1]][ribbonCategory[#1]] & )[
    Z2Cat1Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[Z2Cat1Piv2]][ribbonCategory[#1]] & )[
    Z2Cat1Bal4] ^= 2
balancedCategories[Z2Cat1Brd1] ^= {Z2Cat1Bal1, Z2Cat1Bal2}
 
Z2Cat1Brd1 /: balancedCategory[Z2Cat1Brd1, 1] = Z2Cat1Bal1
 
Z2Cat1Brd1 /: balancedCategory[Z2Cat1Brd1, 2] = Z2Cat1Bal2
 
braidedCategory[Z2Cat1Brd1] ^= Z2Cat1Brd1
 
fusionCategory[Z2Cat1Brd1] ^= Z2Cat1
 
Z2Cat1Brd1 /: modularCategory[Z2Cat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z2Cat1Brd1 /: ribbonCategory[Z2Cat1Brd1, 1] = Z2Cat1Bal1
 
Z2Cat1Brd1 /: ribbonCategory[Z2Cat1Brd1, 2] = Z2Cat1Bal2
 
ring[Z2Cat1Brd1] ^= Z2
 
rMatrixFunction[Z2Cat1Brd1] ^= Z2Cat1Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[Z2Cat1]][braidedCategory[#1]] & )[
    Z2Cat1Brd1] ^= 1
braidedCategory[Z2Cat1Brd1RMatrixFunction] ^= Z2Cat1Brd1
 
fusionCategory[Z2Cat1Brd1RMatrixFunction] ^= Z2Cat1
 
rMatrixFunction[Z2Cat1Brd1RMatrixFunction] ^= Z2Cat1Brd1RMatrixFunction
 
Z2Cat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
Z2Cat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
Z2Cat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
Z2Cat1Brd1RMatrixFunction[1, 1, 0] = {{-I}}
balancedCategories[Z2Cat1Brd2] ^= {Z2Cat1Bal3, Z2Cat1Bal4}
 
Z2Cat1Brd2 /: balancedCategory[Z2Cat1Brd2, 1] = Z2Cat1Bal3
 
Z2Cat1Brd2 /: balancedCategory[Z2Cat1Brd2, 2] = Z2Cat1Bal4
 
braidedCategory[Z2Cat1Brd2] ^= Z2Cat1Brd2
 
fusionCategory[Z2Cat1Brd2] ^= Z2Cat1
 
Z2Cat1Brd2 /: modularCategory[Z2Cat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z2Cat1Brd2 /: ribbonCategory[Z2Cat1Brd2, 1] = Z2Cat1Bal3
 
Z2Cat1Brd2 /: ribbonCategory[Z2Cat1Brd2, 2] = Z2Cat1Bal4
 
ring[Z2Cat1Brd2] ^= Z2
 
rMatrixFunction[Z2Cat1Brd2] ^= Z2Cat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[Z2Cat1]][braidedCategory[#1]] & )[
    Z2Cat1Brd2] ^= 2
braidedCategory[Z2Cat1Brd2RMatrixFunction] ^= Z2Cat1Brd2
 
fusionCategory[Z2Cat1Brd2RMatrixFunction] ^= Z2Cat1
 
rMatrixFunction[Z2Cat1Brd2RMatrixFunction] ^= Z2Cat1Brd2RMatrixFunction
 
Z2Cat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
Z2Cat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
Z2Cat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
Z2Cat1Brd2RMatrixFunction[1, 1, 0] = {{I}}
fMatrixFunction[Z2Cat1FMatrixFunction] ^= Z2Cat1FMatrixFunction
 
fusionCategory[Z2Cat1FMatrixFunction] ^= Z2Cat1
 
ring[Z2Cat1FMatrixFunction] ^= Z2
 
Z2Cat1FMatrixFunction[1, 1, 1, 1] = {{-1}}
 
Z2Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z2Cat1], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
Z2Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z2Cat1], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[Z2Cat1Piv1] ^= {Z2Cat1Bal1, Z2Cat1Bal3}
 
Z2Cat1Piv1 /: balancedCategory[Z2Cat1Piv1, 1] = Z2Cat1Bal1
 
Z2Cat1Piv1 /: balancedCategory[Z2Cat1Piv1, 2] = Z2Cat1Bal3
 
fusionCategory[Z2Cat1Piv1] ^= Z2Cat1
 
Z2Cat1Piv1 /: modularCategory[Z2Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z2Cat1Piv1] ^= Z2Cat1Piv1
 
pivotalIsomorphism[Z2Cat1Piv1] ^= Z2Cat1Piv1PivotalIsomorphism
 
Z2Cat1Piv1 /: ribbonCategory[Z2Cat1Piv1, 1] = Z2Cat1Bal1
 
Z2Cat1Piv1 /: ribbonCategory[Z2Cat1Piv1, 2] = Z2Cat1Bal3
 
ring[Z2Cat1Piv1] ^= Z2
 
sphericalCategory[Z2Cat1Piv1] ^= Z2Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[Z2Cat1]][pivotalCategory[#1]] & )[
    Z2Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[Z2Cat1]][sphericalCategory[#1]] & )[
    Z2Cat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z2Cat1Piv1PivotalIsomorphism] ^= Z2Cat1
 
pivotalCategory[Z2Cat1Piv1PivotalIsomorphism] ^= Z2Cat1Piv1
 
pivotalIsomorphism[Z2Cat1Piv1PivotalIsomorphism] ^= 
   Z2Cat1Piv1PivotalIsomorphism
 
Z2Cat1Piv1PivotalIsomorphism[0] = 1
 
Z2Cat1Piv1PivotalIsomorphism[1] = 1
balancedCategories[Z2Cat1Piv2] ^= {Z2Cat1Bal2, Z2Cat1Bal4}
 
Z2Cat1Piv2 /: balancedCategory[Z2Cat1Piv2, 1] = Z2Cat1Bal2
 
Z2Cat1Piv2 /: balancedCategory[Z2Cat1Piv2, 2] = Z2Cat1Bal4
 
fusionCategory[Z2Cat1Piv2] ^= Z2Cat1
 
Z2Cat1Piv2 /: modularCategory[Z2Cat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z2Cat1Piv2] ^= Z2Cat1Piv2
 
pivotalIsomorphism[Z2Cat1Piv2] ^= Z2Cat1Piv2PivotalIsomorphism
 
Z2Cat1Piv2 /: ribbonCategory[Z2Cat1Piv2, 1] = Z2Cat1Bal2
 
Z2Cat1Piv2 /: ribbonCategory[Z2Cat1Piv2, 2] = Z2Cat1Bal4
 
ring[Z2Cat1Piv2] ^= Z2
 
sphericalCategory[Z2Cat1Piv2] ^= Z2Cat1Piv2
 
(pivotalCategoryIndex[fusionCategory[Z2Cat1]][pivotalCategory[#1]] & )[
    Z2Cat1Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[Z2Cat1]][sphericalCategory[#1]] & )[
    Z2Cat1Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z2Cat1Piv2PivotalIsomorphism] ^= Z2Cat1
 
pivotalCategory[Z2Cat1Piv2PivotalIsomorphism] ^= Z2Cat1Piv2
 
pivotalIsomorphism[Z2Cat1Piv2PivotalIsomorphism] ^= 
   Z2Cat1Piv2PivotalIsomorphism
 
Z2Cat1Piv2PivotalIsomorphism[0] = 1
 
Z2Cat1Piv2PivotalIsomorphism[1] = -1
balancedCategories[Z2Cat2] ^= {Z2Cat2Bal1, Z2Cat2Bal2, Z2Cat2Bal3, Z2Cat2Bal4}
 
Z2Cat2 /: balancedCategory[Z2Cat2, 1] = Z2Cat2Bal1
 
Z2Cat2 /: balancedCategory[Z2Cat2, 2] = Z2Cat2Bal2
 
Z2Cat2 /: balancedCategory[Z2Cat2, 3] = Z2Cat2Bal3
 
Z2Cat2 /: balancedCategory[Z2Cat2, 4] = Z2Cat2Bal4
 
braidedCategories[Z2Cat2] ^= {Z2Cat2Brd1, Z2Cat2Brd2}
 
Z2Cat2 /: braidedCategory[Z2Cat2, 1] = Z2Cat2Brd1
 
Z2Cat2 /: braidedCategory[Z2Cat2, 2] = Z2Cat2Brd2
 
coeval[Z2Cat2] ^= 1/sixJFunction[Z2Cat2][#1, dual[ring[Z2Cat2]][#1], #1, #1, 
      0, 0] & 
 
eval[Z2Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[Z2Cat2] ^= Z2Cat2FMatrixFunction
 
fusionCategory[Z2Cat2] ^= Z2Cat2
 
Z2Cat2 /: modularCategory[Z2Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[Z2Cat2] ^= {Z2Cat2Piv1, Z2Cat2Piv2}
 
Z2Cat2 /: pivotalCategory[Z2Cat2, 1] = Z2Cat2Piv1
 
Z2Cat2 /: pivotalCategory[Z2Cat2, 2] = Z2Cat2Piv2
 
Z2Cat2 /: pivotalCategory[Z2Cat2, {1, -1}] = Z2Cat2Piv2
 
Z2Cat2 /: pivotalCategory[Z2Cat2, {1, 1}] = Z2Cat2Piv1
 
Z2Cat2 /: ribbonCategory[Z2Cat2, 1] = Z2Cat2Bal1
 
Z2Cat2 /: ribbonCategory[Z2Cat2, 2] = Z2Cat2Bal2
 
Z2Cat2 /: ribbonCategory[Z2Cat2, 3] = Z2Cat2Bal3
 
Z2Cat2 /: ribbonCategory[Z2Cat2, 4] = Z2Cat2Bal4
 
ring[Z2Cat2] ^= Z2
 
Z2Cat2 /: sphericalCategory[Z2Cat2, 1] = Z2Cat2Piv1
 
Z2Cat2 /: sphericalCategory[Z2Cat2, 2] = Z2Cat2Piv2
 
Z2Cat2 /: symmetricCategory[Z2Cat2, 1] = Z2Cat2Brd1
 
Z2Cat2 /: symmetricCategory[Z2Cat2, 2] = Z2Cat2Brd2
 
fusionCategoryIndex[Z2][Z2Cat2] ^= 2
balancedCategory[Z2Cat2Bal1] ^= Z2Cat2Bal1
 
braidedCategory[Z2Cat2Bal1] ^= Z2Cat2Brd1
 
fusionCategory[Z2Cat2Bal1] ^= Z2Cat2
 
pivotalCategory[Z2Cat2Bal1] ^= Z2Cat2Piv1
 
ribbonCategory[Z2Cat2Bal1] ^= Z2Cat2Bal1
 
ring[Z2Cat2Bal1] ^= Z2
 
sphericalCategory[Z2Cat2Bal1] ^= Z2Cat2Piv1
 
symmetricCategory[Z2Cat2Bal1] ^= Z2Cat2Brd1
 
(balancedCategoryIndex[braidedCategory[Z2Cat2Brd1]][balancedCategory[#1]] & )[
    Z2Cat2Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z2Cat2]][balancedCategory[#1]] & )[
    Z2Cat2Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[Z2Cat2Piv1]][balancedCategory[#1]] & )[
    Z2Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[Z2Cat2Brd1]][ribbonCategory[#1]] & )[
    Z2Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z2Cat2]][ribbonCategory[#1]] & )[
    Z2Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[Z2Cat2Piv1]][ribbonCategory[#1]] & )[
    Z2Cat2Bal1] ^= 1
balancedCategory[Z2Cat2Bal2] ^= Z2Cat2Bal2
 
braidedCategory[Z2Cat2Bal2] ^= Z2Cat2Brd1
 
fusionCategory[Z2Cat2Bal2] ^= Z2Cat2
 
pivotalCategory[Z2Cat2Bal2] ^= Z2Cat2Piv2
 
ribbonCategory[Z2Cat2Bal2] ^= Z2Cat2Bal2
 
ring[Z2Cat2Bal2] ^= Z2
 
sphericalCategory[Z2Cat2Bal2] ^= Z2Cat2Piv2
 
symmetricCategory[Z2Cat2Bal2] ^= Z2Cat2Brd1
 
(balancedCategoryIndex[braidedCategory[Z2Cat2Brd1]][balancedCategory[#1]] & )[
    Z2Cat2Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z2Cat2]][balancedCategory[#1]] & )[
    Z2Cat2Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[Z2Cat2Piv2]][balancedCategory[#1]] & )[
    Z2Cat2Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[Z2Cat2Brd1]][ribbonCategory[#1]] & )[
    Z2Cat2Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[Z2Cat2]][ribbonCategory[#1]] & )[
    Z2Cat2Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[Z2Cat2Piv2]][ribbonCategory[#1]] & )[
    Z2Cat2Bal2] ^= 1
balancedCategory[Z2Cat2Bal3] ^= Z2Cat2Bal3
 
braidedCategory[Z2Cat2Bal3] ^= Z2Cat2Brd2
 
fusionCategory[Z2Cat2Bal3] ^= Z2Cat2
 
pivotalCategory[Z2Cat2Bal3] ^= Z2Cat2Piv1
 
ribbonCategory[Z2Cat2Bal3] ^= Z2Cat2Bal3
 
ring[Z2Cat2Bal3] ^= Z2
 
sphericalCategory[Z2Cat2Bal3] ^= Z2Cat2Piv1
 
symmetricCategory[Z2Cat2Bal3] ^= Z2Cat2Brd2
 
(balancedCategoryIndex[braidedCategory[Z2Cat2Brd2]][balancedCategory[#1]] & )[
    Z2Cat2Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z2Cat2]][balancedCategory[#1]] & )[
    Z2Cat2Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[Z2Cat2Piv1]][balancedCategory[#1]] & )[
    Z2Cat2Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[Z2Cat2Brd2]][ribbonCategory[#1]] & )[
    Z2Cat2Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z2Cat2]][ribbonCategory[#1]] & )[
    Z2Cat2Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[Z2Cat2Piv1]][ribbonCategory[#1]] & )[
    Z2Cat2Bal3] ^= 2
balancedCategory[Z2Cat2Bal4] ^= Z2Cat2Bal4
 
braidedCategory[Z2Cat2Bal4] ^= Z2Cat2Brd2
 
fusionCategory[Z2Cat2Bal4] ^= Z2Cat2
 
pivotalCategory[Z2Cat2Bal4] ^= Z2Cat2Piv2
 
ribbonCategory[Z2Cat2Bal4] ^= Z2Cat2Bal4
 
ring[Z2Cat2Bal4] ^= Z2
 
sphericalCategory[Z2Cat2Bal4] ^= Z2Cat2Piv2
 
symmetricCategory[Z2Cat2Bal4] ^= Z2Cat2Brd2
 
(balancedCategoryIndex[braidedCategory[Z2Cat2Brd2]][balancedCategory[#1]] & )[
    Z2Cat2Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z2Cat2]][balancedCategory[#1]] & )[
    Z2Cat2Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[Z2Cat2Piv2]][balancedCategory[#1]] & )[
    Z2Cat2Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[Z2Cat2Brd2]][ribbonCategory[#1]] & )[
    Z2Cat2Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[Z2Cat2]][ribbonCategory[#1]] & )[
    Z2Cat2Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[Z2Cat2Piv2]][ribbonCategory[#1]] & )[
    Z2Cat2Bal4] ^= 2
balancedCategories[Z2Cat2Brd1] ^= {Z2Cat2Bal1, Z2Cat2Bal2}
 
Z2Cat2Brd1 /: balancedCategory[Z2Cat2Brd1, 1] = Z2Cat2Bal1
 
Z2Cat2Brd1 /: balancedCategory[Z2Cat2Brd1, 2] = Z2Cat2Bal2
 
braidedCategory[Z2Cat2Brd1] ^= Z2Cat2Brd1
 
fusionCategory[Z2Cat2Brd1] ^= Z2Cat2
 
Z2Cat2Brd1 /: modularCategory[Z2Cat2Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z2Cat2Brd1 /: ribbonCategory[Z2Cat2Brd1, 1] = Z2Cat2Bal1
 
Z2Cat2Brd1 /: ribbonCategory[Z2Cat2Brd1, 2] = Z2Cat2Bal2
 
ring[Z2Cat2Brd1] ^= Z2
 
rMatrixFunction[Z2Cat2Brd1] ^= Z2Cat2Brd1RMatrixFunction
 
symmetricCategory[Z2Cat2Brd1] ^= Z2Cat2Brd1
 
(braidedCategoryIndex[fusionCategory[Z2Cat2]][braidedCategory[#1]] & )[
    Z2Cat2Brd1] ^= 1
 
(symmetricCategoryIndex[fusionCategory[Z2Cat2]][symmetricCategory[#1]] & )[
    Z2Cat2Brd1] ^= 1
braidedCategory[Z2Cat2Brd1RMatrixFunction] ^= Z2Cat2Brd1
 
fusionCategory[Z2Cat2Brd1RMatrixFunction] ^= Z2Cat2
 
rMatrixFunction[Z2Cat2Brd1RMatrixFunction] ^= Z2Cat2Brd1RMatrixFunction
 
Z2Cat2Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
Z2Cat2Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
Z2Cat2Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
Z2Cat2Brd1RMatrixFunction[1, 1, 0] = {{-1}}
balancedCategories[Z2Cat2Brd2] ^= {Z2Cat2Bal3, Z2Cat2Bal4}
 
Z2Cat2Brd2 /: balancedCategory[Z2Cat2Brd2, 1] = Z2Cat2Bal3
 
Z2Cat2Brd2 /: balancedCategory[Z2Cat2Brd2, 2] = Z2Cat2Bal4
 
braidedCategory[Z2Cat2Brd2] ^= Z2Cat2Brd2
 
fusionCategory[Z2Cat2Brd2] ^= Z2Cat2
 
Z2Cat2Brd2 /: modularCategory[Z2Cat2Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z2Cat2Brd2 /: ribbonCategory[Z2Cat2Brd2, 1] = Z2Cat2Bal3
 
Z2Cat2Brd2 /: ribbonCategory[Z2Cat2Brd2, 2] = Z2Cat2Bal4
 
ring[Z2Cat2Brd2] ^= Z2
 
rMatrixFunction[Z2Cat2Brd2] ^= Z2Cat2Brd2RMatrixFunction
 
symmetricCategory[Z2Cat2Brd2] ^= Z2Cat2Brd2
 
(braidedCategoryIndex[fusionCategory[Z2Cat2]][braidedCategory[#1]] & )[
    Z2Cat2Brd2] ^= 2
 
(symmetricCategoryIndex[fusionCategory[Z2Cat2]][symmetricCategory[#1]] & )[
    Z2Cat2Brd2] ^= 2
braidedCategory[Z2Cat2Brd2RMatrixFunction] ^= Z2Cat2Brd2
 
fusionCategory[Z2Cat2Brd2RMatrixFunction] ^= Z2Cat2
 
rMatrixFunction[Z2Cat2Brd2RMatrixFunction] ^= Z2Cat2Brd2RMatrixFunction
 
Z2Cat2Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
Z2Cat2Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
Z2Cat2Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
Z2Cat2Brd2RMatrixFunction[1, 1, 0] = {{1}}
fMatrixFunction[Z2Cat2FMatrixFunction] ^= Z2Cat2FMatrixFunction
 
fusionCategory[Z2Cat2FMatrixFunction] ^= Z2Cat2
 
ring[Z2Cat2FMatrixFunction] ^= Z2
 
Z2Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z2Cat2], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
Z2Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z2Cat2], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[Z2Cat2Piv1] ^= {Z2Cat2Bal1, Z2Cat2Bal3}
 
Z2Cat2Piv1 /: balancedCategory[Z2Cat2Piv1, 1] = Z2Cat2Bal1
 
Z2Cat2Piv1 /: balancedCategory[Z2Cat2Piv1, 2] = Z2Cat2Bal3
 
fusionCategory[Z2Cat2Piv1] ^= Z2Cat2
 
Z2Cat2Piv1 /: modularCategory[Z2Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z2Cat2Piv1] ^= Z2Cat2Piv1
 
pivotalIsomorphism[Z2Cat2Piv1] ^= Z2Cat2Piv1PivotalIsomorphism
 
Z2Cat2Piv1 /: ribbonCategory[Z2Cat2Piv1, 1] = Z2Cat2Bal1
 
Z2Cat2Piv1 /: ribbonCategory[Z2Cat2Piv1, 2] = Z2Cat2Bal3
 
ring[Z2Cat2Piv1] ^= Z2
 
sphericalCategory[Z2Cat2Piv1] ^= Z2Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[Z2Cat2]][pivotalCategory[#1]] & )[
    Z2Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[Z2Cat2]][sphericalCategory[#1]] & )[
    Z2Cat2Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z2Cat2Piv1PivotalIsomorphism] ^= Z2Cat2
 
pivotalCategory[Z2Cat2Piv1PivotalIsomorphism] ^= Z2Cat2Piv1
 
pivotalIsomorphism[Z2Cat2Piv1PivotalIsomorphism] ^= 
   Z2Cat2Piv1PivotalIsomorphism
 
Z2Cat2Piv1PivotalIsomorphism[0] = 1
 
Z2Cat2Piv1PivotalIsomorphism[1] = 1
balancedCategories[Z2Cat2Piv2] ^= {Z2Cat2Bal2, Z2Cat2Bal4}
 
Z2Cat2Piv2 /: balancedCategory[Z2Cat2Piv2, 1] = Z2Cat2Bal2
 
Z2Cat2Piv2 /: balancedCategory[Z2Cat2Piv2, 2] = Z2Cat2Bal4
 
fusionCategory[Z2Cat2Piv2] ^= Z2Cat2
 
Z2Cat2Piv2 /: modularCategory[Z2Cat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z2Cat2Piv2] ^= Z2Cat2Piv2
 
pivotalIsomorphism[Z2Cat2Piv2] ^= Z2Cat2Piv2PivotalIsomorphism
 
Z2Cat2Piv2 /: ribbonCategory[Z2Cat2Piv2, 1] = Z2Cat2Bal2
 
Z2Cat2Piv2 /: ribbonCategory[Z2Cat2Piv2, 2] = Z2Cat2Bal4
 
ring[Z2Cat2Piv2] ^= Z2
 
sphericalCategory[Z2Cat2Piv2] ^= Z2Cat2Piv2
 
(pivotalCategoryIndex[fusionCategory[Z2Cat2]][pivotalCategory[#1]] & )[
    Z2Cat2Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[Z2Cat2]][sphericalCategory[#1]] & )[
    Z2Cat2Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z2Cat2Piv2PivotalIsomorphism] ^= Z2Cat2
 
pivotalCategory[Z2Cat2Piv2PivotalIsomorphism] ^= Z2Cat2Piv2
 
pivotalIsomorphism[Z2Cat2Piv2PivotalIsomorphism] ^= 
   Z2Cat2Piv2PivotalIsomorphism
 
Z2Cat2Piv2PivotalIsomorphism[0] = 1
 
Z2Cat2Piv2PivotalIsomorphism[1] = -1
ring[Z2NFunction] ^= Z2
 
Z2NFunction[0, 0, 0] = 1
 
Z2NFunction[0, 0, 1] = 0
 
Z2NFunction[0, 1, 0] = 0
 
Z2NFunction[0, 1, 1] = 1
 
Z2NFunction[1, 0, 0] = 0
 
Z2NFunction[1, 0, 1] = 1
 
Z2NFunction[1, 1, 0] = 1
 
Z2NFunction[1, 1, 1] = 0
 
Z2NFunction[FusionCategories`Data`Z2`Private`a_, FusionCategories`Data`Z2`Private`b_, FusionCategories`Data`Z2`Private`c_] := 0


 EndPackage[]
