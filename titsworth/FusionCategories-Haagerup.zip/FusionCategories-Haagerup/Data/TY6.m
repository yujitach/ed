BeginPackage["FusionCategories`Data`TY6`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[TY6] ^= {TY6Cat1, TY6Cat2, TY6Cat3, TY6Cat4}
 
TY6 /: fusionCategory[TY6, 1] = TY6Cat1
 
TY6 /: fusionCategory[TY6, 2] = TY6Cat2
 
TY6 /: fusionCategory[TY6, 3] = TY6Cat3
 
TY6 /: fusionCategory[TY6, 4] = TY6Cat4
 
nFunction[TY6] ^= TY6NFunction
 
noMultiplicities[TY6] ^= True
 
rank[TY6] ^= 7
 
ring[TY6] ^= TY6
balancedCategories[TY6Cat1] ^= {}
 
braidedCategories[TY6Cat1] ^= {}
 
coeval[TY6Cat1] ^= 1/sixJFunction[TY6Cat1][#1, dual[ring[TY6Cat1]][#1], #1, 
      #1, 0, 0] & 
 
eval[TY6Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TY6Cat1] ^= TY6Cat1FMatrixFunction
 
fusionCategory[TY6Cat1] ^= TY6Cat1
 
TY6Cat1 /: modularCategory[TY6Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TY6Cat1] ^= {TY6Cat1Piv1, TY6Cat1Piv2}
 
TY6Cat1 /: pivotalCategory[TY6Cat1, 1] = TY6Cat1Piv1
 
TY6Cat1 /: pivotalCategory[TY6Cat1, 2] = TY6Cat1Piv2
 
TY6Cat1 /: pivotalCategory[TY6Cat1, {1, 1, 1, 1, 1, 1, -1}] = TY6Cat1Piv2
 
TY6Cat1 /: pivotalCategory[TY6Cat1, {1, 1, 1, 1, 1, 1, 1}] = TY6Cat1Piv1
 
ring[TY6Cat1] ^= TY6
 
TY6Cat1 /: sphericalCategory[TY6Cat1, 1] = TY6Cat1Piv1
 
TY6Cat1 /: sphericalCategory[TY6Cat1, 2] = TY6Cat1Piv2
 
fusionCategoryIndex[TY6][TY6Cat1] ^= 1
fMatrixFunction[TY6Cat1FMatrixFunction] ^= TY6Cat1FMatrixFunction
 
fusionCategory[TY6Cat1FMatrixFunction] ^= TY6Cat1
 
ring[TY6Cat1FMatrixFunction] ^= TY6
 
TY6Cat1FMatrixFunction[1, 6, 1, 6] = {{(1 - I*Sqrt[3])/2}}
 
TY6Cat1FMatrixFunction[1, 6, 2, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[1, 6, 3, 6] = {{-1}}
 
TY6Cat1FMatrixFunction[1, 6, 4, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[1, 6, 5, 6] = {{(1 + I*Sqrt[3])/2}}
 
TY6Cat1FMatrixFunction[2, 6, 1, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[2, 6, 2, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[2, 6, 4, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[2, 6, 5, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[3, 6, 1, 6] = {{-1}}
 
TY6Cat1FMatrixFunction[3, 6, 3, 6] = {{-1}}
 
TY6Cat1FMatrixFunction[3, 6, 5, 6] = {{-1}}
 
TY6Cat1FMatrixFunction[4, 6, 1, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[4, 6, 2, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[4, 6, 4, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[4, 6, 5, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[5, 6, 1, 6] = {{(1 + I*Sqrt[3])/2}}
 
TY6Cat1FMatrixFunction[5, 6, 2, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[5, 6, 3, 6] = {{-1}}
 
TY6Cat1FMatrixFunction[5, 6, 4, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[5, 6, 5, 6] = {{(1 - I*Sqrt[3])/2}}
 
TY6Cat1FMatrixFunction[6, 1, 6, 1] = {{(1 - I*Sqrt[3])/2}}
 
TY6Cat1FMatrixFunction[6, 1, 6, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[6, 1, 6, 3] = {{-1}}
 
TY6Cat1FMatrixFunction[6, 1, 6, 4] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[6, 1, 6, 5] = {{(1 + I*Sqrt[3])/2}}
 
TY6Cat1FMatrixFunction[6, 2, 6, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[6, 2, 6, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[6, 2, 6, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[6, 2, 6, 5] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[6, 3, 6, 1] = {{-1}}
 
TY6Cat1FMatrixFunction[6, 3, 6, 3] = {{-1}}
 
TY6Cat1FMatrixFunction[6, 3, 6, 5] = {{-1}}
 
TY6Cat1FMatrixFunction[6, 4, 6, 1] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[6, 4, 6, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[6, 4, 6, 4] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[6, 4, 6, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[6, 5, 6, 1] = {{(1 + I*Sqrt[3])/2}}
 
TY6Cat1FMatrixFunction[6, 5, 6, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[6, 5, 6, 3] = {{-1}}
 
TY6Cat1FMatrixFunction[6, 5, 6, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat1FMatrixFunction[6, 5, 6, 5] = {{(1 - I*Sqrt[3])/2}}
 
TY6Cat1FMatrixFunction[6, 6, 6, 6] = 
   {{-(1/Sqrt[6]), -(1/Sqrt[6]), -(1/Sqrt[6]), -(1/Sqrt[6]), -(1/Sqrt[6]), 
     -(1/Sqrt[6])}, {-(1/Sqrt[6]), -((-1)^(1/3)/Sqrt[6]), 
     -((-1)^(2/3)/Sqrt[6]), 1/Sqrt[6], (-1)^(1/3)/Sqrt[6], 
     (-1)^(2/3)/Sqrt[6]}, {-(1/Sqrt[6]), -((-1)^(2/3)/Sqrt[6]), 
     (-1)^(1/3)/Sqrt[6], -(1/Sqrt[6]), -((-1)^(2/3)/Sqrt[6]), 
     (-1)^(1/3)/Sqrt[6]}, {-(1/Sqrt[6]), 1/Sqrt[6], -(1/Sqrt[6]), 1/Sqrt[6], 
     -(1/Sqrt[6]), 1/Sqrt[6]}, {-(1/Sqrt[6]), (-1)^(1/3)/Sqrt[6], 
     -((-1)^(2/3)/Sqrt[6]), -(1/Sqrt[6]), (-1)^(1/3)/Sqrt[6], 
     -((-1)^(2/3)/Sqrt[6])}, {-(1/Sqrt[6]), (-1)^(2/3)/Sqrt[6], 
     (-1)^(1/3)/Sqrt[6], 1/Sqrt[6], -((-1)^(2/3)/Sqrt[6]), 
     -((-1)^(1/3)/Sqrt[6])}}
 
TY6Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY6Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TY6Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY6Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TY6Cat1Piv1] ^= {}
 
fusionCategory[TY6Cat1Piv1] ^= TY6Cat1
 
TY6Cat1Piv1 /: modularCategory[TY6Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY6Cat1Piv1] ^= TY6Cat1Piv1
 
pivotalIsomorphism[TY6Cat1Piv1] ^= TY6Cat1Piv1PivotalIsomorphism
 
ring[TY6Cat1Piv1] ^= TY6
 
sphericalCategory[TY6Cat1Piv1] ^= TY6Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[TY6Cat1]][pivotalCategory[#1]] & )[
    TY6Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TY6Cat1]][sphericalCategory[#1]] & )[
    TY6Cat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY6Cat1Piv1PivotalIsomorphism] ^= TY6Cat1
 
pivotalCategory[TY6Cat1Piv1PivotalIsomorphism] ^= TY6Cat1Piv1
 
pivotalIsomorphism[TY6Cat1Piv1PivotalIsomorphism] ^= 
   TY6Cat1Piv1PivotalIsomorphism
 
TY6Cat1Piv1PivotalIsomorphism[0] = 1
 
TY6Cat1Piv1PivotalIsomorphism[1] = 1
 
TY6Cat1Piv1PivotalIsomorphism[2] = 1
 
TY6Cat1Piv1PivotalIsomorphism[3] = 1
 
TY6Cat1Piv1PivotalIsomorphism[4] = 1
 
TY6Cat1Piv1PivotalIsomorphism[5] = 1
 
TY6Cat1Piv1PivotalIsomorphism[6] = 1
balancedCategories[TY6Cat1Piv2] ^= {}
 
fusionCategory[TY6Cat1Piv2] ^= TY6Cat1
 
TY6Cat1Piv2 /: modularCategory[TY6Cat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY6Cat1Piv2] ^= TY6Cat1Piv2
 
pivotalIsomorphism[TY6Cat1Piv2] ^= TY6Cat1Piv2PivotalIsomorphism
 
ring[TY6Cat1Piv2] ^= TY6
 
sphericalCategory[TY6Cat1Piv2] ^= TY6Cat1Piv2
 
(pivotalCategoryIndex[fusionCategory[TY6Cat1]][pivotalCategory[#1]] & )[
    TY6Cat1Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TY6Cat1]][sphericalCategory[#1]] & )[
    TY6Cat1Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY6Cat1Piv2PivotalIsomorphism] ^= TY6Cat1
 
pivotalCategory[TY6Cat1Piv2PivotalIsomorphism] ^= TY6Cat1Piv2
 
pivotalIsomorphism[TY6Cat1Piv2PivotalIsomorphism] ^= 
   TY6Cat1Piv2PivotalIsomorphism
 
TY6Cat1Piv2PivotalIsomorphism[0] = 1
 
TY6Cat1Piv2PivotalIsomorphism[1] = 1
 
TY6Cat1Piv2PivotalIsomorphism[2] = 1
 
TY6Cat1Piv2PivotalIsomorphism[3] = 1
 
TY6Cat1Piv2PivotalIsomorphism[4] = 1
 
TY6Cat1Piv2PivotalIsomorphism[5] = 1
 
TY6Cat1Piv2PivotalIsomorphism[6] = -1
balancedCategories[TY6Cat2] ^= {}
 
braidedCategories[TY6Cat2] ^= {}
 
coeval[TY6Cat2] ^= 1/sixJFunction[TY6Cat2][#1, dual[ring[TY6Cat2]][#1], #1, 
      #1, 0, 0] & 
 
eval[TY6Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TY6Cat2] ^= TY6Cat2FMatrixFunction
 
fusionCategory[TY6Cat2] ^= TY6Cat2
 
TY6Cat2 /: modularCategory[TY6Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TY6Cat2] ^= {TY6Cat2Piv1, TY6Cat2Piv2}
 
TY6Cat2 /: pivotalCategory[TY6Cat2, 1] = TY6Cat2Piv1
 
TY6Cat2 /: pivotalCategory[TY6Cat2, 2] = TY6Cat2Piv2
 
TY6Cat2 /: pivotalCategory[TY6Cat2, {1, 1, 1, 1, 1, 1, -1}] = TY6Cat2Piv2
 
TY6Cat2 /: pivotalCategory[TY6Cat2, {1, 1, 1, 1, 1, 1, 1}] = TY6Cat2Piv1
 
ring[TY6Cat2] ^= TY6
 
TY6Cat2 /: sphericalCategory[TY6Cat2, 1] = TY6Cat2Piv1
 
TY6Cat2 /: sphericalCategory[TY6Cat2, 2] = TY6Cat2Piv2
 
fusionCategoryIndex[TY6][TY6Cat2] ^= 2
fMatrixFunction[TY6Cat2FMatrixFunction] ^= TY6Cat2FMatrixFunction
 
fusionCategory[TY6Cat2FMatrixFunction] ^= TY6Cat2
 
ring[TY6Cat2FMatrixFunction] ^= TY6
 
TY6Cat2FMatrixFunction[1, 6, 1, 6] = {{(1 + I*Sqrt[3])/2}}
 
TY6Cat2FMatrixFunction[1, 6, 2, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[1, 6, 3, 6] = {{-1}}
 
TY6Cat2FMatrixFunction[1, 6, 4, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[1, 6, 5, 6] = {{(1 - I*Sqrt[3])/2}}
 
TY6Cat2FMatrixFunction[2, 6, 1, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[2, 6, 2, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[2, 6, 4, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[2, 6, 5, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[3, 6, 1, 6] = {{-1}}
 
TY6Cat2FMatrixFunction[3, 6, 3, 6] = {{-1}}
 
TY6Cat2FMatrixFunction[3, 6, 5, 6] = {{-1}}
 
TY6Cat2FMatrixFunction[4, 6, 1, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[4, 6, 2, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[4, 6, 4, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[4, 6, 5, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[5, 6, 1, 6] = {{(1 - I*Sqrt[3])/2}}
 
TY6Cat2FMatrixFunction[5, 6, 2, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[5, 6, 3, 6] = {{-1}}
 
TY6Cat2FMatrixFunction[5, 6, 4, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[5, 6, 5, 6] = {{(1 + I*Sqrt[3])/2}}
 
TY6Cat2FMatrixFunction[6, 1, 6, 1] = {{(1 + I*Sqrt[3])/2}}
 
TY6Cat2FMatrixFunction[6, 1, 6, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[6, 1, 6, 3] = {{-1}}
 
TY6Cat2FMatrixFunction[6, 1, 6, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[6, 1, 6, 5] = {{(1 - I*Sqrt[3])/2}}
 
TY6Cat2FMatrixFunction[6, 2, 6, 1] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[6, 2, 6, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[6, 2, 6, 4] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[6, 2, 6, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[6, 3, 6, 1] = {{-1}}
 
TY6Cat2FMatrixFunction[6, 3, 6, 3] = {{-1}}
 
TY6Cat2FMatrixFunction[6, 3, 6, 5] = {{-1}}
 
TY6Cat2FMatrixFunction[6, 4, 6, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[6, 4, 6, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[6, 4, 6, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[6, 4, 6, 5] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[6, 5, 6, 1] = {{(1 - I*Sqrt[3])/2}}
 
TY6Cat2FMatrixFunction[6, 5, 6, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[6, 5, 6, 3] = {{-1}}
 
TY6Cat2FMatrixFunction[6, 5, 6, 4] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat2FMatrixFunction[6, 5, 6, 5] = {{(1 + I*Sqrt[3])/2}}
 
TY6Cat2FMatrixFunction[6, 6, 6, 6] = 
   {{-(1/Sqrt[6]), -(1/Sqrt[6]), -(1/Sqrt[6]), -(1/Sqrt[6]), -(1/Sqrt[6]), 
     -(1/Sqrt[6])}, {-(1/Sqrt[6]), (-1)^(2/3)/Sqrt[6], (-1)^(1/3)/Sqrt[6], 
     1/Sqrt[6], -((-1)^(2/3)/Sqrt[6]), -((-1)^(1/3)/Sqrt[6])}, 
    {-(1/Sqrt[6]), (-1)^(1/3)/Sqrt[6], -((-1)^(2/3)/Sqrt[6]), -(1/Sqrt[6]), 
     (-1)^(1/3)/Sqrt[6], -((-1)^(2/3)/Sqrt[6])}, {-(1/Sqrt[6]), 1/Sqrt[6], 
     -(1/Sqrt[6]), 1/Sqrt[6], -(1/Sqrt[6]), 1/Sqrt[6]}, 
    {-(1/Sqrt[6]), -((-1)^(2/3)/Sqrt[6]), (-1)^(1/3)/Sqrt[6], -(1/Sqrt[6]), 
     -((-1)^(2/3)/Sqrt[6]), (-1)^(1/3)/Sqrt[6]}, 
    {-(1/Sqrt[6]), -((-1)^(1/3)/Sqrt[6]), -((-1)^(2/3)/Sqrt[6]), 1/Sqrt[6], 
     (-1)^(1/3)/Sqrt[6], (-1)^(2/3)/Sqrt[6]}}
 
TY6Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY6Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TY6Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY6Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TY6Cat2Piv1] ^= {}
 
fusionCategory[TY6Cat2Piv1] ^= TY6Cat2
 
TY6Cat2Piv1 /: modularCategory[TY6Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY6Cat2Piv1] ^= TY6Cat2Piv1
 
pivotalIsomorphism[TY6Cat2Piv1] ^= TY6Cat2Piv1PivotalIsomorphism
 
ring[TY6Cat2Piv1] ^= TY6
 
sphericalCategory[TY6Cat2Piv1] ^= TY6Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[TY6Cat2]][pivotalCategory[#1]] & )[
    TY6Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TY6Cat2]][sphericalCategory[#1]] & )[
    TY6Cat2Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY6Cat2Piv1PivotalIsomorphism] ^= TY6Cat2
 
pivotalCategory[TY6Cat2Piv1PivotalIsomorphism] ^= TY6Cat2Piv1
 
pivotalIsomorphism[TY6Cat2Piv1PivotalIsomorphism] ^= 
   TY6Cat2Piv1PivotalIsomorphism
 
TY6Cat2Piv1PivotalIsomorphism[0] = 1
 
TY6Cat2Piv1PivotalIsomorphism[1] = 1
 
TY6Cat2Piv1PivotalIsomorphism[2] = 1
 
TY6Cat2Piv1PivotalIsomorphism[3] = 1
 
TY6Cat2Piv1PivotalIsomorphism[4] = 1
 
TY6Cat2Piv1PivotalIsomorphism[5] = 1
 
TY6Cat2Piv1PivotalIsomorphism[6] = 1
balancedCategories[TY6Cat2Piv2] ^= {}
 
fusionCategory[TY6Cat2Piv2] ^= TY6Cat2
 
TY6Cat2Piv2 /: modularCategory[TY6Cat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY6Cat2Piv2] ^= TY6Cat2Piv2
 
pivotalIsomorphism[TY6Cat2Piv2] ^= TY6Cat2Piv2PivotalIsomorphism
 
ring[TY6Cat2Piv2] ^= TY6
 
sphericalCategory[TY6Cat2Piv2] ^= TY6Cat2Piv2
 
(pivotalCategoryIndex[fusionCategory[TY6Cat2]][pivotalCategory[#1]] & )[
    TY6Cat2Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TY6Cat2]][sphericalCategory[#1]] & )[
    TY6Cat2Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY6Cat2Piv2PivotalIsomorphism] ^= TY6Cat2
 
pivotalCategory[TY6Cat2Piv2PivotalIsomorphism] ^= TY6Cat2Piv2
 
pivotalIsomorphism[TY6Cat2Piv2PivotalIsomorphism] ^= 
   TY6Cat2Piv2PivotalIsomorphism
 
TY6Cat2Piv2PivotalIsomorphism[0] = 1
 
TY6Cat2Piv2PivotalIsomorphism[1] = 1
 
TY6Cat2Piv2PivotalIsomorphism[2] = 1
 
TY6Cat2Piv2PivotalIsomorphism[3] = 1
 
TY6Cat2Piv2PivotalIsomorphism[4] = 1
 
TY6Cat2Piv2PivotalIsomorphism[5] = 1
 
TY6Cat2Piv2PivotalIsomorphism[6] = -1
balancedCategories[TY6Cat3] ^= {}
 
braidedCategories[TY6Cat3] ^= {}
 
coeval[TY6Cat3] ^= 1/sixJFunction[TY6Cat3][#1, dual[ring[TY6Cat3]][#1], #1, 
      #1, 0, 0] & 
 
eval[TY6Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TY6Cat3] ^= TY6Cat3FMatrixFunction
 
fusionCategory[TY6Cat3] ^= TY6Cat3
 
TY6Cat3 /: modularCategory[TY6Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TY6Cat3] ^= {TY6Cat3Piv1, TY6Cat3Piv2}
 
TY6Cat3 /: pivotalCategory[TY6Cat3, 1] = TY6Cat3Piv1
 
TY6Cat3 /: pivotalCategory[TY6Cat3, 2] = TY6Cat3Piv2
 
TY6Cat3 /: pivotalCategory[TY6Cat3, {1, 1, 1, 1, 1, 1, -1}] = TY6Cat3Piv2
 
TY6Cat3 /: pivotalCategory[TY6Cat3, {1, 1, 1, 1, 1, 1, 1}] = TY6Cat3Piv1
 
ring[TY6Cat3] ^= TY6
 
TY6Cat3 /: sphericalCategory[TY6Cat3, 1] = TY6Cat3Piv1
 
TY6Cat3 /: sphericalCategory[TY6Cat3, 2] = TY6Cat3Piv2
 
fusionCategoryIndex[TY6][TY6Cat3] ^= 3
fMatrixFunction[TY6Cat3FMatrixFunction] ^= TY6Cat3FMatrixFunction
 
fusionCategory[TY6Cat3FMatrixFunction] ^= TY6Cat3
 
ring[TY6Cat3FMatrixFunction] ^= TY6
 
TY6Cat3FMatrixFunction[1, 6, 1, 6] = {{(1 + I*Sqrt[3])/2}}
 
TY6Cat3FMatrixFunction[1, 6, 2, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[1, 6, 3, 6] = {{-1}}
 
TY6Cat3FMatrixFunction[1, 6, 4, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[1, 6, 5, 6] = {{(1 - I*Sqrt[3])/2}}
 
TY6Cat3FMatrixFunction[2, 6, 1, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[2, 6, 2, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[2, 6, 4, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[2, 6, 5, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[3, 6, 1, 6] = {{-1}}
 
TY6Cat3FMatrixFunction[3, 6, 3, 6] = {{-1}}
 
TY6Cat3FMatrixFunction[3, 6, 5, 6] = {{-1}}
 
TY6Cat3FMatrixFunction[4, 6, 1, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[4, 6, 2, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[4, 6, 4, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[4, 6, 5, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[5, 6, 1, 6] = {{(1 - I*Sqrt[3])/2}}
 
TY6Cat3FMatrixFunction[5, 6, 2, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[5, 6, 3, 6] = {{-1}}
 
TY6Cat3FMatrixFunction[5, 6, 4, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[5, 6, 5, 6] = {{(1 + I*Sqrt[3])/2}}
 
TY6Cat3FMatrixFunction[6, 1, 6, 1] = {{(1 + I*Sqrt[3])/2}}
 
TY6Cat3FMatrixFunction[6, 1, 6, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[6, 1, 6, 3] = {{-1}}
 
TY6Cat3FMatrixFunction[6, 1, 6, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[6, 1, 6, 5] = {{(1 - I*Sqrt[3])/2}}
 
TY6Cat3FMatrixFunction[6, 2, 6, 1] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[6, 2, 6, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[6, 2, 6, 4] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[6, 2, 6, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[6, 3, 6, 1] = {{-1}}
 
TY6Cat3FMatrixFunction[6, 3, 6, 3] = {{-1}}
 
TY6Cat3FMatrixFunction[6, 3, 6, 5] = {{-1}}
 
TY6Cat3FMatrixFunction[6, 4, 6, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[6, 4, 6, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[6, 4, 6, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[6, 4, 6, 5] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[6, 5, 6, 1] = {{(1 - I*Sqrt[3])/2}}
 
TY6Cat3FMatrixFunction[6, 5, 6, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[6, 5, 6, 3] = {{-1}}
 
TY6Cat3FMatrixFunction[6, 5, 6, 4] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat3FMatrixFunction[6, 5, 6, 5] = {{(1 + I*Sqrt[3])/2}}
 
TY6Cat3FMatrixFunction[6, 6, 6, 6] = {{1/Sqrt[6], 1/Sqrt[6], 1/Sqrt[6], 
     1/Sqrt[6], 1/Sqrt[6], 1/Sqrt[6]}, {1/Sqrt[6], -((-1)^(2/3)/Sqrt[6]), 
     -((-1)^(1/3)/Sqrt[6]), -(1/Sqrt[6]), (-1)^(2/3)/Sqrt[6], 
     (-1)^(1/3)/Sqrt[6]}, {1/Sqrt[6], -((-1)^(1/3)/Sqrt[6]), 
     (-1)^(2/3)/Sqrt[6], 1/Sqrt[6], -((-1)^(1/3)/Sqrt[6]), 
     (-1)^(2/3)/Sqrt[6]}, {1/Sqrt[6], -(1/Sqrt[6]), 1/Sqrt[6], -(1/Sqrt[6]), 
     1/Sqrt[6], -(1/Sqrt[6])}, {1/Sqrt[6], (-1)^(2/3)/Sqrt[6], 
     -((-1)^(1/3)/Sqrt[6]), 1/Sqrt[6], (-1)^(2/3)/Sqrt[6], 
     -((-1)^(1/3)/Sqrt[6])}, {1/Sqrt[6], (-1)^(1/3)/Sqrt[6], 
     (-1)^(2/3)/Sqrt[6], -(1/Sqrt[6]), -((-1)^(1/3)/Sqrt[6]), 
     -((-1)^(2/3)/Sqrt[6])}}
 
TY6Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY6Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TY6Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY6Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TY6Cat3Piv1] ^= {}
 
fusionCategory[TY6Cat3Piv1] ^= TY6Cat3
 
TY6Cat3Piv1 /: modularCategory[TY6Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY6Cat3Piv1] ^= TY6Cat3Piv1
 
pivotalIsomorphism[TY6Cat3Piv1] ^= TY6Cat3Piv1PivotalIsomorphism
 
ring[TY6Cat3Piv1] ^= TY6
 
sphericalCategory[TY6Cat3Piv1] ^= TY6Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[TY6Cat3]][pivotalCategory[#1]] & )[
    TY6Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TY6Cat3]][sphericalCategory[#1]] & )[
    TY6Cat3Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY6Cat3Piv1PivotalIsomorphism] ^= TY6Cat3
 
pivotalCategory[TY6Cat3Piv1PivotalIsomorphism] ^= TY6Cat3Piv1
 
pivotalIsomorphism[TY6Cat3Piv1PivotalIsomorphism] ^= 
   TY6Cat3Piv1PivotalIsomorphism
 
TY6Cat3Piv1PivotalIsomorphism[0] = 1
 
TY6Cat3Piv1PivotalIsomorphism[1] = 1
 
TY6Cat3Piv1PivotalIsomorphism[2] = 1
 
TY6Cat3Piv1PivotalIsomorphism[3] = 1
 
TY6Cat3Piv1PivotalIsomorphism[4] = 1
 
TY6Cat3Piv1PivotalIsomorphism[5] = 1
 
TY6Cat3Piv1PivotalIsomorphism[6] = 1
balancedCategories[TY6Cat3Piv2] ^= {}
 
fusionCategory[TY6Cat3Piv2] ^= TY6Cat3
 
TY6Cat3Piv2 /: modularCategory[TY6Cat3Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY6Cat3Piv2] ^= TY6Cat3Piv2
 
pivotalIsomorphism[TY6Cat3Piv2] ^= TY6Cat3Piv2PivotalIsomorphism
 
ring[TY6Cat3Piv2] ^= TY6
 
sphericalCategory[TY6Cat3Piv2] ^= TY6Cat3Piv2
 
(pivotalCategoryIndex[fusionCategory[TY6Cat3]][pivotalCategory[#1]] & )[
    TY6Cat3Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TY6Cat3]][sphericalCategory[#1]] & )[
    TY6Cat3Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY6Cat3Piv2PivotalIsomorphism] ^= TY6Cat3
 
pivotalCategory[TY6Cat3Piv2PivotalIsomorphism] ^= TY6Cat3Piv2
 
pivotalIsomorphism[TY6Cat3Piv2PivotalIsomorphism] ^= 
   TY6Cat3Piv2PivotalIsomorphism
 
TY6Cat3Piv2PivotalIsomorphism[0] = 1
 
TY6Cat3Piv2PivotalIsomorphism[1] = 1
 
TY6Cat3Piv2PivotalIsomorphism[2] = 1
 
TY6Cat3Piv2PivotalIsomorphism[3] = 1
 
TY6Cat3Piv2PivotalIsomorphism[4] = 1
 
TY6Cat3Piv2PivotalIsomorphism[5] = 1
 
TY6Cat3Piv2PivotalIsomorphism[6] = -1
balancedCategories[TY6Cat4] ^= {}
 
braidedCategories[TY6Cat4] ^= {}
 
coeval[TY6Cat4] ^= 1/sixJFunction[TY6Cat4][#1, dual[ring[TY6Cat4]][#1], #1, 
      #1, 0, 0] & 
 
eval[TY6Cat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TY6Cat4] ^= TY6Cat4FMatrixFunction
 
fusionCategory[TY6Cat4] ^= TY6Cat4
 
TY6Cat4 /: modularCategory[TY6Cat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TY6Cat4] ^= {TY6Cat4Piv1, TY6Cat4Piv2}
 
TY6Cat4 /: pivotalCategory[TY6Cat4, 1] = TY6Cat4Piv1
 
TY6Cat4 /: pivotalCategory[TY6Cat4, 2] = TY6Cat4Piv2
 
TY6Cat4 /: pivotalCategory[TY6Cat4, {1, 1, 1, 1, 1, 1, -1}] = TY6Cat4Piv2
 
TY6Cat4 /: pivotalCategory[TY6Cat4, {1, 1, 1, 1, 1, 1, 1}] = TY6Cat4Piv1
 
ring[TY6Cat4] ^= TY6
 
TY6Cat4 /: sphericalCategory[TY6Cat4, 1] = TY6Cat4Piv1
 
TY6Cat4 /: sphericalCategory[TY6Cat4, 2] = TY6Cat4Piv2
 
fusionCategoryIndex[TY6][TY6Cat4] ^= 4
fMatrixFunction[TY6Cat4FMatrixFunction] ^= TY6Cat4FMatrixFunction
 
fusionCategory[TY6Cat4FMatrixFunction] ^= TY6Cat4
 
ring[TY6Cat4FMatrixFunction] ^= TY6
 
TY6Cat4FMatrixFunction[1, 6, 1, 6] = {{(1 - I*Sqrt[3])/2}}
 
TY6Cat4FMatrixFunction[1, 6, 2, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[1, 6, 3, 6] = {{-1}}
 
TY6Cat4FMatrixFunction[1, 6, 4, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[1, 6, 5, 6] = {{(1 + I*Sqrt[3])/2}}
 
TY6Cat4FMatrixFunction[2, 6, 1, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[2, 6, 2, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[2, 6, 4, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[2, 6, 5, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[3, 6, 1, 6] = {{-1}}
 
TY6Cat4FMatrixFunction[3, 6, 3, 6] = {{-1}}
 
TY6Cat4FMatrixFunction[3, 6, 5, 6] = {{-1}}
 
TY6Cat4FMatrixFunction[4, 6, 1, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[4, 6, 2, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[4, 6, 4, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[4, 6, 5, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[5, 6, 1, 6] = {{(1 + I*Sqrt[3])/2}}
 
TY6Cat4FMatrixFunction[5, 6, 2, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[5, 6, 3, 6] = {{-1}}
 
TY6Cat4FMatrixFunction[5, 6, 4, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[5, 6, 5, 6] = {{(1 - I*Sqrt[3])/2}}
 
TY6Cat4FMatrixFunction[6, 1, 6, 1] = {{(1 - I*Sqrt[3])/2}}
 
TY6Cat4FMatrixFunction[6, 1, 6, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[6, 1, 6, 3] = {{-1}}
 
TY6Cat4FMatrixFunction[6, 1, 6, 4] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[6, 1, 6, 5] = {{(1 + I*Sqrt[3])/2}}
 
TY6Cat4FMatrixFunction[6, 2, 6, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[6, 2, 6, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[6, 2, 6, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[6, 2, 6, 5] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[6, 3, 6, 1] = {{-1}}
 
TY6Cat4FMatrixFunction[6, 3, 6, 3] = {{-1}}
 
TY6Cat4FMatrixFunction[6, 3, 6, 5] = {{-1}}
 
TY6Cat4FMatrixFunction[6, 4, 6, 1] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[6, 4, 6, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[6, 4, 6, 4] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[6, 4, 6, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[6, 5, 6, 1] = {{(1 + I*Sqrt[3])/2}}
 
TY6Cat4FMatrixFunction[6, 5, 6, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[6, 5, 6, 3] = {{-1}}
 
TY6Cat4FMatrixFunction[6, 5, 6, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY6Cat4FMatrixFunction[6, 5, 6, 5] = {{(1 - I*Sqrt[3])/2}}
 
TY6Cat4FMatrixFunction[6, 6, 6, 6] = {{1/Sqrt[6], 1/Sqrt[6], 1/Sqrt[6], 
     1/Sqrt[6], 1/Sqrt[6], 1/Sqrt[6]}, {1/Sqrt[6], (-1)^(1/3)/Sqrt[6], 
     (-1)^(2/3)/Sqrt[6], -(1/Sqrt[6]), -((-1)^(1/3)/Sqrt[6]), 
     -((-1)^(2/3)/Sqrt[6])}, {1/Sqrt[6], (-1)^(2/3)/Sqrt[6], 
     -((-1)^(1/3)/Sqrt[6]), 1/Sqrt[6], (-1)^(2/3)/Sqrt[6], 
     -((-1)^(1/3)/Sqrt[6])}, {1/Sqrt[6], -(1/Sqrt[6]), 1/Sqrt[6], 
     -(1/Sqrt[6]), 1/Sqrt[6], -(1/Sqrt[6])}, 
    {1/Sqrt[6], -((-1)^(1/3)/Sqrt[6]), (-1)^(2/3)/Sqrt[6], 1/Sqrt[6], 
     -((-1)^(1/3)/Sqrt[6]), (-1)^(2/3)/Sqrt[6]}, 
    {1/Sqrt[6], -((-1)^(2/3)/Sqrt[6]), -((-1)^(1/3)/Sqrt[6]), -(1/Sqrt[6]), 
     (-1)^(2/3)/Sqrt[6], (-1)^(1/3)/Sqrt[6]}}
 
TY6Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY6Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TY6Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY6Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TY6Cat4Piv1] ^= {}
 
fusionCategory[TY6Cat4Piv1] ^= TY6Cat4
 
TY6Cat4Piv1 /: modularCategory[TY6Cat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY6Cat4Piv1] ^= TY6Cat4Piv1
 
pivotalIsomorphism[TY6Cat4Piv1] ^= TY6Cat4Piv1PivotalIsomorphism
 
ring[TY6Cat4Piv1] ^= TY6
 
sphericalCategory[TY6Cat4Piv1] ^= TY6Cat4Piv1
 
(pivotalCategoryIndex[fusionCategory[TY6Cat4]][pivotalCategory[#1]] & )[
    TY6Cat4Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TY6Cat4]][sphericalCategory[#1]] & )[
    TY6Cat4Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY6Cat4Piv1PivotalIsomorphism] ^= TY6Cat4
 
pivotalCategory[TY6Cat4Piv1PivotalIsomorphism] ^= TY6Cat4Piv1
 
pivotalIsomorphism[TY6Cat4Piv1PivotalIsomorphism] ^= 
   TY6Cat4Piv1PivotalIsomorphism
 
TY6Cat4Piv1PivotalIsomorphism[0] = 1
 
TY6Cat4Piv1PivotalIsomorphism[1] = 1
 
TY6Cat4Piv1PivotalIsomorphism[2] = 1
 
TY6Cat4Piv1PivotalIsomorphism[3] = 1
 
TY6Cat4Piv1PivotalIsomorphism[4] = 1
 
TY6Cat4Piv1PivotalIsomorphism[5] = 1
 
TY6Cat4Piv1PivotalIsomorphism[6] = 1
balancedCategories[TY6Cat4Piv2] ^= {}
 
fusionCategory[TY6Cat4Piv2] ^= TY6Cat4
 
TY6Cat4Piv2 /: modularCategory[TY6Cat4Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY6Cat4Piv2] ^= TY6Cat4Piv2
 
pivotalIsomorphism[TY6Cat4Piv2] ^= TY6Cat4Piv2PivotalIsomorphism
 
ring[TY6Cat4Piv2] ^= TY6
 
sphericalCategory[TY6Cat4Piv2] ^= TY6Cat4Piv2
 
(pivotalCategoryIndex[fusionCategory[TY6Cat4]][pivotalCategory[#1]] & )[
    TY6Cat4Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TY6Cat4]][sphericalCategory[#1]] & )[
    TY6Cat4Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY6Cat4Piv2PivotalIsomorphism] ^= TY6Cat4
 
pivotalCategory[TY6Cat4Piv2PivotalIsomorphism] ^= TY6Cat4Piv2
 
pivotalIsomorphism[TY6Cat4Piv2PivotalIsomorphism] ^= 
   TY6Cat4Piv2PivotalIsomorphism
 
TY6Cat4Piv2PivotalIsomorphism[0] = 1
 
TY6Cat4Piv2PivotalIsomorphism[1] = 1
 
TY6Cat4Piv2PivotalIsomorphism[2] = 1
 
TY6Cat4Piv2PivotalIsomorphism[3] = 1
 
TY6Cat4Piv2PivotalIsomorphism[4] = 1
 
TY6Cat4Piv2PivotalIsomorphism[5] = 1
 
TY6Cat4Piv2PivotalIsomorphism[6] = -1
ring[TY6NFunction] ^= TY6
 
TY6NFunction[0, 0, 0] = 1
 
TY6NFunction[0, 0, 1] = 0
 
TY6NFunction[0, 0, 2] = 0
 
TY6NFunction[0, 0, 3] = 0
 
TY6NFunction[0, 0, 4] = 0
 
TY6NFunction[0, 0, 5] = 0
 
TY6NFunction[0, 0, 6] = 0
 
TY6NFunction[0, 1, 0] = 0
 
TY6NFunction[0, 1, 1] = 1
 
TY6NFunction[0, 1, 2] = 0
 
TY6NFunction[0, 1, 3] = 0
 
TY6NFunction[0, 1, 4] = 0
 
TY6NFunction[0, 1, 5] = 0
 
TY6NFunction[0, 1, 6] = 0
 
TY6NFunction[0, 2, 0] = 0
 
TY6NFunction[0, 2, 1] = 0
 
TY6NFunction[0, 2, 2] = 1
 
TY6NFunction[0, 2, 3] = 0
 
TY6NFunction[0, 2, 4] = 0
 
TY6NFunction[0, 2, 5] = 0
 
TY6NFunction[0, 2, 6] = 0
 
TY6NFunction[0, 3, 0] = 0
 
TY6NFunction[0, 3, 1] = 0
 
TY6NFunction[0, 3, 2] = 0
 
TY6NFunction[0, 3, 3] = 1
 
TY6NFunction[0, 3, 4] = 0
 
TY6NFunction[0, 3, 5] = 0
 
TY6NFunction[0, 3, 6] = 0
 
TY6NFunction[0, 4, 0] = 0
 
TY6NFunction[0, 4, 1] = 0
 
TY6NFunction[0, 4, 2] = 0
 
TY6NFunction[0, 4, 3] = 0
 
TY6NFunction[0, 4, 4] = 1
 
TY6NFunction[0, 4, 5] = 0
 
TY6NFunction[0, 4, 6] = 0
 
TY6NFunction[0, 5, 0] = 0
 
TY6NFunction[0, 5, 1] = 0
 
TY6NFunction[0, 5, 2] = 0
 
TY6NFunction[0, 5, 3] = 0
 
TY6NFunction[0, 5, 4] = 0
 
TY6NFunction[0, 5, 5] = 1
 
TY6NFunction[0, 5, 6] = 0
 
TY6NFunction[0, 6, 0] = 0
 
TY6NFunction[0, 6, 1] = 0
 
TY6NFunction[0, 6, 2] = 0
 
TY6NFunction[0, 6, 3] = 0
 
TY6NFunction[0, 6, 4] = 0
 
TY6NFunction[0, 6, 5] = 0
 
TY6NFunction[0, 6, 6] = 1
 
TY6NFunction[1, 0, 0] = 0
 
TY6NFunction[1, 0, 1] = 1
 
TY6NFunction[1, 0, 2] = 0
 
TY6NFunction[1, 0, 3] = 0
 
TY6NFunction[1, 0, 4] = 0
 
TY6NFunction[1, 0, 5] = 0
 
TY6NFunction[1, 0, 6] = 0
 
TY6NFunction[1, 1, 0] = 0
 
TY6NFunction[1, 1, 1] = 0
 
TY6NFunction[1, 1, 2] = 1
 
TY6NFunction[1, 1, 3] = 0
 
TY6NFunction[1, 1, 4] = 0
 
TY6NFunction[1, 1, 5] = 0
 
TY6NFunction[1, 1, 6] = 0
 
TY6NFunction[1, 2, 0] = 0
 
TY6NFunction[1, 2, 1] = 0
 
TY6NFunction[1, 2, 2] = 0
 
TY6NFunction[1, 2, 3] = 1
 
TY6NFunction[1, 2, 4] = 0
 
TY6NFunction[1, 2, 5] = 0
 
TY6NFunction[1, 2, 6] = 0
 
TY6NFunction[1, 3, 0] = 0
 
TY6NFunction[1, 3, 1] = 0
 
TY6NFunction[1, 3, 2] = 0
 
TY6NFunction[1, 3, 3] = 0
 
TY6NFunction[1, 3, 4] = 1
 
TY6NFunction[1, 3, 5] = 0
 
TY6NFunction[1, 3, 6] = 0
 
TY6NFunction[1, 4, 0] = 0
 
TY6NFunction[1, 4, 1] = 0
 
TY6NFunction[1, 4, 2] = 0
 
TY6NFunction[1, 4, 3] = 0
 
TY6NFunction[1, 4, 4] = 0
 
TY6NFunction[1, 4, 5] = 1
 
TY6NFunction[1, 4, 6] = 0
 
TY6NFunction[1, 5, 0] = 1
 
TY6NFunction[1, 5, 1] = 0
 
TY6NFunction[1, 5, 2] = 0
 
TY6NFunction[1, 5, 3] = 0
 
TY6NFunction[1, 5, 4] = 0
 
TY6NFunction[1, 5, 5] = 0
 
TY6NFunction[1, 5, 6] = 0
 
TY6NFunction[1, 6, 0] = 0
 
TY6NFunction[1, 6, 1] = 0
 
TY6NFunction[1, 6, 2] = 0
 
TY6NFunction[1, 6, 3] = 0
 
TY6NFunction[1, 6, 4] = 0
 
TY6NFunction[1, 6, 5] = 0
 
TY6NFunction[1, 6, 6] = 1
 
TY6NFunction[2, 0, 0] = 0
 
TY6NFunction[2, 0, 1] = 0
 
TY6NFunction[2, 0, 2] = 1
 
TY6NFunction[2, 0, 3] = 0
 
TY6NFunction[2, 0, 4] = 0
 
TY6NFunction[2, 0, 5] = 0
 
TY6NFunction[2, 0, 6] = 0
 
TY6NFunction[2, 1, 0] = 0
 
TY6NFunction[2, 1, 1] = 0
 
TY6NFunction[2, 1, 2] = 0
 
TY6NFunction[2, 1, 3] = 1
 
TY6NFunction[2, 1, 4] = 0
 
TY6NFunction[2, 1, 5] = 0
 
TY6NFunction[2, 1, 6] = 0
 
TY6NFunction[2, 2, 0] = 0
 
TY6NFunction[2, 2, 1] = 0
 
TY6NFunction[2, 2, 2] = 0
 
TY6NFunction[2, 2, 3] = 0
 
TY6NFunction[2, 2, 4] = 1
 
TY6NFunction[2, 2, 5] = 0
 
TY6NFunction[2, 2, 6] = 0
 
TY6NFunction[2, 3, 0] = 0
 
TY6NFunction[2, 3, 1] = 0
 
TY6NFunction[2, 3, 2] = 0
 
TY6NFunction[2, 3, 3] = 0
 
TY6NFunction[2, 3, 4] = 0
 
TY6NFunction[2, 3, 5] = 1
 
TY6NFunction[2, 3, 6] = 0
 
TY6NFunction[2, 4, 0] = 1
 
TY6NFunction[2, 4, 1] = 0
 
TY6NFunction[2, 4, 2] = 0
 
TY6NFunction[2, 4, 3] = 0
 
TY6NFunction[2, 4, 4] = 0
 
TY6NFunction[2, 4, 5] = 0
 
TY6NFunction[2, 4, 6] = 0
 
TY6NFunction[2, 5, 0] = 0
 
TY6NFunction[2, 5, 1] = 1
 
TY6NFunction[2, 5, 2] = 0
 
TY6NFunction[2, 5, 3] = 0
 
TY6NFunction[2, 5, 4] = 0
 
TY6NFunction[2, 5, 5] = 0
 
TY6NFunction[2, 5, 6] = 0
 
TY6NFunction[2, 6, 0] = 0
 
TY6NFunction[2, 6, 1] = 0
 
TY6NFunction[2, 6, 2] = 0
 
TY6NFunction[2, 6, 3] = 0
 
TY6NFunction[2, 6, 4] = 0
 
TY6NFunction[2, 6, 5] = 0
 
TY6NFunction[2, 6, 6] = 1
 
TY6NFunction[3, 0, 0] = 0
 
TY6NFunction[3, 0, 1] = 0
 
TY6NFunction[3, 0, 2] = 0
 
TY6NFunction[3, 0, 3] = 1
 
TY6NFunction[3, 0, 4] = 0
 
TY6NFunction[3, 0, 5] = 0
 
TY6NFunction[3, 0, 6] = 0
 
TY6NFunction[3, 1, 0] = 0
 
TY6NFunction[3, 1, 1] = 0
 
TY6NFunction[3, 1, 2] = 0
 
TY6NFunction[3, 1, 3] = 0
 
TY6NFunction[3, 1, 4] = 1
 
TY6NFunction[3, 1, 5] = 0
 
TY6NFunction[3, 1, 6] = 0
 
TY6NFunction[3, 2, 0] = 0
 
TY6NFunction[3, 2, 1] = 0
 
TY6NFunction[3, 2, 2] = 0
 
TY6NFunction[3, 2, 3] = 0
 
TY6NFunction[3, 2, 4] = 0
 
TY6NFunction[3, 2, 5] = 1
 
TY6NFunction[3, 2, 6] = 0
 
TY6NFunction[3, 3, 0] = 1
 
TY6NFunction[3, 3, 1] = 0
 
TY6NFunction[3, 3, 2] = 0
 
TY6NFunction[3, 3, 3] = 0
 
TY6NFunction[3, 3, 4] = 0
 
TY6NFunction[3, 3, 5] = 0
 
TY6NFunction[3, 3, 6] = 0
 
TY6NFunction[3, 4, 0] = 0
 
TY6NFunction[3, 4, 1] = 1
 
TY6NFunction[3, 4, 2] = 0
 
TY6NFunction[3, 4, 3] = 0
 
TY6NFunction[3, 4, 4] = 0
 
TY6NFunction[3, 4, 5] = 0
 
TY6NFunction[3, 4, 6] = 0
 
TY6NFunction[3, 5, 0] = 0
 
TY6NFunction[3, 5, 1] = 0
 
TY6NFunction[3, 5, 2] = 1
 
TY6NFunction[3, 5, 3] = 0
 
TY6NFunction[3, 5, 4] = 0
 
TY6NFunction[3, 5, 5] = 0
 
TY6NFunction[3, 5, 6] = 0
 
TY6NFunction[3, 6, 0] = 0
 
TY6NFunction[3, 6, 1] = 0
 
TY6NFunction[3, 6, 2] = 0
 
TY6NFunction[3, 6, 3] = 0
 
TY6NFunction[3, 6, 4] = 0
 
TY6NFunction[3, 6, 5] = 0
 
TY6NFunction[3, 6, 6] = 1
 
TY6NFunction[4, 0, 0] = 0
 
TY6NFunction[4, 0, 1] = 0
 
TY6NFunction[4, 0, 2] = 0
 
TY6NFunction[4, 0, 3] = 0
 
TY6NFunction[4, 0, 4] = 1
 
TY6NFunction[4, 0, 5] = 0
 
TY6NFunction[4, 0, 6] = 0
 
TY6NFunction[4, 1, 0] = 0
 
TY6NFunction[4, 1, 1] = 0
 
TY6NFunction[4, 1, 2] = 0
 
TY6NFunction[4, 1, 3] = 0
 
TY6NFunction[4, 1, 4] = 0
 
TY6NFunction[4, 1, 5] = 1
 
TY6NFunction[4, 1, 6] = 0
 
TY6NFunction[4, 2, 0] = 1
 
TY6NFunction[4, 2, 1] = 0
 
TY6NFunction[4, 2, 2] = 0
 
TY6NFunction[4, 2, 3] = 0
 
TY6NFunction[4, 2, 4] = 0
 
TY6NFunction[4, 2, 5] = 0
 
TY6NFunction[4, 2, 6] = 0
 
TY6NFunction[4, 3, 0] = 0
 
TY6NFunction[4, 3, 1] = 1
 
TY6NFunction[4, 3, 2] = 0
 
TY6NFunction[4, 3, 3] = 0
 
TY6NFunction[4, 3, 4] = 0
 
TY6NFunction[4, 3, 5] = 0
 
TY6NFunction[4, 3, 6] = 0
 
TY6NFunction[4, 4, 0] = 0
 
TY6NFunction[4, 4, 1] = 0
 
TY6NFunction[4, 4, 2] = 1
 
TY6NFunction[4, 4, 3] = 0
 
TY6NFunction[4, 4, 4] = 0
 
TY6NFunction[4, 4, 5] = 0
 
TY6NFunction[4, 4, 6] = 0
 
TY6NFunction[4, 5, 0] = 0
 
TY6NFunction[4, 5, 1] = 0
 
TY6NFunction[4, 5, 2] = 0
 
TY6NFunction[4, 5, 3] = 1
 
TY6NFunction[4, 5, 4] = 0
 
TY6NFunction[4, 5, 5] = 0
 
TY6NFunction[4, 5, 6] = 0
 
TY6NFunction[4, 6, 0] = 0
 
TY6NFunction[4, 6, 1] = 0
 
TY6NFunction[4, 6, 2] = 0
 
TY6NFunction[4, 6, 3] = 0
 
TY6NFunction[4, 6, 4] = 0
 
TY6NFunction[4, 6, 5] = 0
 
TY6NFunction[4, 6, 6] = 1
 
TY6NFunction[5, 0, 0] = 0
 
TY6NFunction[5, 0, 1] = 0
 
TY6NFunction[5, 0, 2] = 0
 
TY6NFunction[5, 0, 3] = 0
 
TY6NFunction[5, 0, 4] = 0
 
TY6NFunction[5, 0, 5] = 1
 
TY6NFunction[5, 0, 6] = 0
 
TY6NFunction[5, 1, 0] = 1
 
TY6NFunction[5, 1, 1] = 0
 
TY6NFunction[5, 1, 2] = 0
 
TY6NFunction[5, 1, 3] = 0
 
TY6NFunction[5, 1, 4] = 0
 
TY6NFunction[5, 1, 5] = 0
 
TY6NFunction[5, 1, 6] = 0
 
TY6NFunction[5, 2, 0] = 0
 
TY6NFunction[5, 2, 1] = 1
 
TY6NFunction[5, 2, 2] = 0
 
TY6NFunction[5, 2, 3] = 0
 
TY6NFunction[5, 2, 4] = 0
 
TY6NFunction[5, 2, 5] = 0
 
TY6NFunction[5, 2, 6] = 0
 
TY6NFunction[5, 3, 0] = 0
 
TY6NFunction[5, 3, 1] = 0
 
TY6NFunction[5, 3, 2] = 1
 
TY6NFunction[5, 3, 3] = 0
 
TY6NFunction[5, 3, 4] = 0
 
TY6NFunction[5, 3, 5] = 0
 
TY6NFunction[5, 3, 6] = 0
 
TY6NFunction[5, 4, 0] = 0
 
TY6NFunction[5, 4, 1] = 0
 
TY6NFunction[5, 4, 2] = 0
 
TY6NFunction[5, 4, 3] = 1
 
TY6NFunction[5, 4, 4] = 0
 
TY6NFunction[5, 4, 5] = 0
 
TY6NFunction[5, 4, 6] = 0
 
TY6NFunction[5, 5, 0] = 0
 
TY6NFunction[5, 5, 1] = 0
 
TY6NFunction[5, 5, 2] = 0
 
TY6NFunction[5, 5, 3] = 0
 
TY6NFunction[5, 5, 4] = 1
 
TY6NFunction[5, 5, 5] = 0
 
TY6NFunction[5, 5, 6] = 0
 
TY6NFunction[5, 6, 0] = 0
 
TY6NFunction[5, 6, 1] = 0
 
TY6NFunction[5, 6, 2] = 0
 
TY6NFunction[5, 6, 3] = 0
 
TY6NFunction[5, 6, 4] = 0
 
TY6NFunction[5, 6, 5] = 0
 
TY6NFunction[5, 6, 6] = 1
 
TY6NFunction[6, 0, 0] = 0
 
TY6NFunction[6, 0, 1] = 0
 
TY6NFunction[6, 0, 2] = 0
 
TY6NFunction[6, 0, 3] = 0
 
TY6NFunction[6, 0, 4] = 0
 
TY6NFunction[6, 0, 5] = 0
 
TY6NFunction[6, 0, 6] = 1
 
TY6NFunction[6, 1, 0] = 0
 
TY6NFunction[6, 1, 1] = 0
 
TY6NFunction[6, 1, 2] = 0
 
TY6NFunction[6, 1, 3] = 0
 
TY6NFunction[6, 1, 4] = 0
 
TY6NFunction[6, 1, 5] = 0
 
TY6NFunction[6, 1, 6] = 1
 
TY6NFunction[6, 2, 0] = 0
 
TY6NFunction[6, 2, 1] = 0
 
TY6NFunction[6, 2, 2] = 0
 
TY6NFunction[6, 2, 3] = 0
 
TY6NFunction[6, 2, 4] = 0
 
TY6NFunction[6, 2, 5] = 0
 
TY6NFunction[6, 2, 6] = 1
 
TY6NFunction[6, 3, 0] = 0
 
TY6NFunction[6, 3, 1] = 0
 
TY6NFunction[6, 3, 2] = 0
 
TY6NFunction[6, 3, 3] = 0
 
TY6NFunction[6, 3, 4] = 0
 
TY6NFunction[6, 3, 5] = 0
 
TY6NFunction[6, 3, 6] = 1
 
TY6NFunction[6, 4, 0] = 0
 
TY6NFunction[6, 4, 1] = 0
 
TY6NFunction[6, 4, 2] = 0
 
TY6NFunction[6, 4, 3] = 0
 
TY6NFunction[6, 4, 4] = 0
 
TY6NFunction[6, 4, 5] = 0
 
TY6NFunction[6, 4, 6] = 1
 
TY6NFunction[6, 5, 0] = 0
 
TY6NFunction[6, 5, 1] = 0
 
TY6NFunction[6, 5, 2] = 0
 
TY6NFunction[6, 5, 3] = 0
 
TY6NFunction[6, 5, 4] = 0
 
TY6NFunction[6, 5, 5] = 0
 
TY6NFunction[6, 5, 6] = 1
 
TY6NFunction[6, 6, 0] = 1
 
TY6NFunction[6, 6, 1] = 1
 
TY6NFunction[6, 6, 2] = 1
 
TY6NFunction[6, 6, 3] = 1
 
TY6NFunction[6, 6, 4] = 1
 
TY6NFunction[6, 6, 5] = 1
 
TY6NFunction[6, 6, 6] = 0
 
TY6NFunction[FusionCategories`Data`TY6`Private`a_, FusionCategories`Data`TY6`Private`b_, FusionCategories`Data`TY6`Private`c_] := 0

EndPackage[]
