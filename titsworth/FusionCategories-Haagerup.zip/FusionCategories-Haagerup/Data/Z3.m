BeginPackage["FusionCategories`Data`Z3`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[Z3] ^= {Z3Cat1, Z3Cat2, Z3Cat3}
 
Z3 /: fusionCategory[Z3, 1] = Z3Cat1
 
Z3 /: fusionCategory[Z3, 2] = Z3Cat2
 
Z3 /: fusionCategory[Z3, 3] = Z3Cat3
 
nFunction[Z3] ^= Z3NFunction
 
noMultiplicities[Z3] ^= True
 
rank[Z3] ^= 3
 
ring[Z3] ^= Z3
balancedCategories[Z3Cat1] ^= {Z3Cat1Bal1, Z3Cat1Bal2, Z3Cat1Bal3, 
    Z3Cat1Bal4, Z3Cat1Bal5, Z3Cat1Bal6, Z3Cat1Bal7, Z3Cat1Bal8, Z3Cat1Bal9}
 
Z3Cat1 /: balancedCategory[Z3Cat1, 1] = Z3Cat1Bal1
 
Z3Cat1 /: balancedCategory[Z3Cat1, 2] = Z3Cat1Bal2
 
Z3Cat1 /: balancedCategory[Z3Cat1, 3] = Z3Cat1Bal3
 
Z3Cat1 /: balancedCategory[Z3Cat1, 4] = Z3Cat1Bal4
 
Z3Cat1 /: balancedCategory[Z3Cat1, 5] = Z3Cat1Bal5
 
Z3Cat1 /: balancedCategory[Z3Cat1, 6] = Z3Cat1Bal6
 
Z3Cat1 /: balancedCategory[Z3Cat1, 7] = Z3Cat1Bal7
 
Z3Cat1 /: balancedCategory[Z3Cat1, 8] = Z3Cat1Bal8
 
Z3Cat1 /: balancedCategory[Z3Cat1, 9] = Z3Cat1Bal9
 
braidedCategories[Z3Cat1] ^= {Z3Cat1Brd1, Z3Cat1Brd2, Z3Cat1Brd3}
 
Z3Cat1 /: braidedCategory[Z3Cat1, 1] = Z3Cat1Brd1
 
Z3Cat1 /: braidedCategory[Z3Cat1, 2] = Z3Cat1Brd2
 
Z3Cat1 /: braidedCategory[Z3Cat1, 3] = Z3Cat1Brd3
 
coeval[Z3Cat1] ^= 1/sixJFunction[Z3Cat1][#1, dual[ring[Z3Cat1]][#1], #1, #1, 
      0, 0] & 
 
eval[Z3Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[Z3Cat1] ^= Z3Cat1FMatrixFunction
 
fusionCategory[Z3Cat1] ^= Z3Cat1
 
Z3Cat1 /: modularCategory[Z3Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[Z3Cat1] ^= {Z3Cat1Piv1, Z3Cat1Piv2, Z3Cat1Piv3}
 
Z3Cat1 /: pivotalCategory[Z3Cat1, 1] = Z3Cat1Piv1
 
Z3Cat1 /: pivotalCategory[Z3Cat1, 2] = Z3Cat1Piv2
 
Z3Cat1 /: pivotalCategory[Z3Cat1, 3] = Z3Cat1Piv3
 
Z3Cat1 /: pivotalCategory[Z3Cat1, {1, 1, 1}] = Z3Cat1Piv1
 
Z3Cat1 /: pivotalCategory[Z3Cat1, {1, -(-1)^(1/3), (-1)^(2/3)}] = Z3Cat1Piv2
 
Z3Cat1 /: pivotalCategory[Z3Cat1, {1, (-1)^(2/3), -(-1)^(1/3)}] = Z3Cat1Piv3
 
Z3Cat1 /: ribbonCategory[Z3Cat1, 1] = Z3Cat1Bal1
 
Z3Cat1 /: ribbonCategory[Z3Cat1, 2] = Z3Cat1Bal4
 
Z3Cat1 /: ribbonCategory[Z3Cat1, 3] = Z3Cat1Bal7
 
ring[Z3Cat1] ^= Z3
 
Z3Cat1 /: sphericalCategory[Z3Cat1, 1] = Z3Cat1Piv1
 
Z3Cat1 /: symmetricCategory[Z3Cat1, 1] = Z3Cat1Brd1
 
fusionCategoryIndex[Z3][Z3Cat1] ^= 1
balancedCategory[Z3Cat1Bal1] ^= Z3Cat1Bal1
 
braidedCategory[Z3Cat1Bal1] ^= Z3Cat1Brd1
 
fusionCategory[Z3Cat1Bal1] ^= Z3Cat1
 
pivotalCategory[Z3Cat1Bal1] ^= Z3Cat1Piv1
 
ribbonCategory[Z3Cat1Bal1] ^= Z3Cat1Bal1
 
ring[Z3Cat1Bal1] ^= Z3
 
sphericalCategory[Z3Cat1Bal1] ^= Z3Cat1Piv1
 
symmetricCategory[Z3Cat1Bal1] ^= Z3Cat1Brd1
 
(balancedCategoryIndex[braidedCategory[Z3Cat1Brd1]][balancedCategory[#1]] & )[
    Z3Cat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z3Cat1]][balancedCategory[#1]] & )[
    Z3Cat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[Z3Cat1Piv1]][balancedCategory[#1]] & )[
    Z3Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[Z3Cat1Brd1]][ribbonCategory[#1]] & )[
    Z3Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z3Cat1]][ribbonCategory[#1]] & )[
    Z3Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[Z3Cat1Piv1]][ribbonCategory[#1]] & )[
    Z3Cat1Bal1] ^= 1
balancedCategory[Z3Cat1Bal2] ^= Z3Cat1Bal2
 
braidedCategory[Z3Cat1Bal2] ^= Z3Cat1Brd1
 
fusionCategory[Z3Cat1Bal2] ^= Z3Cat1
 
pivotalCategory[Z3Cat1Bal2] ^= Z3Cat1Piv2
 
ring[Z3Cat1Bal2] ^= Z3
 
symmetricCategory[Z3Cat1Bal2] ^= Z3Cat1Brd1
 
(balancedCategoryIndex[braidedCategory[Z3Cat1Brd1]][balancedCategory[#1]] & )[
    Z3Cat1Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z3Cat1]][balancedCategory[#1]] & )[
    Z3Cat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[Z3Cat1Piv2]][balancedCategory[#1]] & )[
    Z3Cat1Bal2] ^= 1
balancedCategory[Z3Cat1Bal3] ^= Z3Cat1Bal3
 
braidedCategory[Z3Cat1Bal3] ^= Z3Cat1Brd1
 
fusionCategory[Z3Cat1Bal3] ^= Z3Cat1
 
pivotalCategory[Z3Cat1Bal3] ^= Z3Cat1Piv3
 
ring[Z3Cat1Bal3] ^= Z3
 
symmetricCategory[Z3Cat1Bal3] ^= Z3Cat1Brd1
 
(balancedCategoryIndex[braidedCategory[Z3Cat1Brd1]][balancedCategory[#1]] & )[
    Z3Cat1Bal3] ^= 3
 
(balancedCategoryIndex[fusionCategory[Z3Cat1]][balancedCategory[#1]] & )[
    Z3Cat1Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[Z3Cat1Piv3]][balancedCategory[#1]] & )[
    Z3Cat1Bal3] ^= 1
balancedCategory[Z3Cat1Bal4] ^= Z3Cat1Bal4
 
braidedCategory[Z3Cat1Bal4] ^= Z3Cat1Brd2
 
fusionCategory[Z3Cat1Bal4] ^= Z3Cat1
 
pivotalCategory[Z3Cat1Bal4] ^= Z3Cat1Piv1
 
ribbonCategory[Z3Cat1Bal4] ^= Z3Cat1Bal4
 
ring[Z3Cat1Bal4] ^= Z3
 
sphericalCategory[Z3Cat1Bal4] ^= Z3Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[Z3Cat1Brd2]][balancedCategory[#1]] & )[
    Z3Cat1Bal4] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z3Cat1]][balancedCategory[#1]] & )[
    Z3Cat1Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[Z3Cat1Piv1]][balancedCategory[#1]] & )[
    Z3Cat1Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[Z3Cat1Brd2]][ribbonCategory[#1]] & )[
    Z3Cat1Bal4] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z3Cat1]][ribbonCategory[#1]] & )[
    Z3Cat1Bal4] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[Z3Cat1Piv1]][ribbonCategory[#1]] & )[
    Z3Cat1Bal4] ^= 2
balancedCategory[Z3Cat1Bal5] ^= Z3Cat1Bal5
 
braidedCategory[Z3Cat1Bal5] ^= Z3Cat1Brd2
 
fusionCategory[Z3Cat1Bal5] ^= Z3Cat1
 
pivotalCategory[Z3Cat1Bal5] ^= Z3Cat1Piv2
 
ring[Z3Cat1Bal5] ^= Z3
 
(balancedCategoryIndex[braidedCategory[Z3Cat1Brd2]][balancedCategory[#1]] & )[
    Z3Cat1Bal5] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z3Cat1]][balancedCategory[#1]] & )[
    Z3Cat1Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[Z3Cat1Piv2]][balancedCategory[#1]] & )[
    Z3Cat1Bal5] ^= 2
balancedCategory[Z3Cat1Bal6] ^= Z3Cat1Bal6
 
braidedCategory[Z3Cat1Bal6] ^= Z3Cat1Brd2
 
fusionCategory[Z3Cat1Bal6] ^= Z3Cat1
 
pivotalCategory[Z3Cat1Bal6] ^= Z3Cat1Piv3
 
ring[Z3Cat1Bal6] ^= Z3
 
(balancedCategoryIndex[braidedCategory[Z3Cat1Brd2]][balancedCategory[#1]] & )[
    Z3Cat1Bal6] ^= 3
 
(balancedCategoryIndex[fusionCategory[Z3Cat1]][balancedCategory[#1]] & )[
    Z3Cat1Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[Z3Cat1Piv3]][balancedCategory[#1]] & )[
    Z3Cat1Bal6] ^= 2
balancedCategory[Z3Cat1Bal7] ^= Z3Cat1Bal7
 
braidedCategory[Z3Cat1Bal7] ^= Z3Cat1Brd3
 
fusionCategory[Z3Cat1Bal7] ^= Z3Cat1
 
pivotalCategory[Z3Cat1Bal7] ^= Z3Cat1Piv1
 
ribbonCategory[Z3Cat1Bal7] ^= Z3Cat1Bal7
 
ring[Z3Cat1Bal7] ^= Z3
 
sphericalCategory[Z3Cat1Bal7] ^= Z3Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[Z3Cat1Brd3]][balancedCategory[#1]] & )[
    Z3Cat1Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z3Cat1]][balancedCategory[#1]] & )[
    Z3Cat1Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[Z3Cat1Piv1]][balancedCategory[#1]] & )[
    Z3Cat1Bal7] ^= 3
 
(ribbonCategoryIndex[braidedCategory[Z3Cat1Brd3]][ribbonCategory[#1]] & )[
    Z3Cat1Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z3Cat1]][ribbonCategory[#1]] & )[
    Z3Cat1Bal7] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[Z3Cat1Piv1]][ribbonCategory[#1]] & )[
    Z3Cat1Bal7] ^= 3
balancedCategory[Z3Cat1Bal8] ^= Z3Cat1Bal8
 
braidedCategory[Z3Cat1Bal8] ^= Z3Cat1Brd3
 
fusionCategory[Z3Cat1Bal8] ^= Z3Cat1
 
pivotalCategory[Z3Cat1Bal8] ^= Z3Cat1Piv2
 
ring[Z3Cat1Bal8] ^= Z3
 
(balancedCategoryIndex[braidedCategory[Z3Cat1Brd3]][balancedCategory[#1]] & )[
    Z3Cat1Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z3Cat1]][balancedCategory[#1]] & )[
    Z3Cat1Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[Z3Cat1Piv2]][balancedCategory[#1]] & )[
    Z3Cat1Bal8] ^= 3
balancedCategory[Z3Cat1Bal9] ^= Z3Cat1Bal9
 
braidedCategory[Z3Cat1Bal9] ^= Z3Cat1Brd3
 
fusionCategory[Z3Cat1Bal9] ^= Z3Cat1
 
pivotalCategory[Z3Cat1Bal9] ^= Z3Cat1Piv3
 
ring[Z3Cat1Bal9] ^= Z3
 
(balancedCategoryIndex[braidedCategory[Z3Cat1Brd3]][balancedCategory[#1]] & )[
    Z3Cat1Bal9] ^= 3
 
(balancedCategoryIndex[fusionCategory[Z3Cat1]][balancedCategory[#1]] & )[
    Z3Cat1Bal9] ^= 9
 
(balancedCategoryIndex[pivotalCategory[Z3Cat1Piv3]][balancedCategory[#1]] & )[
    Z3Cat1Bal9] ^= 3
balancedCategories[Z3Cat1Brd1] ^= {Z3Cat1Bal1, Z3Cat1Bal2, Z3Cat1Bal3}
 
Z3Cat1Brd1 /: balancedCategory[Z3Cat1Brd1, 1] = Z3Cat1Bal1
 
Z3Cat1Brd1 /: balancedCategory[Z3Cat1Brd1, 2] = Z3Cat1Bal2
 
Z3Cat1Brd1 /: balancedCategory[Z3Cat1Brd1, 3] = Z3Cat1Bal3
 
braidedCategory[Z3Cat1Brd1] ^= Z3Cat1Brd1
 
fusionCategory[Z3Cat1Brd1] ^= Z3Cat1
 
Z3Cat1Brd1 /: modularCategory[Z3Cat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z3Cat1Brd1 /: ribbonCategory[Z3Cat1Brd1, 1] = Z3Cat1Bal1
 
ring[Z3Cat1Brd1] ^= Z3
 
rMatrixFunction[Z3Cat1Brd1] ^= Z3Cat1Brd1RMatrixFunction
 
symmetricCategory[Z3Cat1Brd1] ^= Z3Cat1Brd1
 
(braidedCategoryIndex[fusionCategory[Z3Cat1]][braidedCategory[#1]] & )[
    Z3Cat1Brd1] ^= 1
 
(symmetricCategoryIndex[fusionCategory[Z3Cat1]][symmetricCategory[#1]] & )[
    Z3Cat1Brd1] ^= 1
braidedCategory[Z3Cat1Brd1RMatrixFunction] ^= Z3Cat1Brd1
 
fusionCategory[Z3Cat1Brd1RMatrixFunction] ^= Z3Cat1
 
rMatrixFunction[Z3Cat1Brd1RMatrixFunction] ^= Z3Cat1Brd1RMatrixFunction
 
Z3Cat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
Z3Cat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
Z3Cat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
Z3Cat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
Z3Cat1Brd1RMatrixFunction[1, 1, 2] = {{1}}
 
Z3Cat1Brd1RMatrixFunction[1, 2, 0] = {{1}}
 
Z3Cat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
Z3Cat1Brd1RMatrixFunction[2, 1, 0] = {{1}}
 
Z3Cat1Brd1RMatrixFunction[2, 2, 1] = {{1}}
balancedCategories[Z3Cat1Brd2] ^= {Z3Cat1Bal4, Z3Cat1Bal5, Z3Cat1Bal6}
 
Z3Cat1Brd2 /: balancedCategory[Z3Cat1Brd2, 1] = Z3Cat1Bal4
 
Z3Cat1Brd2 /: balancedCategory[Z3Cat1Brd2, 2] = Z3Cat1Bal5
 
Z3Cat1Brd2 /: balancedCategory[Z3Cat1Brd2, 3] = Z3Cat1Bal6
 
braidedCategory[Z3Cat1Brd2] ^= Z3Cat1Brd2
 
fusionCategory[Z3Cat1Brd2] ^= Z3Cat1
 
Z3Cat1Brd2 /: modularCategory[Z3Cat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z3Cat1Brd2 /: ribbonCategory[Z3Cat1Brd2, 1] = Z3Cat1Bal4
 
ring[Z3Cat1Brd2] ^= Z3
 
rMatrixFunction[Z3Cat1Brd2] ^= Z3Cat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[Z3Cat1]][braidedCategory[#1]] & )[
    Z3Cat1Brd2] ^= 2
braidedCategory[Z3Cat1Brd2RMatrixFunction] ^= Z3Cat1Brd2
 
fusionCategory[Z3Cat1Brd2RMatrixFunction] ^= Z3Cat1
 
rMatrixFunction[Z3Cat1Brd2RMatrixFunction] ^= Z3Cat1Brd2RMatrixFunction
 
Z3Cat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
Z3Cat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
Z3Cat1Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
Z3Cat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
Z3Cat1Brd2RMatrixFunction[1, 1, 2] = {{(-1)^(2/3)}}
 
Z3Cat1Brd2RMatrixFunction[1, 2, 0] = {{-(-1)^(1/3)}}
 
Z3Cat1Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
Z3Cat1Brd2RMatrixFunction[2, 1, 0] = {{-(-1)^(1/3)}}
 
Z3Cat1Brd2RMatrixFunction[2, 2, 1] = {{(-1)^(2/3)}}
balancedCategories[Z3Cat1Brd3] ^= {Z3Cat1Bal7, Z3Cat1Bal8, Z3Cat1Bal9}
 
Z3Cat1Brd3 /: balancedCategory[Z3Cat1Brd3, 1] = Z3Cat1Bal7
 
Z3Cat1Brd3 /: balancedCategory[Z3Cat1Brd3, 2] = Z3Cat1Bal8
 
Z3Cat1Brd3 /: balancedCategory[Z3Cat1Brd3, 3] = Z3Cat1Bal9
 
braidedCategory[Z3Cat1Brd3] ^= Z3Cat1Brd3
 
fusionCategory[Z3Cat1Brd3] ^= Z3Cat1
 
Z3Cat1Brd3 /: modularCategory[Z3Cat1Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z3Cat1Brd3 /: ribbonCategory[Z3Cat1Brd3, 1] = Z3Cat1Bal7
 
ring[Z3Cat1Brd3] ^= Z3
 
rMatrixFunction[Z3Cat1Brd3] ^= Z3Cat1Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[Z3Cat1]][braidedCategory[#1]] & )[
    Z3Cat1Brd3] ^= 3
braidedCategory[Z3Cat1Brd3RMatrixFunction] ^= Z3Cat1Brd3
 
fusionCategory[Z3Cat1Brd3RMatrixFunction] ^= Z3Cat1
 
rMatrixFunction[Z3Cat1Brd3RMatrixFunction] ^= Z3Cat1Brd3RMatrixFunction
 
Z3Cat1Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
Z3Cat1Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
Z3Cat1Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
Z3Cat1Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
Z3Cat1Brd3RMatrixFunction[1, 1, 2] = {{-(-1)^(1/3)}}
 
Z3Cat1Brd3RMatrixFunction[1, 2, 0] = {{(-1)^(2/3)}}
 
Z3Cat1Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
Z3Cat1Brd3RMatrixFunction[2, 1, 0] = {{(-1)^(2/3)}}
 
Z3Cat1Brd3RMatrixFunction[2, 2, 1] = {{-(-1)^(1/3)}}
fMatrixFunction[Z3Cat1FMatrixFunction] ^= Z3Cat1FMatrixFunction
 
fusionCategory[Z3Cat1FMatrixFunction] ^= Z3Cat1
 
ring[Z3Cat1FMatrixFunction] ^= Z3
 
Z3Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z3Cat1], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
Z3Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z3Cat1], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[Z3Cat1Piv1] ^= {Z3Cat1Bal1, Z3Cat1Bal4, Z3Cat1Bal7}
 
Z3Cat1Piv1 /: balancedCategory[Z3Cat1Piv1, 1] = Z3Cat1Bal1
 
Z3Cat1Piv1 /: balancedCategory[Z3Cat1Piv1, 2] = Z3Cat1Bal4
 
Z3Cat1Piv1 /: balancedCategory[Z3Cat1Piv1, 3] = Z3Cat1Bal7
 
fusionCategory[Z3Cat1Piv1] ^= Z3Cat1
 
Z3Cat1Piv1 /: modularCategory[Z3Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z3Cat1Piv1] ^= Z3Cat1Piv1
 
pivotalIsomorphism[Z3Cat1Piv1] ^= Z3Cat1Piv1PivotalIsomorphism
 
Z3Cat1Piv1 /: ribbonCategory[Z3Cat1Piv1, 1] = Z3Cat1Bal1
 
Z3Cat1Piv1 /: ribbonCategory[Z3Cat1Piv1, 2] = Z3Cat1Bal4
 
Z3Cat1Piv1 /: ribbonCategory[Z3Cat1Piv1, 3] = Z3Cat1Bal7
 
ring[Z3Cat1Piv1] ^= Z3
 
sphericalCategory[Z3Cat1Piv1] ^= Z3Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[Z3Cat1]][pivotalCategory[#1]] & )[
    Z3Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[Z3Cat1]][sphericalCategory[#1]] & )[
    Z3Cat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z3Cat1Piv1PivotalIsomorphism] ^= Z3Cat1
 
pivotalCategory[Z3Cat1Piv1PivotalIsomorphism] ^= Z3Cat1Piv1
 
pivotalIsomorphism[Z3Cat1Piv1PivotalIsomorphism] ^= 
   Z3Cat1Piv1PivotalIsomorphism
 
Z3Cat1Piv1PivotalIsomorphism[0] = 1
 
Z3Cat1Piv1PivotalIsomorphism[1] = 1
 
Z3Cat1Piv1PivotalIsomorphism[2] = 1
balancedCategories[Z3Cat1Piv2] ^= {Z3Cat1Bal2, Z3Cat1Bal5, Z3Cat1Bal8}
 
Z3Cat1Piv2 /: balancedCategory[Z3Cat1Piv2, 1] = Z3Cat1Bal2
 
Z3Cat1Piv2 /: balancedCategory[Z3Cat1Piv2, 2] = Z3Cat1Bal5
 
Z3Cat1Piv2 /: balancedCategory[Z3Cat1Piv2, 3] = Z3Cat1Bal8
 
fusionCategory[Z3Cat1Piv2] ^= Z3Cat1
 
Z3Cat1Piv2 /: modularCategory[Z3Cat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z3Cat1Piv2] ^= Z3Cat1Piv2
 
pivotalIsomorphism[Z3Cat1Piv2] ^= Z3Cat1Piv2PivotalIsomorphism
 
ring[Z3Cat1Piv2] ^= Z3
 
(pivotalCategoryIndex[fusionCategory[Z3Cat1]][pivotalCategory[#1]] & )[
    Z3Cat1Piv2] ^= 2
fusionCategory[Z3Cat1Piv2PivotalIsomorphism] ^= Z3Cat1
 
pivotalCategory[Z3Cat1Piv2PivotalIsomorphism] ^= Z3Cat1Piv2
 
pivotalIsomorphism[Z3Cat1Piv2PivotalIsomorphism] ^= 
   Z3Cat1Piv2PivotalIsomorphism
 
Z3Cat1Piv2PivotalIsomorphism[0] = 1
 
Z3Cat1Piv2PivotalIsomorphism[1] = -(-1)^(1/3)
 
Z3Cat1Piv2PivotalIsomorphism[2] = (-1)^(2/3)
balancedCategories[Z3Cat1Piv3] ^= {Z3Cat1Bal3, Z3Cat1Bal6, Z3Cat1Bal9}
 
Z3Cat1Piv3 /: balancedCategory[Z3Cat1Piv3, 1] = Z3Cat1Bal3
 
Z3Cat1Piv3 /: balancedCategory[Z3Cat1Piv3, 2] = Z3Cat1Bal6
 
Z3Cat1Piv3 /: balancedCategory[Z3Cat1Piv3, 3] = Z3Cat1Bal9
 
fusionCategory[Z3Cat1Piv3] ^= Z3Cat1
 
Z3Cat1Piv3 /: modularCategory[Z3Cat1Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z3Cat1Piv3] ^= Z3Cat1Piv3
 
pivotalIsomorphism[Z3Cat1Piv3] ^= Z3Cat1Piv3PivotalIsomorphism
 
ring[Z3Cat1Piv3] ^= Z3
 
(pivotalCategoryIndex[fusionCategory[Z3Cat1]][pivotalCategory[#1]] & )[
    Z3Cat1Piv3] ^= 3
fusionCategory[Z3Cat1Piv3PivotalIsomorphism] ^= Z3Cat1
 
pivotalCategory[Z3Cat1Piv3PivotalIsomorphism] ^= Z3Cat1Piv3
 
pivotalIsomorphism[Z3Cat1Piv3PivotalIsomorphism] ^= 
   Z3Cat1Piv3PivotalIsomorphism
 
Z3Cat1Piv3PivotalIsomorphism[0] = 1
 
Z3Cat1Piv3PivotalIsomorphism[1] = (-1)^(2/3)
 
Z3Cat1Piv3PivotalIsomorphism[2] = -(-1)^(1/3)
balancedCategories[Z3Cat2] ^= {}
 
braidedCategories[Z3Cat2] ^= {}
 
coeval[Z3Cat2] ^= 1/sixJFunction[Z3Cat2][#1, dual[ring[Z3Cat2]][#1], #1, #1, 
      0, 0] & 
 
eval[Z3Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[Z3Cat2] ^= Z3Cat2FMatrixFunction
 
fusionCategory[Z3Cat2] ^= Z3Cat2
 
Z3Cat2 /: modularCategory[Z3Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[Z3Cat2] ^= {Z3Cat2Piv1, Z3Cat2Piv2, Z3Cat2Piv3}
 
Z3Cat2 /: pivotalCategory[Z3Cat2, 1] = Z3Cat2Piv1
 
Z3Cat2 /: pivotalCategory[Z3Cat2, 2] = Z3Cat2Piv2
 
Z3Cat2 /: pivotalCategory[Z3Cat2, 3] = Z3Cat2Piv3
 
Z3Cat2 /: pivotalCategory[Z3Cat2, {1, 1, 1}] = Z3Cat2Piv1
 
Z3Cat2 /: pivotalCategory[Z3Cat2, {1, -(-1)^(1/3), (-1)^(2/3)}] = Z3Cat2Piv2
 
Z3Cat2 /: pivotalCategory[Z3Cat2, {1, (-1)^(2/3), -(-1)^(1/3)}] = Z3Cat2Piv3
 
ring[Z3Cat2] ^= Z3
 
Z3Cat2 /: sphericalCategory[Z3Cat2, 1] = Z3Cat2Piv3
 
fusionCategoryIndex[Z3][Z3Cat2] ^= 2
fMatrixFunction[Z3Cat2FMatrixFunction] ^= Z3Cat2FMatrixFunction
 
fusionCategory[Z3Cat2FMatrixFunction] ^= Z3Cat2
 
ring[Z3Cat2FMatrixFunction] ^= Z3
 
Z3Cat2FMatrixFunction[1, 1, 1, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
Z3Cat2FMatrixFunction[1, 2, 1, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
Z3Cat2FMatrixFunction[1, 2, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
Z3Cat2FMatrixFunction[2, 1, 2, 2] = {{(I/2)*(I + Sqrt[3])}}
 
Z3Cat2FMatrixFunction[2, 2, 1, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
Z3Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z3Cat2], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
Z3Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z3Cat2], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[Z3Cat2Piv1] ^= {}
 
fusionCategory[Z3Cat2Piv1] ^= Z3Cat2
 
Z3Cat2Piv1 /: modularCategory[Z3Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z3Cat2Piv1] ^= Z3Cat2Piv1
 
pivotalIsomorphism[Z3Cat2Piv1] ^= Z3Cat2Piv1PivotalIsomorphism
 
ring[Z3Cat2Piv1] ^= Z3
 
(pivotalCategoryIndex[fusionCategory[Z3Cat2]][pivotalCategory[#1]] & )[
    Z3Cat2Piv1] ^= 1
fusionCategory[Z3Cat2Piv1PivotalIsomorphism] ^= Z3Cat2
 
pivotalCategory[Z3Cat2Piv1PivotalIsomorphism] ^= Z3Cat2Piv1
 
pivotalIsomorphism[Z3Cat2Piv1PivotalIsomorphism] ^= 
   Z3Cat2Piv1PivotalIsomorphism
 
Z3Cat2Piv1PivotalIsomorphism[0] = 1
 
Z3Cat2Piv1PivotalIsomorphism[1] = 1
 
Z3Cat2Piv1PivotalIsomorphism[2] = 1
balancedCategories[Z3Cat2Piv2] ^= {}
 
fusionCategory[Z3Cat2Piv2] ^= Z3Cat2
 
Z3Cat2Piv2 /: modularCategory[Z3Cat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z3Cat2Piv2] ^= Z3Cat2Piv2
 
pivotalIsomorphism[Z3Cat2Piv2] ^= Z3Cat2Piv2PivotalIsomorphism
 
ring[Z3Cat2Piv2] ^= Z3
 
(pivotalCategoryIndex[fusionCategory[Z3Cat2]][pivotalCategory[#1]] & )[
    Z3Cat2Piv2] ^= 2
fusionCategory[Z3Cat2Piv2PivotalIsomorphism] ^= Z3Cat2
 
pivotalCategory[Z3Cat2Piv2PivotalIsomorphism] ^= Z3Cat2Piv2
 
pivotalIsomorphism[Z3Cat2Piv2PivotalIsomorphism] ^= 
   Z3Cat2Piv2PivotalIsomorphism
 
Z3Cat2Piv2PivotalIsomorphism[0] = 1
 
Z3Cat2Piv2PivotalIsomorphism[1] = -(-1)^(1/3)
 
Z3Cat2Piv2PivotalIsomorphism[2] = (-1)^(2/3)
balancedCategories[Z3Cat2Piv3] ^= {}
 
fusionCategory[Z3Cat2Piv3] ^= Z3Cat2
 
Z3Cat2Piv3 /: modularCategory[Z3Cat2Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z3Cat2Piv3] ^= Z3Cat2Piv3
 
pivotalIsomorphism[Z3Cat2Piv3] ^= Z3Cat2Piv3PivotalIsomorphism
 
ring[Z3Cat2Piv3] ^= Z3
 
sphericalCategory[Z3Cat2Piv3] ^= Z3Cat2Piv3
 
(pivotalCategoryIndex[fusionCategory[Z3Cat2]][pivotalCategory[#1]] & )[
    Z3Cat2Piv3] ^= 3
 
(sphericalCategoryIndex[fusionCategory[Z3Cat2]][sphericalCategory[#1]] & )[
    Z3Cat2Piv3] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z3Cat2Piv3PivotalIsomorphism] ^= Z3Cat2
 
pivotalCategory[Z3Cat2Piv3PivotalIsomorphism] ^= Z3Cat2Piv3
 
pivotalIsomorphism[Z3Cat2Piv3PivotalIsomorphism] ^= 
   Z3Cat2Piv3PivotalIsomorphism
 
Z3Cat2Piv3PivotalIsomorphism[0] = 1
 
Z3Cat2Piv3PivotalIsomorphism[1] = (-1)^(2/3)
 
Z3Cat2Piv3PivotalIsomorphism[2] = -(-1)^(1/3)
balancedCategories[Z3Cat3] ^= {}
 
braidedCategories[Z3Cat3] ^= {}
 
coeval[Z3Cat3] ^= 1/sixJFunction[Z3Cat3][#1, dual[ring[Z3Cat3]][#1], #1, #1, 
      0, 0] & 
 
eval[Z3Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[Z3Cat3] ^= Z3Cat3FMatrixFunction
 
fusionCategory[Z3Cat3] ^= Z3Cat3
 
Z3Cat3 /: modularCategory[Z3Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[Z3Cat3] ^= {Z3Cat3Piv1, Z3Cat3Piv2, Z3Cat3Piv3}
 
Z3Cat3 /: pivotalCategory[Z3Cat3, 1] = Z3Cat3Piv1
 
Z3Cat3 /: pivotalCategory[Z3Cat3, 2] = Z3Cat3Piv2
 
Z3Cat3 /: pivotalCategory[Z3Cat3, 3] = Z3Cat3Piv3
 
Z3Cat3 /: pivotalCategory[Z3Cat3, {1, 1, 1}] = Z3Cat3Piv1
 
Z3Cat3 /: pivotalCategory[Z3Cat3, {1, -(-1)^(1/3), (-1)^(2/3)}] = Z3Cat3Piv2
 
Z3Cat3 /: pivotalCategory[Z3Cat3, {1, (-1)^(2/3), -(-1)^(1/3)}] = Z3Cat3Piv3
 
ring[Z3Cat3] ^= Z3
 
Z3Cat3 /: sphericalCategory[Z3Cat3, 1] = Z3Cat3Piv2
 
fusionCategoryIndex[Z3][Z3Cat3] ^= 3
fMatrixFunction[Z3Cat3FMatrixFunction] ^= Z3Cat3FMatrixFunction
 
fusionCategory[Z3Cat3FMatrixFunction] ^= Z3Cat3
 
ring[Z3Cat3FMatrixFunction] ^= Z3
 
Z3Cat3FMatrixFunction[1, 1, 1, 0] = {{(I/2)*(I + Sqrt[3])}}
 
Z3Cat3FMatrixFunction[1, 2, 1, 1] = {{(I/2)*(I + Sqrt[3])}}
 
Z3Cat3FMatrixFunction[1, 2, 2, 2] = {{(I/2)*(I + Sqrt[3])}}
 
Z3Cat3FMatrixFunction[2, 1, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
Z3Cat3FMatrixFunction[2, 2, 1, 2] = {{(I/2)*(I + Sqrt[3])}}
 
Z3Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z3Cat3], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
Z3Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z3Cat3], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[Z3Cat3Piv1] ^= {}
 
fusionCategory[Z3Cat3Piv1] ^= Z3Cat3
 
Z3Cat3Piv1 /: modularCategory[Z3Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z3Cat3Piv1] ^= Z3Cat3Piv1
 
pivotalIsomorphism[Z3Cat3Piv1] ^= Z3Cat3Piv1PivotalIsomorphism
 
ring[Z3Cat3Piv1] ^= Z3
 
(pivotalCategoryIndex[fusionCategory[Z3Cat3]][pivotalCategory[#1]] & )[
    Z3Cat3Piv1] ^= 1
fusionCategory[Z3Cat3Piv1PivotalIsomorphism] ^= Z3Cat3
 
pivotalCategory[Z3Cat3Piv1PivotalIsomorphism] ^= Z3Cat3Piv1
 
pivotalIsomorphism[Z3Cat3Piv1PivotalIsomorphism] ^= 
   Z3Cat3Piv1PivotalIsomorphism
 
Z3Cat3Piv1PivotalIsomorphism[0] = 1
 
Z3Cat3Piv1PivotalIsomorphism[1] = 1
 
Z3Cat3Piv1PivotalIsomorphism[2] = 1
balancedCategories[Z3Cat3Piv2] ^= {}
 
fusionCategory[Z3Cat3Piv2] ^= Z3Cat3
 
Z3Cat3Piv2 /: modularCategory[Z3Cat3Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z3Cat3Piv2] ^= Z3Cat3Piv2
 
pivotalIsomorphism[Z3Cat3Piv2] ^= Z3Cat3Piv2PivotalIsomorphism
 
ring[Z3Cat3Piv2] ^= Z3
 
sphericalCategory[Z3Cat3Piv2] ^= Z3Cat3Piv2
 
(pivotalCategoryIndex[fusionCategory[Z3Cat3]][pivotalCategory[#1]] & )[
    Z3Cat3Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[Z3Cat3]][sphericalCategory[#1]] & )[
    Z3Cat3Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z3Cat3Piv2PivotalIsomorphism] ^= Z3Cat3
 
pivotalCategory[Z3Cat3Piv2PivotalIsomorphism] ^= Z3Cat3Piv2
 
pivotalIsomorphism[Z3Cat3Piv2PivotalIsomorphism] ^= 
   Z3Cat3Piv2PivotalIsomorphism
 
Z3Cat3Piv2PivotalIsomorphism[0] = 1
 
Z3Cat3Piv2PivotalIsomorphism[1] = -(-1)^(1/3)
 
Z3Cat3Piv2PivotalIsomorphism[2] = (-1)^(2/3)
balancedCategories[Z3Cat3Piv3] ^= {}
 
fusionCategory[Z3Cat3Piv3] ^= Z3Cat3
 
Z3Cat3Piv3 /: modularCategory[Z3Cat3Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z3Cat3Piv3] ^= Z3Cat3Piv3
 
pivotalIsomorphism[Z3Cat3Piv3] ^= Z3Cat3Piv3PivotalIsomorphism
 
ring[Z3Cat3Piv3] ^= Z3
 
(pivotalCategoryIndex[fusionCategory[Z3Cat3]][pivotalCategory[#1]] & )[
    Z3Cat3Piv3] ^= 3
fusionCategory[Z3Cat3Piv3PivotalIsomorphism] ^= Z3Cat3
 
pivotalCategory[Z3Cat3Piv3PivotalIsomorphism] ^= Z3Cat3Piv3
 
pivotalIsomorphism[Z3Cat3Piv3PivotalIsomorphism] ^= 
   Z3Cat3Piv3PivotalIsomorphism
 
Z3Cat3Piv3PivotalIsomorphism[0] = 1
 
Z3Cat3Piv3PivotalIsomorphism[1] = (-1)^(2/3)
 
Z3Cat3Piv3PivotalIsomorphism[2] = -(-1)^(1/3)
Z3NewCoeval1[(f_)?(has[fusionCategory])] := 
   (-(-1)^(1/3))^#1*FusionCategories`Private`defaultGaugeCoeval[f][#1] & 
Z3NewCoeval2[(f_)?(has[fusionCategory])] := 
   ((-1)^(2/3))^#1*FusionCategories`Private`defaultGaugeCoeval[f][#1] & 
ring[Z3NFunction] ^= Z3
 
Z3NFunction[0, 0, 0] = 1
 
Z3NFunction[0, 0, 1] = 0
 
Z3NFunction[0, 0, 2] = 0
 
Z3NFunction[0, 1, 0] = 0
 
Z3NFunction[0, 1, 1] = 1
 
Z3NFunction[0, 1, 2] = 0
 
Z3NFunction[0, 2, 0] = 0
 
Z3NFunction[0, 2, 1] = 0
 
Z3NFunction[0, 2, 2] = 1
 
Z3NFunction[1, 0, 0] = 0
 
Z3NFunction[1, 0, 1] = 1
 
Z3NFunction[1, 0, 2] = 0
 
Z3NFunction[1, 1, 0] = 0
 
Z3NFunction[1, 1, 1] = 0
 
Z3NFunction[1, 1, 2] = 1
 
Z3NFunction[1, 2, 0] = 1
 
Z3NFunction[1, 2, 1] = 0
 
Z3NFunction[1, 2, 2] = 0
 
Z3NFunction[2, 0, 0] = 0
 
Z3NFunction[2, 0, 1] = 0
 
Z3NFunction[2, 0, 2] = 1
 
Z3NFunction[2, 1, 0] = 1
 
Z3NFunction[2, 1, 1] = 0
 
Z3NFunction[2, 1, 2] = 0
 
Z3NFunction[2, 2, 0] = 0
 
Z3NFunction[2, 2, 1] = 1
 
Z3NFunction[2, 2, 2] = 0
 
Z3NFunction[FusionCategories`Data`Z3`Private`a_, FusionCategories`Data`Z3`Private`b_, FusionCategories`Data`Z3`Private`c_] := 0

coeval[Z3Cat1Piv2] := Z3NewCoeval1[Z3Cat1Piv2]
coeval[Z3Cat2Piv1] := Z3NewCoeval1[Z3Cat2Piv1]
coeval[Z3Cat3Piv3] := Z3NewCoeval1[Z3Cat3Piv3]

coeval[Z3Cat1Piv3] := Z3NewCoeval2[Z3Cat1Piv3]
coeval[Z3Cat2Piv2] := Z3NewCoeval2[Z3Cat2Piv2]
coeval[Z3Cat3Piv1] := Z3NewCoeval2[Z3Cat3Piv1]

EndPackage[]
