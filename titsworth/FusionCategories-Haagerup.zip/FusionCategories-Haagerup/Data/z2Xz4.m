BeginPackage["FusionCategories`Data`z2Xz4`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[z2Xz4] ^= {z2Xz4Cat1, z2Xz4Cat2, z2Xz4Cat3, z2Xz4Cat4, 
    z2Xz4Cat5, z2Xz4Cat6}
 
z2Xz4 /: fusionCategory[z2Xz4, 1] = z2Xz4Cat1
 
z2Xz4 /: fusionCategory[z2Xz4, 2] = z2Xz4Cat2
 
z2Xz4 /: fusionCategory[z2Xz4, 3] = z2Xz4Cat3
 
z2Xz4 /: fusionCategory[z2Xz4, 4] = z2Xz4Cat4
 
z2Xz4 /: fusionCategory[z2Xz4, 5] = z2Xz4Cat5
 
z2Xz4 /: fusionCategory[z2Xz4, 6] = z2Xz4Cat6
 
nFunction[z2Xz4] ^= z2Xz4NFunction
 
noMultiplicities[z2Xz4] ^= True
 
rank[z2Xz4] ^= 6
 
ring[z2Xz4] ^= z2Xz4
balancedCategories[z2Xz4Cat1] ^= {}
 
braidedCategories[z2Xz4Cat1] ^= {}
 
coeval[z2Xz4Cat1] ^= 1/sixJFunction[z2Xz4Cat1][#1, dual[ring[z2Xz4Cat1]][#1], 
      #1, #1, 0, 0] & 
 
eval[z2Xz4Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[z2Xz4Cat1] ^= z2Xz4Cat1FMatrixFunction
 
fusionCategory[z2Xz4Cat1] ^= z2Xz4Cat1
 
z2Xz4Cat1 /: modularCategory[z2Xz4Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[z2Xz4Cat1] ^= {z2Xz4Cat1Piv1, z2Xz4Cat1Piv2, z2Xz4Cat1Piv3, 
    z2Xz4Cat1Piv4}
 
z2Xz4Cat1 /: pivotalCategory[z2Xz4Cat1, 1] = z2Xz4Cat1Piv1
 
z2Xz4Cat1 /: pivotalCategory[z2Xz4Cat1, 2] = z2Xz4Cat1Piv2
 
z2Xz4Cat1 /: pivotalCategory[z2Xz4Cat1, 3] = z2Xz4Cat1Piv3
 
z2Xz4Cat1 /: pivotalCategory[z2Xz4Cat1, 4] = z2Xz4Cat1Piv4
 
z2Xz4Cat1 /: pivotalCategory[z2Xz4Cat1, {1, -1, 1, -1, -1, -1}] = 
    z2Xz4Cat1Piv1
 
z2Xz4Cat1 /: pivotalCategory[z2Xz4Cat1, {1, -1, 1, -1, 1, 1}] = z2Xz4Cat1Piv4
 
z2Xz4Cat1 /: pivotalCategory[z2Xz4Cat1, {1, 1, 1, 1, -1, 1}] = z2Xz4Cat1Piv2
 
z2Xz4Cat1 /: pivotalCategory[z2Xz4Cat1, {1, 1, 1, 1, 1, -1}] = z2Xz4Cat1Piv3
 
ring[z2Xz4Cat1] ^= z2Xz4
 
z2Xz4Cat1 /: sphericalCategory[z2Xz4Cat1, 1] = z2Xz4Cat1Piv1
 
z2Xz4Cat1 /: sphericalCategory[z2Xz4Cat1, 2] = z2Xz4Cat1Piv2
 
z2Xz4Cat1 /: sphericalCategory[z2Xz4Cat1, 3] = z2Xz4Cat1Piv3
 
z2Xz4Cat1 /: sphericalCategory[z2Xz4Cat1, 4] = z2Xz4Cat1Piv4
 
fusionCategoryIndex[z2Xz4][z2Xz4Cat1] ^= 1
fMatrixFunction[z2Xz4Cat1FMatrixFunction] ^= z2Xz4Cat1FMatrixFunction
 
fusionCategory[z2Xz4Cat1FMatrixFunction] ^= z2Xz4Cat1
 
ring[z2Xz4Cat1FMatrixFunction] ^= z2Xz4
 
z2Xz4Cat1FMatrixFunction[1, 1, 1, 3] = {{-I}}
 
z2Xz4Cat1FMatrixFunction[1, 1, 2, 0] = {{-I}}
 
z2Xz4Cat1FMatrixFunction[1, 1, 5, 5] = {{I}}
 
z2Xz4Cat1FMatrixFunction[1, 2, 1, 0] = {{-I}}
 
z2Xz4Cat1FMatrixFunction[1, 2, 2, 1] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[1, 2, 3, 2] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[1, 3, 2, 2] = {{-I}}
 
z2Xz4Cat1FMatrixFunction[1, 3, 4, 4] = {{-I}}
 
z2Xz4Cat1FMatrixFunction[1, 4, 2, 5] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[1, 4, 3, 4] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[1, 4, 4, 1] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[1, 4, 4, 3] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[1, 4, 5, 0] = {{I}}
 
z2Xz4Cat1FMatrixFunction[1, 4, 5, 2] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[1, 5, 1, 5] = {{-I}}
 
z2Xz4Cat1FMatrixFunction[1, 5, 3, 5] = {{-I}}
 
z2Xz4Cat1FMatrixFunction[1, 5, 4, 0] = {{I}}
 
z2Xz4Cat1FMatrixFunction[1, 5, 5, 1] = {{I}}
 
z2Xz4Cat1FMatrixFunction[1, 5, 5, 3] = {{-I}}
 
z2Xz4Cat1FMatrixFunction[2, 1, 1, 0] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[2, 1, 3, 2] = {{I}}
 
z2Xz4Cat1FMatrixFunction[2, 1, 4, 5] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[2, 2, 3, 3] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[2, 2, 4, 4] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[2, 2, 5, 5] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[2, 3, 3, 0] = {{I}}
 
z2Xz4Cat1FMatrixFunction[2, 3, 4, 5] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[2, 4, 1, 5] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[2, 4, 2, 4] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[2, 4, 4, 2] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[2, 4, 5, 1] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[2, 4, 5, 3] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[2, 5, 2, 5] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[2, 5, 3, 4] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[2, 5, 5, 0] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[3, 1, 1, 1] = {{-I}}
 
z2Xz4Cat1FMatrixFunction[3, 1, 5, 5] = {{-I}}
 
z2Xz4Cat1FMatrixFunction[3, 2, 1, 2] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[3, 2, 2, 3] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[3, 2, 3, 0] = {{I}}
 
z2Xz4Cat1FMatrixFunction[3, 3, 1, 3] = {{I}}
 
z2Xz4Cat1FMatrixFunction[3, 3, 2, 0] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[3, 3, 3, 1] = {{I}}
 
z2Xz4Cat1FMatrixFunction[3, 3, 5, 5] = {{-I}}
 
z2Xz4Cat1FMatrixFunction[3, 4, 1, 4] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[3, 4, 3, 4] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[3, 4, 5, 2] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[3, 5, 1, 5] = {{-I}}
 
z2Xz4Cat1FMatrixFunction[3, 5, 2, 4] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[3, 5, 3, 5] = {{I}}
 
z2Xz4Cat1FMatrixFunction[3, 5, 4, 0] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[3, 5, 5, 1] = {{I}}
 
z2Xz4Cat1FMatrixFunction[3, 5, 5, 3] = {{-I}}
 
z2Xz4Cat1FMatrixFunction[4, 1, 1, 4] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[4, 1, 3, 4] = {{I}}
 
z2Xz4Cat1FMatrixFunction[4, 2, 1, 5] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[4, 2, 2, 4] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[4, 2, 3, 5] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[4, 2, 4, 0] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[4, 2, 5, 3] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[4, 3, 3, 4] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[4, 3, 4, 3] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[4, 3, 5, 2] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[4, 4, 1, 1] = {{I}}
 
z2Xz4Cat1FMatrixFunction[4, 4, 1, 3] = {{I}}
 
z2Xz4Cat1FMatrixFunction[4, 4, 2, 0] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[4, 4, 3, 1] = {{-I}}
 
z2Xz4Cat1FMatrixFunction[4, 4, 3, 3] = {{-I}}
 
z2Xz4Cat1FMatrixFunction[4, 4, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
z2Xz4Cat1FMatrixFunction[4, 4, 5, 5] = {{(-I)/Sqrt[2], (-I)/Sqrt[2]}, 
    {I/Sqrt[2], (-I)/Sqrt[2]}}
 
z2Xz4Cat1FMatrixFunction[4, 5, 1, 0] = {{I}}
 
z2Xz4Cat1FMatrixFunction[4, 5, 1, 2] = {{I}}
 
z2Xz4Cat1FMatrixFunction[4, 5, 2, 1] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[4, 5, 2, 3] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[4, 5, 3, 0] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[4, 5, 3, 2] = {{-I}}
 
z2Xz4Cat1FMatrixFunction[4, 5, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
z2Xz4Cat1FMatrixFunction[4, 5, 5, 4] = {{I/Sqrt[2], (-I)/Sqrt[2]}, 
    {I/Sqrt[2], I/Sqrt[2]}}
 
z2Xz4Cat1FMatrixFunction[5, 1, 1, 5] = {{-I}}
 
z2Xz4Cat1FMatrixFunction[5, 1, 2, 4] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[5, 1, 4, 2] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[5, 1, 5, 1] = {{-I}}
 
z2Xz4Cat1FMatrixFunction[5, 1, 5, 3] = {{I}}
 
z2Xz4Cat1FMatrixFunction[5, 2, 1, 4] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[5, 2, 2, 5] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[5, 2, 3, 4] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[5, 2, 4, 3] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[5, 2, 5, 2] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[5, 3, 1, 5] = {{I}}
 
z2Xz4Cat1FMatrixFunction[5, 3, 2, 4] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[5, 3, 3, 5] = {{I}}
 
z2Xz4Cat1FMatrixFunction[5, 3, 5, 1] = {{I}}
 
z2Xz4Cat1FMatrixFunction[5, 3, 5, 3] = {{I}}
 
z2Xz4Cat1FMatrixFunction[5, 4, 1, 0] = {{I}}
 
z2Xz4Cat1FMatrixFunction[5, 4, 1, 2] = {{I}}
 
z2Xz4Cat1FMatrixFunction[5, 4, 3, 2] = {{I}}
 
z2Xz4Cat1FMatrixFunction[5, 4, 4, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
z2Xz4Cat1FMatrixFunction[5, 4, 5, 4] = {{I/Sqrt[2], I/Sqrt[2]}, 
    {I/Sqrt[2], (-I)/Sqrt[2]}}
 
z2Xz4Cat1FMatrixFunction[5, 5, 2, 0] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[5, 5, 3, 1] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[5, 5, 3, 3] = {{-1}}
 
z2Xz4Cat1FMatrixFunction[5, 5, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
z2Xz4Cat1FMatrixFunction[5, 5, 5, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
z2Xz4Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[z2Xz4Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
z2Xz4Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[z2Xz4Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[z2Xz4Cat1Piv1] ^= {}
 
fusionCategory[z2Xz4Cat1Piv1] ^= z2Xz4Cat1
 
z2Xz4Cat1Piv1 /: modularCategory[z2Xz4Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat1Piv1] ^= z2Xz4Cat1Piv1
 
pivotalIsomorphism[z2Xz4Cat1Piv1] ^= z2Xz4Cat1Piv1PivotalIsomorphism
 
ring[z2Xz4Cat1Piv1] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat1Piv1] ^= z2Xz4Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat1]][pivotalCategory[#1]] & )[
    z2Xz4Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat1]][sphericalCategory[#1]] & )[
    z2Xz4Cat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat1Piv1PivotalIsomorphism] ^= z2Xz4Cat1
 
pivotalCategory[z2Xz4Cat1Piv1PivotalIsomorphism] ^= z2Xz4Cat1Piv1
 
pivotalIsomorphism[z2Xz4Cat1Piv1PivotalIsomorphism] ^= 
   z2Xz4Cat1Piv1PivotalIsomorphism
 
z2Xz4Cat1Piv1PivotalIsomorphism[0] = 1
 
z2Xz4Cat1Piv1PivotalIsomorphism[1] = -1
 
z2Xz4Cat1Piv1PivotalIsomorphism[2] = 1
 
z2Xz4Cat1Piv1PivotalIsomorphism[3] = -1
 
z2Xz4Cat1Piv1PivotalIsomorphism[4] = -1
 
z2Xz4Cat1Piv1PivotalIsomorphism[5] = -1
balancedCategories[z2Xz4Cat1Piv2] ^= {}
 
fusionCategory[z2Xz4Cat1Piv2] ^= z2Xz4Cat1
 
z2Xz4Cat1Piv2 /: modularCategory[z2Xz4Cat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat1Piv2] ^= z2Xz4Cat1Piv2
 
pivotalIsomorphism[z2Xz4Cat1Piv2] ^= z2Xz4Cat1Piv2PivotalIsomorphism
 
ring[z2Xz4Cat1Piv2] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat1Piv2] ^= z2Xz4Cat1Piv2
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat1]][pivotalCategory[#1]] & )[
    z2Xz4Cat1Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat1]][sphericalCategory[#1]] & )[
    z2Xz4Cat1Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat1Piv2PivotalIsomorphism] ^= z2Xz4Cat1
 
pivotalCategory[z2Xz4Cat1Piv2PivotalIsomorphism] ^= z2Xz4Cat1Piv2
 
pivotalIsomorphism[z2Xz4Cat1Piv2PivotalIsomorphism] ^= 
   z2Xz4Cat1Piv2PivotalIsomorphism
 
z2Xz4Cat1Piv2PivotalIsomorphism[0] = 1
 
z2Xz4Cat1Piv2PivotalIsomorphism[1] = 1
 
z2Xz4Cat1Piv2PivotalIsomorphism[2] = 1
 
z2Xz4Cat1Piv2PivotalIsomorphism[3] = 1
 
z2Xz4Cat1Piv2PivotalIsomorphism[4] = -1
 
z2Xz4Cat1Piv2PivotalIsomorphism[5] = 1
balancedCategories[z2Xz4Cat1Piv3] ^= {}
 
fusionCategory[z2Xz4Cat1Piv3] ^= z2Xz4Cat1
 
z2Xz4Cat1Piv3 /: modularCategory[z2Xz4Cat1Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat1Piv3] ^= z2Xz4Cat1Piv3
 
pivotalIsomorphism[z2Xz4Cat1Piv3] ^= z2Xz4Cat1Piv3PivotalIsomorphism
 
ring[z2Xz4Cat1Piv3] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat1Piv3] ^= z2Xz4Cat1Piv3
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat1]][pivotalCategory[#1]] & )[
    z2Xz4Cat1Piv3] ^= 3
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat1]][sphericalCategory[#1]] & )[
    z2Xz4Cat1Piv3] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat1Piv3PivotalIsomorphism] ^= z2Xz4Cat1
 
pivotalCategory[z2Xz4Cat1Piv3PivotalIsomorphism] ^= z2Xz4Cat1Piv3
 
pivotalIsomorphism[z2Xz4Cat1Piv3PivotalIsomorphism] ^= 
   z2Xz4Cat1Piv3PivotalIsomorphism
 
z2Xz4Cat1Piv3PivotalIsomorphism[0] = 1
 
z2Xz4Cat1Piv3PivotalIsomorphism[1] = 1
 
z2Xz4Cat1Piv3PivotalIsomorphism[2] = 1
 
z2Xz4Cat1Piv3PivotalIsomorphism[3] = 1
 
z2Xz4Cat1Piv3PivotalIsomorphism[4] = 1
 
z2Xz4Cat1Piv3PivotalIsomorphism[5] = -1
balancedCategories[z2Xz4Cat1Piv4] ^= {}
 
fusionCategory[z2Xz4Cat1Piv4] ^= z2Xz4Cat1
 
z2Xz4Cat1Piv4 /: modularCategory[z2Xz4Cat1Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat1Piv4] ^= z2Xz4Cat1Piv4
 
pivotalIsomorphism[z2Xz4Cat1Piv4] ^= z2Xz4Cat1Piv4PivotalIsomorphism
 
ring[z2Xz4Cat1Piv4] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat1Piv4] ^= z2Xz4Cat1Piv4
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat1]][pivotalCategory[#1]] & )[
    z2Xz4Cat1Piv4] ^= 4
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat1]][sphericalCategory[#1]] & )[
    z2Xz4Cat1Piv4] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat1Piv4PivotalIsomorphism] ^= z2Xz4Cat1
 
pivotalCategory[z2Xz4Cat1Piv4PivotalIsomorphism] ^= z2Xz4Cat1Piv4
 
pivotalIsomorphism[z2Xz4Cat1Piv4PivotalIsomorphism] ^= 
   z2Xz4Cat1Piv4PivotalIsomorphism
 
z2Xz4Cat1Piv4PivotalIsomorphism[0] = 1
 
z2Xz4Cat1Piv4PivotalIsomorphism[1] = -1
 
z2Xz4Cat1Piv4PivotalIsomorphism[2] = 1
 
z2Xz4Cat1Piv4PivotalIsomorphism[3] = -1
 
z2Xz4Cat1Piv4PivotalIsomorphism[4] = 1
 
z2Xz4Cat1Piv4PivotalIsomorphism[5] = 1
balancedCategories[z2Xz4Cat2] ^= {}
 
braidedCategories[z2Xz4Cat2] ^= {}
 
coeval[z2Xz4Cat2] ^= 1/sixJFunction[z2Xz4Cat2][#1, dual[ring[z2Xz4Cat2]][#1], 
      #1, #1, 0, 0] & 
 
eval[z2Xz4Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[z2Xz4Cat2] ^= z2Xz4Cat2FMatrixFunction
 
fusionCategory[z2Xz4Cat2] ^= z2Xz4Cat2
 
z2Xz4Cat2 /: modularCategory[z2Xz4Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[z2Xz4Cat2] ^= {z2Xz4Cat2Piv1, z2Xz4Cat2Piv2, z2Xz4Cat2Piv3, 
    z2Xz4Cat2Piv4}
 
z2Xz4Cat2 /: pivotalCategory[z2Xz4Cat2, 1] = z2Xz4Cat2Piv1
 
z2Xz4Cat2 /: pivotalCategory[z2Xz4Cat2, 2] = z2Xz4Cat2Piv2
 
z2Xz4Cat2 /: pivotalCategory[z2Xz4Cat2, 3] = z2Xz4Cat2Piv3
 
z2Xz4Cat2 /: pivotalCategory[z2Xz4Cat2, 4] = z2Xz4Cat2Piv4
 
z2Xz4Cat2 /: pivotalCategory[z2Xz4Cat2, {1, -1, 1, -1, -1, 1}] = z2Xz4Cat2Piv3
 
z2Xz4Cat2 /: pivotalCategory[z2Xz4Cat2, {1, -1, 1, -1, 1, -1}] = z2Xz4Cat2Piv4
 
z2Xz4Cat2 /: pivotalCategory[z2Xz4Cat2, {1, 1, 1, 1, -1, -1}] = z2Xz4Cat2Piv2
 
z2Xz4Cat2 /: pivotalCategory[z2Xz4Cat2, {1, 1, 1, 1, 1, 1}] = z2Xz4Cat2Piv1
 
ring[z2Xz4Cat2] ^= z2Xz4
 
z2Xz4Cat2 /: sphericalCategory[z2Xz4Cat2, 1] = z2Xz4Cat2Piv1
 
z2Xz4Cat2 /: sphericalCategory[z2Xz4Cat2, 2] = z2Xz4Cat2Piv2
 
z2Xz4Cat2 /: sphericalCategory[z2Xz4Cat2, 3] = z2Xz4Cat2Piv3
 
z2Xz4Cat2 /: sphericalCategory[z2Xz4Cat2, 4] = z2Xz4Cat2Piv4
 
fusionCategoryIndex[z2Xz4][z2Xz4Cat2] ^= 2
fMatrixFunction[z2Xz4Cat2FMatrixFunction] ^= z2Xz4Cat2FMatrixFunction
 
fusionCategory[z2Xz4Cat2FMatrixFunction] ^= z2Xz4Cat2
 
ring[z2Xz4Cat2FMatrixFunction] ^= z2Xz4
 
z2Xz4Cat2FMatrixFunction[1, 1, 1, 3] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[1, 1, 2, 0] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[1, 1, 5, 5] = {{I}}
 
z2Xz4Cat2FMatrixFunction[1, 2, 1, 0] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[1, 2, 2, 1] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[1, 2, 3, 2] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[1, 3, 2, 2] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[1, 3, 4, 4] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[1, 4, 2, 5] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[1, 4, 3, 4] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[1, 4, 4, 1] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[1, 4, 4, 3] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[1, 4, 5, 0] = {{I}}
 
z2Xz4Cat2FMatrixFunction[1, 4, 5, 2] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[1, 5, 1, 5] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[1, 5, 3, 5] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[1, 5, 4, 0] = {{I}}
 
z2Xz4Cat2FMatrixFunction[1, 5, 5, 1] = {{I}}
 
z2Xz4Cat2FMatrixFunction[1, 5, 5, 3] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[2, 1, 1, 0] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[2, 1, 3, 2] = {{I}}
 
z2Xz4Cat2FMatrixFunction[2, 1, 4, 5] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[2, 2, 3, 3] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[2, 2, 4, 4] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[2, 2, 5, 5] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[2, 3, 3, 0] = {{I}}
 
z2Xz4Cat2FMatrixFunction[2, 3, 4, 5] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[2, 4, 1, 5] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[2, 4, 2, 4] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[2, 4, 4, 2] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[2, 4, 5, 1] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[2, 4, 5, 3] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[2, 5, 2, 5] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[2, 5, 3, 4] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[2, 5, 5, 0] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[3, 1, 1, 1] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[3, 1, 5, 5] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[3, 2, 1, 2] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[3, 2, 2, 3] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[3, 2, 3, 0] = {{I}}
 
z2Xz4Cat2FMatrixFunction[3, 3, 1, 3] = {{I}}
 
z2Xz4Cat2FMatrixFunction[3, 3, 2, 0] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[3, 3, 3, 1] = {{I}}
 
z2Xz4Cat2FMatrixFunction[3, 3, 5, 5] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[3, 4, 1, 4] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[3, 4, 3, 4] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[3, 4, 5, 2] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[3, 5, 1, 5] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[3, 5, 2, 4] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[3, 5, 3, 5] = {{I}}
 
z2Xz4Cat2FMatrixFunction[3, 5, 4, 0] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[3, 5, 5, 1] = {{I}}
 
z2Xz4Cat2FMatrixFunction[3, 5, 5, 3] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[4, 1, 1, 4] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[4, 1, 3, 4] = {{I}}
 
z2Xz4Cat2FMatrixFunction[4, 2, 1, 5] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[4, 2, 2, 4] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[4, 2, 3, 5] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[4, 2, 4, 0] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[4, 2, 5, 3] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[4, 3, 3, 4] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[4, 3, 4, 3] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[4, 3, 5, 2] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[4, 4, 1, 1] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[4, 4, 1, 3] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[4, 4, 2, 0] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[4, 4, 3, 1] = {{I}}
 
z2Xz4Cat2FMatrixFunction[4, 4, 3, 3] = {{I}}
 
z2Xz4Cat2FMatrixFunction[4, 4, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
z2Xz4Cat2FMatrixFunction[4, 4, 5, 5] = {{I/Sqrt[2], I/Sqrt[2]}, 
    {(-I)/Sqrt[2], I/Sqrt[2]}}
 
z2Xz4Cat2FMatrixFunction[4, 5, 1, 0] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[4, 5, 1, 2] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[4, 5, 2, 1] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[4, 5, 2, 3] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[4, 5, 3, 2] = {{I}}
 
z2Xz4Cat2FMatrixFunction[4, 5, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
z2Xz4Cat2FMatrixFunction[4, 5, 5, 4] = {{(-I)/Sqrt[2], I/Sqrt[2]}, 
    {(-I)/Sqrt[2], (-I)/Sqrt[2]}}
 
z2Xz4Cat2FMatrixFunction[5, 1, 1, 5] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[5, 1, 2, 4] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[5, 1, 4, 2] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[5, 1, 5, 1] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[5, 1, 5, 3] = {{I}}
 
z2Xz4Cat2FMatrixFunction[5, 2, 1, 4] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[5, 2, 2, 5] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[5, 2, 3, 4] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[5, 2, 4, 3] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[5, 2, 5, 2] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[5, 3, 1, 5] = {{I}}
 
z2Xz4Cat2FMatrixFunction[5, 3, 2, 4] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[5, 3, 3, 5] = {{I}}
 
z2Xz4Cat2FMatrixFunction[5, 3, 5, 1] = {{I}}
 
z2Xz4Cat2FMatrixFunction[5, 3, 5, 3] = {{I}}
 
z2Xz4Cat2FMatrixFunction[5, 4, 1, 0] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[5, 4, 1, 2] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[5, 4, 3, 0] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[5, 4, 3, 2] = {{-I}}
 
z2Xz4Cat2FMatrixFunction[5, 4, 4, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
z2Xz4Cat2FMatrixFunction[5, 4, 5, 4] = {{(-I)/Sqrt[2], (-I)/Sqrt[2]}, 
    {(-I)/Sqrt[2], I/Sqrt[2]}}
 
z2Xz4Cat2FMatrixFunction[5, 5, 1, 1] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[5, 5, 2, 0] = {{-1}}
 
z2Xz4Cat2FMatrixFunction[5, 5, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
z2Xz4Cat2FMatrixFunction[5, 5, 5, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
z2Xz4Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[z2Xz4Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
z2Xz4Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[z2Xz4Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[z2Xz4Cat2Piv1] ^= {}
 
fusionCategory[z2Xz4Cat2Piv1] ^= z2Xz4Cat2
 
z2Xz4Cat2Piv1 /: modularCategory[z2Xz4Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat2Piv1] ^= z2Xz4Cat2Piv1
 
pivotalIsomorphism[z2Xz4Cat2Piv1] ^= z2Xz4Cat2Piv1PivotalIsomorphism
 
ring[z2Xz4Cat2Piv1] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat2Piv1] ^= z2Xz4Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat2]][pivotalCategory[#1]] & )[
    z2Xz4Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat2]][sphericalCategory[#1]] & )[
    z2Xz4Cat2Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat2Piv1PivotalIsomorphism] ^= z2Xz4Cat2
 
pivotalCategory[z2Xz4Cat2Piv1PivotalIsomorphism] ^= z2Xz4Cat2Piv1
 
pivotalIsomorphism[z2Xz4Cat2Piv1PivotalIsomorphism] ^= 
   z2Xz4Cat2Piv1PivotalIsomorphism
 
z2Xz4Cat2Piv1PivotalIsomorphism[0] = 1
 
z2Xz4Cat2Piv1PivotalIsomorphism[1] = 1
 
z2Xz4Cat2Piv1PivotalIsomorphism[2] = 1
 
z2Xz4Cat2Piv1PivotalIsomorphism[3] = 1
 
z2Xz4Cat2Piv1PivotalIsomorphism[4] = 1
 
z2Xz4Cat2Piv1PivotalIsomorphism[5] = 1
balancedCategories[z2Xz4Cat2Piv2] ^= {}
 
fusionCategory[z2Xz4Cat2Piv2] ^= z2Xz4Cat2
 
z2Xz4Cat2Piv2 /: modularCategory[z2Xz4Cat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat2Piv2] ^= z2Xz4Cat2Piv2
 
pivotalIsomorphism[z2Xz4Cat2Piv2] ^= z2Xz4Cat2Piv2PivotalIsomorphism
 
ring[z2Xz4Cat2Piv2] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat2Piv2] ^= z2Xz4Cat2Piv2
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat2]][pivotalCategory[#1]] & )[
    z2Xz4Cat2Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat2]][sphericalCategory[#1]] & )[
    z2Xz4Cat2Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat2Piv2PivotalIsomorphism] ^= z2Xz4Cat2
 
pivotalCategory[z2Xz4Cat2Piv2PivotalIsomorphism] ^= z2Xz4Cat2Piv2
 
pivotalIsomorphism[z2Xz4Cat2Piv2PivotalIsomorphism] ^= 
   z2Xz4Cat2Piv2PivotalIsomorphism
 
z2Xz4Cat2Piv2PivotalIsomorphism[0] = 1
 
z2Xz4Cat2Piv2PivotalIsomorphism[1] = 1
 
z2Xz4Cat2Piv2PivotalIsomorphism[2] = 1
 
z2Xz4Cat2Piv2PivotalIsomorphism[3] = 1
 
z2Xz4Cat2Piv2PivotalIsomorphism[4] = -1
 
z2Xz4Cat2Piv2PivotalIsomorphism[5] = -1
balancedCategories[z2Xz4Cat2Piv3] ^= {}
 
fusionCategory[z2Xz4Cat2Piv3] ^= z2Xz4Cat2
 
z2Xz4Cat2Piv3 /: modularCategory[z2Xz4Cat2Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat2Piv3] ^= z2Xz4Cat2Piv3
 
pivotalIsomorphism[z2Xz4Cat2Piv3] ^= z2Xz4Cat2Piv3PivotalIsomorphism
 
ring[z2Xz4Cat2Piv3] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat2Piv3] ^= z2Xz4Cat2Piv3
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat2]][pivotalCategory[#1]] & )[
    z2Xz4Cat2Piv3] ^= 3
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat2]][sphericalCategory[#1]] & )[
    z2Xz4Cat2Piv3] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat2Piv3PivotalIsomorphism] ^= z2Xz4Cat2
 
pivotalCategory[z2Xz4Cat2Piv3PivotalIsomorphism] ^= z2Xz4Cat2Piv3
 
pivotalIsomorphism[z2Xz4Cat2Piv3PivotalIsomorphism] ^= 
   z2Xz4Cat2Piv3PivotalIsomorphism
 
z2Xz4Cat2Piv3PivotalIsomorphism[0] = 1
 
z2Xz4Cat2Piv3PivotalIsomorphism[1] = -1
 
z2Xz4Cat2Piv3PivotalIsomorphism[2] = 1
 
z2Xz4Cat2Piv3PivotalIsomorphism[3] = -1
 
z2Xz4Cat2Piv3PivotalIsomorphism[4] = -1
 
z2Xz4Cat2Piv3PivotalIsomorphism[5] = 1
balancedCategories[z2Xz4Cat2Piv4] ^= {}
 
fusionCategory[z2Xz4Cat2Piv4] ^= z2Xz4Cat2
 
z2Xz4Cat2Piv4 /: modularCategory[z2Xz4Cat2Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat2Piv4] ^= z2Xz4Cat2Piv4
 
pivotalIsomorphism[z2Xz4Cat2Piv4] ^= z2Xz4Cat2Piv4PivotalIsomorphism
 
ring[z2Xz4Cat2Piv4] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat2Piv4] ^= z2Xz4Cat2Piv4
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat2]][pivotalCategory[#1]] & )[
    z2Xz4Cat2Piv4] ^= 4
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat2]][sphericalCategory[#1]] & )[
    z2Xz4Cat2Piv4] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat2Piv4PivotalIsomorphism] ^= z2Xz4Cat2
 
pivotalCategory[z2Xz4Cat2Piv4PivotalIsomorphism] ^= z2Xz4Cat2Piv4
 
pivotalIsomorphism[z2Xz4Cat2Piv4PivotalIsomorphism] ^= 
   z2Xz4Cat2Piv4PivotalIsomorphism
 
z2Xz4Cat2Piv4PivotalIsomorphism[0] = 1
 
z2Xz4Cat2Piv4PivotalIsomorphism[1] = -1
 
z2Xz4Cat2Piv4PivotalIsomorphism[2] = 1
 
z2Xz4Cat2Piv4PivotalIsomorphism[3] = -1
 
z2Xz4Cat2Piv4PivotalIsomorphism[4] = 1
 
z2Xz4Cat2Piv4PivotalIsomorphism[5] = -1
balancedCategories[z2Xz4Cat3] ^= {}
 
braidedCategories[z2Xz4Cat3] ^= {}
 
coeval[z2Xz4Cat3] ^= 1/sixJFunction[z2Xz4Cat3][#1, dual[ring[z2Xz4Cat3]][#1], 
      #1, #1, 0, 0] & 
 
eval[z2Xz4Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[z2Xz4Cat3] ^= z2Xz4Cat3FMatrixFunction
 
fusionCategory[z2Xz4Cat3] ^= z2Xz4Cat3
 
z2Xz4Cat3 /: modularCategory[z2Xz4Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[z2Xz4Cat3] ^= {z2Xz4Cat3Piv1, z2Xz4Cat3Piv2, z2Xz4Cat3Piv3, 
    z2Xz4Cat3Piv4}
 
z2Xz4Cat3 /: pivotalCategory[z2Xz4Cat3, 1] = z2Xz4Cat3Piv1
 
z2Xz4Cat3 /: pivotalCategory[z2Xz4Cat3, 2] = z2Xz4Cat3Piv2
 
z2Xz4Cat3 /: pivotalCategory[z2Xz4Cat3, 3] = z2Xz4Cat3Piv3
 
z2Xz4Cat3 /: pivotalCategory[z2Xz4Cat3, 4] = z2Xz4Cat3Piv4
 
z2Xz4Cat3 /: pivotalCategory[z2Xz4Cat3, {1, -1, 1, -1, -1, 1}] = z2Xz4Cat3Piv3
 
z2Xz4Cat3 /: pivotalCategory[z2Xz4Cat3, {1, -1, 1, -1, 1, -1}] = z2Xz4Cat3Piv4
 
z2Xz4Cat3 /: pivotalCategory[z2Xz4Cat3, {1, 1, 1, 1, -1, -1}] = z2Xz4Cat3Piv2
 
z2Xz4Cat3 /: pivotalCategory[z2Xz4Cat3, {1, 1, 1, 1, 1, 1}] = z2Xz4Cat3Piv1
 
ring[z2Xz4Cat3] ^= z2Xz4
 
z2Xz4Cat3 /: sphericalCategory[z2Xz4Cat3, 1] = z2Xz4Cat3Piv1
 
z2Xz4Cat3 /: sphericalCategory[z2Xz4Cat3, 2] = z2Xz4Cat3Piv2
 
z2Xz4Cat3 /: sphericalCategory[z2Xz4Cat3, 3] = z2Xz4Cat3Piv3
 
z2Xz4Cat3 /: sphericalCategory[z2Xz4Cat3, 4] = z2Xz4Cat3Piv4
 
fusionCategoryIndex[z2Xz4][z2Xz4Cat3] ^= 3
fMatrixFunction[z2Xz4Cat3FMatrixFunction] ^= z2Xz4Cat3FMatrixFunction
 
fusionCategory[z2Xz4Cat3FMatrixFunction] ^= z2Xz4Cat3
 
ring[z2Xz4Cat3FMatrixFunction] ^= z2Xz4
 
z2Xz4Cat3FMatrixFunction[1, 1, 1, 3] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[1, 1, 2, 0] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[1, 1, 5, 5] = {{I}}
 
z2Xz4Cat3FMatrixFunction[1, 2, 1, 0] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[1, 2, 2, 1] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[1, 2, 3, 2] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[1, 3, 2, 2] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[1, 3, 4, 4] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[1, 4, 2, 5] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[1, 4, 3, 4] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[1, 4, 4, 1] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[1, 4, 4, 3] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[1, 4, 5, 0] = {{I}}
 
z2Xz4Cat3FMatrixFunction[1, 4, 5, 2] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[1, 5, 1, 5] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[1, 5, 3, 5] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[1, 5, 4, 0] = {{I}}
 
z2Xz4Cat3FMatrixFunction[1, 5, 5, 1] = {{I}}
 
z2Xz4Cat3FMatrixFunction[1, 5, 5, 3] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[2, 1, 1, 0] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[2, 1, 3, 2] = {{I}}
 
z2Xz4Cat3FMatrixFunction[2, 1, 4, 5] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[2, 2, 3, 3] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[2, 2, 4, 4] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[2, 2, 5, 5] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[2, 3, 3, 0] = {{I}}
 
z2Xz4Cat3FMatrixFunction[2, 3, 4, 5] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[2, 4, 1, 5] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[2, 4, 2, 4] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[2, 4, 4, 2] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[2, 4, 5, 1] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[2, 4, 5, 3] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[2, 5, 2, 5] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[2, 5, 3, 4] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[2, 5, 5, 0] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[3, 1, 1, 1] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[3, 1, 5, 5] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[3, 2, 1, 2] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[3, 2, 2, 3] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[3, 2, 3, 0] = {{I}}
 
z2Xz4Cat3FMatrixFunction[3, 3, 1, 3] = {{I}}
 
z2Xz4Cat3FMatrixFunction[3, 3, 2, 0] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[3, 3, 3, 1] = {{I}}
 
z2Xz4Cat3FMatrixFunction[3, 3, 5, 5] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[3, 4, 1, 4] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[3, 4, 3, 4] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[3, 4, 5, 2] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[3, 5, 1, 5] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[3, 5, 2, 4] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[3, 5, 3, 5] = {{I}}
 
z2Xz4Cat3FMatrixFunction[3, 5, 4, 0] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[3, 5, 5, 1] = {{I}}
 
z2Xz4Cat3FMatrixFunction[3, 5, 5, 3] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[4, 1, 1, 4] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[4, 1, 3, 4] = {{I}}
 
z2Xz4Cat3FMatrixFunction[4, 2, 1, 5] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[4, 2, 2, 4] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[4, 2, 3, 5] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[4, 2, 4, 0] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[4, 2, 5, 3] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[4, 3, 3, 4] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[4, 3, 4, 3] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[4, 3, 5, 2] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[4, 4, 1, 1] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[4, 4, 1, 3] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[4, 4, 2, 0] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[4, 4, 3, 1] = {{I}}
 
z2Xz4Cat3FMatrixFunction[4, 4, 3, 3] = {{I}}
 
z2Xz4Cat3FMatrixFunction[4, 4, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
z2Xz4Cat3FMatrixFunction[4, 4, 5, 5] = {{(-I)/Sqrt[2], (-I)/Sqrt[2]}, 
    {I/Sqrt[2], (-I)/Sqrt[2]}}
 
z2Xz4Cat3FMatrixFunction[4, 5, 1, 0] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[4, 5, 1, 2] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[4, 5, 2, 1] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[4, 5, 2, 3] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[4, 5, 3, 2] = {{I}}
 
z2Xz4Cat3FMatrixFunction[4, 5, 4, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
z2Xz4Cat3FMatrixFunction[4, 5, 5, 4] = {{I/Sqrt[2], (-I)/Sqrt[2]}, 
    {I/Sqrt[2], I/Sqrt[2]}}
 
z2Xz4Cat3FMatrixFunction[5, 1, 1, 5] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[5, 1, 2, 4] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[5, 1, 4, 2] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[5, 1, 5, 1] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[5, 1, 5, 3] = {{I}}
 
z2Xz4Cat3FMatrixFunction[5, 2, 1, 4] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[5, 2, 2, 5] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[5, 2, 3, 4] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[5, 2, 4, 3] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[5, 2, 5, 2] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[5, 3, 1, 5] = {{I}}
 
z2Xz4Cat3FMatrixFunction[5, 3, 2, 4] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[5, 3, 3, 5] = {{I}}
 
z2Xz4Cat3FMatrixFunction[5, 3, 5, 1] = {{I}}
 
z2Xz4Cat3FMatrixFunction[5, 3, 5, 3] = {{I}}
 
z2Xz4Cat3FMatrixFunction[5, 4, 1, 0] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[5, 4, 1, 2] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[5, 4, 3, 0] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[5, 4, 3, 2] = {{-I}}
 
z2Xz4Cat3FMatrixFunction[5, 4, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
z2Xz4Cat3FMatrixFunction[5, 4, 5, 4] = {{I/Sqrt[2], I/Sqrt[2]}, 
    {I/Sqrt[2], (-I)/Sqrt[2]}}
 
z2Xz4Cat3FMatrixFunction[5, 5, 1, 1] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[5, 5, 2, 0] = {{-1}}
 
z2Xz4Cat3FMatrixFunction[5, 5, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
z2Xz4Cat3FMatrixFunction[5, 5, 5, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
z2Xz4Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[z2Xz4Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
z2Xz4Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[z2Xz4Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[z2Xz4Cat3Piv1] ^= {}
 
fusionCategory[z2Xz4Cat3Piv1] ^= z2Xz4Cat3
 
z2Xz4Cat3Piv1 /: modularCategory[z2Xz4Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat3Piv1] ^= z2Xz4Cat3Piv1
 
pivotalIsomorphism[z2Xz4Cat3Piv1] ^= z2Xz4Cat3Piv1PivotalIsomorphism
 
ring[z2Xz4Cat3Piv1] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat3Piv1] ^= z2Xz4Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat3]][pivotalCategory[#1]] & )[
    z2Xz4Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat3]][sphericalCategory[#1]] & )[
    z2Xz4Cat3Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat3Piv1PivotalIsomorphism] ^= z2Xz4Cat3
 
pivotalCategory[z2Xz4Cat3Piv1PivotalIsomorphism] ^= z2Xz4Cat3Piv1
 
pivotalIsomorphism[z2Xz4Cat3Piv1PivotalIsomorphism] ^= 
   z2Xz4Cat3Piv1PivotalIsomorphism
 
z2Xz4Cat3Piv1PivotalIsomorphism[0] = 1
 
z2Xz4Cat3Piv1PivotalIsomorphism[1] = 1
 
z2Xz4Cat3Piv1PivotalIsomorphism[2] = 1
 
z2Xz4Cat3Piv1PivotalIsomorphism[3] = 1
 
z2Xz4Cat3Piv1PivotalIsomorphism[4] = 1
 
z2Xz4Cat3Piv1PivotalIsomorphism[5] = 1
balancedCategories[z2Xz4Cat3Piv2] ^= {}
 
fusionCategory[z2Xz4Cat3Piv2] ^= z2Xz4Cat3
 
z2Xz4Cat3Piv2 /: modularCategory[z2Xz4Cat3Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat3Piv2] ^= z2Xz4Cat3Piv2
 
pivotalIsomorphism[z2Xz4Cat3Piv2] ^= z2Xz4Cat3Piv2PivotalIsomorphism
 
ring[z2Xz4Cat3Piv2] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat3Piv2] ^= z2Xz4Cat3Piv2
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat3]][pivotalCategory[#1]] & )[
    z2Xz4Cat3Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat3]][sphericalCategory[#1]] & )[
    z2Xz4Cat3Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat3Piv2PivotalIsomorphism] ^= z2Xz4Cat3
 
pivotalCategory[z2Xz4Cat3Piv2PivotalIsomorphism] ^= z2Xz4Cat3Piv2
 
pivotalIsomorphism[z2Xz4Cat3Piv2PivotalIsomorphism] ^= 
   z2Xz4Cat3Piv2PivotalIsomorphism
 
z2Xz4Cat3Piv2PivotalIsomorphism[0] = 1
 
z2Xz4Cat3Piv2PivotalIsomorphism[1] = 1
 
z2Xz4Cat3Piv2PivotalIsomorphism[2] = 1
 
z2Xz4Cat3Piv2PivotalIsomorphism[3] = 1
 
z2Xz4Cat3Piv2PivotalIsomorphism[4] = -1
 
z2Xz4Cat3Piv2PivotalIsomorphism[5] = -1
balancedCategories[z2Xz4Cat3Piv3] ^= {}
 
fusionCategory[z2Xz4Cat3Piv3] ^= z2Xz4Cat3
 
z2Xz4Cat3Piv3 /: modularCategory[z2Xz4Cat3Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat3Piv3] ^= z2Xz4Cat3Piv3
 
pivotalIsomorphism[z2Xz4Cat3Piv3] ^= z2Xz4Cat3Piv3PivotalIsomorphism
 
ring[z2Xz4Cat3Piv3] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat3Piv3] ^= z2Xz4Cat3Piv3
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat3]][pivotalCategory[#1]] & )[
    z2Xz4Cat3Piv3] ^= 3
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat3]][sphericalCategory[#1]] & )[
    z2Xz4Cat3Piv3] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat3Piv3PivotalIsomorphism] ^= z2Xz4Cat3
 
pivotalCategory[z2Xz4Cat3Piv3PivotalIsomorphism] ^= z2Xz4Cat3Piv3
 
pivotalIsomorphism[z2Xz4Cat3Piv3PivotalIsomorphism] ^= 
   z2Xz4Cat3Piv3PivotalIsomorphism
 
z2Xz4Cat3Piv3PivotalIsomorphism[0] = 1
 
z2Xz4Cat3Piv3PivotalIsomorphism[1] = -1
 
z2Xz4Cat3Piv3PivotalIsomorphism[2] = 1
 
z2Xz4Cat3Piv3PivotalIsomorphism[3] = -1
 
z2Xz4Cat3Piv3PivotalIsomorphism[4] = -1
 
z2Xz4Cat3Piv3PivotalIsomorphism[5] = 1
balancedCategories[z2Xz4Cat3Piv4] ^= {}
 
fusionCategory[z2Xz4Cat3Piv4] ^= z2Xz4Cat3
 
z2Xz4Cat3Piv4 /: modularCategory[z2Xz4Cat3Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat3Piv4] ^= z2Xz4Cat3Piv4
 
pivotalIsomorphism[z2Xz4Cat3Piv4] ^= z2Xz4Cat3Piv4PivotalIsomorphism
 
ring[z2Xz4Cat3Piv4] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat3Piv4] ^= z2Xz4Cat3Piv4
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat3]][pivotalCategory[#1]] & )[
    z2Xz4Cat3Piv4] ^= 4
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat3]][sphericalCategory[#1]] & )[
    z2Xz4Cat3Piv4] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat3Piv4PivotalIsomorphism] ^= z2Xz4Cat3
 
pivotalCategory[z2Xz4Cat3Piv4PivotalIsomorphism] ^= z2Xz4Cat3Piv4
 
pivotalIsomorphism[z2Xz4Cat3Piv4PivotalIsomorphism] ^= 
   z2Xz4Cat3Piv4PivotalIsomorphism
 
z2Xz4Cat3Piv4PivotalIsomorphism[0] = 1
 
z2Xz4Cat3Piv4PivotalIsomorphism[1] = -1
 
z2Xz4Cat3Piv4PivotalIsomorphism[2] = 1
 
z2Xz4Cat3Piv4PivotalIsomorphism[3] = -1
 
z2Xz4Cat3Piv4PivotalIsomorphism[4] = 1
 
z2Xz4Cat3Piv4PivotalIsomorphism[5] = -1
balancedCategories[z2Xz4Cat4] ^= {}
 
braidedCategories[z2Xz4Cat4] ^= {}
 
coeval[z2Xz4Cat4] ^= 1/sixJFunction[z2Xz4Cat4][#1, dual[ring[z2Xz4Cat4]][#1], 
      #1, #1, 0, 0] & 
 
eval[z2Xz4Cat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[z2Xz4Cat4] ^= z2Xz4Cat4FMatrixFunction
 
fusionCategory[z2Xz4Cat4] ^= z2Xz4Cat4
 
z2Xz4Cat4 /: modularCategory[z2Xz4Cat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[z2Xz4Cat4] ^= {z2Xz4Cat4Piv1, z2Xz4Cat4Piv2, z2Xz4Cat4Piv3, 
    z2Xz4Cat4Piv4}
 
z2Xz4Cat4 /: pivotalCategory[z2Xz4Cat4, 1] = z2Xz4Cat4Piv1
 
z2Xz4Cat4 /: pivotalCategory[z2Xz4Cat4, 2] = z2Xz4Cat4Piv2
 
z2Xz4Cat4 /: pivotalCategory[z2Xz4Cat4, 3] = z2Xz4Cat4Piv3
 
z2Xz4Cat4 /: pivotalCategory[z2Xz4Cat4, 4] = z2Xz4Cat4Piv4
 
z2Xz4Cat4 /: pivotalCategory[z2Xz4Cat4, {1, -1, 1, -1, -1, 1}] = z2Xz4Cat4Piv3
 
z2Xz4Cat4 /: pivotalCategory[z2Xz4Cat4, {1, -1, 1, -1, 1, -1}] = z2Xz4Cat4Piv4
 
z2Xz4Cat4 /: pivotalCategory[z2Xz4Cat4, {1, 1, 1, 1, -1, -1}] = z2Xz4Cat4Piv2
 
z2Xz4Cat4 /: pivotalCategory[z2Xz4Cat4, {1, 1, 1, 1, 1, 1}] = z2Xz4Cat4Piv1
 
ring[z2Xz4Cat4] ^= z2Xz4
 
z2Xz4Cat4 /: sphericalCategory[z2Xz4Cat4, 1] = z2Xz4Cat4Piv1
 
z2Xz4Cat4 /: sphericalCategory[z2Xz4Cat4, 2] = z2Xz4Cat4Piv2
 
z2Xz4Cat4 /: sphericalCategory[z2Xz4Cat4, 3] = z2Xz4Cat4Piv3
 
z2Xz4Cat4 /: sphericalCategory[z2Xz4Cat4, 4] = z2Xz4Cat4Piv4
 
fusionCategoryIndex[z2Xz4][z2Xz4Cat4] ^= 4
fMatrixFunction[z2Xz4Cat4FMatrixFunction] ^= z2Xz4Cat4FMatrixFunction
 
fusionCategory[z2Xz4Cat4FMatrixFunction] ^= z2Xz4Cat4
 
ring[z2Xz4Cat4FMatrixFunction] ^= z2Xz4
 
z2Xz4Cat4FMatrixFunction[1, 1, 1, 3] = {{I}}
 
z2Xz4Cat4FMatrixFunction[1, 1, 2, 0] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[1, 1, 3, 1] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[1, 1, 5, 5] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[1, 2, 1, 0] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[1, 2, 2, 1] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[1, 2, 3, 2] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[1, 3, 1, 1] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[1, 3, 2, 2] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[1, 3, 3, 3] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[1, 3, 4, 4] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[1, 3, 5, 5] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[1, 4, 2, 5] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[1, 4, 3, 4] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[1, 4, 4, 1] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[1, 4, 4, 3] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[1, 4, 5, 0] = {{I}}
 
z2Xz4Cat4FMatrixFunction[1, 4, 5, 2] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[1, 5, 1, 5] = {{I}}
 
z2Xz4Cat4FMatrixFunction[1, 5, 3, 5] = {{I}}
 
z2Xz4Cat4FMatrixFunction[1, 5, 4, 0] = {{I}}
 
z2Xz4Cat4FMatrixFunction[1, 5, 5, 1] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[1, 5, 5, 3] = {{I}}
 
z2Xz4Cat4FMatrixFunction[2, 1, 1, 0] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[2, 1, 3, 2] = {{I}}
 
z2Xz4Cat4FMatrixFunction[2, 1, 4, 5] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[2, 2, 3, 3] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[2, 2, 4, 4] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[2, 2, 5, 5] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[2, 3, 3, 0] = {{I}}
 
z2Xz4Cat4FMatrixFunction[2, 3, 4, 5] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[2, 4, 1, 5] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[2, 4, 2, 4] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[2, 4, 4, 2] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[2, 4, 5, 1] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[2, 4, 5, 3] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[2, 5, 2, 5] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[2, 5, 3, 4] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[2, 5, 5, 0] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[3, 1, 1, 1] = {{I}}
 
z2Xz4Cat4FMatrixFunction[3, 1, 3, 3] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[3, 1, 5, 5] = {{I}}
 
z2Xz4Cat4FMatrixFunction[3, 2, 1, 2] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[3, 2, 2, 3] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[3, 2, 3, 0] = {{I}}
 
z2Xz4Cat4FMatrixFunction[3, 3, 1, 3] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[3, 3, 2, 0] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[3, 3, 3, 1] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[3, 3, 5, 5] = {{I}}
 
z2Xz4Cat4FMatrixFunction[3, 4, 1, 4] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[3, 4, 3, 4] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[3, 4, 5, 2] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[3, 5, 1, 5] = {{I}}
 
z2Xz4Cat4FMatrixFunction[3, 5, 2, 4] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[3, 5, 3, 5] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[3, 5, 4, 0] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[3, 5, 5, 1] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[3, 5, 5, 3] = {{I}}
 
z2Xz4Cat4FMatrixFunction[4, 1, 1, 4] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[4, 1, 3, 4] = {{I}}
 
z2Xz4Cat4FMatrixFunction[4, 2, 1, 5] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[4, 2, 2, 4] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[4, 2, 3, 5] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[4, 2, 4, 0] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[4, 2, 5, 3] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[4, 3, 3, 4] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[4, 3, 4, 3] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[4, 3, 5, 2] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[4, 4, 1, 1] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[4, 4, 1, 3] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[4, 4, 2, 0] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[4, 4, 3, 1] = {{I}}
 
z2Xz4Cat4FMatrixFunction[4, 4, 3, 3] = {{I}}
 
z2Xz4Cat4FMatrixFunction[4, 4, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
z2Xz4Cat4FMatrixFunction[4, 4, 5, 5] = {{I/Sqrt[2], I/Sqrt[2]}, 
    {(-I)/Sqrt[2], I/Sqrt[2]}}
 
z2Xz4Cat4FMatrixFunction[4, 5, 1, 0] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[4, 5, 1, 2] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[4, 5, 2, 1] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[4, 5, 2, 3] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[4, 5, 3, 2] = {{I}}
 
z2Xz4Cat4FMatrixFunction[4, 5, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
z2Xz4Cat4FMatrixFunction[4, 5, 5, 4] = {{(-I)/Sqrt[2], I/Sqrt[2]}, 
    {(-I)/Sqrt[2], (-I)/Sqrt[2]}}
 
z2Xz4Cat4FMatrixFunction[5, 1, 1, 5] = {{I}}
 
z2Xz4Cat4FMatrixFunction[5, 1, 2, 4] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[5, 1, 3, 5] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[5, 1, 4, 2] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[5, 1, 5, 1] = {{I}}
 
z2Xz4Cat4FMatrixFunction[5, 1, 5, 3] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[5, 2, 1, 4] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[5, 2, 2, 5] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[5, 2, 3, 4] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[5, 2, 4, 3] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[5, 2, 5, 2] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[5, 3, 1, 5] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[5, 3, 2, 4] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[5, 3, 3, 5] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[5, 3, 5, 1] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[5, 3, 5, 3] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[5, 4, 1, 0] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[5, 4, 1, 2] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[5, 4, 3, 0] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[5, 4, 3, 2] = {{-I}}
 
z2Xz4Cat4FMatrixFunction[5, 4, 4, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
z2Xz4Cat4FMatrixFunction[5, 4, 5, 4] = {{(-I)/Sqrt[2], (-I)/Sqrt[2]}, 
    {(-I)/Sqrt[2], I/Sqrt[2]}}
 
z2Xz4Cat4FMatrixFunction[5, 5, 2, 0] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[5, 5, 3, 1] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[5, 5, 3, 3] = {{-1}}
 
z2Xz4Cat4FMatrixFunction[5, 5, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
z2Xz4Cat4FMatrixFunction[5, 5, 5, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
z2Xz4Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[z2Xz4Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
z2Xz4Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[z2Xz4Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[z2Xz4Cat4Piv1] ^= {}
 
fusionCategory[z2Xz4Cat4Piv1] ^= z2Xz4Cat4
 
z2Xz4Cat4Piv1 /: modularCategory[z2Xz4Cat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat4Piv1] ^= z2Xz4Cat4Piv1
 
pivotalIsomorphism[z2Xz4Cat4Piv1] ^= z2Xz4Cat4Piv1PivotalIsomorphism
 
ring[z2Xz4Cat4Piv1] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat4Piv1] ^= z2Xz4Cat4Piv1
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat4]][pivotalCategory[#1]] & )[
    z2Xz4Cat4Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat4]][sphericalCategory[#1]] & )[
    z2Xz4Cat4Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat4Piv1PivotalIsomorphism] ^= z2Xz4Cat4
 
pivotalCategory[z2Xz4Cat4Piv1PivotalIsomorphism] ^= z2Xz4Cat4Piv1
 
pivotalIsomorphism[z2Xz4Cat4Piv1PivotalIsomorphism] ^= 
   z2Xz4Cat4Piv1PivotalIsomorphism
 
z2Xz4Cat4Piv1PivotalIsomorphism[0] = 1
 
z2Xz4Cat4Piv1PivotalIsomorphism[1] = 1
 
z2Xz4Cat4Piv1PivotalIsomorphism[2] = 1
 
z2Xz4Cat4Piv1PivotalIsomorphism[3] = 1
 
z2Xz4Cat4Piv1PivotalIsomorphism[4] = 1
 
z2Xz4Cat4Piv1PivotalIsomorphism[5] = 1
balancedCategories[z2Xz4Cat4Piv2] ^= {}
 
fusionCategory[z2Xz4Cat4Piv2] ^= z2Xz4Cat4
 
z2Xz4Cat4Piv2 /: modularCategory[z2Xz4Cat4Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat4Piv2] ^= z2Xz4Cat4Piv2
 
pivotalIsomorphism[z2Xz4Cat4Piv2] ^= z2Xz4Cat4Piv2PivotalIsomorphism
 
ring[z2Xz4Cat4Piv2] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat4Piv2] ^= z2Xz4Cat4Piv2
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat4]][pivotalCategory[#1]] & )[
    z2Xz4Cat4Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat4]][sphericalCategory[#1]] & )[
    z2Xz4Cat4Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat4Piv2PivotalIsomorphism] ^= z2Xz4Cat4
 
pivotalCategory[z2Xz4Cat4Piv2PivotalIsomorphism] ^= z2Xz4Cat4Piv2
 
pivotalIsomorphism[z2Xz4Cat4Piv2PivotalIsomorphism] ^= 
   z2Xz4Cat4Piv2PivotalIsomorphism
 
z2Xz4Cat4Piv2PivotalIsomorphism[0] = 1
 
z2Xz4Cat4Piv2PivotalIsomorphism[1] = 1
 
z2Xz4Cat4Piv2PivotalIsomorphism[2] = 1
 
z2Xz4Cat4Piv2PivotalIsomorphism[3] = 1
 
z2Xz4Cat4Piv2PivotalIsomorphism[4] = -1
 
z2Xz4Cat4Piv2PivotalIsomorphism[5] = -1
balancedCategories[z2Xz4Cat4Piv3] ^= {}
 
fusionCategory[z2Xz4Cat4Piv3] ^= z2Xz4Cat4
 
z2Xz4Cat4Piv3 /: modularCategory[z2Xz4Cat4Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat4Piv3] ^= z2Xz4Cat4Piv3
 
pivotalIsomorphism[z2Xz4Cat4Piv3] ^= z2Xz4Cat4Piv3PivotalIsomorphism
 
ring[z2Xz4Cat4Piv3] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat4Piv3] ^= z2Xz4Cat4Piv3
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat4]][pivotalCategory[#1]] & )[
    z2Xz4Cat4Piv3] ^= 3
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat4]][sphericalCategory[#1]] & )[
    z2Xz4Cat4Piv3] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat4Piv3PivotalIsomorphism] ^= z2Xz4Cat4
 
pivotalCategory[z2Xz4Cat4Piv3PivotalIsomorphism] ^= z2Xz4Cat4Piv3
 
pivotalIsomorphism[z2Xz4Cat4Piv3PivotalIsomorphism] ^= 
   z2Xz4Cat4Piv3PivotalIsomorphism
 
z2Xz4Cat4Piv3PivotalIsomorphism[0] = 1
 
z2Xz4Cat4Piv3PivotalIsomorphism[1] = -1
 
z2Xz4Cat4Piv3PivotalIsomorphism[2] = 1
 
z2Xz4Cat4Piv3PivotalIsomorphism[3] = -1
 
z2Xz4Cat4Piv3PivotalIsomorphism[4] = -1
 
z2Xz4Cat4Piv3PivotalIsomorphism[5] = 1
balancedCategories[z2Xz4Cat4Piv4] ^= {}
 
fusionCategory[z2Xz4Cat4Piv4] ^= z2Xz4Cat4
 
z2Xz4Cat4Piv4 /: modularCategory[z2Xz4Cat4Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat4Piv4] ^= z2Xz4Cat4Piv4
 
pivotalIsomorphism[z2Xz4Cat4Piv4] ^= z2Xz4Cat4Piv4PivotalIsomorphism
 
ring[z2Xz4Cat4Piv4] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat4Piv4] ^= z2Xz4Cat4Piv4
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat4]][pivotalCategory[#1]] & )[
    z2Xz4Cat4Piv4] ^= 4
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat4]][sphericalCategory[#1]] & )[
    z2Xz4Cat4Piv4] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat4Piv4PivotalIsomorphism] ^= z2Xz4Cat4
 
pivotalCategory[z2Xz4Cat4Piv4PivotalIsomorphism] ^= z2Xz4Cat4Piv4
 
pivotalIsomorphism[z2Xz4Cat4Piv4PivotalIsomorphism] ^= 
   z2Xz4Cat4Piv4PivotalIsomorphism
 
z2Xz4Cat4Piv4PivotalIsomorphism[0] = 1
 
z2Xz4Cat4Piv4PivotalIsomorphism[1] = -1
 
z2Xz4Cat4Piv4PivotalIsomorphism[2] = 1
 
z2Xz4Cat4Piv4PivotalIsomorphism[3] = -1
 
z2Xz4Cat4Piv4PivotalIsomorphism[4] = 1
 
z2Xz4Cat4Piv4PivotalIsomorphism[5] = -1
balancedCategories[z2Xz4Cat5] ^= {}
 
braidedCategories[z2Xz4Cat5] ^= {}
 
coeval[z2Xz4Cat5] ^= 1/sixJFunction[z2Xz4Cat5][#1, dual[ring[z2Xz4Cat5]][#1], 
      #1, #1, 0, 0] & 
 
eval[z2Xz4Cat5] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[z2Xz4Cat5] ^= z2Xz4Cat5FMatrixFunction
 
fusionCategory[z2Xz4Cat5] ^= z2Xz4Cat5
 
z2Xz4Cat5 /: modularCategory[z2Xz4Cat5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[z2Xz4Cat5] ^= {z2Xz4Cat5Piv1, z2Xz4Cat5Piv2, z2Xz4Cat5Piv3, 
    z2Xz4Cat5Piv4}
 
z2Xz4Cat5 /: pivotalCategory[z2Xz4Cat5, 1] = z2Xz4Cat5Piv1
 
z2Xz4Cat5 /: pivotalCategory[z2Xz4Cat5, 2] = z2Xz4Cat5Piv2
 
z2Xz4Cat5 /: pivotalCategory[z2Xz4Cat5, 3] = z2Xz4Cat5Piv3
 
z2Xz4Cat5 /: pivotalCategory[z2Xz4Cat5, 4] = z2Xz4Cat5Piv4
 
z2Xz4Cat5 /: pivotalCategory[z2Xz4Cat5, {1, -1, 1, -1, -1, -1}] = 
    z2Xz4Cat5Piv1
 
z2Xz4Cat5 /: pivotalCategory[z2Xz4Cat5, {1, -1, 1, -1, 1, 1}] = z2Xz4Cat5Piv4
 
z2Xz4Cat5 /: pivotalCategory[z2Xz4Cat5, {1, 1, 1, 1, -1, 1}] = z2Xz4Cat5Piv2
 
z2Xz4Cat5 /: pivotalCategory[z2Xz4Cat5, {1, 1, 1, 1, 1, -1}] = z2Xz4Cat5Piv3
 
ring[z2Xz4Cat5] ^= z2Xz4
 
z2Xz4Cat5 /: sphericalCategory[z2Xz4Cat5, 1] = z2Xz4Cat5Piv1
 
z2Xz4Cat5 /: sphericalCategory[z2Xz4Cat5, 2] = z2Xz4Cat5Piv2
 
z2Xz4Cat5 /: sphericalCategory[z2Xz4Cat5, 3] = z2Xz4Cat5Piv3
 
z2Xz4Cat5 /: sphericalCategory[z2Xz4Cat5, 4] = z2Xz4Cat5Piv4
 
fusionCategoryIndex[z2Xz4][z2Xz4Cat5] ^= 5
fMatrixFunction[z2Xz4Cat5FMatrixFunction] ^= z2Xz4Cat5FMatrixFunction
 
fusionCategory[z2Xz4Cat5FMatrixFunction] ^= z2Xz4Cat5
 
ring[z2Xz4Cat5FMatrixFunction] ^= z2Xz4
 
z2Xz4Cat5FMatrixFunction[1, 1, 1, 3] = {{I}}
 
z2Xz4Cat5FMatrixFunction[1, 1, 2, 0] = {{-I}}
 
z2Xz4Cat5FMatrixFunction[1, 1, 3, 1] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[1, 1, 5, 5] = {{-I}}
 
z2Xz4Cat5FMatrixFunction[1, 2, 1, 0] = {{-I}}
 
z2Xz4Cat5FMatrixFunction[1, 2, 2, 1] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[1, 2, 3, 2] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[1, 3, 1, 1] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[1, 3, 2, 2] = {{-I}}
 
z2Xz4Cat5FMatrixFunction[1, 3, 3, 3] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[1, 3, 4, 4] = {{-I}}
 
z2Xz4Cat5FMatrixFunction[1, 3, 5, 5] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[1, 4, 2, 5] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[1, 4, 3, 4] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[1, 4, 4, 1] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[1, 4, 4, 3] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[1, 4, 5, 0] = {{I}}
 
z2Xz4Cat5FMatrixFunction[1, 4, 5, 2] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[1, 5, 1, 5] = {{I}}
 
z2Xz4Cat5FMatrixFunction[1, 5, 3, 5] = {{I}}
 
z2Xz4Cat5FMatrixFunction[1, 5, 4, 0] = {{I}}
 
z2Xz4Cat5FMatrixFunction[1, 5, 5, 1] = {{-I}}
 
z2Xz4Cat5FMatrixFunction[1, 5, 5, 3] = {{I}}
 
z2Xz4Cat5FMatrixFunction[2, 1, 1, 0] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[2, 1, 3, 2] = {{I}}
 
z2Xz4Cat5FMatrixFunction[2, 1, 4, 5] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[2, 2, 3, 3] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[2, 2, 4, 4] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[2, 2, 5, 5] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[2, 3, 3, 0] = {{I}}
 
z2Xz4Cat5FMatrixFunction[2, 3, 4, 5] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[2, 4, 1, 5] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[2, 4, 2, 4] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[2, 4, 4, 2] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[2, 4, 5, 1] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[2, 4, 5, 3] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[2, 5, 2, 5] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[2, 5, 3, 4] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[2, 5, 5, 0] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[3, 1, 1, 1] = {{I}}
 
z2Xz4Cat5FMatrixFunction[3, 1, 3, 3] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[3, 1, 5, 5] = {{I}}
 
z2Xz4Cat5FMatrixFunction[3, 2, 1, 2] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[3, 2, 2, 3] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[3, 2, 3, 0] = {{I}}
 
z2Xz4Cat5FMatrixFunction[3, 3, 1, 3] = {{-I}}
 
z2Xz4Cat5FMatrixFunction[3, 3, 2, 0] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[3, 3, 3, 1] = {{-I}}
 
z2Xz4Cat5FMatrixFunction[3, 3, 5, 5] = {{I}}
 
z2Xz4Cat5FMatrixFunction[3, 4, 1, 4] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[3, 4, 3, 4] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[3, 4, 5, 2] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[3, 5, 1, 5] = {{I}}
 
z2Xz4Cat5FMatrixFunction[3, 5, 2, 4] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[3, 5, 3, 5] = {{-I}}
 
z2Xz4Cat5FMatrixFunction[3, 5, 4, 0] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[3, 5, 5, 1] = {{-I}}
 
z2Xz4Cat5FMatrixFunction[3, 5, 5, 3] = {{I}}
 
z2Xz4Cat5FMatrixFunction[4, 1, 1, 4] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[4, 1, 3, 4] = {{I}}
 
z2Xz4Cat5FMatrixFunction[4, 2, 1, 5] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[4, 2, 2, 4] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[4, 2, 3, 5] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[4, 2, 4, 0] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[4, 2, 5, 3] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[4, 3, 3, 4] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[4, 3, 4, 3] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[4, 3, 5, 2] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[4, 4, 1, 1] = {{I}}
 
z2Xz4Cat5FMatrixFunction[4, 4, 1, 3] = {{I}}
 
z2Xz4Cat5FMatrixFunction[4, 4, 2, 0] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[4, 4, 3, 1] = {{-I}}
 
z2Xz4Cat5FMatrixFunction[4, 4, 3, 3] = {{-I}}
 
z2Xz4Cat5FMatrixFunction[4, 4, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
z2Xz4Cat5FMatrixFunction[4, 4, 5, 5] = {{(-I)/Sqrt[2], (-I)/Sqrt[2]}, 
    {I/Sqrt[2], (-I)/Sqrt[2]}}
 
z2Xz4Cat5FMatrixFunction[4, 5, 1, 0] = {{I}}
 
z2Xz4Cat5FMatrixFunction[4, 5, 1, 2] = {{I}}
 
z2Xz4Cat5FMatrixFunction[4, 5, 2, 1] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[4, 5, 2, 3] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[4, 5, 3, 0] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[4, 5, 3, 2] = {{-I}}
 
z2Xz4Cat5FMatrixFunction[4, 5, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
z2Xz4Cat5FMatrixFunction[4, 5, 5, 4] = {{I/Sqrt[2], (-I)/Sqrt[2]}, 
    {I/Sqrt[2], I/Sqrt[2]}}
 
z2Xz4Cat5FMatrixFunction[5, 1, 1, 5] = {{I}}
 
z2Xz4Cat5FMatrixFunction[5, 1, 2, 4] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[5, 1, 3, 5] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[5, 1, 4, 2] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[5, 1, 5, 1] = {{I}}
 
z2Xz4Cat5FMatrixFunction[5, 1, 5, 3] = {{-I}}
 
z2Xz4Cat5FMatrixFunction[5, 2, 1, 4] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[5, 2, 2, 5] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[5, 2, 3, 4] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[5, 2, 4, 3] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[5, 2, 5, 2] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[5, 3, 1, 5] = {{-I}}
 
z2Xz4Cat5FMatrixFunction[5, 3, 2, 4] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[5, 3, 3, 5] = {{-I}}
 
z2Xz4Cat5FMatrixFunction[5, 3, 5, 1] = {{-I}}
 
z2Xz4Cat5FMatrixFunction[5, 3, 5, 3] = {{-I}}
 
z2Xz4Cat5FMatrixFunction[5, 4, 1, 0] = {{I}}
 
z2Xz4Cat5FMatrixFunction[5, 4, 1, 2] = {{I}}
 
z2Xz4Cat5FMatrixFunction[5, 4, 3, 2] = {{I}}
 
z2Xz4Cat5FMatrixFunction[5, 4, 4, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
z2Xz4Cat5FMatrixFunction[5, 4, 5, 4] = {{I/Sqrt[2], I/Sqrt[2]}, 
    {I/Sqrt[2], (-I)/Sqrt[2]}}
 
z2Xz4Cat5FMatrixFunction[5, 5, 1, 1] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[5, 5, 2, 0] = {{-1}}
 
z2Xz4Cat5FMatrixFunction[5, 5, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
z2Xz4Cat5FMatrixFunction[5, 5, 5, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
z2Xz4Cat5FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[z2Xz4Cat5], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
z2Xz4Cat5FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[z2Xz4Cat5], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[z2Xz4Cat5Piv1] ^= {}
 
fusionCategory[z2Xz4Cat5Piv1] ^= z2Xz4Cat5
 
z2Xz4Cat5Piv1 /: modularCategory[z2Xz4Cat5Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat5Piv1] ^= z2Xz4Cat5Piv1
 
pivotalIsomorphism[z2Xz4Cat5Piv1] ^= z2Xz4Cat5Piv1PivotalIsomorphism
 
ring[z2Xz4Cat5Piv1] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat5Piv1] ^= z2Xz4Cat5Piv1
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat5]][pivotalCategory[#1]] & )[
    z2Xz4Cat5Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat5]][sphericalCategory[#1]] & )[
    z2Xz4Cat5Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat5Piv1PivotalIsomorphism] ^= z2Xz4Cat5
 
pivotalCategory[z2Xz4Cat5Piv1PivotalIsomorphism] ^= z2Xz4Cat5Piv1
 
pivotalIsomorphism[z2Xz4Cat5Piv1PivotalIsomorphism] ^= 
   z2Xz4Cat5Piv1PivotalIsomorphism
 
z2Xz4Cat5Piv1PivotalIsomorphism[0] = 1
 
z2Xz4Cat5Piv1PivotalIsomorphism[1] = -1
 
z2Xz4Cat5Piv1PivotalIsomorphism[2] = 1
 
z2Xz4Cat5Piv1PivotalIsomorphism[3] = -1
 
z2Xz4Cat5Piv1PivotalIsomorphism[4] = -1
 
z2Xz4Cat5Piv1PivotalIsomorphism[5] = -1
balancedCategories[z2Xz4Cat5Piv2] ^= {}
 
fusionCategory[z2Xz4Cat5Piv2] ^= z2Xz4Cat5
 
z2Xz4Cat5Piv2 /: modularCategory[z2Xz4Cat5Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat5Piv2] ^= z2Xz4Cat5Piv2
 
pivotalIsomorphism[z2Xz4Cat5Piv2] ^= z2Xz4Cat5Piv2PivotalIsomorphism
 
ring[z2Xz4Cat5Piv2] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat5Piv2] ^= z2Xz4Cat5Piv2
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat5]][pivotalCategory[#1]] & )[
    z2Xz4Cat5Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat5]][sphericalCategory[#1]] & )[
    z2Xz4Cat5Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat5Piv2PivotalIsomorphism] ^= z2Xz4Cat5
 
pivotalCategory[z2Xz4Cat5Piv2PivotalIsomorphism] ^= z2Xz4Cat5Piv2
 
pivotalIsomorphism[z2Xz4Cat5Piv2PivotalIsomorphism] ^= 
   z2Xz4Cat5Piv2PivotalIsomorphism
 
z2Xz4Cat5Piv2PivotalIsomorphism[0] = 1
 
z2Xz4Cat5Piv2PivotalIsomorphism[1] = 1
 
z2Xz4Cat5Piv2PivotalIsomorphism[2] = 1
 
z2Xz4Cat5Piv2PivotalIsomorphism[3] = 1
 
z2Xz4Cat5Piv2PivotalIsomorphism[4] = -1
 
z2Xz4Cat5Piv2PivotalIsomorphism[5] = 1
balancedCategories[z2Xz4Cat5Piv3] ^= {}
 
fusionCategory[z2Xz4Cat5Piv3] ^= z2Xz4Cat5
 
z2Xz4Cat5Piv3 /: modularCategory[z2Xz4Cat5Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat5Piv3] ^= z2Xz4Cat5Piv3
 
pivotalIsomorphism[z2Xz4Cat5Piv3] ^= z2Xz4Cat5Piv3PivotalIsomorphism
 
ring[z2Xz4Cat5Piv3] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat5Piv3] ^= z2Xz4Cat5Piv3
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat5]][pivotalCategory[#1]] & )[
    z2Xz4Cat5Piv3] ^= 3
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat5]][sphericalCategory[#1]] & )[
    z2Xz4Cat5Piv3] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat5Piv3PivotalIsomorphism] ^= z2Xz4Cat5
 
pivotalCategory[z2Xz4Cat5Piv3PivotalIsomorphism] ^= z2Xz4Cat5Piv3
 
pivotalIsomorphism[z2Xz4Cat5Piv3PivotalIsomorphism] ^= 
   z2Xz4Cat5Piv3PivotalIsomorphism
 
z2Xz4Cat5Piv3PivotalIsomorphism[0] = 1
 
z2Xz4Cat5Piv3PivotalIsomorphism[1] = 1
 
z2Xz4Cat5Piv3PivotalIsomorphism[2] = 1
 
z2Xz4Cat5Piv3PivotalIsomorphism[3] = 1
 
z2Xz4Cat5Piv3PivotalIsomorphism[4] = 1
 
z2Xz4Cat5Piv3PivotalIsomorphism[5] = -1
balancedCategories[z2Xz4Cat5Piv4] ^= {}
 
fusionCategory[z2Xz4Cat5Piv4] ^= z2Xz4Cat5
 
z2Xz4Cat5Piv4 /: modularCategory[z2Xz4Cat5Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat5Piv4] ^= z2Xz4Cat5Piv4
 
pivotalIsomorphism[z2Xz4Cat5Piv4] ^= z2Xz4Cat5Piv4PivotalIsomorphism
 
ring[z2Xz4Cat5Piv4] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat5Piv4] ^= z2Xz4Cat5Piv4
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat5]][pivotalCategory[#1]] & )[
    z2Xz4Cat5Piv4] ^= 4
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat5]][sphericalCategory[#1]] & )[
    z2Xz4Cat5Piv4] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat5Piv4PivotalIsomorphism] ^= z2Xz4Cat5
 
pivotalCategory[z2Xz4Cat5Piv4PivotalIsomorphism] ^= z2Xz4Cat5Piv4
 
pivotalIsomorphism[z2Xz4Cat5Piv4PivotalIsomorphism] ^= 
   z2Xz4Cat5Piv4PivotalIsomorphism
 
z2Xz4Cat5Piv4PivotalIsomorphism[0] = 1
 
z2Xz4Cat5Piv4PivotalIsomorphism[1] = -1
 
z2Xz4Cat5Piv4PivotalIsomorphism[2] = 1
 
z2Xz4Cat5Piv4PivotalIsomorphism[3] = -1
 
z2Xz4Cat5Piv4PivotalIsomorphism[4] = 1
 
z2Xz4Cat5Piv4PivotalIsomorphism[5] = 1
balancedCategories[z2Xz4Cat6] ^= {}
 
braidedCategories[z2Xz4Cat6] ^= {}
 
coeval[z2Xz4Cat6] ^= 1/sixJFunction[z2Xz4Cat6][#1, dual[ring[z2Xz4Cat6]][#1], 
      #1, #1, 0, 0] & 
 
eval[z2Xz4Cat6] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[z2Xz4Cat6] ^= z2Xz4Cat6FMatrixFunction
 
fusionCategory[z2Xz4Cat6] ^= z2Xz4Cat6
 
z2Xz4Cat6 /: modularCategory[z2Xz4Cat6, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[z2Xz4Cat6] ^= {z2Xz4Cat6Piv1, z2Xz4Cat6Piv2, z2Xz4Cat6Piv3, 
    z2Xz4Cat6Piv4}
 
z2Xz4Cat6 /: pivotalCategory[z2Xz4Cat6, 1] = z2Xz4Cat6Piv1
 
z2Xz4Cat6 /: pivotalCategory[z2Xz4Cat6, 2] = z2Xz4Cat6Piv2
 
z2Xz4Cat6 /: pivotalCategory[z2Xz4Cat6, 3] = z2Xz4Cat6Piv3
 
z2Xz4Cat6 /: pivotalCategory[z2Xz4Cat6, 4] = z2Xz4Cat6Piv4
 
z2Xz4Cat6 /: pivotalCategory[z2Xz4Cat6, {1, -1, 1, -1, -1, -1}] = 
    z2Xz4Cat6Piv1
 
z2Xz4Cat6 /: pivotalCategory[z2Xz4Cat6, {1, -1, 1, -1, 1, 1}] = z2Xz4Cat6Piv4
 
z2Xz4Cat6 /: pivotalCategory[z2Xz4Cat6, {1, 1, 1, 1, -1, 1}] = z2Xz4Cat6Piv2
 
z2Xz4Cat6 /: pivotalCategory[z2Xz4Cat6, {1, 1, 1, 1, 1, -1}] = z2Xz4Cat6Piv3
 
ring[z2Xz4Cat6] ^= z2Xz4
 
z2Xz4Cat6 /: sphericalCategory[z2Xz4Cat6, 1] = z2Xz4Cat6Piv1
 
z2Xz4Cat6 /: sphericalCategory[z2Xz4Cat6, 2] = z2Xz4Cat6Piv2
 
z2Xz4Cat6 /: sphericalCategory[z2Xz4Cat6, 3] = z2Xz4Cat6Piv3
 
z2Xz4Cat6 /: sphericalCategory[z2Xz4Cat6, 4] = z2Xz4Cat6Piv4
 
fusionCategoryIndex[z2Xz4][z2Xz4Cat6] ^= 6
fMatrixFunction[z2Xz4Cat6FMatrixFunction] ^= z2Xz4Cat6FMatrixFunction
 
fusionCategory[z2Xz4Cat6FMatrixFunction] ^= z2Xz4Cat6
 
ring[z2Xz4Cat6FMatrixFunction] ^= z2Xz4
 
z2Xz4Cat6FMatrixFunction[1, 1, 1, 3] = {{I}}
 
z2Xz4Cat6FMatrixFunction[1, 1, 2, 0] = {{-I}}
 
z2Xz4Cat6FMatrixFunction[1, 1, 3, 1] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[1, 1, 5, 5] = {{-I}}
 
z2Xz4Cat6FMatrixFunction[1, 2, 1, 0] = {{-I}}
 
z2Xz4Cat6FMatrixFunction[1, 2, 2, 1] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[1, 2, 3, 2] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[1, 3, 1, 1] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[1, 3, 2, 2] = {{-I}}
 
z2Xz4Cat6FMatrixFunction[1, 3, 3, 3] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[1, 3, 4, 4] = {{-I}}
 
z2Xz4Cat6FMatrixFunction[1, 3, 5, 5] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[1, 4, 2, 5] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[1, 4, 3, 4] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[1, 4, 4, 1] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[1, 4, 4, 3] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[1, 4, 5, 0] = {{I}}
 
z2Xz4Cat6FMatrixFunction[1, 4, 5, 2] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[1, 5, 1, 5] = {{I}}
 
z2Xz4Cat6FMatrixFunction[1, 5, 3, 5] = {{I}}
 
z2Xz4Cat6FMatrixFunction[1, 5, 4, 0] = {{I}}
 
z2Xz4Cat6FMatrixFunction[1, 5, 5, 1] = {{-I}}
 
z2Xz4Cat6FMatrixFunction[1, 5, 5, 3] = {{I}}
 
z2Xz4Cat6FMatrixFunction[2, 1, 1, 0] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[2, 1, 3, 2] = {{I}}
 
z2Xz4Cat6FMatrixFunction[2, 1, 4, 5] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[2, 2, 3, 3] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[2, 2, 4, 4] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[2, 2, 5, 5] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[2, 3, 3, 0] = {{I}}
 
z2Xz4Cat6FMatrixFunction[2, 3, 4, 5] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[2, 4, 1, 5] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[2, 4, 2, 4] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[2, 4, 4, 2] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[2, 4, 5, 1] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[2, 4, 5, 3] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[2, 5, 2, 5] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[2, 5, 3, 4] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[2, 5, 5, 0] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[3, 1, 1, 1] = {{I}}
 
z2Xz4Cat6FMatrixFunction[3, 1, 3, 3] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[3, 1, 5, 5] = {{I}}
 
z2Xz4Cat6FMatrixFunction[3, 2, 1, 2] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[3, 2, 2, 3] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[3, 2, 3, 0] = {{I}}
 
z2Xz4Cat6FMatrixFunction[3, 3, 1, 3] = {{-I}}
 
z2Xz4Cat6FMatrixFunction[3, 3, 2, 0] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[3, 3, 3, 1] = {{-I}}
 
z2Xz4Cat6FMatrixFunction[3, 3, 5, 5] = {{I}}
 
z2Xz4Cat6FMatrixFunction[3, 4, 1, 4] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[3, 4, 3, 4] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[3, 4, 5, 2] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[3, 5, 1, 5] = {{I}}
 
z2Xz4Cat6FMatrixFunction[3, 5, 2, 4] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[3, 5, 3, 5] = {{-I}}
 
z2Xz4Cat6FMatrixFunction[3, 5, 4, 0] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[3, 5, 5, 1] = {{-I}}
 
z2Xz4Cat6FMatrixFunction[3, 5, 5, 3] = {{I}}
 
z2Xz4Cat6FMatrixFunction[4, 1, 1, 4] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[4, 1, 3, 4] = {{I}}
 
z2Xz4Cat6FMatrixFunction[4, 2, 1, 5] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[4, 2, 2, 4] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[4, 2, 3, 5] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[4, 2, 4, 0] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[4, 2, 5, 3] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[4, 3, 3, 4] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[4, 3, 4, 3] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[4, 3, 5, 2] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[4, 4, 1, 1] = {{I}}
 
z2Xz4Cat6FMatrixFunction[4, 4, 1, 3] = {{I}}
 
z2Xz4Cat6FMatrixFunction[4, 4, 2, 0] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[4, 4, 3, 1] = {{-I}}
 
z2Xz4Cat6FMatrixFunction[4, 4, 3, 3] = {{-I}}
 
z2Xz4Cat6FMatrixFunction[4, 4, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
z2Xz4Cat6FMatrixFunction[4, 4, 5, 5] = {{I/Sqrt[2], I/Sqrt[2]}, 
    {(-I)/Sqrt[2], I/Sqrt[2]}}
 
z2Xz4Cat6FMatrixFunction[4, 5, 1, 0] = {{I}}
 
z2Xz4Cat6FMatrixFunction[4, 5, 1, 2] = {{I}}
 
z2Xz4Cat6FMatrixFunction[4, 5, 2, 1] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[4, 5, 2, 3] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[4, 5, 3, 0] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[4, 5, 3, 2] = {{-I}}
 
z2Xz4Cat6FMatrixFunction[4, 5, 4, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
z2Xz4Cat6FMatrixFunction[4, 5, 5, 4] = {{(-I)/Sqrt[2], I/Sqrt[2]}, 
    {(-I)/Sqrt[2], (-I)/Sqrt[2]}}
 
z2Xz4Cat6FMatrixFunction[5, 1, 1, 5] = {{I}}
 
z2Xz4Cat6FMatrixFunction[5, 1, 2, 4] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[5, 1, 3, 5] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[5, 1, 4, 2] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[5, 1, 5, 1] = {{I}}
 
z2Xz4Cat6FMatrixFunction[5, 1, 5, 3] = {{-I}}
 
z2Xz4Cat6FMatrixFunction[5, 2, 1, 4] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[5, 2, 2, 5] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[5, 2, 3, 4] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[5, 2, 4, 3] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[5, 2, 5, 2] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[5, 3, 1, 5] = {{-I}}
 
z2Xz4Cat6FMatrixFunction[5, 3, 2, 4] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[5, 3, 3, 5] = {{-I}}
 
z2Xz4Cat6FMatrixFunction[5, 3, 5, 1] = {{-I}}
 
z2Xz4Cat6FMatrixFunction[5, 3, 5, 3] = {{-I}}
 
z2Xz4Cat6FMatrixFunction[5, 4, 1, 0] = {{I}}
 
z2Xz4Cat6FMatrixFunction[5, 4, 1, 2] = {{I}}
 
z2Xz4Cat6FMatrixFunction[5, 4, 3, 2] = {{I}}
 
z2Xz4Cat6FMatrixFunction[5, 4, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
z2Xz4Cat6FMatrixFunction[5, 4, 5, 4] = {{(-I)/Sqrt[2], (-I)/Sqrt[2]}, 
    {(-I)/Sqrt[2], I/Sqrt[2]}}
 
z2Xz4Cat6FMatrixFunction[5, 5, 1, 1] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[5, 5, 2, 0] = {{-1}}
 
z2Xz4Cat6FMatrixFunction[5, 5, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
z2Xz4Cat6FMatrixFunction[5, 5, 5, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
z2Xz4Cat6FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[z2Xz4Cat6], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
z2Xz4Cat6FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[z2Xz4Cat6], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[z2Xz4Cat6Piv1] ^= {}
 
fusionCategory[z2Xz4Cat6Piv1] ^= z2Xz4Cat6
 
z2Xz4Cat6Piv1 /: modularCategory[z2Xz4Cat6Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat6Piv1] ^= z2Xz4Cat6Piv1
 
pivotalIsomorphism[z2Xz4Cat6Piv1] ^= z2Xz4Cat6Piv1PivotalIsomorphism
 
ring[z2Xz4Cat6Piv1] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat6Piv1] ^= z2Xz4Cat6Piv1
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat6]][pivotalCategory[#1]] & )[
    z2Xz4Cat6Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat6]][sphericalCategory[#1]] & )[
    z2Xz4Cat6Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat6Piv1PivotalIsomorphism] ^= z2Xz4Cat6
 
pivotalCategory[z2Xz4Cat6Piv1PivotalIsomorphism] ^= z2Xz4Cat6Piv1
 
pivotalIsomorphism[z2Xz4Cat6Piv1PivotalIsomorphism] ^= 
   z2Xz4Cat6Piv1PivotalIsomorphism
 
z2Xz4Cat6Piv1PivotalIsomorphism[0] = 1
 
z2Xz4Cat6Piv1PivotalIsomorphism[1] = -1
 
z2Xz4Cat6Piv1PivotalIsomorphism[2] = 1
 
z2Xz4Cat6Piv1PivotalIsomorphism[3] = -1
 
z2Xz4Cat6Piv1PivotalIsomorphism[4] = -1
 
z2Xz4Cat6Piv1PivotalIsomorphism[5] = -1
balancedCategories[z2Xz4Cat6Piv2] ^= {}
 
fusionCategory[z2Xz4Cat6Piv2] ^= z2Xz4Cat6
 
z2Xz4Cat6Piv2 /: modularCategory[z2Xz4Cat6Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat6Piv2] ^= z2Xz4Cat6Piv2
 
pivotalIsomorphism[z2Xz4Cat6Piv2] ^= z2Xz4Cat6Piv2PivotalIsomorphism
 
ring[z2Xz4Cat6Piv2] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat6Piv2] ^= z2Xz4Cat6Piv2
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat6]][pivotalCategory[#1]] & )[
    z2Xz4Cat6Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat6]][sphericalCategory[#1]] & )[
    z2Xz4Cat6Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat6Piv2PivotalIsomorphism] ^= z2Xz4Cat6
 
pivotalCategory[z2Xz4Cat6Piv2PivotalIsomorphism] ^= z2Xz4Cat6Piv2
 
pivotalIsomorphism[z2Xz4Cat6Piv2PivotalIsomorphism] ^= 
   z2Xz4Cat6Piv2PivotalIsomorphism
 
z2Xz4Cat6Piv2PivotalIsomorphism[0] = 1
 
z2Xz4Cat6Piv2PivotalIsomorphism[1] = 1
 
z2Xz4Cat6Piv2PivotalIsomorphism[2] = 1
 
z2Xz4Cat6Piv2PivotalIsomorphism[3] = 1
 
z2Xz4Cat6Piv2PivotalIsomorphism[4] = -1
 
z2Xz4Cat6Piv2PivotalIsomorphism[5] = 1
balancedCategories[z2Xz4Cat6Piv3] ^= {}
 
fusionCategory[z2Xz4Cat6Piv3] ^= z2Xz4Cat6
 
z2Xz4Cat6Piv3 /: modularCategory[z2Xz4Cat6Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat6Piv3] ^= z2Xz4Cat6Piv3
 
pivotalIsomorphism[z2Xz4Cat6Piv3] ^= z2Xz4Cat6Piv3PivotalIsomorphism
 
ring[z2Xz4Cat6Piv3] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat6Piv3] ^= z2Xz4Cat6Piv3
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat6]][pivotalCategory[#1]] & )[
    z2Xz4Cat6Piv3] ^= 3
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat6]][sphericalCategory[#1]] & )[
    z2Xz4Cat6Piv3] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat6Piv3PivotalIsomorphism] ^= z2Xz4Cat6
 
pivotalCategory[z2Xz4Cat6Piv3PivotalIsomorphism] ^= z2Xz4Cat6Piv3
 
pivotalIsomorphism[z2Xz4Cat6Piv3PivotalIsomorphism] ^= 
   z2Xz4Cat6Piv3PivotalIsomorphism
 
z2Xz4Cat6Piv3PivotalIsomorphism[0] = 1
 
z2Xz4Cat6Piv3PivotalIsomorphism[1] = 1
 
z2Xz4Cat6Piv3PivotalIsomorphism[2] = 1
 
z2Xz4Cat6Piv3PivotalIsomorphism[3] = 1
 
z2Xz4Cat6Piv3PivotalIsomorphism[4] = 1
 
z2Xz4Cat6Piv3PivotalIsomorphism[5] = -1
balancedCategories[z2Xz4Cat6Piv4] ^= {}
 
fusionCategory[z2Xz4Cat6Piv4] ^= z2Xz4Cat6
 
z2Xz4Cat6Piv4 /: modularCategory[z2Xz4Cat6Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[z2Xz4Cat6Piv4] ^= z2Xz4Cat6Piv4
 
pivotalIsomorphism[z2Xz4Cat6Piv4] ^= z2Xz4Cat6Piv4PivotalIsomorphism
 
ring[z2Xz4Cat6Piv4] ^= z2Xz4
 
sphericalCategory[z2Xz4Cat6Piv4] ^= z2Xz4Cat6Piv4
 
(pivotalCategoryIndex[fusionCategory[z2Xz4Cat6]][pivotalCategory[#1]] & )[
    z2Xz4Cat6Piv4] ^= 4
 
(sphericalCategoryIndex[fusionCategory[z2Xz4Cat6]][sphericalCategory[#1]] & )[
    z2Xz4Cat6Piv4] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[z2Xz4Cat6Piv4PivotalIsomorphism] ^= z2Xz4Cat6
 
pivotalCategory[z2Xz4Cat6Piv4PivotalIsomorphism] ^= z2Xz4Cat6Piv4
 
pivotalIsomorphism[z2Xz4Cat6Piv4PivotalIsomorphism] ^= 
   z2Xz4Cat6Piv4PivotalIsomorphism
 
z2Xz4Cat6Piv4PivotalIsomorphism[0] = 1
 
z2Xz4Cat6Piv4PivotalIsomorphism[1] = -1
 
z2Xz4Cat6Piv4PivotalIsomorphism[2] = 1
 
z2Xz4Cat6Piv4PivotalIsomorphism[3] = -1
 
z2Xz4Cat6Piv4PivotalIsomorphism[4] = 1
 
z2Xz4Cat6Piv4PivotalIsomorphism[5] = 1
ring[z2Xz4NFunction] ^= z2Xz4
 
z2Xz4NFunction[0, 0, 0] = 1
 
z2Xz4NFunction[0, 0, 1] = 0
 
z2Xz4NFunction[0, 0, 2] = 0
 
z2Xz4NFunction[0, 0, 3] = 0
 
z2Xz4NFunction[0, 0, 4] = 0
 
z2Xz4NFunction[0, 0, 5] = 0
 
z2Xz4NFunction[0, 1, 0] = 0
 
z2Xz4NFunction[0, 1, 1] = 1
 
z2Xz4NFunction[0, 1, 2] = 0
 
z2Xz4NFunction[0, 1, 3] = 0
 
z2Xz4NFunction[0, 1, 4] = 0
 
z2Xz4NFunction[0, 1, 5] = 0
 
z2Xz4NFunction[0, 2, 0] = 0
 
z2Xz4NFunction[0, 2, 1] = 0
 
z2Xz4NFunction[0, 2, 2] = 1
 
z2Xz4NFunction[0, 2, 3] = 0
 
z2Xz4NFunction[0, 2, 4] = 0
 
z2Xz4NFunction[0, 2, 5] = 0
 
z2Xz4NFunction[0, 3, 0] = 0
 
z2Xz4NFunction[0, 3, 1] = 0
 
z2Xz4NFunction[0, 3, 2] = 0
 
z2Xz4NFunction[0, 3, 3] = 1
 
z2Xz4NFunction[0, 3, 4] = 0
 
z2Xz4NFunction[0, 3, 5] = 0
 
z2Xz4NFunction[0, 4, 0] = 0
 
z2Xz4NFunction[0, 4, 1] = 0
 
z2Xz4NFunction[0, 4, 2] = 0
 
z2Xz4NFunction[0, 4, 3] = 0
 
z2Xz4NFunction[0, 4, 4] = 1
 
z2Xz4NFunction[0, 4, 5] = 0
 
z2Xz4NFunction[0, 5, 0] = 0
 
z2Xz4NFunction[0, 5, 1] = 0
 
z2Xz4NFunction[0, 5, 2] = 0
 
z2Xz4NFunction[0, 5, 3] = 0
 
z2Xz4NFunction[0, 5, 4] = 0
 
z2Xz4NFunction[0, 5, 5] = 1
 
z2Xz4NFunction[1, 0, 0] = 0
 
z2Xz4NFunction[1, 0, 1] = 1
 
z2Xz4NFunction[1, 0, 2] = 0
 
z2Xz4NFunction[1, 0, 3] = 0
 
z2Xz4NFunction[1, 0, 4] = 0
 
z2Xz4NFunction[1, 0, 5] = 0
 
z2Xz4NFunction[1, 1, 0] = 0
 
z2Xz4NFunction[1, 1, 1] = 0
 
z2Xz4NFunction[1, 1, 2] = 1
 
z2Xz4NFunction[1, 1, 3] = 0
 
z2Xz4NFunction[1, 1, 4] = 0
 
z2Xz4NFunction[1, 1, 5] = 0
 
z2Xz4NFunction[1, 2, 0] = 0
 
z2Xz4NFunction[1, 2, 1] = 0
 
z2Xz4NFunction[1, 2, 2] = 0
 
z2Xz4NFunction[1, 2, 3] = 1
 
z2Xz4NFunction[1, 2, 4] = 0
 
z2Xz4NFunction[1, 2, 5] = 0
 
z2Xz4NFunction[1, 3, 0] = 1
 
z2Xz4NFunction[1, 3, 1] = 0
 
z2Xz4NFunction[1, 3, 2] = 0
 
z2Xz4NFunction[1, 3, 3] = 0
 
z2Xz4NFunction[1, 3, 4] = 0
 
z2Xz4NFunction[1, 3, 5] = 0
 
z2Xz4NFunction[1, 4, 0] = 0
 
z2Xz4NFunction[1, 4, 1] = 0
 
z2Xz4NFunction[1, 4, 2] = 0
 
z2Xz4NFunction[1, 4, 3] = 0
 
z2Xz4NFunction[1, 4, 4] = 0
 
z2Xz4NFunction[1, 4, 5] = 1
 
z2Xz4NFunction[1, 5, 0] = 0
 
z2Xz4NFunction[1, 5, 1] = 0
 
z2Xz4NFunction[1, 5, 2] = 0
 
z2Xz4NFunction[1, 5, 3] = 0
 
z2Xz4NFunction[1, 5, 4] = 1
 
z2Xz4NFunction[1, 5, 5] = 0
 
z2Xz4NFunction[2, 0, 0] = 0
 
z2Xz4NFunction[2, 0, 1] = 0
 
z2Xz4NFunction[2, 0, 2] = 1
 
z2Xz4NFunction[2, 0, 3] = 0
 
z2Xz4NFunction[2, 0, 4] = 0
 
z2Xz4NFunction[2, 0, 5] = 0
 
z2Xz4NFunction[2, 1, 0] = 0
 
z2Xz4NFunction[2, 1, 1] = 0
 
z2Xz4NFunction[2, 1, 2] = 0
 
z2Xz4NFunction[2, 1, 3] = 1
 
z2Xz4NFunction[2, 1, 4] = 0
 
z2Xz4NFunction[2, 1, 5] = 0
 
z2Xz4NFunction[2, 2, 0] = 1
 
z2Xz4NFunction[2, 2, 1] = 0
 
z2Xz4NFunction[2, 2, 2] = 0
 
z2Xz4NFunction[2, 2, 3] = 0
 
z2Xz4NFunction[2, 2, 4] = 0
 
z2Xz4NFunction[2, 2, 5] = 0
 
z2Xz4NFunction[2, 3, 0] = 0
 
z2Xz4NFunction[2, 3, 1] = 1
 
z2Xz4NFunction[2, 3, 2] = 0
 
z2Xz4NFunction[2, 3, 3] = 0
 
z2Xz4NFunction[2, 3, 4] = 0
 
z2Xz4NFunction[2, 3, 5] = 0
 
z2Xz4NFunction[2, 4, 0] = 0
 
z2Xz4NFunction[2, 4, 1] = 0
 
z2Xz4NFunction[2, 4, 2] = 0
 
z2Xz4NFunction[2, 4, 3] = 0
 
z2Xz4NFunction[2, 4, 4] = 1
 
z2Xz4NFunction[2, 4, 5] = 0
 
z2Xz4NFunction[2, 5, 0] = 0
 
z2Xz4NFunction[2, 5, 1] = 0
 
z2Xz4NFunction[2, 5, 2] = 0
 
z2Xz4NFunction[2, 5, 3] = 0
 
z2Xz4NFunction[2, 5, 4] = 0
 
z2Xz4NFunction[2, 5, 5] = 1
 
z2Xz4NFunction[3, 0, 0] = 0
 
z2Xz4NFunction[3, 0, 1] = 0
 
z2Xz4NFunction[3, 0, 2] = 0
 
z2Xz4NFunction[3, 0, 3] = 1
 
z2Xz4NFunction[3, 0, 4] = 0
 
z2Xz4NFunction[3, 0, 5] = 0
 
z2Xz4NFunction[3, 1, 0] = 1
 
z2Xz4NFunction[3, 1, 1] = 0
 
z2Xz4NFunction[3, 1, 2] = 0
 
z2Xz4NFunction[3, 1, 3] = 0
 
z2Xz4NFunction[3, 1, 4] = 0
 
z2Xz4NFunction[3, 1, 5] = 0
 
z2Xz4NFunction[3, 2, 0] = 0
 
z2Xz4NFunction[3, 2, 1] = 1
 
z2Xz4NFunction[3, 2, 2] = 0
 
z2Xz4NFunction[3, 2, 3] = 0
 
z2Xz4NFunction[3, 2, 4] = 0
 
z2Xz4NFunction[3, 2, 5] = 0
 
z2Xz4NFunction[3, 3, 0] = 0
 
z2Xz4NFunction[3, 3, 1] = 0
 
z2Xz4NFunction[3, 3, 2] = 1
 
z2Xz4NFunction[3, 3, 3] = 0
 
z2Xz4NFunction[3, 3, 4] = 0
 
z2Xz4NFunction[3, 3, 5] = 0
 
z2Xz4NFunction[3, 4, 0] = 0
 
z2Xz4NFunction[3, 4, 1] = 0
 
z2Xz4NFunction[3, 4, 2] = 0
 
z2Xz4NFunction[3, 4, 3] = 0
 
z2Xz4NFunction[3, 4, 4] = 0
 
z2Xz4NFunction[3, 4, 5] = 1
 
z2Xz4NFunction[3, 5, 0] = 0
 
z2Xz4NFunction[3, 5, 1] = 0
 
z2Xz4NFunction[3, 5, 2] = 0
 
z2Xz4NFunction[3, 5, 3] = 0
 
z2Xz4NFunction[3, 5, 4] = 1
 
z2Xz4NFunction[3, 5, 5] = 0
 
z2Xz4NFunction[4, 0, 0] = 0
 
z2Xz4NFunction[4, 0, 1] = 0
 
z2Xz4NFunction[4, 0, 2] = 0
 
z2Xz4NFunction[4, 0, 3] = 0
 
z2Xz4NFunction[4, 0, 4] = 1
 
z2Xz4NFunction[4, 0, 5] = 0
 
z2Xz4NFunction[4, 1, 0] = 0
 
z2Xz4NFunction[4, 1, 1] = 0
 
z2Xz4NFunction[4, 1, 2] = 0
 
z2Xz4NFunction[4, 1, 3] = 0
 
z2Xz4NFunction[4, 1, 4] = 0
 
z2Xz4NFunction[4, 1, 5] = 1
 
z2Xz4NFunction[4, 2, 0] = 0
 
z2Xz4NFunction[4, 2, 1] = 0
 
z2Xz4NFunction[4, 2, 2] = 0
 
z2Xz4NFunction[4, 2, 3] = 0
 
z2Xz4NFunction[4, 2, 4] = 1
 
z2Xz4NFunction[4, 2, 5] = 0
 
z2Xz4NFunction[4, 3, 0] = 0
 
z2Xz4NFunction[4, 3, 1] = 0
 
z2Xz4NFunction[4, 3, 2] = 0
 
z2Xz4NFunction[4, 3, 3] = 0
 
z2Xz4NFunction[4, 3, 4] = 0
 
z2Xz4NFunction[4, 3, 5] = 1
 
z2Xz4NFunction[4, 4, 0] = 1
 
z2Xz4NFunction[4, 4, 1] = 0
 
z2Xz4NFunction[4, 4, 2] = 1
 
z2Xz4NFunction[4, 4, 3] = 0
 
z2Xz4NFunction[4, 4, 4] = 0
 
z2Xz4NFunction[4, 4, 5] = 0
 
z2Xz4NFunction[4, 5, 0] = 0
 
z2Xz4NFunction[4, 5, 1] = 1
 
z2Xz4NFunction[4, 5, 2] = 0
 
z2Xz4NFunction[4, 5, 3] = 1
 
z2Xz4NFunction[4, 5, 4] = 0
 
z2Xz4NFunction[4, 5, 5] = 0
 
z2Xz4NFunction[5, 0, 0] = 0
 
z2Xz4NFunction[5, 0, 1] = 0
 
z2Xz4NFunction[5, 0, 2] = 0
 
z2Xz4NFunction[5, 0, 3] = 0
 
z2Xz4NFunction[5, 0, 4] = 0
 
z2Xz4NFunction[5, 0, 5] = 1
 
z2Xz4NFunction[5, 1, 0] = 0
 
z2Xz4NFunction[5, 1, 1] = 0
 
z2Xz4NFunction[5, 1, 2] = 0
 
z2Xz4NFunction[5, 1, 3] = 0
 
z2Xz4NFunction[5, 1, 4] = 1
 
z2Xz4NFunction[5, 1, 5] = 0
 
z2Xz4NFunction[5, 2, 0] = 0
 
z2Xz4NFunction[5, 2, 1] = 0
 
z2Xz4NFunction[5, 2, 2] = 0
 
z2Xz4NFunction[5, 2, 3] = 0
 
z2Xz4NFunction[5, 2, 4] = 0
 
z2Xz4NFunction[5, 2, 5] = 1
 
z2Xz4NFunction[5, 3, 0] = 0
 
z2Xz4NFunction[5, 3, 1] = 0
 
z2Xz4NFunction[5, 3, 2] = 0
 
z2Xz4NFunction[5, 3, 3] = 0
 
z2Xz4NFunction[5, 3, 4] = 1
 
z2Xz4NFunction[5, 3, 5] = 0
 
z2Xz4NFunction[5, 4, 0] = 0
 
z2Xz4NFunction[5, 4, 1] = 1
 
z2Xz4NFunction[5, 4, 2] = 0
 
z2Xz4NFunction[5, 4, 3] = 1
 
z2Xz4NFunction[5, 4, 4] = 0
 
z2Xz4NFunction[5, 4, 5] = 0
 
z2Xz4NFunction[5, 5, 0] = 1
 
z2Xz4NFunction[5, 5, 1] = 0
 
z2Xz4NFunction[5, 5, 2] = 1
 
z2Xz4NFunction[5, 5, 3] = 0
 
z2Xz4NFunction[5, 5, 4] = 0
 
z2Xz4NFunction[5, 5, 5] = 0
 
z2Xz4NFunction[a_, b_, c_] := 0


 EndPackage[]