BeginPackage["FusionCategories`Data`repDOdd7`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[repDOdd7] ^= {repDOdd7Cat1, repDOdd7Cat2, repDOdd7Cat3}
 
repDOdd7 /: fusionCategory[repDOdd7, 1] = repDOdd7Cat1
 
repDOdd7 /: fusionCategory[repDOdd7, 2] = repDOdd7Cat2
 
repDOdd7 /: fusionCategory[repDOdd7, 3] = repDOdd7Cat3
 
nFunction[repDOdd7] ^= repDOdd7NFunction
 
noMultiplicities[repDOdd7] ^= True
 
rank[repDOdd7] ^= 5
 
ring[repDOdd7] ^= repDOdd7
balancedCategories[repDOdd7Cat1] ^= {repDOdd7Cat1Bal1, repDOdd7Cat1Bal2, 
    repDOdd7Cat1Bal3}
 
repDOdd7Cat1 /: balancedCategory[repDOdd7Cat1, 1] = repDOdd7Cat1Bal1
 
repDOdd7Cat1 /: balancedCategory[repDOdd7Cat1, 2] = repDOdd7Cat1Bal2
 
repDOdd7Cat1 /: balancedCategory[repDOdd7Cat1, 3] = repDOdd7Cat1Bal3
 
braidedCategories[repDOdd7Cat1] ^= {repDOdd7Cat1Brd1, repDOdd7Cat1Brd2, 
    repDOdd7Cat1Brd3}
 
repDOdd7Cat1 /: braidedCategory[repDOdd7Cat1, 1] = repDOdd7Cat1Brd1
 
repDOdd7Cat1 /: braidedCategory[repDOdd7Cat1, 2] = repDOdd7Cat1Brd2
 
repDOdd7Cat1 /: braidedCategory[repDOdd7Cat1, 3] = repDOdd7Cat1Brd3
 
coeval[repDOdd7Cat1] ^= 1/sixJFunction[repDOdd7Cat1][#1, 
      dual[ring[repDOdd7Cat1]][#1], #1, #1, 0, 0] & 
 
eval[repDOdd7Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[repDOdd7Cat1] ^= repDOdd7Cat1FMatrixFunction
 
fusionCategory[repDOdd7Cat1] ^= repDOdd7Cat1
 
repDOdd7Cat1 /: modularCategory[repDOdd7Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[repDOdd7Cat1] ^= {repDOdd7Cat1Piv1}
 
repDOdd7Cat1 /: pivotalCategory[repDOdd7Cat1, 1] = repDOdd7Cat1Piv1
 
repDOdd7Cat1 /: pivotalCategory[repDOdd7Cat1, {1, 1, 1, 1, 1}] = 
    repDOdd7Cat1Piv1
 
repDOdd7Cat1 /: ribbonCategory[repDOdd7Cat1, 1] = repDOdd7Cat1Bal1
 
repDOdd7Cat1 /: ribbonCategory[repDOdd7Cat1, 2] = repDOdd7Cat1Bal2
 
repDOdd7Cat1 /: ribbonCategory[repDOdd7Cat1, 3] = repDOdd7Cat1Bal3
 
ring[repDOdd7Cat1] ^= repDOdd7
 
repDOdd7Cat1 /: sphericalCategory[repDOdd7Cat1, 1] = repDOdd7Cat1Piv1
 
repDOdd7Cat1 /: symmetricCategory[repDOdd7Cat1, 1] = repDOdd7Cat1Brd1
 
fusionCategoryIndex[repDOdd7][repDOdd7Cat1] ^= 1
balancedCategory[repDOdd7Cat1Bal1] ^= repDOdd7Cat1Bal1
 
braidedCategory[repDOdd7Cat1Bal1] ^= repDOdd7Cat1Brd1
 
fusionCategory[repDOdd7Cat1Bal1] ^= repDOdd7Cat1
 
pivotalCategory[repDOdd7Cat1Bal1] ^= repDOdd7Cat1Piv1
 
ribbonCategory[repDOdd7Cat1Bal1] ^= repDOdd7Cat1Bal1
 
ring[repDOdd7Cat1Bal1] ^= repDOdd7
 
sphericalCategory[repDOdd7Cat1Bal1] ^= repDOdd7Cat1Piv1
 
symmetricCategory[repDOdd7Cat1Bal1] ^= repDOdd7Cat1Brd1
 
(balancedCategoryIndex[braidedCategory[repDOdd7Cat1Brd1]][
      balancedCategory[#1]] & )[repDOdd7Cat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[repDOdd7Cat1]][
      balancedCategory[#1]] & )[repDOdd7Cat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[repDOdd7Cat1Piv1]][
      balancedCategory[#1]] & )[repDOdd7Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[repDOdd7Cat1Brd1]][
      ribbonCategory[#1]] & )[repDOdd7Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repDOdd7Cat1]][ribbonCategory[#1]] & )[
    repDOdd7Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[repDOdd7Cat1Piv1]][
      ribbonCategory[#1]] & )[repDOdd7Cat1Bal1] ^= 1
balancedCategory[repDOdd7Cat1Bal2] ^= repDOdd7Cat1Bal2
 
braidedCategory[repDOdd7Cat1Bal2] ^= repDOdd7Cat1Brd2
 
fusionCategory[repDOdd7Cat1Bal2] ^= repDOdd7Cat1
 
pivotalCategory[repDOdd7Cat1Bal2] ^= repDOdd7Cat1Piv1
 
ribbonCategory[repDOdd7Cat1Bal2] ^= repDOdd7Cat1Bal2
 
ring[repDOdd7Cat1Bal2] ^= repDOdd7
 
sphericalCategory[repDOdd7Cat1Bal2] ^= repDOdd7Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[repDOdd7Cat1Brd2]][
      balancedCategory[#1]] & )[repDOdd7Cat1Bal2] ^= 1
 
(balancedCategoryIndex[fusionCategory[repDOdd7Cat1]][
      balancedCategory[#1]] & )[repDOdd7Cat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[repDOdd7Cat1Piv1]][
      balancedCategory[#1]] & )[repDOdd7Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[braidedCategory[repDOdd7Cat1Brd2]][
      ribbonCategory[#1]] & )[repDOdd7Cat1Bal2] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repDOdd7Cat1]][ribbonCategory[#1]] & )[
    repDOdd7Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[repDOdd7Cat1Piv1]][
      ribbonCategory[#1]] & )[repDOdd7Cat1Bal2] ^= 2
balancedCategory[repDOdd7Cat1Bal3] ^= repDOdd7Cat1Bal3
 
braidedCategory[repDOdd7Cat1Bal3] ^= repDOdd7Cat1Brd3
 
fusionCategory[repDOdd7Cat1Bal3] ^= repDOdd7Cat1
 
pivotalCategory[repDOdd7Cat1Bal3] ^= repDOdd7Cat1Piv1
 
ribbonCategory[repDOdd7Cat1Bal3] ^= repDOdd7Cat1Bal3
 
ring[repDOdd7Cat1Bal3] ^= repDOdd7
 
sphericalCategory[repDOdd7Cat1Bal3] ^= repDOdd7Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[repDOdd7Cat1Brd3]][
      balancedCategory[#1]] & )[repDOdd7Cat1Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[repDOdd7Cat1]][
      balancedCategory[#1]] & )[repDOdd7Cat1Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[repDOdd7Cat1Piv1]][
      balancedCategory[#1]] & )[repDOdd7Cat1Bal3] ^= 3
 
(ribbonCategoryIndex[braidedCategory[repDOdd7Cat1Brd3]][
      ribbonCategory[#1]] & )[repDOdd7Cat1Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repDOdd7Cat1]][ribbonCategory[#1]] & )[
    repDOdd7Cat1Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[repDOdd7Cat1Piv1]][
      ribbonCategory[#1]] & )[repDOdd7Cat1Bal3] ^= 3
balancedCategories[repDOdd7Cat1Brd1] ^= {repDOdd7Cat1Bal1}
 
repDOdd7Cat1Brd1 /: balancedCategory[repDOdd7Cat1Brd1, 1] = repDOdd7Cat1Bal1
 
braidedCategory[repDOdd7Cat1Brd1] ^= repDOdd7Cat1Brd1
 
fusionCategory[repDOdd7Cat1Brd1] ^= repDOdd7Cat1
 
repDOdd7Cat1Brd1 /: modularCategory[repDOdd7Cat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repDOdd7Cat1Brd1 /: ribbonCategory[repDOdd7Cat1Brd1, 1] = repDOdd7Cat1Bal1
 
ring[repDOdd7Cat1Brd1] ^= repDOdd7
 
rMatrixFunction[repDOdd7Cat1Brd1] ^= repDOdd7Cat1Brd1RMatrixFunction
 
symmetricCategory[repDOdd7Cat1Brd1] ^= repDOdd7Cat1Brd1
 
(braidedCategoryIndex[fusionCategory[repDOdd7Cat1]][braidedCategory[#1]] & )[
    repDOdd7Cat1Brd1] ^= 1
 
(symmetricCategoryIndex[fusionCategory[repDOdd7Cat1]][
      symmetricCategory[#1]] & )[repDOdd7Cat1Brd1] ^= 1
braidedCategory[repDOdd7Cat1Brd1RMatrixFunction] ^= repDOdd7Cat1Brd1
 
fusionCategory[repDOdd7Cat1Brd1RMatrixFunction] ^= repDOdd7Cat1
 
rMatrixFunction[repDOdd7Cat1Brd1RMatrixFunction] ^= 
   repDOdd7Cat1Brd1RMatrixFunction
 
repDOdd7Cat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[1, 1, 0] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[1, 2, 2] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[1, 3, 3] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[1, 4, 4] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[2, 1, 2] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[2, 2, 0] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[2, 2, 1] = {{-1}}
 
repDOdd7Cat1Brd1RMatrixFunction[2, 2, 3] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[2, 3, 2] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[2, 3, 4] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[2, 4, 3] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[2, 4, 4] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[3, 1, 3] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[3, 2, 2] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[3, 2, 4] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[3, 3, 0] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[3, 3, 1] = {{-1}}
 
repDOdd7Cat1Brd1RMatrixFunction[3, 3, 4] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[3, 4, 2] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[3, 4, 3] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[4, 1, 4] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[4, 2, 3] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[4, 2, 4] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[4, 3, 2] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[4, 3, 3] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[4, 4, 0] = {{1}}
 
repDOdd7Cat1Brd1RMatrixFunction[4, 4, 1] = {{-1}}
 
repDOdd7Cat1Brd1RMatrixFunction[4, 4, 2] = {{1}}
balancedCategories[repDOdd7Cat1Brd2] ^= {repDOdd7Cat1Bal2}
 
repDOdd7Cat1Brd2 /: balancedCategory[repDOdd7Cat1Brd2, 1] = repDOdd7Cat1Bal2
 
braidedCategory[repDOdd7Cat1Brd2] ^= repDOdd7Cat1Brd2
 
fusionCategory[repDOdd7Cat1Brd2] ^= repDOdd7Cat1
 
repDOdd7Cat1Brd2 /: modularCategory[repDOdd7Cat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repDOdd7Cat1Brd2 /: ribbonCategory[repDOdd7Cat1Brd2, 1] = repDOdd7Cat1Bal2
 
ring[repDOdd7Cat1Brd2] ^= repDOdd7
 
rMatrixFunction[repDOdd7Cat1Brd2] ^= repDOdd7Cat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repDOdd7Cat1]][braidedCategory[#1]] & )[
    repDOdd7Cat1Brd2] ^= 2
braidedCategory[repDOdd7Cat1Brd2RMatrixFunction] ^= repDOdd7Cat1Brd2
 
fusionCategory[repDOdd7Cat1Brd2RMatrixFunction] ^= repDOdd7Cat1
 
rMatrixFunction[repDOdd7Cat1Brd2RMatrixFunction] ^= 
   repDOdd7Cat1Brd2RMatrixFunction
 
repDOdd7Cat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
repDOdd7Cat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
repDOdd7Cat1Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
repDOdd7Cat1Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
repDOdd7Cat1Brd2RMatrixFunction[0, 4, 4] = {{1}}
 
repDOdd7Cat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
repDOdd7Cat1Brd2RMatrixFunction[1, 1, 0] = {{1}}
 
repDOdd7Cat1Brd2RMatrixFunction[1, 2, 2] = {{1}}
 
repDOdd7Cat1Brd2RMatrixFunction[1, 3, 3] = {{1}}
 
repDOdd7Cat1Brd2RMatrixFunction[1, 4, 4] = {{1}}
 
repDOdd7Cat1Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
repDOdd7Cat1Brd2RMatrixFunction[2, 1, 2] = {{1}}
 
repDOdd7Cat1Brd2RMatrixFunction[2, 2, 0] = {{(-1)^(2/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[2, 2, 1] = {{-(-1)^(2/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[2, 2, 3] = {{-(-1)^(5/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[2, 3, 2] = {{(-1)^(4/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[2, 3, 4] = {{-(-1)^(3/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[2, 4, 3] = {{(-1)^(6/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[2, 4, 4] = {{-(-1)^(1/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
repDOdd7Cat1Brd2RMatrixFunction[3, 1, 3] = {{1}}
 
repDOdd7Cat1Brd2RMatrixFunction[3, 2, 2] = {{(-1)^(4/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[3, 2, 4] = {{-(-1)^(3/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[3, 3, 0] = {{-(-1)^(1/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[3, 3, 1] = {{(-1)^(1/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[3, 3, 4] = {{(-1)^(6/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[3, 4, 2] = {{-(-1)^(5/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[3, 4, 3] = {{(-1)^(2/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[4, 0, 4] = {{1}}
 
repDOdd7Cat1Brd2RMatrixFunction[4, 1, 4] = {{1}}
 
repDOdd7Cat1Brd2RMatrixFunction[4, 2, 3] = {{(-1)^(6/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[4, 2, 4] = {{-(-1)^(1/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[4, 3, 2] = {{-(-1)^(5/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[4, 3, 3] = {{(-1)^(2/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[4, 4, 0] = {{(-1)^(4/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[4, 4, 1] = {{-(-1)^(4/7)}}
 
repDOdd7Cat1Brd2RMatrixFunction[4, 4, 2] = {{-(-1)^(3/7)}}
balancedCategories[repDOdd7Cat1Brd3] ^= {repDOdd7Cat1Bal3}
 
repDOdd7Cat1Brd3 /: balancedCategory[repDOdd7Cat1Brd3, 1] = repDOdd7Cat1Bal3
 
braidedCategory[repDOdd7Cat1Brd3] ^= repDOdd7Cat1Brd3
 
fusionCategory[repDOdd7Cat1Brd3] ^= repDOdd7Cat1
 
repDOdd7Cat1Brd3 /: modularCategory[repDOdd7Cat1Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repDOdd7Cat1Brd3 /: ribbonCategory[repDOdd7Cat1Brd3, 1] = repDOdd7Cat1Bal3
 
ring[repDOdd7Cat1Brd3] ^= repDOdd7
 
rMatrixFunction[repDOdd7Cat1Brd3] ^= repDOdd7Cat1Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repDOdd7Cat1]][braidedCategory[#1]] & )[
    repDOdd7Cat1Brd3] ^= 3
braidedCategory[repDOdd7Cat1Brd3RMatrixFunction] ^= repDOdd7Cat1Brd3
 
fusionCategory[repDOdd7Cat1Brd3RMatrixFunction] ^= repDOdd7Cat1
 
rMatrixFunction[repDOdd7Cat1Brd3RMatrixFunction] ^= 
   repDOdd7Cat1Brd3RMatrixFunction
 
repDOdd7Cat1Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
repDOdd7Cat1Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
repDOdd7Cat1Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
repDOdd7Cat1Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
repDOdd7Cat1Brd3RMatrixFunction[0, 4, 4] = {{1}}
 
repDOdd7Cat1Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
repDOdd7Cat1Brd3RMatrixFunction[1, 1, 0] = {{1}}
 
repDOdd7Cat1Brd3RMatrixFunction[1, 2, 2] = {{1}}
 
repDOdd7Cat1Brd3RMatrixFunction[1, 3, 3] = {{1}}
 
repDOdd7Cat1Brd3RMatrixFunction[1, 4, 4] = {{1}}
 
repDOdd7Cat1Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
repDOdd7Cat1Brd3RMatrixFunction[2, 1, 2] = {{1}}
 
repDOdd7Cat1Brd3RMatrixFunction[2, 2, 0] = {{(-1)^(6/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[2, 2, 1] = {{-(-1)^(6/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[2, 2, 3] = {{-(-1)^(1/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[2, 3, 2] = {{-(-1)^(5/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[2, 3, 4] = {{(-1)^(2/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[2, 4, 3] = {{(-1)^(4/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[2, 4, 4] = {{-(-1)^(3/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
repDOdd7Cat1Brd3RMatrixFunction[3, 1, 3] = {{1}}
 
repDOdd7Cat1Brd3RMatrixFunction[3, 2, 2] = {{-(-1)^(5/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[3, 2, 4] = {{(-1)^(2/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[3, 3, 0] = {{-(-1)^(3/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[3, 3, 1] = {{(-1)^(3/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[3, 3, 4] = {{(-1)^(4/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[3, 4, 2] = {{-(-1)^(1/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[3, 4, 3] = {{(-1)^(6/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[4, 0, 4] = {{1}}
 
repDOdd7Cat1Brd3RMatrixFunction[4, 1, 4] = {{1}}
 
repDOdd7Cat1Brd3RMatrixFunction[4, 2, 3] = {{(-1)^(4/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[4, 2, 4] = {{-(-1)^(3/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[4, 3, 2] = {{-(-1)^(1/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[4, 3, 3] = {{(-1)^(6/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[4, 4, 0] = {{-(-1)^(5/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[4, 4, 1] = {{(-1)^(5/7)}}
 
repDOdd7Cat1Brd3RMatrixFunction[4, 4, 2] = {{(-1)^(2/7)}}
fMatrixFunction[repDOdd7Cat1FMatrixFunction] ^= repDOdd7Cat1FMatrixFunction
 
fusionCategory[repDOdd7Cat1FMatrixFunction] ^= repDOdd7Cat1
 
ring[repDOdd7Cat1FMatrixFunction] ^= repDOdd7
 
repDOdd7Cat1FMatrixFunction[1, 2, 3, 2] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[1, 2, 3, 4] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[1, 2, 4, 3] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[1, 3, 2, 4] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[1, 3, 3, 0] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[1, 3, 4, 2] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[1, 3, 4, 3] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[1, 4, 2, 3] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[1, 4, 2, 4] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[1, 4, 3, 2] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[1, 4, 4, 0] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[1, 4, 4, 1] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[2, 1, 3, 2] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[2, 1, 4, 4] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {-1/2, -1/2, 1/Sqrt[2]}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
repDOdd7Cat1FMatrixFunction[2, 2, 3, 1] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[2, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repDOdd7Cat1FMatrixFunction[2, 2, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
repDOdd7Cat1FMatrixFunction[2, 3, 1, 4] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[2, 3, 2, 1] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[2, 3, 2, 3] = {{0, 1}, {1, 0}}
 
repDOdd7Cat1FMatrixFunction[2, 3, 3, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repDOdd7Cat1FMatrixFunction[2, 4, 1, 3] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[2, 4, 1, 4] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[2, 4, 2, 4] = {{0, 1}, {1, 0}}
 
repDOdd7Cat1FMatrixFunction[2, 4, 4, 1] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[2, 4, 4, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
repDOdd7Cat1FMatrixFunction[3, 1, 2, 2] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[3, 1, 3, 0] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[3, 1, 3, 1] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[3, 1, 4, 3] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[3, 2, 1, 2] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[3, 2, 1, 4] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[3, 2, 2, 1] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[3, 2, 2, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
repDOdd7Cat1FMatrixFunction[3, 2, 3, 2] = {{0, 1}, {1, 0}}
 
repDOdd7Cat1FMatrixFunction[3, 2, 4, 1] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[3, 3, 2, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
repDOdd7Cat1FMatrixFunction[3, 3, 3, 3] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {1/2, -1/2, -(1/Sqrt[2])}, {1/Sqrt[2], 1/Sqrt[2], 0}}
 
repDOdd7Cat1FMatrixFunction[3, 3, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repDOdd7Cat1FMatrixFunction[3, 4, 1, 2] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[3, 4, 3, 1] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[3, 4, 3, 4] = {{0, 1}, {1, 0}}
 
repDOdd7Cat1FMatrixFunction[3, 4, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
repDOdd7Cat1FMatrixFunction[4, 1, 2, 4] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[4, 1, 3, 3] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[4, 1, 4, 0] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[4, 1, 4, 1] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[4, 2, 1, 3] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[4, 2, 2, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repDOdd7Cat1FMatrixFunction[4, 2, 3, 1] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[4, 2, 4, 2] = {{0, 1}, {1, 0}}
 
repDOdd7Cat1FMatrixFunction[4, 3, 1, 2] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[4, 3, 1, 3] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[4, 3, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
repDOdd7Cat1FMatrixFunction[4, 3, 4, 3] = {{0, 1}, {1, 0}}
 
repDOdd7Cat1FMatrixFunction[4, 4, 2, 1] = {{-1}}
 
repDOdd7Cat1FMatrixFunction[4, 4, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repDOdd7Cat1FMatrixFunction[4, 4, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repDOdd7Cat1FMatrixFunction[4, 4, 4, 4] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {1/2, -1/2, -(1/Sqrt[2])}, {1/Sqrt[2], 1/Sqrt[2], 0}}
 
repDOdd7Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repDOdd7Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
repDOdd7Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repDOdd7Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[repDOdd7Cat1Piv1] ^= {repDOdd7Cat1Bal1, repDOdd7Cat1Bal2, 
    repDOdd7Cat1Bal3}
 
repDOdd7Cat1Piv1 /: balancedCategory[repDOdd7Cat1Piv1, 1] = repDOdd7Cat1Bal1
 
repDOdd7Cat1Piv1 /: balancedCategory[repDOdd7Cat1Piv1, 2] = repDOdd7Cat1Bal2
 
repDOdd7Cat1Piv1 /: balancedCategory[repDOdd7Cat1Piv1, 3] = repDOdd7Cat1Bal3
 
fusionCategory[repDOdd7Cat1Piv1] ^= repDOdd7Cat1
 
repDOdd7Cat1Piv1 /: modularCategory[repDOdd7Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repDOdd7Cat1Piv1] ^= repDOdd7Cat1Piv1
 
pivotalIsomorphism[repDOdd7Cat1Piv1] ^= repDOdd7Cat1Piv1PivotalIsomorphism
 
repDOdd7Cat1Piv1 /: ribbonCategory[repDOdd7Cat1Piv1, 1] = repDOdd7Cat1Bal1
 
repDOdd7Cat1Piv1 /: ribbonCategory[repDOdd7Cat1Piv1, 2] = repDOdd7Cat1Bal2
 
repDOdd7Cat1Piv1 /: ribbonCategory[repDOdd7Cat1Piv1, 3] = repDOdd7Cat1Bal3
 
ring[repDOdd7Cat1Piv1] ^= repDOdd7
 
sphericalCategory[repDOdd7Cat1Piv1] ^= repDOdd7Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[repDOdd7Cat1]][pivotalCategory[#1]] & )[
    repDOdd7Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[repDOdd7Cat1]][
      sphericalCategory[#1]] & )[repDOdd7Cat1Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[repDOdd7Cat1Piv1PivotalIsomorphism] ^= repDOdd7Cat1
 
pivotalCategory[repDOdd7Cat1Piv1PivotalIsomorphism] ^= repDOdd7Cat1Piv1
 
pivotalIsomorphism[repDOdd7Cat1Piv1PivotalIsomorphism] ^= 
   repDOdd7Cat1Piv1PivotalIsomorphism
 
repDOdd7Cat1Piv1PivotalIsomorphism[0] = 1
 
repDOdd7Cat1Piv1PivotalIsomorphism[1] = 1
 
repDOdd7Cat1Piv1PivotalIsomorphism[2] = 1
 
repDOdd7Cat1Piv1PivotalIsomorphism[3] = 1
 
repDOdd7Cat1Piv1PivotalIsomorphism[4] = 1
balancedCategories[repDOdd7Cat2] ^= {}
 
braidedCategories[repDOdd7Cat2] ^= {}
 
coeval[repDOdd7Cat2] ^= 1/sixJFunction[repDOdd7Cat2][#1, 
      dual[ring[repDOdd7Cat2]][#1], #1, #1, 0, 0] & 
 
eval[repDOdd7Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[repDOdd7Cat2] ^= repDOdd7Cat2FMatrixFunction
 
fusionCategory[repDOdd7Cat2] ^= repDOdd7Cat2
 
repDOdd7Cat2 /: modularCategory[repDOdd7Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[repDOdd7Cat2] ^= {repDOdd7Cat2Piv1}
 
repDOdd7Cat2 /: pivotalCategory[repDOdd7Cat2, 1] = repDOdd7Cat2Piv1
 
repDOdd7Cat2 /: pivotalCategory[repDOdd7Cat2, {1, 1, 1, 1, 1}] = 
    repDOdd7Cat2Piv1
 
ring[repDOdd7Cat2] ^= repDOdd7
 
repDOdd7Cat2 /: sphericalCategory[repDOdd7Cat2, 1] = repDOdd7Cat2Piv1
 
fusionCategoryIndex[repDOdd7][repDOdd7Cat2] ^= 2
fMatrixFunction[repDOdd7Cat2FMatrixFunction] ^= repDOdd7Cat2FMatrixFunction
 
fusionCategory[repDOdd7Cat2FMatrixFunction] ^= repDOdd7Cat2
 
ring[repDOdd7Cat2FMatrixFunction] ^= repDOdd7
 
repDOdd7Cat2FMatrixFunction[1, 2, 3, 2] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[1, 2, 3, 4] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[1, 2, 4, 3] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[1, 3, 2, 4] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[1, 3, 3, 0] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[1, 3, 4, 2] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[1, 3, 4, 3] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[1, 4, 2, 3] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[1, 4, 2, 4] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[1, 4, 3, 2] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[1, 4, 4, 0] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[1, 4, 4, 1] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[2, 1, 3, 2] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[2, 1, 4, 4] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {-1/2, -1/2, 1/Sqrt[2]}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
repDOdd7Cat2FMatrixFunction[2, 2, 3, 1] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[2, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-((-1)^(3/7)/Sqrt[2]), (-1)^(3/7)/Sqrt[2]}}
 
repDOdd7Cat2FMatrixFunction[2, 2, 4, 3] = {{-(-1)^(3/7)}}
 
repDOdd7Cat2FMatrixFunction[2, 2, 4, 4] = 
   {{-((-1)^(3/7)/Sqrt[2]), (-1)^(3/7)/Sqrt[2]}, {1/Sqrt[2], 1/Sqrt[2]}}
 
repDOdd7Cat2FMatrixFunction[2, 3, 1, 4] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[2, 3, 2, 1] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[2, 3, 2, 3] = {{0, (-1)^(4/7)}, {-(-1)^(3/7), 0}}
 
repDOdd7Cat2FMatrixFunction[2, 3, 2, 4] = {{(-1)^(4/7)}}
 
repDOdd7Cat2FMatrixFunction[2, 3, 3, 2] = {{1/Sqrt[2], (-1)^(4/7)/Sqrt[2]}, 
    {1/Sqrt[2], -((-1)^(4/7)/Sqrt[2])}}
 
repDOdd7Cat2FMatrixFunction[2, 3, 3, 3] = {{-(-1)^(5/7)}}
 
repDOdd7Cat2FMatrixFunction[2, 4, 1, 3] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[2, 4, 1, 4] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[2, 4, 2, 3] = {{(-1)^(4/7)}}
 
repDOdd7Cat2FMatrixFunction[2, 4, 2, 4] = {{0, (-1)^(6/7)}, {1, 0}}
 
repDOdd7Cat2FMatrixFunction[2, 4, 3, 2] = {{(-1)^(4/7)}}
 
repDOdd7Cat2FMatrixFunction[2, 4, 3, 3] = {{-(-1)^(3/7)}}
 
repDOdd7Cat2FMatrixFunction[2, 4, 3, 4] = {{(-1)^(2/7)}}
 
repDOdd7Cat2FMatrixFunction[2, 4, 4, 1] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[2, 4, 4, 2] = {{(-1)^(4/7)/Sqrt[2], 1/Sqrt[2]}, 
    {-((-1)^(4/7)/Sqrt[2]), 1/Sqrt[2]}}
 
repDOdd7Cat2FMatrixFunction[2, 4, 4, 3] = {{(-1)^(4/7)}}
 
repDOdd7Cat2FMatrixFunction[3, 1, 2, 2] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[3, 1, 3, 0] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[3, 1, 3, 1] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[3, 1, 4, 3] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[3, 2, 1, 2] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[3, 2, 1, 4] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[3, 2, 2, 1] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[3, 2, 2, 3] = {{1/Sqrt[2], (-1)^(4/7)/Sqrt[2]}, 
    {-(1/Sqrt[2]), (-1)^(4/7)/Sqrt[2]}}
 
repDOdd7Cat2FMatrixFunction[3, 2, 2, 4] = {{(-1)^(4/7)}}
 
repDOdd7Cat2FMatrixFunction[3, 2, 3, 2] = {{0, (-1)^(4/7)}, {-(-1)^(3/7), 0}}
 
repDOdd7Cat2FMatrixFunction[3, 2, 3, 3] = {{(-1)^(2/7)}}
 
repDOdd7Cat2FMatrixFunction[3, 2, 4, 1] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[3, 2, 4, 2] = {{-(-1)^(3/7)}}
 
repDOdd7Cat2FMatrixFunction[3, 2, 4, 3] = {{(-1)^(4/7)}}
 
repDOdd7Cat2FMatrixFunction[3, 2, 4, 4] = {{-(-1)^(3/7)}}
 
repDOdd7Cat2FMatrixFunction[3, 3, 2, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-((-1)^(3/7)/Sqrt[2]), -((-1)^(3/7)/Sqrt[2])}}
 
repDOdd7Cat2FMatrixFunction[3, 3, 2, 3] = {{-(-1)^(5/7)}}
 
repDOdd7Cat2FMatrixFunction[3, 3, 2, 4] = {{-(-1)^(3/7)}}
 
repDOdd7Cat2FMatrixFunction[3, 3, 3, 2] = {{(-1)^(2/7)}}
 
repDOdd7Cat2FMatrixFunction[3, 3, 3, 3] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {1/2, -1/2, -(1/Sqrt[2])}, {1/Sqrt[2], 1/Sqrt[2], 0}}
 
repDOdd7Cat2FMatrixFunction[3, 3, 4, 4] = 
   {{-((-1)^(3/7)/Sqrt[2]), -((-1)^(3/7)/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2])}}
 
repDOdd7Cat2FMatrixFunction[3, 4, 1, 2] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[3, 4, 2, 4] = {{(-1)^(2/7)}}
 
repDOdd7Cat2FMatrixFunction[3, 4, 3, 1] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[3, 4, 3, 4] = {{0, -(-1)^(1/7)}, {(-1)^(2/7), 0}}
 
repDOdd7Cat2FMatrixFunction[3, 4, 4, 3] = {{(-1)^(4/7)/Sqrt[2], 1/Sqrt[2]}, 
    {-((-1)^(4/7)/Sqrt[2]), 1/Sqrt[2]}}
 
repDOdd7Cat2FMatrixFunction[3, 4, 4, 4] = {{(-1)^(4/7)}}
 
repDOdd7Cat2FMatrixFunction[4, 1, 2, 4] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[4, 1, 3, 3] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[4, 1, 4, 0] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[4, 1, 4, 1] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[4, 2, 1, 3] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[4, 2, 2, 4] = {{(-1)^(4/7)/Sqrt[2], 1/Sqrt[2]}, 
    {(-1)^(4/7)/Sqrt[2], -(1/Sqrt[2])}}
 
repDOdd7Cat2FMatrixFunction[4, 2, 3, 1] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[4, 2, 3, 2] = {{-(-1)^(3/7)}}
 
repDOdd7Cat2FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[4, 2, 4, 2] = {{0, 1}, {-(-1)^(1/7), 0}}
 
repDOdd7Cat2FMatrixFunction[4, 2, 4, 3] = {{-(-1)^(5/7)}}
 
repDOdd7Cat2FMatrixFunction[4, 3, 1, 2] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[4, 3, 1, 3] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[4, 3, 2, 2] = {{-(-1)^(3/7)}}
 
repDOdd7Cat2FMatrixFunction[4, 3, 2, 4] = {{(-1)^(4/7)}}
 
repDOdd7Cat2FMatrixFunction[4, 3, 3, 2] = {{(-1)^(4/7)}}
 
repDOdd7Cat2FMatrixFunction[4, 3, 3, 4] = {{(-1)^(4/7)/Sqrt[2], 1/Sqrt[2]}, 
    {-((-1)^(4/7)/Sqrt[2]), 1/Sqrt[2]}}
 
repDOdd7Cat2FMatrixFunction[4, 3, 4, 2] = {{-(-1)^(5/7)}}
 
repDOdd7Cat2FMatrixFunction[4, 3, 4, 3] = {{0, -(-1)^(5/7)}, {(-1)^(6/7), 0}}
 
repDOdd7Cat2FMatrixFunction[4, 3, 4, 4] = {{-(-1)^(3/7)}}
 
repDOdd7Cat2FMatrixFunction[4, 4, 2, 1] = {{-1}}
 
repDOdd7Cat2FMatrixFunction[4, 4, 2, 2] = 
   {{-((-1)^(3/7)/Sqrt[2]), -((-1)^(3/7)/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2])}}
 
repDOdd7Cat2FMatrixFunction[4, 4, 3, 2] = {{-(-1)^(3/7)}}
 
repDOdd7Cat2FMatrixFunction[4, 4, 3, 3] = 
   {{-((-1)^(3/7)/Sqrt[2]), -((-1)^(3/7)/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2])}}
 
repDOdd7Cat2FMatrixFunction[4, 4, 3, 4] = {{(-1)^(4/7)}}
 
repDOdd7Cat2FMatrixFunction[4, 4, 4, 3] = {{-(-1)^(3/7)}}
 
repDOdd7Cat2FMatrixFunction[4, 4, 4, 4] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {1/2, -1/2, -(1/Sqrt[2])}, {1/Sqrt[2], 1/Sqrt[2], 0}}
 
repDOdd7Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repDOdd7Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
repDOdd7Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repDOdd7Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[repDOdd7Cat2Piv1] ^= {}
 
fusionCategory[repDOdd7Cat2Piv1] ^= repDOdd7Cat2
 
repDOdd7Cat2Piv1 /: modularCategory[repDOdd7Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repDOdd7Cat2Piv1] ^= repDOdd7Cat2Piv1
 
pivotalIsomorphism[repDOdd7Cat2Piv1] ^= repDOdd7Cat2Piv1PivotalIsomorphism
 
ring[repDOdd7Cat2Piv1] ^= repDOdd7
 
sphericalCategory[repDOdd7Cat2Piv1] ^= repDOdd7Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[repDOdd7Cat2]][pivotalCategory[#1]] & )[
    repDOdd7Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[repDOdd7Cat2]][
      sphericalCategory[#1]] & )[repDOdd7Cat2Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[repDOdd7Cat2Piv1PivotalIsomorphism] ^= repDOdd7Cat2
 
pivotalCategory[repDOdd7Cat2Piv1PivotalIsomorphism] ^= repDOdd7Cat2Piv1
 
pivotalIsomorphism[repDOdd7Cat2Piv1PivotalIsomorphism] ^= 
   repDOdd7Cat2Piv1PivotalIsomorphism
 
repDOdd7Cat2Piv1PivotalIsomorphism[0] = 1
 
repDOdd7Cat2Piv1PivotalIsomorphism[1] = 1
 
repDOdd7Cat2Piv1PivotalIsomorphism[2] = 1
 
repDOdd7Cat2Piv1PivotalIsomorphism[3] = 1
 
repDOdd7Cat2Piv1PivotalIsomorphism[4] = 1
balancedCategories[repDOdd7Cat3] ^= {}
 
braidedCategories[repDOdd7Cat3] ^= {}
 
coeval[repDOdd7Cat3] ^= 1/sixJFunction[repDOdd7Cat3][#1, 
      dual[ring[repDOdd7Cat3]][#1], #1, #1, 0, 0] & 
 
eval[repDOdd7Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[repDOdd7Cat3] ^= repDOdd7Cat3FMatrixFunction
 
fusionCategory[repDOdd7Cat3] ^= repDOdd7Cat3
 
repDOdd7Cat3 /: modularCategory[repDOdd7Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[repDOdd7Cat3] ^= {repDOdd7Cat3Piv1}
 
repDOdd7Cat3 /: pivotalCategory[repDOdd7Cat3, 1] = repDOdd7Cat3Piv1
 
repDOdd7Cat3 /: pivotalCategory[repDOdd7Cat3, {1, 1, 1, 1, 1}] = 
    repDOdd7Cat3Piv1
 
ring[repDOdd7Cat3] ^= repDOdd7
 
repDOdd7Cat3 /: sphericalCategory[repDOdd7Cat3, 1] = repDOdd7Cat3Piv1
 
fusionCategoryIndex[repDOdd7][repDOdd7Cat3] ^= 3
fMatrixFunction[repDOdd7Cat3FMatrixFunction] ^= repDOdd7Cat3FMatrixFunction
 
fusionCategory[repDOdd7Cat3FMatrixFunction] ^= repDOdd7Cat3
 
ring[repDOdd7Cat3FMatrixFunction] ^= repDOdd7
 
repDOdd7Cat3FMatrixFunction[1, 2, 3, 2] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[1, 2, 3, 4] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[1, 2, 4, 3] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[1, 3, 2, 4] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[1, 3, 3, 0] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[1, 3, 4, 2] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[1, 3, 4, 3] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[1, 4, 2, 3] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[1, 4, 2, 4] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[1, 4, 3, 2] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[1, 4, 4, 0] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[1, 4, 4, 1] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[2, 1, 3, 2] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[2, 1, 4, 4] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {-1/2, -1/2, 1/Sqrt[2]}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
repDOdd7Cat3FMatrixFunction[2, 2, 3, 1] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[2, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {(-1)^(2/7)/Sqrt[2], -((-1)^(2/7)/Sqrt[2])}}
 
repDOdd7Cat3FMatrixFunction[2, 2, 4, 3] = {{(-1)^(2/7)}}
 
repDOdd7Cat3FMatrixFunction[2, 2, 4, 4] = 
   {{(-1)^(2/7)/Sqrt[2], -((-1)^(2/7)/Sqrt[2])}, {1/Sqrt[2], 1/Sqrt[2]}}
 
repDOdd7Cat3FMatrixFunction[2, 3, 1, 4] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[2, 3, 2, 1] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[2, 3, 2, 3] = {{0, -(-1)^(5/7)}, {(-1)^(2/7), 0}}
 
repDOdd7Cat3FMatrixFunction[2, 3, 2, 4] = {{-(-1)^(5/7)}}
 
repDOdd7Cat3FMatrixFunction[2, 3, 3, 2] = 
   {{1/Sqrt[2], -((-1)^(5/7)/Sqrt[2])}, {1/Sqrt[2], (-1)^(5/7)/Sqrt[2]}}
 
repDOdd7Cat3FMatrixFunction[2, 3, 3, 3] = {{-(-1)^(1/7)}}
 
repDOdd7Cat3FMatrixFunction[2, 4, 1, 3] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[2, 4, 1, 4] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[2, 4, 2, 3] = {{-(-1)^(5/7)}}
 
repDOdd7Cat3FMatrixFunction[2, 4, 2, 4] = {{0, (-1)^(4/7)}, {1, 0}}
 
repDOdd7Cat3FMatrixFunction[2, 4, 3, 2] = {{-(-1)^(5/7)}}
 
repDOdd7Cat3FMatrixFunction[2, 4, 3, 3] = {{(-1)^(2/7)}}
 
repDOdd7Cat3FMatrixFunction[2, 4, 3, 4] = {{(-1)^(6/7)}}
 
repDOdd7Cat3FMatrixFunction[2, 4, 4, 1] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[2, 4, 4, 2] = 
   {{-((-1)^(5/7)/Sqrt[2]), 1/Sqrt[2]}, {(-1)^(5/7)/Sqrt[2], 1/Sqrt[2]}}
 
repDOdd7Cat3FMatrixFunction[2, 4, 4, 3] = {{-(-1)^(5/7)}}
 
repDOdd7Cat3FMatrixFunction[3, 1, 2, 2] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[3, 1, 3, 0] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[3, 1, 3, 1] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[3, 1, 4, 3] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[3, 2, 1, 2] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[3, 2, 1, 4] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[3, 2, 2, 1] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[3, 2, 2, 3] = 
   {{1/Sqrt[2], -((-1)^(5/7)/Sqrt[2])}, {-(1/Sqrt[2]), -((-1)^(5/7)/Sqrt[2])}}
 
repDOdd7Cat3FMatrixFunction[3, 2, 2, 4] = {{-(-1)^(5/7)}}
 
repDOdd7Cat3FMatrixFunction[3, 2, 3, 2] = {{0, -(-1)^(5/7)}, {(-1)^(2/7), 0}}
 
repDOdd7Cat3FMatrixFunction[3, 2, 3, 3] = {{(-1)^(6/7)}}
 
repDOdd7Cat3FMatrixFunction[3, 2, 4, 1] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[3, 2, 4, 2] = {{(-1)^(2/7)}}
 
repDOdd7Cat3FMatrixFunction[3, 2, 4, 3] = {{-(-1)^(5/7)}}
 
repDOdd7Cat3FMatrixFunction[3, 2, 4, 4] = {{(-1)^(2/7)}}
 
repDOdd7Cat3FMatrixFunction[3, 3, 2, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {(-1)^(2/7)/Sqrt[2], (-1)^(2/7)/Sqrt[2]}}
 
repDOdd7Cat3FMatrixFunction[3, 3, 2, 3] = {{-(-1)^(1/7)}}
 
repDOdd7Cat3FMatrixFunction[3, 3, 2, 4] = {{(-1)^(2/7)}}
 
repDOdd7Cat3FMatrixFunction[3, 3, 3, 2] = {{(-1)^(6/7)}}
 
repDOdd7Cat3FMatrixFunction[3, 3, 3, 3] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {1/2, -1/2, -(1/Sqrt[2])}, {1/Sqrt[2], 1/Sqrt[2], 0}}
 
repDOdd7Cat3FMatrixFunction[3, 3, 4, 4] = 
   {{(-1)^(2/7)/Sqrt[2], (-1)^(2/7)/Sqrt[2]}, {1/Sqrt[2], -(1/Sqrt[2])}}
 
repDOdd7Cat3FMatrixFunction[3, 4, 1, 2] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[3, 4, 2, 4] = {{(-1)^(6/7)}}
 
repDOdd7Cat3FMatrixFunction[3, 4, 3, 1] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[3, 4, 3, 4] = {{0, -(-1)^(3/7)}, {(-1)^(6/7), 0}}
 
repDOdd7Cat3FMatrixFunction[3, 4, 4, 3] = 
   {{-((-1)^(5/7)/Sqrt[2]), 1/Sqrt[2]}, {(-1)^(5/7)/Sqrt[2], 1/Sqrt[2]}}
 
repDOdd7Cat3FMatrixFunction[3, 4, 4, 4] = {{-(-1)^(5/7)}}
 
repDOdd7Cat3FMatrixFunction[4, 1, 2, 4] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[4, 1, 3, 3] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[4, 1, 4, 0] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[4, 1, 4, 1] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[4, 2, 1, 3] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[4, 2, 2, 4] = 
   {{-((-1)^(5/7)/Sqrt[2]), 1/Sqrt[2]}, {-((-1)^(5/7)/Sqrt[2]), -(1/Sqrt[2])}}
 
repDOdd7Cat3FMatrixFunction[4, 2, 3, 1] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[4, 2, 3, 2] = {{(-1)^(2/7)}}
 
repDOdd7Cat3FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[4, 2, 4, 2] = {{0, 1}, {-(-1)^(3/7), 0}}
 
repDOdd7Cat3FMatrixFunction[4, 2, 4, 3] = {{-(-1)^(1/7)}}
 
repDOdd7Cat3FMatrixFunction[4, 3, 1, 2] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[4, 3, 1, 3] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[4, 3, 2, 2] = {{(-1)^(2/7)}}
 
repDOdd7Cat3FMatrixFunction[4, 3, 2, 4] = {{-(-1)^(5/7)}}
 
repDOdd7Cat3FMatrixFunction[4, 3, 3, 2] = {{-(-1)^(5/7)}}
 
repDOdd7Cat3FMatrixFunction[4, 3, 3, 4] = 
   {{-((-1)^(5/7)/Sqrt[2]), 1/Sqrt[2]}, {(-1)^(5/7)/Sqrt[2], 1/Sqrt[2]}}
 
repDOdd7Cat3FMatrixFunction[4, 3, 4, 2] = {{-(-1)^(1/7)}}
 
repDOdd7Cat3FMatrixFunction[4, 3, 4, 3] = {{0, -(-1)^(1/7)}, {(-1)^(4/7), 0}}
 
repDOdd7Cat3FMatrixFunction[4, 3, 4, 4] = {{(-1)^(2/7)}}
 
repDOdd7Cat3FMatrixFunction[4, 4, 2, 1] = {{-1}}
 
repDOdd7Cat3FMatrixFunction[4, 4, 2, 2] = 
   {{(-1)^(2/7)/Sqrt[2], (-1)^(2/7)/Sqrt[2]}, {1/Sqrt[2], -(1/Sqrt[2])}}
 
repDOdd7Cat3FMatrixFunction[4, 4, 3, 2] = {{(-1)^(2/7)}}
 
repDOdd7Cat3FMatrixFunction[4, 4, 3, 3] = 
   {{(-1)^(2/7)/Sqrt[2], (-1)^(2/7)/Sqrt[2]}, {1/Sqrt[2], -(1/Sqrt[2])}}
 
repDOdd7Cat3FMatrixFunction[4, 4, 3, 4] = {{-(-1)^(5/7)}}
 
repDOdd7Cat3FMatrixFunction[4, 4, 4, 3] = {{(-1)^(2/7)}}
 
repDOdd7Cat3FMatrixFunction[4, 4, 4, 4] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {1/2, -1/2, -(1/Sqrt[2])}, {1/Sqrt[2], 1/Sqrt[2], 0}}
 
repDOdd7Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repDOdd7Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
repDOdd7Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repDOdd7Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[repDOdd7Cat3Piv1] ^= {}
 
fusionCategory[repDOdd7Cat3Piv1] ^= repDOdd7Cat3
 
repDOdd7Cat3Piv1 /: modularCategory[repDOdd7Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repDOdd7Cat3Piv1] ^= repDOdd7Cat3Piv1
 
pivotalIsomorphism[repDOdd7Cat3Piv1] ^= repDOdd7Cat3Piv1PivotalIsomorphism
 
ring[repDOdd7Cat3Piv1] ^= repDOdd7
 
sphericalCategory[repDOdd7Cat3Piv1] ^= repDOdd7Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[repDOdd7Cat3]][pivotalCategory[#1]] & )[
    repDOdd7Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[repDOdd7Cat3]][
      sphericalCategory[#1]] & )[repDOdd7Cat3Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[repDOdd7Cat3Piv1PivotalIsomorphism] ^= repDOdd7Cat3
 
pivotalCategory[repDOdd7Cat3Piv1PivotalIsomorphism] ^= repDOdd7Cat3Piv1
 
pivotalIsomorphism[repDOdd7Cat3Piv1PivotalIsomorphism] ^= 
   repDOdd7Cat3Piv1PivotalIsomorphism
 
repDOdd7Cat3Piv1PivotalIsomorphism[0] = 1
 
repDOdd7Cat3Piv1PivotalIsomorphism[1] = 1
 
repDOdd7Cat3Piv1PivotalIsomorphism[2] = 1
 
repDOdd7Cat3Piv1PivotalIsomorphism[3] = 1
 
repDOdd7Cat3Piv1PivotalIsomorphism[4] = 1
ring[repDOdd7NFunction] ^= repDOdd7
 
repDOdd7NFunction[0, 0, 0] = 1
 
repDOdd7NFunction[0, 0, 1] = 0
 
repDOdd7NFunction[0, 0, 2] = 0
 
repDOdd7NFunction[0, 0, 3] = 0
 
repDOdd7NFunction[0, 0, 4] = 0
 
repDOdd7NFunction[0, 1, 0] = 0
 
repDOdd7NFunction[0, 1, 1] = 1
 
repDOdd7NFunction[0, 1, 2] = 0
 
repDOdd7NFunction[0, 1, 3] = 0
 
repDOdd7NFunction[0, 1, 4] = 0
 
repDOdd7NFunction[0, 2, 0] = 0
 
repDOdd7NFunction[0, 2, 1] = 0
 
repDOdd7NFunction[0, 2, 2] = 1
 
repDOdd7NFunction[0, 2, 3] = 0
 
repDOdd7NFunction[0, 2, 4] = 0
 
repDOdd7NFunction[0, 3, 0] = 0
 
repDOdd7NFunction[0, 3, 1] = 0
 
repDOdd7NFunction[0, 3, 2] = 0
 
repDOdd7NFunction[0, 3, 3] = 1
 
repDOdd7NFunction[0, 3, 4] = 0
 
repDOdd7NFunction[0, 4, 0] = 0
 
repDOdd7NFunction[0, 4, 1] = 0
 
repDOdd7NFunction[0, 4, 2] = 0
 
repDOdd7NFunction[0, 4, 3] = 0
 
repDOdd7NFunction[0, 4, 4] = 1
 
repDOdd7NFunction[1, 0, 0] = 0
 
repDOdd7NFunction[1, 0, 1] = 1
 
repDOdd7NFunction[1, 0, 2] = 0
 
repDOdd7NFunction[1, 0, 3] = 0
 
repDOdd7NFunction[1, 0, 4] = 0
 
repDOdd7NFunction[1, 1, 0] = 1
 
repDOdd7NFunction[1, 1, 1] = 0
 
repDOdd7NFunction[1, 1, 2] = 0
 
repDOdd7NFunction[1, 1, 3] = 0
 
repDOdd7NFunction[1, 1, 4] = 0
 
repDOdd7NFunction[1, 2, 0] = 0
 
repDOdd7NFunction[1, 2, 1] = 0
 
repDOdd7NFunction[1, 2, 2] = 1
 
repDOdd7NFunction[1, 2, 3] = 0
 
repDOdd7NFunction[1, 2, 4] = 0
 
repDOdd7NFunction[1, 3, 0] = 0
 
repDOdd7NFunction[1, 3, 1] = 0
 
repDOdd7NFunction[1, 3, 2] = 0
 
repDOdd7NFunction[1, 3, 3] = 1
 
repDOdd7NFunction[1, 3, 4] = 0
 
repDOdd7NFunction[1, 4, 0] = 0
 
repDOdd7NFunction[1, 4, 1] = 0
 
repDOdd7NFunction[1, 4, 2] = 0
 
repDOdd7NFunction[1, 4, 3] = 0
 
repDOdd7NFunction[1, 4, 4] = 1
 
repDOdd7NFunction[2, 0, 0] = 0
 
repDOdd7NFunction[2, 0, 1] = 0
 
repDOdd7NFunction[2, 0, 2] = 1
 
repDOdd7NFunction[2, 0, 3] = 0
 
repDOdd7NFunction[2, 0, 4] = 0
 
repDOdd7NFunction[2, 1, 0] = 0
 
repDOdd7NFunction[2, 1, 1] = 0
 
repDOdd7NFunction[2, 1, 2] = 1
 
repDOdd7NFunction[2, 1, 3] = 0
 
repDOdd7NFunction[2, 1, 4] = 0
 
repDOdd7NFunction[2, 2, 0] = 1
 
repDOdd7NFunction[2, 2, 1] = 1
 
repDOdd7NFunction[2, 2, 2] = 0
 
repDOdd7NFunction[2, 2, 3] = 1
 
repDOdd7NFunction[2, 2, 4] = 0
 
repDOdd7NFunction[2, 3, 0] = 0
 
repDOdd7NFunction[2, 3, 1] = 0
 
repDOdd7NFunction[2, 3, 2] = 1
 
repDOdd7NFunction[2, 3, 3] = 0
 
repDOdd7NFunction[2, 3, 4] = 1
 
repDOdd7NFunction[2, 4, 0] = 0
 
repDOdd7NFunction[2, 4, 1] = 0
 
repDOdd7NFunction[2, 4, 2] = 0
 
repDOdd7NFunction[2, 4, 3] = 1
 
repDOdd7NFunction[2, 4, 4] = 1
 
repDOdd7NFunction[3, 0, 0] = 0
 
repDOdd7NFunction[3, 0, 1] = 0
 
repDOdd7NFunction[3, 0, 2] = 0
 
repDOdd7NFunction[3, 0, 3] = 1
 
repDOdd7NFunction[3, 0, 4] = 0
 
repDOdd7NFunction[3, 1, 0] = 0
 
repDOdd7NFunction[3, 1, 1] = 0
 
repDOdd7NFunction[3, 1, 2] = 0
 
repDOdd7NFunction[3, 1, 3] = 1
 
repDOdd7NFunction[3, 1, 4] = 0
 
repDOdd7NFunction[3, 2, 0] = 0
 
repDOdd7NFunction[3, 2, 1] = 0
 
repDOdd7NFunction[3, 2, 2] = 1
 
repDOdd7NFunction[3, 2, 3] = 0
 
repDOdd7NFunction[3, 2, 4] = 1
 
repDOdd7NFunction[3, 3, 0] = 1
 
repDOdd7NFunction[3, 3, 1] = 1
 
repDOdd7NFunction[3, 3, 2] = 0
 
repDOdd7NFunction[3, 3, 3] = 0
 
repDOdd7NFunction[3, 3, 4] = 1
 
repDOdd7NFunction[3, 4, 0] = 0
 
repDOdd7NFunction[3, 4, 1] = 0
 
repDOdd7NFunction[3, 4, 2] = 1
 
repDOdd7NFunction[3, 4, 3] = 1
 
repDOdd7NFunction[3, 4, 4] = 0
 
repDOdd7NFunction[4, 0, 0] = 0
 
repDOdd7NFunction[4, 0, 1] = 0
 
repDOdd7NFunction[4, 0, 2] = 0
 
repDOdd7NFunction[4, 0, 3] = 0
 
repDOdd7NFunction[4, 0, 4] = 1
 
repDOdd7NFunction[4, 1, 0] = 0
 
repDOdd7NFunction[4, 1, 1] = 0
 
repDOdd7NFunction[4, 1, 2] = 0
 
repDOdd7NFunction[4, 1, 3] = 0
 
repDOdd7NFunction[4, 1, 4] = 1
 
repDOdd7NFunction[4, 2, 0] = 0
 
repDOdd7NFunction[4, 2, 1] = 0
 
repDOdd7NFunction[4, 2, 2] = 0
 
repDOdd7NFunction[4, 2, 3] = 1
 
repDOdd7NFunction[4, 2, 4] = 1
 
repDOdd7NFunction[4, 3, 0] = 0
 
repDOdd7NFunction[4, 3, 1] = 0
 
repDOdd7NFunction[4, 3, 2] = 1
 
repDOdd7NFunction[4, 3, 3] = 1
 
repDOdd7NFunction[4, 3, 4] = 0
 
repDOdd7NFunction[4, 4, 0] = 1
 
repDOdd7NFunction[4, 4, 1] = 1
 
repDOdd7NFunction[4, 4, 2] = 1
 
repDOdd7NFunction[4, 4, 3] = 0
 
repDOdd7NFunction[4, 4, 4] = 0
 
repDOdd7NFunction[a_, b_, c_] := 0


 EndPackage[]