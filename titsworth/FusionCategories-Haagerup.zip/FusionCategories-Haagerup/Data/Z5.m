BeginPackage["FusionCategories`Data`Z5`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[Z5] ^= {Z5Cat1, Z5Cat2, Z5Cat3, Z5Cat4, Z5Cat5}
 
Z5 /: fusionCategory[Z5, 1] = Z5Cat1
 
Z5 /: fusionCategory[Z5, 2] = Z5Cat2
 
Z5 /: fusionCategory[Z5, 3] = Z5Cat3
 
Z5 /: fusionCategory[Z5, 4] = Z5Cat4
 
Z5 /: fusionCategory[Z5, 5] = Z5Cat5
 
nFunction[Z5] ^= Z5NFunction
 
noMultiplicities[Z5] ^= True
 
rank[Z5] ^= 5
 
ring[Z5] ^= Z5
balancedCategories[Z5Cat1] ^= {Z5Cat1Bal1, Z5Cat1Bal2, Z5Cat1Bal3, 
    Z5Cat1Bal4, Z5Cat1Bal5, Z5Cat1Bal6, Z5Cat1Bal7, Z5Cat1Bal8, Z5Cat1Bal9, 
    Z5Cat1Bal10, Z5Cat1Bal11, Z5Cat1Bal12, Z5Cat1Bal13, Z5Cat1Bal14, 
    Z5Cat1Bal15, Z5Cat1Bal16, Z5Cat1Bal17, Z5Cat1Bal18, Z5Cat1Bal19, 
    Z5Cat1Bal20, Z5Cat1Bal21, Z5Cat1Bal22, Z5Cat1Bal23, Z5Cat1Bal24, 
    Z5Cat1Bal25}
 
Z5Cat1 /: balancedCategory[Z5Cat1, 1] = Z5Cat1Bal1
 
Z5Cat1 /: balancedCategory[Z5Cat1, 2] = Z5Cat1Bal2
 
Z5Cat1 /: balancedCategory[Z5Cat1, 3] = Z5Cat1Bal3
 
Z5Cat1 /: balancedCategory[Z5Cat1, 4] = Z5Cat1Bal4
 
Z5Cat1 /: balancedCategory[Z5Cat1, 5] = Z5Cat1Bal5
 
Z5Cat1 /: balancedCategory[Z5Cat1, 6] = Z5Cat1Bal6
 
Z5Cat1 /: balancedCategory[Z5Cat1, 7] = Z5Cat1Bal7
 
Z5Cat1 /: balancedCategory[Z5Cat1, 8] = Z5Cat1Bal8
 
Z5Cat1 /: balancedCategory[Z5Cat1, 9] = Z5Cat1Bal9
 
Z5Cat1 /: balancedCategory[Z5Cat1, 10] = Z5Cat1Bal10
 
Z5Cat1 /: balancedCategory[Z5Cat1, 11] = Z5Cat1Bal11
 
Z5Cat1 /: balancedCategory[Z5Cat1, 12] = Z5Cat1Bal12
 
Z5Cat1 /: balancedCategory[Z5Cat1, 13] = Z5Cat1Bal13
 
Z5Cat1 /: balancedCategory[Z5Cat1, 14] = Z5Cat1Bal14
 
Z5Cat1 /: balancedCategory[Z5Cat1, 15] = Z5Cat1Bal15
 
Z5Cat1 /: balancedCategory[Z5Cat1, 16] = Z5Cat1Bal16
 
Z5Cat1 /: balancedCategory[Z5Cat1, 17] = Z5Cat1Bal17
 
Z5Cat1 /: balancedCategory[Z5Cat1, 18] = Z5Cat1Bal18
 
Z5Cat1 /: balancedCategory[Z5Cat1, 19] = Z5Cat1Bal19
 
Z5Cat1 /: balancedCategory[Z5Cat1, 20] = Z5Cat1Bal20
 
Z5Cat1 /: balancedCategory[Z5Cat1, 21] = Z5Cat1Bal21
 
Z5Cat1 /: balancedCategory[Z5Cat1, 22] = Z5Cat1Bal22
 
Z5Cat1 /: balancedCategory[Z5Cat1, 23] = Z5Cat1Bal23
 
Z5Cat1 /: balancedCategory[Z5Cat1, 24] = Z5Cat1Bal24
 
Z5Cat1 /: balancedCategory[Z5Cat1, 25] = Z5Cat1Bal25
 
braidedCategories[Z5Cat1] ^= {Z5Cat1Brd1, Z5Cat1Brd2, Z5Cat1Brd3, Z5Cat1Brd4, 
    Z5Cat1Brd5}
 
Z5Cat1 /: braidedCategory[Z5Cat1, 1] = Z5Cat1Brd1
 
Z5Cat1 /: braidedCategory[Z5Cat1, 2] = Z5Cat1Brd2
 
Z5Cat1 /: braidedCategory[Z5Cat1, 3] = Z5Cat1Brd3
 
Z5Cat1 /: braidedCategory[Z5Cat1, 4] = Z5Cat1Brd4
 
Z5Cat1 /: braidedCategory[Z5Cat1, 5] = Z5Cat1Brd5
 
coeval[Z5Cat1] ^= 1/sixJFunction[Z5Cat1][#1, dual[ring[Z5Cat1]][#1], #1, #1, 
      0, 0] & 
 
eval[Z5Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[Z5Cat1] ^= Z5Cat1FMatrixFunction
 
fusionCategory[Z5Cat1] ^= Z5Cat1
 
Z5Cat1 /: modularCategory[Z5Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[Z5Cat1] ^= {Z5Cat1Piv1, Z5Cat1Piv2, Z5Cat1Piv3, Z5Cat1Piv4, 
    Z5Cat1Piv5}
 
Z5Cat1 /: pivotalCategory[Z5Cat1, 1] = Z5Cat1Piv1
 
Z5Cat1 /: pivotalCategory[Z5Cat1, 2] = Z5Cat1Piv2
 
Z5Cat1 /: pivotalCategory[Z5Cat1, 3] = Z5Cat1Piv3
 
Z5Cat1 /: pivotalCategory[Z5Cat1, 4] = Z5Cat1Piv4
 
Z5Cat1 /: pivotalCategory[Z5Cat1, 5] = Z5Cat1Piv5
 
Z5Cat1 /: pivotalCategory[Z5Cat1, {1, 1, 1, 1, 1}] = Z5Cat1Piv1
 
Z5Cat1 /: pivotalCategory[Z5Cat1, {1, -(-1)^(1/5), (-1)^(2/5), -(-1)^(3/5), 
      (-1)^(4/5)}] = Z5Cat1Piv3
 
Z5Cat1 /: pivotalCategory[Z5Cat1, {1, (-1)^(2/5), (-1)^(4/5), -(-1)^(1/5), 
      -(-1)^(3/5)}] = Z5Cat1Piv5
 
Z5Cat1 /: pivotalCategory[Z5Cat1, {1, -(-1)^(3/5), -(-1)^(1/5), (-1)^(4/5), 
      (-1)^(2/5)}] = Z5Cat1Piv2
 
Z5Cat1 /: pivotalCategory[Z5Cat1, {1, (-1)^(4/5), -(-1)^(3/5), (-1)^(2/5), 
      -(-1)^(1/5)}] = Z5Cat1Piv4
 
Z5Cat1 /: ribbonCategory[Z5Cat1, 1] = Z5Cat1Bal1
 
Z5Cat1 /: ribbonCategory[Z5Cat1, 2] = Z5Cat1Bal6
 
Z5Cat1 /: ribbonCategory[Z5Cat1, 3] = Z5Cat1Bal11
 
Z5Cat1 /: ribbonCategory[Z5Cat1, 4] = Z5Cat1Bal16
 
Z5Cat1 /: ribbonCategory[Z5Cat1, 5] = Z5Cat1Bal21
 
ring[Z5Cat1] ^= Z5
 
Z5Cat1 /: sphericalCategory[Z5Cat1, 1] = Z5Cat1Piv1
 
Z5Cat1 /: symmetricCategory[Z5Cat1, 1] = Z5Cat1Brd1
 
fusionCategoryIndex[Z5][Z5Cat1] ^= 1
balancedCategory[Z5Cat1Bal1] ^= Z5Cat1Bal1
 
braidedCategory[Z5Cat1Bal1] ^= Z5Cat1Brd1
 
coeval[Z5Cat1Bal1] ^= 1/sixJFunction[Z5Cat1][#1, dual[ring[Z5Cat1]][#1], #1, 
      #1, 0, 0] & 
 
fusionCategory[Z5Cat1Bal1] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal1] ^= Z5Cat1Piv1
 
ribbonCategory[Z5Cat1Bal1] ^= Z5Cat1Bal1
 
ring[Z5Cat1Bal1] ^= Z5
 
sphericalCategory[Z5Cat1Bal1] ^= Z5Cat1Piv1
 
symmetricCategory[Z5Cat1Bal1] ^= Z5Cat1Brd1
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd1]][balancedCategory[#1]] & )[
    Z5Cat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv1]][balancedCategory[#1]] & )[
    Z5Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[Z5Cat1Brd1]][ribbonCategory[#1]] & )[
    Z5Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z5Cat1]][ribbonCategory[#1]] & )[
    Z5Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[Z5Cat1Piv1]][ribbonCategory[#1]] & )[
    Z5Cat1Bal1] ^= 1
balancedCategory[Z5Cat1Bal10] ^= Z5Cat1Bal10
 
braidedCategory[Z5Cat1Bal10] ^= Z5Cat1Brd2
 
coeval[Z5Cat1Bal10] ^= 
   ((-1)^(2/5))^#1*FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv5][
      #1] & 
 
fusionCategory[Z5Cat1Bal10] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal10] ^= Z5Cat1Piv5
 
ribbonCategory[Z5Cat1Bal10] ^= Z5Cat1Bal10
 
ring[Z5Cat1Bal10] ^= Z5
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd2]][balancedCategory[#1]] & )[
    Z5Cat1Bal10] ^= 5
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal10] ^= 10
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv5]][balancedCategory[#1]] & )[
    Z5Cat1Bal10] ^= 2
balancedCategory[Z5Cat1Bal11] ^= Z5Cat1Bal11
 
braidedCategory[Z5Cat1Bal11] ^= Z5Cat1Brd3
 
coeval[Z5Cat1Bal11] ^= 1/sixJFunction[Z5Cat1][#1, dual[ring[Z5Cat1]][#1], #1, 
      #1, 0, 0] & 
 
fusionCategory[Z5Cat1Bal11] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal11] ^= Z5Cat1Piv1
 
ribbonCategory[Z5Cat1Bal11] ^= Z5Cat1Bal11
 
ring[Z5Cat1Bal11] ^= Z5
 
sphericalCategory[Z5Cat1Bal11] ^= Z5Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd3]][balancedCategory[#1]] & )[
    Z5Cat1Bal11] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal11] ^= 11
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv1]][balancedCategory[#1]] & )[
    Z5Cat1Bal11] ^= 3
 
(ribbonCategoryIndex[braidedCategory[Z5Cat1Brd3]][ribbonCategory[#1]] & )[
    Z5Cat1Bal11] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z5Cat1]][ribbonCategory[#1]] & )[
    Z5Cat1Bal11] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[Z5Cat1Piv1]][ribbonCategory[#1]] & )[
    Z5Cat1Bal11] ^= 3
balancedCategory[Z5Cat1Bal12] ^= Z5Cat1Bal12
 
braidedCategory[Z5Cat1Bal12] ^= Z5Cat1Brd3
 
coeval[Z5Cat1Bal12] ^= 
   (-(-1)^(3/5))^#1*FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv2][
      #1] & 
 
fusionCategory[Z5Cat1Bal12] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal12] ^= Z5Cat1Piv2
 
ribbonCategory[Z5Cat1Bal12] ^= Z5Cat1Bal12
 
ring[Z5Cat1Bal12] ^= Z5
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd3]][balancedCategory[#1]] & )[
    Z5Cat1Bal12] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal12] ^= 12
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv2]][balancedCategory[#1]] & )[
    Z5Cat1Bal12] ^= 3
balancedCategory[Z5Cat1Bal13] ^= Z5Cat1Bal13
 
braidedCategory[Z5Cat1Bal13] ^= Z5Cat1Brd3
 
coeval[Z5Cat1Bal13] ^= 
   (-(-1)^(1/5))^#1*FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv3][
      #1] & 
 
fusionCategory[Z5Cat1Bal13] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal13] ^= Z5Cat1Piv3
 
ribbonCategory[Z5Cat1Bal13] ^= Z5Cat1Bal13
 
ring[Z5Cat1Bal13] ^= Z5
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd3]][balancedCategory[#1]] & )[
    Z5Cat1Bal13] ^= 3
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal13] ^= 13
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv3]][balancedCategory[#1]] & )[
    Z5Cat1Bal13] ^= 3
balancedCategory[Z5Cat1Bal14] ^= Z5Cat1Bal14
 
braidedCategory[Z5Cat1Bal14] ^= Z5Cat1Brd3
 
coeval[Z5Cat1Bal14] ^= 
   ((-1)^(4/5))^#1*FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv4][
      #1] & 
 
fusionCategory[Z5Cat1Bal14] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal14] ^= Z5Cat1Piv4
 
ribbonCategory[Z5Cat1Bal14] ^= Z5Cat1Bal14
 
ring[Z5Cat1Bal14] ^= Z5
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd3]][balancedCategory[#1]] & )[
    Z5Cat1Bal14] ^= 4
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal14] ^= 14
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv4]][balancedCategory[#1]] & )[
    Z5Cat1Bal14] ^= 3
balancedCategory[Z5Cat1Bal15] ^= Z5Cat1Bal15
 
braidedCategory[Z5Cat1Bal15] ^= Z5Cat1Brd3
 
coeval[Z5Cat1Bal15] ^= 
   ((-1)^(2/5))^#1*FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv5][
      #1] & 
 
fusionCategory[Z5Cat1Bal15] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal15] ^= Z5Cat1Piv5
 
ribbonCategory[Z5Cat1Bal15] ^= Z5Cat1Bal15
 
ring[Z5Cat1Bal15] ^= Z5
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd3]][balancedCategory[#1]] & )[
    Z5Cat1Bal15] ^= 5
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal15] ^= 15
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv5]][balancedCategory[#1]] & )[
    Z5Cat1Bal15] ^= 3
balancedCategory[Z5Cat1Bal16] ^= Z5Cat1Bal16
 
braidedCategory[Z5Cat1Bal16] ^= Z5Cat1Brd4
 
coeval[Z5Cat1Bal16] ^= 1/sixJFunction[Z5Cat1][#1, dual[ring[Z5Cat1]][#1], #1, 
      #1, 0, 0] & 
 
fusionCategory[Z5Cat1Bal16] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal16] ^= Z5Cat1Piv1
 
ribbonCategory[Z5Cat1Bal16] ^= Z5Cat1Bal16
 
ring[Z5Cat1Bal16] ^= Z5
 
sphericalCategory[Z5Cat1Bal16] ^= Z5Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd4]][balancedCategory[#1]] & )[
    Z5Cat1Bal16] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal16] ^= 16
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv1]][balancedCategory[#1]] & )[
    Z5Cat1Bal16] ^= 4
 
(ribbonCategoryIndex[braidedCategory[Z5Cat1Brd4]][ribbonCategory[#1]] & )[
    Z5Cat1Bal16] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z5Cat1]][ribbonCategory[#1]] & )[
    Z5Cat1Bal16] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[Z5Cat1Piv1]][ribbonCategory[#1]] & )[
    Z5Cat1Bal16] ^= 4
balancedCategory[Z5Cat1Bal17] ^= Z5Cat1Bal17
 
braidedCategory[Z5Cat1Bal17] ^= Z5Cat1Brd4
 
coeval[Z5Cat1Bal17] ^= 
   (-(-1)^(3/5))^#1*FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv2][
      #1] & 
 
fusionCategory[Z5Cat1Bal17] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal17] ^= Z5Cat1Piv2
 
ribbonCategory[Z5Cat1Bal17] ^= Z5Cat1Bal17
 
ring[Z5Cat1Bal17] ^= Z5
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd4]][balancedCategory[#1]] & )[
    Z5Cat1Bal17] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal17] ^= 17
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv2]][balancedCategory[#1]] & )[
    Z5Cat1Bal17] ^= 4
balancedCategory[Z5Cat1Bal18] ^= Z5Cat1Bal18
 
braidedCategory[Z5Cat1Bal18] ^= Z5Cat1Brd4
 
coeval[Z5Cat1Bal18] ^= 
   (-(-1)^(1/5))^#1*FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv3][
      #1] & 
 
fusionCategory[Z5Cat1Bal18] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal18] ^= Z5Cat1Piv3
 
ribbonCategory[Z5Cat1Bal18] ^= Z5Cat1Bal18
 
ring[Z5Cat1Bal18] ^= Z5
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd4]][balancedCategory[#1]] & )[
    Z5Cat1Bal18] ^= 3
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal18] ^= 18
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv3]][balancedCategory[#1]] & )[
    Z5Cat1Bal18] ^= 4
balancedCategory[Z5Cat1Bal19] ^= Z5Cat1Bal19
 
braidedCategory[Z5Cat1Bal19] ^= Z5Cat1Brd4
 
coeval[Z5Cat1Bal19] ^= 
   ((-1)^(4/5))^#1*FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv4][
      #1] & 
 
fusionCategory[Z5Cat1Bal19] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal19] ^= Z5Cat1Piv4
 
ribbonCategory[Z5Cat1Bal19] ^= Z5Cat1Bal19
 
ring[Z5Cat1Bal19] ^= Z5
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd4]][balancedCategory[#1]] & )[
    Z5Cat1Bal19] ^= 4
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal19] ^= 19
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv4]][balancedCategory[#1]] & )[
    Z5Cat1Bal19] ^= 4
balancedCategory[Z5Cat1Bal2] ^= Z5Cat1Bal2
 
braidedCategory[Z5Cat1Bal2] ^= Z5Cat1Brd1
 
coeval[Z5Cat1Bal2] ^= (-(-1)^(3/5))^#1*
     FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv2][#1] & 
 
fusionCategory[Z5Cat1Bal2] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal2] ^= Z5Cat1Piv2
 
ribbonCategory[Z5Cat1Bal2] ^= Z5Cat1Bal2
 
ring[Z5Cat1Bal2] ^= Z5
 
symmetricCategory[Z5Cat1Bal2] ^= Z5Cat1Brd1
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd1]][balancedCategory[#1]] & )[
    Z5Cat1Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv2]][balancedCategory[#1]] & )[
    Z5Cat1Bal2] ^= 1
balancedCategory[Z5Cat1Bal20] ^= Z5Cat1Bal20
 
braidedCategory[Z5Cat1Bal20] ^= Z5Cat1Brd4
 
coeval[Z5Cat1Bal20] ^= 
   ((-1)^(2/5))^#1*FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv5][
      #1] & 
 
fusionCategory[Z5Cat1Bal20] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal20] ^= Z5Cat1Piv5
 
ribbonCategory[Z5Cat1Bal20] ^= Z5Cat1Bal20
 
ring[Z5Cat1Bal20] ^= Z5
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd4]][balancedCategory[#1]] & )[
    Z5Cat1Bal20] ^= 5
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal20] ^= 20
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv5]][balancedCategory[#1]] & )[
    Z5Cat1Bal20] ^= 4
balancedCategory[Z5Cat1Bal21] ^= Z5Cat1Bal21
 
braidedCategory[Z5Cat1Bal21] ^= Z5Cat1Brd5
 
coeval[Z5Cat1Bal21] ^= 1/sixJFunction[Z5Cat1][#1, dual[ring[Z5Cat1]][#1], #1, 
      #1, 0, 0] & 
 
fusionCategory[Z5Cat1Bal21] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal21] ^= Z5Cat1Piv1
 
ribbonCategory[Z5Cat1Bal21] ^= Z5Cat1Bal21
 
ring[Z5Cat1Bal21] ^= Z5
 
sphericalCategory[Z5Cat1Bal21] ^= Z5Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd5]][balancedCategory[#1]] & )[
    Z5Cat1Bal21] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal21] ^= 21
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv1]][balancedCategory[#1]] & )[
    Z5Cat1Bal21] ^= 5
 
(ribbonCategoryIndex[braidedCategory[Z5Cat1Brd5]][ribbonCategory[#1]] & )[
    Z5Cat1Bal21] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z5Cat1]][ribbonCategory[#1]] & )[
    Z5Cat1Bal21] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[Z5Cat1Piv1]][ribbonCategory[#1]] & )[
    Z5Cat1Bal21] ^= 5
balancedCategory[Z5Cat1Bal22] ^= Z5Cat1Bal22
 
braidedCategory[Z5Cat1Bal22] ^= Z5Cat1Brd5
 
coeval[Z5Cat1Bal22] ^= 
   (-(-1)^(3/5))^#1*FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv2][
      #1] & 
 
fusionCategory[Z5Cat1Bal22] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal22] ^= Z5Cat1Piv2
 
ribbonCategory[Z5Cat1Bal22] ^= Z5Cat1Bal22
 
ring[Z5Cat1Bal22] ^= Z5
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd5]][balancedCategory[#1]] & )[
    Z5Cat1Bal22] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal22] ^= 22
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv2]][balancedCategory[#1]] & )[
    Z5Cat1Bal22] ^= 5
balancedCategory[Z5Cat1Bal23] ^= Z5Cat1Bal23
 
braidedCategory[Z5Cat1Bal23] ^= Z5Cat1Brd5
 
coeval[Z5Cat1Bal23] ^= 
   (-(-1)^(1/5))^#1*FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv3][
      #1] & 
 
fusionCategory[Z5Cat1Bal23] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal23] ^= Z5Cat1Piv3
 
ribbonCategory[Z5Cat1Bal23] ^= Z5Cat1Bal23
 
ring[Z5Cat1Bal23] ^= Z5
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd5]][balancedCategory[#1]] & )[
    Z5Cat1Bal23] ^= 3
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal23] ^= 23
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv3]][balancedCategory[#1]] & )[
    Z5Cat1Bal23] ^= 5
balancedCategory[Z5Cat1Bal24] ^= Z5Cat1Bal24
 
braidedCategory[Z5Cat1Bal24] ^= Z5Cat1Brd5
 
coeval[Z5Cat1Bal24] ^= 
   ((-1)^(4/5))^#1*FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv4][
      #1] & 
 
fusionCategory[Z5Cat1Bal24] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal24] ^= Z5Cat1Piv4
 
ribbonCategory[Z5Cat1Bal24] ^= Z5Cat1Bal24
 
ring[Z5Cat1Bal24] ^= Z5
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd5]][balancedCategory[#1]] & )[
    Z5Cat1Bal24] ^= 4
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal24] ^= 24
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv4]][balancedCategory[#1]] & )[
    Z5Cat1Bal24] ^= 5
balancedCategory[Z5Cat1Bal25] ^= Z5Cat1Bal25
 
braidedCategory[Z5Cat1Bal25] ^= Z5Cat1Brd5
 
coeval[Z5Cat1Bal25] ^= 
   ((-1)^(2/5))^#1*FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv5][
      #1] & 
 
fusionCategory[Z5Cat1Bal25] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal25] ^= Z5Cat1Piv5
 
ribbonCategory[Z5Cat1Bal25] ^= Z5Cat1Bal25
 
ring[Z5Cat1Bal25] ^= Z5
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd5]][balancedCategory[#1]] & )[
    Z5Cat1Bal25] ^= 5
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal25] ^= 25
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv5]][balancedCategory[#1]] & )[
    Z5Cat1Bal25] ^= 5
balancedCategory[Z5Cat1Bal3] ^= Z5Cat1Bal3
 
braidedCategory[Z5Cat1Bal3] ^= Z5Cat1Brd1
 
coeval[Z5Cat1Bal3] ^= (-(-1)^(1/5))^#1*
     FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv3][#1] & 
 
fusionCategory[Z5Cat1Bal3] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal3] ^= Z5Cat1Piv3
 
ribbonCategory[Z5Cat1Bal3] ^= Z5Cat1Bal3
 
ring[Z5Cat1Bal3] ^= Z5
 
symmetricCategory[Z5Cat1Bal3] ^= Z5Cat1Brd1
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd1]][balancedCategory[#1]] & )[
    Z5Cat1Bal3] ^= 3
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv3]][balancedCategory[#1]] & )[
    Z5Cat1Bal3] ^= 1
balancedCategory[Z5Cat1Bal4] ^= Z5Cat1Bal4
 
braidedCategory[Z5Cat1Bal4] ^= Z5Cat1Brd1
 
coeval[Z5Cat1Bal4] ^= 
   ((-1)^(4/5))^#1*FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv4][
      #1] & 
 
fusionCategory[Z5Cat1Bal4] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal4] ^= Z5Cat1Piv4
 
ribbonCategory[Z5Cat1Bal4] ^= Z5Cat1Bal4
 
ring[Z5Cat1Bal4] ^= Z5
 
symmetricCategory[Z5Cat1Bal4] ^= Z5Cat1Brd1
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd1]][balancedCategory[#1]] & )[
    Z5Cat1Bal4] ^= 4
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv4]][balancedCategory[#1]] & )[
    Z5Cat1Bal4] ^= 1
balancedCategory[Z5Cat1Bal5] ^= Z5Cat1Bal5
 
braidedCategory[Z5Cat1Bal5] ^= Z5Cat1Brd1
 
coeval[Z5Cat1Bal5] ^= 
   ((-1)^(2/5))^#1*FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv5][
      #1] & 
 
fusionCategory[Z5Cat1Bal5] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal5] ^= Z5Cat1Piv5
 
ribbonCategory[Z5Cat1Bal5] ^= Z5Cat1Bal5
 
ring[Z5Cat1Bal5] ^= Z5
 
symmetricCategory[Z5Cat1Bal5] ^= Z5Cat1Brd1
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd1]][balancedCategory[#1]] & )[
    Z5Cat1Bal5] ^= 5
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv5]][balancedCategory[#1]] & )[
    Z5Cat1Bal5] ^= 1
balancedCategory[Z5Cat1Bal6] ^= Z5Cat1Bal6
 
braidedCategory[Z5Cat1Bal6] ^= Z5Cat1Brd2
 
coeval[Z5Cat1Bal6] ^= 1/sixJFunction[Z5Cat1][#1, dual[ring[Z5Cat1]][#1], #1, 
      #1, 0, 0] & 
 
fusionCategory[Z5Cat1Bal6] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal6] ^= Z5Cat1Piv1
 
ribbonCategory[Z5Cat1Bal6] ^= Z5Cat1Bal6
 
ring[Z5Cat1Bal6] ^= Z5
 
sphericalCategory[Z5Cat1Bal6] ^= Z5Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd2]][balancedCategory[#1]] & )[
    Z5Cat1Bal6] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv1]][balancedCategory[#1]] & )[
    Z5Cat1Bal6] ^= 2
 
(ribbonCategoryIndex[braidedCategory[Z5Cat1Brd2]][ribbonCategory[#1]] & )[
    Z5Cat1Bal6] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z5Cat1]][ribbonCategory[#1]] & )[
    Z5Cat1Bal6] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[Z5Cat1Piv1]][ribbonCategory[#1]] & )[
    Z5Cat1Bal6] ^= 2
balancedCategory[Z5Cat1Bal7] ^= Z5Cat1Bal7
 
braidedCategory[Z5Cat1Bal7] ^= Z5Cat1Brd2
 
coeval[Z5Cat1Bal7] ^= (-(-1)^(3/5))^#1*
     FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv2][#1] & 
 
fusionCategory[Z5Cat1Bal7] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal7] ^= Z5Cat1Piv2
 
ribbonCategory[Z5Cat1Bal7] ^= Z5Cat1Bal7
 
ring[Z5Cat1Bal7] ^= Z5
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd2]][balancedCategory[#1]] & )[
    Z5Cat1Bal7] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv2]][balancedCategory[#1]] & )[
    Z5Cat1Bal7] ^= 2
balancedCategory[Z5Cat1Bal8] ^= Z5Cat1Bal8
 
braidedCategory[Z5Cat1Bal8] ^= Z5Cat1Brd2
 
coeval[Z5Cat1Bal8] ^= (-(-1)^(1/5))^#1*
     FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv3][#1] & 
 
fusionCategory[Z5Cat1Bal8] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal8] ^= Z5Cat1Piv3
 
ribbonCategory[Z5Cat1Bal8] ^= Z5Cat1Bal8
 
ring[Z5Cat1Bal8] ^= Z5
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd2]][balancedCategory[#1]] & )[
    Z5Cat1Bal8] ^= 3
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv3]][balancedCategory[#1]] & )[
    Z5Cat1Bal8] ^= 2
balancedCategory[Z5Cat1Bal9] ^= Z5Cat1Bal9
 
braidedCategory[Z5Cat1Bal9] ^= Z5Cat1Brd2
 
coeval[Z5Cat1Bal9] ^= 
   ((-1)^(4/5))^#1*FusionCategories`Private`defaultGaugeCoeval[Z5Cat1Piv4][
      #1] & 
 
fusionCategory[Z5Cat1Bal9] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Bal9] ^= Z5Cat1Piv4
 
ribbonCategory[Z5Cat1Bal9] ^= Z5Cat1Bal9
 
ring[Z5Cat1Bal9] ^= Z5
 
(balancedCategoryIndex[braidedCategory[Z5Cat1Brd2]][balancedCategory[#1]] & )[
    Z5Cat1Bal9] ^= 4
 
(balancedCategoryIndex[fusionCategory[Z5Cat1]][balancedCategory[#1]] & )[
    Z5Cat1Bal9] ^= 9
 
(balancedCategoryIndex[pivotalCategory[Z5Cat1Piv4]][balancedCategory[#1]] & )[
    Z5Cat1Bal9] ^= 2
balancedCategories[Z5Cat1Brd1] ^= {Z5Cat1Bal1, Z5Cat1Bal2, Z5Cat1Bal3, 
    Z5Cat1Bal4, Z5Cat1Bal5}
 
Z5Cat1Brd1 /: balancedCategory[Z5Cat1Brd1, 1] = Z5Cat1Bal1
 
Z5Cat1Brd1 /: balancedCategory[Z5Cat1Brd1, 2] = Z5Cat1Bal2
 
Z5Cat1Brd1 /: balancedCategory[Z5Cat1Brd1, 3] = Z5Cat1Bal3
 
Z5Cat1Brd1 /: balancedCategory[Z5Cat1Brd1, 4] = Z5Cat1Bal4
 
Z5Cat1Brd1 /: balancedCategory[Z5Cat1Brd1, 5] = Z5Cat1Bal5
 
braidedCategory[Z5Cat1Brd1] ^= Z5Cat1Brd1
 
fusionCategory[Z5Cat1Brd1] ^= Z5Cat1
 
Z5Cat1Brd1 /: modularCategory[Z5Cat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z5Cat1Brd1 /: ribbonCategory[Z5Cat1Brd1, 1] = Z5Cat1Bal1
 
ring[Z5Cat1Brd1] ^= Z5
 
rMatrixFunction[Z5Cat1Brd1] ^= Z5Cat1Brd1RMatrixFunction
 
symmetricCategory[Z5Cat1Brd1] ^= Z5Cat1Brd1
 
(braidedCategoryIndex[fusionCategory[Z5Cat1]][braidedCategory[#1]] & )[
    Z5Cat1Brd1] ^= 1
 
(symmetricCategoryIndex[fusionCategory[Z5Cat1]][symmetricCategory[#1]] & )[
    Z5Cat1Brd1] ^= 1
braidedCategory[Z5Cat1Brd1RMatrixFunction] ^= Z5Cat1Brd1
 
fusionCategory[Z5Cat1Brd1RMatrixFunction] ^= Z5Cat1
 
rMatrixFunction[Z5Cat1Brd1RMatrixFunction] ^= Z5Cat1Brd1RMatrixFunction
 
Z5Cat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[1, 1, 2] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[1, 2, 3] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[1, 3, 4] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[1, 4, 0] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[2, 1, 3] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[2, 2, 4] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[2, 3, 0] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[2, 4, 1] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[3, 1, 4] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[3, 2, 0] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[3, 3, 1] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[3, 4, 2] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[4, 1, 0] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[4, 2, 1] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[4, 3, 2] = {{1}}
 
Z5Cat1Brd1RMatrixFunction[4, 4, 3] = {{1}}
balancedCategories[Z5Cat1Brd2] ^= {Z5Cat1Bal6, Z5Cat1Bal7, Z5Cat1Bal8, 
    Z5Cat1Bal9, Z5Cat1Bal10}
 
Z5Cat1Brd2 /: balancedCategory[Z5Cat1Brd2, 1] = Z5Cat1Bal6
 
Z5Cat1Brd2 /: balancedCategory[Z5Cat1Brd2, 2] = Z5Cat1Bal7
 
Z5Cat1Brd2 /: balancedCategory[Z5Cat1Brd2, 3] = Z5Cat1Bal8
 
Z5Cat1Brd2 /: balancedCategory[Z5Cat1Brd2, 4] = Z5Cat1Bal9
 
Z5Cat1Brd2 /: balancedCategory[Z5Cat1Brd2, 5] = Z5Cat1Bal10
 
braidedCategory[Z5Cat1Brd2] ^= Z5Cat1Brd2
 
fusionCategory[Z5Cat1Brd2] ^= Z5Cat1
 
Z5Cat1Brd2 /: modularCategory[Z5Cat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z5Cat1Brd2 /: ribbonCategory[Z5Cat1Brd2, 1] = Z5Cat1Bal6
 
ring[Z5Cat1Brd2] ^= Z5
 
rMatrixFunction[Z5Cat1Brd2] ^= Z5Cat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[Z5Cat1]][braidedCategory[#1]] & )[
    Z5Cat1Brd2] ^= 2
braidedCategory[Z5Cat1Brd2RMatrixFunction] ^= Z5Cat1Brd2
 
fusionCategory[Z5Cat1Brd2RMatrixFunction] ^= Z5Cat1
 
rMatrixFunction[Z5Cat1Brd2RMatrixFunction] ^= Z5Cat1Brd2RMatrixFunction
 
Z5Cat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
Z5Cat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
Z5Cat1Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
Z5Cat1Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
Z5Cat1Brd2RMatrixFunction[0, 4, 4] = {{1}}
 
Z5Cat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
Z5Cat1Brd2RMatrixFunction[1, 1, 2] = {{-(-1)^(1/5)}}
 
Z5Cat1Brd2RMatrixFunction[1, 2, 3] = {{(-1)^(2/5)}}
 
Z5Cat1Brd2RMatrixFunction[1, 3, 4] = {{-(-1)^(3/5)}}
 
Z5Cat1Brd2RMatrixFunction[1, 4, 0] = {{(-1)^(4/5)}}
 
Z5Cat1Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
Z5Cat1Brd2RMatrixFunction[2, 1, 3] = {{(-1)^(2/5)}}
 
Z5Cat1Brd2RMatrixFunction[2, 2, 4] = {{(-1)^(4/5)}}
 
Z5Cat1Brd2RMatrixFunction[2, 3, 0] = {{-(-1)^(1/5)}}
 
Z5Cat1Brd2RMatrixFunction[2, 4, 1] = {{-(-1)^(3/5)}}
 
Z5Cat1Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
Z5Cat1Brd2RMatrixFunction[3, 1, 4] = {{-(-1)^(3/5)}}
 
Z5Cat1Brd2RMatrixFunction[3, 2, 0] = {{-(-1)^(1/5)}}
 
Z5Cat1Brd2RMatrixFunction[3, 3, 1] = {{(-1)^(4/5)}}
 
Z5Cat1Brd2RMatrixFunction[3, 4, 2] = {{(-1)^(2/5)}}
 
Z5Cat1Brd2RMatrixFunction[4, 0, 4] = {{1}}
 
Z5Cat1Brd2RMatrixFunction[4, 1, 0] = {{(-1)^(4/5)}}
 
Z5Cat1Brd2RMatrixFunction[4, 2, 1] = {{-(-1)^(3/5)}}
 
Z5Cat1Brd2RMatrixFunction[4, 3, 2] = {{(-1)^(2/5)}}
 
Z5Cat1Brd2RMatrixFunction[4, 4, 3] = {{-(-1)^(1/5)}}
balancedCategories[Z5Cat1Brd3] ^= {Z5Cat1Bal11, Z5Cat1Bal12, Z5Cat1Bal13, 
    Z5Cat1Bal14, Z5Cat1Bal15}
 
Z5Cat1Brd3 /: balancedCategory[Z5Cat1Brd3, 1] = Z5Cat1Bal11
 
Z5Cat1Brd3 /: balancedCategory[Z5Cat1Brd3, 2] = Z5Cat1Bal12
 
Z5Cat1Brd3 /: balancedCategory[Z5Cat1Brd3, 3] = Z5Cat1Bal13
 
Z5Cat1Brd3 /: balancedCategory[Z5Cat1Brd3, 4] = Z5Cat1Bal14
 
Z5Cat1Brd3 /: balancedCategory[Z5Cat1Brd3, 5] = Z5Cat1Bal15
 
braidedCategory[Z5Cat1Brd3] ^= Z5Cat1Brd3
 
fusionCategory[Z5Cat1Brd3] ^= Z5Cat1
 
Z5Cat1Brd3 /: modularCategory[Z5Cat1Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z5Cat1Brd3 /: ribbonCategory[Z5Cat1Brd3, 1] = Z5Cat1Bal11
 
ring[Z5Cat1Brd3] ^= Z5
 
rMatrixFunction[Z5Cat1Brd3] ^= Z5Cat1Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[Z5Cat1]][braidedCategory[#1]] & )[
    Z5Cat1Brd3] ^= 3
braidedCategory[Z5Cat1Brd3RMatrixFunction] ^= Z5Cat1Brd3
 
fusionCategory[Z5Cat1Brd3RMatrixFunction] ^= Z5Cat1
 
rMatrixFunction[Z5Cat1Brd3RMatrixFunction] ^= Z5Cat1Brd3RMatrixFunction
 
Z5Cat1Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
Z5Cat1Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
Z5Cat1Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
Z5Cat1Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
Z5Cat1Brd3RMatrixFunction[0, 4, 4] = {{1}}
 
Z5Cat1Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
Z5Cat1Brd3RMatrixFunction[1, 1, 2] = {{(-1)^(2/5)}}
 
Z5Cat1Brd3RMatrixFunction[1, 2, 3] = {{(-1)^(4/5)}}
 
Z5Cat1Brd3RMatrixFunction[1, 3, 4] = {{-(-1)^(1/5)}}
 
Z5Cat1Brd3RMatrixFunction[1, 4, 0] = {{-(-1)^(3/5)}}
 
Z5Cat1Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
Z5Cat1Brd3RMatrixFunction[2, 1, 3] = {{(-1)^(4/5)}}
 
Z5Cat1Brd3RMatrixFunction[2, 2, 4] = {{-(-1)^(3/5)}}
 
Z5Cat1Brd3RMatrixFunction[2, 3, 0] = {{(-1)^(2/5)}}
 
Z5Cat1Brd3RMatrixFunction[2, 4, 1] = {{-(-1)^(1/5)}}
 
Z5Cat1Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
Z5Cat1Brd3RMatrixFunction[3, 1, 4] = {{-(-1)^(1/5)}}
 
Z5Cat1Brd3RMatrixFunction[3, 2, 0] = {{(-1)^(2/5)}}
 
Z5Cat1Brd3RMatrixFunction[3, 3, 1] = {{-(-1)^(3/5)}}
 
Z5Cat1Brd3RMatrixFunction[3, 4, 2] = {{(-1)^(4/5)}}
 
Z5Cat1Brd3RMatrixFunction[4, 0, 4] = {{1}}
 
Z5Cat1Brd3RMatrixFunction[4, 1, 0] = {{-(-1)^(3/5)}}
 
Z5Cat1Brd3RMatrixFunction[4, 2, 1] = {{-(-1)^(1/5)}}
 
Z5Cat1Brd3RMatrixFunction[4, 3, 2] = {{(-1)^(4/5)}}
 
Z5Cat1Brd3RMatrixFunction[4, 4, 3] = {{(-1)^(2/5)}}
balancedCategories[Z5Cat1Brd4] ^= {Z5Cat1Bal16, Z5Cat1Bal17, Z5Cat1Bal18, 
    Z5Cat1Bal19, Z5Cat1Bal20}
 
Z5Cat1Brd4 /: balancedCategory[Z5Cat1Brd4, 1] = Z5Cat1Bal16
 
Z5Cat1Brd4 /: balancedCategory[Z5Cat1Brd4, 2] = Z5Cat1Bal17
 
Z5Cat1Brd4 /: balancedCategory[Z5Cat1Brd4, 3] = Z5Cat1Bal18
 
Z5Cat1Brd4 /: balancedCategory[Z5Cat1Brd4, 4] = Z5Cat1Bal19
 
Z5Cat1Brd4 /: balancedCategory[Z5Cat1Brd4, 5] = Z5Cat1Bal20
 
braidedCategory[Z5Cat1Brd4] ^= Z5Cat1Brd4
 
fusionCategory[Z5Cat1Brd4] ^= Z5Cat1
 
Z5Cat1Brd4 /: modularCategory[Z5Cat1Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z5Cat1Brd4 /: ribbonCategory[Z5Cat1Brd4, 1] = Z5Cat1Bal16
 
ring[Z5Cat1Brd4] ^= Z5
 
rMatrixFunction[Z5Cat1Brd4] ^= Z5Cat1Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[Z5Cat1]][braidedCategory[#1]] & )[
    Z5Cat1Brd4] ^= 4
braidedCategory[Z5Cat1Brd4RMatrixFunction] ^= Z5Cat1Brd4
 
fusionCategory[Z5Cat1Brd4RMatrixFunction] ^= Z5Cat1
 
rMatrixFunction[Z5Cat1Brd4RMatrixFunction] ^= Z5Cat1Brd4RMatrixFunction
 
Z5Cat1Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
Z5Cat1Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
Z5Cat1Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
Z5Cat1Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
Z5Cat1Brd4RMatrixFunction[0, 4, 4] = {{1}}
 
Z5Cat1Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
Z5Cat1Brd4RMatrixFunction[1, 1, 2] = {{-(-1)^(3/5)}}
 
Z5Cat1Brd4RMatrixFunction[1, 2, 3] = {{-(-1)^(1/5)}}
 
Z5Cat1Brd4RMatrixFunction[1, 3, 4] = {{(-1)^(4/5)}}
 
Z5Cat1Brd4RMatrixFunction[1, 4, 0] = {{(-1)^(2/5)}}
 
Z5Cat1Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
Z5Cat1Brd4RMatrixFunction[2, 1, 3] = {{-(-1)^(1/5)}}
 
Z5Cat1Brd4RMatrixFunction[2, 2, 4] = {{(-1)^(2/5)}}
 
Z5Cat1Brd4RMatrixFunction[2, 3, 0] = {{-(-1)^(3/5)}}
 
Z5Cat1Brd4RMatrixFunction[2, 4, 1] = {{(-1)^(4/5)}}
 
Z5Cat1Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
Z5Cat1Brd4RMatrixFunction[3, 1, 4] = {{(-1)^(4/5)}}
 
Z5Cat1Brd4RMatrixFunction[3, 2, 0] = {{-(-1)^(3/5)}}
 
Z5Cat1Brd4RMatrixFunction[3, 3, 1] = {{(-1)^(2/5)}}
 
Z5Cat1Brd4RMatrixFunction[3, 4, 2] = {{-(-1)^(1/5)}}
 
Z5Cat1Brd4RMatrixFunction[4, 0, 4] = {{1}}
 
Z5Cat1Brd4RMatrixFunction[4, 1, 0] = {{(-1)^(2/5)}}
 
Z5Cat1Brd4RMatrixFunction[4, 2, 1] = {{(-1)^(4/5)}}
 
Z5Cat1Brd4RMatrixFunction[4, 3, 2] = {{-(-1)^(1/5)}}
 
Z5Cat1Brd4RMatrixFunction[4, 4, 3] = {{-(-1)^(3/5)}}
balancedCategories[Z5Cat1Brd5] ^= {Z5Cat1Bal21, Z5Cat1Bal22, Z5Cat1Bal23, 
    Z5Cat1Bal24, Z5Cat1Bal25}
 
Z5Cat1Brd5 /: balancedCategory[Z5Cat1Brd5, 1] = Z5Cat1Bal21
 
Z5Cat1Brd5 /: balancedCategory[Z5Cat1Brd5, 2] = Z5Cat1Bal22
 
Z5Cat1Brd5 /: balancedCategory[Z5Cat1Brd5, 3] = Z5Cat1Bal23
 
Z5Cat1Brd5 /: balancedCategory[Z5Cat1Brd5, 4] = Z5Cat1Bal24
 
Z5Cat1Brd5 /: balancedCategory[Z5Cat1Brd5, 5] = Z5Cat1Bal25
 
braidedCategory[Z5Cat1Brd5] ^= Z5Cat1Brd5
 
fusionCategory[Z5Cat1Brd5] ^= Z5Cat1
 
Z5Cat1Brd5 /: modularCategory[Z5Cat1Brd5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z5Cat1Brd5 /: ribbonCategory[Z5Cat1Brd5, 1] = Z5Cat1Bal21
 
ring[Z5Cat1Brd5] ^= Z5
 
rMatrixFunction[Z5Cat1Brd5] ^= Z5Cat1Brd5RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[Z5Cat1]][braidedCategory[#1]] & )[
    Z5Cat1Brd5] ^= 5
braidedCategory[Z5Cat1Brd5RMatrixFunction] ^= Z5Cat1Brd5
 
fusionCategory[Z5Cat1Brd5RMatrixFunction] ^= Z5Cat1
 
rMatrixFunction[Z5Cat1Brd5RMatrixFunction] ^= Z5Cat1Brd5RMatrixFunction
 
Z5Cat1Brd5RMatrixFunction[0, 0, 0] = {{1}}
 
Z5Cat1Brd5RMatrixFunction[0, 1, 1] = {{1}}
 
Z5Cat1Brd5RMatrixFunction[0, 2, 2] = {{1}}
 
Z5Cat1Brd5RMatrixFunction[0, 3, 3] = {{1}}
 
Z5Cat1Brd5RMatrixFunction[0, 4, 4] = {{1}}
 
Z5Cat1Brd5RMatrixFunction[1, 0, 1] = {{1}}
 
Z5Cat1Brd5RMatrixFunction[1, 1, 2] = {{(-1)^(4/5)}}
 
Z5Cat1Brd5RMatrixFunction[1, 2, 3] = {{-(-1)^(3/5)}}
 
Z5Cat1Brd5RMatrixFunction[1, 3, 4] = {{(-1)^(2/5)}}
 
Z5Cat1Brd5RMatrixFunction[1, 4, 0] = {{-(-1)^(1/5)}}
 
Z5Cat1Brd5RMatrixFunction[2, 0, 2] = {{1}}
 
Z5Cat1Brd5RMatrixFunction[2, 1, 3] = {{-(-1)^(3/5)}}
 
Z5Cat1Brd5RMatrixFunction[2, 2, 4] = {{-(-1)^(1/5)}}
 
Z5Cat1Brd5RMatrixFunction[2, 3, 0] = {{(-1)^(4/5)}}
 
Z5Cat1Brd5RMatrixFunction[2, 4, 1] = {{(-1)^(2/5)}}
 
Z5Cat1Brd5RMatrixFunction[3, 0, 3] = {{1}}
 
Z5Cat1Brd5RMatrixFunction[3, 1, 4] = {{(-1)^(2/5)}}
 
Z5Cat1Brd5RMatrixFunction[3, 2, 0] = {{(-1)^(4/5)}}
 
Z5Cat1Brd5RMatrixFunction[3, 3, 1] = {{-(-1)^(1/5)}}
 
Z5Cat1Brd5RMatrixFunction[3, 4, 2] = {{-(-1)^(3/5)}}
 
Z5Cat1Brd5RMatrixFunction[4, 0, 4] = {{1}}
 
Z5Cat1Brd5RMatrixFunction[4, 1, 0] = {{-(-1)^(1/5)}}
 
Z5Cat1Brd5RMatrixFunction[4, 2, 1] = {{(-1)^(2/5)}}
 
Z5Cat1Brd5RMatrixFunction[4, 3, 2] = {{-(-1)^(3/5)}}
 
Z5Cat1Brd5RMatrixFunction[4, 4, 3] = {{(-1)^(4/5)}}
fMatrixFunction[Z5Cat1FMatrixFunction] ^= Z5Cat1FMatrixFunction
 
fusionCategory[Z5Cat1FMatrixFunction] ^= Z5Cat1
 
ring[Z5Cat1FMatrixFunction] ^= Z5
 
Z5Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z5Cat1], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
Z5Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z5Cat1], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[Z5Cat1Piv1] ^= {Z5Cat1Bal1, Z5Cat1Bal6, Z5Cat1Bal11, 
    Z5Cat1Bal16, Z5Cat1Bal21}
 
Z5Cat1Piv1 /: balancedCategory[Z5Cat1Piv1, 1] = Z5Cat1Bal1
 
Z5Cat1Piv1 /: balancedCategory[Z5Cat1Piv1, 2] = Z5Cat1Bal6
 
Z5Cat1Piv1 /: balancedCategory[Z5Cat1Piv1, 3] = Z5Cat1Bal11
 
Z5Cat1Piv1 /: balancedCategory[Z5Cat1Piv1, 4] = Z5Cat1Bal16
 
Z5Cat1Piv1 /: balancedCategory[Z5Cat1Piv1, 5] = Z5Cat1Bal21
 
fusionCategory[Z5Cat1Piv1] ^= Z5Cat1
 
Z5Cat1Piv1 /: modularCategory[Z5Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat1Piv1] ^= Z5Cat1Piv1
 
pivotalIsomorphism[Z5Cat1Piv1] ^= Z5Cat1Piv1PivotalIsomorphism
 
Z5Cat1Piv1 /: ribbonCategory[Z5Cat1Piv1, 1] = Z5Cat1Bal1
 
Z5Cat1Piv1 /: ribbonCategory[Z5Cat1Piv1, 2] = Z5Cat1Bal6
 
Z5Cat1Piv1 /: ribbonCategory[Z5Cat1Piv1, 3] = Z5Cat1Bal11
 
Z5Cat1Piv1 /: ribbonCategory[Z5Cat1Piv1, 4] = Z5Cat1Bal16
 
Z5Cat1Piv1 /: ribbonCategory[Z5Cat1Piv1, 5] = Z5Cat1Bal21
 
ring[Z5Cat1Piv1] ^= Z5
 
sphericalCategory[Z5Cat1Piv1] ^= Z5Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[Z5Cat1]][pivotalCategory[#1]] & )[
    Z5Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[Z5Cat1]][sphericalCategory[#1]] & )[
    Z5Cat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z5Cat1Piv1PivotalIsomorphism] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Piv1PivotalIsomorphism] ^= Z5Cat1Piv1
 
pivotalIsomorphism[Z5Cat1Piv1PivotalIsomorphism] ^= 
   Z5Cat1Piv1PivotalIsomorphism
 
Z5Cat1Piv1PivotalIsomorphism[0] = 1
 
Z5Cat1Piv1PivotalIsomorphism[1] = 1
 
Z5Cat1Piv1PivotalIsomorphism[2] = 1
 
Z5Cat1Piv1PivotalIsomorphism[3] = 1
 
Z5Cat1Piv1PivotalIsomorphism[4] = 1
balancedCategories[Z5Cat1Piv2] ^= {Z5Cat1Bal2, Z5Cat1Bal7, Z5Cat1Bal12, 
    Z5Cat1Bal17, Z5Cat1Bal22}
 
Z5Cat1Piv2 /: balancedCategory[Z5Cat1Piv2, 1] = Z5Cat1Bal2
 
Z5Cat1Piv2 /: balancedCategory[Z5Cat1Piv2, 2] = Z5Cat1Bal7
 
Z5Cat1Piv2 /: balancedCategory[Z5Cat1Piv2, 3] = Z5Cat1Bal12
 
Z5Cat1Piv2 /: balancedCategory[Z5Cat1Piv2, 4] = Z5Cat1Bal17
 
Z5Cat1Piv2 /: balancedCategory[Z5Cat1Piv2, 5] = Z5Cat1Bal22
 
fusionCategory[Z5Cat1Piv2] ^= Z5Cat1
 
Z5Cat1Piv2 /: modularCategory[Z5Cat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat1Piv2] ^= Z5Cat1Piv2
 
pivotalIsomorphism[Z5Cat1Piv2] ^= Z5Cat1Piv2PivotalIsomorphism
 
ring[Z5Cat1Piv2] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat1]][pivotalCategory[#1]] & )[
    Z5Cat1Piv2] ^= 2
fusionCategory[Z5Cat1Piv2PivotalIsomorphism] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Piv2PivotalIsomorphism] ^= Z5Cat1Piv2
 
pivotalIsomorphism[Z5Cat1Piv2PivotalIsomorphism] ^= 
   Z5Cat1Piv2PivotalIsomorphism
 
Z5Cat1Piv2PivotalIsomorphism[0] = 1
 
Z5Cat1Piv2PivotalIsomorphism[1] = -(-1)^(3/5)
 
Z5Cat1Piv2PivotalIsomorphism[2] = -(-1)^(1/5)
 
Z5Cat1Piv2PivotalIsomorphism[3] = (-1)^(4/5)
 
Z5Cat1Piv2PivotalIsomorphism[4] = (-1)^(2/5)
balancedCategories[Z5Cat1Piv3] ^= {Z5Cat1Bal3, Z5Cat1Bal8, Z5Cat1Bal13, 
    Z5Cat1Bal18, Z5Cat1Bal23}
 
Z5Cat1Piv3 /: balancedCategory[Z5Cat1Piv3, 1] = Z5Cat1Bal3
 
Z5Cat1Piv3 /: balancedCategory[Z5Cat1Piv3, 2] = Z5Cat1Bal8
 
Z5Cat1Piv3 /: balancedCategory[Z5Cat1Piv3, 3] = Z5Cat1Bal13
 
Z5Cat1Piv3 /: balancedCategory[Z5Cat1Piv3, 4] = Z5Cat1Bal18
 
Z5Cat1Piv3 /: balancedCategory[Z5Cat1Piv3, 5] = Z5Cat1Bal23
 
fusionCategory[Z5Cat1Piv3] ^= Z5Cat1
 
Z5Cat1Piv3 /: modularCategory[Z5Cat1Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat1Piv3] ^= Z5Cat1Piv3
 
pivotalIsomorphism[Z5Cat1Piv3] ^= Z5Cat1Piv3PivotalIsomorphism
 
ring[Z5Cat1Piv3] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat1]][pivotalCategory[#1]] & )[
    Z5Cat1Piv3] ^= 3
fusionCategory[Z5Cat1Piv3PivotalIsomorphism] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Piv3PivotalIsomorphism] ^= Z5Cat1Piv3
 
pivotalIsomorphism[Z5Cat1Piv3PivotalIsomorphism] ^= 
   Z5Cat1Piv3PivotalIsomorphism
 
Z5Cat1Piv3PivotalIsomorphism[0] = 1
 
Z5Cat1Piv3PivotalIsomorphism[1] = -(-1)^(1/5)
 
Z5Cat1Piv3PivotalIsomorphism[2] = (-1)^(2/5)
 
Z5Cat1Piv3PivotalIsomorphism[3] = -(-1)^(3/5)
 
Z5Cat1Piv3PivotalIsomorphism[4] = (-1)^(4/5)
balancedCategories[Z5Cat1Piv4] ^= {Z5Cat1Bal4, Z5Cat1Bal9, Z5Cat1Bal14, 
    Z5Cat1Bal19, Z5Cat1Bal24}
 
Z5Cat1Piv4 /: balancedCategory[Z5Cat1Piv4, 1] = Z5Cat1Bal4
 
Z5Cat1Piv4 /: balancedCategory[Z5Cat1Piv4, 2] = Z5Cat1Bal9
 
Z5Cat1Piv4 /: balancedCategory[Z5Cat1Piv4, 3] = Z5Cat1Bal14
 
Z5Cat1Piv4 /: balancedCategory[Z5Cat1Piv4, 4] = Z5Cat1Bal19
 
Z5Cat1Piv4 /: balancedCategory[Z5Cat1Piv4, 5] = Z5Cat1Bal24
 
fusionCategory[Z5Cat1Piv4] ^= Z5Cat1
 
Z5Cat1Piv4 /: modularCategory[Z5Cat1Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat1Piv4] ^= Z5Cat1Piv4
 
pivotalIsomorphism[Z5Cat1Piv4] ^= Z5Cat1Piv4PivotalIsomorphism
 
ring[Z5Cat1Piv4] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat1]][pivotalCategory[#1]] & )[
    Z5Cat1Piv4] ^= 4
fusionCategory[Z5Cat1Piv4PivotalIsomorphism] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Piv4PivotalIsomorphism] ^= Z5Cat1Piv4
 
pivotalIsomorphism[Z5Cat1Piv4PivotalIsomorphism] ^= 
   Z5Cat1Piv4PivotalIsomorphism
 
Z5Cat1Piv4PivotalIsomorphism[0] = 1
 
Z5Cat1Piv4PivotalIsomorphism[1] = (-1)^(4/5)
 
Z5Cat1Piv4PivotalIsomorphism[2] = -(-1)^(3/5)
 
Z5Cat1Piv4PivotalIsomorphism[3] = (-1)^(2/5)
 
Z5Cat1Piv4PivotalIsomorphism[4] = -(-1)^(1/5)
balancedCategories[Z5Cat1Piv5] ^= {Z5Cat1Bal5, Z5Cat1Bal10, Z5Cat1Bal15, 
    Z5Cat1Bal20, Z5Cat1Bal25}
 
Z5Cat1Piv5 /: balancedCategory[Z5Cat1Piv5, 1] = Z5Cat1Bal5
 
Z5Cat1Piv5 /: balancedCategory[Z5Cat1Piv5, 2] = Z5Cat1Bal10
 
Z5Cat1Piv5 /: balancedCategory[Z5Cat1Piv5, 3] = Z5Cat1Bal15
 
Z5Cat1Piv5 /: balancedCategory[Z5Cat1Piv5, 4] = Z5Cat1Bal20
 
Z5Cat1Piv5 /: balancedCategory[Z5Cat1Piv5, 5] = Z5Cat1Bal25
 
fusionCategory[Z5Cat1Piv5] ^= Z5Cat1
 
Z5Cat1Piv5 /: modularCategory[Z5Cat1Piv5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat1Piv5] ^= Z5Cat1Piv5
 
pivotalIsomorphism[Z5Cat1Piv5] ^= Z5Cat1Piv5PivotalIsomorphism
 
ring[Z5Cat1Piv5] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat1]][pivotalCategory[#1]] & )[
    Z5Cat1Piv5] ^= 5
fusionCategory[Z5Cat1Piv5PivotalIsomorphism] ^= Z5Cat1
 
pivotalCategory[Z5Cat1Piv5PivotalIsomorphism] ^= Z5Cat1Piv5
 
pivotalIsomorphism[Z5Cat1Piv5PivotalIsomorphism] ^= 
   Z5Cat1Piv5PivotalIsomorphism
 
Z5Cat1Piv5PivotalIsomorphism[0] = 1
 
Z5Cat1Piv5PivotalIsomorphism[1] = (-1)^(2/5)
 
Z5Cat1Piv5PivotalIsomorphism[2] = (-1)^(4/5)
 
Z5Cat1Piv5PivotalIsomorphism[3] = -(-1)^(1/5)
 
Z5Cat1Piv5PivotalIsomorphism[4] = -(-1)^(3/5)
balancedCategories[Z5Cat2] ^= {}
 
braidedCategories[Z5Cat2] ^= {}
 
coeval[Z5Cat2] ^= 1/sixJFunction[Z5Cat2][#1, dual[ring[Z5Cat2]][#1], #1, #1, 
      0, 0] & 
 
eval[Z5Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[Z5Cat2] ^= Z5Cat2FMatrixFunction
 
fusionCategory[Z5Cat2] ^= Z5Cat2
 
Z5Cat2 /: modularCategory[Z5Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[Z5Cat2] ^= {Z5Cat2Piv1, Z5Cat2Piv2, Z5Cat2Piv3, Z5Cat2Piv4, 
    Z5Cat2Piv5}
 
Z5Cat2 /: pivotalCategory[Z5Cat2, 1] = Z5Cat2Piv1
 
Z5Cat2 /: pivotalCategory[Z5Cat2, 2] = Z5Cat2Piv2
 
Z5Cat2 /: pivotalCategory[Z5Cat2, 3] = Z5Cat2Piv3
 
Z5Cat2 /: pivotalCategory[Z5Cat2, 4] = Z5Cat2Piv4
 
Z5Cat2 /: pivotalCategory[Z5Cat2, 5] = Z5Cat2Piv5
 
Z5Cat2 /: pivotalCategory[Z5Cat2, {1, 1, 1, 1, 1}] = Z5Cat2Piv1
 
Z5Cat2 /: pivotalCategory[Z5Cat2, {1, -(-1)^(1/5), (-1)^(2/5), -(-1)^(3/5), 
      (-1)^(4/5)}] = Z5Cat2Piv3
 
Z5Cat2 /: pivotalCategory[Z5Cat2, {1, (-1)^(2/5), (-1)^(4/5), -(-1)^(1/5), 
      -(-1)^(3/5)}] = Z5Cat2Piv5
 
Z5Cat2 /: pivotalCategory[Z5Cat2, {1, -(-1)^(3/5), -(-1)^(1/5), (-1)^(4/5), 
      (-1)^(2/5)}] = Z5Cat2Piv2
 
Z5Cat2 /: pivotalCategory[Z5Cat2, {1, (-1)^(4/5), -(-1)^(3/5), (-1)^(2/5), 
      -(-1)^(1/5)}] = Z5Cat2Piv4
 
ring[Z5Cat2] ^= Z5
 
Z5Cat2 /: sphericalCategory[Z5Cat2, 1] = Z5Cat2Piv5
 
fusionCategoryIndex[Z5][Z5Cat2] ^= 2
fMatrixFunction[Z5Cat2FMatrixFunction] ^= Z5Cat2FMatrixFunction
 
fusionCategory[Z5Cat2FMatrixFunction] ^= Z5Cat2
 
ring[Z5Cat2FMatrixFunction] ^= Z5
 
Z5Cat2FMatrixFunction[1, 1, 1, 3] = {{(-1)^(2/5)}}
 
Z5Cat2FMatrixFunction[1, 1, 2, 4] = {{-(-1)^(3/5)}}
 
Z5Cat2FMatrixFunction[1, 2, 1, 4] = {{(-1)^(2/5)}}
 
Z5Cat2FMatrixFunction[1, 3, 2, 1] = {{-(-1)^(3/5)}}
 
Z5Cat2FMatrixFunction[1, 3, 3, 2] = {{-(-1)^(3/5)}}
 
Z5Cat2FMatrixFunction[1, 3, 4, 3] = {{-(-1)^(3/5)}}
 
Z5Cat2FMatrixFunction[1, 4, 1, 1] = {{-(-1)^(3/5)}}
 
Z5Cat2FMatrixFunction[1, 4, 2, 2] = {{-(-1)^(3/5)}}
 
Z5Cat2FMatrixFunction[1, 4, 3, 3] = {{-(-1)^(3/5)}}
 
Z5Cat2FMatrixFunction[2, 1, 1, 4] = {{-(-1)^(3/5)}}
 
Z5Cat2FMatrixFunction[2, 1, 3, 1] = {{(-1)^(2/5)}}
 
Z5Cat2FMatrixFunction[2, 1, 4, 2] = {{(-1)^(2/5)}}
 
Z5Cat2FMatrixFunction[2, 2, 2, 1] = {{-(-1)^(1/5)}}
 
Z5Cat2FMatrixFunction[2, 2, 3, 2] = {{-(-1)^(1/5)}}
 
Z5Cat2FMatrixFunction[2, 2, 4, 3] = {{(-1)^(4/5)}}
 
Z5Cat2FMatrixFunction[2, 3, 1, 1] = {{-(-1)^(3/5)}}
 
Z5Cat2FMatrixFunction[2, 3, 2, 2] = {{-(-1)^(1/5)}}
 
Z5Cat2FMatrixFunction[2, 3, 3, 3] = {{(-1)^(4/5)}}
 
Z5Cat2FMatrixFunction[2, 4, 1, 2] = {{-(-1)^(3/5)}}
 
Z5Cat2FMatrixFunction[2, 4, 2, 3] = {{-(-1)^(1/5)}}
 
Z5Cat2FMatrixFunction[3, 1, 3, 2] = {{(-1)^(2/5)}}
 
Z5Cat2FMatrixFunction[3, 1, 4, 3] = {{(-1)^(2/5)}}
 
Z5Cat2FMatrixFunction[3, 2, 1, 1] = {{-(-1)^(3/5)}}
 
Z5Cat2FMatrixFunction[3, 2, 2, 2] = {{(-1)^(4/5)}}
 
Z5Cat2FMatrixFunction[3, 2, 3, 3] = {{(-1)^(4/5)}}
 
Z5Cat2FMatrixFunction[3, 2, 4, 4] = {{(-1)^(2/5)}}
 
Z5Cat2FMatrixFunction[3, 3, 1, 2] = {{-(-1)^(3/5)}}
 
Z5Cat2FMatrixFunction[3, 3, 2, 3] = {{-(-1)^(1/5)}}
 
Z5Cat2FMatrixFunction[3, 3, 3, 4] = {{(-1)^(2/5)}}
 
Z5Cat2FMatrixFunction[3, 4, 2, 4] = {{(-1)^(2/5)}}
 
Z5Cat2FMatrixFunction[4, 1, 3, 3] = {{(-1)^(2/5)}}
 
Z5Cat2FMatrixFunction[4, 1, 4, 4] = {{(-1)^(2/5)}}
 
Z5Cat2FMatrixFunction[4, 2, 1, 2] = {{-(-1)^(3/5)}}
 
Z5Cat2FMatrixFunction[4, 2, 2, 3] = {{(-1)^(4/5)}}
 
Z5Cat2FMatrixFunction[4, 2, 3, 4] = {{(-1)^(2/5)}}
 
Z5Cat2FMatrixFunction[4, 3, 2, 4] = {{(-1)^(2/5)}}
 
Z5Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z5Cat2], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
Z5Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z5Cat2], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[Z5Cat2Piv1] ^= {}
 
fusionCategory[Z5Cat2Piv1] ^= Z5Cat2
 
Z5Cat2Piv1 /: modularCategory[Z5Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat2Piv1] ^= Z5Cat2Piv1
 
pivotalIsomorphism[Z5Cat2Piv1] ^= Z5Cat2Piv1PivotalIsomorphism
 
ring[Z5Cat2Piv1] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat2]][pivotalCategory[#1]] & )[
    Z5Cat2Piv1] ^= 1
fusionCategory[Z5Cat2Piv1PivotalIsomorphism] ^= Z5Cat2
 
pivotalCategory[Z5Cat2Piv1PivotalIsomorphism] ^= Z5Cat2Piv1
 
pivotalIsomorphism[Z5Cat2Piv1PivotalIsomorphism] ^= 
   Z5Cat2Piv1PivotalIsomorphism
 
Z5Cat2Piv1PivotalIsomorphism[0] = 1
 
Z5Cat2Piv1PivotalIsomorphism[1] = 1
 
Z5Cat2Piv1PivotalIsomorphism[2] = 1
 
Z5Cat2Piv1PivotalIsomorphism[3] = 1
 
Z5Cat2Piv1PivotalIsomorphism[4] = 1
balancedCategories[Z5Cat2Piv2] ^= {}
 
fusionCategory[Z5Cat2Piv2] ^= Z5Cat2
 
Z5Cat2Piv2 /: modularCategory[Z5Cat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat2Piv2] ^= Z5Cat2Piv2
 
pivotalIsomorphism[Z5Cat2Piv2] ^= Z5Cat2Piv2PivotalIsomorphism
 
ring[Z5Cat2Piv2] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat2]][pivotalCategory[#1]] & )[
    Z5Cat2Piv2] ^= 2
fusionCategory[Z5Cat2Piv2PivotalIsomorphism] ^= Z5Cat2
 
pivotalCategory[Z5Cat2Piv2PivotalIsomorphism] ^= Z5Cat2Piv2
 
pivotalIsomorphism[Z5Cat2Piv2PivotalIsomorphism] ^= 
   Z5Cat2Piv2PivotalIsomorphism
 
Z5Cat2Piv2PivotalIsomorphism[0] = 1
 
Z5Cat2Piv2PivotalIsomorphism[1] = -(-1)^(3/5)
 
Z5Cat2Piv2PivotalIsomorphism[2] = -(-1)^(1/5)
 
Z5Cat2Piv2PivotalIsomorphism[3] = (-1)^(4/5)
 
Z5Cat2Piv2PivotalIsomorphism[4] = (-1)^(2/5)
balancedCategories[Z5Cat2Piv3] ^= {}
 
fusionCategory[Z5Cat2Piv3] ^= Z5Cat2
 
Z5Cat2Piv3 /: modularCategory[Z5Cat2Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat2Piv3] ^= Z5Cat2Piv3
 
pivotalIsomorphism[Z5Cat2Piv3] ^= Z5Cat2Piv3PivotalIsomorphism
 
ring[Z5Cat2Piv3] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat2]][pivotalCategory[#1]] & )[
    Z5Cat2Piv3] ^= 3
fusionCategory[Z5Cat2Piv3PivotalIsomorphism] ^= Z5Cat2
 
pivotalCategory[Z5Cat2Piv3PivotalIsomorphism] ^= Z5Cat2Piv3
 
pivotalIsomorphism[Z5Cat2Piv3PivotalIsomorphism] ^= 
   Z5Cat2Piv3PivotalIsomorphism
 
Z5Cat2Piv3PivotalIsomorphism[0] = 1
 
Z5Cat2Piv3PivotalIsomorphism[1] = -(-1)^(1/5)
 
Z5Cat2Piv3PivotalIsomorphism[2] = (-1)^(2/5)
 
Z5Cat2Piv3PivotalIsomorphism[3] = -(-1)^(3/5)
 
Z5Cat2Piv3PivotalIsomorphism[4] = (-1)^(4/5)
balancedCategories[Z5Cat2Piv4] ^= {}
 
fusionCategory[Z5Cat2Piv4] ^= Z5Cat2
 
Z5Cat2Piv4 /: modularCategory[Z5Cat2Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat2Piv4] ^= Z5Cat2Piv4
 
pivotalIsomorphism[Z5Cat2Piv4] ^= Z5Cat2Piv4PivotalIsomorphism
 
ring[Z5Cat2Piv4] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat2]][pivotalCategory[#1]] & )[
    Z5Cat2Piv4] ^= 4
fusionCategory[Z5Cat2Piv4PivotalIsomorphism] ^= Z5Cat2
 
pivotalCategory[Z5Cat2Piv4PivotalIsomorphism] ^= Z5Cat2Piv4
 
pivotalIsomorphism[Z5Cat2Piv4PivotalIsomorphism] ^= 
   Z5Cat2Piv4PivotalIsomorphism
 
Z5Cat2Piv4PivotalIsomorphism[0] = 1
 
Z5Cat2Piv4PivotalIsomorphism[1] = (-1)^(4/5)
 
Z5Cat2Piv4PivotalIsomorphism[2] = -(-1)^(3/5)
 
Z5Cat2Piv4PivotalIsomorphism[3] = (-1)^(2/5)
 
Z5Cat2Piv4PivotalIsomorphism[4] = -(-1)^(1/5)
balancedCategories[Z5Cat2Piv5] ^= {}
 
fusionCategory[Z5Cat2Piv5] ^= Z5Cat2
 
Z5Cat2Piv5 /: modularCategory[Z5Cat2Piv5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat2Piv5] ^= Z5Cat2Piv5
 
pivotalIsomorphism[Z5Cat2Piv5] ^= Z5Cat2Piv5PivotalIsomorphism
 
ring[Z5Cat2Piv5] ^= Z5
 
sphericalCategory[Z5Cat2Piv5] ^= Z5Cat2Piv5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat2]][pivotalCategory[#1]] & )[
    Z5Cat2Piv5] ^= 5
 
(sphericalCategoryIndex[fusionCategory[Z5Cat2]][sphericalCategory[#1]] & )[
    Z5Cat2Piv5] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z5Cat2Piv5PivotalIsomorphism] ^= Z5Cat2
 
pivotalCategory[Z5Cat2Piv5PivotalIsomorphism] ^= Z5Cat2Piv5
 
pivotalIsomorphism[Z5Cat2Piv5PivotalIsomorphism] ^= 
   Z5Cat2Piv5PivotalIsomorphism
 
Z5Cat2Piv5PivotalIsomorphism[0] = 1
 
Z5Cat2Piv5PivotalIsomorphism[1] = (-1)^(2/5)
 
Z5Cat2Piv5PivotalIsomorphism[2] = (-1)^(4/5)
 
Z5Cat2Piv5PivotalIsomorphism[3] = -(-1)^(1/5)
 
Z5Cat2Piv5PivotalIsomorphism[4] = -(-1)^(3/5)
balancedCategories[Z5Cat3] ^= {}
 
braidedCategories[Z5Cat3] ^= {}
 
coeval[Z5Cat3] ^= 1/sixJFunction[Z5Cat3][#1, dual[ring[Z5Cat3]][#1], #1, #1, 
      0, 0] & 
 
eval[Z5Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[Z5Cat3] ^= Z5Cat3FMatrixFunction
 
fusionCategory[Z5Cat3] ^= Z5Cat3
 
Z5Cat3 /: modularCategory[Z5Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[Z5Cat3] ^= {Z5Cat3Piv1, Z5Cat3Piv2, Z5Cat3Piv3, Z5Cat3Piv4, 
    Z5Cat3Piv5}
 
Z5Cat3 /: pivotalCategory[Z5Cat3, 1] = Z5Cat3Piv1
 
Z5Cat3 /: pivotalCategory[Z5Cat3, 2] = Z5Cat3Piv2
 
Z5Cat3 /: pivotalCategory[Z5Cat3, 3] = Z5Cat3Piv3
 
Z5Cat3 /: pivotalCategory[Z5Cat3, 4] = Z5Cat3Piv4
 
Z5Cat3 /: pivotalCategory[Z5Cat3, 5] = Z5Cat3Piv5
 
Z5Cat3 /: pivotalCategory[Z5Cat3, {1, 1, 1, 1, 1}] = Z5Cat3Piv1
 
Z5Cat3 /: pivotalCategory[Z5Cat3, {1, -(-1)^(1/5), (-1)^(2/5), -(-1)^(3/5), 
      (-1)^(4/5)}] = Z5Cat3Piv3
 
Z5Cat3 /: pivotalCategory[Z5Cat3, {1, (-1)^(2/5), (-1)^(4/5), -(-1)^(1/5), 
      -(-1)^(3/5)}] = Z5Cat3Piv5
 
Z5Cat3 /: pivotalCategory[Z5Cat3, {1, -(-1)^(3/5), -(-1)^(1/5), (-1)^(4/5), 
      (-1)^(2/5)}] = Z5Cat3Piv2
 
Z5Cat3 /: pivotalCategory[Z5Cat3, {1, (-1)^(4/5), -(-1)^(3/5), (-1)^(2/5), 
      -(-1)^(1/5)}] = Z5Cat3Piv4
 
ring[Z5Cat3] ^= Z5
 
Z5Cat3 /: sphericalCategory[Z5Cat3, 1] = Z5Cat3Piv4
 
fusionCategoryIndex[Z5][Z5Cat3] ^= 3
fMatrixFunction[Z5Cat3FMatrixFunction] ^= Z5Cat3FMatrixFunction
 
fusionCategory[Z5Cat3FMatrixFunction] ^= Z5Cat3
 
ring[Z5Cat3FMatrixFunction] ^= Z5
 
Z5Cat3FMatrixFunction[1, 1, 1, 3] = {{(-1)^(4/5)}}
 
Z5Cat3FMatrixFunction[1, 1, 2, 4] = {{-(-1)^(1/5)}}
 
Z5Cat3FMatrixFunction[1, 2, 1, 4] = {{(-1)^(4/5)}}
 
Z5Cat3FMatrixFunction[1, 3, 2, 1] = {{-(-1)^(1/5)}}
 
Z5Cat3FMatrixFunction[1, 3, 3, 2] = {{-(-1)^(1/5)}}
 
Z5Cat3FMatrixFunction[1, 3, 4, 3] = {{-(-1)^(1/5)}}
 
Z5Cat3FMatrixFunction[1, 4, 1, 1] = {{-(-1)^(1/5)}}
 
Z5Cat3FMatrixFunction[1, 4, 2, 2] = {{-(-1)^(1/5)}}
 
Z5Cat3FMatrixFunction[1, 4, 3, 3] = {{-(-1)^(1/5)}}
 
Z5Cat3FMatrixFunction[2, 1, 1, 4] = {{-(-1)^(1/5)}}
 
Z5Cat3FMatrixFunction[2, 1, 3, 1] = {{(-1)^(4/5)}}
 
Z5Cat3FMatrixFunction[2, 1, 4, 2] = {{(-1)^(4/5)}}
 
Z5Cat3FMatrixFunction[2, 2, 2, 1] = {{(-1)^(2/5)}}
 
Z5Cat3FMatrixFunction[2, 2, 3, 2] = {{(-1)^(2/5)}}
 
Z5Cat3FMatrixFunction[2, 2, 4, 3] = {{-(-1)^(3/5)}}
 
Z5Cat3FMatrixFunction[2, 3, 1, 1] = {{-(-1)^(1/5)}}
 
Z5Cat3FMatrixFunction[2, 3, 2, 2] = {{(-1)^(2/5)}}
 
Z5Cat3FMatrixFunction[2, 3, 3, 3] = {{-(-1)^(3/5)}}
 
Z5Cat3FMatrixFunction[2, 4, 1, 2] = {{-(-1)^(1/5)}}
 
Z5Cat3FMatrixFunction[2, 4, 2, 3] = {{(-1)^(2/5)}}
 
Z5Cat3FMatrixFunction[3, 1, 3, 2] = {{(-1)^(4/5)}}
 
Z5Cat3FMatrixFunction[3, 1, 4, 3] = {{(-1)^(4/5)}}
 
Z5Cat3FMatrixFunction[3, 2, 1, 1] = {{-(-1)^(1/5)}}
 
Z5Cat3FMatrixFunction[3, 2, 2, 2] = {{-(-1)^(3/5)}}
 
Z5Cat3FMatrixFunction[3, 2, 3, 3] = {{-(-1)^(3/5)}}
 
Z5Cat3FMatrixFunction[3, 2, 4, 4] = {{(-1)^(4/5)}}
 
Z5Cat3FMatrixFunction[3, 3, 1, 2] = {{-(-1)^(1/5)}}
 
Z5Cat3FMatrixFunction[3, 3, 2, 3] = {{(-1)^(2/5)}}
 
Z5Cat3FMatrixFunction[3, 3, 3, 4] = {{(-1)^(4/5)}}
 
Z5Cat3FMatrixFunction[3, 4, 2, 4] = {{(-1)^(4/5)}}
 
Z5Cat3FMatrixFunction[4, 1, 3, 3] = {{(-1)^(4/5)}}
 
Z5Cat3FMatrixFunction[4, 1, 4, 4] = {{(-1)^(4/5)}}
 
Z5Cat3FMatrixFunction[4, 2, 1, 2] = {{-(-1)^(1/5)}}
 
Z5Cat3FMatrixFunction[4, 2, 2, 3] = {{-(-1)^(3/5)}}
 
Z5Cat3FMatrixFunction[4, 2, 3, 4] = {{(-1)^(4/5)}}
 
Z5Cat3FMatrixFunction[4, 3, 2, 4] = {{(-1)^(4/5)}}
 
Z5Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z5Cat3], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
Z5Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z5Cat3], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[Z5Cat3Piv1] ^= {}
 
fusionCategory[Z5Cat3Piv1] ^= Z5Cat3
 
Z5Cat3Piv1 /: modularCategory[Z5Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat3Piv1] ^= Z5Cat3Piv1
 
pivotalIsomorphism[Z5Cat3Piv1] ^= Z5Cat3Piv1PivotalIsomorphism
 
ring[Z5Cat3Piv1] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat3]][pivotalCategory[#1]] & )[
    Z5Cat3Piv1] ^= 1
fusionCategory[Z5Cat3Piv1PivotalIsomorphism] ^= Z5Cat3
 
pivotalCategory[Z5Cat3Piv1PivotalIsomorphism] ^= Z5Cat3Piv1
 
pivotalIsomorphism[Z5Cat3Piv1PivotalIsomorphism] ^= 
   Z5Cat3Piv1PivotalIsomorphism
 
Z5Cat3Piv1PivotalIsomorphism[0] = 1
 
Z5Cat3Piv1PivotalIsomorphism[1] = 1
 
Z5Cat3Piv1PivotalIsomorphism[2] = 1
 
Z5Cat3Piv1PivotalIsomorphism[3] = 1
 
Z5Cat3Piv1PivotalIsomorphism[4] = 1
balancedCategories[Z5Cat3Piv2] ^= {}
 
fusionCategory[Z5Cat3Piv2] ^= Z5Cat3
 
Z5Cat3Piv2 /: modularCategory[Z5Cat3Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat3Piv2] ^= Z5Cat3Piv2
 
pivotalIsomorphism[Z5Cat3Piv2] ^= Z5Cat3Piv2PivotalIsomorphism
 
ring[Z5Cat3Piv2] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat3]][pivotalCategory[#1]] & )[
    Z5Cat3Piv2] ^= 2
fusionCategory[Z5Cat3Piv2PivotalIsomorphism] ^= Z5Cat3
 
pivotalCategory[Z5Cat3Piv2PivotalIsomorphism] ^= Z5Cat3Piv2
 
pivotalIsomorphism[Z5Cat3Piv2PivotalIsomorphism] ^= 
   Z5Cat3Piv2PivotalIsomorphism
 
Z5Cat3Piv2PivotalIsomorphism[0] = 1
 
Z5Cat3Piv2PivotalIsomorphism[1] = -(-1)^(3/5)
 
Z5Cat3Piv2PivotalIsomorphism[2] = -(-1)^(1/5)
 
Z5Cat3Piv2PivotalIsomorphism[3] = (-1)^(4/5)
 
Z5Cat3Piv2PivotalIsomorphism[4] = (-1)^(2/5)
balancedCategories[Z5Cat3Piv3] ^= {}
 
fusionCategory[Z5Cat3Piv3] ^= Z5Cat3
 
Z5Cat3Piv3 /: modularCategory[Z5Cat3Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat3Piv3] ^= Z5Cat3Piv3
 
pivotalIsomorphism[Z5Cat3Piv3] ^= Z5Cat3Piv3PivotalIsomorphism
 
ring[Z5Cat3Piv3] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat3]][pivotalCategory[#1]] & )[
    Z5Cat3Piv3] ^= 3
fusionCategory[Z5Cat3Piv3PivotalIsomorphism] ^= Z5Cat3
 
pivotalCategory[Z5Cat3Piv3PivotalIsomorphism] ^= Z5Cat3Piv3
 
pivotalIsomorphism[Z5Cat3Piv3PivotalIsomorphism] ^= 
   Z5Cat3Piv3PivotalIsomorphism
 
Z5Cat3Piv3PivotalIsomorphism[0] = 1
 
Z5Cat3Piv3PivotalIsomorphism[1] = -(-1)^(1/5)
 
Z5Cat3Piv3PivotalIsomorphism[2] = (-1)^(2/5)
 
Z5Cat3Piv3PivotalIsomorphism[3] = -(-1)^(3/5)
 
Z5Cat3Piv3PivotalIsomorphism[4] = (-1)^(4/5)
balancedCategories[Z5Cat3Piv4] ^= {}
 
fusionCategory[Z5Cat3Piv4] ^= Z5Cat3
 
Z5Cat3Piv4 /: modularCategory[Z5Cat3Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat3Piv4] ^= Z5Cat3Piv4
 
pivotalIsomorphism[Z5Cat3Piv4] ^= Z5Cat3Piv4PivotalIsomorphism
 
ring[Z5Cat3Piv4] ^= Z5
 
sphericalCategory[Z5Cat3Piv4] ^= Z5Cat3Piv4
 
(pivotalCategoryIndex[fusionCategory[Z5Cat3]][pivotalCategory[#1]] & )[
    Z5Cat3Piv4] ^= 4
 
(sphericalCategoryIndex[fusionCategory[Z5Cat3]][sphericalCategory[#1]] & )[
    Z5Cat3Piv4] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z5Cat3Piv4PivotalIsomorphism] ^= Z5Cat3
 
pivotalCategory[Z5Cat3Piv4PivotalIsomorphism] ^= Z5Cat3Piv4
 
pivotalIsomorphism[Z5Cat3Piv4PivotalIsomorphism] ^= 
   Z5Cat3Piv4PivotalIsomorphism
 
Z5Cat3Piv4PivotalIsomorphism[0] = 1
 
Z5Cat3Piv4PivotalIsomorphism[1] = (-1)^(4/5)
 
Z5Cat3Piv4PivotalIsomorphism[2] = -(-1)^(3/5)
 
Z5Cat3Piv4PivotalIsomorphism[3] = (-1)^(2/5)
 
Z5Cat3Piv4PivotalIsomorphism[4] = -(-1)^(1/5)
balancedCategories[Z5Cat3Piv5] ^= {}
 
fusionCategory[Z5Cat3Piv5] ^= Z5Cat3
 
Z5Cat3Piv5 /: modularCategory[Z5Cat3Piv5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat3Piv5] ^= Z5Cat3Piv5
 
pivotalIsomorphism[Z5Cat3Piv5] ^= Z5Cat3Piv5PivotalIsomorphism
 
ring[Z5Cat3Piv5] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat3]][pivotalCategory[#1]] & )[
    Z5Cat3Piv5] ^= 5
fusionCategory[Z5Cat3Piv5PivotalIsomorphism] ^= Z5Cat3
 
pivotalCategory[Z5Cat3Piv5PivotalIsomorphism] ^= Z5Cat3Piv5
 
pivotalIsomorphism[Z5Cat3Piv5PivotalIsomorphism] ^= 
   Z5Cat3Piv5PivotalIsomorphism
 
Z5Cat3Piv5PivotalIsomorphism[0] = 1
 
Z5Cat3Piv5PivotalIsomorphism[1] = (-1)^(2/5)
 
Z5Cat3Piv5PivotalIsomorphism[2] = (-1)^(4/5)
 
Z5Cat3Piv5PivotalIsomorphism[3] = -(-1)^(1/5)
 
Z5Cat3Piv5PivotalIsomorphism[4] = -(-1)^(3/5)
balancedCategories[Z5Cat4] ^= {}
 
braidedCategories[Z5Cat4] ^= {}
 
coeval[Z5Cat4] ^= 1/sixJFunction[Z5Cat4][#1, dual[ring[Z5Cat4]][#1], #1, #1, 
      0, 0] & 
 
eval[Z5Cat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[Z5Cat4] ^= Z5Cat4FMatrixFunction
 
fusionCategory[Z5Cat4] ^= Z5Cat4
 
Z5Cat4 /: modularCategory[Z5Cat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[Z5Cat4] ^= {Z5Cat4Piv1, Z5Cat4Piv2, Z5Cat4Piv3, Z5Cat4Piv4, 
    Z5Cat4Piv5}
 
Z5Cat4 /: pivotalCategory[Z5Cat4, 1] = Z5Cat4Piv1
 
Z5Cat4 /: pivotalCategory[Z5Cat4, 2] = Z5Cat4Piv2
 
Z5Cat4 /: pivotalCategory[Z5Cat4, 3] = Z5Cat4Piv3
 
Z5Cat4 /: pivotalCategory[Z5Cat4, 4] = Z5Cat4Piv4
 
Z5Cat4 /: pivotalCategory[Z5Cat4, 5] = Z5Cat4Piv5
 
Z5Cat4 /: pivotalCategory[Z5Cat4, {1, 1, 1, 1, 1}] = Z5Cat4Piv1
 
Z5Cat4 /: pivotalCategory[Z5Cat4, {1, -(-1)^(1/5), (-1)^(2/5), -(-1)^(3/5), 
      (-1)^(4/5)}] = Z5Cat4Piv3
 
Z5Cat4 /: pivotalCategory[Z5Cat4, {1, (-1)^(2/5), (-1)^(4/5), -(-1)^(1/5), 
      -(-1)^(3/5)}] = Z5Cat4Piv5
 
Z5Cat4 /: pivotalCategory[Z5Cat4, {1, -(-1)^(3/5), -(-1)^(1/5), (-1)^(4/5), 
      (-1)^(2/5)}] = Z5Cat4Piv2
 
Z5Cat4 /: pivotalCategory[Z5Cat4, {1, (-1)^(4/5), -(-1)^(3/5), (-1)^(2/5), 
      -(-1)^(1/5)}] = Z5Cat4Piv4
 
ring[Z5Cat4] ^= Z5
 
Z5Cat4 /: sphericalCategory[Z5Cat4, 1] = Z5Cat4Piv3
 
fusionCategoryIndex[Z5][Z5Cat4] ^= 4
fMatrixFunction[Z5Cat4FMatrixFunction] ^= Z5Cat4FMatrixFunction
 
fusionCategory[Z5Cat4FMatrixFunction] ^= Z5Cat4
 
ring[Z5Cat4FMatrixFunction] ^= Z5
 
Z5Cat4FMatrixFunction[1, 1, 1, 3] = {{-(-1)^(1/5)}}
 
Z5Cat4FMatrixFunction[1, 1, 2, 4] = {{(-1)^(4/5)}}
 
Z5Cat4FMatrixFunction[1, 2, 1, 4] = {{-(-1)^(1/5)}}
 
Z5Cat4FMatrixFunction[1, 3, 2, 1] = {{(-1)^(4/5)}}
 
Z5Cat4FMatrixFunction[1, 3, 3, 2] = {{(-1)^(4/5)}}
 
Z5Cat4FMatrixFunction[1, 3, 4, 3] = {{(-1)^(4/5)}}
 
Z5Cat4FMatrixFunction[1, 4, 1, 1] = {{(-1)^(4/5)}}
 
Z5Cat4FMatrixFunction[1, 4, 2, 2] = {{(-1)^(4/5)}}
 
Z5Cat4FMatrixFunction[1, 4, 3, 3] = {{(-1)^(4/5)}}
 
Z5Cat4FMatrixFunction[2, 1, 1, 4] = {{(-1)^(4/5)}}
 
Z5Cat4FMatrixFunction[2, 1, 3, 1] = {{-(-1)^(1/5)}}
 
Z5Cat4FMatrixFunction[2, 1, 4, 2] = {{-(-1)^(1/5)}}
 
Z5Cat4FMatrixFunction[2, 2, 2, 1] = {{-(-1)^(3/5)}}
 
Z5Cat4FMatrixFunction[2, 2, 3, 2] = {{-(-1)^(3/5)}}
 
Z5Cat4FMatrixFunction[2, 2, 4, 3] = {{(-1)^(2/5)}}
 
Z5Cat4FMatrixFunction[2, 3, 1, 1] = {{(-1)^(4/5)}}
 
Z5Cat4FMatrixFunction[2, 3, 2, 2] = {{-(-1)^(3/5)}}
 
Z5Cat4FMatrixFunction[2, 3, 3, 3] = {{(-1)^(2/5)}}
 
Z5Cat4FMatrixFunction[2, 4, 1, 2] = {{(-1)^(4/5)}}
 
Z5Cat4FMatrixFunction[2, 4, 2, 3] = {{-(-1)^(3/5)}}
 
Z5Cat4FMatrixFunction[3, 1, 3, 2] = {{-(-1)^(1/5)}}
 
Z5Cat4FMatrixFunction[3, 1, 4, 3] = {{-(-1)^(1/5)}}
 
Z5Cat4FMatrixFunction[3, 2, 1, 1] = {{(-1)^(4/5)}}
 
Z5Cat4FMatrixFunction[3, 2, 2, 2] = {{(-1)^(2/5)}}
 
Z5Cat4FMatrixFunction[3, 2, 3, 3] = {{(-1)^(2/5)}}
 
Z5Cat4FMatrixFunction[3, 2, 4, 4] = {{-(-1)^(1/5)}}
 
Z5Cat4FMatrixFunction[3, 3, 1, 2] = {{(-1)^(4/5)}}
 
Z5Cat4FMatrixFunction[3, 3, 2, 3] = {{-(-1)^(3/5)}}
 
Z5Cat4FMatrixFunction[3, 3, 3, 4] = {{-(-1)^(1/5)}}
 
Z5Cat4FMatrixFunction[3, 4, 2, 4] = {{-(-1)^(1/5)}}
 
Z5Cat4FMatrixFunction[4, 1, 3, 3] = {{-(-1)^(1/5)}}
 
Z5Cat4FMatrixFunction[4, 1, 4, 4] = {{-(-1)^(1/5)}}
 
Z5Cat4FMatrixFunction[4, 2, 1, 2] = {{(-1)^(4/5)}}
 
Z5Cat4FMatrixFunction[4, 2, 2, 3] = {{(-1)^(2/5)}}
 
Z5Cat4FMatrixFunction[4, 2, 3, 4] = {{-(-1)^(1/5)}}
 
Z5Cat4FMatrixFunction[4, 3, 2, 4] = {{-(-1)^(1/5)}}
 
Z5Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z5Cat4], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
Z5Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z5Cat4], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[Z5Cat4Piv1] ^= {}
 
fusionCategory[Z5Cat4Piv1] ^= Z5Cat4
 
Z5Cat4Piv1 /: modularCategory[Z5Cat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat4Piv1] ^= Z5Cat4Piv1
 
pivotalIsomorphism[Z5Cat4Piv1] ^= Z5Cat4Piv1PivotalIsomorphism
 
ring[Z5Cat4Piv1] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat4]][pivotalCategory[#1]] & )[
    Z5Cat4Piv1] ^= 1
fusionCategory[Z5Cat4Piv1PivotalIsomorphism] ^= Z5Cat4
 
pivotalCategory[Z5Cat4Piv1PivotalIsomorphism] ^= Z5Cat4Piv1
 
pivotalIsomorphism[Z5Cat4Piv1PivotalIsomorphism] ^= 
   Z5Cat4Piv1PivotalIsomorphism
 
Z5Cat4Piv1PivotalIsomorphism[0] = 1
 
Z5Cat4Piv1PivotalIsomorphism[1] = 1
 
Z5Cat4Piv1PivotalIsomorphism[2] = 1
 
Z5Cat4Piv1PivotalIsomorphism[3] = 1
 
Z5Cat4Piv1PivotalIsomorphism[4] = 1
balancedCategories[Z5Cat4Piv2] ^= {}
 
fusionCategory[Z5Cat4Piv2] ^= Z5Cat4
 
Z5Cat4Piv2 /: modularCategory[Z5Cat4Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat4Piv2] ^= Z5Cat4Piv2
 
pivotalIsomorphism[Z5Cat4Piv2] ^= Z5Cat4Piv2PivotalIsomorphism
 
ring[Z5Cat4Piv2] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat4]][pivotalCategory[#1]] & )[
    Z5Cat4Piv2] ^= 2
fusionCategory[Z5Cat4Piv2PivotalIsomorphism] ^= Z5Cat4
 
pivotalCategory[Z5Cat4Piv2PivotalIsomorphism] ^= Z5Cat4Piv2
 
pivotalIsomorphism[Z5Cat4Piv2PivotalIsomorphism] ^= 
   Z5Cat4Piv2PivotalIsomorphism
 
Z5Cat4Piv2PivotalIsomorphism[0] = 1
 
Z5Cat4Piv2PivotalIsomorphism[1] = -(-1)^(3/5)
 
Z5Cat4Piv2PivotalIsomorphism[2] = -(-1)^(1/5)
 
Z5Cat4Piv2PivotalIsomorphism[3] = (-1)^(4/5)
 
Z5Cat4Piv2PivotalIsomorphism[4] = (-1)^(2/5)
balancedCategories[Z5Cat4Piv3] ^= {}
 
fusionCategory[Z5Cat4Piv3] ^= Z5Cat4
 
Z5Cat4Piv3 /: modularCategory[Z5Cat4Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat4Piv3] ^= Z5Cat4Piv3
 
pivotalIsomorphism[Z5Cat4Piv3] ^= Z5Cat4Piv3PivotalIsomorphism
 
ring[Z5Cat4Piv3] ^= Z5
 
sphericalCategory[Z5Cat4Piv3] ^= Z5Cat4Piv3
 
(pivotalCategoryIndex[fusionCategory[Z5Cat4]][pivotalCategory[#1]] & )[
    Z5Cat4Piv3] ^= 3
 
(sphericalCategoryIndex[fusionCategory[Z5Cat4]][sphericalCategory[#1]] & )[
    Z5Cat4Piv3] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z5Cat4Piv3PivotalIsomorphism] ^= Z5Cat4
 
pivotalCategory[Z5Cat4Piv3PivotalIsomorphism] ^= Z5Cat4Piv3
 
pivotalIsomorphism[Z5Cat4Piv3PivotalIsomorphism] ^= 
   Z5Cat4Piv3PivotalIsomorphism
 
Z5Cat4Piv3PivotalIsomorphism[0] = 1
 
Z5Cat4Piv3PivotalIsomorphism[1] = -(-1)^(1/5)
 
Z5Cat4Piv3PivotalIsomorphism[2] = (-1)^(2/5)
 
Z5Cat4Piv3PivotalIsomorphism[3] = -(-1)^(3/5)
 
Z5Cat4Piv3PivotalIsomorphism[4] = (-1)^(4/5)
balancedCategories[Z5Cat4Piv4] ^= {}
 
fusionCategory[Z5Cat4Piv4] ^= Z5Cat4
 
Z5Cat4Piv4 /: modularCategory[Z5Cat4Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat4Piv4] ^= Z5Cat4Piv4
 
pivotalIsomorphism[Z5Cat4Piv4] ^= Z5Cat4Piv4PivotalIsomorphism
 
ring[Z5Cat4Piv4] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat4]][pivotalCategory[#1]] & )[
    Z5Cat4Piv4] ^= 4
fusionCategory[Z5Cat4Piv4PivotalIsomorphism] ^= Z5Cat4
 
pivotalCategory[Z5Cat4Piv4PivotalIsomorphism] ^= Z5Cat4Piv4
 
pivotalIsomorphism[Z5Cat4Piv4PivotalIsomorphism] ^= 
   Z5Cat4Piv4PivotalIsomorphism
 
Z5Cat4Piv4PivotalIsomorphism[0] = 1
 
Z5Cat4Piv4PivotalIsomorphism[1] = (-1)^(4/5)
 
Z5Cat4Piv4PivotalIsomorphism[2] = -(-1)^(3/5)
 
Z5Cat4Piv4PivotalIsomorphism[3] = (-1)^(2/5)
 
Z5Cat4Piv4PivotalIsomorphism[4] = -(-1)^(1/5)
balancedCategories[Z5Cat4Piv5] ^= {}
 
fusionCategory[Z5Cat4Piv5] ^= Z5Cat4
 
Z5Cat4Piv5 /: modularCategory[Z5Cat4Piv5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat4Piv5] ^= Z5Cat4Piv5
 
pivotalIsomorphism[Z5Cat4Piv5] ^= Z5Cat4Piv5PivotalIsomorphism
 
ring[Z5Cat4Piv5] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat4]][pivotalCategory[#1]] & )[
    Z5Cat4Piv5] ^= 5
fusionCategory[Z5Cat4Piv5PivotalIsomorphism] ^= Z5Cat4
 
pivotalCategory[Z5Cat4Piv5PivotalIsomorphism] ^= Z5Cat4Piv5
 
pivotalIsomorphism[Z5Cat4Piv5PivotalIsomorphism] ^= 
   Z5Cat4Piv5PivotalIsomorphism
 
Z5Cat4Piv5PivotalIsomorphism[0] = 1
 
Z5Cat4Piv5PivotalIsomorphism[1] = (-1)^(2/5)
 
Z5Cat4Piv5PivotalIsomorphism[2] = (-1)^(4/5)
 
Z5Cat4Piv5PivotalIsomorphism[3] = -(-1)^(1/5)
 
Z5Cat4Piv5PivotalIsomorphism[4] = -(-1)^(3/5)
balancedCategories[Z5Cat5] ^= {}
 
braidedCategories[Z5Cat5] ^= {}
 
coeval[Z5Cat5] ^= 1/sixJFunction[Z5Cat5][#1, dual[ring[Z5Cat5]][#1], #1, #1, 
      0, 0] & 
 
eval[Z5Cat5] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[Z5Cat5] ^= Z5Cat5FMatrixFunction
 
fusionCategory[Z5Cat5] ^= Z5Cat5
 
Z5Cat5 /: modularCategory[Z5Cat5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[Z5Cat5] ^= {Z5Cat5Piv1, Z5Cat5Piv2, Z5Cat5Piv3, Z5Cat5Piv4, 
    Z5Cat5Piv5}
 
Z5Cat5 /: pivotalCategory[Z5Cat5, 1] = Z5Cat5Piv1
 
Z5Cat5 /: pivotalCategory[Z5Cat5, 2] = Z5Cat5Piv2
 
Z5Cat5 /: pivotalCategory[Z5Cat5, 3] = Z5Cat5Piv3
 
Z5Cat5 /: pivotalCategory[Z5Cat5, 4] = Z5Cat5Piv4
 
Z5Cat5 /: pivotalCategory[Z5Cat5, 5] = Z5Cat5Piv5
 
Z5Cat5 /: pivotalCategory[Z5Cat5, {1, 1, 1, 1, 1}] = Z5Cat5Piv1
 
Z5Cat5 /: pivotalCategory[Z5Cat5, {1, -(-1)^(1/5), (-1)^(2/5), -(-1)^(3/5), 
      (-1)^(4/5)}] = Z5Cat5Piv3
 
Z5Cat5 /: pivotalCategory[Z5Cat5, {1, (-1)^(2/5), (-1)^(4/5), -(-1)^(1/5), 
      -(-1)^(3/5)}] = Z5Cat5Piv5
 
Z5Cat5 /: pivotalCategory[Z5Cat5, {1, -(-1)^(3/5), -(-1)^(1/5), (-1)^(4/5), 
      (-1)^(2/5)}] = Z5Cat5Piv2
 
Z5Cat5 /: pivotalCategory[Z5Cat5, {1, (-1)^(4/5), -(-1)^(3/5), (-1)^(2/5), 
      -(-1)^(1/5)}] = Z5Cat5Piv4
 
ring[Z5Cat5] ^= Z5
 
Z5Cat5 /: sphericalCategory[Z5Cat5, 1] = Z5Cat5Piv2
 
fusionCategoryIndex[Z5][Z5Cat5] ^= 5
fMatrixFunction[Z5Cat5FMatrixFunction] ^= Z5Cat5FMatrixFunction
 
fusionCategory[Z5Cat5FMatrixFunction] ^= Z5Cat5
 
ring[Z5Cat5FMatrixFunction] ^= Z5
 
Z5Cat5FMatrixFunction[1, 1, 1, 3] = {{-(-1)^(3/5)}}
 
Z5Cat5FMatrixFunction[1, 1, 2, 4] = {{(-1)^(2/5)}}
 
Z5Cat5FMatrixFunction[1, 2, 1, 4] = {{-(-1)^(3/5)}}
 
Z5Cat5FMatrixFunction[1, 3, 2, 1] = {{(-1)^(2/5)}}
 
Z5Cat5FMatrixFunction[1, 3, 3, 2] = {{(-1)^(2/5)}}
 
Z5Cat5FMatrixFunction[1, 3, 4, 3] = {{(-1)^(2/5)}}
 
Z5Cat5FMatrixFunction[1, 4, 1, 1] = {{(-1)^(2/5)}}
 
Z5Cat5FMatrixFunction[1, 4, 2, 2] = {{(-1)^(2/5)}}
 
Z5Cat5FMatrixFunction[1, 4, 3, 3] = {{(-1)^(2/5)}}
 
Z5Cat5FMatrixFunction[2, 1, 1, 4] = {{(-1)^(2/5)}}
 
Z5Cat5FMatrixFunction[2, 1, 3, 1] = {{-(-1)^(3/5)}}
 
Z5Cat5FMatrixFunction[2, 1, 4, 2] = {{-(-1)^(3/5)}}
 
Z5Cat5FMatrixFunction[2, 2, 2, 1] = {{(-1)^(4/5)}}
 
Z5Cat5FMatrixFunction[2, 2, 3, 2] = {{(-1)^(4/5)}}
 
Z5Cat5FMatrixFunction[2, 2, 4, 3] = {{-(-1)^(1/5)}}
 
Z5Cat5FMatrixFunction[2, 3, 1, 1] = {{(-1)^(2/5)}}
 
Z5Cat5FMatrixFunction[2, 3, 2, 2] = {{(-1)^(4/5)}}
 
Z5Cat5FMatrixFunction[2, 3, 3, 3] = {{-(-1)^(1/5)}}
 
Z5Cat5FMatrixFunction[2, 4, 1, 2] = {{(-1)^(2/5)}}
 
Z5Cat5FMatrixFunction[2, 4, 2, 3] = {{(-1)^(4/5)}}
 
Z5Cat5FMatrixFunction[3, 1, 3, 2] = {{-(-1)^(3/5)}}
 
Z5Cat5FMatrixFunction[3, 1, 4, 3] = {{-(-1)^(3/5)}}
 
Z5Cat5FMatrixFunction[3, 2, 1, 1] = {{(-1)^(2/5)}}
 
Z5Cat5FMatrixFunction[3, 2, 2, 2] = {{-(-1)^(1/5)}}
 
Z5Cat5FMatrixFunction[3, 2, 3, 3] = {{-(-1)^(1/5)}}
 
Z5Cat5FMatrixFunction[3, 2, 4, 4] = {{-(-1)^(3/5)}}
 
Z5Cat5FMatrixFunction[3, 3, 1, 2] = {{(-1)^(2/5)}}
 
Z5Cat5FMatrixFunction[3, 3, 2, 3] = {{(-1)^(4/5)}}
 
Z5Cat5FMatrixFunction[3, 3, 3, 4] = {{-(-1)^(3/5)}}
 
Z5Cat5FMatrixFunction[3, 4, 2, 4] = {{-(-1)^(3/5)}}
 
Z5Cat5FMatrixFunction[4, 1, 3, 3] = {{-(-1)^(3/5)}}
 
Z5Cat5FMatrixFunction[4, 1, 4, 4] = {{-(-1)^(3/5)}}
 
Z5Cat5FMatrixFunction[4, 2, 1, 2] = {{(-1)^(2/5)}}
 
Z5Cat5FMatrixFunction[4, 2, 2, 3] = {{-(-1)^(1/5)}}
 
Z5Cat5FMatrixFunction[4, 2, 3, 4] = {{-(-1)^(3/5)}}
 
Z5Cat5FMatrixFunction[4, 3, 2, 4] = {{-(-1)^(3/5)}}
 
Z5Cat5FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z5Cat5], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
Z5Cat5FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z5Cat5], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[Z5Cat5Piv1] ^= {}
 
fusionCategory[Z5Cat5Piv1] ^= Z5Cat5
 
Z5Cat5Piv1 /: modularCategory[Z5Cat5Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat5Piv1] ^= Z5Cat5Piv1
 
pivotalIsomorphism[Z5Cat5Piv1] ^= Z5Cat5Piv1PivotalIsomorphism
 
ring[Z5Cat5Piv1] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat5]][pivotalCategory[#1]] & )[
    Z5Cat5Piv1] ^= 1
fusionCategory[Z5Cat5Piv1PivotalIsomorphism] ^= Z5Cat5
 
pivotalCategory[Z5Cat5Piv1PivotalIsomorphism] ^= Z5Cat5Piv1
 
pivotalIsomorphism[Z5Cat5Piv1PivotalIsomorphism] ^= 
   Z5Cat5Piv1PivotalIsomorphism
 
Z5Cat5Piv1PivotalIsomorphism[0] = 1
 
Z5Cat5Piv1PivotalIsomorphism[1] = 1
 
Z5Cat5Piv1PivotalIsomorphism[2] = 1
 
Z5Cat5Piv1PivotalIsomorphism[3] = 1
 
Z5Cat5Piv1PivotalIsomorphism[4] = 1
balancedCategories[Z5Cat5Piv2] ^= {}
 
fusionCategory[Z5Cat5Piv2] ^= Z5Cat5
 
Z5Cat5Piv2 /: modularCategory[Z5Cat5Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat5Piv2] ^= Z5Cat5Piv2
 
pivotalIsomorphism[Z5Cat5Piv2] ^= Z5Cat5Piv2PivotalIsomorphism
 
ring[Z5Cat5Piv2] ^= Z5
 
sphericalCategory[Z5Cat5Piv2] ^= Z5Cat5Piv2
 
(pivotalCategoryIndex[fusionCategory[Z5Cat5]][pivotalCategory[#1]] & )[
    Z5Cat5Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[Z5Cat5]][sphericalCategory[#1]] & )[
    Z5Cat5Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z5Cat5Piv2PivotalIsomorphism] ^= Z5Cat5
 
pivotalCategory[Z5Cat5Piv2PivotalIsomorphism] ^= Z5Cat5Piv2
 
pivotalIsomorphism[Z5Cat5Piv2PivotalIsomorphism] ^= 
   Z5Cat5Piv2PivotalIsomorphism
 
Z5Cat5Piv2PivotalIsomorphism[0] = 1
 
Z5Cat5Piv2PivotalIsomorphism[1] = -(-1)^(3/5)
 
Z5Cat5Piv2PivotalIsomorphism[2] = -(-1)^(1/5)
 
Z5Cat5Piv2PivotalIsomorphism[3] = (-1)^(4/5)
 
Z5Cat5Piv2PivotalIsomorphism[4] = (-1)^(2/5)
balancedCategories[Z5Cat5Piv3] ^= {}
 
fusionCategory[Z5Cat5Piv3] ^= Z5Cat5
 
Z5Cat5Piv3 /: modularCategory[Z5Cat5Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat5Piv3] ^= Z5Cat5Piv3
 
pivotalIsomorphism[Z5Cat5Piv3] ^= Z5Cat5Piv3PivotalIsomorphism
 
ring[Z5Cat5Piv3] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat5]][pivotalCategory[#1]] & )[
    Z5Cat5Piv3] ^= 3
fusionCategory[Z5Cat5Piv3PivotalIsomorphism] ^= Z5Cat5
 
pivotalCategory[Z5Cat5Piv3PivotalIsomorphism] ^= Z5Cat5Piv3
 
pivotalIsomorphism[Z5Cat5Piv3PivotalIsomorphism] ^= 
   Z5Cat5Piv3PivotalIsomorphism
 
Z5Cat5Piv3PivotalIsomorphism[0] = 1
 
Z5Cat5Piv3PivotalIsomorphism[1] = -(-1)^(1/5)
 
Z5Cat5Piv3PivotalIsomorphism[2] = (-1)^(2/5)
 
Z5Cat5Piv3PivotalIsomorphism[3] = -(-1)^(3/5)
 
Z5Cat5Piv3PivotalIsomorphism[4] = (-1)^(4/5)
balancedCategories[Z5Cat5Piv4] ^= {}
 
fusionCategory[Z5Cat5Piv4] ^= Z5Cat5
 
Z5Cat5Piv4 /: modularCategory[Z5Cat5Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat5Piv4] ^= Z5Cat5Piv4
 
pivotalIsomorphism[Z5Cat5Piv4] ^= Z5Cat5Piv4PivotalIsomorphism
 
ring[Z5Cat5Piv4] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat5]][pivotalCategory[#1]] & )[
    Z5Cat5Piv4] ^= 4
fusionCategory[Z5Cat5Piv4PivotalIsomorphism] ^= Z5Cat5
 
pivotalCategory[Z5Cat5Piv4PivotalIsomorphism] ^= Z5Cat5Piv4
 
pivotalIsomorphism[Z5Cat5Piv4PivotalIsomorphism] ^= 
   Z5Cat5Piv4PivotalIsomorphism
 
Z5Cat5Piv4PivotalIsomorphism[0] = 1
 
Z5Cat5Piv4PivotalIsomorphism[1] = (-1)^(4/5)
 
Z5Cat5Piv4PivotalIsomorphism[2] = -(-1)^(3/5)
 
Z5Cat5Piv4PivotalIsomorphism[3] = (-1)^(2/5)
 
Z5Cat5Piv4PivotalIsomorphism[4] = -(-1)^(1/5)
balancedCategories[Z5Cat5Piv5] ^= {}
 
fusionCategory[Z5Cat5Piv5] ^= Z5Cat5
 
Z5Cat5Piv5 /: modularCategory[Z5Cat5Piv5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z5Cat5Piv5] ^= Z5Cat5Piv5
 
pivotalIsomorphism[Z5Cat5Piv5] ^= Z5Cat5Piv5PivotalIsomorphism
 
ring[Z5Cat5Piv5] ^= Z5
 
(pivotalCategoryIndex[fusionCategory[Z5Cat5]][pivotalCategory[#1]] & )[
    Z5Cat5Piv5] ^= 5
fusionCategory[Z5Cat5Piv5PivotalIsomorphism] ^= Z5Cat5
 
pivotalCategory[Z5Cat5Piv5PivotalIsomorphism] ^= Z5Cat5Piv5
 
pivotalIsomorphism[Z5Cat5Piv5PivotalIsomorphism] ^= 
   Z5Cat5Piv5PivotalIsomorphism
 
Z5Cat5Piv5PivotalIsomorphism[0] = 1
 
Z5Cat5Piv5PivotalIsomorphism[1] = (-1)^(2/5)
 
Z5Cat5Piv5PivotalIsomorphism[2] = (-1)^(4/5)
 
Z5Cat5Piv5PivotalIsomorphism[3] = -(-1)^(1/5)
 
Z5Cat5Piv5PivotalIsomorphism[4] = -(-1)^(3/5)
ring[Z5NFunction] ^= Z5
 
Z5NFunction[0, 0, 0] = 1
 
Z5NFunction[0, 0, 1] = 0
 
Z5NFunction[0, 0, 2] = 0
 
Z5NFunction[0, 0, 3] = 0
 
Z5NFunction[0, 0, 4] = 0
 
Z5NFunction[0, 1, 0] = 0
 
Z5NFunction[0, 1, 1] = 1
 
Z5NFunction[0, 1, 2] = 0
 
Z5NFunction[0, 1, 3] = 0
 
Z5NFunction[0, 1, 4] = 0
 
Z5NFunction[0, 2, 0] = 0
 
Z5NFunction[0, 2, 1] = 0
 
Z5NFunction[0, 2, 2] = 1
 
Z5NFunction[0, 2, 3] = 0
 
Z5NFunction[0, 2, 4] = 0
 
Z5NFunction[0, 3, 0] = 0
 
Z5NFunction[0, 3, 1] = 0
 
Z5NFunction[0, 3, 2] = 0
 
Z5NFunction[0, 3, 3] = 1
 
Z5NFunction[0, 3, 4] = 0
 
Z5NFunction[0, 4, 0] = 0
 
Z5NFunction[0, 4, 1] = 0
 
Z5NFunction[0, 4, 2] = 0
 
Z5NFunction[0, 4, 3] = 0
 
Z5NFunction[0, 4, 4] = 1
 
Z5NFunction[1, 0, 0] = 0
 
Z5NFunction[1, 0, 1] = 1
 
Z5NFunction[1, 0, 2] = 0
 
Z5NFunction[1, 0, 3] = 0
 
Z5NFunction[1, 0, 4] = 0
 
Z5NFunction[1, 1, 0] = 0
 
Z5NFunction[1, 1, 1] = 0
 
Z5NFunction[1, 1, 2] = 1
 
Z5NFunction[1, 1, 3] = 0
 
Z5NFunction[1, 1, 4] = 0
 
Z5NFunction[1, 2, 0] = 0
 
Z5NFunction[1, 2, 1] = 0
 
Z5NFunction[1, 2, 2] = 0
 
Z5NFunction[1, 2, 3] = 1
 
Z5NFunction[1, 2, 4] = 0
 
Z5NFunction[1, 3, 0] = 0
 
Z5NFunction[1, 3, 1] = 0
 
Z5NFunction[1, 3, 2] = 0
 
Z5NFunction[1, 3, 3] = 0
 
Z5NFunction[1, 3, 4] = 1
 
Z5NFunction[1, 4, 0] = 1
 
Z5NFunction[1, 4, 1] = 0
 
Z5NFunction[1, 4, 2] = 0
 
Z5NFunction[1, 4, 3] = 0
 
Z5NFunction[1, 4, 4] = 0
 
Z5NFunction[2, 0, 0] = 0
 
Z5NFunction[2, 0, 1] = 0
 
Z5NFunction[2, 0, 2] = 1
 
Z5NFunction[2, 0, 3] = 0
 
Z5NFunction[2, 0, 4] = 0
 
Z5NFunction[2, 1, 0] = 0
 
Z5NFunction[2, 1, 1] = 0
 
Z5NFunction[2, 1, 2] = 0
 
Z5NFunction[2, 1, 3] = 1
 
Z5NFunction[2, 1, 4] = 0
 
Z5NFunction[2, 2, 0] = 0
 
Z5NFunction[2, 2, 1] = 0
 
Z5NFunction[2, 2, 2] = 0
 
Z5NFunction[2, 2, 3] = 0
 
Z5NFunction[2, 2, 4] = 1
 
Z5NFunction[2, 3, 0] = 1
 
Z5NFunction[2, 3, 1] = 0
 
Z5NFunction[2, 3, 2] = 0
 
Z5NFunction[2, 3, 3] = 0
 
Z5NFunction[2, 3, 4] = 0
 
Z5NFunction[2, 4, 0] = 0
 
Z5NFunction[2, 4, 1] = 1
 
Z5NFunction[2, 4, 2] = 0
 
Z5NFunction[2, 4, 3] = 0
 
Z5NFunction[2, 4, 4] = 0
 
Z5NFunction[3, 0, 0] = 0
 
Z5NFunction[3, 0, 1] = 0
 
Z5NFunction[3, 0, 2] = 0
 
Z5NFunction[3, 0, 3] = 1
 
Z5NFunction[3, 0, 4] = 0
 
Z5NFunction[3, 1, 0] = 0
 
Z5NFunction[3, 1, 1] = 0
 
Z5NFunction[3, 1, 2] = 0
 
Z5NFunction[3, 1, 3] = 0
 
Z5NFunction[3, 1, 4] = 1
 
Z5NFunction[3, 2, 0] = 1
 
Z5NFunction[3, 2, 1] = 0
 
Z5NFunction[3, 2, 2] = 0
 
Z5NFunction[3, 2, 3] = 0
 
Z5NFunction[3, 2, 4] = 0
 
Z5NFunction[3, 3, 0] = 0
 
Z5NFunction[3, 3, 1] = 1
 
Z5NFunction[3, 3, 2] = 0
 
Z5NFunction[3, 3, 3] = 0
 
Z5NFunction[3, 3, 4] = 0
 
Z5NFunction[3, 4, 0] = 0
 
Z5NFunction[3, 4, 1] = 0
 
Z5NFunction[3, 4, 2] = 1
 
Z5NFunction[3, 4, 3] = 0
 
Z5NFunction[3, 4, 4] = 0
 
Z5NFunction[4, 0, 0] = 0
 
Z5NFunction[4, 0, 1] = 0
 
Z5NFunction[4, 0, 2] = 0
 
Z5NFunction[4, 0, 3] = 0
 
Z5NFunction[4, 0, 4] = 1
 
Z5NFunction[4, 1, 0] = 1
 
Z5NFunction[4, 1, 1] = 0
 
Z5NFunction[4, 1, 2] = 0
 
Z5NFunction[4, 1, 3] = 0
 
Z5NFunction[4, 1, 4] = 0
 
Z5NFunction[4, 2, 0] = 0
 
Z5NFunction[4, 2, 1] = 1
 
Z5NFunction[4, 2, 2] = 0
 
Z5NFunction[4, 2, 3] = 0
 
Z5NFunction[4, 2, 4] = 0
 
Z5NFunction[4, 3, 0] = 0
 
Z5NFunction[4, 3, 1] = 0
 
Z5NFunction[4, 3, 2] = 1
 
Z5NFunction[4, 3, 3] = 0
 
Z5NFunction[4, 3, 4] = 0
 
Z5NFunction[4, 4, 0] = 0
 
Z5NFunction[4, 4, 1] = 0
 
Z5NFunction[4, 4, 2] = 0
 
Z5NFunction[4, 4, 3] = 1
 
Z5NFunction[4, 4, 4] = 0
 
Z5NFunction[FusionCategories`Data`Z5`Private`a_, FusionCategories`Data`Z5`Private`b_, FusionCategories`Data`Z5`Private`c_] := 0


 EndPackage[]
