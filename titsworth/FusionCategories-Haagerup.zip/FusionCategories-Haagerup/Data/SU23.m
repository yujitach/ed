BeginPackage["FusionCategories`Data`SU23`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[SU23] ^= {SU23Cat1, SU23Cat2, SU23Cat3, SU23Cat4}
 
SU23 /: fusionCategory[SU23, 1] = SU23Cat1
 
SU23 /: fusionCategory[SU23, 2] = SU23Cat2
 
SU23 /: fusionCategory[SU23, 3] = SU23Cat3
 
SU23 /: fusionCategory[SU23, 4] = SU23Cat4
 
nFunction[SU23] ^= SU23NFunction
 
noMultiplicities[SU23] ^= True
 
rank[SU23] ^= 4
 
ring[SU23] ^= SU23
balancedCategories[SU23Cat1] ^= {SU23Cat1Bal1, SU23Cat1Bal2, SU23Cat1Bal3, 
    SU23Cat1Bal4, SU23Cat1Bal5, SU23Cat1Bal6, SU23Cat1Bal7, SU23Cat1Bal8}
 
SU23Cat1 /: balancedCategory[SU23Cat1, 1] = SU23Cat1Bal1
 
SU23Cat1 /: balancedCategory[SU23Cat1, 2] = SU23Cat1Bal2
 
SU23Cat1 /: balancedCategory[SU23Cat1, 3] = SU23Cat1Bal3
 
SU23Cat1 /: balancedCategory[SU23Cat1, 4] = SU23Cat1Bal4
 
SU23Cat1 /: balancedCategory[SU23Cat1, 5] = SU23Cat1Bal5
 
SU23Cat1 /: balancedCategory[SU23Cat1, 6] = SU23Cat1Bal6
 
SU23Cat1 /: balancedCategory[SU23Cat1, 7] = SU23Cat1Bal7
 
SU23Cat1 /: balancedCategory[SU23Cat1, 8] = SU23Cat1Bal8
 
braidedCategories[SU23Cat1] ^= {SU23Cat1Brd1, SU23Cat1Brd2, SU23Cat1Brd3, 
    SU23Cat1Brd4}
 
SU23Cat1 /: braidedCategory[SU23Cat1, 1] = SU23Cat1Brd1
 
SU23Cat1 /: braidedCategory[SU23Cat1, 2] = SU23Cat1Brd2
 
SU23Cat1 /: braidedCategory[SU23Cat1, 3] = SU23Cat1Brd3
 
SU23Cat1 /: braidedCategory[SU23Cat1, 4] = SU23Cat1Brd4
 
coeval[SU23Cat1] ^= 1/sixJFunction[SU23Cat1][#1, dual[ring[SU23Cat1]][#1], 
      #1, #1, 0, 0] & 
 
eval[SU23Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[SU23Cat1] ^= SU23Cat1FMatrixFunction
 
fusionCategory[SU23Cat1] ^= SU23Cat1
 
SU23Cat1 /: modularCategory[SU23Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[SU23Cat1] ^= {SU23Cat1Piv1, SU23Cat1Piv2}
 
SU23Cat1 /: pivotalCategory[SU23Cat1, 1] = SU23Cat1Piv1
 
SU23Cat1 /: pivotalCategory[SU23Cat1, 2] = SU23Cat1Piv2
 
SU23Cat1 /: pivotalCategory[SU23Cat1, {1, -1, 1, -1}] = SU23Cat1Piv2
 
SU23Cat1 /: pivotalCategory[SU23Cat1, {1, 1, 1, 1}] = SU23Cat1Piv1
 
SU23Cat1 /: ribbonCategory[SU23Cat1, 1] = SU23Cat1Bal1
 
SU23Cat1 /: ribbonCategory[SU23Cat1, 2] = SU23Cat1Bal2
 
SU23Cat1 /: ribbonCategory[SU23Cat1, 3] = SU23Cat1Bal3
 
SU23Cat1 /: ribbonCategory[SU23Cat1, 4] = SU23Cat1Bal4
 
SU23Cat1 /: ribbonCategory[SU23Cat1, 5] = SU23Cat1Bal5
 
SU23Cat1 /: ribbonCategory[SU23Cat1, 6] = SU23Cat1Bal6
 
SU23Cat1 /: ribbonCategory[SU23Cat1, 7] = SU23Cat1Bal7
 
SU23Cat1 /: ribbonCategory[SU23Cat1, 8] = SU23Cat1Bal8
 
ring[SU23Cat1] ^= SU23
 
SU23Cat1 /: sphericalCategory[SU23Cat1, 1] = SU23Cat1Piv1
 
SU23Cat1 /: sphericalCategory[SU23Cat1, 2] = SU23Cat1Piv2
 
fusionCategoryIndex[SU23][SU23Cat1] ^= 1
balancedCategory[SU23Cat1Bal1] ^= SU23Cat1Bal1
 
braidedCategory[SU23Cat1Bal1] ^= SU23Cat1Brd1
 
fusionCategory[SU23Cat1Bal1] ^= SU23Cat1
 
pivotalCategory[SU23Cat1Bal1] ^= SU23Cat1Piv1
 
ribbonCategory[SU23Cat1Bal1] ^= SU23Cat1Bal1
 
ring[SU23Cat1Bal1] ^= SU23
 
sphericalCategory[SU23Cat1Bal1] ^= SU23Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SU23Cat1Brd1]][
      balancedCategory[#1]] & )[SU23Cat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[SU23Cat1]][balancedCategory[#1]] & )[
    SU23Cat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[SU23Cat1Piv1]][
      balancedCategory[#1]] & )[SU23Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SU23Cat1Brd1]][ribbonCategory[#1]] & )[
    SU23Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SU23Cat1]][ribbonCategory[#1]] & )[
    SU23Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat1Piv1]][ribbonCategory[#1]] & )[
    SU23Cat1Bal1] ^= 1
balancedCategory[SU23Cat1Bal2] ^= SU23Cat1Bal2
 
braidedCategory[SU23Cat1Bal2] ^= SU23Cat1Brd1
 
fusionCategory[SU23Cat1Bal2] ^= SU23Cat1
 
pivotalCategory[SU23Cat1Bal2] ^= SU23Cat1Piv2
 
ribbonCategory[SU23Cat1Bal2] ^= SU23Cat1Bal2
 
ring[SU23Cat1Bal2] ^= SU23
 
sphericalCategory[SU23Cat1Bal2] ^= SU23Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[SU23Cat1Brd1]][
      balancedCategory[#1]] & )[SU23Cat1Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[SU23Cat1]][balancedCategory[#1]] & )[
    SU23Cat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[SU23Cat1Piv2]][
      balancedCategory[#1]] & )[SU23Cat1Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SU23Cat1Brd1]][ribbonCategory[#1]] & )[
    SU23Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SU23Cat1]][ribbonCategory[#1]] & )[
    SU23Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat1Piv2]][ribbonCategory[#1]] & )[
    SU23Cat1Bal2] ^= 1
balancedCategory[SU23Cat1Bal3] ^= SU23Cat1Bal3
 
braidedCategory[SU23Cat1Bal3] ^= SU23Cat1Brd2
 
fusionCategory[SU23Cat1Bal3] ^= SU23Cat1
 
pivotalCategory[SU23Cat1Bal3] ^= SU23Cat1Piv1
 
ribbonCategory[SU23Cat1Bal3] ^= SU23Cat1Bal3
 
ring[SU23Cat1Bal3] ^= SU23
 
sphericalCategory[SU23Cat1Bal3] ^= SU23Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SU23Cat1Brd2]][
      balancedCategory[#1]] & )[SU23Cat1Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[SU23Cat1]][balancedCategory[#1]] & )[
    SU23Cat1Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[SU23Cat1Piv1]][
      balancedCategory[#1]] & )[SU23Cat1Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SU23Cat1Brd2]][ribbonCategory[#1]] & )[
    SU23Cat1Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SU23Cat1]][ribbonCategory[#1]] & )[
    SU23Cat1Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat1Piv1]][ribbonCategory[#1]] & )[
    SU23Cat1Bal3] ^= 2
balancedCategory[SU23Cat1Bal4] ^= SU23Cat1Bal4
 
braidedCategory[SU23Cat1Bal4] ^= SU23Cat1Brd2
 
fusionCategory[SU23Cat1Bal4] ^= SU23Cat1
 
pivotalCategory[SU23Cat1Bal4] ^= SU23Cat1Piv2
 
ribbonCategory[SU23Cat1Bal4] ^= SU23Cat1Bal4
 
ring[SU23Cat1Bal4] ^= SU23
 
sphericalCategory[SU23Cat1Bal4] ^= SU23Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[SU23Cat1Brd2]][
      balancedCategory[#1]] & )[SU23Cat1Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[SU23Cat1]][balancedCategory[#1]] & )[
    SU23Cat1Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[SU23Cat1Piv2]][
      balancedCategory[#1]] & )[SU23Cat1Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SU23Cat1Brd2]][ribbonCategory[#1]] & )[
    SU23Cat1Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SU23Cat1]][ribbonCategory[#1]] & )[
    SU23Cat1Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat1Piv2]][ribbonCategory[#1]] & )[
    SU23Cat1Bal4] ^= 2
balancedCategory[SU23Cat1Bal5] ^= SU23Cat1Bal5
 
braidedCategory[SU23Cat1Bal5] ^= SU23Cat1Brd3
 
fusionCategory[SU23Cat1Bal5] ^= SU23Cat1
 
pivotalCategory[SU23Cat1Bal5] ^= SU23Cat1Piv1
 
ribbonCategory[SU23Cat1Bal5] ^= SU23Cat1Bal5
 
ring[SU23Cat1Bal5] ^= SU23
 
sphericalCategory[SU23Cat1Bal5] ^= SU23Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SU23Cat1Brd3]][
      balancedCategory[#1]] & )[SU23Cat1Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[SU23Cat1]][balancedCategory[#1]] & )[
    SU23Cat1Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[SU23Cat1Piv1]][
      balancedCategory[#1]] & )[SU23Cat1Bal5] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SU23Cat1Brd3]][ribbonCategory[#1]] & )[
    SU23Cat1Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SU23Cat1]][ribbonCategory[#1]] & )[
    SU23Cat1Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat1Piv1]][ribbonCategory[#1]] & )[
    SU23Cat1Bal5] ^= 3
balancedCategory[SU23Cat1Bal6] ^= SU23Cat1Bal6
 
braidedCategory[SU23Cat1Bal6] ^= SU23Cat1Brd3
 
fusionCategory[SU23Cat1Bal6] ^= SU23Cat1
 
pivotalCategory[SU23Cat1Bal6] ^= SU23Cat1Piv2
 
ribbonCategory[SU23Cat1Bal6] ^= SU23Cat1Bal6
 
ring[SU23Cat1Bal6] ^= SU23
 
sphericalCategory[SU23Cat1Bal6] ^= SU23Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[SU23Cat1Brd3]][
      balancedCategory[#1]] & )[SU23Cat1Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[SU23Cat1]][balancedCategory[#1]] & )[
    SU23Cat1Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[SU23Cat1Piv2]][
      balancedCategory[#1]] & )[SU23Cat1Bal6] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SU23Cat1Brd3]][ribbonCategory[#1]] & )[
    SU23Cat1Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SU23Cat1]][ribbonCategory[#1]] & )[
    SU23Cat1Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat1Piv2]][ribbonCategory[#1]] & )[
    SU23Cat1Bal6] ^= 3
balancedCategory[SU23Cat1Bal7] ^= SU23Cat1Bal7
 
braidedCategory[SU23Cat1Bal7] ^= SU23Cat1Brd4
 
fusionCategory[SU23Cat1Bal7] ^= SU23Cat1
 
pivotalCategory[SU23Cat1Bal7] ^= SU23Cat1Piv1
 
ribbonCategory[SU23Cat1Bal7] ^= SU23Cat1Bal7
 
ring[SU23Cat1Bal7] ^= SU23
 
sphericalCategory[SU23Cat1Bal7] ^= SU23Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SU23Cat1Brd4]][
      balancedCategory[#1]] & )[SU23Cat1Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[SU23Cat1]][balancedCategory[#1]] & )[
    SU23Cat1Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[SU23Cat1Piv1]][
      balancedCategory[#1]] & )[SU23Cat1Bal7] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SU23Cat1Brd4]][ribbonCategory[#1]] & )[
    SU23Cat1Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SU23Cat1]][ribbonCategory[#1]] & )[
    SU23Cat1Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat1Piv1]][ribbonCategory[#1]] & )[
    SU23Cat1Bal7] ^= 4
balancedCategory[SU23Cat1Bal8] ^= SU23Cat1Bal8
 
braidedCategory[SU23Cat1Bal8] ^= SU23Cat1Brd4
 
fusionCategory[SU23Cat1Bal8] ^= SU23Cat1
 
pivotalCategory[SU23Cat1Bal8] ^= SU23Cat1Piv2
 
ribbonCategory[SU23Cat1Bal8] ^= SU23Cat1Bal8
 
ring[SU23Cat1Bal8] ^= SU23
 
sphericalCategory[SU23Cat1Bal8] ^= SU23Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[SU23Cat1Brd4]][
      balancedCategory[#1]] & )[SU23Cat1Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[SU23Cat1]][balancedCategory[#1]] & )[
    SU23Cat1Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[SU23Cat1Piv2]][
      balancedCategory[#1]] & )[SU23Cat1Bal8] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SU23Cat1Brd4]][ribbonCategory[#1]] & )[
    SU23Cat1Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SU23Cat1]][ribbonCategory[#1]] & )[
    SU23Cat1Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat1Piv2]][ribbonCategory[#1]] & )[
    SU23Cat1Bal8] ^= 4
balancedCategories[SU23Cat1Brd1] ^= {SU23Cat1Bal1, SU23Cat1Bal2}
 
SU23Cat1Brd1 /: balancedCategory[SU23Cat1Brd1, 1] = SU23Cat1Bal1
 
SU23Cat1Brd1 /: balancedCategory[SU23Cat1Brd1, 2] = SU23Cat1Bal2
 
braidedCategory[SU23Cat1Brd1] ^= SU23Cat1Brd1
 
fusionCategory[SU23Cat1Brd1] ^= SU23Cat1
 
SU23Cat1Brd1 /: modularCategory[SU23Cat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SU23Cat1Brd1 /: ribbonCategory[SU23Cat1Brd1, 1] = SU23Cat1Bal1
 
SU23Cat1Brd1 /: ribbonCategory[SU23Cat1Brd1, 2] = SU23Cat1Bal2
 
ring[SU23Cat1Brd1] ^= SU23
 
rMatrixFunction[SU23Cat1Brd1] ^= SU23Cat1Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SU23Cat1]][braidedCategory[#1]] & )[
    SU23Cat1Brd1] ^= 1
fusionCategory[SU23Cat1Brd1RMatrixFunction] ^= SU23Cat1
 
rMatrixFunction[SU23Cat1Brd1RMatrixFunction] ^= SU23Cat1Brd1RMatrixFunction
 
SU23Cat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
SU23Cat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
SU23Cat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
SU23Cat1Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
SU23Cat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
SU23Cat1Brd1RMatrixFunction[1, 1, 0] = {{(-1)^(3/10)}}
 
SU23Cat1Brd1RMatrixFunction[1, 1, 2] = {{(-1)^(9/10)}}
 
SU23Cat1Brd1RMatrixFunction[1, 2, 1] = {{-(-1)^(2/5)}}
 
SU23Cat1Brd1RMatrixFunction[1, 2, 3] = {{(-1)^(4/5)}}
 
SU23Cat1Brd1RMatrixFunction[1, 3, 2] = {{-I}}
 
SU23Cat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
SU23Cat1Brd1RMatrixFunction[2, 1, 1] = {{-(-1)^(2/5)}}
 
SU23Cat1Brd1RMatrixFunction[2, 1, 3] = {{(-1)^(4/5)}}
 
SU23Cat1Brd1RMatrixFunction[2, 2, 0] = {{(-1)^(4/5)}}
 
SU23Cat1Brd1RMatrixFunction[2, 2, 2] = {{-(-1)^(2/5)}}
 
SU23Cat1Brd1RMatrixFunction[2, 3, 1] = {{1}}
 
SU23Cat1Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
SU23Cat1Brd1RMatrixFunction[3, 1, 2] = {{-I}}
 
SU23Cat1Brd1RMatrixFunction[3, 2, 1] = {{1}}
 
SU23Cat1Brd1RMatrixFunction[3, 3, 0] = {{-I}}
balancedCategories[SU23Cat1Brd2] ^= {SU23Cat1Bal3, SU23Cat1Bal4}
 
SU23Cat1Brd2 /: balancedCategory[SU23Cat1Brd2, 1] = SU23Cat1Bal3
 
SU23Cat1Brd2 /: balancedCategory[SU23Cat1Brd2, 2] = SU23Cat1Bal4
 
braidedCategory[SU23Cat1Brd2] ^= SU23Cat1Brd2
 
fusionCategory[SU23Cat1Brd2] ^= SU23Cat1
 
SU23Cat1Brd2 /: modularCategory[SU23Cat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SU23Cat1Brd2 /: ribbonCategory[SU23Cat1Brd2, 1] = SU23Cat1Bal3
 
SU23Cat1Brd2 /: ribbonCategory[SU23Cat1Brd2, 2] = SU23Cat1Bal4
 
ring[SU23Cat1Brd2] ^= SU23
 
rMatrixFunction[SU23Cat1Brd2] ^= SU23Cat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SU23Cat1]][braidedCategory[#1]] & )[
    SU23Cat1Brd2] ^= 2
fusionCategory[SU23Cat1Brd2RMatrixFunction] ^= SU23Cat1
 
rMatrixFunction[SU23Cat1Brd2RMatrixFunction] ^= SU23Cat1Brd2RMatrixFunction
 
SU23Cat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
SU23Cat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
SU23Cat1Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
SU23Cat1Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
SU23Cat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
SU23Cat1Brd2RMatrixFunction[1, 1, 0] = {{-(-1)^(7/10)}}
 
SU23Cat1Brd2RMatrixFunction[1, 1, 2] = {{-(-1)^(1/10)}}
 
SU23Cat1Brd2RMatrixFunction[1, 2, 1] = {{(-1)^(3/5)}}
 
SU23Cat1Brd2RMatrixFunction[1, 2, 3] = {{-(-1)^(1/5)}}
 
SU23Cat1Brd2RMatrixFunction[1, 3, 2] = {{I}}
 
SU23Cat1Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
SU23Cat1Brd2RMatrixFunction[2, 1, 1] = {{(-1)^(3/5)}}
 
SU23Cat1Brd2RMatrixFunction[2, 1, 3] = {{-(-1)^(1/5)}}
 
SU23Cat1Brd2RMatrixFunction[2, 2, 0] = {{-(-1)^(1/5)}}
 
SU23Cat1Brd2RMatrixFunction[2, 2, 2] = {{(-1)^(3/5)}}
 
SU23Cat1Brd2RMatrixFunction[2, 3, 1] = {{1}}
 
SU23Cat1Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
SU23Cat1Brd2RMatrixFunction[3, 1, 2] = {{I}}
 
SU23Cat1Brd2RMatrixFunction[3, 2, 1] = {{1}}
 
SU23Cat1Brd2RMatrixFunction[3, 3, 0] = {{I}}
balancedCategories[SU23Cat1Brd3] ^= {SU23Cat1Bal5, SU23Cat1Bal6}
 
SU23Cat1Brd3 /: balancedCategory[SU23Cat1Brd3, 1] = SU23Cat1Bal5
 
SU23Cat1Brd3 /: balancedCategory[SU23Cat1Brd3, 2] = SU23Cat1Bal6
 
braidedCategory[SU23Cat1Brd3] ^= SU23Cat1Brd3
 
fusionCategory[SU23Cat1Brd3] ^= SU23Cat1
 
SU23Cat1Brd3 /: modularCategory[SU23Cat1Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SU23Cat1Brd3 /: ribbonCategory[SU23Cat1Brd3, 1] = SU23Cat1Bal5
 
SU23Cat1Brd3 /: ribbonCategory[SU23Cat1Brd3, 2] = SU23Cat1Bal6
 
ring[SU23Cat1Brd3] ^= SU23
 
rMatrixFunction[SU23Cat1Brd3] ^= SU23Cat1Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SU23Cat1]][braidedCategory[#1]] & )[
    SU23Cat1Brd3] ^= 3
fusionCategory[SU23Cat1Brd3RMatrixFunction] ^= SU23Cat1
 
rMatrixFunction[SU23Cat1Brd3RMatrixFunction] ^= SU23Cat1Brd3RMatrixFunction
 
SU23Cat1Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
SU23Cat1Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
SU23Cat1Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
SU23Cat1Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
SU23Cat1Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
SU23Cat1Brd3RMatrixFunction[1, 1, 0] = {{(-1)^(7/10)}}
 
SU23Cat1Brd3RMatrixFunction[1, 1, 2] = {{(-1)^(1/10)}}
 
SU23Cat1Brd3RMatrixFunction[1, 2, 1] = {{(-1)^(3/5)}}
 
SU23Cat1Brd3RMatrixFunction[1, 2, 3] = {{-(-1)^(1/5)}}
 
SU23Cat1Brd3RMatrixFunction[1, 3, 2] = {{-I}}
 
SU23Cat1Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
SU23Cat1Brd3RMatrixFunction[2, 1, 1] = {{(-1)^(3/5)}}
 
SU23Cat1Brd3RMatrixFunction[2, 1, 3] = {{-(-1)^(1/5)}}
 
SU23Cat1Brd3RMatrixFunction[2, 2, 0] = {{-(-1)^(1/5)}}
 
SU23Cat1Brd3RMatrixFunction[2, 2, 2] = {{(-1)^(3/5)}}
 
SU23Cat1Brd3RMatrixFunction[2, 3, 1] = {{1}}
 
SU23Cat1Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
SU23Cat1Brd3RMatrixFunction[3, 1, 2] = {{-I}}
 
SU23Cat1Brd3RMatrixFunction[3, 2, 1] = {{1}}
 
SU23Cat1Brd3RMatrixFunction[3, 3, 0] = {{-I}}
balancedCategories[SU23Cat1Brd4] ^= {SU23Cat1Bal7, SU23Cat1Bal8}
 
SU23Cat1Brd4 /: balancedCategory[SU23Cat1Brd4, 1] = SU23Cat1Bal7
 
SU23Cat1Brd4 /: balancedCategory[SU23Cat1Brd4, 2] = SU23Cat1Bal8
 
braidedCategory[SU23Cat1Brd4] ^= SU23Cat1Brd4
 
fusionCategory[SU23Cat1Brd4] ^= SU23Cat1
 
SU23Cat1Brd4 /: modularCategory[SU23Cat1Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SU23Cat1Brd4 /: ribbonCategory[SU23Cat1Brd4, 1] = SU23Cat1Bal7
 
SU23Cat1Brd4 /: ribbonCategory[SU23Cat1Brd4, 2] = SU23Cat1Bal8
 
ring[SU23Cat1Brd4] ^= SU23
 
rMatrixFunction[SU23Cat1Brd4] ^= SU23Cat1Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SU23Cat1]][braidedCategory[#1]] & )[
    SU23Cat1Brd4] ^= 4
fusionCategory[SU23Cat1Brd4RMatrixFunction] ^= SU23Cat1
 
rMatrixFunction[SU23Cat1Brd4RMatrixFunction] ^= SU23Cat1Brd4RMatrixFunction
 
SU23Cat1Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
SU23Cat1Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
SU23Cat1Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
SU23Cat1Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
SU23Cat1Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
SU23Cat1Brd4RMatrixFunction[1, 1, 0] = {{-(-1)^(3/10)}}
 
SU23Cat1Brd4RMatrixFunction[1, 1, 2] = {{-(-1)^(9/10)}}
 
SU23Cat1Brd4RMatrixFunction[1, 2, 1] = {{-(-1)^(2/5)}}
 
SU23Cat1Brd4RMatrixFunction[1, 2, 3] = {{(-1)^(4/5)}}
 
SU23Cat1Brd4RMatrixFunction[1, 3, 2] = {{I}}
 
SU23Cat1Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
SU23Cat1Brd4RMatrixFunction[2, 1, 1] = {{-(-1)^(2/5)}}
 
SU23Cat1Brd4RMatrixFunction[2, 1, 3] = {{(-1)^(4/5)}}
 
SU23Cat1Brd4RMatrixFunction[2, 2, 0] = {{(-1)^(4/5)}}
 
SU23Cat1Brd4RMatrixFunction[2, 2, 2] = {{-(-1)^(2/5)}}
 
SU23Cat1Brd4RMatrixFunction[2, 3, 1] = {{1}}
 
SU23Cat1Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
SU23Cat1Brd4RMatrixFunction[3, 1, 2] = {{I}}
 
SU23Cat1Brd4RMatrixFunction[3, 2, 1] = {{1}}
 
SU23Cat1Brd4RMatrixFunction[3, 3, 0] = {{I}}
fMatrixFunction[SU23Cat1FMatrixFunction] ^= SU23Cat1FMatrixFunction
 
ring[SU23Cat1FMatrixFunction] ^= SU23
 
SU23Cat1FMatrixFunction[1, 1, 1, 1] = 
   {{(1 - Sqrt[5])/2, Root[-1 + #1^2 + #1^4 & , 1, 0]}, 
    {Root[-1 + #1^2 + #1^4 & , 1, 0], (-1 + Sqrt[5])/2}}
 
SU23Cat1FMatrixFunction[1, 1, 1, 3] = {{-1}}
 
SU23Cat1FMatrixFunction[1, 1, 2, 2] = 
   {{Root[-1 + #1^2 + #1^4 & , 2, 0], (-1 + Sqrt[5])/2}, 
    {(1 - Sqrt[5])/2, Root[-1 + #1^2 + #1^4 & , 2, 0]}}
 
SU23Cat1FMatrixFunction[1, 1, 3, 1] = {{-1}}
 
SU23Cat1FMatrixFunction[1, 2, 1, 2] = 
   {{(1 - Sqrt[5])/2, Root[-1 + #1^2 + #1^4 & , 1, 0]}, 
    {Root[-1 + #1^2 + #1^4 & , 1, 0], (-1 + Sqrt[5])/2}}
 
SU23Cat1FMatrixFunction[1, 2, 2, 1] = 
   {{Root[-1 + #1^2 + #1^4 & , 2, 0], (1 - Sqrt[5])/2}, 
    {(-1 + Sqrt[5])/2, Root[-1 + #1^2 + #1^4 & , 2, 0]}}
 
SU23Cat1FMatrixFunction[1, 2, 2, 3] = {{-1}}
 
SU23Cat1FMatrixFunction[1, 3, 1, 1] = {{-1}}
 
SU23Cat1FMatrixFunction[1, 3, 1, 3] = {{-1}}
 
SU23Cat1FMatrixFunction[1, 3, 2, 2] = {{-1}}
 
SU23Cat1FMatrixFunction[2, 1, 1, 2] = 
   {{Root[-1 + #1^2 + #1^4 & , 2, 0], (1 - Sqrt[5])/2}, 
    {(-1 + Sqrt[5])/2, Root[-1 + #1^2 + #1^4 & , 2, 0]}}
 
SU23Cat1FMatrixFunction[2, 1, 2, 1] = 
   {{(1 - Sqrt[5])/2, Root[-1 + #1^2 + #1^4 & , 1, 0]}, 
    {Root[-1 + #1^2 + #1^4 & , 1, 0], (-1 + Sqrt[5])/2}}
 
SU23Cat1FMatrixFunction[2, 1, 3, 2] = {{-1}}
 
SU23Cat1FMatrixFunction[2, 2, 1, 1] = 
   {{Root[-1 + #1^2 + #1^4 & , 2, 0], (-1 + Sqrt[5])/2}, 
    {(1 - Sqrt[5])/2, Root[-1 + #1^2 + #1^4 & , 2, 0]}}
 
SU23Cat1FMatrixFunction[2, 2, 1, 3] = {{-1}}
 
SU23Cat1FMatrixFunction[2, 2, 2, 2] = 
   {{(-1 + Sqrt[5])/2, Root[-1 + #1^2 + #1^4 & , 2, 0]}, 
    {Root[-1 + #1^2 + #1^4 & , 2, 0], (1 - Sqrt[5])/2}}
 
SU23Cat1FMatrixFunction[2, 2, 3, 1] = {{-1}}
 
SU23Cat1FMatrixFunction[2, 2, 3, 3] = {{-1}}
 
SU23Cat1FMatrixFunction[2, 3, 1, 2] = {{-1}}
 
SU23Cat1FMatrixFunction[2, 3, 3, 2] = {{-1}}
 
SU23Cat1FMatrixFunction[3, 1, 1, 1] = {{-1}}
 
SU23Cat1FMatrixFunction[3, 1, 2, 2] = {{-1}}
 
SU23Cat1FMatrixFunction[3, 1, 3, 1] = {{-1}}
 
SU23Cat1FMatrixFunction[3, 2, 2, 1] = {{-1}}
 
SU23Cat1FMatrixFunction[3, 2, 2, 3] = {{-1}}
 
SU23Cat1FMatrixFunction[3, 3, 2, 2] = {{-1}}
 
SU23Cat1FMatrixFunction[3, 3, 3, 3] = {{-1}}
 
SU23Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SU23Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
SU23Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SU23Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[SU23Cat1Piv1] ^= {SU23Cat1Bal1, SU23Cat1Bal3, 
    SU23Cat1Bal5, SU23Cat1Bal7}
 
SU23Cat1Piv1 /: balancedCategory[SU23Cat1Piv1, 1] = SU23Cat1Bal1
 
SU23Cat1Piv1 /: balancedCategory[SU23Cat1Piv1, 2] = SU23Cat1Bal3
 
SU23Cat1Piv1 /: balancedCategory[SU23Cat1Piv1, 3] = SU23Cat1Bal5
 
SU23Cat1Piv1 /: balancedCategory[SU23Cat1Piv1, 4] = SU23Cat1Bal7
 
fusionCategory[SU23Cat1Piv1] ^= SU23Cat1
 
SU23Cat1Piv1 /: modularCategory[SU23Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SU23Cat1Piv1] ^= SU23Cat1Piv1
 
pivotalIsomorphism[SU23Cat1Piv1] ^= SU23Cat1Piv1PivotalIsomorphism
 
SU23Cat1Piv1 /: ribbonCategory[SU23Cat1Piv1, 1] = SU23Cat1Bal1
 
SU23Cat1Piv1 /: ribbonCategory[SU23Cat1Piv1, 2] = SU23Cat1Bal3
 
SU23Cat1Piv1 /: ribbonCategory[SU23Cat1Piv1, 3] = SU23Cat1Bal5
 
SU23Cat1Piv1 /: ribbonCategory[SU23Cat1Piv1, 4] = SU23Cat1Bal7
 
ring[SU23Cat1Piv1] ^= SU23
 
sphericalCategory[SU23Cat1Piv1] ^= SU23Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[SU23Cat1]][pivotalCategory[#1]] & )[
    SU23Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[SU23Cat1]][sphericalCategory[#1]] & )[
    SU23Cat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[SU23Cat1Piv1PivotalIsomorphism] ^= SU23Cat1
 
pivotalCategory[SU23Cat1Piv1PivotalIsomorphism] ^= SU23Cat1Piv1
 
pivotalIsomorphism[SU23Cat1Piv1PivotalIsomorphism] ^= 
   SU23Cat1Piv1PivotalIsomorphism
 
SU23Cat1Piv1PivotalIsomorphism[0] = 1
 
SU23Cat1Piv1PivotalIsomorphism[1] = 1
 
SU23Cat1Piv1PivotalIsomorphism[2] = 1
 
SU23Cat1Piv1PivotalIsomorphism[3] = 1
balancedCategories[SU23Cat1Piv2] ^= {SU23Cat1Bal2, SU23Cat1Bal4, 
    SU23Cat1Bal6, SU23Cat1Bal8}
 
SU23Cat1Piv2 /: balancedCategory[SU23Cat1Piv2, 1] = SU23Cat1Bal2
 
SU23Cat1Piv2 /: balancedCategory[SU23Cat1Piv2, 2] = SU23Cat1Bal4
 
SU23Cat1Piv2 /: balancedCategory[SU23Cat1Piv2, 3] = SU23Cat1Bal6
 
SU23Cat1Piv2 /: balancedCategory[SU23Cat1Piv2, 4] = SU23Cat1Bal8
 
fusionCategory[SU23Cat1Piv2] ^= SU23Cat1
 
SU23Cat1Piv2 /: modularCategory[SU23Cat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SU23Cat1Piv2] ^= SU23Cat1Piv2
 
pivotalIsomorphism[SU23Cat1Piv2] ^= SU23Cat1Piv2PivotalIsomorphism
 
SU23Cat1Piv2 /: ribbonCategory[SU23Cat1Piv2, 1] = SU23Cat1Bal2
 
SU23Cat1Piv2 /: ribbonCategory[SU23Cat1Piv2, 2] = SU23Cat1Bal4
 
SU23Cat1Piv2 /: ribbonCategory[SU23Cat1Piv2, 3] = SU23Cat1Bal6
 
SU23Cat1Piv2 /: ribbonCategory[SU23Cat1Piv2, 4] = SU23Cat1Bal8
 
ring[SU23Cat1Piv2] ^= SU23
 
sphericalCategory[SU23Cat1Piv2] ^= SU23Cat1Piv2
 
(pivotalCategoryIndex[fusionCategory[SU23Cat1]][pivotalCategory[#1]] & )[
    SU23Cat1Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[SU23Cat1]][sphericalCategory[#1]] & )[
    SU23Cat1Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[SU23Cat1Piv2PivotalIsomorphism] ^= SU23Cat1
 
pivotalCategory[SU23Cat1Piv2PivotalIsomorphism] ^= SU23Cat1Piv2
 
pivotalIsomorphism[SU23Cat1Piv2PivotalIsomorphism] ^= 
   SU23Cat1Piv2PivotalIsomorphism
 
SU23Cat1Piv2PivotalIsomorphism[0] = 1
 
SU23Cat1Piv2PivotalIsomorphism[1] = -1
 
SU23Cat1Piv2PivotalIsomorphism[2] = 1
 
SU23Cat1Piv2PivotalIsomorphism[3] = -1
balancedCategories[SU23Cat2] ^= {SU23Cat2Bal1, SU23Cat2Bal2, SU23Cat2Bal3, 
    SU23Cat2Bal4, SU23Cat2Bal5, SU23Cat2Bal6, SU23Cat2Bal7, SU23Cat2Bal8}
 
SU23Cat2 /: balancedCategory[SU23Cat2, 1] = SU23Cat2Bal1
 
SU23Cat2 /: balancedCategory[SU23Cat2, 2] = SU23Cat2Bal2
 
SU23Cat2 /: balancedCategory[SU23Cat2, 3] = SU23Cat2Bal3
 
SU23Cat2 /: balancedCategory[SU23Cat2, 4] = SU23Cat2Bal4
 
SU23Cat2 /: balancedCategory[SU23Cat2, 5] = SU23Cat2Bal5
 
SU23Cat2 /: balancedCategory[SU23Cat2, 6] = SU23Cat2Bal6
 
SU23Cat2 /: balancedCategory[SU23Cat2, 7] = SU23Cat2Bal7
 
SU23Cat2 /: balancedCategory[SU23Cat2, 8] = SU23Cat2Bal8
 
braidedCategories[SU23Cat2] ^= {SU23Cat2Brd1, SU23Cat2Brd2, SU23Cat2Brd3, 
    SU23Cat2Brd4}
 
SU23Cat2 /: braidedCategory[SU23Cat2, 1] = SU23Cat2Brd1
 
SU23Cat2 /: braidedCategory[SU23Cat2, 2] = SU23Cat2Brd2
 
SU23Cat2 /: braidedCategory[SU23Cat2, 3] = SU23Cat2Brd3
 
SU23Cat2 /: braidedCategory[SU23Cat2, 4] = SU23Cat2Brd4
 
coeval[SU23Cat2] ^= 1/sixJFunction[SU23Cat2][#1, dual[ring[SU23Cat2]][#1], 
      #1, #1, 0, 0] & 
 
eval[SU23Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[SU23Cat2] ^= SU23Cat2FMatrixFunction
 
fusionCategory[SU23Cat2] ^= SU23Cat2
 
SU23Cat2 /: modularCategory[SU23Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[SU23Cat2] ^= {SU23Cat2Piv1, SU23Cat2Piv2}
 
SU23Cat2 /: pivotalCategory[SU23Cat2, 1] = SU23Cat2Piv1
 
SU23Cat2 /: pivotalCategory[SU23Cat2, 2] = SU23Cat2Piv2
 
SU23Cat2 /: pivotalCategory[SU23Cat2, {1, -1, 1, -1}] = SU23Cat2Piv2
 
SU23Cat2 /: pivotalCategory[SU23Cat2, {1, 1, 1, 1}] = SU23Cat2Piv1
 
SU23Cat2 /: ribbonCategory[SU23Cat2, 1] = SU23Cat2Bal1
 
SU23Cat2 /: ribbonCategory[SU23Cat2, 2] = SU23Cat2Bal2
 
SU23Cat2 /: ribbonCategory[SU23Cat2, 3] = SU23Cat2Bal3
 
SU23Cat2 /: ribbonCategory[SU23Cat2, 4] = SU23Cat2Bal4
 
SU23Cat2 /: ribbonCategory[SU23Cat2, 5] = SU23Cat2Bal5
 
SU23Cat2 /: ribbonCategory[SU23Cat2, 6] = SU23Cat2Bal6
 
SU23Cat2 /: ribbonCategory[SU23Cat2, 7] = SU23Cat2Bal7
 
SU23Cat2 /: ribbonCategory[SU23Cat2, 8] = SU23Cat2Bal8
 
ring[SU23Cat2] ^= SU23
 
SU23Cat2 /: sphericalCategory[SU23Cat2, 1] = SU23Cat2Piv1
 
SU23Cat2 /: sphericalCategory[SU23Cat2, 2] = SU23Cat2Piv2
 
fusionCategoryIndex[SU23][SU23Cat2] ^= 2
balancedCategory[SU23Cat2Bal1] ^= SU23Cat2Bal1
 
braidedCategory[SU23Cat2Bal1] ^= SU23Cat2Brd1
 
fusionCategory[SU23Cat2Bal1] ^= SU23Cat2
 
pivotalCategory[SU23Cat2Bal1] ^= SU23Cat2Piv1
 
ribbonCategory[SU23Cat2Bal1] ^= SU23Cat2Bal1
 
ring[SU23Cat2Bal1] ^= SU23
 
sphericalCategory[SU23Cat2Bal1] ^= SU23Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[SU23Cat2Brd1]][
      balancedCategory[#1]] & )[SU23Cat2Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[SU23Cat2]][balancedCategory[#1]] & )[
    SU23Cat2Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[SU23Cat2Piv1]][
      balancedCategory[#1]] & )[SU23Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SU23Cat2Brd1]][ribbonCategory[#1]] & )[
    SU23Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SU23Cat2]][ribbonCategory[#1]] & )[
    SU23Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat2Piv1]][ribbonCategory[#1]] & )[
    SU23Cat2Bal1] ^= 1
balancedCategory[SU23Cat2Bal2] ^= SU23Cat2Bal2
 
braidedCategory[SU23Cat2Bal2] ^= SU23Cat2Brd1
 
fusionCategory[SU23Cat2Bal2] ^= SU23Cat2
 
pivotalCategory[SU23Cat2Bal2] ^= SU23Cat2Piv2
 
ribbonCategory[SU23Cat2Bal2] ^= SU23Cat2Bal2
 
ring[SU23Cat2Bal2] ^= SU23
 
sphericalCategory[SU23Cat2Bal2] ^= SU23Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[SU23Cat2Brd1]][
      balancedCategory[#1]] & )[SU23Cat2Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[SU23Cat2]][balancedCategory[#1]] & )[
    SU23Cat2Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[SU23Cat2Piv2]][
      balancedCategory[#1]] & )[SU23Cat2Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SU23Cat2Brd1]][ribbonCategory[#1]] & )[
    SU23Cat2Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SU23Cat2]][ribbonCategory[#1]] & )[
    SU23Cat2Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat2Piv2]][ribbonCategory[#1]] & )[
    SU23Cat2Bal2] ^= 1
balancedCategory[SU23Cat2Bal3] ^= SU23Cat2Bal3
 
braidedCategory[SU23Cat2Bal3] ^= SU23Cat2Brd2
 
fusionCategory[SU23Cat2Bal3] ^= SU23Cat2
 
pivotalCategory[SU23Cat2Bal3] ^= SU23Cat2Piv1
 
ribbonCategory[SU23Cat2Bal3] ^= SU23Cat2Bal3
 
ring[SU23Cat2Bal3] ^= SU23
 
sphericalCategory[SU23Cat2Bal3] ^= SU23Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[SU23Cat2Brd2]][
      balancedCategory[#1]] & )[SU23Cat2Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[SU23Cat2]][balancedCategory[#1]] & )[
    SU23Cat2Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[SU23Cat2Piv1]][
      balancedCategory[#1]] & )[SU23Cat2Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SU23Cat2Brd2]][ribbonCategory[#1]] & )[
    SU23Cat2Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SU23Cat2]][ribbonCategory[#1]] & )[
    SU23Cat2Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat2Piv1]][ribbonCategory[#1]] & )[
    SU23Cat2Bal3] ^= 2
balancedCategory[SU23Cat2Bal4] ^= SU23Cat2Bal4
 
braidedCategory[SU23Cat2Bal4] ^= SU23Cat2Brd2
 
fusionCategory[SU23Cat2Bal4] ^= SU23Cat2
 
pivotalCategory[SU23Cat2Bal4] ^= SU23Cat2Piv2
 
ribbonCategory[SU23Cat2Bal4] ^= SU23Cat2Bal4
 
ring[SU23Cat2Bal4] ^= SU23
 
sphericalCategory[SU23Cat2Bal4] ^= SU23Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[SU23Cat2Brd2]][
      balancedCategory[#1]] & )[SU23Cat2Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[SU23Cat2]][balancedCategory[#1]] & )[
    SU23Cat2Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[SU23Cat2Piv2]][
      balancedCategory[#1]] & )[SU23Cat2Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SU23Cat2Brd2]][ribbonCategory[#1]] & )[
    SU23Cat2Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SU23Cat2]][ribbonCategory[#1]] & )[
    SU23Cat2Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat2Piv2]][ribbonCategory[#1]] & )[
    SU23Cat2Bal4] ^= 2
balancedCategory[SU23Cat2Bal5] ^= SU23Cat2Bal5
 
braidedCategory[SU23Cat2Bal5] ^= SU23Cat2Brd3
 
fusionCategory[SU23Cat2Bal5] ^= SU23Cat2
 
pivotalCategory[SU23Cat2Bal5] ^= SU23Cat2Piv1
 
ribbonCategory[SU23Cat2Bal5] ^= SU23Cat2Bal5
 
ring[SU23Cat2Bal5] ^= SU23
 
sphericalCategory[SU23Cat2Bal5] ^= SU23Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[SU23Cat2Brd3]][
      balancedCategory[#1]] & )[SU23Cat2Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[SU23Cat2]][balancedCategory[#1]] & )[
    SU23Cat2Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[SU23Cat2Piv1]][
      balancedCategory[#1]] & )[SU23Cat2Bal5] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SU23Cat2Brd3]][ribbonCategory[#1]] & )[
    SU23Cat2Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SU23Cat2]][ribbonCategory[#1]] & )[
    SU23Cat2Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat2Piv1]][ribbonCategory[#1]] & )[
    SU23Cat2Bal5] ^= 3
balancedCategory[SU23Cat2Bal6] ^= SU23Cat2Bal6
 
braidedCategory[SU23Cat2Bal6] ^= SU23Cat2Brd3
 
fusionCategory[SU23Cat2Bal6] ^= SU23Cat2
 
pivotalCategory[SU23Cat2Bal6] ^= SU23Cat2Piv2
 
ribbonCategory[SU23Cat2Bal6] ^= SU23Cat2Bal6
 
ring[SU23Cat2Bal6] ^= SU23
 
sphericalCategory[SU23Cat2Bal6] ^= SU23Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[SU23Cat2Brd3]][
      balancedCategory[#1]] & )[SU23Cat2Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[SU23Cat2]][balancedCategory[#1]] & )[
    SU23Cat2Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[SU23Cat2Piv2]][
      balancedCategory[#1]] & )[SU23Cat2Bal6] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SU23Cat2Brd3]][ribbonCategory[#1]] & )[
    SU23Cat2Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SU23Cat2]][ribbonCategory[#1]] & )[
    SU23Cat2Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat2Piv2]][ribbonCategory[#1]] & )[
    SU23Cat2Bal6] ^= 3
balancedCategory[SU23Cat2Bal7] ^= SU23Cat2Bal7
 
braidedCategory[SU23Cat2Bal7] ^= SU23Cat2Brd4
 
fusionCategory[SU23Cat2Bal7] ^= SU23Cat2
 
pivotalCategory[SU23Cat2Bal7] ^= SU23Cat2Piv1
 
ribbonCategory[SU23Cat2Bal7] ^= SU23Cat2Bal7
 
ring[SU23Cat2Bal7] ^= SU23
 
sphericalCategory[SU23Cat2Bal7] ^= SU23Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[SU23Cat2Brd4]][
      balancedCategory[#1]] & )[SU23Cat2Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[SU23Cat2]][balancedCategory[#1]] & )[
    SU23Cat2Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[SU23Cat2Piv1]][
      balancedCategory[#1]] & )[SU23Cat2Bal7] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SU23Cat2Brd4]][ribbonCategory[#1]] & )[
    SU23Cat2Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SU23Cat2]][ribbonCategory[#1]] & )[
    SU23Cat2Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat2Piv1]][ribbonCategory[#1]] & )[
    SU23Cat2Bal7] ^= 4
balancedCategory[SU23Cat2Bal8] ^= SU23Cat2Bal8
 
braidedCategory[SU23Cat2Bal8] ^= SU23Cat2Brd4
 
fusionCategory[SU23Cat2Bal8] ^= SU23Cat2
 
pivotalCategory[SU23Cat2Bal8] ^= SU23Cat2Piv2
 
ribbonCategory[SU23Cat2Bal8] ^= SU23Cat2Bal8
 
ring[SU23Cat2Bal8] ^= SU23
 
sphericalCategory[SU23Cat2Bal8] ^= SU23Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[SU23Cat2Brd4]][
      balancedCategory[#1]] & )[SU23Cat2Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[SU23Cat2]][balancedCategory[#1]] & )[
    SU23Cat2Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[SU23Cat2Piv2]][
      balancedCategory[#1]] & )[SU23Cat2Bal8] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SU23Cat2Brd4]][ribbonCategory[#1]] & )[
    SU23Cat2Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SU23Cat2]][ribbonCategory[#1]] & )[
    SU23Cat2Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat2Piv2]][ribbonCategory[#1]] & )[
    SU23Cat2Bal8] ^= 4
balancedCategories[SU23Cat2Brd1] ^= {SU23Cat2Bal1, SU23Cat2Bal2}
 
SU23Cat2Brd1 /: balancedCategory[SU23Cat2Brd1, 1] = SU23Cat2Bal1
 
SU23Cat2Brd1 /: balancedCategory[SU23Cat2Brd1, 2] = SU23Cat2Bal2
 
braidedCategory[SU23Cat2Brd1] ^= SU23Cat2Brd1
 
fusionCategory[SU23Cat2Brd1] ^= SU23Cat2
 
SU23Cat2Brd1 /: modularCategory[SU23Cat2Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SU23Cat2Brd1 /: ribbonCategory[SU23Cat2Brd1, 1] = SU23Cat2Bal1
 
SU23Cat2Brd1 /: ribbonCategory[SU23Cat2Brd1, 2] = SU23Cat2Bal2
 
ring[SU23Cat2Brd1] ^= SU23
 
rMatrixFunction[SU23Cat2Brd1] ^= SU23Cat2Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SU23Cat2]][braidedCategory[#1]] & )[
    SU23Cat2Brd1] ^= 1
fusionCategory[SU23Cat2Brd1RMatrixFunction] ^= SU23Cat2
 
rMatrixFunction[SU23Cat2Brd1RMatrixFunction] ^= SU23Cat2Brd1RMatrixFunction
 
SU23Cat2Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
SU23Cat2Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
SU23Cat2Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
SU23Cat2Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
SU23Cat2Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
SU23Cat2Brd1RMatrixFunction[1, 1, 0] = {{(-1)^(1/5)}}
 
SU23Cat2Brd1RMatrixFunction[1, 1, 2] = {{-(-1)^(3/5)}}
 
SU23Cat2Brd1RMatrixFunction[1, 2, 1] = {{(-1)^(3/5)}}
 
SU23Cat2Brd1RMatrixFunction[1, 2, 3] = {{-(-1)^(1/5)}}
 
SU23Cat2Brd1RMatrixFunction[1, 3, 2] = {{1}}
 
SU23Cat2Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
SU23Cat2Brd1RMatrixFunction[2, 1, 1] = {{(-1)^(3/5)}}
 
SU23Cat2Brd1RMatrixFunction[2, 1, 3] = {{-(-1)^(1/5)}}
 
SU23Cat2Brd1RMatrixFunction[2, 2, 0] = {{-(-1)^(1/5)}}
 
SU23Cat2Brd1RMatrixFunction[2, 2, 2] = {{(-1)^(3/5)}}
 
SU23Cat2Brd1RMatrixFunction[2, 3, 1] = {{1}}
 
SU23Cat2Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
SU23Cat2Brd1RMatrixFunction[3, 1, 2] = {{1}}
 
SU23Cat2Brd1RMatrixFunction[3, 2, 1] = {{1}}
 
SU23Cat2Brd1RMatrixFunction[3, 3, 0] = {{-1}}
balancedCategories[SU23Cat2Brd2] ^= {SU23Cat2Bal3, SU23Cat2Bal4}
 
SU23Cat2Brd2 /: balancedCategory[SU23Cat2Brd2, 1] = SU23Cat2Bal3
 
SU23Cat2Brd2 /: balancedCategory[SU23Cat2Brd2, 2] = SU23Cat2Bal4
 
braidedCategory[SU23Cat2Brd2] ^= SU23Cat2Brd2
 
fusionCategory[SU23Cat2Brd2] ^= SU23Cat2
 
SU23Cat2Brd2 /: modularCategory[SU23Cat2Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SU23Cat2Brd2 /: ribbonCategory[SU23Cat2Brd2, 1] = SU23Cat2Bal3
 
SU23Cat2Brd2 /: ribbonCategory[SU23Cat2Brd2, 2] = SU23Cat2Bal4
 
ring[SU23Cat2Brd2] ^= SU23
 
rMatrixFunction[SU23Cat2Brd2] ^= SU23Cat2Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SU23Cat2]][braidedCategory[#1]] & )[
    SU23Cat2Brd2] ^= 2
fusionCategory[SU23Cat2Brd2RMatrixFunction] ^= SU23Cat2
 
rMatrixFunction[SU23Cat2Brd2RMatrixFunction] ^= SU23Cat2Brd2RMatrixFunction
 
SU23Cat2Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
SU23Cat2Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
SU23Cat2Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
SU23Cat2Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
SU23Cat2Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
SU23Cat2Brd2RMatrixFunction[1, 1, 0] = {{(-1)^(4/5)}}
 
SU23Cat2Brd2RMatrixFunction[1, 1, 2] = {{-(-1)^(2/5)}}
 
SU23Cat2Brd2RMatrixFunction[1, 2, 1] = {{-(-1)^(2/5)}}
 
SU23Cat2Brd2RMatrixFunction[1, 2, 3] = {{(-1)^(4/5)}}
 
SU23Cat2Brd2RMatrixFunction[1, 3, 2] = {{-1}}
 
SU23Cat2Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
SU23Cat2Brd2RMatrixFunction[2, 1, 1] = {{-(-1)^(2/5)}}
 
SU23Cat2Brd2RMatrixFunction[2, 1, 3] = {{(-1)^(4/5)}}
 
SU23Cat2Brd2RMatrixFunction[2, 2, 0] = {{(-1)^(4/5)}}
 
SU23Cat2Brd2RMatrixFunction[2, 2, 2] = {{-(-1)^(2/5)}}
 
SU23Cat2Brd2RMatrixFunction[2, 3, 1] = {{1}}
 
SU23Cat2Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
SU23Cat2Brd2RMatrixFunction[3, 1, 2] = {{-1}}
 
SU23Cat2Brd2RMatrixFunction[3, 2, 1] = {{1}}
 
SU23Cat2Brd2RMatrixFunction[3, 3, 0] = {{1}}
balancedCategories[SU23Cat2Brd3] ^= {SU23Cat2Bal5, SU23Cat2Bal6}
 
SU23Cat2Brd3 /: balancedCategory[SU23Cat2Brd3, 1] = SU23Cat2Bal5
 
SU23Cat2Brd3 /: balancedCategory[SU23Cat2Brd3, 2] = SU23Cat2Bal6
 
braidedCategory[SU23Cat2Brd3] ^= SU23Cat2Brd3
 
fusionCategory[SU23Cat2Brd3] ^= SU23Cat2
 
SU23Cat2Brd3 /: modularCategory[SU23Cat2Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SU23Cat2Brd3 /: ribbonCategory[SU23Cat2Brd3, 1] = SU23Cat2Bal5
 
SU23Cat2Brd3 /: ribbonCategory[SU23Cat2Brd3, 2] = SU23Cat2Bal6
 
ring[SU23Cat2Brd3] ^= SU23
 
rMatrixFunction[SU23Cat2Brd3] ^= SU23Cat2Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SU23Cat2]][braidedCategory[#1]] & )[
    SU23Cat2Brd3] ^= 3
fusionCategory[SU23Cat2Brd3RMatrixFunction] ^= SU23Cat2
 
rMatrixFunction[SU23Cat2Brd3RMatrixFunction] ^= SU23Cat2Brd3RMatrixFunction
 
SU23Cat2Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
SU23Cat2Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
SU23Cat2Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
SU23Cat2Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
SU23Cat2Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
SU23Cat2Brd3RMatrixFunction[1, 1, 0] = {{-(-1)^(4/5)}}
 
SU23Cat2Brd3RMatrixFunction[1, 1, 2] = {{(-1)^(2/5)}}
 
SU23Cat2Brd3RMatrixFunction[1, 2, 1] = {{-(-1)^(2/5)}}
 
SU23Cat2Brd3RMatrixFunction[1, 2, 3] = {{(-1)^(4/5)}}
 
SU23Cat2Brd3RMatrixFunction[1, 3, 2] = {{1}}
 
SU23Cat2Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
SU23Cat2Brd3RMatrixFunction[2, 1, 1] = {{-(-1)^(2/5)}}
 
SU23Cat2Brd3RMatrixFunction[2, 1, 3] = {{(-1)^(4/5)}}
 
SU23Cat2Brd3RMatrixFunction[2, 2, 0] = {{(-1)^(4/5)}}
 
SU23Cat2Brd3RMatrixFunction[2, 2, 2] = {{-(-1)^(2/5)}}
 
SU23Cat2Brd3RMatrixFunction[2, 3, 1] = {{1}}
 
SU23Cat2Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
SU23Cat2Brd3RMatrixFunction[3, 1, 2] = {{1}}
 
SU23Cat2Brd3RMatrixFunction[3, 2, 1] = {{1}}
 
SU23Cat2Brd3RMatrixFunction[3, 3, 0] = {{-1}}
balancedCategories[SU23Cat2Brd4] ^= {SU23Cat2Bal7, SU23Cat2Bal8}
 
SU23Cat2Brd4 /: balancedCategory[SU23Cat2Brd4, 1] = SU23Cat2Bal7
 
SU23Cat2Brd4 /: balancedCategory[SU23Cat2Brd4, 2] = SU23Cat2Bal8
 
braidedCategory[SU23Cat2Brd4] ^= SU23Cat2Brd4
 
fusionCategory[SU23Cat2Brd4] ^= SU23Cat2
 
SU23Cat2Brd4 /: modularCategory[SU23Cat2Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SU23Cat2Brd4 /: ribbonCategory[SU23Cat2Brd4, 1] = SU23Cat2Bal7
 
SU23Cat2Brd4 /: ribbonCategory[SU23Cat2Brd4, 2] = SU23Cat2Bal8
 
ring[SU23Cat2Brd4] ^= SU23
 
rMatrixFunction[SU23Cat2Brd4] ^= SU23Cat2Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SU23Cat2]][braidedCategory[#1]] & )[
    SU23Cat2Brd4] ^= 4
fusionCategory[SU23Cat2Brd4RMatrixFunction] ^= SU23Cat2
 
rMatrixFunction[SU23Cat2Brd4RMatrixFunction] ^= SU23Cat2Brd4RMatrixFunction
 
SU23Cat2Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
SU23Cat2Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
SU23Cat2Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
SU23Cat2Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
SU23Cat2Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
SU23Cat2Brd4RMatrixFunction[1, 1, 0] = {{-(-1)^(1/5)}}
 
SU23Cat2Brd4RMatrixFunction[1, 1, 2] = {{(-1)^(3/5)}}
 
SU23Cat2Brd4RMatrixFunction[1, 2, 1] = {{(-1)^(3/5)}}
 
SU23Cat2Brd4RMatrixFunction[1, 2, 3] = {{-(-1)^(1/5)}}
 
SU23Cat2Brd4RMatrixFunction[1, 3, 2] = {{-1}}
 
SU23Cat2Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
SU23Cat2Brd4RMatrixFunction[2, 1, 1] = {{(-1)^(3/5)}}
 
SU23Cat2Brd4RMatrixFunction[2, 1, 3] = {{-(-1)^(1/5)}}
 
SU23Cat2Brd4RMatrixFunction[2, 2, 0] = {{-(-1)^(1/5)}}
 
SU23Cat2Brd4RMatrixFunction[2, 2, 2] = {{(-1)^(3/5)}}
 
SU23Cat2Brd4RMatrixFunction[2, 3, 1] = {{1}}
 
SU23Cat2Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
SU23Cat2Brd4RMatrixFunction[3, 1, 2] = {{-1}}
 
SU23Cat2Brd4RMatrixFunction[3, 2, 1] = {{1}}
 
SU23Cat2Brd4RMatrixFunction[3, 3, 0] = {{1}}
fMatrixFunction[SU23Cat2FMatrixFunction] ^= SU23Cat2FMatrixFunction
 
ring[SU23Cat2FMatrixFunction] ^= SU23
 
SU23Cat2FMatrixFunction[1, 1, 1, 1] = 
   {{(-1 + Sqrt[5])/2, Root[-1 + #1^2 + #1^4 & , 2, 0]}, 
    {Root[-1 + #1^2 + #1^4 & , 2, 0], (1 - Sqrt[5])/2}}
 
SU23Cat2FMatrixFunction[1, 1, 2, 2] = 
   {{Root[-1 + #1^2 + #1^4 & , 2, 0], (-1 + Sqrt[5])/2}, 
    {(-1 + Sqrt[5])/2, Root[-1 + #1^2 + #1^4 & , 1, 0]}}
 
SU23Cat2FMatrixFunction[1, 2, 1, 2] = 
   {{(1 - Sqrt[5])/2, Root[-1 + #1^2 + #1^4 & , 1, 0]}, 
    {Root[-1 + #1^2 + #1^4 & , 2, 0], (1 - Sqrt[5])/2}}
 
SU23Cat2FMatrixFunction[1, 2, 2, 1] = 
   {{Root[-1 + #1^2 + #1^4 & , 2, 0], (-1 + Sqrt[5])/2}, 
    {(-1 + Sqrt[5])/2, Root[-1 + #1^2 + #1^4 & , 1, 0]}}
 
SU23Cat2FMatrixFunction[1, 2, 2, 3] = {{-1}}
 
SU23Cat2FMatrixFunction[1, 3, 1, 1] = {{-1}}
 
SU23Cat2FMatrixFunction[1, 3, 1, 3] = {{-1}}
 
SU23Cat2FMatrixFunction[1, 3, 2, 2] = {{-1}}
 
SU23Cat2FMatrixFunction[2, 1, 1, 2] = 
   {{Root[-1 + #1^2 + #1^4 & , 2, 0], (1 - Sqrt[5])/2}, 
    {(-1 + Sqrt[5])/2, Root[-1 + #1^2 + #1^4 & , 2, 0]}}
 
SU23Cat2FMatrixFunction[2, 1, 2, 1] = 
   {{(1 - Sqrt[5])/2, Root[-1 + #1^2 + #1^4 & , 2, 0]}, 
    {Root[-1 + #1^2 + #1^4 & , 2, 0], (-1 + Sqrt[5])/2}}
 
SU23Cat2FMatrixFunction[2, 1, 3, 2] = {{-1}}
 
SU23Cat2FMatrixFunction[2, 2, 1, 1] = 
   {{Root[-1 + #1^2 + #1^4 & , 2, 0], (-1 + Sqrt[5])/2}, 
    {(-1 + Sqrt[5])/2, Root[-1 + #1^2 + #1^4 & , 1, 0]}}
 
SU23Cat2FMatrixFunction[2, 2, 1, 3] = {{-1}}
 
SU23Cat2FMatrixFunction[2, 2, 2, 2] = 
   {{(-1 + Sqrt[5])/2, Root[-1 + #1^2 + #1^4 & , 2, 0]}, 
    {Root[-1 + #1^2 + #1^4 & , 2, 0], (1 - Sqrt[5])/2}}
 
SU23Cat2FMatrixFunction[2, 2, 3, 1] = {{-1}}
 
SU23Cat2FMatrixFunction[2, 3, 1, 0] = {{-1}}
 
SU23Cat2FMatrixFunction[3, 1, 1, 1] = {{-1}}
 
SU23Cat2FMatrixFunction[3, 1, 1, 3] = {{-1}}
 
SU23Cat2FMatrixFunction[3, 1, 2, 0] = {{-1}}
 
SU23Cat2FMatrixFunction[3, 1, 2, 2] = {{-1}}
 
SU23Cat2FMatrixFunction[3, 1, 3, 1] = {{-1}}
 
SU23Cat2FMatrixFunction[3, 2, 1, 2] = {{-1}}
 
SU23Cat2FMatrixFunction[3, 2, 2, 1] = {{-1}}
 
SU23Cat2FMatrixFunction[3, 2, 3, 2] = {{-1}}
 
SU23Cat2FMatrixFunction[3, 3, 1, 1] = {{-1}}
 
SU23Cat2FMatrixFunction[3, 3, 2, 2] = {{-1}}
 
SU23Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SU23Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
SU23Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SU23Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[SU23Cat2Piv1] ^= {SU23Cat2Bal1, SU23Cat2Bal3, 
    SU23Cat2Bal5, SU23Cat2Bal7}
 
SU23Cat2Piv1 /: balancedCategory[SU23Cat2Piv1, 1] = SU23Cat2Bal1
 
SU23Cat2Piv1 /: balancedCategory[SU23Cat2Piv1, 2] = SU23Cat2Bal3
 
SU23Cat2Piv1 /: balancedCategory[SU23Cat2Piv1, 3] = SU23Cat2Bal5
 
SU23Cat2Piv1 /: balancedCategory[SU23Cat2Piv1, 4] = SU23Cat2Bal7
 
fusionCategory[SU23Cat2Piv1] ^= SU23Cat2
 
SU23Cat2Piv1 /: modularCategory[SU23Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SU23Cat2Piv1] ^= SU23Cat2Piv1
 
pivotalIsomorphism[SU23Cat2Piv1] ^= SU23Cat2Piv1PivotalIsomorphism
 
SU23Cat2Piv1 /: ribbonCategory[SU23Cat2Piv1, 1] = SU23Cat2Bal1
 
SU23Cat2Piv1 /: ribbonCategory[SU23Cat2Piv1, 2] = SU23Cat2Bal3
 
SU23Cat2Piv1 /: ribbonCategory[SU23Cat2Piv1, 3] = SU23Cat2Bal5
 
SU23Cat2Piv1 /: ribbonCategory[SU23Cat2Piv1, 4] = SU23Cat2Bal7
 
ring[SU23Cat2Piv1] ^= SU23
 
sphericalCategory[SU23Cat2Piv1] ^= SU23Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[SU23Cat2]][pivotalCategory[#1]] & )[
    SU23Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[SU23Cat2]][sphericalCategory[#1]] & )[
    SU23Cat2Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[SU23Cat2Piv1PivotalIsomorphism] ^= SU23Cat2
 
pivotalCategory[SU23Cat2Piv1PivotalIsomorphism] ^= SU23Cat2Piv1
 
pivotalIsomorphism[SU23Cat2Piv1PivotalIsomorphism] ^= 
   SU23Cat2Piv1PivotalIsomorphism
 
SU23Cat2Piv1PivotalIsomorphism[0] = 1
 
SU23Cat2Piv1PivotalIsomorphism[1] = 1
 
SU23Cat2Piv1PivotalIsomorphism[2] = 1
 
SU23Cat2Piv1PivotalIsomorphism[3] = 1
balancedCategories[SU23Cat2Piv2] ^= {SU23Cat2Bal2, SU23Cat2Bal4, 
    SU23Cat2Bal6, SU23Cat2Bal8}
 
SU23Cat2Piv2 /: balancedCategory[SU23Cat2Piv2, 1] = SU23Cat2Bal2
 
SU23Cat2Piv2 /: balancedCategory[SU23Cat2Piv2, 2] = SU23Cat2Bal4
 
SU23Cat2Piv2 /: balancedCategory[SU23Cat2Piv2, 3] = SU23Cat2Bal6
 
SU23Cat2Piv2 /: balancedCategory[SU23Cat2Piv2, 4] = SU23Cat2Bal8
 
fusionCategory[SU23Cat2Piv2] ^= SU23Cat2
 
SU23Cat2Piv2 /: modularCategory[SU23Cat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SU23Cat2Piv2] ^= SU23Cat2Piv2
 
pivotalIsomorphism[SU23Cat2Piv2] ^= SU23Cat2Piv2PivotalIsomorphism
 
SU23Cat2Piv2 /: ribbonCategory[SU23Cat2Piv2, 1] = SU23Cat2Bal2
 
SU23Cat2Piv2 /: ribbonCategory[SU23Cat2Piv2, 2] = SU23Cat2Bal4
 
SU23Cat2Piv2 /: ribbonCategory[SU23Cat2Piv2, 3] = SU23Cat2Bal6
 
SU23Cat2Piv2 /: ribbonCategory[SU23Cat2Piv2, 4] = SU23Cat2Bal8
 
ring[SU23Cat2Piv2] ^= SU23
 
sphericalCategory[SU23Cat2Piv2] ^= SU23Cat2Piv2
 
(pivotalCategoryIndex[fusionCategory[SU23Cat2]][pivotalCategory[#1]] & )[
    SU23Cat2Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[SU23Cat2]][sphericalCategory[#1]] & )[
    SU23Cat2Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[SU23Cat2Piv2PivotalIsomorphism] ^= SU23Cat2
 
pivotalCategory[SU23Cat2Piv2PivotalIsomorphism] ^= SU23Cat2Piv2
 
pivotalIsomorphism[SU23Cat2Piv2PivotalIsomorphism] ^= 
   SU23Cat2Piv2PivotalIsomorphism
 
SU23Cat2Piv2PivotalIsomorphism[0] = 1
 
SU23Cat2Piv2PivotalIsomorphism[1] = -1
 
SU23Cat2Piv2PivotalIsomorphism[2] = 1
 
SU23Cat2Piv2PivotalIsomorphism[3] = -1
balancedCategories[SU23Cat3] ^= {SU23Cat3Bal1, SU23Cat3Bal2, SU23Cat3Bal3, 
    SU23Cat3Bal4, SU23Cat3Bal5, SU23Cat3Bal6, SU23Cat3Bal7, SU23Cat3Bal8}
 
SU23Cat3 /: balancedCategory[SU23Cat3, 1] = SU23Cat3Bal1
 
SU23Cat3 /: balancedCategory[SU23Cat3, 2] = SU23Cat3Bal2
 
SU23Cat3 /: balancedCategory[SU23Cat3, 3] = SU23Cat3Bal3
 
SU23Cat3 /: balancedCategory[SU23Cat3, 4] = SU23Cat3Bal4
 
SU23Cat3 /: balancedCategory[SU23Cat3, 5] = SU23Cat3Bal5
 
SU23Cat3 /: balancedCategory[SU23Cat3, 6] = SU23Cat3Bal6
 
SU23Cat3 /: balancedCategory[SU23Cat3, 7] = SU23Cat3Bal7
 
SU23Cat3 /: balancedCategory[SU23Cat3, 8] = SU23Cat3Bal8
 
braidedCategories[SU23Cat3] ^= {SU23Cat3Brd1, SU23Cat3Brd2, SU23Cat3Brd3, 
    SU23Cat3Brd4}
 
SU23Cat3 /: braidedCategory[SU23Cat3, 1] = SU23Cat3Brd1
 
SU23Cat3 /: braidedCategory[SU23Cat3, 2] = SU23Cat3Brd2
 
SU23Cat3 /: braidedCategory[SU23Cat3, 3] = SU23Cat3Brd3
 
SU23Cat3 /: braidedCategory[SU23Cat3, 4] = SU23Cat3Brd4
 
coeval[SU23Cat3] ^= 1/sixJFunction[SU23Cat3][#1, dual[ring[SU23Cat3]][#1], 
      #1, #1, 0, 0] & 
 
eval[SU23Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[SU23Cat3] ^= SU23Cat3FMatrixFunction
 
fusionCategory[SU23Cat3] ^= SU23Cat3
 
SU23Cat3 /: modularCategory[SU23Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[SU23Cat3] ^= {SU23Cat3Piv1, SU23Cat3Piv2}
 
SU23Cat3 /: pivotalCategory[SU23Cat3, 1] = SU23Cat3Piv1
 
SU23Cat3 /: pivotalCategory[SU23Cat3, 2] = SU23Cat3Piv2
 
SU23Cat3 /: pivotalCategory[SU23Cat3, {1, -1, 1, -1}] = SU23Cat3Piv2
 
SU23Cat3 /: pivotalCategory[SU23Cat3, {1, 1, 1, 1}] = SU23Cat3Piv1
 
SU23Cat3 /: ribbonCategory[SU23Cat3, 1] = SU23Cat3Bal1
 
SU23Cat3 /: ribbonCategory[SU23Cat3, 2] = SU23Cat3Bal2
 
SU23Cat3 /: ribbonCategory[SU23Cat3, 3] = SU23Cat3Bal3
 
SU23Cat3 /: ribbonCategory[SU23Cat3, 4] = SU23Cat3Bal4
 
SU23Cat3 /: ribbonCategory[SU23Cat3, 5] = SU23Cat3Bal5
 
SU23Cat3 /: ribbonCategory[SU23Cat3, 6] = SU23Cat3Bal6
 
SU23Cat3 /: ribbonCategory[SU23Cat3, 7] = SU23Cat3Bal7
 
SU23Cat3 /: ribbonCategory[SU23Cat3, 8] = SU23Cat3Bal8
 
ring[SU23Cat3] ^= SU23
 
SU23Cat3 /: sphericalCategory[SU23Cat3, 1] = SU23Cat3Piv1
 
SU23Cat3 /: sphericalCategory[SU23Cat3, 2] = SU23Cat3Piv2
 
fusionCategoryIndex[SU23][SU23Cat3] ^= 3
balancedCategory[SU23Cat3Bal1] ^= SU23Cat3Bal1
 
braidedCategory[SU23Cat3Bal1] ^= SU23Cat3Brd1
 
fusionCategory[SU23Cat3Bal1] ^= SU23Cat3
 
pivotalCategory[SU23Cat3Bal1] ^= SU23Cat3Piv1
 
ribbonCategory[SU23Cat3Bal1] ^= SU23Cat3Bal1
 
ring[SU23Cat3Bal1] ^= SU23
 
sphericalCategory[SU23Cat3Bal1] ^= SU23Cat3Piv1
 
(balancedCategoryIndex[braidedCategory[SU23Cat3Brd1]][
      balancedCategory[#1]] & )[SU23Cat3Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[SU23Cat3]][balancedCategory[#1]] & )[
    SU23Cat3Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[SU23Cat3Piv1]][
      balancedCategory[#1]] & )[SU23Cat3Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SU23Cat3Brd1]][ribbonCategory[#1]] & )[
    SU23Cat3Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SU23Cat3]][ribbonCategory[#1]] & )[
    SU23Cat3Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat3Piv1]][ribbonCategory[#1]] & )[
    SU23Cat3Bal1] ^= 1
balancedCategory[SU23Cat3Bal2] ^= SU23Cat3Bal2
 
braidedCategory[SU23Cat3Bal2] ^= SU23Cat3Brd1
 
fusionCategory[SU23Cat3Bal2] ^= SU23Cat3
 
pivotalCategory[SU23Cat3Bal2] ^= SU23Cat3Piv2
 
ribbonCategory[SU23Cat3Bal2] ^= SU23Cat3Bal2
 
ring[SU23Cat3Bal2] ^= SU23
 
sphericalCategory[SU23Cat3Bal2] ^= SU23Cat3Piv2
 
(balancedCategoryIndex[braidedCategory[SU23Cat3Brd1]][
      balancedCategory[#1]] & )[SU23Cat3Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[SU23Cat3]][balancedCategory[#1]] & )[
    SU23Cat3Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[SU23Cat3Piv2]][
      balancedCategory[#1]] & )[SU23Cat3Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SU23Cat3Brd1]][ribbonCategory[#1]] & )[
    SU23Cat3Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SU23Cat3]][ribbonCategory[#1]] & )[
    SU23Cat3Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat3Piv2]][ribbonCategory[#1]] & )[
    SU23Cat3Bal2] ^= 1
balancedCategory[SU23Cat3Bal3] ^= SU23Cat3Bal3
 
braidedCategory[SU23Cat3Bal3] ^= SU23Cat3Brd2
 
fusionCategory[SU23Cat3Bal3] ^= SU23Cat3
 
pivotalCategory[SU23Cat3Bal3] ^= SU23Cat3Piv1
 
ribbonCategory[SU23Cat3Bal3] ^= SU23Cat3Bal3
 
ring[SU23Cat3Bal3] ^= SU23
 
sphericalCategory[SU23Cat3Bal3] ^= SU23Cat3Piv1
 
(balancedCategoryIndex[braidedCategory[SU23Cat3Brd2]][
      balancedCategory[#1]] & )[SU23Cat3Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[SU23Cat3]][balancedCategory[#1]] & )[
    SU23Cat3Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[SU23Cat3Piv1]][
      balancedCategory[#1]] & )[SU23Cat3Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SU23Cat3Brd2]][ribbonCategory[#1]] & )[
    SU23Cat3Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SU23Cat3]][ribbonCategory[#1]] & )[
    SU23Cat3Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat3Piv1]][ribbonCategory[#1]] & )[
    SU23Cat3Bal3] ^= 2
balancedCategory[SU23Cat3Bal4] ^= SU23Cat3Bal4
 
braidedCategory[SU23Cat3Bal4] ^= SU23Cat3Brd2
 
fusionCategory[SU23Cat3Bal4] ^= SU23Cat3
 
pivotalCategory[SU23Cat3Bal4] ^= SU23Cat3Piv2
 
ribbonCategory[SU23Cat3Bal4] ^= SU23Cat3Bal4
 
ring[SU23Cat3Bal4] ^= SU23
 
sphericalCategory[SU23Cat3Bal4] ^= SU23Cat3Piv2
 
(balancedCategoryIndex[braidedCategory[SU23Cat3Brd2]][
      balancedCategory[#1]] & )[SU23Cat3Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[SU23Cat3]][balancedCategory[#1]] & )[
    SU23Cat3Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[SU23Cat3Piv2]][
      balancedCategory[#1]] & )[SU23Cat3Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SU23Cat3Brd2]][ribbonCategory[#1]] & )[
    SU23Cat3Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SU23Cat3]][ribbonCategory[#1]] & )[
    SU23Cat3Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat3Piv2]][ribbonCategory[#1]] & )[
    SU23Cat3Bal4] ^= 2
balancedCategory[SU23Cat3Bal5] ^= SU23Cat3Bal5
 
braidedCategory[SU23Cat3Bal5] ^= SU23Cat3Brd3
 
fusionCategory[SU23Cat3Bal5] ^= SU23Cat3
 
pivotalCategory[SU23Cat3Bal5] ^= SU23Cat3Piv1
 
ribbonCategory[SU23Cat3Bal5] ^= SU23Cat3Bal5
 
ring[SU23Cat3Bal5] ^= SU23
 
sphericalCategory[SU23Cat3Bal5] ^= SU23Cat3Piv1
 
(balancedCategoryIndex[braidedCategory[SU23Cat3Brd3]][
      balancedCategory[#1]] & )[SU23Cat3Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[SU23Cat3]][balancedCategory[#1]] & )[
    SU23Cat3Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[SU23Cat3Piv1]][
      balancedCategory[#1]] & )[SU23Cat3Bal5] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SU23Cat3Brd3]][ribbonCategory[#1]] & )[
    SU23Cat3Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SU23Cat3]][ribbonCategory[#1]] & )[
    SU23Cat3Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat3Piv1]][ribbonCategory[#1]] & )[
    SU23Cat3Bal5] ^= 3
balancedCategory[SU23Cat3Bal6] ^= SU23Cat3Bal6
 
braidedCategory[SU23Cat3Bal6] ^= SU23Cat3Brd3
 
fusionCategory[SU23Cat3Bal6] ^= SU23Cat3
 
pivotalCategory[SU23Cat3Bal6] ^= SU23Cat3Piv2
 
ribbonCategory[SU23Cat3Bal6] ^= SU23Cat3Bal6
 
ring[SU23Cat3Bal6] ^= SU23
 
sphericalCategory[SU23Cat3Bal6] ^= SU23Cat3Piv2
 
(balancedCategoryIndex[braidedCategory[SU23Cat3Brd3]][
      balancedCategory[#1]] & )[SU23Cat3Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[SU23Cat3]][balancedCategory[#1]] & )[
    SU23Cat3Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[SU23Cat3Piv2]][
      balancedCategory[#1]] & )[SU23Cat3Bal6] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SU23Cat3Brd3]][ribbonCategory[#1]] & )[
    SU23Cat3Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SU23Cat3]][ribbonCategory[#1]] & )[
    SU23Cat3Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat3Piv2]][ribbonCategory[#1]] & )[
    SU23Cat3Bal6] ^= 3
balancedCategory[SU23Cat3Bal7] ^= SU23Cat3Bal7
 
braidedCategory[SU23Cat3Bal7] ^= SU23Cat3Brd4
 
fusionCategory[SU23Cat3Bal7] ^= SU23Cat3
 
pivotalCategory[SU23Cat3Bal7] ^= SU23Cat3Piv1
 
ribbonCategory[SU23Cat3Bal7] ^= SU23Cat3Bal7
 
ring[SU23Cat3Bal7] ^= SU23
 
sphericalCategory[SU23Cat3Bal7] ^= SU23Cat3Piv1
 
(balancedCategoryIndex[braidedCategory[SU23Cat3Brd4]][
      balancedCategory[#1]] & )[SU23Cat3Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[SU23Cat3]][balancedCategory[#1]] & )[
    SU23Cat3Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[SU23Cat3Piv1]][
      balancedCategory[#1]] & )[SU23Cat3Bal7] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SU23Cat3Brd4]][ribbonCategory[#1]] & )[
    SU23Cat3Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SU23Cat3]][ribbonCategory[#1]] & )[
    SU23Cat3Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat3Piv1]][ribbonCategory[#1]] & )[
    SU23Cat3Bal7] ^= 4
balancedCategory[SU23Cat3Bal8] ^= SU23Cat3Bal8
 
braidedCategory[SU23Cat3Bal8] ^= SU23Cat3Brd4
 
fusionCategory[SU23Cat3Bal8] ^= SU23Cat3
 
pivotalCategory[SU23Cat3Bal8] ^= SU23Cat3Piv2
 
ribbonCategory[SU23Cat3Bal8] ^= SU23Cat3Bal8
 
ring[SU23Cat3Bal8] ^= SU23
 
sphericalCategory[SU23Cat3Bal8] ^= SU23Cat3Piv2
 
(balancedCategoryIndex[braidedCategory[SU23Cat3Brd4]][
      balancedCategory[#1]] & )[SU23Cat3Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[SU23Cat3]][balancedCategory[#1]] & )[
    SU23Cat3Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[SU23Cat3Piv2]][
      balancedCategory[#1]] & )[SU23Cat3Bal8] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SU23Cat3Brd4]][ribbonCategory[#1]] & )[
    SU23Cat3Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SU23Cat3]][ribbonCategory[#1]] & )[
    SU23Cat3Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat3Piv2]][ribbonCategory[#1]] & )[
    SU23Cat3Bal8] ^= 4
balancedCategories[SU23Cat3Brd1] ^= {SU23Cat3Bal1, SU23Cat3Bal2}
 
SU23Cat3Brd1 /: balancedCategory[SU23Cat3Brd1, 1] = SU23Cat3Bal1
 
SU23Cat3Brd1 /: balancedCategory[SU23Cat3Brd1, 2] = SU23Cat3Bal2
 
braidedCategory[SU23Cat3Brd1] ^= SU23Cat3Brd1
 
fusionCategory[SU23Cat3Brd1] ^= SU23Cat3
 
SU23Cat3Brd1 /: modularCategory[SU23Cat3Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SU23Cat3Brd1 /: ribbonCategory[SU23Cat3Brd1, 1] = SU23Cat3Bal1
 
SU23Cat3Brd1 /: ribbonCategory[SU23Cat3Brd1, 2] = SU23Cat3Bal2
 
ring[SU23Cat3Brd1] ^= SU23
 
rMatrixFunction[SU23Cat3Brd1] ^= SU23Cat3Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SU23Cat3]][braidedCategory[#1]] & )[
    SU23Cat3Brd1] ^= 1
braidedCategory[SU23Cat3Brd1RMatrixFunction] ^= SU23Cat3Brd1
 
fusionCategory[SU23Cat3Brd1RMatrixFunction] ^= SU23Cat3
 
rMatrixFunction[SU23Cat3Brd1RMatrixFunction] ^= SU23Cat3Brd1RMatrixFunction
 
SU23Cat3Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
SU23Cat3Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
SU23Cat3Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
SU23Cat3Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
SU23Cat3Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
SU23Cat3Brd1RMatrixFunction[1, 1, 0] = {{-(-1)^(1/10)}}
 
SU23Cat3Brd1RMatrixFunction[1, 1, 2] = {{-(-1)^(3/10)}}
 
SU23Cat3Brd1RMatrixFunction[1, 2, 1] = {{-(-1)^(4/5)}}
 
SU23Cat3Brd1RMatrixFunction[1, 2, 3] = {{-(-1)^(3/5)}}
 
SU23Cat3Brd1RMatrixFunction[1, 3, 2] = {{I}}
 
SU23Cat3Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
SU23Cat3Brd1RMatrixFunction[2, 1, 1] = {{-(-1)^(4/5)}}
 
SU23Cat3Brd1RMatrixFunction[2, 1, 3] = {{-(-1)^(3/5)}}
 
SU23Cat3Brd1RMatrixFunction[2, 2, 0] = {{-(-1)^(3/5)}}
 
SU23Cat3Brd1RMatrixFunction[2, 2, 2] = {{-(-1)^(4/5)}}
 
SU23Cat3Brd1RMatrixFunction[2, 3, 1] = {{1}}
 
SU23Cat3Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
SU23Cat3Brd1RMatrixFunction[3, 1, 2] = {{I}}
 
SU23Cat3Brd1RMatrixFunction[3, 2, 1] = {{1}}
 
SU23Cat3Brd1RMatrixFunction[3, 3, 0] = {{-I}}
balancedCategories[SU23Cat3Brd2] ^= {SU23Cat3Bal3, SU23Cat3Bal4}
 
SU23Cat3Brd2 /: balancedCategory[SU23Cat3Brd2, 1] = SU23Cat3Bal3
 
SU23Cat3Brd2 /: balancedCategory[SU23Cat3Brd2, 2] = SU23Cat3Bal4
 
braidedCategory[SU23Cat3Brd2] ^= SU23Cat3Brd2
 
fusionCategory[SU23Cat3Brd2] ^= SU23Cat3
 
SU23Cat3Brd2 /: modularCategory[SU23Cat3Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SU23Cat3Brd2 /: ribbonCategory[SU23Cat3Brd2, 1] = SU23Cat3Bal3
 
SU23Cat3Brd2 /: ribbonCategory[SU23Cat3Brd2, 2] = SU23Cat3Bal4
 
ring[SU23Cat3Brd2] ^= SU23
 
rMatrixFunction[SU23Cat3Brd2] ^= SU23Cat3Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SU23Cat3]][braidedCategory[#1]] & )[
    SU23Cat3Brd2] ^= 2
braidedCategory[SU23Cat3Brd2RMatrixFunction] ^= SU23Cat3Brd2
 
fusionCategory[SU23Cat3Brd2RMatrixFunction] ^= SU23Cat3
 
rMatrixFunction[SU23Cat3Brd2RMatrixFunction] ^= SU23Cat3Brd2RMatrixFunction
 
SU23Cat3Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
SU23Cat3Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
SU23Cat3Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
SU23Cat3Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
SU23Cat3Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
SU23Cat3Brd2RMatrixFunction[1, 1, 0] = {{(-1)^(9/10)}}
 
SU23Cat3Brd2RMatrixFunction[1, 1, 2] = {{(-1)^(7/10)}}
 
SU23Cat3Brd2RMatrixFunction[1, 2, 1] = {{(-1)^(1/5)}}
 
SU23Cat3Brd2RMatrixFunction[1, 2, 3] = {{(-1)^(2/5)}}
 
SU23Cat3Brd2RMatrixFunction[1, 3, 2] = {{-I}}
 
SU23Cat3Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
SU23Cat3Brd2RMatrixFunction[2, 1, 1] = {{(-1)^(1/5)}}
 
SU23Cat3Brd2RMatrixFunction[2, 1, 3] = {{(-1)^(2/5)}}
 
SU23Cat3Brd2RMatrixFunction[2, 2, 0] = {{(-1)^(2/5)}}
 
SU23Cat3Brd2RMatrixFunction[2, 2, 2] = {{(-1)^(1/5)}}
 
SU23Cat3Brd2RMatrixFunction[2, 3, 1] = {{1}}
 
SU23Cat3Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
SU23Cat3Brd2RMatrixFunction[3, 1, 2] = {{-I}}
 
SU23Cat3Brd2RMatrixFunction[3, 2, 1] = {{1}}
 
SU23Cat3Brd2RMatrixFunction[3, 3, 0] = {{I}}
balancedCategories[SU23Cat3Brd3] ^= {SU23Cat3Bal5, SU23Cat3Bal6}
 
SU23Cat3Brd3 /: balancedCategory[SU23Cat3Brd3, 1] = SU23Cat3Bal5
 
SU23Cat3Brd3 /: balancedCategory[SU23Cat3Brd3, 2] = SU23Cat3Bal6
 
braidedCategory[SU23Cat3Brd3] ^= SU23Cat3Brd3
 
fusionCategory[SU23Cat3Brd3] ^= SU23Cat3
 
SU23Cat3Brd3 /: modularCategory[SU23Cat3Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SU23Cat3Brd3 /: ribbonCategory[SU23Cat3Brd3, 1] = SU23Cat3Bal5
 
SU23Cat3Brd3 /: ribbonCategory[SU23Cat3Brd3, 2] = SU23Cat3Bal6
 
ring[SU23Cat3Brd3] ^= SU23
 
rMatrixFunction[SU23Cat3Brd3] ^= SU23Cat3Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SU23Cat3]][braidedCategory[#1]] & )[
    SU23Cat3Brd3] ^= 3
braidedCategory[SU23Cat3Brd3RMatrixFunction] ^= SU23Cat3Brd3
 
fusionCategory[SU23Cat3Brd3RMatrixFunction] ^= SU23Cat3
 
rMatrixFunction[SU23Cat3Brd3RMatrixFunction] ^= SU23Cat3Brd3RMatrixFunction
 
SU23Cat3Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
SU23Cat3Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
SU23Cat3Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
SU23Cat3Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
SU23Cat3Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
SU23Cat3Brd3RMatrixFunction[1, 1, 0] = {{-(-1)^(9/10)}}
 
SU23Cat3Brd3RMatrixFunction[1, 1, 2] = {{-(-1)^(7/10)}}
 
SU23Cat3Brd3RMatrixFunction[1, 2, 1] = {{(-1)^(1/5)}}
 
SU23Cat3Brd3RMatrixFunction[1, 2, 3] = {{(-1)^(2/5)}}
 
SU23Cat3Brd3RMatrixFunction[1, 3, 2] = {{I}}
 
SU23Cat3Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
SU23Cat3Brd3RMatrixFunction[2, 1, 1] = {{(-1)^(1/5)}}
 
SU23Cat3Brd3RMatrixFunction[2, 1, 3] = {{(-1)^(2/5)}}
 
SU23Cat3Brd3RMatrixFunction[2, 2, 0] = {{(-1)^(2/5)}}
 
SU23Cat3Brd3RMatrixFunction[2, 2, 2] = {{(-1)^(1/5)}}
 
SU23Cat3Brd3RMatrixFunction[2, 3, 1] = {{1}}
 
SU23Cat3Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
SU23Cat3Brd3RMatrixFunction[3, 1, 2] = {{I}}
 
SU23Cat3Brd3RMatrixFunction[3, 2, 1] = {{1}}
 
SU23Cat3Brd3RMatrixFunction[3, 3, 0] = {{-I}}
balancedCategories[SU23Cat3Brd4] ^= {SU23Cat3Bal7, SU23Cat3Bal8}
 
SU23Cat3Brd4 /: balancedCategory[SU23Cat3Brd4, 1] = SU23Cat3Bal7
 
SU23Cat3Brd4 /: balancedCategory[SU23Cat3Brd4, 2] = SU23Cat3Bal8
 
braidedCategory[SU23Cat3Brd4] ^= SU23Cat3Brd4
 
fusionCategory[SU23Cat3Brd4] ^= SU23Cat3
 
SU23Cat3Brd4 /: modularCategory[SU23Cat3Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SU23Cat3Brd4 /: ribbonCategory[SU23Cat3Brd4, 1] = SU23Cat3Bal7
 
SU23Cat3Brd4 /: ribbonCategory[SU23Cat3Brd4, 2] = SU23Cat3Bal8
 
ring[SU23Cat3Brd4] ^= SU23
 
rMatrixFunction[SU23Cat3Brd4] ^= SU23Cat3Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SU23Cat3]][braidedCategory[#1]] & )[
    SU23Cat3Brd4] ^= 4
braidedCategory[SU23Cat3Brd4RMatrixFunction] ^= SU23Cat3Brd4
 
fusionCategory[SU23Cat3Brd4RMatrixFunction] ^= SU23Cat3
 
rMatrixFunction[SU23Cat3Brd4RMatrixFunction] ^= SU23Cat3Brd4RMatrixFunction
 
SU23Cat3Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
SU23Cat3Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
SU23Cat3Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
SU23Cat3Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
SU23Cat3Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
SU23Cat3Brd4RMatrixFunction[1, 1, 0] = {{(-1)^(1/10)}}
 
SU23Cat3Brd4RMatrixFunction[1, 1, 2] = {{(-1)^(3/10)}}
 
SU23Cat3Brd4RMatrixFunction[1, 2, 1] = {{-(-1)^(4/5)}}
 
SU23Cat3Brd4RMatrixFunction[1, 2, 3] = {{-(-1)^(3/5)}}
 
SU23Cat3Brd4RMatrixFunction[1, 3, 2] = {{-I}}
 
SU23Cat3Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
SU23Cat3Brd4RMatrixFunction[2, 1, 1] = {{-(-1)^(4/5)}}
 
SU23Cat3Brd4RMatrixFunction[2, 1, 3] = {{-(-1)^(3/5)}}
 
SU23Cat3Brd4RMatrixFunction[2, 2, 0] = {{-(-1)^(3/5)}}
 
SU23Cat3Brd4RMatrixFunction[2, 2, 2] = {{-(-1)^(4/5)}}
 
SU23Cat3Brd4RMatrixFunction[2, 3, 1] = {{1}}
 
SU23Cat3Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
SU23Cat3Brd4RMatrixFunction[3, 1, 2] = {{-I}}
 
SU23Cat3Brd4RMatrixFunction[3, 2, 1] = {{1}}
 
SU23Cat3Brd4RMatrixFunction[3, 3, 0] = {{I}}
fMatrixFunction[SU23Cat3FMatrixFunction] ^= SU23Cat3FMatrixFunction
 
fusionCategory[SU23Cat3FMatrixFunction] ^= SU23Cat3
 
ring[SU23Cat3FMatrixFunction] ^= SU23
 
SU23Cat3FMatrixFunction[1, 1, 1, 1] = {{(1 + Sqrt[5])/2, (1 + Sqrt[5])/2}, 
    {-1, (-1 - Sqrt[5])/2}}
 
SU23Cat3FMatrixFunction[1, 1, 1, 3] = {{-1}}
 
SU23Cat3FMatrixFunction[1, 1, 2, 2] = {{1, (1 + Sqrt[5])/2}, 
    {(1 + Sqrt[5])/2, (1 + Sqrt[5])/2}}
 
SU23Cat3FMatrixFunction[1, 1, 3, 1] = {{-1}}
 
SU23Cat3FMatrixFunction[1, 2, 1, 2] = {{(1 + Sqrt[5])/2, 1}, 
    {(1 + Sqrt[5])/2, (1 + Sqrt[5])/2}}
 
SU23Cat3FMatrixFunction[1, 2, 2, 1] = {{(-1 - Sqrt[5])/2, (1 + Sqrt[5])/2}, 
    {(1 + Sqrt[5])/2, -1}}
 
SU23Cat3FMatrixFunction[2, 1, 1, 2] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {(1 + Sqrt[5])/2, 1}}
 
SU23Cat3FMatrixFunction[2, 1, 2, 1] = {{(1 + Sqrt[5])/2, -1}, 
    {(1 + Sqrt[5])/2, (-1 - Sqrt[5])/2}}
 
SU23Cat3FMatrixFunction[2, 2, 1, 1] = {{1, (1 + Sqrt[5])/2}, 
    {(1 + Sqrt[5])/2, (1 + Sqrt[5])/2}}
 
SU23Cat3FMatrixFunction[2, 2, 2, 2] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
SU23Cat3FMatrixFunction[2, 2, 3, 3] = {{-1}}
 
SU23Cat3FMatrixFunction[2, 3, 1, 0] = {{-1}}
 
SU23Cat3FMatrixFunction[2, 3, 1, 2] = {{-1}}
 
SU23Cat3FMatrixFunction[2, 3, 3, 2] = {{-1}}
 
SU23Cat3FMatrixFunction[3, 1, 1, 3] = {{-1}}
 
SU23Cat3FMatrixFunction[3, 1, 2, 0] = {{-1}}
 
SU23Cat3FMatrixFunction[3, 2, 1, 2] = {{-1}}
 
SU23Cat3FMatrixFunction[3, 2, 2, 3] = {{-1}}
 
SU23Cat3FMatrixFunction[3, 2, 3, 2] = {{-1}}
 
SU23Cat3FMatrixFunction[3, 3, 1, 1] = {{-1}}
 
SU23Cat3FMatrixFunction[3, 3, 3, 3] = {{-1}}
 
SU23Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SU23Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
SU23Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SU23Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[SU23Cat3Piv1] ^= {SU23Cat3Bal1, SU23Cat3Bal3, 
    SU23Cat3Bal5, SU23Cat3Bal7}
 
SU23Cat3Piv1 /: balancedCategory[SU23Cat3Piv1, 1] = SU23Cat3Bal1
 
SU23Cat3Piv1 /: balancedCategory[SU23Cat3Piv1, 2] = SU23Cat3Bal3
 
SU23Cat3Piv1 /: balancedCategory[SU23Cat3Piv1, 3] = SU23Cat3Bal5
 
SU23Cat3Piv1 /: balancedCategory[SU23Cat3Piv1, 4] = SU23Cat3Bal7
 
fusionCategory[SU23Cat3Piv1] ^= SU23Cat3
 
SU23Cat3Piv1 /: modularCategory[SU23Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SU23Cat3Piv1] ^= SU23Cat3Piv1
 
pivotalIsomorphism[SU23Cat3Piv1] ^= SU23Cat3Piv1PivotalIsomorphism
 
SU23Cat3Piv1 /: ribbonCategory[SU23Cat3Piv1, 1] = SU23Cat3Bal1
 
SU23Cat3Piv1 /: ribbonCategory[SU23Cat3Piv1, 2] = SU23Cat3Bal3
 
SU23Cat3Piv1 /: ribbonCategory[SU23Cat3Piv1, 3] = SU23Cat3Bal5
 
SU23Cat3Piv1 /: ribbonCategory[SU23Cat3Piv1, 4] = SU23Cat3Bal7
 
ring[SU23Cat3Piv1] ^= SU23
 
sphericalCategory[SU23Cat3Piv1] ^= SU23Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[SU23Cat3]][pivotalCategory[#1]] & )[
    SU23Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[SU23Cat3]][sphericalCategory[#1]] & )[
    SU23Cat3Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[SU23Cat3Piv1PivotalIsomorphism] ^= SU23Cat3
 
pivotalCategory[SU23Cat3Piv1PivotalIsomorphism] ^= SU23Cat3Piv1
 
pivotalIsomorphism[SU23Cat3Piv1PivotalIsomorphism] ^= 
   SU23Cat3Piv1PivotalIsomorphism
 
SU23Cat3Piv1PivotalIsomorphism[0] = 1
 
SU23Cat3Piv1PivotalIsomorphism[1] = 1
 
SU23Cat3Piv1PivotalIsomorphism[2] = 1
 
SU23Cat3Piv1PivotalIsomorphism[3] = 1
balancedCategories[SU23Cat3Piv2] ^= {SU23Cat3Bal2, SU23Cat3Bal4, 
    SU23Cat3Bal6, SU23Cat3Bal8}
 
SU23Cat3Piv2 /: balancedCategory[SU23Cat3Piv2, 1] = SU23Cat3Bal2
 
SU23Cat3Piv2 /: balancedCategory[SU23Cat3Piv2, 2] = SU23Cat3Bal4
 
SU23Cat3Piv2 /: balancedCategory[SU23Cat3Piv2, 3] = SU23Cat3Bal6
 
SU23Cat3Piv2 /: balancedCategory[SU23Cat3Piv2, 4] = SU23Cat3Bal8
 
fusionCategory[SU23Cat3Piv2] ^= SU23Cat3
 
SU23Cat3Piv2 /: modularCategory[SU23Cat3Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SU23Cat3Piv2] ^= SU23Cat3Piv2
 
pivotalIsomorphism[SU23Cat3Piv2] ^= SU23Cat3Piv2PivotalIsomorphism
 
SU23Cat3Piv2 /: ribbonCategory[SU23Cat3Piv2, 1] = SU23Cat3Bal2
 
SU23Cat3Piv2 /: ribbonCategory[SU23Cat3Piv2, 2] = SU23Cat3Bal4
 
SU23Cat3Piv2 /: ribbonCategory[SU23Cat3Piv2, 3] = SU23Cat3Bal6
 
SU23Cat3Piv2 /: ribbonCategory[SU23Cat3Piv2, 4] = SU23Cat3Bal8
 
ring[SU23Cat3Piv2] ^= SU23
 
sphericalCategory[SU23Cat3Piv2] ^= SU23Cat3Piv2
 
(pivotalCategoryIndex[fusionCategory[SU23Cat3]][pivotalCategory[#1]] & )[
    SU23Cat3Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[SU23Cat3]][sphericalCategory[#1]] & )[
    SU23Cat3Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[SU23Cat3Piv2PivotalIsomorphism] ^= SU23Cat3
 
pivotalCategory[SU23Cat3Piv2PivotalIsomorphism] ^= SU23Cat3Piv2
 
pivotalIsomorphism[SU23Cat3Piv2PivotalIsomorphism] ^= 
   SU23Cat3Piv2PivotalIsomorphism
 
SU23Cat3Piv2PivotalIsomorphism[0] = 1
 
SU23Cat3Piv2PivotalIsomorphism[1] = -1
 
SU23Cat3Piv2PivotalIsomorphism[2] = 1
 
SU23Cat3Piv2PivotalIsomorphism[3] = -1
balancedCategories[SU23Cat4] ^= {SU23Cat4Bal1, SU23Cat4Bal2, SU23Cat4Bal3, 
    SU23Cat4Bal4, SU23Cat4Bal5, SU23Cat4Bal6, SU23Cat4Bal7, SU23Cat4Bal8}
 
SU23Cat4 /: balancedCategory[SU23Cat4, 1] = SU23Cat4Bal1
 
SU23Cat4 /: balancedCategory[SU23Cat4, 2] = SU23Cat4Bal2
 
SU23Cat4 /: balancedCategory[SU23Cat4, 3] = SU23Cat4Bal3
 
SU23Cat4 /: balancedCategory[SU23Cat4, 4] = SU23Cat4Bal4
 
SU23Cat4 /: balancedCategory[SU23Cat4, 5] = SU23Cat4Bal5
 
SU23Cat4 /: balancedCategory[SU23Cat4, 6] = SU23Cat4Bal6
 
SU23Cat4 /: balancedCategory[SU23Cat4, 7] = SU23Cat4Bal7
 
SU23Cat4 /: balancedCategory[SU23Cat4, 8] = SU23Cat4Bal8
 
braidedCategories[SU23Cat4] ^= {SU23Cat4Brd1, SU23Cat4Brd2, SU23Cat4Brd3, 
    SU23Cat4Brd4}
 
SU23Cat4 /: braidedCategory[SU23Cat4, 1] = SU23Cat4Brd1
 
SU23Cat4 /: braidedCategory[SU23Cat4, 2] = SU23Cat4Brd2
 
SU23Cat4 /: braidedCategory[SU23Cat4, 3] = SU23Cat4Brd3
 
SU23Cat4 /: braidedCategory[SU23Cat4, 4] = SU23Cat4Brd4
 
coeval[SU23Cat4] ^= 1/sixJFunction[SU23Cat4][#1, dual[ring[SU23Cat4]][#1], 
      #1, #1, 0, 0] & 
 
eval[SU23Cat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[SU23Cat4] ^= SU23Cat4FMatrixFunction
 
fusionCategory[SU23Cat4] ^= SU23Cat4
 
SU23Cat4 /: modularCategory[SU23Cat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[SU23Cat4] ^= {SU23Cat4Piv1, SU23Cat4Piv2}
 
SU23Cat4 /: pivotalCategory[SU23Cat4, 1] = SU23Cat4Piv1
 
SU23Cat4 /: pivotalCategory[SU23Cat4, 2] = SU23Cat4Piv2
 
SU23Cat4 /: pivotalCategory[SU23Cat4, {1, -1, 1, -1}] = SU23Cat4Piv2
 
SU23Cat4 /: pivotalCategory[SU23Cat4, {1, 1, 1, 1}] = SU23Cat4Piv1
 
SU23Cat4 /: ribbonCategory[SU23Cat4, 1] = SU23Cat4Bal1
 
SU23Cat4 /: ribbonCategory[SU23Cat4, 2] = SU23Cat4Bal2
 
SU23Cat4 /: ribbonCategory[SU23Cat4, 3] = SU23Cat4Bal3
 
SU23Cat4 /: ribbonCategory[SU23Cat4, 4] = SU23Cat4Bal4
 
SU23Cat4 /: ribbonCategory[SU23Cat4, 5] = SU23Cat4Bal5
 
SU23Cat4 /: ribbonCategory[SU23Cat4, 6] = SU23Cat4Bal6
 
SU23Cat4 /: ribbonCategory[SU23Cat4, 7] = SU23Cat4Bal7
 
SU23Cat4 /: ribbonCategory[SU23Cat4, 8] = SU23Cat4Bal8
 
ring[SU23Cat4] ^= SU23
 
SU23Cat4 /: sphericalCategory[SU23Cat4, 1] = SU23Cat4Piv1
 
SU23Cat4 /: sphericalCategory[SU23Cat4, 2] = SU23Cat4Piv2
 
fusionCategoryIndex[SU23][SU23Cat4] ^= 4
balancedCategory[SU23Cat4Bal1] ^= SU23Cat4Bal1
 
braidedCategory[SU23Cat4Bal1] ^= SU23Cat4Brd1
 
fusionCategory[SU23Cat4Bal1] ^= SU23Cat4
 
pivotalCategory[SU23Cat4Bal1] ^= SU23Cat4Piv1
 
ribbonCategory[SU23Cat4Bal1] ^= SU23Cat4Bal1
 
ring[SU23Cat4Bal1] ^= SU23
 
sphericalCategory[SU23Cat4Bal1] ^= SU23Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[SU23Cat4Brd1]][
      balancedCategory[#1]] & )[SU23Cat4Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[SU23Cat4]][balancedCategory[#1]] & )[
    SU23Cat4Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[SU23Cat4Piv1]][
      balancedCategory[#1]] & )[SU23Cat4Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SU23Cat4Brd1]][ribbonCategory[#1]] & )[
    SU23Cat4Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SU23Cat4]][ribbonCategory[#1]] & )[
    SU23Cat4Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat4Piv1]][ribbonCategory[#1]] & )[
    SU23Cat4Bal1] ^= 1
balancedCategory[SU23Cat4Bal2] ^= SU23Cat4Bal2
 
braidedCategory[SU23Cat4Bal2] ^= SU23Cat4Brd1
 
fusionCategory[SU23Cat4Bal2] ^= SU23Cat4
 
pivotalCategory[SU23Cat4Bal2] ^= SU23Cat4Piv2
 
ribbonCategory[SU23Cat4Bal2] ^= SU23Cat4Bal2
 
ring[SU23Cat4Bal2] ^= SU23
 
sphericalCategory[SU23Cat4Bal2] ^= SU23Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[SU23Cat4Brd1]][
      balancedCategory[#1]] & )[SU23Cat4Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[SU23Cat4]][balancedCategory[#1]] & )[
    SU23Cat4Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[SU23Cat4Piv2]][
      balancedCategory[#1]] & )[SU23Cat4Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SU23Cat4Brd1]][ribbonCategory[#1]] & )[
    SU23Cat4Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SU23Cat4]][ribbonCategory[#1]] & )[
    SU23Cat4Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat4Piv2]][ribbonCategory[#1]] & )[
    SU23Cat4Bal2] ^= 1
balancedCategory[SU23Cat4Bal3] ^= SU23Cat4Bal3
 
braidedCategory[SU23Cat4Bal3] ^= SU23Cat4Brd2
 
fusionCategory[SU23Cat4Bal3] ^= SU23Cat4
 
pivotalCategory[SU23Cat4Bal3] ^= SU23Cat4Piv1
 
ribbonCategory[SU23Cat4Bal3] ^= SU23Cat4Bal3
 
ring[SU23Cat4Bal3] ^= SU23
 
sphericalCategory[SU23Cat4Bal3] ^= SU23Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[SU23Cat4Brd2]][
      balancedCategory[#1]] & )[SU23Cat4Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[SU23Cat4]][balancedCategory[#1]] & )[
    SU23Cat4Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[SU23Cat4Piv1]][
      balancedCategory[#1]] & )[SU23Cat4Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SU23Cat4Brd2]][ribbonCategory[#1]] & )[
    SU23Cat4Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SU23Cat4]][ribbonCategory[#1]] & )[
    SU23Cat4Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat4Piv1]][ribbonCategory[#1]] & )[
    SU23Cat4Bal3] ^= 2
balancedCategory[SU23Cat4Bal4] ^= SU23Cat4Bal4
 
braidedCategory[SU23Cat4Bal4] ^= SU23Cat4Brd2
 
fusionCategory[SU23Cat4Bal4] ^= SU23Cat4
 
pivotalCategory[SU23Cat4Bal4] ^= SU23Cat4Piv2
 
ribbonCategory[SU23Cat4Bal4] ^= SU23Cat4Bal4
 
ring[SU23Cat4Bal4] ^= SU23
 
sphericalCategory[SU23Cat4Bal4] ^= SU23Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[SU23Cat4Brd2]][
      balancedCategory[#1]] & )[SU23Cat4Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[SU23Cat4]][balancedCategory[#1]] & )[
    SU23Cat4Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[SU23Cat4Piv2]][
      balancedCategory[#1]] & )[SU23Cat4Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SU23Cat4Brd2]][ribbonCategory[#1]] & )[
    SU23Cat4Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SU23Cat4]][ribbonCategory[#1]] & )[
    SU23Cat4Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat4Piv2]][ribbonCategory[#1]] & )[
    SU23Cat4Bal4] ^= 2
balancedCategory[SU23Cat4Bal5] ^= SU23Cat4Bal5
 
braidedCategory[SU23Cat4Bal5] ^= SU23Cat4Brd3
 
fusionCategory[SU23Cat4Bal5] ^= SU23Cat4
 
pivotalCategory[SU23Cat4Bal5] ^= SU23Cat4Piv1
 
ribbonCategory[SU23Cat4Bal5] ^= SU23Cat4Bal5
 
ring[SU23Cat4Bal5] ^= SU23
 
sphericalCategory[SU23Cat4Bal5] ^= SU23Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[SU23Cat4Brd3]][
      balancedCategory[#1]] & )[SU23Cat4Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[SU23Cat4]][balancedCategory[#1]] & )[
    SU23Cat4Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[SU23Cat4Piv1]][
      balancedCategory[#1]] & )[SU23Cat4Bal5] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SU23Cat4Brd3]][ribbonCategory[#1]] & )[
    SU23Cat4Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SU23Cat4]][ribbonCategory[#1]] & )[
    SU23Cat4Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat4Piv1]][ribbonCategory[#1]] & )[
    SU23Cat4Bal5] ^= 3
balancedCategory[SU23Cat4Bal6] ^= SU23Cat4Bal6
 
braidedCategory[SU23Cat4Bal6] ^= SU23Cat4Brd3
 
fusionCategory[SU23Cat4Bal6] ^= SU23Cat4
 
pivotalCategory[SU23Cat4Bal6] ^= SU23Cat4Piv2
 
ribbonCategory[SU23Cat4Bal6] ^= SU23Cat4Bal6
 
ring[SU23Cat4Bal6] ^= SU23
 
sphericalCategory[SU23Cat4Bal6] ^= SU23Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[SU23Cat4Brd3]][
      balancedCategory[#1]] & )[SU23Cat4Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[SU23Cat4]][balancedCategory[#1]] & )[
    SU23Cat4Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[SU23Cat4Piv2]][
      balancedCategory[#1]] & )[SU23Cat4Bal6] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SU23Cat4Brd3]][ribbonCategory[#1]] & )[
    SU23Cat4Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SU23Cat4]][ribbonCategory[#1]] & )[
    SU23Cat4Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat4Piv2]][ribbonCategory[#1]] & )[
    SU23Cat4Bal6] ^= 3
balancedCategory[SU23Cat4Bal7] ^= SU23Cat4Bal7
 
braidedCategory[SU23Cat4Bal7] ^= SU23Cat4Brd4
 
fusionCategory[SU23Cat4Bal7] ^= SU23Cat4
 
pivotalCategory[SU23Cat4Bal7] ^= SU23Cat4Piv1
 
ribbonCategory[SU23Cat4Bal7] ^= SU23Cat4Bal7
 
ring[SU23Cat4Bal7] ^= SU23
 
sphericalCategory[SU23Cat4Bal7] ^= SU23Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[SU23Cat4Brd4]][
      balancedCategory[#1]] & )[SU23Cat4Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[SU23Cat4]][balancedCategory[#1]] & )[
    SU23Cat4Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[SU23Cat4Piv1]][
      balancedCategory[#1]] & )[SU23Cat4Bal7] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SU23Cat4Brd4]][ribbonCategory[#1]] & )[
    SU23Cat4Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SU23Cat4]][ribbonCategory[#1]] & )[
    SU23Cat4Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat4Piv1]][ribbonCategory[#1]] & )[
    SU23Cat4Bal7] ^= 4
balancedCategory[SU23Cat4Bal8] ^= SU23Cat4Bal8
 
braidedCategory[SU23Cat4Bal8] ^= SU23Cat4Brd4
 
fusionCategory[SU23Cat4Bal8] ^= SU23Cat4
 
pivotalCategory[SU23Cat4Bal8] ^= SU23Cat4Piv2
 
ribbonCategory[SU23Cat4Bal8] ^= SU23Cat4Bal8
 
ring[SU23Cat4Bal8] ^= SU23
 
sphericalCategory[SU23Cat4Bal8] ^= SU23Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[SU23Cat4Brd4]][
      balancedCategory[#1]] & )[SU23Cat4Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[SU23Cat4]][balancedCategory[#1]] & )[
    SU23Cat4Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[SU23Cat4Piv2]][
      balancedCategory[#1]] & )[SU23Cat4Bal8] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SU23Cat4Brd4]][ribbonCategory[#1]] & )[
    SU23Cat4Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SU23Cat4]][ribbonCategory[#1]] & )[
    SU23Cat4Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[SU23Cat4Piv2]][ribbonCategory[#1]] & )[
    SU23Cat4Bal8] ^= 4
balancedCategories[SU23Cat4Brd1] ^= {SU23Cat4Bal1, SU23Cat4Bal2}
 
SU23Cat4Brd1 /: balancedCategory[SU23Cat4Brd1, 1] = SU23Cat4Bal1
 
SU23Cat4Brd1 /: balancedCategory[SU23Cat4Brd1, 2] = SU23Cat4Bal2
 
braidedCategory[SU23Cat4Brd1] ^= SU23Cat4Brd1
 
fusionCategory[SU23Cat4Brd1] ^= SU23Cat4
 
SU23Cat4Brd1 /: modularCategory[SU23Cat4Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SU23Cat4Brd1 /: ribbonCategory[SU23Cat4Brd1, 1] = SU23Cat4Bal1
 
SU23Cat4Brd1 /: ribbonCategory[SU23Cat4Brd1, 2] = SU23Cat4Bal2
 
ring[SU23Cat4Brd1] ^= SU23
 
rMatrixFunction[SU23Cat4Brd1] ^= SU23Cat4Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SU23Cat4]][braidedCategory[#1]] & )[
    SU23Cat4Brd1] ^= 1
braidedCategory[SU23Cat4Brd1RMatrixFunction] ^= SU23Cat4Brd1
 
fusionCategory[SU23Cat4Brd1RMatrixFunction] ^= SU23Cat4
 
rMatrixFunction[SU23Cat4Brd1RMatrixFunction] ^= SU23Cat4Brd1RMatrixFunction
 
SU23Cat4Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
SU23Cat4Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
SU23Cat4Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
SU23Cat4Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
SU23Cat4Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
SU23Cat4Brd1RMatrixFunction[1, 1, 0] = {{-(-1)^(2/5)}}
 
SU23Cat4Brd1RMatrixFunction[1, 1, 2] = {{-(-1)^(1/5)}}
 
SU23Cat4Brd1RMatrixFunction[1, 2, 1] = {{(-1)^(1/5)}}
 
SU23Cat4Brd1RMatrixFunction[1, 2, 3] = {{(-1)^(2/5)}}
 
SU23Cat4Brd1RMatrixFunction[1, 3, 2] = {{-1}}
 
SU23Cat4Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
SU23Cat4Brd1RMatrixFunction[2, 1, 1] = {{(-1)^(1/5)}}
 
SU23Cat4Brd1RMatrixFunction[2, 1, 3] = {{(-1)^(2/5)}}
 
SU23Cat4Brd1RMatrixFunction[2, 2, 0] = {{(-1)^(2/5)}}
 
SU23Cat4Brd1RMatrixFunction[2, 2, 2] = {{(-1)^(1/5)}}
 
SU23Cat4Brd1RMatrixFunction[2, 3, 1] = {{1}}
 
SU23Cat4Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
SU23Cat4Brd1RMatrixFunction[3, 1, 2] = {{-1}}
 
SU23Cat4Brd1RMatrixFunction[3, 2, 1] = {{1}}
 
SU23Cat4Brd1RMatrixFunction[3, 3, 0] = {{-1}}
balancedCategories[SU23Cat4Brd2] ^= {SU23Cat4Bal3, SU23Cat4Bal4}
 
SU23Cat4Brd2 /: balancedCategory[SU23Cat4Brd2, 1] = SU23Cat4Bal3
 
SU23Cat4Brd2 /: balancedCategory[SU23Cat4Brd2, 2] = SU23Cat4Bal4
 
braidedCategory[SU23Cat4Brd2] ^= SU23Cat4Brd2
 
fusionCategory[SU23Cat4Brd2] ^= SU23Cat4
 
SU23Cat4Brd2 /: modularCategory[SU23Cat4Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SU23Cat4Brd2 /: ribbonCategory[SU23Cat4Brd2, 1] = SU23Cat4Bal3
 
SU23Cat4Brd2 /: ribbonCategory[SU23Cat4Brd2, 2] = SU23Cat4Bal4
 
ring[SU23Cat4Brd2] ^= SU23
 
rMatrixFunction[SU23Cat4Brd2] ^= SU23Cat4Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SU23Cat4]][braidedCategory[#1]] & )[
    SU23Cat4Brd2] ^= 2
braidedCategory[SU23Cat4Brd2RMatrixFunction] ^= SU23Cat4Brd2
 
fusionCategory[SU23Cat4Brd2RMatrixFunction] ^= SU23Cat4
 
rMatrixFunction[SU23Cat4Brd2RMatrixFunction] ^= SU23Cat4Brd2RMatrixFunction
 
SU23Cat4Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
SU23Cat4Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
SU23Cat4Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
SU23Cat4Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
SU23Cat4Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
SU23Cat4Brd2RMatrixFunction[1, 1, 0] = {{-(-1)^(3/5)}}
 
SU23Cat4Brd2RMatrixFunction[1, 1, 2] = {{-(-1)^(4/5)}}
 
SU23Cat4Brd2RMatrixFunction[1, 2, 1] = {{-(-1)^(4/5)}}
 
SU23Cat4Brd2RMatrixFunction[1, 2, 3] = {{-(-1)^(3/5)}}
 
SU23Cat4Brd2RMatrixFunction[1, 3, 2] = {{1}}
 
SU23Cat4Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
SU23Cat4Brd2RMatrixFunction[2, 1, 1] = {{-(-1)^(4/5)}}
 
SU23Cat4Brd2RMatrixFunction[2, 1, 3] = {{-(-1)^(3/5)}}
 
SU23Cat4Brd2RMatrixFunction[2, 2, 0] = {{-(-1)^(3/5)}}
 
SU23Cat4Brd2RMatrixFunction[2, 2, 2] = {{-(-1)^(4/5)}}
 
SU23Cat4Brd2RMatrixFunction[2, 3, 1] = {{1}}
 
SU23Cat4Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
SU23Cat4Brd2RMatrixFunction[3, 1, 2] = {{1}}
 
SU23Cat4Brd2RMatrixFunction[3, 2, 1] = {{1}}
 
SU23Cat4Brd2RMatrixFunction[3, 3, 0] = {{1}}
balancedCategories[SU23Cat4Brd3] ^= {SU23Cat4Bal5, SU23Cat4Bal6}
 
SU23Cat4Brd3 /: balancedCategory[SU23Cat4Brd3, 1] = SU23Cat4Bal5
 
SU23Cat4Brd3 /: balancedCategory[SU23Cat4Brd3, 2] = SU23Cat4Bal6
 
braidedCategory[SU23Cat4Brd3] ^= SU23Cat4Brd3
 
fusionCategory[SU23Cat4Brd3] ^= SU23Cat4
 
SU23Cat4Brd3 /: modularCategory[SU23Cat4Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SU23Cat4Brd3 /: ribbonCategory[SU23Cat4Brd3, 1] = SU23Cat4Bal5
 
SU23Cat4Brd3 /: ribbonCategory[SU23Cat4Brd3, 2] = SU23Cat4Bal6
 
ring[SU23Cat4Brd3] ^= SU23
 
rMatrixFunction[SU23Cat4Brd3] ^= SU23Cat4Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SU23Cat4]][braidedCategory[#1]] & )[
    SU23Cat4Brd3] ^= 3
braidedCategory[SU23Cat4Brd3RMatrixFunction] ^= SU23Cat4Brd3
 
fusionCategory[SU23Cat4Brd3RMatrixFunction] ^= SU23Cat4
 
rMatrixFunction[SU23Cat4Brd3RMatrixFunction] ^= SU23Cat4Brd3RMatrixFunction
 
SU23Cat4Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
SU23Cat4Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
SU23Cat4Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
SU23Cat4Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
SU23Cat4Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
SU23Cat4Brd3RMatrixFunction[1, 1, 0] = {{(-1)^(3/5)}}
 
SU23Cat4Brd3RMatrixFunction[1, 1, 2] = {{(-1)^(4/5)}}
 
SU23Cat4Brd3RMatrixFunction[1, 2, 1] = {{-(-1)^(4/5)}}
 
SU23Cat4Brd3RMatrixFunction[1, 2, 3] = {{-(-1)^(3/5)}}
 
SU23Cat4Brd3RMatrixFunction[1, 3, 2] = {{-1}}
 
SU23Cat4Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
SU23Cat4Brd3RMatrixFunction[2, 1, 1] = {{-(-1)^(4/5)}}
 
SU23Cat4Brd3RMatrixFunction[2, 1, 3] = {{-(-1)^(3/5)}}
 
SU23Cat4Brd3RMatrixFunction[2, 2, 0] = {{-(-1)^(3/5)}}
 
SU23Cat4Brd3RMatrixFunction[2, 2, 2] = {{-(-1)^(4/5)}}
 
SU23Cat4Brd3RMatrixFunction[2, 3, 1] = {{1}}
 
SU23Cat4Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
SU23Cat4Brd3RMatrixFunction[3, 1, 2] = {{-1}}
 
SU23Cat4Brd3RMatrixFunction[3, 2, 1] = {{1}}
 
SU23Cat4Brd3RMatrixFunction[3, 3, 0] = {{-1}}
balancedCategories[SU23Cat4Brd4] ^= {SU23Cat4Bal7, SU23Cat4Bal8}
 
SU23Cat4Brd4 /: balancedCategory[SU23Cat4Brd4, 1] = SU23Cat4Bal7
 
SU23Cat4Brd4 /: balancedCategory[SU23Cat4Brd4, 2] = SU23Cat4Bal8
 
braidedCategory[SU23Cat4Brd4] ^= SU23Cat4Brd4
 
fusionCategory[SU23Cat4Brd4] ^= SU23Cat4
 
SU23Cat4Brd4 /: modularCategory[SU23Cat4Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SU23Cat4Brd4 /: ribbonCategory[SU23Cat4Brd4, 1] = SU23Cat4Bal7
 
SU23Cat4Brd4 /: ribbonCategory[SU23Cat4Brd4, 2] = SU23Cat4Bal8
 
ring[SU23Cat4Brd4] ^= SU23
 
rMatrixFunction[SU23Cat4Brd4] ^= SU23Cat4Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SU23Cat4]][braidedCategory[#1]] & )[
    SU23Cat4Brd4] ^= 4
braidedCategory[SU23Cat4Brd4RMatrixFunction] ^= SU23Cat4Brd4
 
fusionCategory[SU23Cat4Brd4RMatrixFunction] ^= SU23Cat4
 
rMatrixFunction[SU23Cat4Brd4RMatrixFunction] ^= SU23Cat4Brd4RMatrixFunction
 
SU23Cat4Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
SU23Cat4Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
SU23Cat4Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
SU23Cat4Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
SU23Cat4Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
SU23Cat4Brd4RMatrixFunction[1, 1, 0] = {{(-1)^(2/5)}}
 
SU23Cat4Brd4RMatrixFunction[1, 1, 2] = {{(-1)^(1/5)}}
 
SU23Cat4Brd4RMatrixFunction[1, 2, 1] = {{(-1)^(1/5)}}
 
SU23Cat4Brd4RMatrixFunction[1, 2, 3] = {{(-1)^(2/5)}}
 
SU23Cat4Brd4RMatrixFunction[1, 3, 2] = {{1}}
 
SU23Cat4Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
SU23Cat4Brd4RMatrixFunction[2, 1, 1] = {{(-1)^(1/5)}}
 
SU23Cat4Brd4RMatrixFunction[2, 1, 3] = {{(-1)^(2/5)}}
 
SU23Cat4Brd4RMatrixFunction[2, 2, 0] = {{(-1)^(2/5)}}
 
SU23Cat4Brd4RMatrixFunction[2, 2, 2] = {{(-1)^(1/5)}}
 
SU23Cat4Brd4RMatrixFunction[2, 3, 1] = {{1}}
 
SU23Cat4Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
SU23Cat4Brd4RMatrixFunction[3, 1, 2] = {{1}}
 
SU23Cat4Brd4RMatrixFunction[3, 2, 1] = {{1}}
 
SU23Cat4Brd4RMatrixFunction[3, 3, 0] = {{1}}
fMatrixFunction[SU23Cat4FMatrixFunction] ^= SU23Cat4FMatrixFunction
 
fusionCategory[SU23Cat4FMatrixFunction] ^= SU23Cat4
 
ring[SU23Cat4FMatrixFunction] ^= SU23
 
SU23Cat4FMatrixFunction[1, 1, 1, 1] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
SU23Cat4FMatrixFunction[1, 1, 2, 2] = {{1, (1 + Sqrt[5])/2}, 
    {(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}}
 
SU23Cat4FMatrixFunction[1, 2, 1, 2] = {{(1 + Sqrt[5])/2, 1}, 
    {(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}}
 
SU23Cat4FMatrixFunction[1, 2, 2, 1] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {(1 + Sqrt[5])/2, 1}}
 
SU23Cat4FMatrixFunction[2, 1, 1, 2] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {(1 + Sqrt[5])/2, 1}}
 
SU23Cat4FMatrixFunction[2, 1, 2, 1] = {{(1 + Sqrt[5])/2, 1}, 
    {(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}}
 
SU23Cat4FMatrixFunction[2, 2, 1, 1] = {{1, (1 + Sqrt[5])/2}, 
    {(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}}
 
SU23Cat4FMatrixFunction[2, 2, 2, 2] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
SU23Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SU23Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
SU23Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SU23Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[SU23Cat4Piv1] ^= {SU23Cat4Bal1, SU23Cat4Bal3, 
    SU23Cat4Bal5, SU23Cat4Bal7}
 
SU23Cat4Piv1 /: balancedCategory[SU23Cat4Piv1, 1] = SU23Cat4Bal1
 
SU23Cat4Piv1 /: balancedCategory[SU23Cat4Piv1, 2] = SU23Cat4Bal3
 
SU23Cat4Piv1 /: balancedCategory[SU23Cat4Piv1, 3] = SU23Cat4Bal5
 
SU23Cat4Piv1 /: balancedCategory[SU23Cat4Piv1, 4] = SU23Cat4Bal7
 
fusionCategory[SU23Cat4Piv1] ^= SU23Cat4
 
SU23Cat4Piv1 /: modularCategory[SU23Cat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SU23Cat4Piv1] ^= SU23Cat4Piv1
 
pivotalIsomorphism[SU23Cat4Piv1] ^= SU23Cat4Piv1PivotalIsomorphism
 
SU23Cat4Piv1 /: ribbonCategory[SU23Cat4Piv1, 1] = SU23Cat4Bal1
 
SU23Cat4Piv1 /: ribbonCategory[SU23Cat4Piv1, 2] = SU23Cat4Bal3
 
SU23Cat4Piv1 /: ribbonCategory[SU23Cat4Piv1, 3] = SU23Cat4Bal5
 
SU23Cat4Piv1 /: ribbonCategory[SU23Cat4Piv1, 4] = SU23Cat4Bal7
 
ring[SU23Cat4Piv1] ^= SU23
 
sphericalCategory[SU23Cat4Piv1] ^= SU23Cat4Piv1
 
(pivotalCategoryIndex[fusionCategory[SU23Cat4]][pivotalCategory[#1]] & )[
    SU23Cat4Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[SU23Cat4]][sphericalCategory[#1]] & )[
    SU23Cat4Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[SU23Cat4Piv1PivotalIsomorphism] ^= SU23Cat4
 
pivotalCategory[SU23Cat4Piv1PivotalIsomorphism] ^= SU23Cat4Piv1
 
pivotalIsomorphism[SU23Cat4Piv1PivotalIsomorphism] ^= 
   SU23Cat4Piv1PivotalIsomorphism
 
SU23Cat4Piv1PivotalIsomorphism[0] = 1
 
SU23Cat4Piv1PivotalIsomorphism[1] = 1
 
SU23Cat4Piv1PivotalIsomorphism[2] = 1
 
SU23Cat4Piv1PivotalIsomorphism[3] = 1
balancedCategories[SU23Cat4Piv2] ^= {SU23Cat4Bal2, SU23Cat4Bal4, 
    SU23Cat4Bal6, SU23Cat4Bal8}
 
SU23Cat4Piv2 /: balancedCategory[SU23Cat4Piv2, 1] = SU23Cat4Bal2
 
SU23Cat4Piv2 /: balancedCategory[SU23Cat4Piv2, 2] = SU23Cat4Bal4
 
SU23Cat4Piv2 /: balancedCategory[SU23Cat4Piv2, 3] = SU23Cat4Bal6
 
SU23Cat4Piv2 /: balancedCategory[SU23Cat4Piv2, 4] = SU23Cat4Bal8
 
fusionCategory[SU23Cat4Piv2] ^= SU23Cat4
 
SU23Cat4Piv2 /: modularCategory[SU23Cat4Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SU23Cat4Piv2] ^= SU23Cat4Piv2
 
pivotalIsomorphism[SU23Cat4Piv2] ^= SU23Cat4Piv2PivotalIsomorphism
 
SU23Cat4Piv2 /: ribbonCategory[SU23Cat4Piv2, 1] = SU23Cat4Bal2
 
SU23Cat4Piv2 /: ribbonCategory[SU23Cat4Piv2, 2] = SU23Cat4Bal4
 
SU23Cat4Piv2 /: ribbonCategory[SU23Cat4Piv2, 3] = SU23Cat4Bal6
 
SU23Cat4Piv2 /: ribbonCategory[SU23Cat4Piv2, 4] = SU23Cat4Bal8
 
ring[SU23Cat4Piv2] ^= SU23
 
sphericalCategory[SU23Cat4Piv2] ^= SU23Cat4Piv2
 
(pivotalCategoryIndex[fusionCategory[SU23Cat4]][pivotalCategory[#1]] & )[
    SU23Cat4Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[SU23Cat4]][sphericalCategory[#1]] & )[
    SU23Cat4Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[SU23Cat4Piv2PivotalIsomorphism] ^= SU23Cat4
 
pivotalCategory[SU23Cat4Piv2PivotalIsomorphism] ^= SU23Cat4Piv2
 
pivotalIsomorphism[SU23Cat4Piv2PivotalIsomorphism] ^= 
   SU23Cat4Piv2PivotalIsomorphism
 
SU23Cat4Piv2PivotalIsomorphism[0] = 1
 
SU23Cat4Piv2PivotalIsomorphism[1] = -1
 
SU23Cat4Piv2PivotalIsomorphism[2] = 1
 
SU23Cat4Piv2PivotalIsomorphism[3] = -1
ring[SU23NFunction] ^= SU23
 
SU23NFunction[0, 0, 0] = 1
 
SU23NFunction[0, 0, 1] = 0
 
SU23NFunction[0, 0, 2] = 0
 
SU23NFunction[0, 0, 3] = 0
 
SU23NFunction[0, 1, 0] = 0
 
SU23NFunction[0, 1, 1] = 1
 
SU23NFunction[0, 1, 2] = 0
 
SU23NFunction[0, 1, 3] = 0
 
SU23NFunction[0, 2, 0] = 0
 
SU23NFunction[0, 2, 1] = 0
 
SU23NFunction[0, 2, 2] = 1
 
SU23NFunction[0, 2, 3] = 0
 
SU23NFunction[0, 3, 0] = 0
 
SU23NFunction[0, 3, 1] = 0
 
SU23NFunction[0, 3, 2] = 0
 
SU23NFunction[0, 3, 3] = 1
 
SU23NFunction[1, 0, 0] = 0
 
SU23NFunction[1, 0, 1] = 1
 
SU23NFunction[1, 0, 2] = 0
 
SU23NFunction[1, 0, 3] = 0
 
SU23NFunction[1, 1, 0] = 1
 
SU23NFunction[1, 1, 1] = 0
 
SU23NFunction[1, 1, 2] = 1
 
SU23NFunction[1, 1, 3] = 0
 
SU23NFunction[1, 2, 0] = 0
 
SU23NFunction[1, 2, 1] = 1
 
SU23NFunction[1, 2, 2] = 0
 
SU23NFunction[1, 2, 3] = 1
 
SU23NFunction[1, 3, 0] = 0
 
SU23NFunction[1, 3, 1] = 0
 
SU23NFunction[1, 3, 2] = 1
 
SU23NFunction[1, 3, 3] = 0
 
SU23NFunction[2, 0, 0] = 0
 
SU23NFunction[2, 0, 1] = 0
 
SU23NFunction[2, 0, 2] = 1
 
SU23NFunction[2, 0, 3] = 0
 
SU23NFunction[2, 1, 0] = 0
 
SU23NFunction[2, 1, 1] = 1
 
SU23NFunction[2, 1, 2] = 0
 
SU23NFunction[2, 1, 3] = 1
 
SU23NFunction[2, 2, 0] = 1
 
SU23NFunction[2, 2, 1] = 0
 
SU23NFunction[2, 2, 2] = 1
 
SU23NFunction[2, 2, 3] = 0
 
SU23NFunction[2, 3, 0] = 0
 
SU23NFunction[2, 3, 1] = 1
 
SU23NFunction[2, 3, 2] = 0
 
SU23NFunction[2, 3, 3] = 0
 
SU23NFunction[3, 0, 0] = 0
 
SU23NFunction[3, 0, 1] = 0
 
SU23NFunction[3, 0, 2] = 0
 
SU23NFunction[3, 0, 3] = 1
 
SU23NFunction[3, 1, 0] = 0
 
SU23NFunction[3, 1, 1] = 0
 
SU23NFunction[3, 1, 2] = 1
 
SU23NFunction[3, 1, 3] = 0
 
SU23NFunction[3, 2, 0] = 0
 
SU23NFunction[3, 2, 1] = 1
 
SU23NFunction[3, 2, 2] = 0
 
SU23NFunction[3, 2, 3] = 0
 
SU23NFunction[3, 3, 0] = 1
 
SU23NFunction[3, 3, 1] = 0
 
SU23NFunction[3, 3, 2] = 0
 
SU23NFunction[3, 3, 3] = 0
 
SU23NFunction[FusionCategories`Data`SU23`Private`a_, 
    FusionCategories`Data`SU23`Private`b_, 
    FusionCategories`Data`SU23`Private`c_] := 0


 EndPackage[]