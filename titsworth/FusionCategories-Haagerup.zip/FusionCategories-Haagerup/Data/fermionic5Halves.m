BeginPackage["FusionCategories`Data`fermionic5Halves`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[fermionic5Halves] ^= {fermionic5HalvesCat1, 
    fermionic5HalvesCat2}
 
fermionic5Halves /: fusionCategory[fermionic5Halves, 1] = fermionic5HalvesCat1
 
fermionic5Halves /: fusionCategory[fermionic5Halves, 2] = fermionic5HalvesCat2
 
nFunction[fermionic5Halves] ^= fermionic5HalvesNFunction
 
noMultiplicities[fermionic5Halves] ^= True
 
rank[fermionic5Halves] ^= 6
 
ring[fermionic5Halves] ^= fermionic5Halves
balancedCategories[fermionic5HalvesCat1] ^= {fermionic5HalvesCat1Bal1, 
    fermionic5HalvesCat1Bal2, fermionic5HalvesCat1Bal3, 
    fermionic5HalvesCat1Bal4, fermionic5HalvesCat1Bal5, 
    fermionic5HalvesCat1Bal6, fermionic5HalvesCat1Bal7, 
    fermionic5HalvesCat1Bal8, fermionic5HalvesCat1Bal9, 
    fermionic5HalvesCat1Bal10, fermionic5HalvesCat1Bal11, 
    fermionic5HalvesCat1Bal12, fermionic5HalvesCat1Bal13, 
    fermionic5HalvesCat1Bal14, fermionic5HalvesCat1Bal15, 
    fermionic5HalvesCat1Bal16, fermionic5HalvesCat1Bal17, 
    fermionic5HalvesCat1Bal18, fermionic5HalvesCat1Bal19, 
    fermionic5HalvesCat1Bal20, fermionic5HalvesCat1Bal21, 
    fermionic5HalvesCat1Bal22, fermionic5HalvesCat1Bal23, 
    fermionic5HalvesCat1Bal24, fermionic5HalvesCat1Bal25, 
    fermionic5HalvesCat1Bal26, fermionic5HalvesCat1Bal27, 
    fermionic5HalvesCat1Bal28, fermionic5HalvesCat1Bal29, 
    fermionic5HalvesCat1Bal30, fermionic5HalvesCat1Bal31, 
    fermionic5HalvesCat1Bal32}
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 1] = 
    fermionic5HalvesCat1Bal1
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 2] = 
    fermionic5HalvesCat1Bal2
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 3] = 
    fermionic5HalvesCat1Bal3
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 4] = 
    fermionic5HalvesCat1Bal4
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 5] = 
    fermionic5HalvesCat1Bal5
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 6] = 
    fermionic5HalvesCat1Bal6
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 7] = 
    fermionic5HalvesCat1Bal7
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 8] = 
    fermionic5HalvesCat1Bal8
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 9] = 
    fermionic5HalvesCat1Bal9
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 10] = 
    fermionic5HalvesCat1Bal10
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 11] = 
    fermionic5HalvesCat1Bal11
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 12] = 
    fermionic5HalvesCat1Bal12
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 13] = 
    fermionic5HalvesCat1Bal13
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 14] = 
    fermionic5HalvesCat1Bal14
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 15] = 
    fermionic5HalvesCat1Bal15
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 16] = 
    fermionic5HalvesCat1Bal16
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 17] = 
    fermionic5HalvesCat1Bal17
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 18] = 
    fermionic5HalvesCat1Bal18
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 19] = 
    fermionic5HalvesCat1Bal19
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 20] = 
    fermionic5HalvesCat1Bal20
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 21] = 
    fermionic5HalvesCat1Bal21
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 22] = 
    fermionic5HalvesCat1Bal22
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 23] = 
    fermionic5HalvesCat1Bal23
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 24] = 
    fermionic5HalvesCat1Bal24
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 25] = 
    fermionic5HalvesCat1Bal25
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 26] = 
    fermionic5HalvesCat1Bal26
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 27] = 
    fermionic5HalvesCat1Bal27
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 28] = 
    fermionic5HalvesCat1Bal28
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 29] = 
    fermionic5HalvesCat1Bal29
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 30] = 
    fermionic5HalvesCat1Bal30
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 31] = 
    fermionic5HalvesCat1Bal31
 
fermionic5HalvesCat1 /: balancedCategory[fermionic5HalvesCat1, 32] = 
    fermionic5HalvesCat1Bal32
 
braidedCategories[fermionic5HalvesCat1] ^= {fermionic5HalvesCat1Brd1, 
    fermionic5HalvesCat1Brd2, fermionic5HalvesCat1Brd3, 
    fermionic5HalvesCat1Brd4, fermionic5HalvesCat1Brd5, 
    fermionic5HalvesCat1Brd6, fermionic5HalvesCat1Brd7, 
    fermionic5HalvesCat1Brd8}
 
fermionic5HalvesCat1 /: braidedCategory[fermionic5HalvesCat1, 1] = 
    fermionic5HalvesCat1Brd1
 
fermionic5HalvesCat1 /: braidedCategory[fermionic5HalvesCat1, 2] = 
    fermionic5HalvesCat1Brd2
 
fermionic5HalvesCat1 /: braidedCategory[fermionic5HalvesCat1, 3] = 
    fermionic5HalvesCat1Brd3
 
fermionic5HalvesCat1 /: braidedCategory[fermionic5HalvesCat1, 4] = 
    fermionic5HalvesCat1Brd4
 
fermionic5HalvesCat1 /: braidedCategory[fermionic5HalvesCat1, 5] = 
    fermionic5HalvesCat1Brd5
 
fermionic5HalvesCat1 /: braidedCategory[fermionic5HalvesCat1, 6] = 
    fermionic5HalvesCat1Brd6
 
fermionic5HalvesCat1 /: braidedCategory[fermionic5HalvesCat1, 7] = 
    fermionic5HalvesCat1Brd7
 
fermionic5HalvesCat1 /: braidedCategory[fermionic5HalvesCat1, 8] = 
    fermionic5HalvesCat1Brd8
 
coeval[fermionic5HalvesCat1] ^= 
   1/sixJFunction[fermionic5HalvesCat1][#1, dual[ring[fermionic5HalvesCat1]][
       #1], #1, #1, 0, 0] & 
 
eval[fermionic5HalvesCat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[fermionic5HalvesCat1] ^= fermionic5HalvesCat1FMatrixFunction
 
fusionCategory[fermionic5HalvesCat1] ^= fermionic5HalvesCat1
 
fermionic5HalvesCat1 /: modularCategory[fermionic5HalvesCat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[fermionic5HalvesCat1] ^= {fermionic5HalvesCat1Piv1, 
    fermionic5HalvesCat1Piv2, fermionic5HalvesCat1Piv3, 
    fermionic5HalvesCat1Piv4}
 
fermionic5HalvesCat1 /: pivotalCategory[fermionic5HalvesCat1, 1] = 
    fermionic5HalvesCat1Piv1
 
fermionic5HalvesCat1 /: pivotalCategory[fermionic5HalvesCat1, 2] = 
    fermionic5HalvesCat1Piv2
 
fermionic5HalvesCat1 /: pivotalCategory[fermionic5HalvesCat1, 3] = 
    fermionic5HalvesCat1Piv3
 
fermionic5HalvesCat1 /: pivotalCategory[fermionic5HalvesCat1, 4] = 
    fermionic5HalvesCat1Piv4
 
fermionic5HalvesCat1 /: pivotalCategory[fermionic5HalvesCat1, 
     {1, -1, 1, -1, -1, -1}] = fermionic5HalvesCat1Piv1
 
fermionic5HalvesCat1 /: pivotalCategory[fermionic5HalvesCat1, 
     {1, -I, 1, 1, I, 1}] = fermionic5HalvesCat1Piv4
 
fermionic5HalvesCat1 /: pivotalCategory[fermionic5HalvesCat1, 
     {1, I, 1, 1, -I, 1}] = fermionic5HalvesCat1Piv3
 
fermionic5HalvesCat1 /: pivotalCategory[fermionic5HalvesCat1, 
     {1, 1, 1, -1, 1, -1}] = fermionic5HalvesCat1Piv2
 
fermionic5HalvesCat1 /: ribbonCategory[fermionic5HalvesCat1, 1] = 
    fermionic5HalvesCat1Bal3
 
fermionic5HalvesCat1 /: ribbonCategory[fermionic5HalvesCat1, 2] = 
    fermionic5HalvesCat1Bal4
 
fermionic5HalvesCat1 /: ribbonCategory[fermionic5HalvesCat1, 3] = 
    fermionic5HalvesCat1Bal7
 
fermionic5HalvesCat1 /: ribbonCategory[fermionic5HalvesCat1, 4] = 
    fermionic5HalvesCat1Bal8
 
fermionic5HalvesCat1 /: ribbonCategory[fermionic5HalvesCat1, 5] = 
    fermionic5HalvesCat1Bal11
 
fermionic5HalvesCat1 /: ribbonCategory[fermionic5HalvesCat1, 6] = 
    fermionic5HalvesCat1Bal12
 
fermionic5HalvesCat1 /: ribbonCategory[fermionic5HalvesCat1, 7] = 
    fermionic5HalvesCat1Bal15
 
fermionic5HalvesCat1 /: ribbonCategory[fermionic5HalvesCat1, 8] = 
    fermionic5HalvesCat1Bal16
 
fermionic5HalvesCat1 /: ribbonCategory[fermionic5HalvesCat1, 9] = 
    fermionic5HalvesCat1Bal19
 
fermionic5HalvesCat1 /: ribbonCategory[fermionic5HalvesCat1, 10] = 
    fermionic5HalvesCat1Bal20
 
fermionic5HalvesCat1 /: ribbonCategory[fermionic5HalvesCat1, 11] = 
    fermionic5HalvesCat1Bal23
 
fermionic5HalvesCat1 /: ribbonCategory[fermionic5HalvesCat1, 12] = 
    fermionic5HalvesCat1Bal24
 
fermionic5HalvesCat1 /: ribbonCategory[fermionic5HalvesCat1, 13] = 
    fermionic5HalvesCat1Bal27
 
fermionic5HalvesCat1 /: ribbonCategory[fermionic5HalvesCat1, 14] = 
    fermionic5HalvesCat1Bal28
 
fermionic5HalvesCat1 /: ribbonCategory[fermionic5HalvesCat1, 15] = 
    fermionic5HalvesCat1Bal31
 
fermionic5HalvesCat1 /: ribbonCategory[fermionic5HalvesCat1, 16] = 
    fermionic5HalvesCat1Bal32
 
ring[fermionic5HalvesCat1] ^= fermionic5Halves
 
fermionic5HalvesCat1 /: sphericalCategory[fermionic5HalvesCat1, 1] = 
    fermionic5HalvesCat1Piv3
 
fermionic5HalvesCat1 /: sphericalCategory[fermionic5HalvesCat1, 2] = 
    fermionic5HalvesCat1Piv4
 
fusionCategoryIndex[fermionic5Halves][fermionic5HalvesCat1] ^= 1
balancedCategory[fermionic5HalvesCat1Bal1] ^= fermionic5HalvesCat1Bal1
 
braidedCategory[fermionic5HalvesCat1Bal1] ^= fermionic5HalvesCat1Brd1
 
coeval[fermionic5HalvesCat1Bal1] ^= 
   Which[fpDimension[fermionic5HalvesCat1Piv1][#1] != Sqrt[2], 
     FusionCategories`Private`defaultGaugeCoeval[fermionic5HalvesCat1Piv1][
      #1], #1 == 1, I*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv1][#1], #1 == 4, 
     (-I)*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv1][#1]] & 
 
fusionCategory[fermionic5HalvesCat1Bal1] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal1] ^= fermionic5HalvesCat1Piv1
 
ribbonCategory[fermionic5HalvesCat1Bal1] ^= fermionic5HalvesCat1Bal1
 
ring[fermionic5HalvesCat1Bal1] ^= fermionic5Halves
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal1] ^= 1
balancedCategory[fermionic5HalvesCat1Bal10] ^= fermionic5HalvesCat1Bal10
 
braidedCategory[fermionic5HalvesCat1Bal10] ^= fermionic5HalvesCat1Brd3
 
coeval[fermionic5HalvesCat1Bal10] ^= 
   Which[fpDimension[fermionic5HalvesCat1Piv2][#1] != Sqrt[2], 
     FusionCategories`Private`defaultGaugeCoeval[fermionic5HalvesCat1Piv2][
      #1], #1 == 1, I*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv2][#1], #1 == 4, 
     (-I)*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv2][#1]] & 
 
fusionCategory[fermionic5HalvesCat1Bal10] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal10] ^= fermionic5HalvesCat1Piv2
 
ribbonCategory[fermionic5HalvesCat1Bal10] ^= fermionic5HalvesCat1Bal10
 
ring[fermionic5HalvesCat1Bal10] ^= fermionic5Halves
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd3]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal10] ^= 2
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal10] ^= 10
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv2]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal10] ^= 3
balancedCategory[fermionic5HalvesCat1Bal11] ^= fermionic5HalvesCat1Bal11
 
braidedCategory[fermionic5HalvesCat1Bal11] ^= fermionic5HalvesCat1Brd3
 
coeval[fermionic5HalvesCat1Bal11] ^= 
   1/sixJFunction[fermionic5HalvesCat1][#1, dual[ring[fermionic5HalvesCat1]][
       #1], #1, #1, 0, 0] & 
 
fusionCategory[fermionic5HalvesCat1Bal11] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal11] ^= fermionic5HalvesCat1Piv3
 
ribbonCategory[fermionic5HalvesCat1Bal11] ^= fermionic5HalvesCat1Bal11
 
ring[fermionic5HalvesCat1Bal11] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat1Bal11] ^= fermionic5HalvesCat1Piv3
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd3]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal11] ^= 3
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal11] ^= 11
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv3]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal11] ^= 3
 
(ribbonCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd3]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal11] ^= 1
 
(ribbonCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal11] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[fermionic5HalvesCat1Piv3]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal11] ^= 3
balancedCategory[fermionic5HalvesCat1Bal12] ^= fermionic5HalvesCat1Bal12
 
braidedCategory[fermionic5HalvesCat1Bal12] ^= fermionic5HalvesCat1Brd3
 
coeval[fermionic5HalvesCat1Bal12] ^= 
   1/sixJFunction[fermionic5HalvesCat1][#1, dual[ring[fermionic5HalvesCat1]][
       #1], #1, #1, 0, 0] & 
 
fusionCategory[fermionic5HalvesCat1Bal12] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal12] ^= fermionic5HalvesCat1Piv4
 
ribbonCategory[fermionic5HalvesCat1Bal12] ^= fermionic5HalvesCat1Bal12
 
ring[fermionic5HalvesCat1Bal12] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat1Bal12] ^= fermionic5HalvesCat1Piv4
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd3]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal12] ^= 4
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal12] ^= 12
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv4]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal12] ^= 3
 
(ribbonCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd3]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal12] ^= 2
 
(ribbonCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal12] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[fermionic5HalvesCat1Piv4]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal12] ^= 3
balancedCategory[fermionic5HalvesCat1Bal13] ^= fermionic5HalvesCat1Bal13
 
braidedCategory[fermionic5HalvesCat1Bal13] ^= fermionic5HalvesCat1Brd4
 
coeval[fermionic5HalvesCat1Bal13] ^= 
   Which[fpDimension[fermionic5HalvesCat1Piv1][#1] != Sqrt[2], 
     FusionCategories`Private`defaultGaugeCoeval[fermionic5HalvesCat1Piv1][
      #1], #1 == 1, I*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv1][#1], #1 == 4, 
     (-I)*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv1][#1]] & 
 
fusionCategory[fermionic5HalvesCat1Bal13] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal13] ^= fermionic5HalvesCat1Piv1
 
ribbonCategory[fermionic5HalvesCat1Bal13] ^= fermionic5HalvesCat1Bal13
 
ring[fermionic5HalvesCat1Bal13] ^= fermionic5Halves
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd4]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal13] ^= 1
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal13] ^= 13
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal13] ^= 4
balancedCategory[fermionic5HalvesCat1Bal14] ^= fermionic5HalvesCat1Bal14
 
braidedCategory[fermionic5HalvesCat1Bal14] ^= fermionic5HalvesCat1Brd4
 
coeval[fermionic5HalvesCat1Bal14] ^= 
   Which[fpDimension[fermionic5HalvesCat1Piv2][#1] != Sqrt[2], 
     FusionCategories`Private`defaultGaugeCoeval[fermionic5HalvesCat1Piv2][
      #1], #1 == 1, I*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv2][#1], #1 == 4, 
     (-I)*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv2][#1]] & 
 
fusionCategory[fermionic5HalvesCat1Bal14] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal14] ^= fermionic5HalvesCat1Piv2
 
ribbonCategory[fermionic5HalvesCat1Bal14] ^= fermionic5HalvesCat1Bal14
 
ring[fermionic5HalvesCat1Bal14] ^= fermionic5Halves
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd4]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal14] ^= 2
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal14] ^= 14
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv2]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal14] ^= 4
balancedCategory[fermionic5HalvesCat1Bal15] ^= fermionic5HalvesCat1Bal15
 
braidedCategory[fermionic5HalvesCat1Bal15] ^= fermionic5HalvesCat1Brd4
 
coeval[fermionic5HalvesCat1Bal15] ^= 
   1/sixJFunction[fermionic5HalvesCat1][#1, dual[ring[fermionic5HalvesCat1]][
       #1], #1, #1, 0, 0] & 
 
fusionCategory[fermionic5HalvesCat1Bal15] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal15] ^= fermionic5HalvesCat1Piv3
 
ribbonCategory[fermionic5HalvesCat1Bal15] ^= fermionic5HalvesCat1Bal15
 
ring[fermionic5HalvesCat1Bal15] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat1Bal15] ^= fermionic5HalvesCat1Piv3
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd4]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal15] ^= 3
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal15] ^= 15
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv3]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal15] ^= 4
 
(ribbonCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd4]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal15] ^= 1
 
(ribbonCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal15] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[fermionic5HalvesCat1Piv3]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal15] ^= 4
balancedCategory[fermionic5HalvesCat1Bal16] ^= fermionic5HalvesCat1Bal16
 
braidedCategory[fermionic5HalvesCat1Bal16] ^= fermionic5HalvesCat1Brd4
 
coeval[fermionic5HalvesCat1Bal16] ^= 
   1/sixJFunction[fermionic5HalvesCat1][#1, dual[ring[fermionic5HalvesCat1]][
       #1], #1, #1, 0, 0] & 
 
fusionCategory[fermionic5HalvesCat1Bal16] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal16] ^= fermionic5HalvesCat1Piv4
 
ribbonCategory[fermionic5HalvesCat1Bal16] ^= fermionic5HalvesCat1Bal16
 
ring[fermionic5HalvesCat1Bal16] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat1Bal16] ^= fermionic5HalvesCat1Piv4
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd4]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal16] ^= 4
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal16] ^= 16
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv4]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal16] ^= 4
 
(ribbonCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd4]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal16] ^= 2
 
(ribbonCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal16] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[fermionic5HalvesCat1Piv4]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal16] ^= 4
balancedCategory[fermionic5HalvesCat1Bal17] ^= fermionic5HalvesCat1Bal17
 
braidedCategory[fermionic5HalvesCat1Bal17] ^= fermionic5HalvesCat1Brd5
 
coeval[fermionic5HalvesCat1Bal17] ^= 
   Which[fpDimension[fermionic5HalvesCat1Piv1][#1] != Sqrt[2], 
     FusionCategories`Private`defaultGaugeCoeval[fermionic5HalvesCat1Piv1][
      #1], #1 == 1, I*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv1][#1], #1 == 4, 
     (-I)*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv1][#1]] & 
 
fusionCategory[fermionic5HalvesCat1Bal17] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal17] ^= fermionic5HalvesCat1Piv1
 
ribbonCategory[fermionic5HalvesCat1Bal17] ^= fermionic5HalvesCat1Bal17
 
ring[fermionic5HalvesCat1Bal17] ^= fermionic5Halves
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd5]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal17] ^= 1
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal17] ^= 17
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal17] ^= 5
balancedCategory[fermionic5HalvesCat1Bal18] ^= fermionic5HalvesCat1Bal18
 
braidedCategory[fermionic5HalvesCat1Bal18] ^= fermionic5HalvesCat1Brd5
 
coeval[fermionic5HalvesCat1Bal18] ^= 
   Which[fpDimension[fermionic5HalvesCat1Piv2][#1] != Sqrt[2], 
     FusionCategories`Private`defaultGaugeCoeval[fermionic5HalvesCat1Piv2][
      #1], #1 == 1, I*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv2][#1], #1 == 4, 
     (-I)*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv2][#1]] & 
 
fusionCategory[fermionic5HalvesCat1Bal18] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal18] ^= fermionic5HalvesCat1Piv2
 
ribbonCategory[fermionic5HalvesCat1Bal18] ^= fermionic5HalvesCat1Bal18
 
ring[fermionic5HalvesCat1Bal18] ^= fermionic5Halves
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd5]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal18] ^= 2
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal18] ^= 18
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv2]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal18] ^= 5
balancedCategory[fermionic5HalvesCat1Bal19] ^= fermionic5HalvesCat1Bal19
 
braidedCategory[fermionic5HalvesCat1Bal19] ^= fermionic5HalvesCat1Brd5
 
coeval[fermionic5HalvesCat1Bal19] ^= 
   1/sixJFunction[fermionic5HalvesCat1][#1, dual[ring[fermionic5HalvesCat1]][
       #1], #1, #1, 0, 0] & 
 
fusionCategory[fermionic5HalvesCat1Bal19] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal19] ^= fermionic5HalvesCat1Piv3
 
ribbonCategory[fermionic5HalvesCat1Bal19] ^= fermionic5HalvesCat1Bal19
 
ring[fermionic5HalvesCat1Bal19] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat1Bal19] ^= fermionic5HalvesCat1Piv3
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd5]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal19] ^= 3
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal19] ^= 19
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv3]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal19] ^= 5
 
(ribbonCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd5]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal19] ^= 1
 
(ribbonCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal19] ^= 9
 
(ribbonCategoryIndex[sphericalCategory[fermionic5HalvesCat1Piv3]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal19] ^= 5
balancedCategory[fermionic5HalvesCat1Bal2] ^= fermionic5HalvesCat1Bal2
 
braidedCategory[fermionic5HalvesCat1Bal2] ^= fermionic5HalvesCat1Brd1
 
coeval[fermionic5HalvesCat1Bal2] ^= 
   Which[fpDimension[fermionic5HalvesCat1Piv2][#1] != Sqrt[2], 
     FusionCategories`Private`defaultGaugeCoeval[fermionic5HalvesCat1Piv2][
      #1], #1 == 1, I*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv2][#1], #1 == 4, 
     (-I)*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv2][#1]] & 
 
fusionCategory[fermionic5HalvesCat1Bal2] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal2] ^= fermionic5HalvesCat1Piv2
 
ribbonCategory[fermionic5HalvesCat1Bal2] ^= fermionic5HalvesCat1Bal2
 
ring[fermionic5HalvesCat1Bal2] ^= fermionic5Halves
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv2]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal2] ^= 1
balancedCategory[fermionic5HalvesCat1Bal20] ^= fermionic5HalvesCat1Bal20
 
braidedCategory[fermionic5HalvesCat1Bal20] ^= fermionic5HalvesCat1Brd5
 
coeval[fermionic5HalvesCat1Bal20] ^= 
   1/sixJFunction[fermionic5HalvesCat1][#1, dual[ring[fermionic5HalvesCat1]][
       #1], #1, #1, 0, 0] & 
 
fusionCategory[fermionic5HalvesCat1Bal20] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal20] ^= fermionic5HalvesCat1Piv4
 
ribbonCategory[fermionic5HalvesCat1Bal20] ^= fermionic5HalvesCat1Bal20
 
ring[fermionic5HalvesCat1Bal20] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat1Bal20] ^= fermionic5HalvesCat1Piv4
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd5]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal20] ^= 4
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal20] ^= 20
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv4]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal20] ^= 5
 
(ribbonCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd5]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal20] ^= 2
 
(ribbonCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal20] ^= 10
 
(ribbonCategoryIndex[sphericalCategory[fermionic5HalvesCat1Piv4]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal20] ^= 5
balancedCategory[fermionic5HalvesCat1Bal21] ^= fermionic5HalvesCat1Bal21
 
braidedCategory[fermionic5HalvesCat1Bal21] ^= fermionic5HalvesCat1Brd6
 
coeval[fermionic5HalvesCat1Bal21] ^= 
   Which[fpDimension[fermionic5HalvesCat1Piv1][#1] != Sqrt[2], 
     FusionCategories`Private`defaultGaugeCoeval[fermionic5HalvesCat1Piv1][
      #1], #1 == 1, I*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv1][#1], #1 == 4, 
     (-I)*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv1][#1]] & 
 
fusionCategory[fermionic5HalvesCat1Bal21] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal21] ^= fermionic5HalvesCat1Piv1
 
ribbonCategory[fermionic5HalvesCat1Bal21] ^= fermionic5HalvesCat1Bal21
 
ring[fermionic5HalvesCat1Bal21] ^= fermionic5Halves
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd6]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal21] ^= 1
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal21] ^= 21
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal21] ^= 6
balancedCategory[fermionic5HalvesCat1Bal22] ^= fermionic5HalvesCat1Bal22
 
braidedCategory[fermionic5HalvesCat1Bal22] ^= fermionic5HalvesCat1Brd6
 
coeval[fermionic5HalvesCat1Bal22] ^= 
   Which[fpDimension[fermionic5HalvesCat1Piv2][#1] != Sqrt[2], 
     FusionCategories`Private`defaultGaugeCoeval[fermionic5HalvesCat1Piv2][
      #1], #1 == 1, I*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv2][#1], #1 == 4, 
     (-I)*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv2][#1]] & 
 
fusionCategory[fermionic5HalvesCat1Bal22] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal22] ^= fermionic5HalvesCat1Piv2
 
ribbonCategory[fermionic5HalvesCat1Bal22] ^= fermionic5HalvesCat1Bal22
 
ring[fermionic5HalvesCat1Bal22] ^= fermionic5Halves
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd6]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal22] ^= 2
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal22] ^= 22
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv2]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal22] ^= 6
balancedCategory[fermionic5HalvesCat1Bal23] ^= fermionic5HalvesCat1Bal23
 
braidedCategory[fermionic5HalvesCat1Bal23] ^= fermionic5HalvesCat1Brd6
 
coeval[fermionic5HalvesCat1Bal23] ^= 
   1/sixJFunction[fermionic5HalvesCat1][#1, dual[ring[fermionic5HalvesCat1]][
       #1], #1, #1, 0, 0] & 
 
fusionCategory[fermionic5HalvesCat1Bal23] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal23] ^= fermionic5HalvesCat1Piv3
 
ribbonCategory[fermionic5HalvesCat1Bal23] ^= fermionic5HalvesCat1Bal23
 
ring[fermionic5HalvesCat1Bal23] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat1Bal23] ^= fermionic5HalvesCat1Piv3
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd6]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal23] ^= 3
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal23] ^= 23
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv3]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal23] ^= 6
 
(ribbonCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd6]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal23] ^= 1
 
(ribbonCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal23] ^= 11
 
(ribbonCategoryIndex[sphericalCategory[fermionic5HalvesCat1Piv3]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal23] ^= 6
balancedCategory[fermionic5HalvesCat1Bal24] ^= fermionic5HalvesCat1Bal24
 
braidedCategory[fermionic5HalvesCat1Bal24] ^= fermionic5HalvesCat1Brd6
 
coeval[fermionic5HalvesCat1Bal24] ^= 
   1/sixJFunction[fermionic5HalvesCat1][#1, dual[ring[fermionic5HalvesCat1]][
       #1], #1, #1, 0, 0] & 
 
fusionCategory[fermionic5HalvesCat1Bal24] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal24] ^= fermionic5HalvesCat1Piv4
 
ribbonCategory[fermionic5HalvesCat1Bal24] ^= fermionic5HalvesCat1Bal24
 
ring[fermionic5HalvesCat1Bal24] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat1Bal24] ^= fermionic5HalvesCat1Piv4
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd6]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal24] ^= 4
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal24] ^= 24
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv4]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal24] ^= 6
 
(ribbonCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd6]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal24] ^= 2
 
(ribbonCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal24] ^= 12
 
(ribbonCategoryIndex[sphericalCategory[fermionic5HalvesCat1Piv4]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal24] ^= 6
balancedCategory[fermionic5HalvesCat1Bal25] ^= fermionic5HalvesCat1Bal25
 
braidedCategory[fermionic5HalvesCat1Bal25] ^= fermionic5HalvesCat1Brd7
 
coeval[fermionic5HalvesCat1Bal25] ^= 
   Which[fpDimension[fermionic5HalvesCat1Piv1][#1] != Sqrt[2], 
     FusionCategories`Private`defaultGaugeCoeval[fermionic5HalvesCat1Piv1][
      #1], #1 == 1, I*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv1][#1], #1 == 4, 
     (-I)*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv1][#1]] & 
 
fusionCategory[fermionic5HalvesCat1Bal25] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal25] ^= fermionic5HalvesCat1Piv1
 
ribbonCategory[fermionic5HalvesCat1Bal25] ^= fermionic5HalvesCat1Bal25
 
ring[fermionic5HalvesCat1Bal25] ^= fermionic5Halves
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd7]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal25] ^= 1
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal25] ^= 25
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal25] ^= 7
balancedCategory[fermionic5HalvesCat1Bal26] ^= fermionic5HalvesCat1Bal26
 
braidedCategory[fermionic5HalvesCat1Bal26] ^= fermionic5HalvesCat1Brd7
 
coeval[fermionic5HalvesCat1Bal26] ^= 
   Which[fpDimension[fermionic5HalvesCat1Piv2][#1] != Sqrt[2], 
     FusionCategories`Private`defaultGaugeCoeval[fermionic5HalvesCat1Piv2][
      #1], #1 == 1, I*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv2][#1], #1 == 4, 
     (-I)*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv2][#1]] & 
 
fusionCategory[fermionic5HalvesCat1Bal26] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal26] ^= fermionic5HalvesCat1Piv2
 
ribbonCategory[fermionic5HalvesCat1Bal26] ^= fermionic5HalvesCat1Bal26
 
ring[fermionic5HalvesCat1Bal26] ^= fermionic5Halves
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd7]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal26] ^= 2
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal26] ^= 26
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv2]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal26] ^= 7
balancedCategory[fermionic5HalvesCat1Bal27] ^= fermionic5HalvesCat1Bal27
 
braidedCategory[fermionic5HalvesCat1Bal27] ^= fermionic5HalvesCat1Brd7
 
coeval[fermionic5HalvesCat1Bal27] ^= 
   1/sixJFunction[fermionic5HalvesCat1][#1, dual[ring[fermionic5HalvesCat1]][
       #1], #1, #1, 0, 0] & 
 
fusionCategory[fermionic5HalvesCat1Bal27] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal27] ^= fermionic5HalvesCat1Piv3
 
ribbonCategory[fermionic5HalvesCat1Bal27] ^= fermionic5HalvesCat1Bal27
 
ring[fermionic5HalvesCat1Bal27] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat1Bal27] ^= fermionic5HalvesCat1Piv3
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd7]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal27] ^= 3
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal27] ^= 27
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv3]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal27] ^= 7
 
(ribbonCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd7]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal27] ^= 1
 
(ribbonCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal27] ^= 13
 
(ribbonCategoryIndex[sphericalCategory[fermionic5HalvesCat1Piv3]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal27] ^= 7
balancedCategory[fermionic5HalvesCat1Bal28] ^= fermionic5HalvesCat1Bal28
 
braidedCategory[fermionic5HalvesCat1Bal28] ^= fermionic5HalvesCat1Brd7
 
coeval[fermionic5HalvesCat1Bal28] ^= 
   1/sixJFunction[fermionic5HalvesCat1][#1, dual[ring[fermionic5HalvesCat1]][
       #1], #1, #1, 0, 0] & 
 
fusionCategory[fermionic5HalvesCat1Bal28] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal28] ^= fermionic5HalvesCat1Piv4
 
ribbonCategory[fermionic5HalvesCat1Bal28] ^= fermionic5HalvesCat1Bal28
 
ring[fermionic5HalvesCat1Bal28] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat1Bal28] ^= fermionic5HalvesCat1Piv4
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd7]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal28] ^= 4
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal28] ^= 28
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv4]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal28] ^= 7
 
(ribbonCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd7]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal28] ^= 2
 
(ribbonCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal28] ^= 14
 
(ribbonCategoryIndex[sphericalCategory[fermionic5HalvesCat1Piv4]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal28] ^= 7
balancedCategory[fermionic5HalvesCat1Bal29] ^= fermionic5HalvesCat1Bal29
 
braidedCategory[fermionic5HalvesCat1Bal29] ^= fermionic5HalvesCat1Brd8
 
coeval[fermionic5HalvesCat1Bal29] ^= 
   Which[fpDimension[fermionic5HalvesCat1Piv1][#1] != Sqrt[2], 
     FusionCategories`Private`defaultGaugeCoeval[fermionic5HalvesCat1Piv1][
      #1], #1 == 1, I*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv1][#1], #1 == 4, 
     (-I)*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv1][#1]] & 
 
fusionCategory[fermionic5HalvesCat1Bal29] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal29] ^= fermionic5HalvesCat1Piv1
 
ribbonCategory[fermionic5HalvesCat1Bal29] ^= fermionic5HalvesCat1Bal29
 
ring[fermionic5HalvesCat1Bal29] ^= fermionic5Halves
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd8]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal29] ^= 1
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal29] ^= 29
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal29] ^= 8
balancedCategory[fermionic5HalvesCat1Bal3] ^= fermionic5HalvesCat1Bal3
 
braidedCategory[fermionic5HalvesCat1Bal3] ^= fermionic5HalvesCat1Brd1
 
coeval[fermionic5HalvesCat1Bal3] ^= 
   1/sixJFunction[fermionic5HalvesCat1][#1, dual[ring[fermionic5HalvesCat1]][
       #1], #1, #1, 0, 0] & 
 
fusionCategory[fermionic5HalvesCat1Bal3] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal3] ^= fermionic5HalvesCat1Piv3
 
ribbonCategory[fermionic5HalvesCat1Bal3] ^= fermionic5HalvesCat1Bal3
 
ring[fermionic5HalvesCat1Bal3] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat1Bal3] ^= fermionic5HalvesCat1Piv3
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal3] ^= 3
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv3]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal3] ^= 1
 
(ribbonCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd1]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal3] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[fermionic5HalvesCat1Piv3]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal3] ^= 1
balancedCategory[fermionic5HalvesCat1Bal30] ^= fermionic5HalvesCat1Bal30
 
braidedCategory[fermionic5HalvesCat1Bal30] ^= fermionic5HalvesCat1Brd8
 
coeval[fermionic5HalvesCat1Bal30] ^= 
   Which[fpDimension[fermionic5HalvesCat1Piv2][#1] != Sqrt[2], 
     FusionCategories`Private`defaultGaugeCoeval[fermionic5HalvesCat1Piv2][
      #1], #1 == 1, I*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv2][#1], #1 == 4, 
     (-I)*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv2][#1]] & 
 
fusionCategory[fermionic5HalvesCat1Bal30] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal30] ^= fermionic5HalvesCat1Piv2
 
ribbonCategory[fermionic5HalvesCat1Bal30] ^= fermionic5HalvesCat1Bal30
 
ring[fermionic5HalvesCat1Bal30] ^= fermionic5Halves
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd8]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal30] ^= 2
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal30] ^= 30
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv2]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal30] ^= 8
balancedCategory[fermionic5HalvesCat1Bal31] ^= fermionic5HalvesCat1Bal31
 
braidedCategory[fermionic5HalvesCat1Bal31] ^= fermionic5HalvesCat1Brd8
 
coeval[fermionic5HalvesCat1Bal31] ^= 
   1/sixJFunction[fermionic5HalvesCat1][#1, dual[ring[fermionic5HalvesCat1]][
       #1], #1, #1, 0, 0] & 
 
fusionCategory[fermionic5HalvesCat1Bal31] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal31] ^= fermionic5HalvesCat1Piv3
 
ribbonCategory[fermionic5HalvesCat1Bal31] ^= fermionic5HalvesCat1Bal31
 
ring[fermionic5HalvesCat1Bal31] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat1Bal31] ^= fermionic5HalvesCat1Piv3
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd8]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal31] ^= 3
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal31] ^= 31
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv3]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal31] ^= 8
 
(ribbonCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd8]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal31] ^= 1
 
(ribbonCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal31] ^= 15
 
(ribbonCategoryIndex[sphericalCategory[fermionic5HalvesCat1Piv3]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal31] ^= 8
balancedCategory[fermionic5HalvesCat1Bal32] ^= fermionic5HalvesCat1Bal32
 
braidedCategory[fermionic5HalvesCat1Bal32] ^= fermionic5HalvesCat1Brd8
 
coeval[fermionic5HalvesCat1Bal32] ^= 
   1/sixJFunction[fermionic5HalvesCat1][#1, dual[ring[fermionic5HalvesCat1]][
       #1], #1, #1, 0, 0] & 
 
fusionCategory[fermionic5HalvesCat1Bal32] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal32] ^= fermionic5HalvesCat1Piv4
 
ribbonCategory[fermionic5HalvesCat1Bal32] ^= fermionic5HalvesCat1Bal32
 
ring[fermionic5HalvesCat1Bal32] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat1Bal32] ^= fermionic5HalvesCat1Piv4
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd8]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal32] ^= 4
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal32] ^= 32
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv4]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal32] ^= 8
 
(ribbonCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd8]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal32] ^= 2
 
(ribbonCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal32] ^= 16
 
(ribbonCategoryIndex[sphericalCategory[fermionic5HalvesCat1Piv4]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal32] ^= 8
balancedCategory[fermionic5HalvesCat1Bal4] ^= fermionic5HalvesCat1Bal4
 
braidedCategory[fermionic5HalvesCat1Bal4] ^= fermionic5HalvesCat1Brd1
 
coeval[fermionic5HalvesCat1Bal4] ^= 
   1/sixJFunction[fermionic5HalvesCat1][#1, dual[ring[fermionic5HalvesCat1]][
       #1], #1, #1, 0, 0] & 
 
fusionCategory[fermionic5HalvesCat1Bal4] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal4] ^= fermionic5HalvesCat1Piv4
 
ribbonCategory[fermionic5HalvesCat1Bal4] ^= fermionic5HalvesCat1Bal4
 
ring[fermionic5HalvesCat1Bal4] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat1Bal4] ^= fermionic5HalvesCat1Piv4
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal4] ^= 4
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv4]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal4] ^= 1
 
(ribbonCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd1]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal4] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[fermionic5HalvesCat1Piv4]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal4] ^= 1
balancedCategory[fermionic5HalvesCat1Bal5] ^= fermionic5HalvesCat1Bal5
 
braidedCategory[fermionic5HalvesCat1Bal5] ^= fermionic5HalvesCat1Brd2
 
coeval[fermionic5HalvesCat1Bal5] ^= 
   Which[fpDimension[fermionic5HalvesCat1Piv1][#1] != Sqrt[2], 
     FusionCategories`Private`defaultGaugeCoeval[fermionic5HalvesCat1Piv1][
      #1], #1 == 1, I*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv1][#1], #1 == 4, 
     (-I)*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv1][#1]] & 
 
fusionCategory[fermionic5HalvesCat1Bal5] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal5] ^= fermionic5HalvesCat1Piv1
 
ribbonCategory[fermionic5HalvesCat1Bal5] ^= fermionic5HalvesCat1Bal5
 
ring[fermionic5HalvesCat1Bal5] ^= fermionic5Halves
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd2]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal5] ^= 2
balancedCategory[fermionic5HalvesCat1Bal6] ^= fermionic5HalvesCat1Bal6
 
braidedCategory[fermionic5HalvesCat1Bal6] ^= fermionic5HalvesCat1Brd2
 
coeval[fermionic5HalvesCat1Bal6] ^= 
   Which[fpDimension[fermionic5HalvesCat1Piv2][#1] != Sqrt[2], 
     FusionCategories`Private`defaultGaugeCoeval[fermionic5HalvesCat1Piv2][
      #1], #1 == 1, I*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv2][#1], #1 == 4, 
     (-I)*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv2][#1]] & 
 
fusionCategory[fermionic5HalvesCat1Bal6] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal6] ^= fermionic5HalvesCat1Piv2
 
ribbonCategory[fermionic5HalvesCat1Bal6] ^= fermionic5HalvesCat1Bal6
 
ring[fermionic5HalvesCat1Bal6] ^= fermionic5Halves
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd2]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv2]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal6] ^= 2
balancedCategory[fermionic5HalvesCat1Bal7] ^= fermionic5HalvesCat1Bal7
 
braidedCategory[fermionic5HalvesCat1Bal7] ^= fermionic5HalvesCat1Brd2
 
coeval[fermionic5HalvesCat1Bal7] ^= 
   1/sixJFunction[fermionic5HalvesCat1][#1, dual[ring[fermionic5HalvesCat1]][
       #1], #1, #1, 0, 0] & 
 
fusionCategory[fermionic5HalvesCat1Bal7] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal7] ^= fermionic5HalvesCat1Piv3
 
ribbonCategory[fermionic5HalvesCat1Bal7] ^= fermionic5HalvesCat1Bal7
 
ring[fermionic5HalvesCat1Bal7] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat1Bal7] ^= fermionic5HalvesCat1Piv3
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd2]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal7] ^= 3
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv3]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal7] ^= 2
 
(ribbonCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd2]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal7] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[fermionic5HalvesCat1Piv3]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal7] ^= 2
balancedCategory[fermionic5HalvesCat1Bal8] ^= fermionic5HalvesCat1Bal8
 
braidedCategory[fermionic5HalvesCat1Bal8] ^= fermionic5HalvesCat1Brd2
 
coeval[fermionic5HalvesCat1Bal8] ^= 
   1/sixJFunction[fermionic5HalvesCat1][#1, dual[ring[fermionic5HalvesCat1]][
       #1], #1, #1, 0, 0] & 
 
fusionCategory[fermionic5HalvesCat1Bal8] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal8] ^= fermionic5HalvesCat1Piv4
 
ribbonCategory[fermionic5HalvesCat1Bal8] ^= fermionic5HalvesCat1Bal8
 
ring[fermionic5HalvesCat1Bal8] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat1Bal8] ^= fermionic5HalvesCat1Piv4
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd2]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal8] ^= 4
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv4]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal8] ^= 2
 
(ribbonCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd2]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal8] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[fermionic5HalvesCat1Piv4]][
      ribbonCategory[#1]] & )[fermionic5HalvesCat1Bal8] ^= 2
balancedCategory[fermionic5HalvesCat1Bal9] ^= fermionic5HalvesCat1Bal9
 
braidedCategory[fermionic5HalvesCat1Bal9] ^= fermionic5HalvesCat1Brd3
 
coeval[fermionic5HalvesCat1Bal9] ^= 
   Which[fpDimension[fermionic5HalvesCat1Piv1][#1] != Sqrt[2], 
     FusionCategories`Private`defaultGaugeCoeval[fermionic5HalvesCat1Piv1][
      #1], #1 == 1, I*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv1][#1], #1 == 4, 
     (-I)*FusionCategories`Private`defaultGaugeCoeval[
        fermionic5HalvesCat1Piv1][#1]] & 
 
fusionCategory[fermionic5HalvesCat1Bal9] ^= fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Bal9] ^= fermionic5HalvesCat1Piv1
 
ribbonCategory[fermionic5HalvesCat1Bal9] ^= fermionic5HalvesCat1Bal9
 
ring[fermionic5HalvesCat1Bal9] ^= fermionic5Halves
 
(balancedCategoryIndex[braidedCategory[fermionic5HalvesCat1Brd3]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal9] ^= 1
 
(balancedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal9] ^= 9
 
(balancedCategoryIndex[pivotalCategory[fermionic5HalvesCat1Piv1]][
      balancedCategory[#1]] & )[fermionic5HalvesCat1Bal9] ^= 3
balancedCategories[fermionic5HalvesCat1Brd1] ^= {fermionic5HalvesCat1Bal1, 
    fermionic5HalvesCat1Bal2, fermionic5HalvesCat1Bal3, 
    fermionic5HalvesCat1Bal4}
 
fermionic5HalvesCat1Brd1 /: balancedCategory[fermionic5HalvesCat1Brd1, 1] = 
    fermionic5HalvesCat1Bal1
 
fermionic5HalvesCat1Brd1 /: balancedCategory[fermionic5HalvesCat1Brd1, 2] = 
    fermionic5HalvesCat1Bal2
 
fermionic5HalvesCat1Brd1 /: balancedCategory[fermionic5HalvesCat1Brd1, 3] = 
    fermionic5HalvesCat1Bal3
 
fermionic5HalvesCat1Brd1 /: balancedCategory[fermionic5HalvesCat1Brd1, 4] = 
    fermionic5HalvesCat1Bal4
 
braidedCategory[fermionic5HalvesCat1Brd1] ^= fermionic5HalvesCat1Brd1
 
fusionCategory[fermionic5HalvesCat1Brd1] ^= fermionic5HalvesCat1
 
fermionic5HalvesCat1Brd1 /: modularCategory[fermionic5HalvesCat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
fermionic5HalvesCat1Brd1 /: ribbonCategory[fermionic5HalvesCat1Brd1, 1] = 
    fermionic5HalvesCat1Bal3
 
fermionic5HalvesCat1Brd1 /: ribbonCategory[fermionic5HalvesCat1Brd1, 2] = 
    fermionic5HalvesCat1Bal4
 
ring[fermionic5HalvesCat1Brd1] ^= fermionic5Halves
 
rMatrixFunction[fermionic5HalvesCat1Brd1] ^= 
   fermionic5HalvesCat1Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      braidedCategory[#1]] & )[fermionic5HalvesCat1Brd1] ^= 1
braidedCategory[fermionic5HalvesCat1Brd1RMatrixFunction] ^= 
   fermionic5HalvesCat1Brd1
 
fusionCategory[fermionic5HalvesCat1Brd1RMatrixFunction] ^= 
   fermionic5HalvesCat1
 
rMatrixFunction[fermionic5HalvesCat1Brd1RMatrixFunction] ^= 
   fermionic5HalvesCat1Brd1RMatrixFunction
 
fermionic5HalvesCat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[0, 5, 5] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[1, 1, 3] = {{(-1)^(7/8)}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[1, 1, 5] = {{(-1)^(3/8)}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[1, 2, 1] = {{I}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[1, 3, 4] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[1, 4, 0] = {{(-1)^(7/8)}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[1, 4, 2] = {{(-1)^(3/8)}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[1, 5, 4] = {{-I}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[2, 1, 1] = {{I}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[2, 2, 0] = {{-1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[2, 3, 5] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[2, 4, 4] = {{I}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[2, 5, 3] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[3, 1, 4] = {{-1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[3, 2, 5] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[3, 3, 0] = {{-1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[3, 4, 1] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[3, 5, 2] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[4, 1, 0] = {{-(-1)^(7/8)}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[4, 1, 2] = {{-(-1)^(3/8)}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[4, 2, 4] = {{I}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[4, 3, 1] = {{-1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[4, 4, 3] = {{(-1)^(7/8)}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[4, 4, 5] = {{(-1)^(3/8)}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[4, 5, 1] = {{I}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[5, 0, 5] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[5, 1, 4] = {{I}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[5, 2, 3] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[5, 3, 2] = {{1}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[5, 4, 1] = {{-I}}
 
fermionic5HalvesCat1Brd1RMatrixFunction[5, 5, 0] = {{1}}
balancedCategories[fermionic5HalvesCat1Brd2] ^= {fermionic5HalvesCat1Bal5, 
    fermionic5HalvesCat1Bal6, fermionic5HalvesCat1Bal7, 
    fermionic5HalvesCat1Bal8}
 
fermionic5HalvesCat1Brd2 /: balancedCategory[fermionic5HalvesCat1Brd2, 1] = 
    fermionic5HalvesCat1Bal5
 
fermionic5HalvesCat1Brd2 /: balancedCategory[fermionic5HalvesCat1Brd2, 2] = 
    fermionic5HalvesCat1Bal6
 
fermionic5HalvesCat1Brd2 /: balancedCategory[fermionic5HalvesCat1Brd2, 3] = 
    fermionic5HalvesCat1Bal7
 
fermionic5HalvesCat1Brd2 /: balancedCategory[fermionic5HalvesCat1Brd2, 4] = 
    fermionic5HalvesCat1Bal8
 
braidedCategory[fermionic5HalvesCat1Brd2] ^= fermionic5HalvesCat1Brd2
 
fusionCategory[fermionic5HalvesCat1Brd2] ^= fermionic5HalvesCat1
 
fermionic5HalvesCat1Brd2 /: modularCategory[fermionic5HalvesCat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
fermionic5HalvesCat1Brd2 /: ribbonCategory[fermionic5HalvesCat1Brd2, 1] = 
    fermionic5HalvesCat1Bal7
 
fermionic5HalvesCat1Brd2 /: ribbonCategory[fermionic5HalvesCat1Brd2, 2] = 
    fermionic5HalvesCat1Bal8
 
ring[fermionic5HalvesCat1Brd2] ^= fermionic5Halves
 
rMatrixFunction[fermionic5HalvesCat1Brd2] ^= 
   fermionic5HalvesCat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      braidedCategory[#1]] & )[fermionic5HalvesCat1Brd2] ^= 2
braidedCategory[fermionic5HalvesCat1Brd2RMatrixFunction] ^= 
   fermionic5HalvesCat1Brd2
 
fusionCategory[fermionic5HalvesCat1Brd2RMatrixFunction] ^= 
   fermionic5HalvesCat1
 
rMatrixFunction[fermionic5HalvesCat1Brd2RMatrixFunction] ^= 
   fermionic5HalvesCat1Brd2RMatrixFunction
 
fermionic5HalvesCat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[0, 4, 4] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[0, 5, 5] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[1, 1, 3] = {{-(-1)^(7/8)}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[1, 1, 5] = {{-(-1)^(3/8)}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[1, 2, 1] = {{I}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[1, 3, 4] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[1, 4, 0] = {{-(-1)^(7/8)}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[1, 4, 2] = {{-(-1)^(3/8)}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[1, 5, 4] = {{-I}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[2, 1, 1] = {{I}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[2, 2, 0] = {{-1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[2, 3, 5] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[2, 4, 4] = {{I}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[2, 5, 3] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[3, 1, 4] = {{-1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[3, 2, 5] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[3, 3, 0] = {{-1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[3, 4, 1] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[3, 5, 2] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[4, 0, 4] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[4, 1, 0] = {{(-1)^(7/8)}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[4, 1, 2] = {{(-1)^(3/8)}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[4, 2, 4] = {{I}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[4, 3, 1] = {{-1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[4, 4, 3] = {{-(-1)^(7/8)}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[4, 4, 5] = {{-(-1)^(3/8)}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[4, 5, 1] = {{I}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[5, 0, 5] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[5, 1, 4] = {{I}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[5, 2, 3] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[5, 3, 2] = {{1}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[5, 4, 1] = {{-I}}
 
fermionic5HalvesCat1Brd2RMatrixFunction[5, 5, 0] = {{1}}
balancedCategories[fermionic5HalvesCat1Brd3] ^= {fermionic5HalvesCat1Bal9, 
    fermionic5HalvesCat1Bal10, fermionic5HalvesCat1Bal11, 
    fermionic5HalvesCat1Bal12}
 
fermionic5HalvesCat1Brd3 /: balancedCategory[fermionic5HalvesCat1Brd3, 1] = 
    fermionic5HalvesCat1Bal9
 
fermionic5HalvesCat1Brd3 /: balancedCategory[fermionic5HalvesCat1Brd3, 2] = 
    fermionic5HalvesCat1Bal10
 
fermionic5HalvesCat1Brd3 /: balancedCategory[fermionic5HalvesCat1Brd3, 3] = 
    fermionic5HalvesCat1Bal11
 
fermionic5HalvesCat1Brd3 /: balancedCategory[fermionic5HalvesCat1Brd3, 4] = 
    fermionic5HalvesCat1Bal12
 
braidedCategory[fermionic5HalvesCat1Brd3] ^= fermionic5HalvesCat1Brd3
 
fusionCategory[fermionic5HalvesCat1Brd3] ^= fermionic5HalvesCat1
 
fermionic5HalvesCat1Brd3 /: modularCategory[fermionic5HalvesCat1Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
fermionic5HalvesCat1Brd3 /: ribbonCategory[fermionic5HalvesCat1Brd3, 1] = 
    fermionic5HalvesCat1Bal11
 
fermionic5HalvesCat1Brd3 /: ribbonCategory[fermionic5HalvesCat1Brd3, 2] = 
    fermionic5HalvesCat1Bal12
 
ring[fermionic5HalvesCat1Brd3] ^= fermionic5Halves
 
rMatrixFunction[fermionic5HalvesCat1Brd3] ^= 
   fermionic5HalvesCat1Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      braidedCategory[#1]] & )[fermionic5HalvesCat1Brd3] ^= 3
braidedCategory[fermionic5HalvesCat1Brd3RMatrixFunction] ^= 
   fermionic5HalvesCat1Brd3
 
fusionCategory[fermionic5HalvesCat1Brd3RMatrixFunction] ^= 
   fermionic5HalvesCat1
 
rMatrixFunction[fermionic5HalvesCat1Brd3RMatrixFunction] ^= 
   fermionic5HalvesCat1Brd3RMatrixFunction
 
fermionic5HalvesCat1Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[0, 4, 4] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[0, 5, 5] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[1, 1, 3] = {{(-1)^(5/8)}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[1, 1, 5] = {{-(-1)^(1/8)}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[1, 2, 1] = {{-I}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[1, 3, 4] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[1, 4, 0] = {{(-1)^(5/8)}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[1, 4, 2] = {{-(-1)^(1/8)}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[1, 5, 4] = {{I}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[2, 1, 1] = {{-I}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[2, 2, 0] = {{-1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[2, 3, 5] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[2, 4, 4] = {{-I}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[2, 5, 3] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[3, 1, 4] = {{-1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[3, 2, 5] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[3, 3, 0] = {{-1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[3, 4, 1] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[3, 5, 2] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[4, 0, 4] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[4, 1, 0] = {{-(-1)^(5/8)}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[4, 1, 2] = {{(-1)^(1/8)}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[4, 2, 4] = {{-I}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[4, 3, 1] = {{-1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[4, 4, 3] = {{(-1)^(5/8)}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[4, 4, 5] = {{-(-1)^(1/8)}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[4, 5, 1] = {{-I}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[5, 0, 5] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[5, 1, 4] = {{-I}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[5, 2, 3] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[5, 3, 2] = {{1}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[5, 4, 1] = {{I}}
 
fermionic5HalvesCat1Brd3RMatrixFunction[5, 5, 0] = {{1}}
balancedCategories[fermionic5HalvesCat1Brd4] ^= {fermionic5HalvesCat1Bal13, 
    fermionic5HalvesCat1Bal14, fermionic5HalvesCat1Bal15, 
    fermionic5HalvesCat1Bal16}
 
fermionic5HalvesCat1Brd4 /: balancedCategory[fermionic5HalvesCat1Brd4, 1] = 
    fermionic5HalvesCat1Bal13
 
fermionic5HalvesCat1Brd4 /: balancedCategory[fermionic5HalvesCat1Brd4, 2] = 
    fermionic5HalvesCat1Bal14
 
fermionic5HalvesCat1Brd4 /: balancedCategory[fermionic5HalvesCat1Brd4, 3] = 
    fermionic5HalvesCat1Bal15
 
fermionic5HalvesCat1Brd4 /: balancedCategory[fermionic5HalvesCat1Brd4, 4] = 
    fermionic5HalvesCat1Bal16
 
braidedCategory[fermionic5HalvesCat1Brd4] ^= fermionic5HalvesCat1Brd4
 
fusionCategory[fermionic5HalvesCat1Brd4] ^= fermionic5HalvesCat1
 
fermionic5HalvesCat1Brd4 /: modularCategory[fermionic5HalvesCat1Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
fermionic5HalvesCat1Brd4 /: ribbonCategory[fermionic5HalvesCat1Brd4, 1] = 
    fermionic5HalvesCat1Bal15
 
fermionic5HalvesCat1Brd4 /: ribbonCategory[fermionic5HalvesCat1Brd4, 2] = 
    fermionic5HalvesCat1Bal16
 
ring[fermionic5HalvesCat1Brd4] ^= fermionic5Halves
 
rMatrixFunction[fermionic5HalvesCat1Brd4] ^= 
   fermionic5HalvesCat1Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      braidedCategory[#1]] & )[fermionic5HalvesCat1Brd4] ^= 4
braidedCategory[fermionic5HalvesCat1Brd4RMatrixFunction] ^= 
   fermionic5HalvesCat1Brd4
 
fusionCategory[fermionic5HalvesCat1Brd4RMatrixFunction] ^= 
   fermionic5HalvesCat1
 
rMatrixFunction[fermionic5HalvesCat1Brd4RMatrixFunction] ^= 
   fermionic5HalvesCat1Brd4RMatrixFunction
 
fermionic5HalvesCat1Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[0, 4, 4] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[0, 5, 5] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[1, 1, 3] = {{-(-1)^(5/8)}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[1, 1, 5] = {{(-1)^(1/8)}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[1, 2, 1] = {{-I}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[1, 3, 4] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[1, 4, 0] = {{-(-1)^(5/8)}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[1, 4, 2] = {{(-1)^(1/8)}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[1, 5, 4] = {{I}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[2, 1, 1] = {{-I}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[2, 2, 0] = {{-1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[2, 3, 5] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[2, 4, 4] = {{-I}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[2, 5, 3] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[3, 1, 4] = {{-1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[3, 2, 5] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[3, 3, 0] = {{-1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[3, 4, 1] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[3, 5, 2] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[4, 0, 4] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[4, 1, 0] = {{(-1)^(5/8)}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[4, 1, 2] = {{-(-1)^(1/8)}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[4, 2, 4] = {{-I}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[4, 3, 1] = {{-1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[4, 4, 3] = {{-(-1)^(5/8)}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[4, 4, 5] = {{(-1)^(1/8)}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[4, 5, 1] = {{-I}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[5, 0, 5] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[5, 1, 4] = {{-I}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[5, 2, 3] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[5, 3, 2] = {{1}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[5, 4, 1] = {{I}}
 
fermionic5HalvesCat1Brd4RMatrixFunction[5, 5, 0] = {{1}}
balancedCategories[fermionic5HalvesCat1Brd5] ^= {fermionic5HalvesCat1Bal17, 
    fermionic5HalvesCat1Bal18, fermionic5HalvesCat1Bal19, 
    fermionic5HalvesCat1Bal20}
 
fermionic5HalvesCat1Brd5 /: balancedCategory[fermionic5HalvesCat1Brd5, 1] = 
    fermionic5HalvesCat1Bal17
 
fermionic5HalvesCat1Brd5 /: balancedCategory[fermionic5HalvesCat1Brd5, 2] = 
    fermionic5HalvesCat1Bal18
 
fermionic5HalvesCat1Brd5 /: balancedCategory[fermionic5HalvesCat1Brd5, 3] = 
    fermionic5HalvesCat1Bal19
 
fermionic5HalvesCat1Brd5 /: balancedCategory[fermionic5HalvesCat1Brd5, 4] = 
    fermionic5HalvesCat1Bal20
 
braidedCategory[fermionic5HalvesCat1Brd5] ^= fermionic5HalvesCat1Brd5
 
fusionCategory[fermionic5HalvesCat1Brd5] ^= fermionic5HalvesCat1
 
fermionic5HalvesCat1Brd5 /: modularCategory[fermionic5HalvesCat1Brd5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
fermionic5HalvesCat1Brd5 /: ribbonCategory[fermionic5HalvesCat1Brd5, 1] = 
    fermionic5HalvesCat1Bal19
 
fermionic5HalvesCat1Brd5 /: ribbonCategory[fermionic5HalvesCat1Brd5, 2] = 
    fermionic5HalvesCat1Bal20
 
ring[fermionic5HalvesCat1Brd5] ^= fermionic5Halves
 
rMatrixFunction[fermionic5HalvesCat1Brd5] ^= 
   fermionic5HalvesCat1Brd5RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      braidedCategory[#1]] & )[fermionic5HalvesCat1Brd5] ^= 5
braidedCategory[fermionic5HalvesCat1Brd5RMatrixFunction] ^= 
   fermionic5HalvesCat1Brd5
 
fusionCategory[fermionic5HalvesCat1Brd5RMatrixFunction] ^= 
   fermionic5HalvesCat1
 
rMatrixFunction[fermionic5HalvesCat1Brd5RMatrixFunction] ^= 
   fermionic5HalvesCat1Brd5RMatrixFunction
 
fermionic5HalvesCat1Brd5RMatrixFunction[0, 0, 0] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[0, 1, 1] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[0, 2, 2] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[0, 3, 3] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[0, 4, 4] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[0, 5, 5] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[1, 0, 1] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[1, 1, 3] = {{-(-1)^(3/8)}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[1, 1, 5] = {{(-1)^(7/8)}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[1, 2, 1] = {{I}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[1, 3, 4] = {{-1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[1, 4, 0] = {{(-1)^(3/8)}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[1, 4, 2] = {{-(-1)^(7/8)}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[1, 5, 4] = {{I}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[2, 0, 2] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[2, 1, 1] = {{I}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[2, 2, 0] = {{-1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[2, 3, 5] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[2, 4, 4] = {{I}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[2, 5, 3] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[3, 0, 3] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[3, 1, 4] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[3, 2, 5] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[3, 3, 0] = {{-1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[3, 4, 1] = {{-1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[3, 5, 2] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[4, 0, 4] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[4, 1, 0] = {{-(-1)^(3/8)}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[4, 1, 2] = {{(-1)^(7/8)}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[4, 2, 4] = {{I}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[4, 3, 1] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[4, 4, 3] = {{-(-1)^(3/8)}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[4, 4, 5] = {{(-1)^(7/8)}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[4, 5, 1] = {{-I}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[5, 0, 5] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[5, 1, 4] = {{-I}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[5, 2, 3] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[5, 3, 2] = {{1}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[5, 4, 1] = {{I}}
 
fermionic5HalvesCat1Brd5RMatrixFunction[5, 5, 0] = {{1}}
balancedCategories[fermionic5HalvesCat1Brd6] ^= {fermionic5HalvesCat1Bal21, 
    fermionic5HalvesCat1Bal22, fermionic5HalvesCat1Bal23, 
    fermionic5HalvesCat1Bal24}
 
fermionic5HalvesCat1Brd6 /: balancedCategory[fermionic5HalvesCat1Brd6, 1] = 
    fermionic5HalvesCat1Bal21
 
fermionic5HalvesCat1Brd6 /: balancedCategory[fermionic5HalvesCat1Brd6, 2] = 
    fermionic5HalvesCat1Bal22
 
fermionic5HalvesCat1Brd6 /: balancedCategory[fermionic5HalvesCat1Brd6, 3] = 
    fermionic5HalvesCat1Bal23
 
fermionic5HalvesCat1Brd6 /: balancedCategory[fermionic5HalvesCat1Brd6, 4] = 
    fermionic5HalvesCat1Bal24
 
braidedCategory[fermionic5HalvesCat1Brd6] ^= fermionic5HalvesCat1Brd6
 
fusionCategory[fermionic5HalvesCat1Brd6] ^= fermionic5HalvesCat1
 
fermionic5HalvesCat1Brd6 /: modularCategory[fermionic5HalvesCat1Brd6, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
fermionic5HalvesCat1Brd6 /: ribbonCategory[fermionic5HalvesCat1Brd6, 1] = 
    fermionic5HalvesCat1Bal23
 
fermionic5HalvesCat1Brd6 /: ribbonCategory[fermionic5HalvesCat1Brd6, 2] = 
    fermionic5HalvesCat1Bal24
 
ring[fermionic5HalvesCat1Brd6] ^= fermionic5Halves
 
rMatrixFunction[fermionic5HalvesCat1Brd6] ^= 
   fermionic5HalvesCat1Brd6RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      braidedCategory[#1]] & )[fermionic5HalvesCat1Brd6] ^= 6
braidedCategory[fermionic5HalvesCat1Brd6RMatrixFunction] ^= 
   fermionic5HalvesCat1Brd6
 
fusionCategory[fermionic5HalvesCat1Brd6RMatrixFunction] ^= 
   fermionic5HalvesCat1
 
rMatrixFunction[fermionic5HalvesCat1Brd6RMatrixFunction] ^= 
   fermionic5HalvesCat1Brd6RMatrixFunction
 
fermionic5HalvesCat1Brd6RMatrixFunction[0, 0, 0] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[0, 1, 1] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[0, 2, 2] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[0, 3, 3] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[0, 4, 4] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[0, 5, 5] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[1, 0, 1] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[1, 1, 3] = {{(-1)^(3/8)}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[1, 1, 5] = {{-(-1)^(7/8)}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[1, 2, 1] = {{I}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[1, 3, 4] = {{-1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[1, 4, 0] = {{-(-1)^(3/8)}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[1, 4, 2] = {{(-1)^(7/8)}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[1, 5, 4] = {{I}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[2, 0, 2] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[2, 1, 1] = {{I}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[2, 2, 0] = {{-1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[2, 3, 5] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[2, 4, 4] = {{I}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[2, 5, 3] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[3, 0, 3] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[3, 1, 4] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[3, 2, 5] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[3, 3, 0] = {{-1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[3, 4, 1] = {{-1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[3, 5, 2] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[4, 0, 4] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[4, 1, 0] = {{(-1)^(3/8)}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[4, 1, 2] = {{-(-1)^(7/8)}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[4, 2, 4] = {{I}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[4, 3, 1] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[4, 4, 3] = {{(-1)^(3/8)}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[4, 4, 5] = {{-(-1)^(7/8)}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[4, 5, 1] = {{-I}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[5, 0, 5] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[5, 1, 4] = {{-I}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[5, 2, 3] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[5, 3, 2] = {{1}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[5, 4, 1] = {{I}}
 
fermionic5HalvesCat1Brd6RMatrixFunction[5, 5, 0] = {{1}}
balancedCategories[fermionic5HalvesCat1Brd7] ^= {fermionic5HalvesCat1Bal25, 
    fermionic5HalvesCat1Bal26, fermionic5HalvesCat1Bal27, 
    fermionic5HalvesCat1Bal28}
 
fermionic5HalvesCat1Brd7 /: balancedCategory[fermionic5HalvesCat1Brd7, 1] = 
    fermionic5HalvesCat1Bal25
 
fermionic5HalvesCat1Brd7 /: balancedCategory[fermionic5HalvesCat1Brd7, 2] = 
    fermionic5HalvesCat1Bal26
 
fermionic5HalvesCat1Brd7 /: balancedCategory[fermionic5HalvesCat1Brd7, 3] = 
    fermionic5HalvesCat1Bal27
 
fermionic5HalvesCat1Brd7 /: balancedCategory[fermionic5HalvesCat1Brd7, 4] = 
    fermionic5HalvesCat1Bal28
 
braidedCategory[fermionic5HalvesCat1Brd7] ^= fermionic5HalvesCat1Brd7
 
fusionCategory[fermionic5HalvesCat1Brd7] ^= fermionic5HalvesCat1
 
fermionic5HalvesCat1Brd7 /: modularCategory[fermionic5HalvesCat1Brd7, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
fermionic5HalvesCat1Brd7 /: ribbonCategory[fermionic5HalvesCat1Brd7, 1] = 
    fermionic5HalvesCat1Bal27
 
fermionic5HalvesCat1Brd7 /: ribbonCategory[fermionic5HalvesCat1Brd7, 2] = 
    fermionic5HalvesCat1Bal28
 
ring[fermionic5HalvesCat1Brd7] ^= fermionic5Halves
 
rMatrixFunction[fermionic5HalvesCat1Brd7] ^= 
   fermionic5HalvesCat1Brd7RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      braidedCategory[#1]] & )[fermionic5HalvesCat1Brd7] ^= 7
braidedCategory[fermionic5HalvesCat1Brd7RMatrixFunction] ^= 
   fermionic5HalvesCat1Brd7
 
fusionCategory[fermionic5HalvesCat1Brd7RMatrixFunction] ^= 
   fermionic5HalvesCat1
 
rMatrixFunction[fermionic5HalvesCat1Brd7RMatrixFunction] ^= 
   fermionic5HalvesCat1Brd7RMatrixFunction
 
fermionic5HalvesCat1Brd7RMatrixFunction[0, 0, 0] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[0, 1, 1] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[0, 2, 2] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[0, 3, 3] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[0, 4, 4] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[0, 5, 5] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[1, 0, 1] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[1, 1, 3] = {{-(-1)^(1/8)}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[1, 1, 5] = {{-(-1)^(5/8)}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[1, 2, 1] = {{-I}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[1, 3, 4] = {{-1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[1, 4, 0] = {{(-1)^(1/8)}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[1, 4, 2] = {{(-1)^(5/8)}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[1, 5, 4] = {{-I}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[2, 0, 2] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[2, 1, 1] = {{-I}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[2, 2, 0] = {{-1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[2, 3, 5] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[2, 4, 4] = {{-I}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[2, 5, 3] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[3, 0, 3] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[3, 1, 4] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[3, 2, 5] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[3, 3, 0] = {{-1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[3, 4, 1] = {{-1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[3, 5, 2] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[4, 0, 4] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[4, 1, 0] = {{-(-1)^(1/8)}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[4, 1, 2] = {{-(-1)^(5/8)}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[4, 2, 4] = {{-I}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[4, 3, 1] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[4, 4, 3] = {{-(-1)^(1/8)}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[4, 4, 5] = {{-(-1)^(5/8)}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[4, 5, 1] = {{I}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[5, 0, 5] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[5, 1, 4] = {{I}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[5, 2, 3] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[5, 3, 2] = {{1}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[5, 4, 1] = {{-I}}
 
fermionic5HalvesCat1Brd7RMatrixFunction[5, 5, 0] = {{1}}
balancedCategories[fermionic5HalvesCat1Brd8] ^= {fermionic5HalvesCat1Bal29, 
    fermionic5HalvesCat1Bal30, fermionic5HalvesCat1Bal31, 
    fermionic5HalvesCat1Bal32}
 
fermionic5HalvesCat1Brd8 /: balancedCategory[fermionic5HalvesCat1Brd8, 1] = 
    fermionic5HalvesCat1Bal29
 
fermionic5HalvesCat1Brd8 /: balancedCategory[fermionic5HalvesCat1Brd8, 2] = 
    fermionic5HalvesCat1Bal30
 
fermionic5HalvesCat1Brd8 /: balancedCategory[fermionic5HalvesCat1Brd8, 3] = 
    fermionic5HalvesCat1Bal31
 
fermionic5HalvesCat1Brd8 /: balancedCategory[fermionic5HalvesCat1Brd8, 4] = 
    fermionic5HalvesCat1Bal32
 
braidedCategory[fermionic5HalvesCat1Brd8] ^= fermionic5HalvesCat1Brd8
 
fusionCategory[fermionic5HalvesCat1Brd8] ^= fermionic5HalvesCat1
 
fermionic5HalvesCat1Brd8 /: modularCategory[fermionic5HalvesCat1Brd8, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
fermionic5HalvesCat1Brd8 /: ribbonCategory[fermionic5HalvesCat1Brd8, 1] = 
    fermionic5HalvesCat1Bal31
 
fermionic5HalvesCat1Brd8 /: ribbonCategory[fermionic5HalvesCat1Brd8, 2] = 
    fermionic5HalvesCat1Bal32
 
ring[fermionic5HalvesCat1Brd8] ^= fermionic5Halves
 
rMatrixFunction[fermionic5HalvesCat1Brd8] ^= 
   fermionic5HalvesCat1Brd8RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      braidedCategory[#1]] & )[fermionic5HalvesCat1Brd8] ^= 8
braidedCategory[fermionic5HalvesCat1Brd8RMatrixFunction] ^= 
   fermionic5HalvesCat1Brd8
 
fusionCategory[fermionic5HalvesCat1Brd8RMatrixFunction] ^= 
   fermionic5HalvesCat1
 
rMatrixFunction[fermionic5HalvesCat1Brd8RMatrixFunction] ^= 
   fermionic5HalvesCat1Brd8RMatrixFunction
 
fermionic5HalvesCat1Brd8RMatrixFunction[0, 0, 0] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[0, 1, 1] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[0, 2, 2] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[0, 3, 3] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[0, 4, 4] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[0, 5, 5] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[1, 0, 1] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[1, 1, 3] = {{(-1)^(1/8)}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[1, 1, 5] = {{(-1)^(5/8)}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[1, 2, 1] = {{-I}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[1, 3, 4] = {{-1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[1, 4, 0] = {{-(-1)^(1/8)}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[1, 4, 2] = {{-(-1)^(5/8)}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[1, 5, 4] = {{-I}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[2, 0, 2] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[2, 1, 1] = {{-I}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[2, 2, 0] = {{-1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[2, 3, 5] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[2, 4, 4] = {{-I}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[2, 5, 3] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[3, 0, 3] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[3, 1, 4] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[3, 2, 5] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[3, 3, 0] = {{-1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[3, 4, 1] = {{-1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[3, 5, 2] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[4, 0, 4] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[4, 1, 0] = {{(-1)^(1/8)}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[4, 1, 2] = {{(-1)^(5/8)}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[4, 2, 4] = {{-I}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[4, 3, 1] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[4, 4, 3] = {{(-1)^(1/8)}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[4, 4, 5] = {{(-1)^(5/8)}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[4, 5, 1] = {{I}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[5, 0, 5] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[5, 1, 4] = {{I}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[5, 2, 3] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[5, 3, 2] = {{1}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[5, 4, 1] = {{-I}}
 
fermionic5HalvesCat1Brd8RMatrixFunction[5, 5, 0] = {{1}}
fMatrixFunction[fermionic5HalvesCat1FMatrixFunction] ^= 
   fermionic5HalvesCat1FMatrixFunction
 
fusionCategory[fermionic5HalvesCat1FMatrixFunction] ^= fermionic5HalvesCat1
 
ring[fermionic5HalvesCat1FMatrixFunction] ^= fermionic5Halves
 
fermionic5HalvesCat1FMatrixFunction[1, 1, 1, 4] = 
   {{I/Sqrt[2], I/Sqrt[2]}, {(-I)/Sqrt[2], I/Sqrt[2]}}
 
fermionic5HalvesCat1FMatrixFunction[1, 1, 2, 5] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[1, 1, 4, 1] = 
   {{I/Sqrt[2], (-I)/Sqrt[2]}, {(-I)/Sqrt[2], (-I)/Sqrt[2]}}
 
fermionic5HalvesCat1FMatrixFunction[1, 2, 1, 5] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[1, 2, 2, 1] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[1, 2, 4, 2] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[1, 4, 1, 1] = 
   {{I/Sqrt[2], (-I)/Sqrt[2]}, {(-I)/Sqrt[2], (-I)/Sqrt[2]}}
 
fermionic5HalvesCat1FMatrixFunction[1, 4, 2, 2] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[1, 4, 4, 4] = 
   {{I/Sqrt[2], (-I)/Sqrt[2]}, {(-I)/Sqrt[2], (-I)/Sqrt[2]}}
 
fermionic5HalvesCat1FMatrixFunction[1, 5, 1, 0] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[1, 5, 2, 4] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[1, 5, 4, 5] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 1, 1, 3] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 1, 1, 5] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 1, 4, 2] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 1, 5, 4] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 2, 3, 3] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 2, 4, 4] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 2, 5, 5] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 3, 1, 4] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 3, 2, 3] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 3, 5, 0] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 4, 1, 2] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 4, 2, 4] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 4, 4, 3] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 4, 4, 5] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 4, 5, 1] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 5, 1, 4] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 5, 2, 5] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[2, 5, 3, 0] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[3, 1, 1, 0] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[3, 1, 4, 3] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[3, 1, 4, 5] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[3, 1, 5, 1] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[3, 2, 1, 4] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[3, 2, 3, 2] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[3, 2, 5, 0] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[3, 3, 2, 2] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[3, 3, 5, 5] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[3, 4, 1, 3] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[3, 4, 1, 5] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[3, 4, 4, 0] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[3, 4, 5, 4] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[3, 5, 2, 0] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[3, 5, 3, 5] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[3, 5, 4, 4] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[4, 1, 1, 1] = 
   {{(-I)/Sqrt[2], I/Sqrt[2]}, {(-I)/Sqrt[2], (-I)/Sqrt[2]}}
 
fermionic5HalvesCat1FMatrixFunction[4, 1, 2, 2] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[4, 1, 4, 4] = 
   {{(-I)/Sqrt[2], I/Sqrt[2]}, {I/Sqrt[2], I/Sqrt[2]}}
 
fermionic5HalvesCat1FMatrixFunction[4, 1, 5, 3] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[4, 1, 5, 5] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[4, 2, 1, 2] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[4, 2, 2, 4] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[4, 2, 3, 1] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[4, 2, 4, 5] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[4, 2, 5, 1] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[4, 3, 2, 1] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[4, 3, 5, 4] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[4, 4, 1, 4] = 
   {{(-I)/Sqrt[2], (-I)/Sqrt[2]}, {I/Sqrt[2], (-I)/Sqrt[2]}}
 
fermionic5HalvesCat1FMatrixFunction[4, 4, 2, 5] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[4, 4, 4, 1] = 
   {{(-I)/Sqrt[2], I/Sqrt[2]}, {(-I)/Sqrt[2], (-I)/Sqrt[2]}}
 
fermionic5HalvesCat1FMatrixFunction[4, 4, 5, 0] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[4, 4, 5, 2] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[4, 5, 1, 5] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[4, 5, 3, 4] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[4, 5, 4, 0] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[5, 1, 1, 2] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[5, 1, 2, 4] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[5, 1, 3, 1] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[5, 1, 4, 5] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[5, 1, 5, 1] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[5, 2, 4, 1] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[5, 3, 4, 4] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[5, 4, 1, 3] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[5, 4, 2, 1] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[5, 4, 3, 4] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[5, 4, 4, 0] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[5, 4, 5, 4] = {{-1}}
 
fermionic5HalvesCat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[fermionic5HalvesCat1], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
fermionic5HalvesCat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[fermionic5HalvesCat1], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[fermionic5HalvesCat1Piv1] ^= {fermionic5HalvesCat1Bal1, 
    fermionic5HalvesCat1Bal5, fermionic5HalvesCat1Bal9, 
    fermionic5HalvesCat1Bal13, fermionic5HalvesCat1Bal17, 
    fermionic5HalvesCat1Bal21, fermionic5HalvesCat1Bal25, 
    fermionic5HalvesCat1Bal29}
 
fermionic5HalvesCat1Piv1 /: balancedCategory[fermionic5HalvesCat1Piv1, 1] = 
    fermionic5HalvesCat1Bal1
 
fermionic5HalvesCat1Piv1 /: balancedCategory[fermionic5HalvesCat1Piv1, 2] = 
    fermionic5HalvesCat1Bal5
 
fermionic5HalvesCat1Piv1 /: balancedCategory[fermionic5HalvesCat1Piv1, 3] = 
    fermionic5HalvesCat1Bal9
 
fermionic5HalvesCat1Piv1 /: balancedCategory[fermionic5HalvesCat1Piv1, 4] = 
    fermionic5HalvesCat1Bal13
 
fermionic5HalvesCat1Piv1 /: balancedCategory[fermionic5HalvesCat1Piv1, 5] = 
    fermionic5HalvesCat1Bal17
 
fermionic5HalvesCat1Piv1 /: balancedCategory[fermionic5HalvesCat1Piv1, 6] = 
    fermionic5HalvesCat1Bal21
 
fermionic5HalvesCat1Piv1 /: balancedCategory[fermionic5HalvesCat1Piv1, 7] = 
    fermionic5HalvesCat1Bal25
 
fermionic5HalvesCat1Piv1 /: balancedCategory[fermionic5HalvesCat1Piv1, 8] = 
    fermionic5HalvesCat1Bal29
 
fusionCategory[fermionic5HalvesCat1Piv1] ^= fermionic5HalvesCat1
 
fermionic5HalvesCat1Piv1 /: modularCategory[fermionic5HalvesCat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[fermionic5HalvesCat1Piv1] ^= fermionic5HalvesCat1Piv1
 
pivotalIsomorphism[fermionic5HalvesCat1Piv1] ^= 
   fermionic5HalvesCat1Piv1PivotalIsomorphism
 
ring[fermionic5HalvesCat1Piv1] ^= fermionic5Halves
 
(pivotalCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      pivotalCategory[#1]] & )[fermionic5HalvesCat1Piv1] ^= 1
fusionCategory[fermionic5HalvesCat1Piv1PivotalIsomorphism] ^= 
   fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Piv1PivotalIsomorphism] ^= 
   fermionic5HalvesCat1Piv1
 
pivotalIsomorphism[fermionic5HalvesCat1Piv1PivotalIsomorphism] ^= 
   fermionic5HalvesCat1Piv1PivotalIsomorphism
 
fermionic5HalvesCat1Piv1PivotalIsomorphism[0] = 1
 
fermionic5HalvesCat1Piv1PivotalIsomorphism[1] = -1
 
fermionic5HalvesCat1Piv1PivotalIsomorphism[2] = 1
 
fermionic5HalvesCat1Piv1PivotalIsomorphism[3] = -1
 
fermionic5HalvesCat1Piv1PivotalIsomorphism[4] = -1
 
fermionic5HalvesCat1Piv1PivotalIsomorphism[5] = -1
balancedCategories[fermionic5HalvesCat1Piv2] ^= {fermionic5HalvesCat1Bal2, 
    fermionic5HalvesCat1Bal6, fermionic5HalvesCat1Bal10, 
    fermionic5HalvesCat1Bal14, fermionic5HalvesCat1Bal18, 
    fermionic5HalvesCat1Bal22, fermionic5HalvesCat1Bal26, 
    fermionic5HalvesCat1Bal30}
 
fermionic5HalvesCat1Piv2 /: balancedCategory[fermionic5HalvesCat1Piv2, 1] = 
    fermionic5HalvesCat1Bal2
 
fermionic5HalvesCat1Piv2 /: balancedCategory[fermionic5HalvesCat1Piv2, 2] = 
    fermionic5HalvesCat1Bal6
 
fermionic5HalvesCat1Piv2 /: balancedCategory[fermionic5HalvesCat1Piv2, 3] = 
    fermionic5HalvesCat1Bal10
 
fermionic5HalvesCat1Piv2 /: balancedCategory[fermionic5HalvesCat1Piv2, 4] = 
    fermionic5HalvesCat1Bal14
 
fermionic5HalvesCat1Piv2 /: balancedCategory[fermionic5HalvesCat1Piv2, 5] = 
    fermionic5HalvesCat1Bal18
 
fermionic5HalvesCat1Piv2 /: balancedCategory[fermionic5HalvesCat1Piv2, 6] = 
    fermionic5HalvesCat1Bal22
 
fermionic5HalvesCat1Piv2 /: balancedCategory[fermionic5HalvesCat1Piv2, 7] = 
    fermionic5HalvesCat1Bal26
 
fermionic5HalvesCat1Piv2 /: balancedCategory[fermionic5HalvesCat1Piv2, 8] = 
    fermionic5HalvesCat1Bal30
 
fusionCategory[fermionic5HalvesCat1Piv2] ^= fermionic5HalvesCat1
 
fermionic5HalvesCat1Piv2 /: modularCategory[fermionic5HalvesCat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[fermionic5HalvesCat1Piv2] ^= fermionic5HalvesCat1Piv2
 
pivotalIsomorphism[fermionic5HalvesCat1Piv2] ^= 
   fermionic5HalvesCat1Piv2PivotalIsomorphism
 
ring[fermionic5HalvesCat1Piv2] ^= fermionic5Halves
 
(pivotalCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      pivotalCategory[#1]] & )[fermionic5HalvesCat1Piv2] ^= 2
fusionCategory[fermionic5HalvesCat1Piv2PivotalIsomorphism] ^= 
   fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Piv2PivotalIsomorphism] ^= 
   fermionic5HalvesCat1Piv2
 
pivotalIsomorphism[fermionic5HalvesCat1Piv2PivotalIsomorphism] ^= 
   fermionic5HalvesCat1Piv2PivotalIsomorphism
 
fermionic5HalvesCat1Piv2PivotalIsomorphism[0] = 1
 
fermionic5HalvesCat1Piv2PivotalIsomorphism[1] = 1
 
fermionic5HalvesCat1Piv2PivotalIsomorphism[2] = 1
 
fermionic5HalvesCat1Piv2PivotalIsomorphism[3] = -1
 
fermionic5HalvesCat1Piv2PivotalIsomorphism[4] = 1
 
fermionic5HalvesCat1Piv2PivotalIsomorphism[5] = -1
balancedCategories[fermionic5HalvesCat1Piv3] ^= {fermionic5HalvesCat1Bal3, 
    fermionic5HalvesCat1Bal7, fermionic5HalvesCat1Bal11, 
    fermionic5HalvesCat1Bal15, fermionic5HalvesCat1Bal19, 
    fermionic5HalvesCat1Bal23, fermionic5HalvesCat1Bal27, 
    fermionic5HalvesCat1Bal31}
 
fermionic5HalvesCat1Piv3 /: balancedCategory[fermionic5HalvesCat1Piv3, 1] = 
    fermionic5HalvesCat1Bal3
 
fermionic5HalvesCat1Piv3 /: balancedCategory[fermionic5HalvesCat1Piv3, 2] = 
    fermionic5HalvesCat1Bal7
 
fermionic5HalvesCat1Piv3 /: balancedCategory[fermionic5HalvesCat1Piv3, 3] = 
    fermionic5HalvesCat1Bal11
 
fermionic5HalvesCat1Piv3 /: balancedCategory[fermionic5HalvesCat1Piv3, 4] = 
    fermionic5HalvesCat1Bal15
 
fermionic5HalvesCat1Piv3 /: balancedCategory[fermionic5HalvesCat1Piv3, 5] = 
    fermionic5HalvesCat1Bal19
 
fermionic5HalvesCat1Piv3 /: balancedCategory[fermionic5HalvesCat1Piv3, 6] = 
    fermionic5HalvesCat1Bal23
 
fermionic5HalvesCat1Piv3 /: balancedCategory[fermionic5HalvesCat1Piv3, 7] = 
    fermionic5HalvesCat1Bal27
 
fermionic5HalvesCat1Piv3 /: balancedCategory[fermionic5HalvesCat1Piv3, 8] = 
    fermionic5HalvesCat1Bal31
 
fusionCategory[fermionic5HalvesCat1Piv3] ^= fermionic5HalvesCat1
 
fermionic5HalvesCat1Piv3 /: modularCategory[fermionic5HalvesCat1Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[fermionic5HalvesCat1Piv3] ^= fermionic5HalvesCat1Piv3
 
pivotalIsomorphism[fermionic5HalvesCat1Piv3] ^= 
   fermionic5HalvesCat1Piv3PivotalIsomorphism
 
fermionic5HalvesCat1Piv3 /: ribbonCategory[fermionic5HalvesCat1Piv3, 1] = 
    fermionic5HalvesCat1Bal3
 
fermionic5HalvesCat1Piv3 /: ribbonCategory[fermionic5HalvesCat1Piv3, 2] = 
    fermionic5HalvesCat1Bal7
 
fermionic5HalvesCat1Piv3 /: ribbonCategory[fermionic5HalvesCat1Piv3, 3] = 
    fermionic5HalvesCat1Bal11
 
fermionic5HalvesCat1Piv3 /: ribbonCategory[fermionic5HalvesCat1Piv3, 4] = 
    fermionic5HalvesCat1Bal15
 
fermionic5HalvesCat1Piv3 /: ribbonCategory[fermionic5HalvesCat1Piv3, 5] = 
    fermionic5HalvesCat1Bal19
 
fermionic5HalvesCat1Piv3 /: ribbonCategory[fermionic5HalvesCat1Piv3, 6] = 
    fermionic5HalvesCat1Bal23
 
fermionic5HalvesCat1Piv3 /: ribbonCategory[fermionic5HalvesCat1Piv3, 7] = 
    fermionic5HalvesCat1Bal27
 
fermionic5HalvesCat1Piv3 /: ribbonCategory[fermionic5HalvesCat1Piv3, 8] = 
    fermionic5HalvesCat1Bal31
 
ring[fermionic5HalvesCat1Piv3] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat1Piv3] ^= fermionic5HalvesCat1Piv3
 
(pivotalCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      pivotalCategory[#1]] & )[fermionic5HalvesCat1Piv3] ^= 3
 
(sphericalCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      sphericalCategory[#1]] & )[fermionic5HalvesCat1Piv3] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[fermionic5HalvesCat1Piv3PivotalIsomorphism] ^= 
   fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Piv3PivotalIsomorphism] ^= 
   fermionic5HalvesCat1Piv3
 
pivotalIsomorphism[fermionic5HalvesCat1Piv3PivotalIsomorphism] ^= 
   fermionic5HalvesCat1Piv3PivotalIsomorphism
 
fermionic5HalvesCat1Piv3PivotalIsomorphism[0] = 1
 
fermionic5HalvesCat1Piv3PivotalIsomorphism[1] = I
 
fermionic5HalvesCat1Piv3PivotalIsomorphism[2] = 1
 
fermionic5HalvesCat1Piv3PivotalIsomorphism[3] = 1
 
fermionic5HalvesCat1Piv3PivotalIsomorphism[4] = -I
 
fermionic5HalvesCat1Piv3PivotalIsomorphism[5] = 1
balancedCategories[fermionic5HalvesCat1Piv4] ^= {fermionic5HalvesCat1Bal4, 
    fermionic5HalvesCat1Bal8, fermionic5HalvesCat1Bal12, 
    fermionic5HalvesCat1Bal16, fermionic5HalvesCat1Bal20, 
    fermionic5HalvesCat1Bal24, fermionic5HalvesCat1Bal28, 
    fermionic5HalvesCat1Bal32}
 
fermionic5HalvesCat1Piv4 /: balancedCategory[fermionic5HalvesCat1Piv4, 1] = 
    fermionic5HalvesCat1Bal4
 
fermionic5HalvesCat1Piv4 /: balancedCategory[fermionic5HalvesCat1Piv4, 2] = 
    fermionic5HalvesCat1Bal8
 
fermionic5HalvesCat1Piv4 /: balancedCategory[fermionic5HalvesCat1Piv4, 3] = 
    fermionic5HalvesCat1Bal12
 
fermionic5HalvesCat1Piv4 /: balancedCategory[fermionic5HalvesCat1Piv4, 4] = 
    fermionic5HalvesCat1Bal16
 
fermionic5HalvesCat1Piv4 /: balancedCategory[fermionic5HalvesCat1Piv4, 5] = 
    fermionic5HalvesCat1Bal20
 
fermionic5HalvesCat1Piv4 /: balancedCategory[fermionic5HalvesCat1Piv4, 6] = 
    fermionic5HalvesCat1Bal24
 
fermionic5HalvesCat1Piv4 /: balancedCategory[fermionic5HalvesCat1Piv4, 7] = 
    fermionic5HalvesCat1Bal28
 
fermionic5HalvesCat1Piv4 /: balancedCategory[fermionic5HalvesCat1Piv4, 8] = 
    fermionic5HalvesCat1Bal32
 
fusionCategory[fermionic5HalvesCat1Piv4] ^= fermionic5HalvesCat1
 
fermionic5HalvesCat1Piv4 /: modularCategory[fermionic5HalvesCat1Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[fermionic5HalvesCat1Piv4] ^= fermionic5HalvesCat1Piv4
 
pivotalIsomorphism[fermionic5HalvesCat1Piv4] ^= 
   fermionic5HalvesCat1Piv4PivotalIsomorphism
 
fermionic5HalvesCat1Piv4 /: ribbonCategory[fermionic5HalvesCat1Piv4, 1] = 
    fermionic5HalvesCat1Bal4
 
fermionic5HalvesCat1Piv4 /: ribbonCategory[fermionic5HalvesCat1Piv4, 2] = 
    fermionic5HalvesCat1Bal8
 
fermionic5HalvesCat1Piv4 /: ribbonCategory[fermionic5HalvesCat1Piv4, 3] = 
    fermionic5HalvesCat1Bal12
 
fermionic5HalvesCat1Piv4 /: ribbonCategory[fermionic5HalvesCat1Piv4, 4] = 
    fermionic5HalvesCat1Bal16
 
fermionic5HalvesCat1Piv4 /: ribbonCategory[fermionic5HalvesCat1Piv4, 5] = 
    fermionic5HalvesCat1Bal20
 
fermionic5HalvesCat1Piv4 /: ribbonCategory[fermionic5HalvesCat1Piv4, 6] = 
    fermionic5HalvesCat1Bal24
 
fermionic5HalvesCat1Piv4 /: ribbonCategory[fermionic5HalvesCat1Piv4, 7] = 
    fermionic5HalvesCat1Bal28
 
fermionic5HalvesCat1Piv4 /: ribbonCategory[fermionic5HalvesCat1Piv4, 8] = 
    fermionic5HalvesCat1Bal32
 
ring[fermionic5HalvesCat1Piv4] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat1Piv4] ^= fermionic5HalvesCat1Piv4
 
(pivotalCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      pivotalCategory[#1]] & )[fermionic5HalvesCat1Piv4] ^= 4
 
(sphericalCategoryIndex[fusionCategory[fermionic5HalvesCat1]][
      sphericalCategory[#1]] & )[fermionic5HalvesCat1Piv4] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[fermionic5HalvesCat1Piv4PivotalIsomorphism] ^= 
   fermionic5HalvesCat1
 
pivotalCategory[fermionic5HalvesCat1Piv4PivotalIsomorphism] ^= 
   fermionic5HalvesCat1Piv4
 
pivotalIsomorphism[fermionic5HalvesCat1Piv4PivotalIsomorphism] ^= 
   fermionic5HalvesCat1Piv4PivotalIsomorphism
 
fermionic5HalvesCat1Piv4PivotalIsomorphism[0] = 1
 
fermionic5HalvesCat1Piv4PivotalIsomorphism[1] = -I
 
fermionic5HalvesCat1Piv4PivotalIsomorphism[2] = 1
 
fermionic5HalvesCat1Piv4PivotalIsomorphism[3] = 1
 
fermionic5HalvesCat1Piv4PivotalIsomorphism[4] = I
 
fermionic5HalvesCat1Piv4PivotalIsomorphism[5] = 1
balancedCategories[fermionic5HalvesCat2] ^= {}
 
braidedCategories[fermionic5HalvesCat2] ^= {}
 
coeval[fermionic5HalvesCat2] ^= 
   1/sixJFunction[fermionic5HalvesCat2][#1, dual[ring[fermionic5HalvesCat2]][
       #1], #1, #1, 0, 0] & 
 
eval[fermionic5HalvesCat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[fermionic5HalvesCat2] ^= fermionic5HalvesCat2FMatrixFunction
 
fusionCategory[fermionic5HalvesCat2] ^= fermionic5HalvesCat2
 
fermionic5HalvesCat2 /: modularCategory[fermionic5HalvesCat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[fermionic5HalvesCat2] ^= {fermionic5HalvesCat2Piv1, 
    fermionic5HalvesCat2Piv2, fermionic5HalvesCat2Piv3, 
    fermionic5HalvesCat2Piv4}
 
fermionic5HalvesCat2 /: pivotalCategory[fermionic5HalvesCat2, 1] = 
    fermionic5HalvesCat2Piv1
 
fermionic5HalvesCat2 /: pivotalCategory[fermionic5HalvesCat2, 2] = 
    fermionic5HalvesCat2Piv2
 
fermionic5HalvesCat2 /: pivotalCategory[fermionic5HalvesCat2, 3] = 
    fermionic5HalvesCat2Piv3
 
fermionic5HalvesCat2 /: pivotalCategory[fermionic5HalvesCat2, 4] = 
    fermionic5HalvesCat2Piv4
 
fermionic5HalvesCat2 /: pivotalCategory[fermionic5HalvesCat2, 
     {1, -(-1)^(1/4), 1, -1, (-1)^(3/4), -1}] = fermionic5HalvesCat2Piv4
 
fermionic5HalvesCat2 /: pivotalCategory[fermionic5HalvesCat2, 
     {1, (-1)^(1/4), 1, -1, -(-1)^(3/4), -1}] = fermionic5HalvesCat2Piv3
 
fermionic5HalvesCat2 /: pivotalCategory[fermionic5HalvesCat2, 
     {1, -(-1)^(3/4), 1, 1, (-1)^(1/4), 1}] = fermionic5HalvesCat2Piv2
 
fermionic5HalvesCat2 /: pivotalCategory[fermionic5HalvesCat2, 
     {1, (-1)^(3/4), 1, 1, -(-1)^(1/4), 1}] = fermionic5HalvesCat2Piv1
 
ring[fermionic5HalvesCat2] ^= fermionic5Halves
 
fermionic5HalvesCat2 /: sphericalCategory[fermionic5HalvesCat2, 1] = 
    fermionic5HalvesCat2Piv3
 
fermionic5HalvesCat2 /: sphericalCategory[fermionic5HalvesCat2, 2] = 
    fermionic5HalvesCat2Piv4
 
fusionCategoryIndex[fermionic5Halves][fermionic5HalvesCat2] ^= 2
fMatrixFunction[fermionic5HalvesCat2FMatrixFunction] ^= 
   fermionic5HalvesCat2FMatrixFunction
 
fusionCategory[fermionic5HalvesCat2FMatrixFunction] ^= fermionic5HalvesCat2
 
ring[fermionic5HalvesCat2FMatrixFunction] ^= fermionic5Halves
 
fermionic5HalvesCat2FMatrixFunction[1, 1, 1, 4] = 
   {{1/2 - I/2, 1/2 - I/2}, {-1/2 + I/2, 1/2 - I/2}}
 
fermionic5HalvesCat2FMatrixFunction[1, 1, 2, 5] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[1, 1, 4, 1] = 
   {{1/2 - I/2, -1/2 + I/2}, {-1/2 + I/2, -1/2 + I/2}}
 
fermionic5HalvesCat2FMatrixFunction[1, 2, 1, 5] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[1, 2, 2, 1] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[1, 2, 4, 2] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[1, 4, 1, 1] = 
   {{-1/2 + I/2, 1/2 - I/2}, {1/2 - I/2, 1/2 - I/2}}
 
fermionic5HalvesCat2FMatrixFunction[1, 4, 2, 2] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[1, 4, 3, 3] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[1, 4, 3, 5] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[1, 4, 4, 4] = 
   {{1/2 - I/2, -1/2 + I/2}, {-1/2 + I/2, -1/2 + I/2}}
 
fermionic5HalvesCat2FMatrixFunction[1, 4, 5, 3] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[1, 4, 5, 5] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[1, 5, 1, 0] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[1, 5, 2, 4] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[1, 5, 4, 5] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 1, 1, 3] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 1, 1, 5] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 1, 4, 2] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 1, 5, 4] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 2, 3, 3] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 2, 4, 4] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 2, 5, 5] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 3, 1, 4] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 3, 2, 3] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 3, 5, 0] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 4, 1, 2] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 4, 2, 4] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 4, 4, 3] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 4, 4, 5] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 4, 5, 1] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 5, 1, 4] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 5, 2, 5] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[2, 5, 3, 0] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[3, 1, 1, 0] = {{-I}}
 
fermionic5HalvesCat2FMatrixFunction[3, 1, 1, 2] = {{I}}
 
fermionic5HalvesCat2FMatrixFunction[3, 1, 4, 3] = {{-I}}
 
fermionic5HalvesCat2FMatrixFunction[3, 1, 4, 5] = {{-I}}
 
fermionic5HalvesCat2FMatrixFunction[3, 1, 5, 1] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[3, 2, 1, 4] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[3, 2, 3, 2] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[3, 2, 5, 0] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[3, 3, 1, 1] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[3, 3, 2, 2] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[3, 3, 3, 3] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[3, 4, 1, 3] = {{I}}
 
fermionic5HalvesCat2FMatrixFunction[3, 4, 1, 5] = {{I}}
 
fermionic5HalvesCat2FMatrixFunction[3, 4, 3, 4] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[3, 4, 4, 0] = {{-I}}
 
fermionic5HalvesCat2FMatrixFunction[3, 4, 4, 2] = {{I}}
 
fermionic5HalvesCat2FMatrixFunction[3, 5, 1, 1] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[3, 5, 2, 0] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[3, 5, 4, 4] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[3, 5, 5, 3] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[4, 1, 1, 1] = 
   {{1/2 + I/2, -1/2 - I/2}, {1/2 + I/2, 1/2 + I/2}}
 
fermionic5HalvesCat2FMatrixFunction[4, 1, 2, 2] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[4, 1, 3, 3] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[4, 1, 3, 5] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[4, 1, 4, 4] = 
   {{-1/2 - I/2, 1/2 + I/2}, {1/2 + I/2, 1/2 + I/2}}
 
fermionic5HalvesCat2FMatrixFunction[4, 2, 1, 2] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[4, 2, 2, 4] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[4, 2, 3, 1] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[4, 2, 4, 5] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[4, 2, 5, 1] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[4, 3, 1, 3] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[4, 3, 1, 5] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[4, 3, 2, 1] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[4, 3, 3, 4] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[4, 4, 1, 4] = 
   {{1/2 + I/2, 1/2 + I/2}, {-1/2 - I/2, 1/2 + I/2}}
 
fermionic5HalvesCat2FMatrixFunction[4, 4, 2, 5] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[4, 4, 3, 0] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[4, 4, 3, 2] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[4, 4, 4, 1] = 
   {{-1/2 - I/2, 1/2 + I/2}, {-1/2 - I/2, -1/2 - I/2}}
 
fermionic5HalvesCat2FMatrixFunction[4, 5, 1, 3] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[4, 5, 4, 0] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[4, 5, 5, 4] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[5, 1, 1, 0] = {{I}}
 
fermionic5HalvesCat2FMatrixFunction[5, 1, 1, 2] = {{-I}}
 
fermionic5HalvesCat2FMatrixFunction[5, 1, 2, 4] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[5, 1, 3, 1] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[5, 1, 4, 3] = {{I}}
 
fermionic5HalvesCat2FMatrixFunction[5, 1, 4, 5] = {{-I}}
 
fermionic5HalvesCat2FMatrixFunction[5, 1, 5, 1] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[5, 2, 4, 1] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[5, 3, 1, 1] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[5, 3, 3, 5] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[5, 3, 4, 4] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[5, 3, 5, 3] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[5, 4, 1, 3] = {{I}}
 
fermionic5HalvesCat2FMatrixFunction[5, 4, 1, 5] = {{-I}}
 
fermionic5HalvesCat2FMatrixFunction[5, 4, 2, 1] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[5, 4, 4, 0] = {{-I}}
 
fermionic5HalvesCat2FMatrixFunction[5, 4, 4, 2] = {{I}}
 
fermionic5HalvesCat2FMatrixFunction[5, 5, 1, 1] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[5, 5, 3, 3] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[5, 5, 5, 5] = {{-1}}
 
fermionic5HalvesCat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[fermionic5HalvesCat2], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
fermionic5HalvesCat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[fermionic5HalvesCat2], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[fermionic5HalvesCat2Piv1] ^= {}
 
fusionCategory[fermionic5HalvesCat2Piv1] ^= fermionic5HalvesCat2
 
fermionic5HalvesCat2Piv1 /: modularCategory[fermionic5HalvesCat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[fermionic5HalvesCat2Piv1] ^= fermionic5HalvesCat2Piv1
 
pivotalIsomorphism[fermionic5HalvesCat2Piv1] ^= 
   fermionic5HalvesCat2Piv1PivotalIsomorphism
 
ring[fermionic5HalvesCat2Piv1] ^= fermionic5Halves
 
(pivotalCategoryIndex[fusionCategory[fermionic5HalvesCat2]][
      pivotalCategory[#1]] & )[fermionic5HalvesCat2Piv1] ^= 1
fusionCategory[fermionic5HalvesCat2Piv1PivotalIsomorphism] ^= 
   fermionic5HalvesCat2
 
pivotalCategory[fermionic5HalvesCat2Piv1PivotalIsomorphism] ^= 
   fermionic5HalvesCat2Piv1
 
pivotalIsomorphism[fermionic5HalvesCat2Piv1PivotalIsomorphism] ^= 
   fermionic5HalvesCat2Piv1PivotalIsomorphism
 
fermionic5HalvesCat2Piv1PivotalIsomorphism[0] = 1
 
fermionic5HalvesCat2Piv1PivotalIsomorphism[1] = (-1)^(3/4)
 
fermionic5HalvesCat2Piv1PivotalIsomorphism[2] = 1
 
fermionic5HalvesCat2Piv1PivotalIsomorphism[3] = 1
 
fermionic5HalvesCat2Piv1PivotalIsomorphism[4] = -(-1)^(1/4)
 
fermionic5HalvesCat2Piv1PivotalIsomorphism[5] = 1
balancedCategories[fermionic5HalvesCat2Piv2] ^= {}
 
fusionCategory[fermionic5HalvesCat2Piv2] ^= fermionic5HalvesCat2
 
fermionic5HalvesCat2Piv2 /: modularCategory[fermionic5HalvesCat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[fermionic5HalvesCat2Piv2] ^= fermionic5HalvesCat2Piv2
 
pivotalIsomorphism[fermionic5HalvesCat2Piv2] ^= 
   fermionic5HalvesCat2Piv2PivotalIsomorphism
 
ring[fermionic5HalvesCat2Piv2] ^= fermionic5Halves
 
(pivotalCategoryIndex[fusionCategory[fermionic5HalvesCat2]][
      pivotalCategory[#1]] & )[fermionic5HalvesCat2Piv2] ^= 2
fusionCategory[fermionic5HalvesCat2Piv2PivotalIsomorphism] ^= 
   fermionic5HalvesCat2
 
pivotalCategory[fermionic5HalvesCat2Piv2PivotalIsomorphism] ^= 
   fermionic5HalvesCat2Piv2
 
pivotalIsomorphism[fermionic5HalvesCat2Piv2PivotalIsomorphism] ^= 
   fermionic5HalvesCat2Piv2PivotalIsomorphism
 
fermionic5HalvesCat2Piv2PivotalIsomorphism[0] = 1
 
fermionic5HalvesCat2Piv2PivotalIsomorphism[1] = -(-1)^(3/4)
 
fermionic5HalvesCat2Piv2PivotalIsomorphism[2] = 1
 
fermionic5HalvesCat2Piv2PivotalIsomorphism[3] = 1
 
fermionic5HalvesCat2Piv2PivotalIsomorphism[4] = (-1)^(1/4)
 
fermionic5HalvesCat2Piv2PivotalIsomorphism[5] = 1
balancedCategories[fermionic5HalvesCat2Piv3] ^= {}
 
fusionCategory[fermionic5HalvesCat2Piv3] ^= fermionic5HalvesCat2
 
fermionic5HalvesCat2Piv3 /: modularCategory[fermionic5HalvesCat2Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[fermionic5HalvesCat2Piv3] ^= fermionic5HalvesCat2Piv3
 
pivotalIsomorphism[fermionic5HalvesCat2Piv3] ^= 
   fermionic5HalvesCat2Piv3PivotalIsomorphism
 
ring[fermionic5HalvesCat2Piv3] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat2Piv3] ^= fermionic5HalvesCat2Piv3
 
(pivotalCategoryIndex[fusionCategory[fermionic5HalvesCat2]][
      pivotalCategory[#1]] & )[fermionic5HalvesCat2Piv3] ^= 3
 
(sphericalCategoryIndex[fusionCategory[fermionic5HalvesCat2]][
      sphericalCategory[#1]] & )[fermionic5HalvesCat2Piv3] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[fermionic5HalvesCat2Piv3PivotalIsomorphism] ^= 
   fermionic5HalvesCat2
 
pivotalCategory[fermionic5HalvesCat2Piv3PivotalIsomorphism] ^= 
   fermionic5HalvesCat2Piv3
 
pivotalIsomorphism[fermionic5HalvesCat2Piv3PivotalIsomorphism] ^= 
   fermionic5HalvesCat2Piv3PivotalIsomorphism
 
fermionic5HalvesCat2Piv3PivotalIsomorphism[0] = 1
 
fermionic5HalvesCat2Piv3PivotalIsomorphism[1] = (-1)^(1/4)
 
fermionic5HalvesCat2Piv3PivotalIsomorphism[2] = 1
 
fermionic5HalvesCat2Piv3PivotalIsomorphism[3] = -1
 
fermionic5HalvesCat2Piv3PivotalIsomorphism[4] = -(-1)^(3/4)
 
fermionic5HalvesCat2Piv3PivotalIsomorphism[5] = -1
balancedCategories[fermionic5HalvesCat2Piv4] ^= {}
 
fusionCategory[fermionic5HalvesCat2Piv4] ^= fermionic5HalvesCat2
 
fermionic5HalvesCat2Piv4 /: modularCategory[fermionic5HalvesCat2Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[fermionic5HalvesCat2Piv4] ^= fermionic5HalvesCat2Piv4
 
pivotalIsomorphism[fermionic5HalvesCat2Piv4] ^= 
   fermionic5HalvesCat2Piv4PivotalIsomorphism
 
ring[fermionic5HalvesCat2Piv4] ^= fermionic5Halves
 
sphericalCategory[fermionic5HalvesCat2Piv4] ^= fermionic5HalvesCat2Piv4
 
(pivotalCategoryIndex[fusionCategory[fermionic5HalvesCat2]][
      pivotalCategory[#1]] & )[fermionic5HalvesCat2Piv4] ^= 4
 
(sphericalCategoryIndex[fusionCategory[fermionic5HalvesCat2]][
      sphericalCategory[#1]] & )[fermionic5HalvesCat2Piv4] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[fermionic5HalvesCat2Piv4PivotalIsomorphism] ^= 
   fermionic5HalvesCat2
 
pivotalCategory[fermionic5HalvesCat2Piv4PivotalIsomorphism] ^= 
   fermionic5HalvesCat2Piv4
 
pivotalIsomorphism[fermionic5HalvesCat2Piv4PivotalIsomorphism] ^= 
   fermionic5HalvesCat2Piv4PivotalIsomorphism
 
fermionic5HalvesCat2Piv4PivotalIsomorphism[0] = 1
 
fermionic5HalvesCat2Piv4PivotalIsomorphism[1] = -(-1)^(1/4)
 
fermionic5HalvesCat2Piv4PivotalIsomorphism[2] = 1
 
fermionic5HalvesCat2Piv4PivotalIsomorphism[3] = -1
 
fermionic5HalvesCat2Piv4PivotalIsomorphism[4] = (-1)^(3/4)
 
fermionic5HalvesCat2Piv4PivotalIsomorphism[5] = -1
ring[fermionic5HalvesNFunction] ^= fermionic5Halves
 
fermionic5HalvesNFunction[0, 0, 0] = 1
 
fermionic5HalvesNFunction[0, 0, 1] = 0
 
fermionic5HalvesNFunction[0, 0, 2] = 0
 
fermionic5HalvesNFunction[0, 0, 3] = 0
 
fermionic5HalvesNFunction[0, 0, 4] = 0
 
fermionic5HalvesNFunction[0, 0, 5] = 0
 
fermionic5HalvesNFunction[0, 1, 0] = 0
 
fermionic5HalvesNFunction[0, 1, 1] = 1
 
fermionic5HalvesNFunction[0, 1, 2] = 0
 
fermionic5HalvesNFunction[0, 1, 3] = 0
 
fermionic5HalvesNFunction[0, 1, 4] = 0
 
fermionic5HalvesNFunction[0, 1, 5] = 0
 
fermionic5HalvesNFunction[0, 2, 0] = 0
 
fermionic5HalvesNFunction[0, 2, 1] = 0
 
fermionic5HalvesNFunction[0, 2, 2] = 1
 
fermionic5HalvesNFunction[0, 2, 3] = 0
 
fermionic5HalvesNFunction[0, 2, 4] = 0
 
fermionic5HalvesNFunction[0, 2, 5] = 0
 
fermionic5HalvesNFunction[0, 3, 0] = 0
 
fermionic5HalvesNFunction[0, 3, 1] = 0
 
fermionic5HalvesNFunction[0, 3, 2] = 0
 
fermionic5HalvesNFunction[0, 3, 3] = 1
 
fermionic5HalvesNFunction[0, 3, 4] = 0
 
fermionic5HalvesNFunction[0, 3, 5] = 0
 
fermionic5HalvesNFunction[0, 4, 0] = 0
 
fermionic5HalvesNFunction[0, 4, 1] = 0
 
fermionic5HalvesNFunction[0, 4, 2] = 0
 
fermionic5HalvesNFunction[0, 4, 3] = 0
 
fermionic5HalvesNFunction[0, 4, 4] = 1
 
fermionic5HalvesNFunction[0, 4, 5] = 0
 
fermionic5HalvesNFunction[0, 5, 0] = 0
 
fermionic5HalvesNFunction[0, 5, 1] = 0
 
fermionic5HalvesNFunction[0, 5, 2] = 0
 
fermionic5HalvesNFunction[0, 5, 3] = 0
 
fermionic5HalvesNFunction[0, 5, 4] = 0
 
fermionic5HalvesNFunction[0, 5, 5] = 1
 
fermionic5HalvesNFunction[1, 0, 0] = 0
 
fermionic5HalvesNFunction[1, 0, 1] = 1
 
fermionic5HalvesNFunction[1, 0, 2] = 0
 
fermionic5HalvesNFunction[1, 0, 3] = 0
 
fermionic5HalvesNFunction[1, 0, 4] = 0
 
fermionic5HalvesNFunction[1, 0, 5] = 0
 
fermionic5HalvesNFunction[1, 1, 0] = 0
 
fermionic5HalvesNFunction[1, 1, 1] = 0
 
fermionic5HalvesNFunction[1, 1, 2] = 0
 
fermionic5HalvesNFunction[1, 1, 3] = 1
 
fermionic5HalvesNFunction[1, 1, 4] = 0
 
fermionic5HalvesNFunction[1, 1, 5] = 1
 
fermionic5HalvesNFunction[1, 2, 0] = 0
 
fermionic5HalvesNFunction[1, 2, 1] = 1
 
fermionic5HalvesNFunction[1, 2, 2] = 0
 
fermionic5HalvesNFunction[1, 2, 3] = 0
 
fermionic5HalvesNFunction[1, 2, 4] = 0
 
fermionic5HalvesNFunction[1, 2, 5] = 0
 
fermionic5HalvesNFunction[1, 3, 0] = 0
 
fermionic5HalvesNFunction[1, 3, 1] = 0
 
fermionic5HalvesNFunction[1, 3, 2] = 0
 
fermionic5HalvesNFunction[1, 3, 3] = 0
 
fermionic5HalvesNFunction[1, 3, 4] = 1
 
fermionic5HalvesNFunction[1, 3, 5] = 0
 
fermionic5HalvesNFunction[1, 4, 0] = 1
 
fermionic5HalvesNFunction[1, 4, 1] = 0
 
fermionic5HalvesNFunction[1, 4, 2] = 1
 
fermionic5HalvesNFunction[1, 4, 3] = 0
 
fermionic5HalvesNFunction[1, 4, 4] = 0
 
fermionic5HalvesNFunction[1, 4, 5] = 0
 
fermionic5HalvesNFunction[1, 5, 0] = 0
 
fermionic5HalvesNFunction[1, 5, 1] = 0
 
fermionic5HalvesNFunction[1, 5, 2] = 0
 
fermionic5HalvesNFunction[1, 5, 3] = 0
 
fermionic5HalvesNFunction[1, 5, 4] = 1
 
fermionic5HalvesNFunction[1, 5, 5] = 0
 
fermionic5HalvesNFunction[2, 0, 0] = 0
 
fermionic5HalvesNFunction[2, 0, 1] = 0
 
fermionic5HalvesNFunction[2, 0, 2] = 1
 
fermionic5HalvesNFunction[2, 0, 3] = 0
 
fermionic5HalvesNFunction[2, 0, 4] = 0
 
fermionic5HalvesNFunction[2, 0, 5] = 0
 
fermionic5HalvesNFunction[2, 1, 0] = 0
 
fermionic5HalvesNFunction[2, 1, 1] = 1
 
fermionic5HalvesNFunction[2, 1, 2] = 0
 
fermionic5HalvesNFunction[2, 1, 3] = 0
 
fermionic5HalvesNFunction[2, 1, 4] = 0
 
fermionic5HalvesNFunction[2, 1, 5] = 0
 
fermionic5HalvesNFunction[2, 2, 0] = 1
 
fermionic5HalvesNFunction[2, 2, 1] = 0
 
fermionic5HalvesNFunction[2, 2, 2] = 0
 
fermionic5HalvesNFunction[2, 2, 3] = 0
 
fermionic5HalvesNFunction[2, 2, 4] = 0
 
fermionic5HalvesNFunction[2, 2, 5] = 0
 
fermionic5HalvesNFunction[2, 3, 0] = 0
 
fermionic5HalvesNFunction[2, 3, 1] = 0
 
fermionic5HalvesNFunction[2, 3, 2] = 0
 
fermionic5HalvesNFunction[2, 3, 3] = 0
 
fermionic5HalvesNFunction[2, 3, 4] = 0
 
fermionic5HalvesNFunction[2, 3, 5] = 1
 
fermionic5HalvesNFunction[2, 4, 0] = 0
 
fermionic5HalvesNFunction[2, 4, 1] = 0
 
fermionic5HalvesNFunction[2, 4, 2] = 0
 
fermionic5HalvesNFunction[2, 4, 3] = 0
 
fermionic5HalvesNFunction[2, 4, 4] = 1
 
fermionic5HalvesNFunction[2, 4, 5] = 0
 
fermionic5HalvesNFunction[2, 5, 0] = 0
 
fermionic5HalvesNFunction[2, 5, 1] = 0
 
fermionic5HalvesNFunction[2, 5, 2] = 0
 
fermionic5HalvesNFunction[2, 5, 3] = 1
 
fermionic5HalvesNFunction[2, 5, 4] = 0
 
fermionic5HalvesNFunction[2, 5, 5] = 0
 
fermionic5HalvesNFunction[3, 0, 0] = 0
 
fermionic5HalvesNFunction[3, 0, 1] = 0
 
fermionic5HalvesNFunction[3, 0, 2] = 0
 
fermionic5HalvesNFunction[3, 0, 3] = 1
 
fermionic5HalvesNFunction[3, 0, 4] = 0
 
fermionic5HalvesNFunction[3, 0, 5] = 0
 
fermionic5HalvesNFunction[3, 1, 0] = 0
 
fermionic5HalvesNFunction[3, 1, 1] = 0
 
fermionic5HalvesNFunction[3, 1, 2] = 0
 
fermionic5HalvesNFunction[3, 1, 3] = 0
 
fermionic5HalvesNFunction[3, 1, 4] = 1
 
fermionic5HalvesNFunction[3, 1, 5] = 0
 
fermionic5HalvesNFunction[3, 2, 0] = 0
 
fermionic5HalvesNFunction[3, 2, 1] = 0
 
fermionic5HalvesNFunction[3, 2, 2] = 0
 
fermionic5HalvesNFunction[3, 2, 3] = 0
 
fermionic5HalvesNFunction[3, 2, 4] = 0
 
fermionic5HalvesNFunction[3, 2, 5] = 1
 
fermionic5HalvesNFunction[3, 3, 0] = 1
 
fermionic5HalvesNFunction[3, 3, 1] = 0
 
fermionic5HalvesNFunction[3, 3, 2] = 0
 
fermionic5HalvesNFunction[3, 3, 3] = 0
 
fermionic5HalvesNFunction[3, 3, 4] = 0
 
fermionic5HalvesNFunction[3, 3, 5] = 0
 
fermionic5HalvesNFunction[3, 4, 0] = 0
 
fermionic5HalvesNFunction[3, 4, 1] = 1
 
fermionic5HalvesNFunction[3, 4, 2] = 0
 
fermionic5HalvesNFunction[3, 4, 3] = 0
 
fermionic5HalvesNFunction[3, 4, 4] = 0
 
fermionic5HalvesNFunction[3, 4, 5] = 0
 
fermionic5HalvesNFunction[3, 5, 0] = 0
 
fermionic5HalvesNFunction[3, 5, 1] = 0
 
fermionic5HalvesNFunction[3, 5, 2] = 1
 
fermionic5HalvesNFunction[3, 5, 3] = 0
 
fermionic5HalvesNFunction[3, 5, 4] = 0
 
fermionic5HalvesNFunction[3, 5, 5] = 0
 
fermionic5HalvesNFunction[4, 0, 0] = 0
 
fermionic5HalvesNFunction[4, 0, 1] = 0
 
fermionic5HalvesNFunction[4, 0, 2] = 0
 
fermionic5HalvesNFunction[4, 0, 3] = 0
 
fermionic5HalvesNFunction[4, 0, 4] = 1
 
fermionic5HalvesNFunction[4, 0, 5] = 0
 
fermionic5HalvesNFunction[4, 1, 0] = 1
 
fermionic5HalvesNFunction[4, 1, 1] = 0
 
fermionic5HalvesNFunction[4, 1, 2] = 1
 
fermionic5HalvesNFunction[4, 1, 3] = 0
 
fermionic5HalvesNFunction[4, 1, 4] = 0
 
fermionic5HalvesNFunction[4, 1, 5] = 0
 
fermionic5HalvesNFunction[4, 2, 0] = 0
 
fermionic5HalvesNFunction[4, 2, 1] = 0
 
fermionic5HalvesNFunction[4, 2, 2] = 0
 
fermionic5HalvesNFunction[4, 2, 3] = 0
 
fermionic5HalvesNFunction[4, 2, 4] = 1
 
fermionic5HalvesNFunction[4, 2, 5] = 0
 
fermionic5HalvesNFunction[4, 3, 0] = 0
 
fermionic5HalvesNFunction[4, 3, 1] = 1
 
fermionic5HalvesNFunction[4, 3, 2] = 0
 
fermionic5HalvesNFunction[4, 3, 3] = 0
 
fermionic5HalvesNFunction[4, 3, 4] = 0
 
fermionic5HalvesNFunction[4, 3, 5] = 0
 
fermionic5HalvesNFunction[4, 4, 0] = 0
 
fermionic5HalvesNFunction[4, 4, 1] = 0
 
fermionic5HalvesNFunction[4, 4, 2] = 0
 
fermionic5HalvesNFunction[4, 4, 3] = 1
 
fermionic5HalvesNFunction[4, 4, 4] = 0
 
fermionic5HalvesNFunction[4, 4, 5] = 1
 
fermionic5HalvesNFunction[4, 5, 0] = 0
 
fermionic5HalvesNFunction[4, 5, 1] = 1
 
fermionic5HalvesNFunction[4, 5, 2] = 0
 
fermionic5HalvesNFunction[4, 5, 3] = 0
 
fermionic5HalvesNFunction[4, 5, 4] = 0
 
fermionic5HalvesNFunction[4, 5, 5] = 0
 
fermionic5HalvesNFunction[5, 0, 0] = 0
 
fermionic5HalvesNFunction[5, 0, 1] = 0
 
fermionic5HalvesNFunction[5, 0, 2] = 0
 
fermionic5HalvesNFunction[5, 0, 3] = 0
 
fermionic5HalvesNFunction[5, 0, 4] = 0
 
fermionic5HalvesNFunction[5, 0, 5] = 1
 
fermionic5HalvesNFunction[5, 1, 0] = 0
 
fermionic5HalvesNFunction[5, 1, 1] = 0
 
fermionic5HalvesNFunction[5, 1, 2] = 0
 
fermionic5HalvesNFunction[5, 1, 3] = 0
 
fermionic5HalvesNFunction[5, 1, 4] = 1
 
fermionic5HalvesNFunction[5, 1, 5] = 0
 
fermionic5HalvesNFunction[5, 2, 0] = 0
 
fermionic5HalvesNFunction[5, 2, 1] = 0
 
fermionic5HalvesNFunction[5, 2, 2] = 0
 
fermionic5HalvesNFunction[5, 2, 3] = 1
 
fermionic5HalvesNFunction[5, 2, 4] = 0
 
fermionic5HalvesNFunction[5, 2, 5] = 0
 
fermionic5HalvesNFunction[5, 3, 0] = 0
 
fermionic5HalvesNFunction[5, 3, 1] = 0
 
fermionic5HalvesNFunction[5, 3, 2] = 1
 
fermionic5HalvesNFunction[5, 3, 3] = 0
 
fermionic5HalvesNFunction[5, 3, 4] = 0
 
fermionic5HalvesNFunction[5, 3, 5] = 0
 
fermionic5HalvesNFunction[5, 4, 0] = 0
 
fermionic5HalvesNFunction[5, 4, 1] = 1
 
fermionic5HalvesNFunction[5, 4, 2] = 0
 
fermionic5HalvesNFunction[5, 4, 3] = 0
 
fermionic5HalvesNFunction[5, 4, 4] = 0
 
fermionic5HalvesNFunction[5, 4, 5] = 0
 
fermionic5HalvesNFunction[5, 5, 0] = 1
 
fermionic5HalvesNFunction[5, 5, 1] = 0
 
fermionic5HalvesNFunction[5, 5, 2] = 0
 
fermionic5HalvesNFunction[5, 5, 3] = 0
 
fermionic5HalvesNFunction[5, 5, 4] = 0
 
fermionic5HalvesNFunction[5, 5, 5] = 0
 
fermionic5HalvesNFunction[FusionCategories`Data`fermionic5Halves`Private`a_, FusionCategories`Data`fermionic5Halves`Private`b_, FusionCategories`Data`fermionic5Halves`Private`c_] := 0


 EndPackage[]
