BeginPackage["FusionCategories`Data`soOddLevel2Odd`", {"FusionCategories`","FusionCategories`PivotalCategories`", "FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}]

(* Grothendieck Ring Information *)

ring[soOddLevel2[p_Integer]] ^:= soOddLevel2[p]

rank[soOddLevel2[p_Integer]] ^:= p + 4

noMultiplicities[soOddLevel2[p_Integer]] ^:= True

nFunction[soOddLevel2[p_Integer]] ^:= gRing[p]

(* Fusion Category Information *)

fusionCategories[soOddLevel2[p_Integer]] := Join[Table[soOddLevel2Cat[p,r,1],{r, roots[p]}],Table[soOddLevel2Cat[p,r,-1],{r,roots[p]}]]

fusionCategory[soOddLevel2Cat[p_Integer, r_Integer, k_Integer]]/;( MemberQ[roots[p], r] && ( k==1 || k==-1 )) ^:= soOddLevel2Cat[p,r,k]

fusionCategory[soOddLevel2[p_Integer], i_Integer]/;(1<= i <= Length[fusionCategories[soOddLevel2[p]]]) := fusionCategories[soOddLevel2[p]][[i]]

fMatrixFunction[soOddLevel2Cat[p_Integer, r_Integer, k_Integer]]/;( MemberQ[roots[p], r] && ( k==1 || k==-1 )) ^:= fMat[p,r,k]

eval[soOddLevel2Cat[p_Integer, r_Integer, k_Integer]]^=FusionCategories`Private`defaultGaugeEval

coeval[soOddLevel2Cat[p_Integer, r_Integer, k_Integer]] ^:= 1/sixJFunction[soOddLevel2Cat[p,r,k]][#1, #1, #1, #1, 0, 0] &

(* Generic functions for soOddLevel2 stuff *)

Begin["`Private`"]

roots[p_] := Select[Range[2 p + 1], OddQ[#] && GCD[#, 2 p + 1] == 1 &]

(* Grothendieck ring stuff *)
zp[p_Integer, a_Integer] :=  Select[Range[-p, p], Mod[a, 2 p + 1] == Mod[#, 2 p + 1] &][[1]]

g[p_Integer, a_Integer] := Abs[zp[p, a]]

gTab[p_Integer, a_Integer, b_Integer] :=  If[a == b, {g[p, a + a]}, {g[p, a - b], g[p, a + b]}]
gTab[p_Integer] := Table[gTab[p, a, b], {a, Range[p]}, {b, Range[p]}]

pointedQ[x_] := ((x == 0) || (x == 1))
spinorQ[x_] := ((x == 2) || (x == 3))
vectorQ[p_, x_] := ((x > 3) && x < p + 4

gRing[p_Integer] := gRing[p, #1, #2, #3] &
gRing[p_Integer, {a_, b_, c_}] := gRing[p, a, b, c]
gRing[p_Integer, a_, b_, c_] := 0
gRing[p_Integer, a_, b_, c_] /; ((a == 0 && b == c) || (b == 0 && a == c) || (c == 0 && a == b)) := 1
gRing[p_Integer, 1, b_?spinorQ, c_?spinorQ] := Abs[KroneckerDelta[b, c] - 1]
gRing[p_Integer, 1, b_, c_] /; (vectorQ[p, b] && vectorQ[p, c]) :=  KroneckerDelta[b, c]
gRing[p_Integer, a_?(! pointedQ[#] &), 1, c_?(! pointedQ[#] &)] :=  gRing[p, 1, a, c]
gRing[p_Integer, a_?(! pointedQ[#] &), b_?(! pointedQ[#] &), 1] :=  gRing[p, 1, a, b]
gRing[p_Integer, a_?spinorQ, b_?spinorQ, c_] /; vectorQ[p, c] := 1
gRing[p_Integer, a_?spinorQ, b_, c_?spinorQ] /; vectorQ[p, b] := 1
gRing[p_Integer, a_, b_?spinorQ, c_?spinorQ] /; vectorQ[p, a] := 1
gRing[p_Integer, a_, b_, c_] /; (vectorQ[p, a] && vectorQ[p, b] && vectorQ[p, c]) :=  Module[{a0 = a - 3, b0 = b - 3, c0 = c - 3},  If[KroneckerDelta[g[p, a0 + b0], c0] == 1, KroneckerDelta[g[p, a0 + b0], c0], KroneckerDelta[g[p, a0 - b0], c0]]]


(* Fusion Category stuff *)
q[p_Integer] := Exp[(\[Pi] I)/(2 p + 1)]

realQ[x_] := Element[x, Reals]

parameterCondition[w_, x_, y_, z_] := (realQ[w] && realQ[x] && realQ[y] && realQ[z] && (Abs[w] == 1) && (Abs[x] == 1) && (Abs[y] == 1) && (Abs[z] == 1) && (w x y z == -1))

zeta[0, 0] := 0
zeta[0, j_?(# > 0 &)] := 1/2
zeta[i_?(# > 0 &), 0] := 1/2
zeta[i_?(# > 0 &), j_?(# > 0 &)] := 1

vec[x_] := x - 3

(* General Matrices *)


(* Patterns *)

(* epsilon-vector-vector-vector *)
evvv[p_, {a_, b_, c_, d_}] := If[a == 1, evvv[p, b, c, d], Transpose[evvv[p, Permute[{a, b, c, d}, Cycles[{{1, 2, 3, 4}}]]]]]
evvv[p_, b_, c_, d_] /; (c <= b) := {{(-1)^Mod[vec[c], 2]}}
evvv[p_, b_, c_, d_] /; (c > b && d == (g[p, b + c - 6] + 3)) := {{(-1)^Mod[vec[c], 2]}}
evvv[p_, b_, c_, d_] /; (c > b && d == (g[p, b - c] + 3)) := {{(-1)^Mod[vec[c] - 1, 2]}}

(* epsilon-spinor-spinor-vector *)
essv[p_, {a_, b_, c_, d_}] := If[a == 1, essv[p, a, b, c, d], Transpose[essv[p, Permute[{a, b, c, d}, Cycles[{{1, 2, 3, 4}}]]]]]
essv[p_, a_, b_, c_, d_] := {{1}}
essv[p_, a_, b_?spinorQ, c_, d_?spinorQ] /; (b != d) := {{-1}}

(* vector-vector-vector-vector *)
vvvv[p_, {a_, b_, c_, d_}] := vvvv[p, a, b, c, d]
vvvv[p_, a_, b_, c_, d_] := {{1}}
vvvv[p_, a_, b_, c_, d_] /; (a == b && a == c && a == d) := CMatrix
vvvv[p_, a_, b_, c_, d_] /; (a == c && b == d && a != b) := BMatrix
vvvv[p_, a_, b_, c_, d_] /; (((a == b && c == d) || (a == d && b == c)) && b != d) := AMatrix[1, 1, (-1)^Mod[vec[b] - vec[d] + 1, 2], (-1)^Mod[vec[b] - vec[d], 2]]

(* vector-vector-spinor-spinor *)
vvss[p_, r_, {a_, b_, c_, d_}] := If[vectorQ[p, a] && vectorQ[p, b], vvss[p, r, a, b, c, d], Transpose[vvss[p, r, Permute[{a, b, c, d}, Cycles[{{1, 2, 3, 4}}]]]]]
vvss[p_, r_, a_, b_, c_, d_] /; (a == b) := If[c == d, AMatrix[1, 1, 1, -1], AMatrix[-1, -1, (-1)^Mod[vec[a], 2], (-1)^Mod[vec[a] + 1, 2]]]
vvss[p_, r_, a_, b_, c_, d_] /; (a != b && c == d) := If[Mod[a - b, 2] == 0, AMatrix[(-1)^c, (-1)^c, 1, -1], AMatrix[1, -1, (-1)^c, (-1)^c]]
vvss[p_, r_, a_, b_, c_, d_] /; (a != b && c != d && vectorQ[p, b]) := (-1)^vec[a] If[a < b, AMatrix[(-1)^Mod[vec[a] - vec[b] + 1, 2], -1, (-1)^Mod[vec[a] - vec[b], 2], -1], AMatrix[(-1)^Mod[vec[a] - vec[b], 2], 1, (-1)^Mod[vec[a] - vec[b], 2], -1]]

(* vector-spinor-vector-spinor *)
vsvs[p_, r_, {a_, b_, c_, d_}] := If[vectorQ[p, a], vsvs[p, r, a, b, c, d], Transpose[vsvs[p, r, Permute[{a, b, c, d}, Cycles[{{1, 2, 3, 4}}]]]]]
vsvs[p_, r_, a_, b_, c_, d_] /; (vectorQ[p, c] && b == d) := (-1)^(b + 1) (-1)^((vec[a] - 1) (vec[c] - 1))DMatrix[p, r, vec[a] vec[c], -1, (-1)^(vec[a] + vec[c]), (-1)^(vec[a] + vec[c]), 1]
vsvs[p_, r_, a_, b_, c_, d_] /; (vectorQ[p, c] && b != d) := -EMatrix[p, r, vec[a] vec[c], (-1)^(vec[a] + vec[c]), 1, 1, (-1)^(vec[a] + vec[c] + 1)]

(* spinor-spinor-spinor-spinor *)
ssss[p_, r_, k_, a_, b_, c_, d_] /; (a == c && b == d) := If[a == b, HMatrix[p, r, k], -HMatrix[p, r, k]]
ssss[p_, r_, k_, a_, b_, c_, d_] /; ((a == b && c == d && b != c) || (b == c && a == d && a != b)) := HPMatrix[p, r, k]
ssss[p_, r_, k_, a_, b_, c_, d_] /; ((b == c && a != d) || (a == b && c != d) || (c == d && a != b)) := If[b == 2, GMatrix[p, r, k], -GMatrix[p, r, k]]

(* fMatrices *)
fMat[p_, r_, k_] := fMat[p, r, k, {#1, #2, #3, #4}] &
fMat[p_, r_, k_, {a_, b_, c_, d_}] := fMat[p, r, k, a, b, c, d]
fMat[p_, r_, k_, a_, b_, c_, d_] /; (! admissibleQuad[p, a, b, c, d]) := {{0}}
fMat[p_, r_, k_, a_, b_, c_, d_] := {{1}}

fMat[p_, r_, k_, 0, b_, c_, d_] := {{gRing[p, b, c, d]}}
fMat[p_, r_, k_, a_, 0, c_, d_] := {{gRing[p, a, c, d]}}
fMat[p_, r_, k_, a_, b_, 0, d_] := {{gRing[p, a, b, d]}}
fMat[p_, r_, k_, a_, b_, c_, 0] := {{gRing[p, a, b, c]}}

fMat[p_, r_, k_, 1, 1, 1, 1] := {{1}}
fMat[p_, r_, k_, a_, b_, c_, d_] /; (Length[Select[{a, b, c, d}, spinorQ[#] &]] == 2 && Length[Select[{a, b, c, d}, # == 1 &]] == 2) := {{-1}}
fMat[p_, r_, k_, a_, b_, c_, d_] /; (Length[Select[{a, b, c, d}, spinorQ[#] &]] == 2 && Length[Select[{a, b, c, d}, # == 1 &]] == 1) := essv[p, {a, b, c, d}]
fMat[p_, r_, k_, a_, b_, c_, d_] /; (Length[Select[{a, b, c, d}, vectorQ[p, #] &]] == 2 && Length[Select[{a, b, c, d}, # == 1 &]] == 2) := {{1}}
fMat[p_, r_, k_, a_, b_, c_, d_] /; (Length[Select[{a, b, c, d}, vectorQ[p, #] &]] == 3 && Length[Select[{a, b, c, d}, # == 1 &]] == 1) := evvv[p, {a, b, c, d}]
fMat[p_, r_, k_, a_, b_, c_, d_] /; (Length[Select[{a, b, c, d}, vectorQ[p, #] &]] == 4) := vvvv[p, {a, b, c, d}]
fMat[p_, r_, k_, a_, b_, c_, d_] /; ((Length[Select[{a, b, c, d}, spinorQ[#] &]] == 2) && (Length[Select[{a, b, c, d}, vectorQ[p, #] &]] == 2) && (vectorQ[p, a] == vectorQ[p, b] || vectorQ[p, b] == vectorQ[p, c] || vectorQ[p, c] == vectorQ[p, d])) := vvss[p, r, {a, b, c, d}]
fMat[p_, r_, k_, a_, b_, c_, d_] /; ((Length[Select[{a, b, c, d}, spinorQ[#] &]] == 2) && (Length[Select[{a, b, c, d}, vectorQ[p, #] &]] == 2) && (vectorQ[p, a] != vectorQ[p, b] && vectorQ[p, b] != vectorQ[p, c])) := vsvs[p, r, {a, b, c, d}]
fMat[p_, r_, k_, a_, b_, c_, d_] /; (Length[Select[{a, b, c, d}, spinorQ[#] &]] == 4) := ssss[p, r, k, a, b, c, d]

End[]

EndPackage[]
