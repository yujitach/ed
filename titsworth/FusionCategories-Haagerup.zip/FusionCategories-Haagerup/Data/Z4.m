BeginPackage["FusionCategories`Data`Z4`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[Z4] ^= {Z4Cat1, Z4Cat2, Z4Cat3, Z4Cat4}
 
Z4 /: fusionCategory[Z4, 1] = Z4Cat1
 
Z4 /: fusionCategory[Z4, 2] = Z4Cat2
 
Z4 /: fusionCategory[Z4, 3] = Z4Cat3
 
Z4 /: fusionCategory[Z4, 4] = Z4Cat4
 
nFunction[Z4] ^= Z4NFunction
 
noMultiplicities[Z4] ^= True
 
rank[Z4] ^= 4
 
ring[Z4] ^= Z4
balancedCategories[Z4Cat1] ^= {Z4Cat1Bal1, Z4Cat1Bal2, Z4Cat1Bal3, 
    Z4Cat1Bal4, Z4Cat1Bal5, Z4Cat1Bal6, Z4Cat1Bal7, Z4Cat1Bal8, Z4Cat1Bal9, 
    Z4Cat1Bal10, Z4Cat1Bal11, Z4Cat1Bal12, Z4Cat1Bal13, Z4Cat1Bal14, 
    Z4Cat1Bal15, Z4Cat1Bal16}
 
Z4Cat1 /: balancedCategory[Z4Cat1, 1] = Z4Cat1Bal1
 
Z4Cat1 /: balancedCategory[Z4Cat1, 2] = Z4Cat1Bal2
 
Z4Cat1 /: balancedCategory[Z4Cat1, 3] = Z4Cat1Bal3
 
Z4Cat1 /: balancedCategory[Z4Cat1, 4] = Z4Cat1Bal4
 
Z4Cat1 /: balancedCategory[Z4Cat1, 5] = Z4Cat1Bal5
 
Z4Cat1 /: balancedCategory[Z4Cat1, 6] = Z4Cat1Bal6
 
Z4Cat1 /: balancedCategory[Z4Cat1, 7] = Z4Cat1Bal7
 
Z4Cat1 /: balancedCategory[Z4Cat1, 8] = Z4Cat1Bal8
 
Z4Cat1 /: balancedCategory[Z4Cat1, 9] = Z4Cat1Bal9
 
Z4Cat1 /: balancedCategory[Z4Cat1, 10] = Z4Cat1Bal10
 
Z4Cat1 /: balancedCategory[Z4Cat1, 11] = Z4Cat1Bal11
 
Z4Cat1 /: balancedCategory[Z4Cat1, 12] = Z4Cat1Bal12
 
Z4Cat1 /: balancedCategory[Z4Cat1, 13] = Z4Cat1Bal13
 
Z4Cat1 /: balancedCategory[Z4Cat1, 14] = Z4Cat1Bal14
 
Z4Cat1 /: balancedCategory[Z4Cat1, 15] = Z4Cat1Bal15
 
Z4Cat1 /: balancedCategory[Z4Cat1, 16] = Z4Cat1Bal16
 
braidedCategories[Z4Cat1] ^= {Z4Cat1Brd1, Z4Cat1Brd2, Z4Cat1Brd3, Z4Cat1Brd4}
 
Z4Cat1 /: braidedCategory[Z4Cat1, 1] = Z4Cat1Brd1
 
Z4Cat1 /: braidedCategory[Z4Cat1, 2] = Z4Cat1Brd2
 
Z4Cat1 /: braidedCategory[Z4Cat1, 3] = Z4Cat1Brd3
 
Z4Cat1 /: braidedCategory[Z4Cat1, 4] = Z4Cat1Brd4
 
coeval[Z4Cat1] ^= 1/sixJFunction[Z4Cat1][#1, dual[ring[Z4Cat1]][#1], #1, #1, 
      0, 0] & 
 
eval[Z4Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[Z4Cat1] ^= Z4Cat1FMatrixFunction
 
fusionCategory[Z4Cat1] ^= Z4Cat1
 
Z4Cat1 /: modularCategory[Z4Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[Z4Cat1] ^= {Z4Cat1Piv1, Z4Cat1Piv2, Z4Cat1Piv3, Z4Cat1Piv4}
 
Z4Cat1 /: pivotalCategory[Z4Cat1, 1] = Z4Cat1Piv1
 
Z4Cat1 /: pivotalCategory[Z4Cat1, 2] = Z4Cat1Piv2
 
Z4Cat1 /: pivotalCategory[Z4Cat1, 3] = Z4Cat1Piv3
 
Z4Cat1 /: pivotalCategory[Z4Cat1, 4] = Z4Cat1Piv4
 
Z4Cat1 /: pivotalCategory[Z4Cat1, {1, -1, 1, -1}] = Z4Cat1Piv2
 
Z4Cat1 /: pivotalCategory[Z4Cat1, {1, -I, -1, I}] = Z4Cat1Piv3
 
Z4Cat1 /: pivotalCategory[Z4Cat1, {1, I, -1, -I}] = Z4Cat1Piv4
 
Z4Cat1 /: pivotalCategory[Z4Cat1, {1, 1, 1, 1}] = Z4Cat1Piv1
 
Z4Cat1 /: ribbonCategory[Z4Cat1, 1] = Z4Cat1Bal1
 
Z4Cat1 /: ribbonCategory[Z4Cat1, 2] = Z4Cat1Bal2
 
Z4Cat1 /: ribbonCategory[Z4Cat1, 3] = Z4Cat1Bal5
 
Z4Cat1 /: ribbonCategory[Z4Cat1, 4] = Z4Cat1Bal6
 
Z4Cat1 /: ribbonCategory[Z4Cat1, 5] = Z4Cat1Bal9
 
Z4Cat1 /: ribbonCategory[Z4Cat1, 6] = Z4Cat1Bal10
 
Z4Cat1 /: ribbonCategory[Z4Cat1, 7] = Z4Cat1Bal13
 
Z4Cat1 /: ribbonCategory[Z4Cat1, 8] = Z4Cat1Bal14
 
ring[Z4Cat1] ^= Z4
 
Z4Cat1 /: sphericalCategory[Z4Cat1, 1] = Z4Cat1Piv1
 
Z4Cat1 /: sphericalCategory[Z4Cat1, 2] = Z4Cat1Piv2
 
fusionCategoryIndex[Z4][Z4Cat1] ^= 1
balancedCategory[Z4Cat1Bal1] ^= Z4Cat1Bal1
 
braidedCategory[Z4Cat1Bal1] ^= Z4Cat1Brd1
 
coeval[Z4Cat1Bal1] ^= (-1)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat1Piv1][#1] & 
 
fusionCategory[Z4Cat1Bal1] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Bal1] ^= Z4Cat1Piv1
 
ribbonCategory[Z4Cat1Bal1] ^= Z4Cat1Bal1
 
ring[Z4Cat1Bal1] ^= Z4
 
sphericalCategory[Z4Cat1Bal1] ^= Z4Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[Z4Cat1Brd1]][balancedCategory[#1]] & )[
    Z4Cat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z4Cat1]][balancedCategory[#1]] & )[
    Z4Cat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[Z4Cat1Piv1]][balancedCategory[#1]] & )[
    Z4Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[Z4Cat1Brd1]][ribbonCategory[#1]] & )[
    Z4Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z4Cat1]][ribbonCategory[#1]] & )[
    Z4Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[Z4Cat1Piv1]][ribbonCategory[#1]] & )[
    Z4Cat1Bal1] ^= 1
balancedCategory[Z4Cat1Bal10] ^= Z4Cat1Bal10
 
braidedCategory[Z4Cat1Bal10] ^= Z4Cat1Brd3
 
coeval[Z4Cat1Bal10] ^= 1/sixJFunction[Z4Cat1][#1, dual[ring[Z4Cat1]][#1], #1, 
      #1, 0, 0] & 
 
fusionCategory[Z4Cat1Bal10] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Bal10] ^= Z4Cat1Piv2
 
ribbonCategory[Z4Cat1Bal10] ^= Z4Cat1Bal10
 
ring[Z4Cat1Bal10] ^= Z4
 
sphericalCategory[Z4Cat1Bal10] ^= Z4Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[Z4Cat1Brd3]][balancedCategory[#1]] & )[
    Z4Cat1Bal10] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z4Cat1]][balancedCategory[#1]] & )[
    Z4Cat1Bal10] ^= 10
 
(balancedCategoryIndex[pivotalCategory[Z4Cat1Piv2]][balancedCategory[#1]] & )[
    Z4Cat1Bal10] ^= 3
 
(ribbonCategoryIndex[braidedCategory[Z4Cat1Brd3]][ribbonCategory[#1]] & )[
    Z4Cat1Bal10] ^= 2
 
(ribbonCategoryIndex[fusionCategory[Z4Cat1]][ribbonCategory[#1]] & )[
    Z4Cat1Bal10] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[Z4Cat1Piv2]][ribbonCategory[#1]] & )[
    Z4Cat1Bal10] ^= 3
balancedCategory[Z4Cat1Bal11] ^= Z4Cat1Bal11
 
braidedCategory[Z4Cat1Bal11] ^= Z4Cat1Brd3
 
coeval[Z4Cat1Bal11] ^= I^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat1Piv3][#1] & 
 
fusionCategory[Z4Cat1Bal11] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Bal11] ^= Z4Cat1Piv3
 
ribbonCategory[Z4Cat1Bal11] ^= Z4Cat1Bal11
 
ring[Z4Cat1Bal11] ^= Z4
 
(balancedCategoryIndex[braidedCategory[Z4Cat1Brd3]][balancedCategory[#1]] & )[
    Z4Cat1Bal11] ^= 3
 
(balancedCategoryIndex[fusionCategory[Z4Cat1]][balancedCategory[#1]] & )[
    Z4Cat1Bal11] ^= 11
 
(balancedCategoryIndex[pivotalCategory[Z4Cat1Piv3]][balancedCategory[#1]] & )[
    Z4Cat1Bal11] ^= 3
balancedCategory[Z4Cat1Bal12] ^= Z4Cat1Bal12
 
braidedCategory[Z4Cat1Bal12] ^= Z4Cat1Brd3
 
coeval[Z4Cat1Bal12] ^= (-I)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat1Piv4][#1] & 
 
fusionCategory[Z4Cat1Bal12] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Bal12] ^= Z4Cat1Piv4
 
ribbonCategory[Z4Cat1Bal12] ^= Z4Cat1Bal12
 
ring[Z4Cat1Bal12] ^= Z4
 
(balancedCategoryIndex[braidedCategory[Z4Cat1Brd3]][balancedCategory[#1]] & )[
    Z4Cat1Bal12] ^= 4
 
(balancedCategoryIndex[fusionCategory[Z4Cat1]][balancedCategory[#1]] & )[
    Z4Cat1Bal12] ^= 12
 
(balancedCategoryIndex[pivotalCategory[Z4Cat1Piv4]][balancedCategory[#1]] & )[
    Z4Cat1Bal12] ^= 3
balancedCategory[Z4Cat1Bal13] ^= Z4Cat1Bal13
 
braidedCategory[Z4Cat1Bal13] ^= Z4Cat1Brd4
 
coeval[Z4Cat1Bal13] ^= (-1)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat1Piv1][#1] & 
 
fusionCategory[Z4Cat1Bal13] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Bal13] ^= Z4Cat1Piv1
 
ribbonCategory[Z4Cat1Bal13] ^= Z4Cat1Bal13
 
ring[Z4Cat1Bal13] ^= Z4
 
sphericalCategory[Z4Cat1Bal13] ^= Z4Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[Z4Cat1Brd4]][balancedCategory[#1]] & )[
    Z4Cat1Bal13] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z4Cat1]][balancedCategory[#1]] & )[
    Z4Cat1Bal13] ^= 13
 
(balancedCategoryIndex[pivotalCategory[Z4Cat1Piv1]][balancedCategory[#1]] & )[
    Z4Cat1Bal13] ^= 4
 
(ribbonCategoryIndex[braidedCategory[Z4Cat1Brd4]][ribbonCategory[#1]] & )[
    Z4Cat1Bal13] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z4Cat1]][ribbonCategory[#1]] & )[
    Z4Cat1Bal13] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[Z4Cat1Piv1]][ribbonCategory[#1]] & )[
    Z4Cat1Bal13] ^= 4
balancedCategory[Z4Cat1Bal14] ^= Z4Cat1Bal14
 
braidedCategory[Z4Cat1Bal14] ^= Z4Cat1Brd4
 
coeval[Z4Cat1Bal14] ^= 1/sixJFunction[Z4Cat1][#1, dual[ring[Z4Cat1]][#1], #1, 
      #1, 0, 0] & 
 
fusionCategory[Z4Cat1Bal14] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Bal14] ^= Z4Cat1Piv2
 
ribbonCategory[Z4Cat1Bal14] ^= Z4Cat1Bal14
 
ring[Z4Cat1Bal14] ^= Z4
 
sphericalCategory[Z4Cat1Bal14] ^= Z4Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[Z4Cat1Brd4]][balancedCategory[#1]] & )[
    Z4Cat1Bal14] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z4Cat1]][balancedCategory[#1]] & )[
    Z4Cat1Bal14] ^= 14
 
(balancedCategoryIndex[pivotalCategory[Z4Cat1Piv2]][balancedCategory[#1]] & )[
    Z4Cat1Bal14] ^= 4
 
(ribbonCategoryIndex[braidedCategory[Z4Cat1Brd4]][ribbonCategory[#1]] & )[
    Z4Cat1Bal14] ^= 2
 
(ribbonCategoryIndex[fusionCategory[Z4Cat1]][ribbonCategory[#1]] & )[
    Z4Cat1Bal14] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[Z4Cat1Piv2]][ribbonCategory[#1]] & )[
    Z4Cat1Bal14] ^= 4
balancedCategory[Z4Cat1Bal15] ^= Z4Cat1Bal15
 
braidedCategory[Z4Cat1Bal15] ^= Z4Cat1Brd4
 
coeval[Z4Cat1Bal15] ^= I^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat1Piv3][#1] & 
 
fusionCategory[Z4Cat1Bal15] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Bal15] ^= Z4Cat1Piv3
 
ribbonCategory[Z4Cat1Bal15] ^= Z4Cat1Bal15
 
ring[Z4Cat1Bal15] ^= Z4
 
(balancedCategoryIndex[braidedCategory[Z4Cat1Brd4]][balancedCategory[#1]] & )[
    Z4Cat1Bal15] ^= 3
 
(balancedCategoryIndex[fusionCategory[Z4Cat1]][balancedCategory[#1]] & )[
    Z4Cat1Bal15] ^= 15
 
(balancedCategoryIndex[pivotalCategory[Z4Cat1Piv3]][balancedCategory[#1]] & )[
    Z4Cat1Bal15] ^= 4
balancedCategory[Z4Cat1Bal16] ^= Z4Cat1Bal16
 
braidedCategory[Z4Cat1Bal16] ^= Z4Cat1Brd4
 
coeval[Z4Cat1Bal16] ^= (-I)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat1Piv4][#1] & 
 
fusionCategory[Z4Cat1Bal16] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Bal16] ^= Z4Cat1Piv4
 
ribbonCategory[Z4Cat1Bal16] ^= Z4Cat1Bal16
 
ring[Z4Cat1Bal16] ^= Z4
 
(balancedCategoryIndex[braidedCategory[Z4Cat1Brd4]][balancedCategory[#1]] & )[
    Z4Cat1Bal16] ^= 4
 
(balancedCategoryIndex[fusionCategory[Z4Cat1]][balancedCategory[#1]] & )[
    Z4Cat1Bal16] ^= 16
 
(balancedCategoryIndex[pivotalCategory[Z4Cat1Piv4]][balancedCategory[#1]] & )[
    Z4Cat1Bal16] ^= 4
balancedCategory[Z4Cat1Bal2] ^= Z4Cat1Bal2
 
braidedCategory[Z4Cat1Bal2] ^= Z4Cat1Brd1
 
coeval[Z4Cat1Bal2] ^= 1/sixJFunction[Z4Cat1][#1, dual[ring[Z4Cat1]][#1], #1, 
      #1, 0, 0] & 
 
fusionCategory[Z4Cat1Bal2] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Bal2] ^= Z4Cat1Piv2
 
ribbonCategory[Z4Cat1Bal2] ^= Z4Cat1Bal2
 
ring[Z4Cat1Bal2] ^= Z4
 
sphericalCategory[Z4Cat1Bal2] ^= Z4Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[Z4Cat1Brd1]][balancedCategory[#1]] & )[
    Z4Cat1Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z4Cat1]][balancedCategory[#1]] & )[
    Z4Cat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[Z4Cat1Piv2]][balancedCategory[#1]] & )[
    Z4Cat1Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[Z4Cat1Brd1]][ribbonCategory[#1]] & )[
    Z4Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[Z4Cat1]][ribbonCategory[#1]] & )[
    Z4Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[Z4Cat1Piv2]][ribbonCategory[#1]] & )[
    Z4Cat1Bal2] ^= 1
balancedCategory[Z4Cat1Bal3] ^= Z4Cat1Bal3
 
braidedCategory[Z4Cat1Bal3] ^= Z4Cat1Brd1
 
coeval[Z4Cat1Bal3] ^= I^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat1Piv3][#1] & 
 
fusionCategory[Z4Cat1Bal3] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Bal3] ^= Z4Cat1Piv3
 
ribbonCategory[Z4Cat1Bal3] ^= Z4Cat1Bal3
 
ring[Z4Cat1Bal3] ^= Z4
 
(balancedCategoryIndex[braidedCategory[Z4Cat1Brd1]][balancedCategory[#1]] & )[
    Z4Cat1Bal3] ^= 3
 
(balancedCategoryIndex[fusionCategory[Z4Cat1]][balancedCategory[#1]] & )[
    Z4Cat1Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[Z4Cat1Piv3]][balancedCategory[#1]] & )[
    Z4Cat1Bal3] ^= 1
balancedCategory[Z4Cat1Bal4] ^= Z4Cat1Bal4
 
braidedCategory[Z4Cat1Bal4] ^= Z4Cat1Brd1
 
coeval[Z4Cat1Bal4] ^= (-I)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat1Piv4][#1] & 
 
fusionCategory[Z4Cat1Bal4] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Bal4] ^= Z4Cat1Piv4
 
ribbonCategory[Z4Cat1Bal4] ^= Z4Cat1Bal4
 
ring[Z4Cat1Bal4] ^= Z4
 
(balancedCategoryIndex[braidedCategory[Z4Cat1Brd1]][balancedCategory[#1]] & )[
    Z4Cat1Bal4] ^= 4
 
(balancedCategoryIndex[fusionCategory[Z4Cat1]][balancedCategory[#1]] & )[
    Z4Cat1Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[Z4Cat1Piv4]][balancedCategory[#1]] & )[
    Z4Cat1Bal4] ^= 1
balancedCategory[Z4Cat1Bal5] ^= Z4Cat1Bal5
 
braidedCategory[Z4Cat1Bal5] ^= Z4Cat1Brd2
 
coeval[Z4Cat1Bal5] ^= (-1)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat1Piv1][#1] & 
 
fusionCategory[Z4Cat1Bal5] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Bal5] ^= Z4Cat1Piv1
 
ribbonCategory[Z4Cat1Bal5] ^= Z4Cat1Bal5
 
ring[Z4Cat1Bal5] ^= Z4
 
sphericalCategory[Z4Cat1Bal5] ^= Z4Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[Z4Cat1Brd2]][balancedCategory[#1]] & )[
    Z4Cat1Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z4Cat1]][balancedCategory[#1]] & )[
    Z4Cat1Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[Z4Cat1Piv1]][balancedCategory[#1]] & )[
    Z4Cat1Bal5] ^= 2
 
(ribbonCategoryIndex[braidedCategory[Z4Cat1Brd2]][ribbonCategory[#1]] & )[
    Z4Cat1Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z4Cat1]][ribbonCategory[#1]] & )[
    Z4Cat1Bal5] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[Z4Cat1Piv1]][ribbonCategory[#1]] & )[
    Z4Cat1Bal5] ^= 2
balancedCategory[Z4Cat1Bal6] ^= Z4Cat1Bal6
 
braidedCategory[Z4Cat1Bal6] ^= Z4Cat1Brd2
 
coeval[Z4Cat1Bal6] ^= 1/sixJFunction[Z4Cat1][#1, dual[ring[Z4Cat1]][#1], #1, 
      #1, 0, 0] & 
 
fusionCategory[Z4Cat1Bal6] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Bal6] ^= Z4Cat1Piv2
 
ribbonCategory[Z4Cat1Bal6] ^= Z4Cat1Bal6
 
ring[Z4Cat1Bal6] ^= Z4
 
sphericalCategory[Z4Cat1Bal6] ^= Z4Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[Z4Cat1Brd2]][balancedCategory[#1]] & )[
    Z4Cat1Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z4Cat1]][balancedCategory[#1]] & )[
    Z4Cat1Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[Z4Cat1Piv2]][balancedCategory[#1]] & )[
    Z4Cat1Bal6] ^= 2
 
(ribbonCategoryIndex[braidedCategory[Z4Cat1Brd2]][ribbonCategory[#1]] & )[
    Z4Cat1Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[Z4Cat1]][ribbonCategory[#1]] & )[
    Z4Cat1Bal6] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[Z4Cat1Piv2]][ribbonCategory[#1]] & )[
    Z4Cat1Bal6] ^= 2
balancedCategory[Z4Cat1Bal7] ^= Z4Cat1Bal7
 
braidedCategory[Z4Cat1Bal7] ^= Z4Cat1Brd2
 
coeval[Z4Cat1Bal7] ^= I^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat1Piv3][#1] & 
 
fusionCategory[Z4Cat1Bal7] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Bal7] ^= Z4Cat1Piv3
 
ribbonCategory[Z4Cat1Bal7] ^= Z4Cat1Bal7
 
ring[Z4Cat1Bal7] ^= Z4
 
(balancedCategoryIndex[braidedCategory[Z4Cat1Brd2]][balancedCategory[#1]] & )[
    Z4Cat1Bal7] ^= 3
 
(balancedCategoryIndex[fusionCategory[Z4Cat1]][balancedCategory[#1]] & )[
    Z4Cat1Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[Z4Cat1Piv3]][balancedCategory[#1]] & )[
    Z4Cat1Bal7] ^= 2
balancedCategory[Z4Cat1Bal8] ^= Z4Cat1Bal8
 
braidedCategory[Z4Cat1Bal8] ^= Z4Cat1Brd2
 
coeval[Z4Cat1Bal8] ^= (-I)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat1Piv4][#1] & 
 
fusionCategory[Z4Cat1Bal8] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Bal8] ^= Z4Cat1Piv4
 
ribbonCategory[Z4Cat1Bal8] ^= Z4Cat1Bal8
 
ring[Z4Cat1Bal8] ^= Z4
 
(balancedCategoryIndex[braidedCategory[Z4Cat1Brd2]][balancedCategory[#1]] & )[
    Z4Cat1Bal8] ^= 4
 
(balancedCategoryIndex[fusionCategory[Z4Cat1]][balancedCategory[#1]] & )[
    Z4Cat1Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[Z4Cat1Piv4]][balancedCategory[#1]] & )[
    Z4Cat1Bal8] ^= 2
balancedCategory[Z4Cat1Bal9] ^= Z4Cat1Bal9
 
braidedCategory[Z4Cat1Bal9] ^= Z4Cat1Brd3
 
coeval[Z4Cat1Bal9] ^= (-1)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat1Piv1][#1] & 
 
fusionCategory[Z4Cat1Bal9] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Bal9] ^= Z4Cat1Piv1
 
ribbonCategory[Z4Cat1Bal9] ^= Z4Cat1Bal9
 
ring[Z4Cat1Bal9] ^= Z4
 
sphericalCategory[Z4Cat1Bal9] ^= Z4Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[Z4Cat1Brd3]][balancedCategory[#1]] & )[
    Z4Cat1Bal9] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z4Cat1]][balancedCategory[#1]] & )[
    Z4Cat1Bal9] ^= 9
 
(balancedCategoryIndex[pivotalCategory[Z4Cat1Piv1]][balancedCategory[#1]] & )[
    Z4Cat1Bal9] ^= 3
 
(ribbonCategoryIndex[braidedCategory[Z4Cat1Brd3]][ribbonCategory[#1]] & )[
    Z4Cat1Bal9] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z4Cat1]][ribbonCategory[#1]] & )[
    Z4Cat1Bal9] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[Z4Cat1Piv1]][ribbonCategory[#1]] & )[
    Z4Cat1Bal9] ^= 3
balancedCategories[Z4Cat1Brd1] ^= {Z4Cat1Bal1, Z4Cat1Bal2, Z4Cat1Bal3, 
    Z4Cat1Bal4}
 
Z4Cat1Brd1 /: balancedCategory[Z4Cat1Brd1, 1] = Z4Cat1Bal1
 
Z4Cat1Brd1 /: balancedCategory[Z4Cat1Brd1, 2] = Z4Cat1Bal2
 
Z4Cat1Brd1 /: balancedCategory[Z4Cat1Brd1, 3] = Z4Cat1Bal3
 
Z4Cat1Brd1 /: balancedCategory[Z4Cat1Brd1, 4] = Z4Cat1Bal4
 
braidedCategory[Z4Cat1Brd1] ^= Z4Cat1Brd1
 
fusionCategory[Z4Cat1Brd1] ^= Z4Cat1
 
Z4Cat1Brd1 /: modularCategory[Z4Cat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z4Cat1Brd1 /: ribbonCategory[Z4Cat1Brd1, 1] = Z4Cat1Bal1
 
Z4Cat1Brd1 /: ribbonCategory[Z4Cat1Brd1, 2] = Z4Cat1Bal2
 
ring[Z4Cat1Brd1] ^= Z4
 
rMatrixFunction[Z4Cat1Brd1] ^= Z4Cat1Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[Z4Cat1]][braidedCategory[#1]] & )[
    Z4Cat1Brd1] ^= 1
braidedCategory[Z4Cat1Brd1RMatrixFunction] ^= Z4Cat1Brd1
 
fusionCategory[Z4Cat1Brd1RMatrixFunction] ^= Z4Cat1
 
rMatrixFunction[Z4Cat1Brd1RMatrixFunction] ^= Z4Cat1Brd1RMatrixFunction
 
Z4Cat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
Z4Cat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
Z4Cat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
Z4Cat1Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
Z4Cat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
Z4Cat1Brd1RMatrixFunction[1, 1, 2] = {{-(-1)^(3/4)}}
 
Z4Cat1Brd1RMatrixFunction[1, 2, 3] = {{-I}}
 
Z4Cat1Brd1RMatrixFunction[1, 3, 0] = {{-(-1)^(1/4)}}
 
Z4Cat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
Z4Cat1Brd1RMatrixFunction[2, 1, 3] = {{-I}}
 
Z4Cat1Brd1RMatrixFunction[2, 2, 0] = {{-1}}
 
Z4Cat1Brd1RMatrixFunction[2, 3, 1] = {{-I}}
 
Z4Cat1Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
Z4Cat1Brd1RMatrixFunction[3, 1, 0] = {{-(-1)^(1/4)}}
 
Z4Cat1Brd1RMatrixFunction[3, 2, 1] = {{-I}}
 
Z4Cat1Brd1RMatrixFunction[3, 3, 2] = {{-(-1)^(3/4)}}
balancedCategories[Z4Cat1Brd2] ^= {Z4Cat1Bal5, Z4Cat1Bal6, Z4Cat1Bal7, 
    Z4Cat1Bal8}
 
Z4Cat1Brd2 /: balancedCategory[Z4Cat1Brd2, 1] = Z4Cat1Bal5
 
Z4Cat1Brd2 /: balancedCategory[Z4Cat1Brd2, 2] = Z4Cat1Bal6
 
Z4Cat1Brd2 /: balancedCategory[Z4Cat1Brd2, 3] = Z4Cat1Bal7
 
Z4Cat1Brd2 /: balancedCategory[Z4Cat1Brd2, 4] = Z4Cat1Bal8
 
braidedCategory[Z4Cat1Brd2] ^= Z4Cat1Brd2
 
fusionCategory[Z4Cat1Brd2] ^= Z4Cat1
 
Z4Cat1Brd2 /: modularCategory[Z4Cat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z4Cat1Brd2 /: ribbonCategory[Z4Cat1Brd2, 1] = Z4Cat1Bal5
 
Z4Cat1Brd2 /: ribbonCategory[Z4Cat1Brd2, 2] = Z4Cat1Bal6
 
ring[Z4Cat1Brd2] ^= Z4
 
rMatrixFunction[Z4Cat1Brd2] ^= Z4Cat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[Z4Cat1]][braidedCategory[#1]] & )[
    Z4Cat1Brd2] ^= 2
braidedCategory[Z4Cat1Brd2RMatrixFunction] ^= Z4Cat1Brd2
 
fusionCategory[Z4Cat1Brd2RMatrixFunction] ^= Z4Cat1
 
rMatrixFunction[Z4Cat1Brd2RMatrixFunction] ^= Z4Cat1Brd2RMatrixFunction
 
Z4Cat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
Z4Cat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
Z4Cat1Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
Z4Cat1Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
Z4Cat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
Z4Cat1Brd2RMatrixFunction[1, 1, 2] = {{(-1)^(3/4)}}
 
Z4Cat1Brd2RMatrixFunction[1, 2, 3] = {{-I}}
 
Z4Cat1Brd2RMatrixFunction[1, 3, 0] = {{(-1)^(1/4)}}
 
Z4Cat1Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
Z4Cat1Brd2RMatrixFunction[2, 1, 3] = {{-I}}
 
Z4Cat1Brd2RMatrixFunction[2, 2, 0] = {{-1}}
 
Z4Cat1Brd2RMatrixFunction[2, 3, 1] = {{-I}}
 
Z4Cat1Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
Z4Cat1Brd2RMatrixFunction[3, 1, 0] = {{(-1)^(1/4)}}
 
Z4Cat1Brd2RMatrixFunction[3, 2, 1] = {{-I}}
 
Z4Cat1Brd2RMatrixFunction[3, 3, 2] = {{(-1)^(3/4)}}
balancedCategories[Z4Cat1Brd3] ^= {Z4Cat1Bal9, Z4Cat1Bal10, Z4Cat1Bal11, 
    Z4Cat1Bal12}
 
Z4Cat1Brd3 /: balancedCategory[Z4Cat1Brd3, 1] = Z4Cat1Bal9
 
Z4Cat1Brd3 /: balancedCategory[Z4Cat1Brd3, 2] = Z4Cat1Bal10
 
Z4Cat1Brd3 /: balancedCategory[Z4Cat1Brd3, 3] = Z4Cat1Bal11
 
Z4Cat1Brd3 /: balancedCategory[Z4Cat1Brd3, 4] = Z4Cat1Bal12
 
braidedCategory[Z4Cat1Brd3] ^= Z4Cat1Brd3
 
fusionCategory[Z4Cat1Brd3] ^= Z4Cat1
 
Z4Cat1Brd3 /: modularCategory[Z4Cat1Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z4Cat1Brd3 /: ribbonCategory[Z4Cat1Brd3, 1] = Z4Cat1Bal9
 
Z4Cat1Brd3 /: ribbonCategory[Z4Cat1Brd3, 2] = Z4Cat1Bal10
 
ring[Z4Cat1Brd3] ^= Z4
 
rMatrixFunction[Z4Cat1Brd3] ^= Z4Cat1Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[Z4Cat1]][braidedCategory[#1]] & )[
    Z4Cat1Brd3] ^= 3
braidedCategory[Z4Cat1Brd3RMatrixFunction] ^= Z4Cat1Brd3
 
fusionCategory[Z4Cat1Brd3RMatrixFunction] ^= Z4Cat1
 
rMatrixFunction[Z4Cat1Brd3RMatrixFunction] ^= Z4Cat1Brd3RMatrixFunction
 
Z4Cat1Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
Z4Cat1Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
Z4Cat1Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
Z4Cat1Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
Z4Cat1Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
Z4Cat1Brd3RMatrixFunction[1, 1, 2] = {{-(-1)^(1/4)}}
 
Z4Cat1Brd3RMatrixFunction[1, 2, 3] = {{I}}
 
Z4Cat1Brd3RMatrixFunction[1, 3, 0] = {{-(-1)^(3/4)}}
 
Z4Cat1Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
Z4Cat1Brd3RMatrixFunction[2, 1, 3] = {{I}}
 
Z4Cat1Brd3RMatrixFunction[2, 2, 0] = {{-1}}
 
Z4Cat1Brd3RMatrixFunction[2, 3, 1] = {{I}}
 
Z4Cat1Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
Z4Cat1Brd3RMatrixFunction[3, 1, 0] = {{-(-1)^(3/4)}}
 
Z4Cat1Brd3RMatrixFunction[3, 2, 1] = {{I}}
 
Z4Cat1Brd3RMatrixFunction[3, 3, 2] = {{-(-1)^(1/4)}}
balancedCategories[Z4Cat1Brd4] ^= {Z4Cat1Bal13, Z4Cat1Bal14, Z4Cat1Bal15, 
    Z4Cat1Bal16}
 
Z4Cat1Brd4 /: balancedCategory[Z4Cat1Brd4, 1] = Z4Cat1Bal13
 
Z4Cat1Brd4 /: balancedCategory[Z4Cat1Brd4, 2] = Z4Cat1Bal14
 
Z4Cat1Brd4 /: balancedCategory[Z4Cat1Brd4, 3] = Z4Cat1Bal15
 
Z4Cat1Brd4 /: balancedCategory[Z4Cat1Brd4, 4] = Z4Cat1Bal16
 
braidedCategory[Z4Cat1Brd4] ^= Z4Cat1Brd4
 
fusionCategory[Z4Cat1Brd4] ^= Z4Cat1
 
Z4Cat1Brd4 /: modularCategory[Z4Cat1Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z4Cat1Brd4 /: ribbonCategory[Z4Cat1Brd4, 1] = Z4Cat1Bal13
 
Z4Cat1Brd4 /: ribbonCategory[Z4Cat1Brd4, 2] = Z4Cat1Bal14
 
ring[Z4Cat1Brd4] ^= Z4
 
rMatrixFunction[Z4Cat1Brd4] ^= Z4Cat1Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[Z4Cat1]][braidedCategory[#1]] & )[
    Z4Cat1Brd4] ^= 4
braidedCategory[Z4Cat1Brd4RMatrixFunction] ^= Z4Cat1Brd4
 
fusionCategory[Z4Cat1Brd4RMatrixFunction] ^= Z4Cat1
 
rMatrixFunction[Z4Cat1Brd4RMatrixFunction] ^= Z4Cat1Brd4RMatrixFunction
 
Z4Cat1Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
Z4Cat1Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
Z4Cat1Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
Z4Cat1Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
Z4Cat1Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
Z4Cat1Brd4RMatrixFunction[1, 1, 2] = {{(-1)^(1/4)}}
 
Z4Cat1Brd4RMatrixFunction[1, 2, 3] = {{I}}
 
Z4Cat1Brd4RMatrixFunction[1, 3, 0] = {{(-1)^(3/4)}}
 
Z4Cat1Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
Z4Cat1Brd4RMatrixFunction[2, 1, 3] = {{I}}
 
Z4Cat1Brd4RMatrixFunction[2, 2, 0] = {{-1}}
 
Z4Cat1Brd4RMatrixFunction[2, 3, 1] = {{I}}
 
Z4Cat1Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
Z4Cat1Brd4RMatrixFunction[3, 1, 0] = {{(-1)^(3/4)}}
 
Z4Cat1Brd4RMatrixFunction[3, 2, 1] = {{I}}
 
Z4Cat1Brd4RMatrixFunction[3, 3, 2] = {{(-1)^(1/4)}}
fMatrixFunction[Z4Cat1FMatrixFunction] ^= Z4Cat1FMatrixFunction
 
fusionCategory[Z4Cat1FMatrixFunction] ^= Z4Cat1
 
ring[Z4Cat1FMatrixFunction] ^= Z4
 
Z4Cat1FMatrixFunction[1, 2, 2, 1] = {{-1}}
 
Z4Cat1FMatrixFunction[1, 2, 3, 2] = {{-1}}
 
Z4Cat1FMatrixFunction[1, 3, 1, 1] = {{-1}}
 
Z4Cat1FMatrixFunction[1, 3, 2, 2] = {{-1}}
 
Z4Cat1FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
Z4Cat1FMatrixFunction[2, 1, 3, 2] = {{-1}}
 
Z4Cat1FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
Z4Cat1FMatrixFunction[2, 2, 3, 3] = {{-1}}
 
Z4Cat1FMatrixFunction[2, 3, 1, 2] = {{-1}}
 
Z4Cat1FMatrixFunction[2, 3, 2, 3] = {{-1}}
 
Z4Cat1FMatrixFunction[3, 1, 2, 2] = {{-1}}
 
Z4Cat1FMatrixFunction[3, 1, 3, 3] = {{-1}}
 
Z4Cat1FMatrixFunction[3, 2, 1, 2] = {{-1}}
 
Z4Cat1FMatrixFunction[3, 2, 2, 3] = {{-1}}
 
Z4Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z4Cat1], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
Z4Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z4Cat1], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[Z4Cat1Piv1] ^= {Z4Cat1Bal1, Z4Cat1Bal5, Z4Cat1Bal9, 
    Z4Cat1Bal13}
 
Z4Cat1Piv1 /: balancedCategory[Z4Cat1Piv1, 1] = Z4Cat1Bal1
 
Z4Cat1Piv1 /: balancedCategory[Z4Cat1Piv1, 2] = Z4Cat1Bal5
 
Z4Cat1Piv1 /: balancedCategory[Z4Cat1Piv1, 3] = Z4Cat1Bal9
 
Z4Cat1Piv1 /: balancedCategory[Z4Cat1Piv1, 4] = Z4Cat1Bal13
 
coeval[Z4Cat1Piv1] ^= (-1)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat1Piv1][#1] & 
 
fusionCategory[Z4Cat1Piv1] ^= Z4Cat1
 
Z4Cat1Piv1 /: modularCategory[Z4Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z4Cat1Piv1] ^= Z4Cat1Piv1
 
pivotalIsomorphism[Z4Cat1Piv1] ^= Z4Cat1Piv1PivotalIsomorphism
 
Z4Cat1Piv1 /: ribbonCategory[Z4Cat1Piv1, 1] = Z4Cat1Bal1
 
Z4Cat1Piv1 /: ribbonCategory[Z4Cat1Piv1, 2] = Z4Cat1Bal5
 
Z4Cat1Piv1 /: ribbonCategory[Z4Cat1Piv1, 3] = Z4Cat1Bal9
 
Z4Cat1Piv1 /: ribbonCategory[Z4Cat1Piv1, 4] = Z4Cat1Bal13
 
ring[Z4Cat1Piv1] ^= Z4
 
sphericalCategory[Z4Cat1Piv1] ^= Z4Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[Z4Cat1]][pivotalCategory[#1]] & )[
    Z4Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[Z4Cat1]][sphericalCategory[#1]] & )[
    Z4Cat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z4Cat1Piv1PivotalIsomorphism] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Piv1PivotalIsomorphism] ^= Z4Cat1Piv1
 
pivotalIsomorphism[Z4Cat1Piv1PivotalIsomorphism] ^= 
   Z4Cat1Piv1PivotalIsomorphism
 
Z4Cat1Piv1PivotalIsomorphism[0] = 1
 
Z4Cat1Piv1PivotalIsomorphism[1] = 1
 
Z4Cat1Piv1PivotalIsomorphism[2] = 1
 
Z4Cat1Piv1PivotalIsomorphism[3] = 1
balancedCategories[Z4Cat1Piv2] ^= {Z4Cat1Bal2, Z4Cat1Bal6, Z4Cat1Bal10, 
    Z4Cat1Bal14}
 
Z4Cat1Piv2 /: balancedCategory[Z4Cat1Piv2, 1] = Z4Cat1Bal2
 
Z4Cat1Piv2 /: balancedCategory[Z4Cat1Piv2, 2] = Z4Cat1Bal6
 
Z4Cat1Piv2 /: balancedCategory[Z4Cat1Piv2, 3] = Z4Cat1Bal10
 
Z4Cat1Piv2 /: balancedCategory[Z4Cat1Piv2, 4] = Z4Cat1Bal14
 
fusionCategory[Z4Cat1Piv2] ^= Z4Cat1
 
Z4Cat1Piv2 /: modularCategory[Z4Cat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z4Cat1Piv2] ^= Z4Cat1Piv2
 
pivotalIsomorphism[Z4Cat1Piv2] ^= Z4Cat1Piv2PivotalIsomorphism
 
Z4Cat1Piv2 /: ribbonCategory[Z4Cat1Piv2, 1] = Z4Cat1Bal2
 
Z4Cat1Piv2 /: ribbonCategory[Z4Cat1Piv2, 2] = Z4Cat1Bal6
 
Z4Cat1Piv2 /: ribbonCategory[Z4Cat1Piv2, 3] = Z4Cat1Bal10
 
Z4Cat1Piv2 /: ribbonCategory[Z4Cat1Piv2, 4] = Z4Cat1Bal14
 
ring[Z4Cat1Piv2] ^= Z4
 
sphericalCategory[Z4Cat1Piv2] ^= Z4Cat1Piv2
 
(pivotalCategoryIndex[fusionCategory[Z4Cat1]][pivotalCategory[#1]] & )[
    Z4Cat1Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[Z4Cat1]][sphericalCategory[#1]] & )[
    Z4Cat1Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z4Cat1Piv2PivotalIsomorphism] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Piv2PivotalIsomorphism] ^= Z4Cat1Piv2
 
pivotalIsomorphism[Z4Cat1Piv2PivotalIsomorphism] ^= 
   Z4Cat1Piv2PivotalIsomorphism
 
Z4Cat1Piv2PivotalIsomorphism[0] = 1
 
Z4Cat1Piv2PivotalIsomorphism[1] = -1
 
Z4Cat1Piv2PivotalIsomorphism[2] = 1
 
Z4Cat1Piv2PivotalIsomorphism[3] = -1
balancedCategories[Z4Cat1Piv3] ^= {Z4Cat1Bal3, Z4Cat1Bal7, Z4Cat1Bal11, 
    Z4Cat1Bal15}
 
Z4Cat1Piv3 /: balancedCategory[Z4Cat1Piv3, 1] = Z4Cat1Bal3
 
Z4Cat1Piv3 /: balancedCategory[Z4Cat1Piv3, 2] = Z4Cat1Bal7
 
Z4Cat1Piv3 /: balancedCategory[Z4Cat1Piv3, 3] = Z4Cat1Bal11
 
Z4Cat1Piv3 /: balancedCategory[Z4Cat1Piv3, 4] = Z4Cat1Bal15
 
coeval[Z4Cat1Piv3] ^= I^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat1Piv3][#1] & 
 
fusionCategory[Z4Cat1Piv3] ^= Z4Cat1
 
Z4Cat1Piv3 /: modularCategory[Z4Cat1Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z4Cat1Piv3] ^= Z4Cat1Piv3
 
pivotalIsomorphism[Z4Cat1Piv3] ^= Z4Cat1Piv3PivotalIsomorphism
 
ring[Z4Cat1Piv3] ^= Z4
 
(pivotalCategoryIndex[fusionCategory[Z4Cat1]][pivotalCategory[#1]] & )[
    Z4Cat1Piv3] ^= 3
fusionCategory[Z4Cat1Piv3PivotalIsomorphism] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Piv3PivotalIsomorphism] ^= Z4Cat1Piv3
 
pivotalIsomorphism[Z4Cat1Piv3PivotalIsomorphism] ^= 
   Z4Cat1Piv3PivotalIsomorphism
 
Z4Cat1Piv3PivotalIsomorphism[0] = 1
 
Z4Cat1Piv3PivotalIsomorphism[1] = -I
 
Z4Cat1Piv3PivotalIsomorphism[2] = -1
 
Z4Cat1Piv3PivotalIsomorphism[3] = I
balancedCategories[Z4Cat1Piv4] ^= {Z4Cat1Bal4, Z4Cat1Bal8, Z4Cat1Bal12, 
    Z4Cat1Bal16}
 
Z4Cat1Piv4 /: balancedCategory[Z4Cat1Piv4, 1] = Z4Cat1Bal4
 
Z4Cat1Piv4 /: balancedCategory[Z4Cat1Piv4, 2] = Z4Cat1Bal8
 
Z4Cat1Piv4 /: balancedCategory[Z4Cat1Piv4, 3] = Z4Cat1Bal12
 
Z4Cat1Piv4 /: balancedCategory[Z4Cat1Piv4, 4] = Z4Cat1Bal16
 
coeval[Z4Cat1Piv4] ^= (-I)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat1Piv4][#1] & 
 
fusionCategory[Z4Cat1Piv4] ^= Z4Cat1
 
Z4Cat1Piv4 /: modularCategory[Z4Cat1Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z4Cat1Piv4] ^= Z4Cat1Piv4
 
pivotalIsomorphism[Z4Cat1Piv4] ^= Z4Cat1Piv4PivotalIsomorphism
 
ring[Z4Cat1Piv4] ^= Z4
 
(pivotalCategoryIndex[fusionCategory[Z4Cat1]][pivotalCategory[#1]] & )[
    Z4Cat1Piv4] ^= 4
fusionCategory[Z4Cat1Piv4PivotalIsomorphism] ^= Z4Cat1
 
pivotalCategory[Z4Cat1Piv4PivotalIsomorphism] ^= Z4Cat1Piv4
 
pivotalIsomorphism[Z4Cat1Piv4PivotalIsomorphism] ^= 
   Z4Cat1Piv4PivotalIsomorphism
 
Z4Cat1Piv4PivotalIsomorphism[0] = 1
 
Z4Cat1Piv4PivotalIsomorphism[1] = I
 
Z4Cat1Piv4PivotalIsomorphism[2] = -1
 
Z4Cat1Piv4PivotalIsomorphism[3] = -I
balancedCategories[Z4Cat2] ^= {Z4Cat2Bal1, Z4Cat2Bal2, Z4Cat2Bal3, 
    Z4Cat2Bal4, Z4Cat2Bal5, Z4Cat2Bal6, Z4Cat2Bal7, Z4Cat2Bal8, Z4Cat2Bal9, 
    Z4Cat2Bal10, Z4Cat2Bal11, Z4Cat2Bal12, Z4Cat2Bal13, Z4Cat2Bal14, 
    Z4Cat2Bal15, Z4Cat2Bal16}
 
Z4Cat2 /: balancedCategory[Z4Cat2, 1] = Z4Cat2Bal1
 
Z4Cat2 /: balancedCategory[Z4Cat2, 2] = Z4Cat2Bal2
 
Z4Cat2 /: balancedCategory[Z4Cat2, 3] = Z4Cat2Bal3
 
Z4Cat2 /: balancedCategory[Z4Cat2, 4] = Z4Cat2Bal4
 
Z4Cat2 /: balancedCategory[Z4Cat2, 5] = Z4Cat2Bal5
 
Z4Cat2 /: balancedCategory[Z4Cat2, 6] = Z4Cat2Bal6
 
Z4Cat2 /: balancedCategory[Z4Cat2, 7] = Z4Cat2Bal7
 
Z4Cat2 /: balancedCategory[Z4Cat2, 8] = Z4Cat2Bal8
 
Z4Cat2 /: balancedCategory[Z4Cat2, 9] = Z4Cat2Bal9
 
Z4Cat2 /: balancedCategory[Z4Cat2, 10] = Z4Cat2Bal10
 
Z4Cat2 /: balancedCategory[Z4Cat2, 11] = Z4Cat2Bal11
 
Z4Cat2 /: balancedCategory[Z4Cat2, 12] = Z4Cat2Bal12
 
Z4Cat2 /: balancedCategory[Z4Cat2, 13] = Z4Cat2Bal13
 
Z4Cat2 /: balancedCategory[Z4Cat2, 14] = Z4Cat2Bal14
 
Z4Cat2 /: balancedCategory[Z4Cat2, 15] = Z4Cat2Bal15
 
Z4Cat2 /: balancedCategory[Z4Cat2, 16] = Z4Cat2Bal16
 
braidedCategories[Z4Cat2] ^= {Z4Cat2Brd1, Z4Cat2Brd2, Z4Cat2Brd3, Z4Cat2Brd4}
 
Z4Cat2 /: braidedCategory[Z4Cat2, 1] = Z4Cat2Brd1
 
Z4Cat2 /: braidedCategory[Z4Cat2, 2] = Z4Cat2Brd2
 
Z4Cat2 /: braidedCategory[Z4Cat2, 3] = Z4Cat2Brd3
 
Z4Cat2 /: braidedCategory[Z4Cat2, 4] = Z4Cat2Brd4
 
coeval[Z4Cat2] ^= 1/sixJFunction[Z4Cat2][#1, dual[ring[Z4Cat2]][#1], #1, #1, 
      0, 0] & 
 
eval[Z4Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[Z4Cat2] ^= Z4Cat2FMatrixFunction
 
fusionCategory[Z4Cat2] ^= Z4Cat2
 
Z4Cat2 /: modularCategory[Z4Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[Z4Cat2] ^= {Z4Cat2Piv1, Z4Cat2Piv2, Z4Cat2Piv3, Z4Cat2Piv4}
 
Z4Cat2 /: pivotalCategory[Z4Cat2, 1] = Z4Cat2Piv1
 
Z4Cat2 /: pivotalCategory[Z4Cat2, 2] = Z4Cat2Piv2
 
Z4Cat2 /: pivotalCategory[Z4Cat2, 3] = Z4Cat2Piv3
 
Z4Cat2 /: pivotalCategory[Z4Cat2, 4] = Z4Cat2Piv4
 
Z4Cat2 /: pivotalCategory[Z4Cat2, {1, -1, 1, -1}] = Z4Cat2Piv2
 
Z4Cat2 /: pivotalCategory[Z4Cat2, {1, -I, -1, I}] = Z4Cat2Piv3
 
Z4Cat2 /: pivotalCategory[Z4Cat2, {1, I, -1, -I}] = Z4Cat2Piv4
 
Z4Cat2 /: pivotalCategory[Z4Cat2, {1, 1, 1, 1}] = Z4Cat2Piv1
 
Z4Cat2 /: ribbonCategory[Z4Cat2, 1] = Z4Cat2Bal1
 
Z4Cat2 /: ribbonCategory[Z4Cat2, 2] = Z4Cat2Bal2
 
Z4Cat2 /: ribbonCategory[Z4Cat2, 3] = Z4Cat2Bal5
 
Z4Cat2 /: ribbonCategory[Z4Cat2, 4] = Z4Cat2Bal6
 
Z4Cat2 /: ribbonCategory[Z4Cat2, 5] = Z4Cat2Bal9
 
Z4Cat2 /: ribbonCategory[Z4Cat2, 6] = Z4Cat2Bal10
 
Z4Cat2 /: ribbonCategory[Z4Cat2, 7] = Z4Cat2Bal13
 
Z4Cat2 /: ribbonCategory[Z4Cat2, 8] = Z4Cat2Bal14
 
ring[Z4Cat2] ^= Z4
 
Z4Cat2 /: sphericalCategory[Z4Cat2, 1] = Z4Cat2Piv1
 
Z4Cat2 /: sphericalCategory[Z4Cat2, 2] = Z4Cat2Piv2
 
Z4Cat2 /: symmetricCategory[Z4Cat2, 1] = Z4Cat2Brd1
 
Z4Cat2 /: symmetricCategory[Z4Cat2, 2] = Z4Cat2Brd4
 
fusionCategoryIndex[Z4][Z4Cat2] ^= 2
balancedCategory[Z4Cat2Bal1] ^= Z4Cat2Bal1
 
braidedCategory[Z4Cat2Bal1] ^= Z4Cat2Brd1
 
coeval[Z4Cat2Bal1] ^= (-1)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat2Piv1][#1] & 
 
fusionCategory[Z4Cat2Bal1] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Bal1] ^= Z4Cat2Piv1
 
ribbonCategory[Z4Cat2Bal1] ^= Z4Cat2Bal1
 
ring[Z4Cat2Bal1] ^= Z4
 
sphericalCategory[Z4Cat2Bal1] ^= Z4Cat2Piv1
 
symmetricCategory[Z4Cat2Bal1] ^= Z4Cat2Brd1
 
(balancedCategoryIndex[braidedCategory[Z4Cat2Brd1]][balancedCategory[#1]] & )[
    Z4Cat2Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z4Cat2]][balancedCategory[#1]] & )[
    Z4Cat2Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[Z4Cat2Piv1]][balancedCategory[#1]] & )[
    Z4Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[Z4Cat2Brd1]][ribbonCategory[#1]] & )[
    Z4Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z4Cat2]][ribbonCategory[#1]] & )[
    Z4Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[Z4Cat2Piv1]][ribbonCategory[#1]] & )[
    Z4Cat2Bal1] ^= 1
balancedCategory[Z4Cat2Bal10] ^= Z4Cat2Bal10
 
braidedCategory[Z4Cat2Bal10] ^= Z4Cat2Brd3
 
coeval[Z4Cat2Bal10] ^= 1/sixJFunction[Z4Cat2][#1, dual[ring[Z4Cat2]][#1], #1, 
      #1, 0, 0] & 
 
fusionCategory[Z4Cat2Bal10] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Bal10] ^= Z4Cat2Piv2
 
ribbonCategory[Z4Cat2Bal10] ^= Z4Cat2Bal10
 
ring[Z4Cat2Bal10] ^= Z4
 
sphericalCategory[Z4Cat2Bal10] ^= Z4Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[Z4Cat2Brd3]][balancedCategory[#1]] & )[
    Z4Cat2Bal10] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z4Cat2]][balancedCategory[#1]] & )[
    Z4Cat2Bal10] ^= 10
 
(balancedCategoryIndex[pivotalCategory[Z4Cat2Piv2]][balancedCategory[#1]] & )[
    Z4Cat2Bal10] ^= 3
 
(ribbonCategoryIndex[braidedCategory[Z4Cat2Brd3]][ribbonCategory[#1]] & )[
    Z4Cat2Bal10] ^= 2
 
(ribbonCategoryIndex[fusionCategory[Z4Cat2]][ribbonCategory[#1]] & )[
    Z4Cat2Bal10] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[Z4Cat2Piv2]][ribbonCategory[#1]] & )[
    Z4Cat2Bal10] ^= 3
balancedCategory[Z4Cat2Bal11] ^= Z4Cat2Bal11
 
braidedCategory[Z4Cat2Bal11] ^= Z4Cat2Brd3
 
coeval[Z4Cat2Bal11] ^= I^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat2Piv3][#1] & 
 
fusionCategory[Z4Cat2Bal11] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Bal11] ^= Z4Cat2Piv3
 
ribbonCategory[Z4Cat2Bal11] ^= Z4Cat2Bal11
 
ring[Z4Cat2Bal11] ^= Z4
 
(balancedCategoryIndex[braidedCategory[Z4Cat2Brd3]][balancedCategory[#1]] & )[
    Z4Cat2Bal11] ^= 3
 
(balancedCategoryIndex[fusionCategory[Z4Cat2]][balancedCategory[#1]] & )[
    Z4Cat2Bal11] ^= 11
 
(balancedCategoryIndex[pivotalCategory[Z4Cat2Piv3]][balancedCategory[#1]] & )[
    Z4Cat2Bal11] ^= 3
balancedCategory[Z4Cat2Bal12] ^= Z4Cat2Bal12
 
braidedCategory[Z4Cat2Bal12] ^= Z4Cat2Brd3
 
coeval[Z4Cat2Bal12] ^= (-I)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat2Piv4][#1] & 
 
fusionCategory[Z4Cat2Bal12] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Bal12] ^= Z4Cat2Piv4
 
ribbonCategory[Z4Cat2Bal12] ^= Z4Cat2Bal12
 
ring[Z4Cat2Bal12] ^= Z4
 
(balancedCategoryIndex[braidedCategory[Z4Cat2Brd3]][balancedCategory[#1]] & )[
    Z4Cat2Bal12] ^= 4
 
(balancedCategoryIndex[fusionCategory[Z4Cat2]][balancedCategory[#1]] & )[
    Z4Cat2Bal12] ^= 12
 
(balancedCategoryIndex[pivotalCategory[Z4Cat2Piv4]][balancedCategory[#1]] & )[
    Z4Cat2Bal12] ^= 3
balancedCategory[Z4Cat2Bal13] ^= Z4Cat2Bal13
 
braidedCategory[Z4Cat2Bal13] ^= Z4Cat2Brd4
 
coeval[Z4Cat2Bal13] ^= (-1)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat2Piv1][#1] & 
 
fusionCategory[Z4Cat2Bal13] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Bal13] ^= Z4Cat2Piv1
 
ribbonCategory[Z4Cat2Bal13] ^= Z4Cat2Bal13
 
ring[Z4Cat2Bal13] ^= Z4
 
sphericalCategory[Z4Cat2Bal13] ^= Z4Cat2Piv1
 
symmetricCategory[Z4Cat2Bal13] ^= Z4Cat2Brd4
 
(balancedCategoryIndex[braidedCategory[Z4Cat2Brd4]][balancedCategory[#1]] & )[
    Z4Cat2Bal13] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z4Cat2]][balancedCategory[#1]] & )[
    Z4Cat2Bal13] ^= 13
 
(balancedCategoryIndex[pivotalCategory[Z4Cat2Piv1]][balancedCategory[#1]] & )[
    Z4Cat2Bal13] ^= 4
 
(ribbonCategoryIndex[braidedCategory[Z4Cat2Brd4]][ribbonCategory[#1]] & )[
    Z4Cat2Bal13] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z4Cat2]][ribbonCategory[#1]] & )[
    Z4Cat2Bal13] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[Z4Cat2Piv1]][ribbonCategory[#1]] & )[
    Z4Cat2Bal13] ^= 4
balancedCategory[Z4Cat2Bal14] ^= Z4Cat2Bal14
 
braidedCategory[Z4Cat2Bal14] ^= Z4Cat2Brd4
 
coeval[Z4Cat2Bal14] ^= 1/sixJFunction[Z4Cat2][#1, dual[ring[Z4Cat2]][#1], #1, 
      #1, 0, 0] & 
 
fusionCategory[Z4Cat2Bal14] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Bal14] ^= Z4Cat2Piv2
 
ribbonCategory[Z4Cat2Bal14] ^= Z4Cat2Bal14
 
ring[Z4Cat2Bal14] ^= Z4
 
sphericalCategory[Z4Cat2Bal14] ^= Z4Cat2Piv2
 
symmetricCategory[Z4Cat2Bal14] ^= Z4Cat2Brd4
 
(balancedCategoryIndex[braidedCategory[Z4Cat2Brd4]][balancedCategory[#1]] & )[
    Z4Cat2Bal14] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z4Cat2]][balancedCategory[#1]] & )[
    Z4Cat2Bal14] ^= 14
 
(balancedCategoryIndex[pivotalCategory[Z4Cat2Piv2]][balancedCategory[#1]] & )[
    Z4Cat2Bal14] ^= 4
 
(ribbonCategoryIndex[braidedCategory[Z4Cat2Brd4]][ribbonCategory[#1]] & )[
    Z4Cat2Bal14] ^= 2
 
(ribbonCategoryIndex[fusionCategory[Z4Cat2]][ribbonCategory[#1]] & )[
    Z4Cat2Bal14] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[Z4Cat2Piv2]][ribbonCategory[#1]] & )[
    Z4Cat2Bal14] ^= 4
balancedCategory[Z4Cat2Bal15] ^= Z4Cat2Bal15
 
braidedCategory[Z4Cat2Bal15] ^= Z4Cat2Brd4
 
coeval[Z4Cat2Bal15] ^= I^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat2Piv3][#1] & 
 
fusionCategory[Z4Cat2Bal15] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Bal15] ^= Z4Cat2Piv3
 
ribbonCategory[Z4Cat2Bal15] ^= Z4Cat2Bal15
 
ring[Z4Cat2Bal15] ^= Z4
 
symmetricCategory[Z4Cat2Bal15] ^= Z4Cat2Brd4
 
(balancedCategoryIndex[braidedCategory[Z4Cat2Brd4]][balancedCategory[#1]] & )[
    Z4Cat2Bal15] ^= 3
 
(balancedCategoryIndex[fusionCategory[Z4Cat2]][balancedCategory[#1]] & )[
    Z4Cat2Bal15] ^= 15
 
(balancedCategoryIndex[pivotalCategory[Z4Cat2Piv3]][balancedCategory[#1]] & )[
    Z4Cat2Bal15] ^= 4
balancedCategory[Z4Cat2Bal16] ^= Z4Cat2Bal16
 
braidedCategory[Z4Cat2Bal16] ^= Z4Cat2Brd4
 
coeval[Z4Cat2Bal16] ^= (-I)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat2Piv4][#1] & 
 
fusionCategory[Z4Cat2Bal16] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Bal16] ^= Z4Cat2Piv4
 
ribbonCategory[Z4Cat2Bal16] ^= Z4Cat2Bal16
 
ring[Z4Cat2Bal16] ^= Z4
 
symmetricCategory[Z4Cat2Bal16] ^= Z4Cat2Brd4
 
(balancedCategoryIndex[braidedCategory[Z4Cat2Brd4]][balancedCategory[#1]] & )[
    Z4Cat2Bal16] ^= 4
 
(balancedCategoryIndex[fusionCategory[Z4Cat2]][balancedCategory[#1]] & )[
    Z4Cat2Bal16] ^= 16
 
(balancedCategoryIndex[pivotalCategory[Z4Cat2Piv4]][balancedCategory[#1]] & )[
    Z4Cat2Bal16] ^= 4
balancedCategory[Z4Cat2Bal2] ^= Z4Cat2Bal2
 
braidedCategory[Z4Cat2Bal2] ^= Z4Cat2Brd1
 
coeval[Z4Cat2Bal2] ^= 1/sixJFunction[Z4Cat2][#1, dual[ring[Z4Cat2]][#1], #1, 
      #1, 0, 0] & 
 
fusionCategory[Z4Cat2Bal2] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Bal2] ^= Z4Cat2Piv2
 
ribbonCategory[Z4Cat2Bal2] ^= Z4Cat2Bal2
 
ring[Z4Cat2Bal2] ^= Z4
 
sphericalCategory[Z4Cat2Bal2] ^= Z4Cat2Piv2
 
symmetricCategory[Z4Cat2Bal2] ^= Z4Cat2Brd1
 
(balancedCategoryIndex[braidedCategory[Z4Cat2Brd1]][balancedCategory[#1]] & )[
    Z4Cat2Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z4Cat2]][balancedCategory[#1]] & )[
    Z4Cat2Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[Z4Cat2Piv2]][balancedCategory[#1]] & )[
    Z4Cat2Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[Z4Cat2Brd1]][ribbonCategory[#1]] & )[
    Z4Cat2Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[Z4Cat2]][ribbonCategory[#1]] & )[
    Z4Cat2Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[Z4Cat2Piv2]][ribbonCategory[#1]] & )[
    Z4Cat2Bal2] ^= 1
balancedCategory[Z4Cat2Bal3] ^= Z4Cat2Bal3
 
braidedCategory[Z4Cat2Bal3] ^= Z4Cat2Brd1
 
coeval[Z4Cat2Bal3] ^= I^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat2Piv3][#1] & 
 
fusionCategory[Z4Cat2Bal3] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Bal3] ^= Z4Cat2Piv3
 
ribbonCategory[Z4Cat2Bal3] ^= Z4Cat2Bal3
 
ring[Z4Cat2Bal3] ^= Z4
 
symmetricCategory[Z4Cat2Bal3] ^= Z4Cat2Brd1
 
(balancedCategoryIndex[braidedCategory[Z4Cat2Brd1]][balancedCategory[#1]] & )[
    Z4Cat2Bal3] ^= 3
 
(balancedCategoryIndex[fusionCategory[Z4Cat2]][balancedCategory[#1]] & )[
    Z4Cat2Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[Z4Cat2Piv3]][balancedCategory[#1]] & )[
    Z4Cat2Bal3] ^= 1
balancedCategory[Z4Cat2Bal4] ^= Z4Cat2Bal4
 
braidedCategory[Z4Cat2Bal4] ^= Z4Cat2Brd1
 
coeval[Z4Cat2Bal4] ^= (-I)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat2Piv4][#1] & 
 
fusionCategory[Z4Cat2Bal4] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Bal4] ^= Z4Cat2Piv4
 
ribbonCategory[Z4Cat2Bal4] ^= Z4Cat2Bal4
 
ring[Z4Cat2Bal4] ^= Z4
 
symmetricCategory[Z4Cat2Bal4] ^= Z4Cat2Brd1
 
(balancedCategoryIndex[braidedCategory[Z4Cat2Brd1]][balancedCategory[#1]] & )[
    Z4Cat2Bal4] ^= 4
 
(balancedCategoryIndex[fusionCategory[Z4Cat2]][balancedCategory[#1]] & )[
    Z4Cat2Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[Z4Cat2Piv4]][balancedCategory[#1]] & )[
    Z4Cat2Bal4] ^= 1
balancedCategory[Z4Cat2Bal5] ^= Z4Cat2Bal5
 
braidedCategory[Z4Cat2Bal5] ^= Z4Cat2Brd2
 
coeval[Z4Cat2Bal5] ^= (-1)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat2Piv1][#1] & 
 
fusionCategory[Z4Cat2Bal5] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Bal5] ^= Z4Cat2Piv1
 
ribbonCategory[Z4Cat2Bal5] ^= Z4Cat2Bal5
 
ring[Z4Cat2Bal5] ^= Z4
 
sphericalCategory[Z4Cat2Bal5] ^= Z4Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[Z4Cat2Brd2]][balancedCategory[#1]] & )[
    Z4Cat2Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z4Cat2]][balancedCategory[#1]] & )[
    Z4Cat2Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[Z4Cat2Piv1]][balancedCategory[#1]] & )[
    Z4Cat2Bal5] ^= 2
 
(ribbonCategoryIndex[braidedCategory[Z4Cat2Brd2]][ribbonCategory[#1]] & )[
    Z4Cat2Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z4Cat2]][ribbonCategory[#1]] & )[
    Z4Cat2Bal5] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[Z4Cat2Piv1]][ribbonCategory[#1]] & )[
    Z4Cat2Bal5] ^= 2
balancedCategory[Z4Cat2Bal6] ^= Z4Cat2Bal6
 
braidedCategory[Z4Cat2Bal6] ^= Z4Cat2Brd2
 
coeval[Z4Cat2Bal6] ^= 1/sixJFunction[Z4Cat2][#1, dual[ring[Z4Cat2]][#1], #1, 
      #1, 0, 0] & 
 
fusionCategory[Z4Cat2Bal6] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Bal6] ^= Z4Cat2Piv2
 
ribbonCategory[Z4Cat2Bal6] ^= Z4Cat2Bal6
 
ring[Z4Cat2Bal6] ^= Z4
 
sphericalCategory[Z4Cat2Bal6] ^= Z4Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[Z4Cat2Brd2]][balancedCategory[#1]] & )[
    Z4Cat2Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[Z4Cat2]][balancedCategory[#1]] & )[
    Z4Cat2Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[Z4Cat2Piv2]][balancedCategory[#1]] & )[
    Z4Cat2Bal6] ^= 2
 
(ribbonCategoryIndex[braidedCategory[Z4Cat2Brd2]][ribbonCategory[#1]] & )[
    Z4Cat2Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[Z4Cat2]][ribbonCategory[#1]] & )[
    Z4Cat2Bal6] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[Z4Cat2Piv2]][ribbonCategory[#1]] & )[
    Z4Cat2Bal6] ^= 2
balancedCategory[Z4Cat2Bal7] ^= Z4Cat2Bal7
 
braidedCategory[Z4Cat2Bal7] ^= Z4Cat2Brd2
 
coeval[Z4Cat2Bal7] ^= I^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat2Piv3][#1] & 
 
fusionCategory[Z4Cat2Bal7] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Bal7] ^= Z4Cat2Piv3
 
ribbonCategory[Z4Cat2Bal7] ^= Z4Cat2Bal7
 
ring[Z4Cat2Bal7] ^= Z4
 
(balancedCategoryIndex[braidedCategory[Z4Cat2Brd2]][balancedCategory[#1]] & )[
    Z4Cat2Bal7] ^= 3
 
(balancedCategoryIndex[fusionCategory[Z4Cat2]][balancedCategory[#1]] & )[
    Z4Cat2Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[Z4Cat2Piv3]][balancedCategory[#1]] & )[
    Z4Cat2Bal7] ^= 2
balancedCategory[Z4Cat2Bal8] ^= Z4Cat2Bal8
 
braidedCategory[Z4Cat2Bal8] ^= Z4Cat2Brd2
 
coeval[Z4Cat2Bal8] ^= (-I)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat2Piv4][#1] & 
 
fusionCategory[Z4Cat2Bal8] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Bal8] ^= Z4Cat2Piv4
 
ribbonCategory[Z4Cat2Bal8] ^= Z4Cat2Bal8
 
ring[Z4Cat2Bal8] ^= Z4
 
(balancedCategoryIndex[braidedCategory[Z4Cat2Brd2]][balancedCategory[#1]] & )[
    Z4Cat2Bal8] ^= 4
 
(balancedCategoryIndex[fusionCategory[Z4Cat2]][balancedCategory[#1]] & )[
    Z4Cat2Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[Z4Cat2Piv4]][balancedCategory[#1]] & )[
    Z4Cat2Bal8] ^= 2
balancedCategory[Z4Cat2Bal9] ^= Z4Cat2Bal9
 
braidedCategory[Z4Cat2Bal9] ^= Z4Cat2Brd3
 
coeval[Z4Cat2Bal9] ^= (-1)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat2Piv1][#1] & 
 
fusionCategory[Z4Cat2Bal9] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Bal9] ^= Z4Cat2Piv1
 
ribbonCategory[Z4Cat2Bal9] ^= Z4Cat2Bal9
 
ring[Z4Cat2Bal9] ^= Z4
 
sphericalCategory[Z4Cat2Bal9] ^= Z4Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[Z4Cat2Brd3]][balancedCategory[#1]] & )[
    Z4Cat2Bal9] ^= 1
 
(balancedCategoryIndex[fusionCategory[Z4Cat2]][balancedCategory[#1]] & )[
    Z4Cat2Bal9] ^= 9
 
(balancedCategoryIndex[pivotalCategory[Z4Cat2Piv1]][balancedCategory[#1]] & )[
    Z4Cat2Bal9] ^= 3
 
(ribbonCategoryIndex[braidedCategory[Z4Cat2Brd3]][ribbonCategory[#1]] & )[
    Z4Cat2Bal9] ^= 1
 
(ribbonCategoryIndex[fusionCategory[Z4Cat2]][ribbonCategory[#1]] & )[
    Z4Cat2Bal9] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[Z4Cat2Piv1]][ribbonCategory[#1]] & )[
    Z4Cat2Bal9] ^= 3
balancedCategories[Z4Cat2Brd1] ^= {Z4Cat2Bal1, Z4Cat2Bal2, Z4Cat2Bal3, 
    Z4Cat2Bal4}
 
Z4Cat2Brd1 /: balancedCategory[Z4Cat2Brd1, 1] = Z4Cat2Bal1
 
Z4Cat2Brd1 /: balancedCategory[Z4Cat2Brd1, 2] = Z4Cat2Bal2
 
Z4Cat2Brd1 /: balancedCategory[Z4Cat2Brd1, 3] = Z4Cat2Bal3
 
Z4Cat2Brd1 /: balancedCategory[Z4Cat2Brd1, 4] = Z4Cat2Bal4
 
braidedCategory[Z4Cat2Brd1] ^= Z4Cat2Brd1
 
fusionCategory[Z4Cat2Brd1] ^= Z4Cat2
 
Z4Cat2Brd1 /: modularCategory[Z4Cat2Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z4Cat2Brd1 /: ribbonCategory[Z4Cat2Brd1, 1] = Z4Cat2Bal1
 
Z4Cat2Brd1 /: ribbonCategory[Z4Cat2Brd1, 2] = Z4Cat2Bal2
 
ring[Z4Cat2Brd1] ^= Z4
 
rMatrixFunction[Z4Cat2Brd1] ^= Z4Cat2Brd1RMatrixFunction
 
symmetricCategory[Z4Cat2Brd1] ^= Z4Cat2Brd1
 
(braidedCategoryIndex[fusionCategory[Z4Cat2]][braidedCategory[#1]] & )[
    Z4Cat2Brd1] ^= 1
 
(symmetricCategoryIndex[fusionCategory[Z4Cat2]][symmetricCategory[#1]] & )[
    Z4Cat2Brd1] ^= 1
braidedCategory[Z4Cat2Brd1RMatrixFunction] ^= Z4Cat2Brd1
 
fusionCategory[Z4Cat2Brd1RMatrixFunction] ^= Z4Cat2
 
rMatrixFunction[Z4Cat2Brd1RMatrixFunction] ^= Z4Cat2Brd1RMatrixFunction
 
Z4Cat2Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
Z4Cat2Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
Z4Cat2Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
Z4Cat2Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
Z4Cat2Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
Z4Cat2Brd1RMatrixFunction[1, 1, 2] = {{1}}
 
Z4Cat2Brd1RMatrixFunction[1, 2, 3] = {{-1}}
 
Z4Cat2Brd1RMatrixFunction[1, 3, 0] = {{-1}}
 
Z4Cat2Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
Z4Cat2Brd1RMatrixFunction[2, 1, 3] = {{-1}}
 
Z4Cat2Brd1RMatrixFunction[2, 2, 0] = {{1}}
 
Z4Cat2Brd1RMatrixFunction[2, 3, 1] = {{-1}}
 
Z4Cat2Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
Z4Cat2Brd1RMatrixFunction[3, 1, 0] = {{-1}}
 
Z4Cat2Brd1RMatrixFunction[3, 2, 1] = {{-1}}
 
Z4Cat2Brd1RMatrixFunction[3, 3, 2] = {{1}}
balancedCategories[Z4Cat2Brd2] ^= {Z4Cat2Bal5, Z4Cat2Bal6, Z4Cat2Bal7, 
    Z4Cat2Bal8}
 
Z4Cat2Brd2 /: balancedCategory[Z4Cat2Brd2, 1] = Z4Cat2Bal5
 
Z4Cat2Brd2 /: balancedCategory[Z4Cat2Brd2, 2] = Z4Cat2Bal6
 
Z4Cat2Brd2 /: balancedCategory[Z4Cat2Brd2, 3] = Z4Cat2Bal7
 
Z4Cat2Brd2 /: balancedCategory[Z4Cat2Brd2, 4] = Z4Cat2Bal8
 
braidedCategory[Z4Cat2Brd2] ^= Z4Cat2Brd2
 
fusionCategory[Z4Cat2Brd2] ^= Z4Cat2
 
Z4Cat2Brd2 /: modularCategory[Z4Cat2Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z4Cat2Brd2 /: ribbonCategory[Z4Cat2Brd2, 1] = Z4Cat2Bal5
 
Z4Cat2Brd2 /: ribbonCategory[Z4Cat2Brd2, 2] = Z4Cat2Bal6
 
ring[Z4Cat2Brd2] ^= Z4
 
rMatrixFunction[Z4Cat2Brd2] ^= Z4Cat2Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[Z4Cat2]][braidedCategory[#1]] & )[
    Z4Cat2Brd2] ^= 2
braidedCategory[Z4Cat2Brd2RMatrixFunction] ^= Z4Cat2Brd2
 
fusionCategory[Z4Cat2Brd2RMatrixFunction] ^= Z4Cat2
 
rMatrixFunction[Z4Cat2Brd2RMatrixFunction] ^= Z4Cat2Brd2RMatrixFunction
 
Z4Cat2Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
Z4Cat2Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
Z4Cat2Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
Z4Cat2Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
Z4Cat2Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
Z4Cat2Brd2RMatrixFunction[1, 1, 2] = {{-I}}
 
Z4Cat2Brd2RMatrixFunction[1, 2, 3] = {{1}}
 
Z4Cat2Brd2RMatrixFunction[1, 3, 0] = {{-I}}
 
Z4Cat2Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
Z4Cat2Brd2RMatrixFunction[2, 1, 3] = {{1}}
 
Z4Cat2Brd2RMatrixFunction[2, 2, 0] = {{1}}
 
Z4Cat2Brd2RMatrixFunction[2, 3, 1] = {{1}}
 
Z4Cat2Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
Z4Cat2Brd2RMatrixFunction[3, 1, 0] = {{-I}}
 
Z4Cat2Brd2RMatrixFunction[3, 2, 1] = {{1}}
 
Z4Cat2Brd2RMatrixFunction[3, 3, 2] = {{-I}}
balancedCategories[Z4Cat2Brd3] ^= {Z4Cat2Bal9, Z4Cat2Bal10, Z4Cat2Bal11, 
    Z4Cat2Bal12}
 
Z4Cat2Brd3 /: balancedCategory[Z4Cat2Brd3, 1] = Z4Cat2Bal9
 
Z4Cat2Brd3 /: balancedCategory[Z4Cat2Brd3, 2] = Z4Cat2Bal10
 
Z4Cat2Brd3 /: balancedCategory[Z4Cat2Brd3, 3] = Z4Cat2Bal11
 
Z4Cat2Brd3 /: balancedCategory[Z4Cat2Brd3, 4] = Z4Cat2Bal12
 
braidedCategory[Z4Cat2Brd3] ^= Z4Cat2Brd3
 
fusionCategory[Z4Cat2Brd3] ^= Z4Cat2
 
Z4Cat2Brd3 /: modularCategory[Z4Cat2Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z4Cat2Brd3 /: ribbonCategory[Z4Cat2Brd3, 1] = Z4Cat2Bal9
 
Z4Cat2Brd3 /: ribbonCategory[Z4Cat2Brd3, 2] = Z4Cat2Bal10
 
ring[Z4Cat2Brd3] ^= Z4
 
rMatrixFunction[Z4Cat2Brd3] ^= Z4Cat2Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[Z4Cat2]][braidedCategory[#1]] & )[
    Z4Cat2Brd3] ^= 3
braidedCategory[Z4Cat2Brd3RMatrixFunction] ^= Z4Cat2Brd3
 
fusionCategory[Z4Cat2Brd3RMatrixFunction] ^= Z4Cat2
 
rMatrixFunction[Z4Cat2Brd3RMatrixFunction] ^= Z4Cat2Brd3RMatrixFunction
 
Z4Cat2Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
Z4Cat2Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
Z4Cat2Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
Z4Cat2Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
Z4Cat2Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
Z4Cat2Brd3RMatrixFunction[1, 1, 2] = {{I}}
 
Z4Cat2Brd3RMatrixFunction[1, 2, 3] = {{1}}
 
Z4Cat2Brd3RMatrixFunction[1, 3, 0] = {{I}}
 
Z4Cat2Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
Z4Cat2Brd3RMatrixFunction[2, 1, 3] = {{1}}
 
Z4Cat2Brd3RMatrixFunction[2, 2, 0] = {{1}}
 
Z4Cat2Brd3RMatrixFunction[2, 3, 1] = {{1}}
 
Z4Cat2Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
Z4Cat2Brd3RMatrixFunction[3, 1, 0] = {{I}}
 
Z4Cat2Brd3RMatrixFunction[3, 2, 1] = {{1}}
 
Z4Cat2Brd3RMatrixFunction[3, 3, 2] = {{I}}
balancedCategories[Z4Cat2Brd4] ^= {Z4Cat2Bal13, Z4Cat2Bal14, Z4Cat2Bal15, 
    Z4Cat2Bal16}
 
Z4Cat2Brd4 /: balancedCategory[Z4Cat2Brd4, 1] = Z4Cat2Bal13
 
Z4Cat2Brd4 /: balancedCategory[Z4Cat2Brd4, 2] = Z4Cat2Bal14
 
Z4Cat2Brd4 /: balancedCategory[Z4Cat2Brd4, 3] = Z4Cat2Bal15
 
Z4Cat2Brd4 /: balancedCategory[Z4Cat2Brd4, 4] = Z4Cat2Bal16
 
braidedCategory[Z4Cat2Brd4] ^= Z4Cat2Brd4
 
fusionCategory[Z4Cat2Brd4] ^= Z4Cat2
 
Z4Cat2Brd4 /: modularCategory[Z4Cat2Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
Z4Cat2Brd4 /: ribbonCategory[Z4Cat2Brd4, 1] = Z4Cat2Bal13
 
Z4Cat2Brd4 /: ribbonCategory[Z4Cat2Brd4, 2] = Z4Cat2Bal14
 
ring[Z4Cat2Brd4] ^= Z4
 
rMatrixFunction[Z4Cat2Brd4] ^= Z4Cat2Brd4RMatrixFunction
 
symmetricCategory[Z4Cat2Brd4] ^= Z4Cat2Brd4
 
(braidedCategoryIndex[fusionCategory[Z4Cat2]][braidedCategory[#1]] & )[
    Z4Cat2Brd4] ^= 4
 
(symmetricCategoryIndex[fusionCategory[Z4Cat2]][symmetricCategory[#1]] & )[
    Z4Cat2Brd4] ^= 2
braidedCategory[Z4Cat2Brd4RMatrixFunction] ^= Z4Cat2Brd4
 
fusionCategory[Z4Cat2Brd4RMatrixFunction] ^= Z4Cat2
 
rMatrixFunction[Z4Cat2Brd4RMatrixFunction] ^= Z4Cat2Brd4RMatrixFunction
 
Z4Cat2Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
Z4Cat2Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
Z4Cat2Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
Z4Cat2Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
Z4Cat2Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
Z4Cat2Brd4RMatrixFunction[1, 1, 2] = {{-1}}
 
Z4Cat2Brd4RMatrixFunction[1, 2, 3] = {{-1}}
 
Z4Cat2Brd4RMatrixFunction[1, 3, 0] = {{1}}
 
Z4Cat2Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
Z4Cat2Brd4RMatrixFunction[2, 1, 3] = {{-1}}
 
Z4Cat2Brd4RMatrixFunction[2, 2, 0] = {{1}}
 
Z4Cat2Brd4RMatrixFunction[2, 3, 1] = {{-1}}
 
Z4Cat2Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
Z4Cat2Brd4RMatrixFunction[3, 1, 0] = {{1}}
 
Z4Cat2Brd4RMatrixFunction[3, 2, 1] = {{-1}}
 
Z4Cat2Brd4RMatrixFunction[3, 3, 2] = {{-1}}
fMatrixFunction[Z4Cat2FMatrixFunction] ^= Z4Cat2FMatrixFunction
 
fusionCategory[Z4Cat2FMatrixFunction] ^= Z4Cat2
 
ring[Z4Cat2FMatrixFunction] ^= Z4
 
Z4Cat2FMatrixFunction[1, 1, 1, 3] = {{-1}}
 
Z4Cat2FMatrixFunction[1, 2, 2, 1] = {{-1}}
 
Z4Cat2FMatrixFunction[1, 3, 1, 1] = {{-1}}
 
Z4Cat2FMatrixFunction[1, 3, 2, 2] = {{-1}}
 
Z4Cat2FMatrixFunction[2, 1, 3, 2] = {{-1}}
 
Z4Cat2FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
Z4Cat2FMatrixFunction[2, 2, 3, 3] = {{-1}}
 
Z4Cat2FMatrixFunction[2, 3, 1, 2] = {{-1}}
 
Z4Cat2FMatrixFunction[3, 1, 2, 2] = {{-1}}
 
Z4Cat2FMatrixFunction[3, 1, 3, 3] = {{-1}}
 
Z4Cat2FMatrixFunction[3, 2, 2, 3] = {{-1}}
 
Z4Cat2FMatrixFunction[3, 3, 3, 1] = {{-1}}
 
Z4Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z4Cat2], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
Z4Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z4Cat2], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[Z4Cat2Piv1] ^= {Z4Cat2Bal1, Z4Cat2Bal5, Z4Cat2Bal9, 
    Z4Cat2Bal13}
 
Z4Cat2Piv1 /: balancedCategory[Z4Cat2Piv1, 1] = Z4Cat2Bal1
 
Z4Cat2Piv1 /: balancedCategory[Z4Cat2Piv1, 2] = Z4Cat2Bal5
 
Z4Cat2Piv1 /: balancedCategory[Z4Cat2Piv1, 3] = Z4Cat2Bal9
 
Z4Cat2Piv1 /: balancedCategory[Z4Cat2Piv1, 4] = Z4Cat2Bal13
 
coeval[Z4Cat2Piv1] ^= (-1)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat2Piv1][#1] & 
 
fusionCategory[Z4Cat2Piv1] ^= Z4Cat2
 
Z4Cat2Piv1 /: modularCategory[Z4Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z4Cat2Piv1] ^= Z4Cat2Piv1
 
pivotalIsomorphism[Z4Cat2Piv1] ^= Z4Cat2Piv1PivotalIsomorphism
 
Z4Cat2Piv1 /: ribbonCategory[Z4Cat2Piv1, 1] = Z4Cat2Bal1
 
Z4Cat2Piv1 /: ribbonCategory[Z4Cat2Piv1, 2] = Z4Cat2Bal5
 
Z4Cat2Piv1 /: ribbonCategory[Z4Cat2Piv1, 3] = Z4Cat2Bal9
 
Z4Cat2Piv1 /: ribbonCategory[Z4Cat2Piv1, 4] = Z4Cat2Bal13
 
ring[Z4Cat2Piv1] ^= Z4
 
sphericalCategory[Z4Cat2Piv1] ^= Z4Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[Z4Cat2]][pivotalCategory[#1]] & )[
    Z4Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[Z4Cat2]][sphericalCategory[#1]] & )[
    Z4Cat2Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z4Cat2Piv1PivotalIsomorphism] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Piv1PivotalIsomorphism] ^= Z4Cat2Piv1
 
pivotalIsomorphism[Z4Cat2Piv1PivotalIsomorphism] ^= 
   Z4Cat2Piv1PivotalIsomorphism
 
Z4Cat2Piv1PivotalIsomorphism[0] = 1
 
Z4Cat2Piv1PivotalIsomorphism[1] = 1
 
Z4Cat2Piv1PivotalIsomorphism[2] = 1
 
Z4Cat2Piv1PivotalIsomorphism[3] = 1
balancedCategories[Z4Cat2Piv2] ^= {Z4Cat2Bal2, Z4Cat2Bal6, Z4Cat2Bal10, 
    Z4Cat2Bal14}
 
Z4Cat2Piv2 /: balancedCategory[Z4Cat2Piv2, 1] = Z4Cat2Bal2
 
Z4Cat2Piv2 /: balancedCategory[Z4Cat2Piv2, 2] = Z4Cat2Bal6
 
Z4Cat2Piv2 /: balancedCategory[Z4Cat2Piv2, 3] = Z4Cat2Bal10
 
Z4Cat2Piv2 /: balancedCategory[Z4Cat2Piv2, 4] = Z4Cat2Bal14
 
fusionCategory[Z4Cat2Piv2] ^= Z4Cat2
 
Z4Cat2Piv2 /: modularCategory[Z4Cat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z4Cat2Piv2] ^= Z4Cat2Piv2
 
pivotalIsomorphism[Z4Cat2Piv2] ^= Z4Cat2Piv2PivotalIsomorphism
 
Z4Cat2Piv2 /: ribbonCategory[Z4Cat2Piv2, 1] = Z4Cat2Bal2
 
Z4Cat2Piv2 /: ribbonCategory[Z4Cat2Piv2, 2] = Z4Cat2Bal6
 
Z4Cat2Piv2 /: ribbonCategory[Z4Cat2Piv2, 3] = Z4Cat2Bal10
 
Z4Cat2Piv2 /: ribbonCategory[Z4Cat2Piv2, 4] = Z4Cat2Bal14
 
ring[Z4Cat2Piv2] ^= Z4
 
sphericalCategory[Z4Cat2Piv2] ^= Z4Cat2Piv2
 
(pivotalCategoryIndex[fusionCategory[Z4Cat2]][pivotalCategory[#1]] & )[
    Z4Cat2Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[Z4Cat2]][sphericalCategory[#1]] & )[
    Z4Cat2Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z4Cat2Piv2PivotalIsomorphism] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Piv2PivotalIsomorphism] ^= Z4Cat2Piv2
 
pivotalIsomorphism[Z4Cat2Piv2PivotalIsomorphism] ^= 
   Z4Cat2Piv2PivotalIsomorphism
 
Z4Cat2Piv2PivotalIsomorphism[0] = 1
 
Z4Cat2Piv2PivotalIsomorphism[1] = -1
 
Z4Cat2Piv2PivotalIsomorphism[2] = 1
 
Z4Cat2Piv2PivotalIsomorphism[3] = -1
balancedCategories[Z4Cat2Piv3] ^= {Z4Cat2Bal3, Z4Cat2Bal7, Z4Cat2Bal11, 
    Z4Cat2Bal15}
 
Z4Cat2Piv3 /: balancedCategory[Z4Cat2Piv3, 1] = Z4Cat2Bal3
 
Z4Cat2Piv3 /: balancedCategory[Z4Cat2Piv3, 2] = Z4Cat2Bal7
 
Z4Cat2Piv3 /: balancedCategory[Z4Cat2Piv3, 3] = Z4Cat2Bal11
 
Z4Cat2Piv3 /: balancedCategory[Z4Cat2Piv3, 4] = Z4Cat2Bal15
 
coeval[Z4Cat2Piv3] ^= I^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat2Piv3][#1] & 
 
fusionCategory[Z4Cat2Piv3] ^= Z4Cat2
 
Z4Cat2Piv3 /: modularCategory[Z4Cat2Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z4Cat2Piv3] ^= Z4Cat2Piv3
 
pivotalIsomorphism[Z4Cat2Piv3] ^= Z4Cat2Piv3PivotalIsomorphism
 
ring[Z4Cat2Piv3] ^= Z4
 
(pivotalCategoryIndex[fusionCategory[Z4Cat2]][pivotalCategory[#1]] & )[
    Z4Cat2Piv3] ^= 3
fusionCategory[Z4Cat2Piv3PivotalIsomorphism] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Piv3PivotalIsomorphism] ^= Z4Cat2Piv3
 
pivotalIsomorphism[Z4Cat2Piv3PivotalIsomorphism] ^= 
   Z4Cat2Piv3PivotalIsomorphism
 
Z4Cat2Piv3PivotalIsomorphism[0] = 1
 
Z4Cat2Piv3PivotalIsomorphism[1] = -I
 
Z4Cat2Piv3PivotalIsomorphism[2] = -1
 
Z4Cat2Piv3PivotalIsomorphism[3] = I
balancedCategories[Z4Cat2Piv4] ^= {Z4Cat2Bal4, Z4Cat2Bal8, Z4Cat2Bal12, 
    Z4Cat2Bal16}
 
Z4Cat2Piv4 /: balancedCategory[Z4Cat2Piv4, 1] = Z4Cat2Bal4
 
Z4Cat2Piv4 /: balancedCategory[Z4Cat2Piv4, 2] = Z4Cat2Bal8
 
Z4Cat2Piv4 /: balancedCategory[Z4Cat2Piv4, 3] = Z4Cat2Bal12
 
Z4Cat2Piv4 /: balancedCategory[Z4Cat2Piv4, 4] = Z4Cat2Bal16
 
coeval[Z4Cat2Piv4] ^= (-I)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat2Piv4][#1] & 
 
fusionCategory[Z4Cat2Piv4] ^= Z4Cat2
 
Z4Cat2Piv4 /: modularCategory[Z4Cat2Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z4Cat2Piv4] ^= Z4Cat2Piv4
 
pivotalIsomorphism[Z4Cat2Piv4] ^= Z4Cat2Piv4PivotalIsomorphism
 
ring[Z4Cat2Piv4] ^= Z4
 
(pivotalCategoryIndex[fusionCategory[Z4Cat2]][pivotalCategory[#1]] & )[
    Z4Cat2Piv4] ^= 4
fusionCategory[Z4Cat2Piv4PivotalIsomorphism] ^= Z4Cat2
 
pivotalCategory[Z4Cat2Piv4PivotalIsomorphism] ^= Z4Cat2Piv4
 
pivotalIsomorphism[Z4Cat2Piv4PivotalIsomorphism] ^= 
   Z4Cat2Piv4PivotalIsomorphism
 
Z4Cat2Piv4PivotalIsomorphism[0] = 1
 
Z4Cat2Piv4PivotalIsomorphism[1] = I
 
Z4Cat2Piv4PivotalIsomorphism[2] = -1
 
Z4Cat2Piv4PivotalIsomorphism[3] = -I
balancedCategories[Z4Cat3] ^= {}
 
braidedCategories[Z4Cat3] ^= {}
 
coeval[Z4Cat3] ^= 1/sixJFunction[Z4Cat3][#1, dual[ring[Z4Cat3]][#1], #1, #1, 
      0, 0] & 
 
eval[Z4Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[Z4Cat3] ^= Z4Cat3FMatrixFunction
 
fusionCategory[Z4Cat3] ^= Z4Cat3
 
Z4Cat3 /: modularCategory[Z4Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[Z4Cat3] ^= {Z4Cat3Piv1, Z4Cat3Piv2, Z4Cat3Piv3, Z4Cat3Piv4}
 
Z4Cat3 /: pivotalCategory[Z4Cat3, 1] = Z4Cat3Piv1
 
Z4Cat3 /: pivotalCategory[Z4Cat3, 2] = Z4Cat3Piv2
 
Z4Cat3 /: pivotalCategory[Z4Cat3, 3] = Z4Cat3Piv3
 
Z4Cat3 /: pivotalCategory[Z4Cat3, 4] = Z4Cat3Piv4
 
Z4Cat3 /: pivotalCategory[Z4Cat3, {1, -1, 1, -1}] = Z4Cat3Piv2
 
Z4Cat3 /: pivotalCategory[Z4Cat3, {1, -I, -1, I}] = Z4Cat3Piv3
 
Z4Cat3 /: pivotalCategory[Z4Cat3, {1, I, -1, -I}] = Z4Cat3Piv4
 
Z4Cat3 /: pivotalCategory[Z4Cat3, {1, 1, 1, 1}] = Z4Cat3Piv1
 
ring[Z4Cat3] ^= Z4
 
Z4Cat3 /: sphericalCategory[Z4Cat3, 1] = Z4Cat3Piv3
 
Z4Cat3 /: sphericalCategory[Z4Cat3, 2] = Z4Cat3Piv4
 
fusionCategoryIndex[Z4][Z4Cat3] ^= 3
fMatrixFunction[Z4Cat3FMatrixFunction] ^= Z4Cat3FMatrixFunction
 
fusionCategory[Z4Cat3FMatrixFunction] ^= Z4Cat3
 
ring[Z4Cat3FMatrixFunction] ^= Z4
 
Z4Cat3FMatrixFunction[1, 2, 2, 1] = {{-I}}
 
Z4Cat3FMatrixFunction[1, 2, 3, 2] = {{I}}
 
Z4Cat3FMatrixFunction[1, 3, 1, 1] = {{-I}}
 
Z4Cat3FMatrixFunction[1, 3, 2, 2] = {{-I}}
 
Z4Cat3FMatrixFunction[2, 1, 2, 1] = {{-I}}
 
Z4Cat3FMatrixFunction[2, 1, 3, 2] = {{I}}
 
Z4Cat3FMatrixFunction[2, 2, 1, 1] = {{-I}}
 
Z4Cat3FMatrixFunction[2, 2, 2, 2] = {{-1}}
 
Z4Cat3FMatrixFunction[2, 2, 3, 3] = {{I}}
 
Z4Cat3FMatrixFunction[2, 3, 1, 2] = {{-I}}
 
Z4Cat3FMatrixFunction[2, 3, 2, 3] = {{-I}}
 
Z4Cat3FMatrixFunction[3, 1, 2, 2] = {{I}}
 
Z4Cat3FMatrixFunction[3, 1, 3, 3] = {{I}}
 
Z4Cat3FMatrixFunction[3, 2, 1, 2] = {{I}}
 
Z4Cat3FMatrixFunction[3, 2, 2, 3] = {{I}}
 
Z4Cat3FMatrixFunction[3, 3, 3, 1] = {{-1}}
 
Z4Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z4Cat3], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
Z4Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z4Cat3], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[Z4Cat3Piv1] ^= {}
 
coeval[Z4Cat3Piv1] ^= (-I)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat3Piv1][#1] & 
 
fusionCategory[Z4Cat3Piv1] ^= Z4Cat3
 
Z4Cat3Piv1 /: modularCategory[Z4Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z4Cat3Piv1] ^= Z4Cat3Piv1
 
pivotalIsomorphism[Z4Cat3Piv1] ^= Z4Cat3Piv1PivotalIsomorphism
 
ring[Z4Cat3Piv1] ^= Z4
 
(pivotalCategoryIndex[fusionCategory[Z4Cat3]][pivotalCategory[#1]] & )[
    Z4Cat3Piv1] ^= 1
fusionCategory[Z4Cat3Piv1PivotalIsomorphism] ^= Z4Cat3
 
pivotalCategory[Z4Cat3Piv1PivotalIsomorphism] ^= Z4Cat3Piv1
 
pivotalIsomorphism[Z4Cat3Piv1PivotalIsomorphism] ^= 
   Z4Cat3Piv1PivotalIsomorphism
 
Z4Cat3Piv1PivotalIsomorphism[0] = 1
 
Z4Cat3Piv1PivotalIsomorphism[1] = 1
 
Z4Cat3Piv1PivotalIsomorphism[2] = 1
 
Z4Cat3Piv1PivotalIsomorphism[3] = 1
balancedCategories[Z4Cat3Piv2] ^= {}
 
coeval[Z4Cat3Piv2] ^= I^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat3Piv2][#1] & 
 
fusionCategory[Z4Cat3Piv2] ^= Z4Cat3
 
Z4Cat3Piv2 /: modularCategory[Z4Cat3Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z4Cat3Piv2] ^= Z4Cat3Piv2
 
pivotalIsomorphism[Z4Cat3Piv2] ^= Z4Cat3Piv2PivotalIsomorphism
 
ring[Z4Cat3Piv2] ^= Z4
 
(pivotalCategoryIndex[fusionCategory[Z4Cat3]][pivotalCategory[#1]] & )[
    Z4Cat3Piv2] ^= 2
fusionCategory[Z4Cat3Piv2PivotalIsomorphism] ^= Z4Cat3
 
pivotalCategory[Z4Cat3Piv2PivotalIsomorphism] ^= Z4Cat3Piv2
 
pivotalIsomorphism[Z4Cat3Piv2PivotalIsomorphism] ^= 
   Z4Cat3Piv2PivotalIsomorphism
 
Z4Cat3Piv2PivotalIsomorphism[0] = 1
 
Z4Cat3Piv2PivotalIsomorphism[1] = -1
 
Z4Cat3Piv2PivotalIsomorphism[2] = 1
 
Z4Cat3Piv2PivotalIsomorphism[3] = -1
balancedCategories[Z4Cat3Piv3] ^= {}
 
coeval[Z4Cat3Piv3] ^= (-1)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat3Piv3][#1] & 
 
fusionCategory[Z4Cat3Piv3] ^= Z4Cat3
 
Z4Cat3Piv3 /: modularCategory[Z4Cat3Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z4Cat3Piv3] ^= Z4Cat3Piv3
 
pivotalIsomorphism[Z4Cat3Piv3] ^= Z4Cat3Piv3PivotalIsomorphism
 
ring[Z4Cat3Piv3] ^= Z4
 
sphericalCategory[Z4Cat3Piv3] ^= Z4Cat3Piv3
 
(pivotalCategoryIndex[fusionCategory[Z4Cat3]][pivotalCategory[#1]] & )[
    Z4Cat3Piv3] ^= 3
 
(sphericalCategoryIndex[fusionCategory[Z4Cat3]][sphericalCategory[#1]] & )[
    Z4Cat3Piv3] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z4Cat3Piv3PivotalIsomorphism] ^= Z4Cat3
 
pivotalCategory[Z4Cat3Piv3PivotalIsomorphism] ^= Z4Cat3Piv3
 
pivotalIsomorphism[Z4Cat3Piv3PivotalIsomorphism] ^= 
   Z4Cat3Piv3PivotalIsomorphism
 
Z4Cat3Piv3PivotalIsomorphism[0] = 1
 
Z4Cat3Piv3PivotalIsomorphism[1] = -I
 
Z4Cat3Piv3PivotalIsomorphism[2] = -1
 
Z4Cat3Piv3PivotalIsomorphism[3] = I
balancedCategories[Z4Cat3Piv4] ^= {}
 
fusionCategory[Z4Cat3Piv4] ^= Z4Cat3
 
Z4Cat3Piv4 /: modularCategory[Z4Cat3Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z4Cat3Piv4] ^= Z4Cat3Piv4
 
pivotalIsomorphism[Z4Cat3Piv4] ^= Z4Cat3Piv4PivotalIsomorphism
 
ring[Z4Cat3Piv4] ^= Z4
 
sphericalCategory[Z4Cat3Piv4] ^= Z4Cat3Piv4
 
(pivotalCategoryIndex[fusionCategory[Z4Cat3]][pivotalCategory[#1]] & )[
    Z4Cat3Piv4] ^= 4
 
(sphericalCategoryIndex[fusionCategory[Z4Cat3]][sphericalCategory[#1]] & )[
    Z4Cat3Piv4] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z4Cat3Piv4PivotalIsomorphism] ^= Z4Cat3
 
pivotalCategory[Z4Cat3Piv4PivotalIsomorphism] ^= Z4Cat3Piv4
 
pivotalIsomorphism[Z4Cat3Piv4PivotalIsomorphism] ^= 
   Z4Cat3Piv4PivotalIsomorphism
 
Z4Cat3Piv4PivotalIsomorphism[0] = 1
 
Z4Cat3Piv4PivotalIsomorphism[1] = I
 
Z4Cat3Piv4PivotalIsomorphism[2] = -1
 
Z4Cat3Piv4PivotalIsomorphism[3] = -I
balancedCategories[Z4Cat4] ^= {}
 
braidedCategories[Z4Cat4] ^= {}
 
coeval[Z4Cat4] ^= 1/sixJFunction[Z4Cat4][#1, dual[ring[Z4Cat4]][#1], #1, #1, 
      0, 0] & 
 
eval[Z4Cat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[Z4Cat4] ^= Z4Cat4FMatrixFunction
 
fusionCategory[Z4Cat4] ^= Z4Cat4
 
Z4Cat4 /: modularCategory[Z4Cat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[Z4Cat4] ^= {Z4Cat4Piv1, Z4Cat4Piv2, Z4Cat4Piv3, Z4Cat4Piv4}
 
Z4Cat4 /: pivotalCategory[Z4Cat4, 1] = Z4Cat4Piv1
 
Z4Cat4 /: pivotalCategory[Z4Cat4, 2] = Z4Cat4Piv2
 
Z4Cat4 /: pivotalCategory[Z4Cat4, 3] = Z4Cat4Piv3
 
Z4Cat4 /: pivotalCategory[Z4Cat4, 4] = Z4Cat4Piv4
 
Z4Cat4 /: pivotalCategory[Z4Cat4, {1, -1, 1, -1}] = Z4Cat4Piv2
 
Z4Cat4 /: pivotalCategory[Z4Cat4, {1, -I, -1, I}] = Z4Cat4Piv3
 
Z4Cat4 /: pivotalCategory[Z4Cat4, {1, I, -1, -I}] = Z4Cat4Piv4
 
Z4Cat4 /: pivotalCategory[Z4Cat4, {1, 1, 1, 1}] = Z4Cat4Piv1
 
ring[Z4Cat4] ^= Z4
 
Z4Cat4 /: sphericalCategory[Z4Cat4, 1] = Z4Cat4Piv3
 
Z4Cat4 /: sphericalCategory[Z4Cat4, 2] = Z4Cat4Piv4
 
fusionCategoryIndex[Z4][Z4Cat4] ^= 4
fMatrixFunction[Z4Cat4FMatrixFunction] ^= Z4Cat4FMatrixFunction
 
fusionCategory[Z4Cat4FMatrixFunction] ^= Z4Cat4
 
ring[Z4Cat4FMatrixFunction] ^= Z4
 
Z4Cat4FMatrixFunction[1, 1, 1, 3] = {{-1}}
 
Z4Cat4FMatrixFunction[1, 2, 2, 1] = {{-I}}
 
Z4Cat4FMatrixFunction[1, 2, 3, 2] = {{-I}}
 
Z4Cat4FMatrixFunction[1, 3, 1, 1] = {{-I}}
 
Z4Cat4FMatrixFunction[1, 3, 2, 2] = {{-I}}
 
Z4Cat4FMatrixFunction[2, 1, 2, 1] = {{I}}
 
Z4Cat4FMatrixFunction[2, 1, 3, 2] = {{I}}
 
Z4Cat4FMatrixFunction[2, 2, 1, 1] = {{-I}}
 
Z4Cat4FMatrixFunction[2, 2, 2, 2] = {{-1}}
 
Z4Cat4FMatrixFunction[2, 2, 3, 3] = {{I}}
 
Z4Cat4FMatrixFunction[2, 3, 1, 2] = {{-I}}
 
Z4Cat4FMatrixFunction[2, 3, 2, 3] = {{I}}
 
Z4Cat4FMatrixFunction[3, 1, 2, 2] = {{I}}
 
Z4Cat4FMatrixFunction[3, 1, 3, 3] = {{I}}
 
Z4Cat4FMatrixFunction[3, 2, 1, 2] = {{-I}}
 
Z4Cat4FMatrixFunction[3, 2, 2, 3] = {{I}}
 
Z4Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z4Cat4], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
Z4Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[Z4Cat4], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[Z4Cat4Piv1] ^= {}
 
coeval[Z4Cat4Piv1] ^= (-I)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat4Piv1][#1] & 
 
fusionCategory[Z4Cat4Piv1] ^= Z4Cat4
 
Z4Cat4Piv1 /: modularCategory[Z4Cat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z4Cat4Piv1] ^= Z4Cat4Piv1
 
pivotalIsomorphism[Z4Cat4Piv1] ^= Z4Cat4Piv1PivotalIsomorphism
 
ring[Z4Cat4Piv1] ^= Z4
 
(pivotalCategoryIndex[fusionCategory[Z4Cat4]][pivotalCategory[#1]] & )[
    Z4Cat4Piv1] ^= 1
fusionCategory[Z4Cat4Piv1PivotalIsomorphism] ^= Z4Cat4
 
pivotalCategory[Z4Cat4Piv1PivotalIsomorphism] ^= Z4Cat4Piv1
 
pivotalIsomorphism[Z4Cat4Piv1PivotalIsomorphism] ^= 
   Z4Cat4Piv1PivotalIsomorphism
 
Z4Cat4Piv1PivotalIsomorphism[0] = 1
 
Z4Cat4Piv1PivotalIsomorphism[1] = 1
 
Z4Cat4Piv1PivotalIsomorphism[2] = 1
 
Z4Cat4Piv1PivotalIsomorphism[3] = 1
balancedCategories[Z4Cat4Piv2] ^= {}
 
coeval[Z4Cat4Piv2] ^= I^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat4Piv2][#1] & 
 
fusionCategory[Z4Cat4Piv2] ^= Z4Cat4
 
Z4Cat4Piv2 /: modularCategory[Z4Cat4Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z4Cat4Piv2] ^= Z4Cat4Piv2
 
pivotalIsomorphism[Z4Cat4Piv2] ^= Z4Cat4Piv2PivotalIsomorphism
 
ring[Z4Cat4Piv2] ^= Z4
 
(pivotalCategoryIndex[fusionCategory[Z4Cat4]][pivotalCategory[#1]] & )[
    Z4Cat4Piv2] ^= 2
fusionCategory[Z4Cat4Piv2PivotalIsomorphism] ^= Z4Cat4
 
pivotalCategory[Z4Cat4Piv2PivotalIsomorphism] ^= Z4Cat4Piv2
 
pivotalIsomorphism[Z4Cat4Piv2PivotalIsomorphism] ^= 
   Z4Cat4Piv2PivotalIsomorphism
 
Z4Cat4Piv2PivotalIsomorphism[0] = 1
 
Z4Cat4Piv2PivotalIsomorphism[1] = -1
 
Z4Cat4Piv2PivotalIsomorphism[2] = 1
 
Z4Cat4Piv2PivotalIsomorphism[3] = -1
balancedCategories[Z4Cat4Piv3] ^= {}
 
coeval[Z4Cat4Piv3] ^= (-1)^#1*FusionCategories`Private`defaultGaugeCoeval[
       Z4Cat4Piv3][#1] & 
 
fusionCategory[Z4Cat4Piv3] ^= Z4Cat4
 
Z4Cat4Piv3 /: modularCategory[Z4Cat4Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z4Cat4Piv3] ^= Z4Cat4Piv3
 
pivotalIsomorphism[Z4Cat4Piv3] ^= Z4Cat4Piv3PivotalIsomorphism
 
ring[Z4Cat4Piv3] ^= Z4
 
sphericalCategory[Z4Cat4Piv3] ^= Z4Cat4Piv3
 
(pivotalCategoryIndex[fusionCategory[Z4Cat4]][pivotalCategory[#1]] & )[
    Z4Cat4Piv3] ^= 3
 
(sphericalCategoryIndex[fusionCategory[Z4Cat4]][sphericalCategory[#1]] & )[
    Z4Cat4Piv3] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z4Cat4Piv3PivotalIsomorphism] ^= Z4Cat4
 
pivotalCategory[Z4Cat4Piv3PivotalIsomorphism] ^= Z4Cat4Piv3
 
pivotalIsomorphism[Z4Cat4Piv3PivotalIsomorphism] ^= 
   Z4Cat4Piv3PivotalIsomorphism
 
Z4Cat4Piv3PivotalIsomorphism[0] = 1
 
Z4Cat4Piv3PivotalIsomorphism[1] = -I
 
Z4Cat4Piv3PivotalIsomorphism[2] = -1
 
Z4Cat4Piv3PivotalIsomorphism[3] = I
balancedCategories[Z4Cat4Piv4] ^= {}
 
fusionCategory[Z4Cat4Piv4] ^= Z4Cat4
 
Z4Cat4Piv4 /: modularCategory[Z4Cat4Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[Z4Cat4Piv4] ^= Z4Cat4Piv4
 
pivotalIsomorphism[Z4Cat4Piv4] ^= Z4Cat4Piv4PivotalIsomorphism
 
ring[Z4Cat4Piv4] ^= Z4
 
sphericalCategory[Z4Cat4Piv4] ^= Z4Cat4Piv4
 
(pivotalCategoryIndex[fusionCategory[Z4Cat4]][pivotalCategory[#1]] & )[
    Z4Cat4Piv4] ^= 4
 
(sphericalCategoryIndex[fusionCategory[Z4Cat4]][sphericalCategory[#1]] & )[
    Z4Cat4Piv4] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[Z4Cat4Piv4PivotalIsomorphism] ^= Z4Cat4
 
pivotalCategory[Z4Cat4Piv4PivotalIsomorphism] ^= Z4Cat4Piv4
 
pivotalIsomorphism[Z4Cat4Piv4PivotalIsomorphism] ^= 
   Z4Cat4Piv4PivotalIsomorphism
 
Z4Cat4Piv4PivotalIsomorphism[0] = 1
 
Z4Cat4Piv4PivotalIsomorphism[1] = I
 
Z4Cat4Piv4PivotalIsomorphism[2] = -1
 
Z4Cat4Piv4PivotalIsomorphism[3] = -I
Z4NewCoeval1[(f_)?(has[fusionCategory])] := 
   (-1)^#1*FusionCategories`Private`defaultGaugeCoeval[f][#1] & 
Z4NewCoeval2[(f_)?(has[fusionCategory])] := 
   (-I)^#1*FusionCategories`Private`defaultGaugeCoeval[f][#1] & 
Z4NewCoeval3[(f_)?(has[fusionCategory])] := 
   I^#1*FusionCategories`Private`defaultGaugeCoeval[f][#1] & 
ring[Z4NFunction] ^= Z4
 
Z4NFunction[0, 0, 0] = 1
 
Z4NFunction[0, 0, 1] = 0
 
Z4NFunction[0, 0, 2] = 0
 
Z4NFunction[0, 0, 3] = 0
 
Z4NFunction[0, 1, 0] = 0
 
Z4NFunction[0, 1, 1] = 1
 
Z4NFunction[0, 1, 2] = 0
 
Z4NFunction[0, 1, 3] = 0
 
Z4NFunction[0, 2, 0] = 0
 
Z4NFunction[0, 2, 1] = 0
 
Z4NFunction[0, 2, 2] = 1
 
Z4NFunction[0, 2, 3] = 0
 
Z4NFunction[0, 3, 0] = 0
 
Z4NFunction[0, 3, 1] = 0
 
Z4NFunction[0, 3, 2] = 0
 
Z4NFunction[0, 3, 3] = 1
 
Z4NFunction[1, 0, 0] = 0
 
Z4NFunction[1, 0, 1] = 1
 
Z4NFunction[1, 0, 2] = 0
 
Z4NFunction[1, 0, 3] = 0
 
Z4NFunction[1, 1, 0] = 0
 
Z4NFunction[1, 1, 1] = 0
 
Z4NFunction[1, 1, 2] = 1
 
Z4NFunction[1, 1, 3] = 0
 
Z4NFunction[1, 2, 0] = 0
 
Z4NFunction[1, 2, 1] = 0
 
Z4NFunction[1, 2, 2] = 0
 
Z4NFunction[1, 2, 3] = 1
 
Z4NFunction[1, 3, 0] = 1
 
Z4NFunction[1, 3, 1] = 0
 
Z4NFunction[1, 3, 2] = 0
 
Z4NFunction[1, 3, 3] = 0
 
Z4NFunction[2, 0, 0] = 0
 
Z4NFunction[2, 0, 1] = 0
 
Z4NFunction[2, 0, 2] = 1
 
Z4NFunction[2, 0, 3] = 0
 
Z4NFunction[2, 1, 0] = 0
 
Z4NFunction[2, 1, 1] = 0
 
Z4NFunction[2, 1, 2] = 0
 
Z4NFunction[2, 1, 3] = 1
 
Z4NFunction[2, 2, 0] = 1
 
Z4NFunction[2, 2, 1] = 0
 
Z4NFunction[2, 2, 2] = 0
 
Z4NFunction[2, 2, 3] = 0
 
Z4NFunction[2, 3, 0] = 0
 
Z4NFunction[2, 3, 1] = 1
 
Z4NFunction[2, 3, 2] = 0
 
Z4NFunction[2, 3, 3] = 0
 
Z4NFunction[3, 0, 0] = 0
 
Z4NFunction[3, 0, 1] = 0
 
Z4NFunction[3, 0, 2] = 0
 
Z4NFunction[3, 0, 3] = 1
 
Z4NFunction[3, 1, 0] = 1
 
Z4NFunction[3, 1, 1] = 0
 
Z4NFunction[3, 1, 2] = 0
 
Z4NFunction[3, 1, 3] = 0
 
Z4NFunction[3, 2, 0] = 0
 
Z4NFunction[3, 2, 1] = 1
 
Z4NFunction[3, 2, 2] = 0
 
Z4NFunction[3, 2, 3] = 0
 
Z4NFunction[3, 3, 0] = 0
 
Z4NFunction[3, 3, 1] = 0
 
Z4NFunction[3, 3, 2] = 1
 
Z4NFunction[3, 3, 3] = 0
 
Z4NFunction[FusionCategories`Data`Z4`Private`a_, FusionCategories`Data`Z4`Private`b_, FusionCategories`Data`Z4`Private`c_] := 0


 EndPackage[]
