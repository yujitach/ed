BeginPackage["FusionCategories`Data`TY3`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[TY3] ^= {TY3Cat1, TY3Cat2, TY3Cat3, TY3Cat4}
 
TY3 /: fusionCategory[TY3, 1] = TY3Cat1
 
TY3 /: fusionCategory[TY3, 2] = TY3Cat2
 
TY3 /: fusionCategory[TY3, 3] = TY3Cat3
 
TY3 /: fusionCategory[TY3, 4] = TY3Cat4
 
nFunction[TY3] ^= TY3NFunction
 
noMultiplicities[TY3] ^= True
 
rank[TY3] ^= 4
 
ring[TY3] ^= TY3
balancedCategories[TY3Cat1] ^= {}
 
braidedCategories[TY3Cat1] ^= {}
 
coeval[TY3Cat1] ^= 1/sixJFunction[TY3Cat1][#1, dual[ring[TY3Cat1]][#1], #1, 
      #1, 0, 0] & 
 
eval[TY3Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TY3Cat1] ^= TY3Cat1FMatrixFunction
 
fusionCategory[TY3Cat1] ^= TY3Cat1
 
TY3Cat1 /: modularCategory[TY3Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TY3Cat1] ^= {TY3Cat1Piv1, TY3Cat1Piv2}
 
TY3Cat1 /: pivotalCategory[TY3Cat1, 1] = TY3Cat1Piv1
 
TY3Cat1 /: pivotalCategory[TY3Cat1, 2] = TY3Cat1Piv2
 
TY3Cat1 /: pivotalCategory[TY3Cat1, {1, 1, 1, -1}] = TY3Cat1Piv2
 
TY3Cat1 /: pivotalCategory[TY3Cat1, {1, 1, 1, 1}] = TY3Cat1Piv1
 
ring[TY3Cat1] ^= TY3
 
TY3Cat1 /: sphericalCategory[TY3Cat1, 1] = TY3Cat1Piv1
 
TY3Cat1 /: sphericalCategory[TY3Cat1, 2] = TY3Cat1Piv2
 
fusionCategoryIndex[TY3][TY3Cat1] ^= 1
fMatrixFunction[TY3Cat1FMatrixFunction] ^= TY3Cat1FMatrixFunction
 
fusionCategory[TY3Cat1FMatrixFunction] ^= TY3Cat1
 
ring[TY3Cat1FMatrixFunction] ^= TY3
 
TY3Cat1FMatrixFunction[1, 3, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
TY3Cat1FMatrixFunction[1, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY3Cat1FMatrixFunction[2, 3, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY3Cat1FMatrixFunction[2, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
TY3Cat1FMatrixFunction[3, 1, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
TY3Cat1FMatrixFunction[3, 1, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY3Cat1FMatrixFunction[3, 2, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY3Cat1FMatrixFunction[3, 2, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY3Cat1FMatrixFunction[3, 3, 3, 3] = 
   {{-(1/Sqrt[3]), -(1/Sqrt[3]), -(1/Sqrt[3])}, 
    {-(1/Sqrt[3]), (3*I + Sqrt[3])/6, (-3*I + Sqrt[3])/6}, 
    {-(1/Sqrt[3]), (-3*I + Sqrt[3])/6, (3*I + Sqrt[3])/6}}
 
TY3Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY3Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TY3Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY3Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TY3Cat1Piv1] ^= {}
 
fusionCategory[TY3Cat1Piv1] ^= TY3Cat1
 
TY3Cat1Piv1 /: modularCategory[TY3Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY3Cat1Piv1] ^= TY3Cat1Piv1
 
pivotalIsomorphism[TY3Cat1Piv1] ^= TY3Cat1Piv1PivotalIsomorphism
 
ring[TY3Cat1Piv1] ^= TY3
 
sphericalCategory[TY3Cat1Piv1] ^= TY3Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[TY3Cat1]][pivotalCategory[#1]] & )[
    TY3Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TY3Cat1]][sphericalCategory[#1]] & )[
    TY3Cat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY3Cat1Piv1PivotalIsomorphism] ^= TY3Cat1
 
pivotalCategory[TY3Cat1Piv1PivotalIsomorphism] ^= TY3Cat1Piv1
 
pivotalIsomorphism[TY3Cat1Piv1PivotalIsomorphism] ^= 
   TY3Cat1Piv1PivotalIsomorphism
 
TY3Cat1Piv1PivotalIsomorphism[0] = 1
 
TY3Cat1Piv1PivotalIsomorphism[1] = 1
 
TY3Cat1Piv1PivotalIsomorphism[2] = 1
 
TY3Cat1Piv1PivotalIsomorphism[3] = 1
balancedCategories[TY3Cat1Piv2] ^= {}
 
fusionCategory[TY3Cat1Piv2] ^= TY3Cat1
 
TY3Cat1Piv2 /: modularCategory[TY3Cat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY3Cat1Piv2] ^= TY3Cat1Piv2
 
pivotalIsomorphism[TY3Cat1Piv2] ^= TY3Cat1Piv2PivotalIsomorphism
 
ring[TY3Cat1Piv2] ^= TY3
 
sphericalCategory[TY3Cat1Piv2] ^= TY3Cat1Piv2
 
(pivotalCategoryIndex[fusionCategory[TY3Cat1]][pivotalCategory[#1]] & )[
    TY3Cat1Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TY3Cat1]][sphericalCategory[#1]] & )[
    TY3Cat1Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY3Cat1Piv2PivotalIsomorphism] ^= TY3Cat1
 
pivotalCategory[TY3Cat1Piv2PivotalIsomorphism] ^= TY3Cat1Piv2
 
pivotalIsomorphism[TY3Cat1Piv2PivotalIsomorphism] ^= 
   TY3Cat1Piv2PivotalIsomorphism
 
TY3Cat1Piv2PivotalIsomorphism[0] = 1
 
TY3Cat1Piv2PivotalIsomorphism[1] = 1
 
TY3Cat1Piv2PivotalIsomorphism[2] = 1
 
TY3Cat1Piv2PivotalIsomorphism[3] = -1
balancedCategories[TY3Cat2] ^= {}
 
braidedCategories[TY3Cat2] ^= {}
 
coeval[TY3Cat2] ^= 1/sixJFunction[TY3Cat2][#1, dual[ring[TY3Cat2]][#1], #1, 
      #1, 0, 0] & 
 
eval[TY3Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TY3Cat2] ^= TY3Cat2FMatrixFunction
 
fusionCategory[TY3Cat2] ^= TY3Cat2
 
TY3Cat2 /: modularCategory[TY3Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TY3Cat2] ^= {TY3Cat2Piv1, TY3Cat2Piv2}
 
TY3Cat2 /: pivotalCategory[TY3Cat2, 1] = TY3Cat2Piv1
 
TY3Cat2 /: pivotalCategory[TY3Cat2, 2] = TY3Cat2Piv2
 
TY3Cat2 /: pivotalCategory[TY3Cat2, {1, 1, 1, -1}] = TY3Cat2Piv2
 
TY3Cat2 /: pivotalCategory[TY3Cat2, {1, 1, 1, 1}] = TY3Cat2Piv1
 
ring[TY3Cat2] ^= TY3
 
TY3Cat2 /: sphericalCategory[TY3Cat2, 1] = TY3Cat2Piv1
 
TY3Cat2 /: sphericalCategory[TY3Cat2, 2] = TY3Cat2Piv2
 
fusionCategoryIndex[TY3][TY3Cat2] ^= 2
fMatrixFunction[TY3Cat2FMatrixFunction] ^= TY3Cat2FMatrixFunction
 
fusionCategory[TY3Cat2FMatrixFunction] ^= TY3Cat2
 
ring[TY3Cat2FMatrixFunction] ^= TY3
 
TY3Cat2FMatrixFunction[1, 3, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY3Cat2FMatrixFunction[1, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
TY3Cat2FMatrixFunction[2, 3, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
TY3Cat2FMatrixFunction[2, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY3Cat2FMatrixFunction[3, 1, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY3Cat2FMatrixFunction[3, 1, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY3Cat2FMatrixFunction[3, 2, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
TY3Cat2FMatrixFunction[3, 2, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY3Cat2FMatrixFunction[3, 3, 3, 3] = 
   {{-(1/Sqrt[3]), -(1/Sqrt[3]), -(1/Sqrt[3])}, 
    {-(1/Sqrt[3]), (-3*I + Sqrt[3])/6, (3*I + Sqrt[3])/6}, 
    {-(1/Sqrt[3]), (3*I + Sqrt[3])/6, (-3*I + Sqrt[3])/6}}
 
TY3Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY3Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TY3Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY3Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TY3Cat2Piv1] ^= {}
 
fusionCategory[TY3Cat2Piv1] ^= TY3Cat2
 
TY3Cat2Piv1 /: modularCategory[TY3Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY3Cat2Piv1] ^= TY3Cat2Piv1
 
pivotalIsomorphism[TY3Cat2Piv1] ^= TY3Cat2Piv1PivotalIsomorphism
 
ring[TY3Cat2Piv1] ^= TY3
 
sphericalCategory[TY3Cat2Piv1] ^= TY3Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[TY3Cat2]][pivotalCategory[#1]] & )[
    TY3Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TY3Cat2]][sphericalCategory[#1]] & )[
    TY3Cat2Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY3Cat2Piv1PivotalIsomorphism] ^= TY3Cat2
 
pivotalCategory[TY3Cat2Piv1PivotalIsomorphism] ^= TY3Cat2Piv1
 
pivotalIsomorphism[TY3Cat2Piv1PivotalIsomorphism] ^= 
   TY3Cat2Piv1PivotalIsomorphism
 
TY3Cat2Piv1PivotalIsomorphism[0] = 1
 
TY3Cat2Piv1PivotalIsomorphism[1] = 1
 
TY3Cat2Piv1PivotalIsomorphism[2] = 1
 
TY3Cat2Piv1PivotalIsomorphism[3] = 1
balancedCategories[TY3Cat2Piv2] ^= {}
 
fusionCategory[TY3Cat2Piv2] ^= TY3Cat2
 
TY3Cat2Piv2 /: modularCategory[TY3Cat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY3Cat2Piv2] ^= TY3Cat2Piv2
 
pivotalIsomorphism[TY3Cat2Piv2] ^= TY3Cat2Piv2PivotalIsomorphism
 
ring[TY3Cat2Piv2] ^= TY3
 
sphericalCategory[TY3Cat2Piv2] ^= TY3Cat2Piv2
 
(pivotalCategoryIndex[fusionCategory[TY3Cat2]][pivotalCategory[#1]] & )[
    TY3Cat2Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TY3Cat2]][sphericalCategory[#1]] & )[
    TY3Cat2Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY3Cat2Piv2PivotalIsomorphism] ^= TY3Cat2
 
pivotalCategory[TY3Cat2Piv2PivotalIsomorphism] ^= TY3Cat2Piv2
 
pivotalIsomorphism[TY3Cat2Piv2PivotalIsomorphism] ^= 
   TY3Cat2Piv2PivotalIsomorphism
 
TY3Cat2Piv2PivotalIsomorphism[0] = 1
 
TY3Cat2Piv2PivotalIsomorphism[1] = 1
 
TY3Cat2Piv2PivotalIsomorphism[2] = 1
 
TY3Cat2Piv2PivotalIsomorphism[3] = -1
balancedCategories[TY3Cat3] ^= {}
 
braidedCategories[TY3Cat3] ^= {}
 
coeval[TY3Cat3] ^= 1/sixJFunction[TY3Cat3][#1, dual[ring[TY3Cat3]][#1], #1, 
      #1, 0, 0] & 
 
eval[TY3Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TY3Cat3] ^= TY3Cat3FMatrixFunction
 
fusionCategory[TY3Cat3] ^= TY3Cat3
 
TY3Cat3 /: modularCategory[TY3Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TY3Cat3] ^= {TY3Cat3Piv1, TY3Cat3Piv2}
 
TY3Cat3 /: pivotalCategory[TY3Cat3, 1] = TY3Cat3Piv1
 
TY3Cat3 /: pivotalCategory[TY3Cat3, 2] = TY3Cat3Piv2
 
TY3Cat3 /: pivotalCategory[TY3Cat3, {1, 1, 1, -1}] = TY3Cat3Piv2
 
TY3Cat3 /: pivotalCategory[TY3Cat3, {1, 1, 1, 1}] = TY3Cat3Piv1
 
ring[TY3Cat3] ^= TY3
 
TY3Cat3 /: sphericalCategory[TY3Cat3, 1] = TY3Cat3Piv1
 
TY3Cat3 /: sphericalCategory[TY3Cat3, 2] = TY3Cat3Piv2
 
fusionCategoryIndex[TY3][TY3Cat3] ^= 3
fMatrixFunction[TY3Cat3FMatrixFunction] ^= TY3Cat3FMatrixFunction
 
fusionCategory[TY3Cat3FMatrixFunction] ^= TY3Cat3
 
ring[TY3Cat3FMatrixFunction] ^= TY3
 
TY3Cat3FMatrixFunction[1, 3, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY3Cat3FMatrixFunction[1, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
TY3Cat3FMatrixFunction[2, 3, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
TY3Cat3FMatrixFunction[2, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY3Cat3FMatrixFunction[3, 1, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY3Cat3FMatrixFunction[3, 1, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY3Cat3FMatrixFunction[3, 2, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
TY3Cat3FMatrixFunction[3, 2, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY3Cat3FMatrixFunction[3, 3, 3, 3] = {{1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3]}, 
    {1/Sqrt[3], (-1)^(2/3)/Sqrt[3], (-3*I - Sqrt[3])/6}, 
    {1/Sqrt[3], (-3*I - Sqrt[3])/6, (-1)^(2/3)/Sqrt[3]}}
 
TY3Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY3Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TY3Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY3Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TY3Cat3Piv1] ^= {}
 
fusionCategory[TY3Cat3Piv1] ^= TY3Cat3
 
TY3Cat3Piv1 /: modularCategory[TY3Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY3Cat3Piv1] ^= TY3Cat3Piv1
 
pivotalIsomorphism[TY3Cat3Piv1] ^= TY3Cat3Piv1PivotalIsomorphism
 
ring[TY3Cat3Piv1] ^= TY3
 
sphericalCategory[TY3Cat3Piv1] ^= TY3Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[TY3Cat3]][pivotalCategory[#1]] & )[
    TY3Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TY3Cat3]][sphericalCategory[#1]] & )[
    TY3Cat3Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY3Cat3Piv1PivotalIsomorphism] ^= TY3Cat3
 
pivotalCategory[TY3Cat3Piv1PivotalIsomorphism] ^= TY3Cat3Piv1
 
pivotalIsomorphism[TY3Cat3Piv1PivotalIsomorphism] ^= 
   TY3Cat3Piv1PivotalIsomorphism
 
TY3Cat3Piv1PivotalIsomorphism[0] = 1
 
TY3Cat3Piv1PivotalIsomorphism[1] = 1
 
TY3Cat3Piv1PivotalIsomorphism[2] = 1
 
TY3Cat3Piv1PivotalIsomorphism[3] = 1
balancedCategories[TY3Cat3Piv2] ^= {}
 
fusionCategory[TY3Cat3Piv2] ^= TY3Cat3
 
TY3Cat3Piv2 /: modularCategory[TY3Cat3Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY3Cat3Piv2] ^= TY3Cat3Piv2
 
pivotalIsomorphism[TY3Cat3Piv2] ^= TY3Cat3Piv2PivotalIsomorphism
 
ring[TY3Cat3Piv2] ^= TY3
 
sphericalCategory[TY3Cat3Piv2] ^= TY3Cat3Piv2
 
(pivotalCategoryIndex[fusionCategory[TY3Cat3]][pivotalCategory[#1]] & )[
    TY3Cat3Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TY3Cat3]][sphericalCategory[#1]] & )[
    TY3Cat3Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY3Cat3Piv2PivotalIsomorphism] ^= TY3Cat3
 
pivotalCategory[TY3Cat3Piv2PivotalIsomorphism] ^= TY3Cat3Piv2
 
pivotalIsomorphism[TY3Cat3Piv2PivotalIsomorphism] ^= 
   TY3Cat3Piv2PivotalIsomorphism
 
TY3Cat3Piv2PivotalIsomorphism[0] = 1
 
TY3Cat3Piv2PivotalIsomorphism[1] = 1
 
TY3Cat3Piv2PivotalIsomorphism[2] = 1
 
TY3Cat3Piv2PivotalIsomorphism[3] = -1
balancedCategories[TY3Cat4] ^= {}
 
braidedCategories[TY3Cat4] ^= {}
 
coeval[TY3Cat4] ^= 1/sixJFunction[TY3Cat4][#1, dual[ring[TY3Cat4]][#1], #1, 
      #1, 0, 0] & 
 
eval[TY3Cat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TY3Cat4] ^= TY3Cat4FMatrixFunction
 
fusionCategory[TY3Cat4] ^= TY3Cat4
 
TY3Cat4 /: modularCategory[TY3Cat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TY3Cat4] ^= {TY3Cat4Piv1, TY3Cat4Piv2}
 
TY3Cat4 /: pivotalCategory[TY3Cat4, 1] = TY3Cat4Piv1
 
TY3Cat4 /: pivotalCategory[TY3Cat4, 2] = TY3Cat4Piv2
 
TY3Cat4 /: pivotalCategory[TY3Cat4, {1, 1, 1, -1}] = TY3Cat4Piv2
 
TY3Cat4 /: pivotalCategory[TY3Cat4, {1, 1, 1, 1}] = TY3Cat4Piv1
 
ring[TY3Cat4] ^= TY3
 
TY3Cat4 /: sphericalCategory[TY3Cat4, 1] = TY3Cat4Piv1
 
TY3Cat4 /: sphericalCategory[TY3Cat4, 2] = TY3Cat4Piv2
 
fusionCategoryIndex[TY3][TY3Cat4] ^= 4
fMatrixFunction[TY3Cat4FMatrixFunction] ^= TY3Cat4FMatrixFunction
 
fusionCategory[TY3Cat4FMatrixFunction] ^= TY3Cat4
 
ring[TY3Cat4FMatrixFunction] ^= TY3
 
TY3Cat4FMatrixFunction[1, 3, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
TY3Cat4FMatrixFunction[1, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY3Cat4FMatrixFunction[2, 3, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY3Cat4FMatrixFunction[2, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
TY3Cat4FMatrixFunction[3, 1, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
TY3Cat4FMatrixFunction[3, 1, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY3Cat4FMatrixFunction[3, 2, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY3Cat4FMatrixFunction[3, 2, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY3Cat4FMatrixFunction[3, 3, 3, 3] = {{1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3]}, 
    {1/Sqrt[3], (-3*I - Sqrt[3])/6, (-1)^(2/3)/Sqrt[3]}, 
    {1/Sqrt[3], (-1)^(2/3)/Sqrt[3], (-3*I - Sqrt[3])/6}}
 
TY3Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY3Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TY3Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY3Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TY3Cat4Piv1] ^= {}
 
fusionCategory[TY3Cat4Piv1] ^= TY3Cat4
 
TY3Cat4Piv1 /: modularCategory[TY3Cat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY3Cat4Piv1] ^= TY3Cat4Piv1
 
pivotalIsomorphism[TY3Cat4Piv1] ^= TY3Cat4Piv1PivotalIsomorphism
 
ring[TY3Cat4Piv1] ^= TY3
 
sphericalCategory[TY3Cat4Piv1] ^= TY3Cat4Piv1
 
(pivotalCategoryIndex[fusionCategory[TY3Cat4]][pivotalCategory[#1]] & )[
    TY3Cat4Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TY3Cat4]][sphericalCategory[#1]] & )[
    TY3Cat4Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY3Cat4Piv1PivotalIsomorphism] ^= TY3Cat4
 
pivotalCategory[TY3Cat4Piv1PivotalIsomorphism] ^= TY3Cat4Piv1
 
pivotalIsomorphism[TY3Cat4Piv1PivotalIsomorphism] ^= 
   TY3Cat4Piv1PivotalIsomorphism
 
TY3Cat4Piv1PivotalIsomorphism[0] = 1
 
TY3Cat4Piv1PivotalIsomorphism[1] = 1
 
TY3Cat4Piv1PivotalIsomorphism[2] = 1
 
TY3Cat4Piv1PivotalIsomorphism[3] = 1
balancedCategories[TY3Cat4Piv2] ^= {}
 
fusionCategory[TY3Cat4Piv2] ^= TY3Cat4
 
TY3Cat4Piv2 /: modularCategory[TY3Cat4Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY3Cat4Piv2] ^= TY3Cat4Piv2
 
pivotalIsomorphism[TY3Cat4Piv2] ^= TY3Cat4Piv2PivotalIsomorphism
 
ring[TY3Cat4Piv2] ^= TY3
 
sphericalCategory[TY3Cat4Piv2] ^= TY3Cat4Piv2
 
(pivotalCategoryIndex[fusionCategory[TY3Cat4]][pivotalCategory[#1]] & )[
    TY3Cat4Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TY3Cat4]][sphericalCategory[#1]] & )[
    TY3Cat4Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY3Cat4Piv2PivotalIsomorphism] ^= TY3Cat4
 
pivotalCategory[TY3Cat4Piv2PivotalIsomorphism] ^= TY3Cat4Piv2
 
pivotalIsomorphism[TY3Cat4Piv2PivotalIsomorphism] ^= 
   TY3Cat4Piv2PivotalIsomorphism
 
TY3Cat4Piv2PivotalIsomorphism[0] = 1
 
TY3Cat4Piv2PivotalIsomorphism[1] = 1
 
TY3Cat4Piv2PivotalIsomorphism[2] = 1
 
TY3Cat4Piv2PivotalIsomorphism[3] = -1
ring[TY3NFunction] ^= TY3
 
TY3NFunction[0, 0, 0] = 1
 
TY3NFunction[0, 0, 1] = 0
 
TY3NFunction[0, 0, 2] = 0
 
TY3NFunction[0, 0, 3] = 0
 
TY3NFunction[0, 1, 0] = 0
 
TY3NFunction[0, 1, 1] = 1
 
TY3NFunction[0, 1, 2] = 0
 
TY3NFunction[0, 1, 3] = 0
 
TY3NFunction[0, 2, 0] = 0
 
TY3NFunction[0, 2, 1] = 0
 
TY3NFunction[0, 2, 2] = 1
 
TY3NFunction[0, 2, 3] = 0
 
TY3NFunction[0, 3, 0] = 0
 
TY3NFunction[0, 3, 1] = 0
 
TY3NFunction[0, 3, 2] = 0
 
TY3NFunction[0, 3, 3] = 1
 
TY3NFunction[1, 0, 0] = 0
 
TY3NFunction[1, 0, 1] = 1
 
TY3NFunction[1, 0, 2] = 0
 
TY3NFunction[1, 0, 3] = 0
 
TY3NFunction[1, 1, 0] = 0
 
TY3NFunction[1, 1, 1] = 0
 
TY3NFunction[1, 1, 2] = 1
 
TY3NFunction[1, 1, 3] = 0
 
TY3NFunction[1, 2, 0] = 1
 
TY3NFunction[1, 2, 1] = 0
 
TY3NFunction[1, 2, 2] = 0
 
TY3NFunction[1, 2, 3] = 0
 
TY3NFunction[1, 3, 0] = 0
 
TY3NFunction[1, 3, 1] = 0
 
TY3NFunction[1, 3, 2] = 0
 
TY3NFunction[1, 3, 3] = 1
 
TY3NFunction[2, 0, 0] = 0
 
TY3NFunction[2, 0, 1] = 0
 
TY3NFunction[2, 0, 2] = 1
 
TY3NFunction[2, 0, 3] = 0
 
TY3NFunction[2, 1, 0] = 1
 
TY3NFunction[2, 1, 1] = 0
 
TY3NFunction[2, 1, 2] = 0
 
TY3NFunction[2, 1, 3] = 0
 
TY3NFunction[2, 2, 0] = 0
 
TY3NFunction[2, 2, 1] = 1
 
TY3NFunction[2, 2, 2] = 0
 
TY3NFunction[2, 2, 3] = 0
 
TY3NFunction[2, 3, 0] = 0
 
TY3NFunction[2, 3, 1] = 0
 
TY3NFunction[2, 3, 2] = 0
 
TY3NFunction[2, 3, 3] = 1
 
TY3NFunction[3, 0, 0] = 0
 
TY3NFunction[3, 0, 1] = 0
 
TY3NFunction[3, 0, 2] = 0
 
TY3NFunction[3, 0, 3] = 1
 
TY3NFunction[3, 1, 0] = 0
 
TY3NFunction[3, 1, 1] = 0
 
TY3NFunction[3, 1, 2] = 0
 
TY3NFunction[3, 1, 3] = 1
 
TY3NFunction[3, 2, 0] = 0
 
TY3NFunction[3, 2, 1] = 0
 
TY3NFunction[3, 2, 2] = 0
 
TY3NFunction[3, 2, 3] = 1
 
TY3NFunction[3, 3, 0] = 1
 
TY3NFunction[3, 3, 1] = 1
 
TY3NFunction[3, 3, 2] = 1
 
TY3NFunction[3, 3, 3] = 0
 
TY3NFunction[FusionCategories`Data`TY3`Private`a_, FusionCategories`Data`TY3`Private`b_, FusionCategories`Data`TY3`Private`c_] := 0


 EndPackage[]
