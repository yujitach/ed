BeginPackage["FusionCategories`Data`SO35`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[SO35] ^= {SO35Cat1, SO35Cat2, SO35Cat3}
 
SO35 /: fusionCategory[SO35, 1] = SO35Cat1
 
SO35 /: fusionCategory[SO35, 2] = SO35Cat2
 
SO35 /: fusionCategory[SO35, 3] = SO35Cat3
 
nFunction[SO35] ^= SO35NFunction
 
noMultiplicities[SO35] ^= True
 
rank[SO35] ^= 3
 
ring[SO35] ^= SO35
balancedCategories[SO35Cat1] ^= {SO35Cat1Bal1, SO35Cat1Bal2}
 
SO35Cat1 /: balancedCategory[SO35Cat1, 1] = SO35Cat1Bal1
 
SO35Cat1 /: balancedCategory[SO35Cat1, 2] = SO35Cat1Bal2
 
braidedCategories[SO35Cat1] ^= {SO35Cat1Brd1, SO35Cat1Brd2}
 
SO35Cat1 /: braidedCategory[SO35Cat1, 1] = SO35Cat1Brd1
 
SO35Cat1 /: braidedCategory[SO35Cat1, 2] = SO35Cat1Brd2
 
coeval[SO35Cat1] ^= 1/sixJFunction[SO35Cat1][#1, dual[ring[SO35Cat1]][#1], 
      #1, #1, 0, 0] & 
 
eval[SO35Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[SO35Cat1] ^= SO35Cat1FMatrixFunction
 
fusionCategory[SO35Cat1] ^= SO35Cat1
 
SO35Cat1 /: modularCategory[SO35Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[SO35Cat1] ^= {SO35Cat1Piv1}
 
SO35Cat1 /: pivotalCategory[SO35Cat1, 1] = SO35Cat1Piv1
 
SO35Cat1 /: pivotalCategory[SO35Cat1, {1, 1, 1}] = SO35Cat1Piv1
 
SO35Cat1 /: ribbonCategory[SO35Cat1, 1] = SO35Cat1Bal1
 
SO35Cat1 /: ribbonCategory[SO35Cat1, 2] = SO35Cat1Bal2
 
ring[SO35Cat1] ^= SO35
 
SO35Cat1 /: sphericalCategory[SO35Cat1, 1] = SO35Cat1Piv1
 
fusionCategoryIndex[SO35][SO35Cat1] ^= 1
balancedCategory[SO35Cat1Bal1] ^= SO35Cat1Bal1
 
braidedCategory[SO35Cat1Bal1] ^= SO35Cat1Brd1
 
fusionCategory[SO35Cat1Bal1] ^= SO35Cat1
 
pivotalCategory[SO35Cat1Bal1] ^= SO35Cat1Piv1
 
ribbonCategory[SO35Cat1Bal1] ^= SO35Cat1Bal1
 
ring[SO35Cat1Bal1] ^= SO35
 
sphericalCategory[SO35Cat1Bal1] ^= SO35Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SO35Cat1Brd1]][
      balancedCategory[#1]] & )[SO35Cat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[SO35Cat1]][balancedCategory[#1]] & )[
    SO35Cat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[SO35Cat1Piv1]][
      balancedCategory[#1]] & )[SO35Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SO35Cat1Brd1]][ribbonCategory[#1]] & )[
    SO35Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SO35Cat1]][ribbonCategory[#1]] & )[
    SO35Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[SO35Cat1Piv1]][ribbonCategory[#1]] & )[
    SO35Cat1Bal1] ^= 1
balancedCategory[SO35Cat1Bal2] ^= SO35Cat1Bal2
 
braidedCategory[SO35Cat1Bal2] ^= SO35Cat1Brd2
 
fusionCategory[SO35Cat1Bal2] ^= SO35Cat1
 
pivotalCategory[SO35Cat1Bal2] ^= SO35Cat1Piv1
 
ribbonCategory[SO35Cat1Bal2] ^= SO35Cat1Bal2
 
ring[SO35Cat1Bal2] ^= SO35
 
sphericalCategory[SO35Cat1Bal2] ^= SO35Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SO35Cat1Brd2]][
      balancedCategory[#1]] & )[SO35Cat1Bal2] ^= 1
 
(balancedCategoryIndex[fusionCategory[SO35Cat1]][balancedCategory[#1]] & )[
    SO35Cat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[SO35Cat1Piv1]][
      balancedCategory[#1]] & )[SO35Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SO35Cat1Brd2]][ribbonCategory[#1]] & )[
    SO35Cat1Bal2] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SO35Cat1]][ribbonCategory[#1]] & )[
    SO35Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[SO35Cat1Piv1]][ribbonCategory[#1]] & )[
    SO35Cat1Bal2] ^= 2
balancedCategories[SO35Cat1Brd1] ^= {SO35Cat1Bal1}
 
SO35Cat1Brd1 /: balancedCategory[SO35Cat1Brd1, 1] = SO35Cat1Bal1
 
braidedCategory[SO35Cat1Brd1] ^= SO35Cat1Brd1
 
fusionCategory[SO35Cat1Brd1] ^= SO35Cat1
 
SO35Cat1Brd1 /: modularCategory[SO35Cat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SO35Cat1Brd1 /: ribbonCategory[SO35Cat1Brd1, 1] = SO35Cat1Bal1
 
ring[SO35Cat1Brd1] ^= SO35
 
rMatrixFunction[SO35Cat1Brd1] ^= SO35Cat1Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SO35Cat1]][braidedCategory[#1]] & )[
    SO35Cat1Brd1] ^= 1
braidedCategory[SO35Cat1Brd1RMatrixFunction] ^= SO35Cat1Brd1
 
fusionCategory[SO35Cat1Brd1RMatrixFunction] ^= SO35Cat1
 
rMatrixFunction[SO35Cat1Brd1RMatrixFunction] ^= SO35Cat1Brd1RMatrixFunction
 
SO35Cat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
SO35Cat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
SO35Cat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
SO35Cat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
SO35Cat1Brd1RMatrixFunction[1, 1, 0] = {{-(-1)^(5/7)}}
 
SO35Cat1Brd1RMatrixFunction[1, 1, 2] = {{(-1)^(3/7)}}
 
SO35Cat1Brd1RMatrixFunction[1, 2, 1] = {{(-1)^(2/7)}}
 
SO35Cat1Brd1RMatrixFunction[1, 2, 2] = {{-(-1)^(6/7)}}
 
SO35Cat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
SO35Cat1Brd1RMatrixFunction[2, 1, 1] = {{(-1)^(2/7)}}
 
SO35Cat1Brd1RMatrixFunction[2, 1, 2] = {{-(-1)^(6/7)}}
 
SO35Cat1Brd1RMatrixFunction[2, 2, 0] = {{(-1)^(4/7)}}
 
SO35Cat1Brd1RMatrixFunction[2, 2, 1] = {{-(-1)^(5/7)}}
 
SO35Cat1Brd1RMatrixFunction[2, 2, 2] = {{-(-1)^(2/7)}}
balancedCategories[SO35Cat1Brd2] ^= {SO35Cat1Bal2}
 
SO35Cat1Brd2 /: balancedCategory[SO35Cat1Brd2, 1] = SO35Cat1Bal2
 
braidedCategory[SO35Cat1Brd2] ^= SO35Cat1Brd2
 
fusionCategory[SO35Cat1Brd2] ^= SO35Cat1
 
SO35Cat1Brd2 /: modularCategory[SO35Cat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SO35Cat1Brd2 /: ribbonCategory[SO35Cat1Brd2, 1] = SO35Cat1Bal2
 
ring[SO35Cat1Brd2] ^= SO35
 
rMatrixFunction[SO35Cat1Brd2] ^= SO35Cat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SO35Cat1]][braidedCategory[#1]] & )[
    SO35Cat1Brd2] ^= 2
braidedCategory[SO35Cat1Brd2RMatrixFunction] ^= SO35Cat1Brd2
 
fusionCategory[SO35Cat1Brd2RMatrixFunction] ^= SO35Cat1
 
rMatrixFunction[SO35Cat1Brd2RMatrixFunction] ^= SO35Cat1Brd2RMatrixFunction
 
SO35Cat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
SO35Cat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
SO35Cat1Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
SO35Cat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
SO35Cat1Brd2RMatrixFunction[1, 1, 0] = {{(-1)^(2/7)}}
 
SO35Cat1Brd2RMatrixFunction[1, 1, 2] = {{-(-1)^(4/7)}}
 
SO35Cat1Brd2RMatrixFunction[1, 2, 1] = {{-(-1)^(5/7)}}
 
SO35Cat1Brd2RMatrixFunction[1, 2, 2] = {{(-1)^(1/7)}}
 
SO35Cat1Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
SO35Cat1Brd2RMatrixFunction[2, 1, 1] = {{-(-1)^(5/7)}}
 
SO35Cat1Brd2RMatrixFunction[2, 1, 2] = {{(-1)^(1/7)}}
 
SO35Cat1Brd2RMatrixFunction[2, 2, 0] = {{-(-1)^(3/7)}}
 
SO35Cat1Brd2RMatrixFunction[2, 2, 1] = {{(-1)^(2/7)}}
 
SO35Cat1Brd2RMatrixFunction[2, 2, 2] = {{(-1)^(5/7)}}
fMatrixFunction[SO35Cat1FMatrixFunction] ^= SO35Cat1FMatrixFunction
 
fusionCategory[SO35Cat1FMatrixFunction] ^= SO35Cat1
 
ring[SO35Cat1FMatrixFunction] ^= SO35
 
SO35Cat1FMatrixFunction[1, 1, 1, 1] = 
   {{Root[1 - #1 - 2*#1^2 + #1^3 & , 2, 0], Root[1 + 6*#1 + 5*#1^2 + #1^3 & , 
      2, 0]}, {Root[1 - 2*#1 - #1^2 + #1^3 & , 2, 0], 
     Root[1 - #1 - 2*#1^2 + #1^3 & , 2, 0]}}
 
SO35Cat1FMatrixFunction[1, 1, 1, 2] = {{-1}}
 
SO35Cat1FMatrixFunction[1, 1, 2, 2] = 
   {{Root[1 - 4*#1 + 3*#1^2 + #1^3 & , 2, 0], 
     Root[-1 - 2*#1 + #1^2 + #1^3 & , 2, 0]}, 
    {Root[1 - 2*#1 - #1^2 + #1^3 & , 2, 0], Root[1 - 2*#1 - #1^2 + #1^3 & , 
      2, 0]}}
 
SO35Cat1FMatrixFunction[1, 2, 1, 0] = {{-1}}
 
SO35Cat1FMatrixFunction[1, 2, 1, 2] = 
   {{Root[1 - 2*#1 - #1^2 + #1^3 & , 2, 0], Root[-1 - #1 + 2*#1^2 + #1^3 & , 
      3, 0]}, {-1, Root[1 - 2*#1 - #1^2 + #1^3 & , 2, 0]}}
 
SO35Cat1FMatrixFunction[1, 2, 2, 1] = 
   {{Root[-1 - 2*#1 + #1^2 + #1^3 & , 3, 0], Root[-1 - 2*#1 + #1^2 + #1^3 & , 
      3, 0]}, {Root[1 - 2*#1 - #1^2 + #1^3 & , 1, 0], 1}}
 
SO35Cat1FMatrixFunction[1, 2, 2, 2] = 
   {{Root[-1 - #1 + 2*#1^2 + #1^3 & , 3, 0], 
     Root[1 - 4*#1 + 3*#1^2 + #1^3 & , 2, 0]}, 
    {1, Root[1 - #1 - 2*#1^2 + #1^3 & , 1, 0]}}
 
SO35Cat1FMatrixFunction[2, 1, 1, 0] = {{-1}}
 
SO35Cat1FMatrixFunction[2, 1, 1, 2] = 
   {{Root[1 - 2*#1 - #1^2 + #1^3 & , 1, 0], Root[-1 - 2*#1 + #1^2 + #1^3 & , 
      3, 0]}, {Root[-1 - 2*#1 + #1^2 + #1^3 & , 3, 0], 1}}
 
SO35Cat1FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
SO35Cat1FMatrixFunction[2, 1, 2, 1] = 
   {{Root[-1 - 2*#1 + #1^2 + #1^3 & , 2, 0], Root[-1 - #1 + 2*#1^2 + #1^3 & , 
      3, 0]}, {-1, Root[-1 - 2*#1 + #1^2 + #1^3 & , 2, 0]}}
 
SO35Cat1FMatrixFunction[2, 1, 2, 2] = 
   {{Root[-1 - #1 + 2*#1^2 + #1^3 & , 3, 0], 
     Root[1 - 4*#1 + 3*#1^2 + #1^3 & , 2, 0]}, 
    {-1, Root[-1 - #1 + 2*#1^2 + #1^3 & , 3, 0]}}
 
SO35Cat1FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
SO35Cat1FMatrixFunction[2, 2, 1, 1] = 
   {{Root[1 - 4*#1 + 3*#1^2 + #1^3 & , 2, 0], Root[1 - 2*#1 - #1^2 + #1^3 & , 
      2, 0]}, {Root[-1 - 2*#1 + #1^2 + #1^3 & , 2, 0], 
     Root[1 - 2*#1 - #1^2 + #1^3 & , 2, 0]}}
 
SO35Cat1FMatrixFunction[2, 2, 1, 2] = 
   {{Root[-1 - #1 + 2*#1^2 + #1^3 & , 3, 0], 
     Root[-1 - 4*#1 - 3*#1^2 + #1^3 & , 2, 0]}, 
    {-1, Root[1 - #1 - 2*#1^2 + #1^3 & , 1, 0]}}
 
SO35Cat1FMatrixFunction[2, 2, 2, 1] = 
   {{Root[1 - #1 - 2*#1^2 + #1^3 & , 1, 0], 
     Root[-1 - 4*#1 - 3*#1^2 + #1^3 & , 2, 0]}, 
    {1, Root[1 - #1 - 2*#1^2 + #1^3 & , 1, 0]}}
 
SO35Cat1FMatrixFunction[2, 2, 2, 2] = 
   {{Root[1 - 2*#1 - #1^2 + #1^3 & , 2, 0], 1, 
     Root[1 - 2*#1 - #1^2 + #1^3 & , 2, 0]}, 
    {Root[-1 - 4*#1 - 3*#1^2 + #1^3 & , 2, 0], 
     Root[-1 - 4*#1 - 3*#1^2 + #1^3 & , 2, 0], 
     Root[1 - #1 - 9*#1^2 + #1^3 & , 2, 0]}, 
    {1, Root[-1 - 2*#1 + #1^2 + #1^3 & , 1, 0], 
     Root[-1 + 6*#1 - 5*#1^2 + #1^3 & , 1, 0]}}
 
SO35Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SO35Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
SO35Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SO35Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[SO35Cat1Piv1] ^= {SO35Cat1Bal1, SO35Cat1Bal2}
 
SO35Cat1Piv1 /: balancedCategory[SO35Cat1Piv1, 1] = SO35Cat1Bal1
 
SO35Cat1Piv1 /: balancedCategory[SO35Cat1Piv1, 2] = SO35Cat1Bal2
 
fusionCategory[SO35Cat1Piv1] ^= SO35Cat1
 
SO35Cat1Piv1 /: modularCategory[SO35Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SO35Cat1Piv1] ^= SO35Cat1Piv1
 
pivotalIsomorphism[SO35Cat1Piv1] ^= SO35Cat1Piv1PivotalIsomorphism
 
SO35Cat1Piv1 /: ribbonCategory[SO35Cat1Piv1, 1] = SO35Cat1Bal1
 
SO35Cat1Piv1 /: ribbonCategory[SO35Cat1Piv1, 2] = SO35Cat1Bal2
 
ring[SO35Cat1Piv1] ^= SO35
 
sphericalCategory[SO35Cat1Piv1] ^= SO35Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[SO35Cat1]][pivotalCategory[#1]] & )[
    SO35Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[SO35Cat1]][sphericalCategory[#1]] & )[
    SO35Cat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[SO35Cat1Piv1PivotalIsomorphism] ^= SO35Cat1
 
pivotalCategory[SO35Cat1Piv1PivotalIsomorphism] ^= SO35Cat1Piv1
 
pivotalIsomorphism[SO35Cat1Piv1PivotalIsomorphism] ^= 
   SO35Cat1Piv1PivotalIsomorphism
 
SO35Cat1Piv1PivotalIsomorphism[0] = 1
 
SO35Cat1Piv1PivotalIsomorphism[1] = 1
 
SO35Cat1Piv1PivotalIsomorphism[2] = 1
balancedCategories[SO35Cat2] ^= {SO35Cat2Bal1, SO35Cat2Bal2}
 
SO35Cat2 /: balancedCategory[SO35Cat2, 1] = SO35Cat2Bal1
 
SO35Cat2 /: balancedCategory[SO35Cat2, 2] = SO35Cat2Bal2
 
braidedCategories[SO35Cat2] ^= {SO35Cat2Brd1, SO35Cat2Brd2}
 
SO35Cat2 /: braidedCategory[SO35Cat2, 1] = SO35Cat2Brd1
 
SO35Cat2 /: braidedCategory[SO35Cat2, 2] = SO35Cat2Brd2
 
coeval[SO35Cat2] ^= 1/sixJFunction[SO35Cat2][#1, dual[ring[SO35Cat2]][#1], 
      #1, #1, 0, 0] & 
 
eval[SO35Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[SO35Cat2] ^= SO35Cat2FMatrixFunction
 
fusionCategory[SO35Cat2] ^= SO35Cat2
 
SO35Cat2 /: modularCategory[SO35Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[SO35Cat2] ^= {SO35Cat2Piv1}
 
SO35Cat2 /: pivotalCategory[SO35Cat2, 1] = SO35Cat2Piv1
 
SO35Cat2 /: pivotalCategory[SO35Cat2, {1, 1, 1}] = SO35Cat2Piv1
 
SO35Cat2 /: ribbonCategory[SO35Cat2, 1] = SO35Cat2Bal1
 
SO35Cat2 /: ribbonCategory[SO35Cat2, 2] = SO35Cat2Bal2
 
ring[SO35Cat2] ^= SO35
 
SO35Cat2 /: sphericalCategory[SO35Cat2, 1] = SO35Cat2Piv1
 
fusionCategoryIndex[SO35][SO35Cat2] ^= 2
balancedCategory[SO35Cat2Bal1] ^= SO35Cat2Bal1
 
braidedCategory[SO35Cat2Bal1] ^= SO35Cat2Brd1
 
fusionCategory[SO35Cat2Bal1] ^= SO35Cat2
 
pivotalCategory[SO35Cat2Bal1] ^= SO35Cat2Piv1
 
ribbonCategory[SO35Cat2Bal1] ^= SO35Cat2Bal1
 
ring[SO35Cat2Bal1] ^= SO35
 
sphericalCategory[SO35Cat2Bal1] ^= SO35Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[SO35Cat2Brd1]][
      balancedCategory[#1]] & )[SO35Cat2Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[SO35Cat2]][balancedCategory[#1]] & )[
    SO35Cat2Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[SO35Cat2Piv1]][
      balancedCategory[#1]] & )[SO35Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SO35Cat2Brd1]][ribbonCategory[#1]] & )[
    SO35Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SO35Cat2]][ribbonCategory[#1]] & )[
    SO35Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[SO35Cat2Piv1]][ribbonCategory[#1]] & )[
    SO35Cat2Bal1] ^= 1
balancedCategory[SO35Cat2Bal2] ^= SO35Cat2Bal2
 
braidedCategory[SO35Cat2Bal2] ^= SO35Cat2Brd2
 
fusionCategory[SO35Cat2Bal2] ^= SO35Cat2
 
pivotalCategory[SO35Cat2Bal2] ^= SO35Cat2Piv1
 
ribbonCategory[SO35Cat2Bal2] ^= SO35Cat2Bal2
 
ring[SO35Cat2Bal2] ^= SO35
 
sphericalCategory[SO35Cat2Bal2] ^= SO35Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[SO35Cat2Brd2]][
      balancedCategory[#1]] & )[SO35Cat2Bal2] ^= 1
 
(balancedCategoryIndex[fusionCategory[SO35Cat2]][balancedCategory[#1]] & )[
    SO35Cat2Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[SO35Cat2Piv1]][
      balancedCategory[#1]] & )[SO35Cat2Bal2] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SO35Cat2Brd2]][ribbonCategory[#1]] & )[
    SO35Cat2Bal2] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SO35Cat2]][ribbonCategory[#1]] & )[
    SO35Cat2Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[SO35Cat2Piv1]][ribbonCategory[#1]] & )[
    SO35Cat2Bal2] ^= 2
balancedCategories[SO35Cat2Brd1] ^= {SO35Cat2Bal1}
 
SO35Cat2Brd1 /: balancedCategory[SO35Cat2Brd1, 1] = SO35Cat2Bal1
 
braidedCategory[SO35Cat2Brd1] ^= SO35Cat2Brd1
 
fusionCategory[SO35Cat2Brd1] ^= SO35Cat2
 
SO35Cat2Brd1 /: modularCategory[SO35Cat2Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SO35Cat2Brd1 /: ribbonCategory[SO35Cat2Brd1, 1] = SO35Cat2Bal1
 
ring[SO35Cat2Brd1] ^= SO35
 
rMatrixFunction[SO35Cat2Brd1] ^= SO35Cat2Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SO35Cat2]][braidedCategory[#1]] & )[
    SO35Cat2Brd1] ^= 1
braidedCategory[SO35Cat2Brd1RMatrixFunction] ^= SO35Cat2Brd1
 
fusionCategory[SO35Cat2Brd1RMatrixFunction] ^= SO35Cat2
 
rMatrixFunction[SO35Cat2Brd1RMatrixFunction] ^= SO35Cat2Brd1RMatrixFunction
 
SO35Cat2Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
SO35Cat2Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
SO35Cat2Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
SO35Cat2Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
SO35Cat2Brd1RMatrixFunction[1, 1, 0] = {{(-1)^(6/7)}}
 
SO35Cat2Brd1RMatrixFunction[1, 1, 2] = {{(-1)^(5/7)}}
 
SO35Cat2Brd1RMatrixFunction[1, 2, 1] = {{-(-1)^(1/7)}}
 
SO35Cat2Brd1RMatrixFunction[1, 2, 2] = {{(-1)^(3/7)}}
 
SO35Cat2Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
SO35Cat2Brd1RMatrixFunction[2, 1, 1] = {{-(-1)^(1/7)}}
 
SO35Cat2Brd1RMatrixFunction[2, 1, 2] = {{(-1)^(3/7)}}
 
SO35Cat2Brd1RMatrixFunction[2, 2, 0] = {{(-1)^(2/7)}}
 
SO35Cat2Brd1RMatrixFunction[2, 2, 1] = {{(-1)^(6/7)}}
 
SO35Cat2Brd1RMatrixFunction[2, 2, 2] = {{(-1)^(1/7)}}
balancedCategories[SO35Cat2Brd2] ^= {SO35Cat2Bal2}
 
SO35Cat2Brd2 /: balancedCategory[SO35Cat2Brd2, 1] = SO35Cat2Bal2
 
braidedCategory[SO35Cat2Brd2] ^= SO35Cat2Brd2
 
fusionCategory[SO35Cat2Brd2] ^= SO35Cat2
 
SO35Cat2Brd2 /: modularCategory[SO35Cat2Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SO35Cat2Brd2 /: ribbonCategory[SO35Cat2Brd2, 1] = SO35Cat2Bal2
 
ring[SO35Cat2Brd2] ^= SO35
 
rMatrixFunction[SO35Cat2Brd2] ^= SO35Cat2Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SO35Cat2]][braidedCategory[#1]] & )[
    SO35Cat2Brd2] ^= 2
braidedCategory[SO35Cat2Brd2RMatrixFunction] ^= SO35Cat2Brd2
 
fusionCategory[SO35Cat2Brd2RMatrixFunction] ^= SO35Cat2
 
rMatrixFunction[SO35Cat2Brd2RMatrixFunction] ^= SO35Cat2Brd2RMatrixFunction
 
SO35Cat2Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
SO35Cat2Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
SO35Cat2Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
SO35Cat2Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
SO35Cat2Brd2RMatrixFunction[1, 1, 0] = {{-(-1)^(1/7)}}
 
SO35Cat2Brd2RMatrixFunction[1, 1, 2] = {{-(-1)^(2/7)}}
 
SO35Cat2Brd2RMatrixFunction[1, 2, 1] = {{(-1)^(6/7)}}
 
SO35Cat2Brd2RMatrixFunction[1, 2, 2] = {{-(-1)^(4/7)}}
 
SO35Cat2Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
SO35Cat2Brd2RMatrixFunction[2, 1, 1] = {{(-1)^(6/7)}}
 
SO35Cat2Brd2RMatrixFunction[2, 1, 2] = {{-(-1)^(4/7)}}
 
SO35Cat2Brd2RMatrixFunction[2, 2, 0] = {{-(-1)^(5/7)}}
 
SO35Cat2Brd2RMatrixFunction[2, 2, 1] = {{-(-1)^(1/7)}}
 
SO35Cat2Brd2RMatrixFunction[2, 2, 2] = {{-(-1)^(6/7)}}
fMatrixFunction[SO35Cat2FMatrixFunction] ^= SO35Cat2FMatrixFunction
 
fusionCategory[SO35Cat2FMatrixFunction] ^= SO35Cat2
 
ring[SO35Cat2FMatrixFunction] ^= SO35
 
SO35Cat2FMatrixFunction[1, 1, 1, 1] = 
   {{Root[1 - #1 - 2*#1^2 + #1^3 & , 3, 0], Root[1 + 6*#1 + 5*#1^2 + #1^3 & , 
      1, 0]}, {Root[1 - 2*#1 - #1^2 + #1^3 & , 1, 0], 
     Root[1 - #1 - 2*#1^2 + #1^3 & , 3, 0]}}
 
SO35Cat2FMatrixFunction[1, 1, 1, 2] = {{-1}}
 
SO35Cat2FMatrixFunction[1, 1, 2, 2] = 
   {{Root[1 - 4*#1 + 3*#1^2 + #1^3 & , 3, 0], 
     Root[-1 - 2*#1 + #1^2 + #1^3 & , 3, 0]}, 
    {Root[1 - 2*#1 - #1^2 + #1^3 & , 1, 0], Root[1 - 2*#1 - #1^2 + #1^3 & , 
      1, 0]}}
 
SO35Cat2FMatrixFunction[1, 2, 1, 0] = {{-1}}
 
SO35Cat2FMatrixFunction[1, 2, 1, 2] = 
   {{Root[1 - 2*#1 - #1^2 + #1^3 & , 1, 0], Root[-1 - #1 + 2*#1^2 + #1^3 & , 
      2, 0]}, {-1, Root[1 - 2*#1 - #1^2 + #1^3 & , 1, 0]}}
 
SO35Cat2FMatrixFunction[1, 2, 2, 1] = 
   {{Root[-1 - 2*#1 + #1^2 + #1^3 & , 1, 0], Root[-1 - 2*#1 + #1^2 + #1^3 & , 
      1, 0]}, {Root[1 - 2*#1 - #1^2 + #1^3 & , 3, 0], 1}}
 
SO35Cat2FMatrixFunction[1, 2, 2, 2] = 
   {{Root[-1 - #1 + 2*#1^2 + #1^3 & , 2, 0], 
     Root[1 - 4*#1 + 3*#1^2 + #1^3 & , 3, 0]}, 
    {1, Root[1 - #1 - 2*#1^2 + #1^3 & , 2, 0]}}
 
SO35Cat2FMatrixFunction[2, 1, 1, 0] = {{-1}}
 
SO35Cat2FMatrixFunction[2, 1, 1, 2] = 
   {{Root[1 - 2*#1 - #1^2 + #1^3 & , 3, 0], Root[-1 - 2*#1 + #1^2 + #1^3 & , 
      1, 0]}, {Root[-1 - 2*#1 + #1^2 + #1^3 & , 1, 0], 1}}
 
SO35Cat2FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
SO35Cat2FMatrixFunction[2, 1, 2, 1] = 
   {{Root[-1 - 2*#1 + #1^2 + #1^3 & , 3, 0], Root[-1 - #1 + 2*#1^2 + #1^3 & , 
      2, 0]}, {-1, Root[-1 - 2*#1 + #1^2 + #1^3 & , 3, 0]}}
 
SO35Cat2FMatrixFunction[2, 1, 2, 2] = 
   {{Root[-1 - #1 + 2*#1^2 + #1^3 & , 2, 0], 
     Root[1 - 4*#1 + 3*#1^2 + #1^3 & , 3, 0]}, 
    {-1, Root[-1 - #1 + 2*#1^2 + #1^3 & , 2, 0]}}
 
SO35Cat2FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
SO35Cat2FMatrixFunction[2, 2, 1, 1] = 
   {{Root[1 - 4*#1 + 3*#1^2 + #1^3 & , 3, 0], Root[1 - 2*#1 - #1^2 + #1^3 & , 
      1, 0]}, {Root[-1 - 2*#1 + #1^2 + #1^3 & , 3, 0], 
     Root[1 - 2*#1 - #1^2 + #1^3 & , 1, 0]}}
 
SO35Cat2FMatrixFunction[2, 2, 1, 2] = 
   {{Root[-1 - #1 + 2*#1^2 + #1^3 & , 2, 0], 
     Root[-1 - 4*#1 - 3*#1^2 + #1^3 & , 1, 0]}, 
    {-1, Root[1 - #1 - 2*#1^2 + #1^3 & , 2, 0]}}
 
SO35Cat2FMatrixFunction[2, 2, 2, 1] = 
   {{Root[1 - #1 - 2*#1^2 + #1^3 & , 2, 0], 
     Root[-1 - 4*#1 - 3*#1^2 + #1^3 & , 1, 0]}, 
    {1, Root[1 - #1 - 2*#1^2 + #1^3 & , 2, 0]}}
 
SO35Cat2FMatrixFunction[2, 2, 2, 2] = 
   {{Root[1 - 2*#1 - #1^2 + #1^3 & , 1, 0], 1, 
     Root[1 - 2*#1 - #1^2 + #1^3 & , 1, 0]}, 
    {Root[-1 - 4*#1 - 3*#1^2 + #1^3 & , 1, 0], 
     Root[-1 - 4*#1 - 3*#1^2 + #1^3 & , 1, 0], 
     Root[1 - #1 - 9*#1^2 + #1^3 & , 1, 0]}, 
    {1, Root[-1 - 2*#1 + #1^2 + #1^3 & , 2, 0], 
     Root[-1 + 6*#1 - 5*#1^2 + #1^3 & , 2, 0]}}
 
SO35Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SO35Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
SO35Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SO35Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[SO35Cat2Piv1] ^= {SO35Cat2Bal1, SO35Cat2Bal2}
 
SO35Cat2Piv1 /: balancedCategory[SO35Cat2Piv1, 1] = SO35Cat2Bal1
 
SO35Cat2Piv1 /: balancedCategory[SO35Cat2Piv1, 2] = SO35Cat2Bal2
 
fusionCategory[SO35Cat2Piv1] ^= SO35Cat2
 
SO35Cat2Piv1 /: modularCategory[SO35Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SO35Cat2Piv1] ^= SO35Cat2Piv1
 
pivotalIsomorphism[SO35Cat2Piv1] ^= SO35Cat2Piv1PivotalIsomorphism
 
SO35Cat2Piv1 /: ribbonCategory[SO35Cat2Piv1, 1] = SO35Cat2Bal1
 
SO35Cat2Piv1 /: ribbonCategory[SO35Cat2Piv1, 2] = SO35Cat2Bal2
 
ring[SO35Cat2Piv1] ^= SO35
 
sphericalCategory[SO35Cat2Piv1] ^= SO35Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[SO35Cat2]][pivotalCategory[#1]] & )[
    SO35Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[SO35Cat2]][sphericalCategory[#1]] & )[
    SO35Cat2Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[SO35Cat2Piv1PivotalIsomorphism] ^= SO35Cat2
 
pivotalCategory[SO35Cat2Piv1PivotalIsomorphism] ^= SO35Cat2Piv1
 
pivotalIsomorphism[SO35Cat2Piv1PivotalIsomorphism] ^= 
   SO35Cat2Piv1PivotalIsomorphism
 
SO35Cat2Piv1PivotalIsomorphism[0] = 1
 
SO35Cat2Piv1PivotalIsomorphism[1] = 1
 
SO35Cat2Piv1PivotalIsomorphism[2] = 1
balancedCategories[SO35Cat3] ^= {SO35Cat3Bal1, SO35Cat3Bal2}
 
SO35Cat3 /: balancedCategory[SO35Cat3, 1] = SO35Cat3Bal1
 
SO35Cat3 /: balancedCategory[SO35Cat3, 2] = SO35Cat3Bal2
 
braidedCategories[SO35Cat3] ^= {SO35Cat3Brd1, SO35Cat3Brd2}
 
SO35Cat3 /: braidedCategory[SO35Cat3, 1] = SO35Cat3Brd1
 
SO35Cat3 /: braidedCategory[SO35Cat3, 2] = SO35Cat3Brd2
 
coeval[SO35Cat3] ^= 1/sixJFunction[SO35Cat3][#1, dual[ring[SO35Cat3]][#1], 
      #1, #1, 0, 0] & 
 
eval[SO35Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[SO35Cat3] ^= SO35Cat3FMatrixFunction
 
fusionCategory[SO35Cat3] ^= SO35Cat3
 
SO35Cat3 /: modularCategory[SO35Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[SO35Cat3] ^= {SO35Cat3Piv1}
 
SO35Cat3 /: pivotalCategory[SO35Cat3, 1] = SO35Cat3Piv1
 
SO35Cat3 /: pivotalCategory[SO35Cat3, {1, 1, 1}] = SO35Cat3Piv1
 
SO35Cat3 /: ribbonCategory[SO35Cat3, 1] = SO35Cat3Bal1
 
SO35Cat3 /: ribbonCategory[SO35Cat3, 2] = SO35Cat3Bal2
 
ring[SO35Cat3] ^= SO35
 
SO35Cat3 /: sphericalCategory[SO35Cat3, 1] = SO35Cat3Piv1
 
fusionCategoryIndex[SO35][SO35Cat3] ^= 3
balancedCategory[SO35Cat3Bal1] ^= SO35Cat3Bal1
 
braidedCategory[SO35Cat3Bal1] ^= SO35Cat3Brd1
 
fusionCategory[SO35Cat3Bal1] ^= SO35Cat3
 
pivotalCategory[SO35Cat3Bal1] ^= SO35Cat3Piv1
 
ribbonCategory[SO35Cat3Bal1] ^= SO35Cat3Bal1
 
ring[SO35Cat3Bal1] ^= SO35
 
sphericalCategory[SO35Cat3Bal1] ^= SO35Cat3Piv1
 
(balancedCategoryIndex[braidedCategory[SO35Cat3Brd1]][
      balancedCategory[#1]] & )[SO35Cat3Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[SO35Cat3]][balancedCategory[#1]] & )[
    SO35Cat3Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[SO35Cat3Piv1]][
      balancedCategory[#1]] & )[SO35Cat3Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SO35Cat3Brd1]][ribbonCategory[#1]] & )[
    SO35Cat3Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SO35Cat3]][ribbonCategory[#1]] & )[
    SO35Cat3Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[SO35Cat3Piv1]][ribbonCategory[#1]] & )[
    SO35Cat3Bal1] ^= 1
balancedCategory[SO35Cat3Bal2] ^= SO35Cat3Bal2
 
braidedCategory[SO35Cat3Bal2] ^= SO35Cat3Brd2
 
fusionCategory[SO35Cat3Bal2] ^= SO35Cat3
 
pivotalCategory[SO35Cat3Bal2] ^= SO35Cat3Piv1
 
ribbonCategory[SO35Cat3Bal2] ^= SO35Cat3Bal2
 
ring[SO35Cat3Bal2] ^= SO35
 
sphericalCategory[SO35Cat3Bal2] ^= SO35Cat3Piv1
 
(balancedCategoryIndex[braidedCategory[SO35Cat3Brd2]][
      balancedCategory[#1]] & )[SO35Cat3Bal2] ^= 1
 
(balancedCategoryIndex[fusionCategory[SO35Cat3]][balancedCategory[#1]] & )[
    SO35Cat3Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[SO35Cat3Piv1]][
      balancedCategory[#1]] & )[SO35Cat3Bal2] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SO35Cat3Brd2]][ribbonCategory[#1]] & )[
    SO35Cat3Bal2] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SO35Cat3]][ribbonCategory[#1]] & )[
    SO35Cat3Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[SO35Cat3Piv1]][ribbonCategory[#1]] & )[
    SO35Cat3Bal2] ^= 2
balancedCategories[SO35Cat3Brd1] ^= {SO35Cat3Bal1}
 
SO35Cat3Brd1 /: balancedCategory[SO35Cat3Brd1, 1] = SO35Cat3Bal1
 
braidedCategory[SO35Cat3Brd1] ^= SO35Cat3Brd1
 
fusionCategory[SO35Cat3Brd1] ^= SO35Cat3
 
SO35Cat3Brd1 /: modularCategory[SO35Cat3Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SO35Cat3Brd1 /: ribbonCategory[SO35Cat3Brd1, 1] = SO35Cat3Bal1
 
ring[SO35Cat3Brd1] ^= SO35
 
rMatrixFunction[SO35Cat3Brd1] ^= SO35Cat3Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SO35Cat3]][braidedCategory[#1]] & )[
    SO35Cat3Brd1] ^= 1
braidedCategory[SO35Cat3Brd1RMatrixFunction] ^= SO35Cat3Brd1
 
fusionCategory[SO35Cat3Brd1RMatrixFunction] ^= SO35Cat3
 
rMatrixFunction[SO35Cat3Brd1RMatrixFunction] ^= SO35Cat3Brd1RMatrixFunction
 
SO35Cat3Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
SO35Cat3Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
SO35Cat3Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
SO35Cat3Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
SO35Cat3Brd1RMatrixFunction[1, 1, 0] = {{(-1)^(4/7)}}
 
SO35Cat3Brd1RMatrixFunction[1, 1, 2] = {{(-1)^(1/7)}}
 
SO35Cat3Brd1RMatrixFunction[1, 2, 1] = {{-(-1)^(3/7)}}
 
SO35Cat3Brd1RMatrixFunction[1, 2, 2] = {{-(-1)^(2/7)}}
 
SO35Cat3Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
SO35Cat3Brd1RMatrixFunction[2, 1, 1] = {{-(-1)^(3/7)}}
 
SO35Cat3Brd1RMatrixFunction[2, 1, 2] = {{-(-1)^(2/7)}}
 
SO35Cat3Brd1RMatrixFunction[2, 2, 0] = {{(-1)^(6/7)}}
 
SO35Cat3Brd1RMatrixFunction[2, 2, 1] = {{(-1)^(4/7)}}
 
SO35Cat3Brd1RMatrixFunction[2, 2, 2] = {{(-1)^(3/7)}}
balancedCategories[SO35Cat3Brd2] ^= {SO35Cat3Bal2}
 
SO35Cat3Brd2 /: balancedCategory[SO35Cat3Brd2, 1] = SO35Cat3Bal2
 
braidedCategory[SO35Cat3Brd2] ^= SO35Cat3Brd2
 
fusionCategory[SO35Cat3Brd2] ^= SO35Cat3
 
SO35Cat3Brd2 /: modularCategory[SO35Cat3Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SO35Cat3Brd2 /: ribbonCategory[SO35Cat3Brd2, 1] = SO35Cat3Bal2
 
ring[SO35Cat3Brd2] ^= SO35
 
rMatrixFunction[SO35Cat3Brd2] ^= SO35Cat3Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SO35Cat3]][braidedCategory[#1]] & )[
    SO35Cat3Brd2] ^= 2
braidedCategory[SO35Cat3Brd2RMatrixFunction] ^= SO35Cat3Brd2
 
fusionCategory[SO35Cat3Brd2RMatrixFunction] ^= SO35Cat3
 
rMatrixFunction[SO35Cat3Brd2RMatrixFunction] ^= SO35Cat3Brd2RMatrixFunction
 
SO35Cat3Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
SO35Cat3Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
SO35Cat3Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
SO35Cat3Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
SO35Cat3Brd2RMatrixFunction[1, 1, 0] = {{-(-1)^(3/7)}}
 
SO35Cat3Brd2RMatrixFunction[1, 1, 2] = {{-(-1)^(6/7)}}
 
SO35Cat3Brd2RMatrixFunction[1, 2, 1] = {{(-1)^(4/7)}}
 
SO35Cat3Brd2RMatrixFunction[1, 2, 2] = {{(-1)^(5/7)}}
 
SO35Cat3Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
SO35Cat3Brd2RMatrixFunction[2, 1, 1] = {{(-1)^(4/7)}}
 
SO35Cat3Brd2RMatrixFunction[2, 1, 2] = {{(-1)^(5/7)}}
 
SO35Cat3Brd2RMatrixFunction[2, 2, 0] = {{-(-1)^(1/7)}}
 
SO35Cat3Brd2RMatrixFunction[2, 2, 1] = {{-(-1)^(3/7)}}
 
SO35Cat3Brd2RMatrixFunction[2, 2, 2] = {{-(-1)^(4/7)}}
fMatrixFunction[SO35Cat3FMatrixFunction] ^= SO35Cat3FMatrixFunction
 
fusionCategory[SO35Cat3FMatrixFunction] ^= SO35Cat3
 
ring[SO35Cat3FMatrixFunction] ^= SO35
 
SO35Cat3FMatrixFunction[1, 1, 1, 1] = 
   {{Root[1 - #1 - 2*#1^2 + #1^3 & , 1, 0], Root[1 + 6*#1 + 5*#1^2 + #1^3 & , 
      3, 0]}, {Root[1 - 2*#1 - #1^2 + #1^3 & , 3, 0], 
     Root[1 - #1 - 2*#1^2 + #1^3 & , 1, 0]}}
 
SO35Cat3FMatrixFunction[1, 1, 1, 2] = {{-1}}
 
SO35Cat3FMatrixFunction[1, 1, 2, 2] = 
   {{Root[1 - 4*#1 + 3*#1^2 + #1^3 & , 1, 0], 
     Root[-1 - 2*#1 + #1^2 + #1^3 & , 1, 0]}, 
    {Root[1 - 2*#1 - #1^2 + #1^3 & , 3, 0], Root[1 - 2*#1 - #1^2 + #1^3 & , 
      3, 0]}}
 
SO35Cat3FMatrixFunction[1, 2, 1, 0] = {{-1}}
 
SO35Cat3FMatrixFunction[1, 2, 1, 2] = 
   {{Root[1 - 2*#1 - #1^2 + #1^3 & , 3, 0], Root[-1 - #1 + 2*#1^2 + #1^3 & , 
      1, 0]}, {-1, Root[1 - 2*#1 - #1^2 + #1^3 & , 3, 0]}}
 
SO35Cat3FMatrixFunction[1, 2, 2, 1] = 
   {{Root[-1 - 2*#1 + #1^2 + #1^3 & , 2, 0], Root[-1 - 2*#1 + #1^2 + #1^3 & , 
      2, 0]}, {Root[1 - 2*#1 - #1^2 + #1^3 & , 2, 0], 1}}
 
SO35Cat3FMatrixFunction[1, 2, 2, 2] = 
   {{Root[-1 - #1 + 2*#1^2 + #1^3 & , 1, 0], 
     Root[1 - 4*#1 + 3*#1^2 + #1^3 & , 1, 0]}, 
    {1, Root[1 - #1 - 2*#1^2 + #1^3 & , 3, 0]}}
 
SO35Cat3FMatrixFunction[2, 1, 1, 0] = {{-1}}
 
SO35Cat3FMatrixFunction[2, 1, 1, 2] = 
   {{Root[1 - 2*#1 - #1^2 + #1^3 & , 2, 0], Root[-1 - 2*#1 + #1^2 + #1^3 & , 
      2, 0]}, {Root[-1 - 2*#1 + #1^2 + #1^3 & , 2, 0], 1}}
 
SO35Cat3FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
SO35Cat3FMatrixFunction[2, 1, 2, 1] = 
   {{Root[-1 - 2*#1 + #1^2 + #1^3 & , 1, 0], Root[-1 - #1 + 2*#1^2 + #1^3 & , 
      1, 0]}, {-1, Root[-1 - 2*#1 + #1^2 + #1^3 & , 1, 0]}}
 
SO35Cat3FMatrixFunction[2, 1, 2, 2] = 
   {{Root[-1 - #1 + 2*#1^2 + #1^3 & , 1, 0], 
     Root[1 - 4*#1 + 3*#1^2 + #1^3 & , 1, 0]}, 
    {-1, Root[-1 - #1 + 2*#1^2 + #1^3 & , 1, 0]}}
 
SO35Cat3FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
SO35Cat3FMatrixFunction[2, 2, 1, 1] = 
   {{Root[1 - 4*#1 + 3*#1^2 + #1^3 & , 1, 0], Root[1 - 2*#1 - #1^2 + #1^3 & , 
      3, 0]}, {Root[-1 - 2*#1 + #1^2 + #1^3 & , 1, 0], 
     Root[1 - 2*#1 - #1^2 + #1^3 & , 3, 0]}}
 
SO35Cat3FMatrixFunction[2, 2, 1, 2] = 
   {{Root[-1 - #1 + 2*#1^2 + #1^3 & , 1, 0], 
     Root[-1 - 4*#1 - 3*#1^2 + #1^3 & , 3, 0]}, 
    {-1, Root[1 - #1 - 2*#1^2 + #1^3 & , 3, 0]}}
 
SO35Cat3FMatrixFunction[2, 2, 2, 1] = 
   {{Root[1 - #1 - 2*#1^2 + #1^3 & , 3, 0], 
     Root[-1 - 4*#1 - 3*#1^2 + #1^3 & , 3, 0]}, 
    {1, Root[1 - #1 - 2*#1^2 + #1^3 & , 3, 0]}}
 
SO35Cat3FMatrixFunction[2, 2, 2, 2] = 
   {{Root[1 - 2*#1 - #1^2 + #1^3 & , 3, 0], 1, 
     Root[1 - 2*#1 - #1^2 + #1^3 & , 3, 0]}, 
    {Root[-1 - 4*#1 - 3*#1^2 + #1^3 & , 3, 0], 
     Root[-1 - 4*#1 - 3*#1^2 + #1^3 & , 3, 0], 
     Root[1 - #1 - 9*#1^2 + #1^3 & , 3, 0]}, 
    {1, Root[-1 - 2*#1 + #1^2 + #1^3 & , 3, 0], 
     Root[-1 + 6*#1 - 5*#1^2 + #1^3 & , 3, 0]}}
 
SO35Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SO35Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
SO35Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SO35Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[SO35Cat3Piv1] ^= {SO35Cat3Bal1, SO35Cat3Bal2}
 
SO35Cat3Piv1 /: balancedCategory[SO35Cat3Piv1, 1] = SO35Cat3Bal1
 
SO35Cat3Piv1 /: balancedCategory[SO35Cat3Piv1, 2] = SO35Cat3Bal2
 
fusionCategory[SO35Cat3Piv1] ^= SO35Cat3
 
SO35Cat3Piv1 /: modularCategory[SO35Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SO35Cat3Piv1] ^= SO35Cat3Piv1
 
pivotalIsomorphism[SO35Cat3Piv1] ^= SO35Cat3Piv1PivotalIsomorphism
 
SO35Cat3Piv1 /: ribbonCategory[SO35Cat3Piv1, 1] = SO35Cat3Bal1
 
SO35Cat3Piv1 /: ribbonCategory[SO35Cat3Piv1, 2] = SO35Cat3Bal2
 
ring[SO35Cat3Piv1] ^= SO35
 
sphericalCategory[SO35Cat3Piv1] ^= SO35Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[SO35Cat3]][pivotalCategory[#1]] & )[
    SO35Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[SO35Cat3]][sphericalCategory[#1]] & )[
    SO35Cat3Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[SO35Cat3Piv1PivotalIsomorphism] ^= SO35Cat3
 
pivotalCategory[SO35Cat3Piv1PivotalIsomorphism] ^= SO35Cat3Piv1
 
pivotalIsomorphism[SO35Cat3Piv1PivotalIsomorphism] ^= 
   SO35Cat3Piv1PivotalIsomorphism
 
SO35Cat3Piv1PivotalIsomorphism[0] = 1
 
SO35Cat3Piv1PivotalIsomorphism[1] = 1
 
SO35Cat3Piv1PivotalIsomorphism[2] = 1
ring[SO35NFunction] ^= SO35
 
SO35NFunction[0, 0, 0] = 1
 
SO35NFunction[0, 0, 1] = 0
 
SO35NFunction[0, 0, 2] = 0
 
SO35NFunction[0, 1, 0] = 0
 
SO35NFunction[0, 1, 1] = 1
 
SO35NFunction[0, 1, 2] = 0
 
SO35NFunction[0, 2, 0] = 0
 
SO35NFunction[0, 2, 1] = 0
 
SO35NFunction[0, 2, 2] = 1
 
SO35NFunction[1, 0, 0] = 0
 
SO35NFunction[1, 0, 1] = 1
 
SO35NFunction[1, 0, 2] = 0
 
SO35NFunction[1, 1, 0] = 1
 
SO35NFunction[1, 1, 1] = 0
 
SO35NFunction[1, 1, 2] = 1
 
SO35NFunction[1, 2, 0] = 0
 
SO35NFunction[1, 2, 1] = 1
 
SO35NFunction[1, 2, 2] = 1
 
SO35NFunction[2, 0, 0] = 0
 
SO35NFunction[2, 0, 1] = 0
 
SO35NFunction[2, 0, 2] = 1
 
SO35NFunction[2, 1, 0] = 0
 
SO35NFunction[2, 1, 1] = 1
 
SO35NFunction[2, 1, 2] = 1
 
SO35NFunction[2, 2, 0] = 1
 
SO35NFunction[2, 2, 1] = 1
 
SO35NFunction[2, 2, 2] = 1
 
SO35NFunction[FusionCategories`Data`SO35`Private`a_, FusionCategories`Data`SO35`Private`b_, FusionCategories`Data`SO35`Private`c_] := 0


 EndPackage[]
