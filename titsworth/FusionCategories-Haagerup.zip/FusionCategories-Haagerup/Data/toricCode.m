BeginPackage["FusionCategories`Data`toricCode`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[toricCode] ^= {toricCodeCat1, toricCodeCat2, toricCodeCat3, 
    toricCodeCat4}
 
toricCode /: fusionCategory[toricCode, 1] = toricCodeCat1
 
toricCode /: fusionCategory[toricCode, 2] = toricCodeCat2
 
toricCode /: fusionCategory[toricCode, 3] = toricCodeCat3
 
toricCode /: fusionCategory[toricCode, 4] = toricCodeCat4
 
nFunction[toricCode] ^= toricCodeNFunction
 
noMultiplicities[toricCode] ^= True
 
rank[toricCode] ^= 4
 
ring[toricCode] ^= toricCode
balancedCategories[toricCodeCat1] ^= {}
 
braidedCategories[toricCodeCat1] ^= {}
 
coeval[toricCodeCat1] ^= 1/sixJFunction[toricCodeCat1][#1, 
      dual[ring[toricCodeCat1]][#1], #1, #1, 0, 0] & 
 
eval[toricCodeCat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[toricCodeCat1] ^= toricCodeCat1FMatrixFunction
 
fusionCategory[toricCodeCat1] ^= toricCodeCat1
 
toricCodeCat1 /: modularCategory[toricCodeCat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[toricCodeCat1] ^= {toricCodeCat1Piv1, toricCodeCat1Piv2, 
    toricCodeCat1Piv3, toricCodeCat1Piv4}
 
toricCodeCat1 /: pivotalCategory[toricCodeCat1, 1] = toricCodeCat1Piv1
 
toricCodeCat1 /: pivotalCategory[toricCodeCat1, 2] = toricCodeCat1Piv2
 
toricCodeCat1 /: pivotalCategory[toricCodeCat1, 3] = toricCodeCat1Piv3
 
toricCodeCat1 /: pivotalCategory[toricCodeCat1, 4] = toricCodeCat1Piv4
 
toricCodeCat1 /: pivotalCategory[toricCodeCat1, {1, -1, -1, -1}] = 
    toricCodeCat1Piv1
 
toricCodeCat1 /: pivotalCategory[toricCodeCat1, {1, -1, 1, 1}] = 
    toricCodeCat1Piv3
 
toricCodeCat1 /: pivotalCategory[toricCodeCat1, {1, 1, -1, 1}] = 
    toricCodeCat1Piv2
 
toricCodeCat1 /: pivotalCategory[toricCodeCat1, {1, 1, 1, -1}] = 
    toricCodeCat1Piv4
 
ring[toricCodeCat1] ^= toricCode
 
toricCodeCat1 /: sphericalCategory[toricCodeCat1, 1] = toricCodeCat1Piv1
 
toricCodeCat1 /: sphericalCategory[toricCodeCat1, 2] = toricCodeCat1Piv2
 
toricCodeCat1 /: sphericalCategory[toricCodeCat1, 3] = toricCodeCat1Piv3
 
toricCodeCat1 /: sphericalCategory[toricCodeCat1, 4] = toricCodeCat1Piv4
 
fusionCategoryIndex[toricCode][toricCodeCat1] ^= 1
fMatrixFunction[toricCodeCat1FMatrixFunction] ^= toricCodeCat1FMatrixFunction
 
fusionCategory[toricCodeCat1FMatrixFunction] ^= toricCodeCat1
 
ring[toricCodeCat1FMatrixFunction] ^= toricCode
 
toricCodeCat1FMatrixFunction[1, 1, 1, 1] = {{-1}}
 
toricCodeCat1FMatrixFunction[1, 1, 3, 3] = {{-1}}
 
toricCodeCat1FMatrixFunction[1, 2, 1, 2] = {{-1}}
 
toricCodeCat1FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
toricCodeCat1FMatrixFunction[2, 1, 1, 2] = {{-1}}
 
toricCodeCat1FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
toricCodeCat1FMatrixFunction[2, 2, 2, 2] = {{-1}}
 
toricCodeCat1FMatrixFunction[2, 3, 2, 3] = {{-1}}
 
toricCodeCat1FMatrixFunction[3, 1, 2, 0] = {{-1}}
 
toricCodeCat1FMatrixFunction[3, 2, 1, 0] = {{-1}}
 
toricCodeCat1FMatrixFunction[3, 2, 2, 3] = {{-1}}
 
toricCodeCat1FMatrixFunction[3, 2, 3, 2] = {{-1}}
 
toricCodeCat1FMatrixFunction[3, 3, 1, 1] = {{-1}}
 
toricCodeCat1FMatrixFunction[3, 3, 3, 3] = {{-1}}
 
toricCodeCat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[toricCodeCat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
toricCodeCat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[toricCodeCat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[toricCodeCat1Piv1] ^= {}
 
fusionCategory[toricCodeCat1Piv1] ^= toricCodeCat1
 
toricCodeCat1Piv1 /: modularCategory[toricCodeCat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[toricCodeCat1Piv1] ^= toricCodeCat1Piv1
 
pivotalIsomorphism[toricCodeCat1Piv1] ^= toricCodeCat1Piv1PivotalIsomorphism
 
ring[toricCodeCat1Piv1] ^= toricCode
 
sphericalCategory[toricCodeCat1Piv1] ^= toricCodeCat1Piv1
 
(pivotalCategoryIndex[fusionCategory[toricCodeCat1]][pivotalCategory[#1]] & )[
    toricCodeCat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[toricCodeCat1]][
      sphericalCategory[#1]] & )[toricCodeCat1Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[toricCodeCat1Piv1PivotalIsomorphism] ^= toricCodeCat1
 
pivotalCategory[toricCodeCat1Piv1PivotalIsomorphism] ^= toricCodeCat1Piv1
 
pivotalIsomorphism[toricCodeCat1Piv1PivotalIsomorphism] ^= 
   toricCodeCat1Piv1PivotalIsomorphism
 
toricCodeCat1Piv1PivotalIsomorphism[0] = 1
 
toricCodeCat1Piv1PivotalIsomorphism[1] = -1
 
toricCodeCat1Piv1PivotalIsomorphism[2] = -1
 
toricCodeCat1Piv1PivotalIsomorphism[3] = -1
balancedCategories[toricCodeCat1Piv2] ^= {}
 
fusionCategory[toricCodeCat1Piv2] ^= toricCodeCat1
 
toricCodeCat1Piv2 /: modularCategory[toricCodeCat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[toricCodeCat1Piv2] ^= toricCodeCat1Piv2
 
pivotalIsomorphism[toricCodeCat1Piv2] ^= toricCodeCat1Piv2PivotalIsomorphism
 
ring[toricCodeCat1Piv2] ^= toricCode
 
sphericalCategory[toricCodeCat1Piv2] ^= toricCodeCat1Piv2
 
(pivotalCategoryIndex[fusionCategory[toricCodeCat1]][pivotalCategory[#1]] & )[
    toricCodeCat1Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[toricCodeCat1]][
      sphericalCategory[#1]] & )[toricCodeCat1Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[toricCodeCat1Piv2PivotalIsomorphism] ^= toricCodeCat1
 
pivotalCategory[toricCodeCat1Piv2PivotalIsomorphism] ^= toricCodeCat1Piv2
 
pivotalIsomorphism[toricCodeCat1Piv2PivotalIsomorphism] ^= 
   toricCodeCat1Piv2PivotalIsomorphism
 
toricCodeCat1Piv2PivotalIsomorphism[0] = 1
 
toricCodeCat1Piv2PivotalIsomorphism[1] = 1
 
toricCodeCat1Piv2PivotalIsomorphism[2] = -1
 
toricCodeCat1Piv2PivotalIsomorphism[3] = 1
balancedCategories[toricCodeCat1Piv3] ^= {}
 
fusionCategory[toricCodeCat1Piv3] ^= toricCodeCat1
 
toricCodeCat1Piv3 /: modularCategory[toricCodeCat1Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[toricCodeCat1Piv3] ^= toricCodeCat1Piv3
 
pivotalIsomorphism[toricCodeCat1Piv3] ^= toricCodeCat1Piv3PivotalIsomorphism
 
ring[toricCodeCat1Piv3] ^= toricCode
 
sphericalCategory[toricCodeCat1Piv3] ^= toricCodeCat1Piv3
 
(pivotalCategoryIndex[fusionCategory[toricCodeCat1]][pivotalCategory[#1]] & )[
    toricCodeCat1Piv3] ^= 3
 
(sphericalCategoryIndex[fusionCategory[toricCodeCat1]][
      sphericalCategory[#1]] & )[toricCodeCat1Piv3] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[toricCodeCat1Piv3PivotalIsomorphism] ^= toricCodeCat1
 
pivotalCategory[toricCodeCat1Piv3PivotalIsomorphism] ^= toricCodeCat1Piv3
 
pivotalIsomorphism[toricCodeCat1Piv3PivotalIsomorphism] ^= 
   toricCodeCat1Piv3PivotalIsomorphism
 
toricCodeCat1Piv3PivotalIsomorphism[0] = 1
 
toricCodeCat1Piv3PivotalIsomorphism[1] = -1
 
toricCodeCat1Piv3PivotalIsomorphism[2] = 1
 
toricCodeCat1Piv3PivotalIsomorphism[3] = 1
balancedCategories[toricCodeCat1Piv4] ^= {}
 
fusionCategory[toricCodeCat1Piv4] ^= toricCodeCat1
 
toricCodeCat1Piv4 /: modularCategory[toricCodeCat1Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[toricCodeCat1Piv4] ^= toricCodeCat1Piv4
 
pivotalIsomorphism[toricCodeCat1Piv4] ^= toricCodeCat1Piv4PivotalIsomorphism
 
ring[toricCodeCat1Piv4] ^= toricCode
 
sphericalCategory[toricCodeCat1Piv4] ^= toricCodeCat1Piv4
 
(pivotalCategoryIndex[fusionCategory[toricCodeCat1]][pivotalCategory[#1]] & )[
    toricCodeCat1Piv4] ^= 4
 
(sphericalCategoryIndex[fusionCategory[toricCodeCat1]][
      sphericalCategory[#1]] & )[toricCodeCat1Piv4] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[toricCodeCat1Piv4PivotalIsomorphism] ^= toricCodeCat1
 
pivotalCategory[toricCodeCat1Piv4PivotalIsomorphism] ^= toricCodeCat1Piv4
 
pivotalIsomorphism[toricCodeCat1Piv4PivotalIsomorphism] ^= 
   toricCodeCat1Piv4PivotalIsomorphism
 
toricCodeCat1Piv4PivotalIsomorphism[0] = 1
 
toricCodeCat1Piv4PivotalIsomorphism[1] = 1
 
toricCodeCat1Piv4PivotalIsomorphism[2] = 1
 
toricCodeCat1Piv4PivotalIsomorphism[3] = -1
balancedCategories[toricCodeCat2] ^= {}
 
braidedCategories[toricCodeCat2] ^= {}
 
coeval[toricCodeCat2] ^= 1/sixJFunction[toricCodeCat2][#1, 
      dual[ring[toricCodeCat2]][#1], #1, #1, 0, 0] & 
 
eval[toricCodeCat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[toricCodeCat2] ^= toricCodeCat2FMatrixFunction
 
fusionCategory[toricCodeCat2] ^= toricCodeCat2
 
toricCodeCat2 /: modularCategory[toricCodeCat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[toricCodeCat2] ^= {toricCodeCat2Piv1, toricCodeCat2Piv2, 
    toricCodeCat2Piv3, toricCodeCat2Piv4}
 
toricCodeCat2 /: pivotalCategory[toricCodeCat2, 1] = toricCodeCat2Piv1
 
toricCodeCat2 /: pivotalCategory[toricCodeCat2, 2] = toricCodeCat2Piv2
 
toricCodeCat2 /: pivotalCategory[toricCodeCat2, 3] = toricCodeCat2Piv3
 
toricCodeCat2 /: pivotalCategory[toricCodeCat2, 4] = toricCodeCat2Piv4
 
toricCodeCat2 /: pivotalCategory[toricCodeCat2, {1, -1, -1, -1}] = 
    toricCodeCat2Piv1
 
toricCodeCat2 /: pivotalCategory[toricCodeCat2, {1, -1, 1, 1}] = 
    toricCodeCat2Piv3
 
toricCodeCat2 /: pivotalCategory[toricCodeCat2, {1, 1, -1, 1}] = 
    toricCodeCat2Piv2
 
toricCodeCat2 /: pivotalCategory[toricCodeCat2, {1, 1, 1, -1}] = 
    toricCodeCat2Piv4
 
ring[toricCodeCat2] ^= toricCode
 
toricCodeCat2 /: sphericalCategory[toricCodeCat2, 1] = toricCodeCat2Piv1
 
toricCodeCat2 /: sphericalCategory[toricCodeCat2, 2] = toricCodeCat2Piv2
 
toricCodeCat2 /: sphericalCategory[toricCodeCat2, 3] = toricCodeCat2Piv3
 
toricCodeCat2 /: sphericalCategory[toricCodeCat2, 4] = toricCodeCat2Piv4
 
fusionCategoryIndex[toricCode][toricCodeCat2] ^= 2
fMatrixFunction[toricCodeCat2FMatrixFunction] ^= toricCodeCat2FMatrixFunction
 
fusionCategory[toricCodeCat2FMatrixFunction] ^= toricCodeCat2
 
ring[toricCodeCat2FMatrixFunction] ^= toricCode
 
toricCodeCat2FMatrixFunction[1, 1, 1, 1] = {{-1}}
 
toricCodeCat2FMatrixFunction[1, 1, 3, 3] = {{-1}}
 
toricCodeCat2FMatrixFunction[1, 2, 1, 2] = {{-1}}
 
toricCodeCat2FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
toricCodeCat2FMatrixFunction[2, 1, 1, 2] = {{-1}}
 
toricCodeCat2FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
toricCodeCat2FMatrixFunction[2, 2, 3, 3] = {{-1}}
 
toricCodeCat2FMatrixFunction[2, 3, 3, 2] = {{-1}}
 
toricCodeCat2FMatrixFunction[3, 1, 2, 0] = {{-1}}
 
toricCodeCat2FMatrixFunction[3, 2, 1, 0] = {{-1}}
 
toricCodeCat2FMatrixFunction[3, 3, 1, 1] = {{-1}}
 
toricCodeCat2FMatrixFunction[3, 3, 2, 2] = {{-1}}
 
toricCodeCat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[toricCodeCat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
toricCodeCat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[toricCodeCat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[toricCodeCat2Piv1] ^= {}
 
fusionCategory[toricCodeCat2Piv1] ^= toricCodeCat2
 
toricCodeCat2Piv1 /: modularCategory[toricCodeCat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[toricCodeCat2Piv1] ^= toricCodeCat2Piv1
 
pivotalIsomorphism[toricCodeCat2Piv1] ^= toricCodeCat2Piv1PivotalIsomorphism
 
ring[toricCodeCat2Piv1] ^= toricCode
 
sphericalCategory[toricCodeCat2Piv1] ^= toricCodeCat2Piv1
 
(pivotalCategoryIndex[fusionCategory[toricCodeCat2]][pivotalCategory[#1]] & )[
    toricCodeCat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[toricCodeCat2]][
      sphericalCategory[#1]] & )[toricCodeCat2Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[toricCodeCat2Piv1PivotalIsomorphism] ^= toricCodeCat2
 
pivotalCategory[toricCodeCat2Piv1PivotalIsomorphism] ^= toricCodeCat2Piv1
 
pivotalIsomorphism[toricCodeCat2Piv1PivotalIsomorphism] ^= 
   toricCodeCat2Piv1PivotalIsomorphism
 
toricCodeCat2Piv1PivotalIsomorphism[0] = 1
 
toricCodeCat2Piv1PivotalIsomorphism[1] = -1
 
toricCodeCat2Piv1PivotalIsomorphism[2] = -1
 
toricCodeCat2Piv1PivotalIsomorphism[3] = -1
balancedCategories[toricCodeCat2Piv2] ^= {}
 
fusionCategory[toricCodeCat2Piv2] ^= toricCodeCat2
 
toricCodeCat2Piv2 /: modularCategory[toricCodeCat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[toricCodeCat2Piv2] ^= toricCodeCat2Piv2
 
pivotalIsomorphism[toricCodeCat2Piv2] ^= toricCodeCat2Piv2PivotalIsomorphism
 
ring[toricCodeCat2Piv2] ^= toricCode
 
sphericalCategory[toricCodeCat2Piv2] ^= toricCodeCat2Piv2
 
(pivotalCategoryIndex[fusionCategory[toricCodeCat2]][pivotalCategory[#1]] & )[
    toricCodeCat2Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[toricCodeCat2]][
      sphericalCategory[#1]] & )[toricCodeCat2Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[toricCodeCat2Piv2PivotalIsomorphism] ^= toricCodeCat2
 
pivotalCategory[toricCodeCat2Piv2PivotalIsomorphism] ^= toricCodeCat2Piv2
 
pivotalIsomorphism[toricCodeCat2Piv2PivotalIsomorphism] ^= 
   toricCodeCat2Piv2PivotalIsomorphism
 
toricCodeCat2Piv2PivotalIsomorphism[0] = 1
 
toricCodeCat2Piv2PivotalIsomorphism[1] = 1
 
toricCodeCat2Piv2PivotalIsomorphism[2] = -1
 
toricCodeCat2Piv2PivotalIsomorphism[3] = 1
balancedCategories[toricCodeCat2Piv3] ^= {}
 
fusionCategory[toricCodeCat2Piv3] ^= toricCodeCat2
 
toricCodeCat2Piv3 /: modularCategory[toricCodeCat2Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[toricCodeCat2Piv3] ^= toricCodeCat2Piv3
 
pivotalIsomorphism[toricCodeCat2Piv3] ^= toricCodeCat2Piv3PivotalIsomorphism
 
ring[toricCodeCat2Piv3] ^= toricCode
 
sphericalCategory[toricCodeCat2Piv3] ^= toricCodeCat2Piv3
 
(pivotalCategoryIndex[fusionCategory[toricCodeCat2]][pivotalCategory[#1]] & )[
    toricCodeCat2Piv3] ^= 3
 
(sphericalCategoryIndex[fusionCategory[toricCodeCat2]][
      sphericalCategory[#1]] & )[toricCodeCat2Piv3] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[toricCodeCat2Piv3PivotalIsomorphism] ^= toricCodeCat2
 
pivotalCategory[toricCodeCat2Piv3PivotalIsomorphism] ^= toricCodeCat2Piv3
 
pivotalIsomorphism[toricCodeCat2Piv3PivotalIsomorphism] ^= 
   toricCodeCat2Piv3PivotalIsomorphism
 
toricCodeCat2Piv3PivotalIsomorphism[0] = 1
 
toricCodeCat2Piv3PivotalIsomorphism[1] = -1
 
toricCodeCat2Piv3PivotalIsomorphism[2] = 1
 
toricCodeCat2Piv3PivotalIsomorphism[3] = 1
balancedCategories[toricCodeCat2Piv4] ^= {}
 
fusionCategory[toricCodeCat2Piv4] ^= toricCodeCat2
 
toricCodeCat2Piv4 /: modularCategory[toricCodeCat2Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[toricCodeCat2Piv4] ^= toricCodeCat2Piv4
 
pivotalIsomorphism[toricCodeCat2Piv4] ^= toricCodeCat2Piv4PivotalIsomorphism
 
ring[toricCodeCat2Piv4] ^= toricCode
 
sphericalCategory[toricCodeCat2Piv4] ^= toricCodeCat2Piv4
 
(pivotalCategoryIndex[fusionCategory[toricCodeCat2]][pivotalCategory[#1]] & )[
    toricCodeCat2Piv4] ^= 4
 
(sphericalCategoryIndex[fusionCategory[toricCodeCat2]][
      sphericalCategory[#1]] & )[toricCodeCat2Piv4] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[toricCodeCat2Piv4PivotalIsomorphism] ^= toricCodeCat2
 
pivotalCategory[toricCodeCat2Piv4PivotalIsomorphism] ^= toricCodeCat2Piv4
 
pivotalIsomorphism[toricCodeCat2Piv4PivotalIsomorphism] ^= 
   toricCodeCat2Piv4PivotalIsomorphism
 
toricCodeCat2Piv4PivotalIsomorphism[0] = 1
 
toricCodeCat2Piv4PivotalIsomorphism[1] = 1
 
toricCodeCat2Piv4PivotalIsomorphism[2] = 1
 
toricCodeCat2Piv4PivotalIsomorphism[3] = -1
balancedCategories[toricCodeCat3] ^= {toricCodeCat3Bal1, toricCodeCat3Bal2, 
    toricCodeCat3Bal3, toricCodeCat3Bal4, toricCodeCat3Bal5, 
    toricCodeCat3Bal6, toricCodeCat3Bal7, toricCodeCat3Bal8, 
    toricCodeCat3Bal9, toricCodeCat3Bal10, toricCodeCat3Bal11, 
    toricCodeCat3Bal12, toricCodeCat3Bal13, toricCodeCat3Bal14, 
    toricCodeCat3Bal15, toricCodeCat3Bal16, toricCodeCat3Bal17, 
    toricCodeCat3Bal18, toricCodeCat3Bal19, toricCodeCat3Bal20, 
    toricCodeCat3Bal21, toricCodeCat3Bal22, toricCodeCat3Bal23, 
    toricCodeCat3Bal24, toricCodeCat3Bal25, toricCodeCat3Bal26, 
    toricCodeCat3Bal27, toricCodeCat3Bal28, toricCodeCat3Bal29, 
    toricCodeCat3Bal30, toricCodeCat3Bal31, toricCodeCat3Bal32}
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 1] = toricCodeCat3Bal1
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 2] = toricCodeCat3Bal2
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 3] = toricCodeCat3Bal3
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 4] = toricCodeCat3Bal4
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 5] = toricCodeCat3Bal5
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 6] = toricCodeCat3Bal6
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 7] = toricCodeCat3Bal7
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 8] = toricCodeCat3Bal8
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 9] = toricCodeCat3Bal9
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 10] = toricCodeCat3Bal10
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 11] = toricCodeCat3Bal11
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 12] = toricCodeCat3Bal12
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 13] = toricCodeCat3Bal13
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 14] = toricCodeCat3Bal14
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 15] = toricCodeCat3Bal15
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 16] = toricCodeCat3Bal16
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 17] = toricCodeCat3Bal17
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 18] = toricCodeCat3Bal18
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 19] = toricCodeCat3Bal19
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 20] = toricCodeCat3Bal20
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 21] = toricCodeCat3Bal21
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 22] = toricCodeCat3Bal22
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 23] = toricCodeCat3Bal23
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 24] = toricCodeCat3Bal24
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 25] = toricCodeCat3Bal25
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 26] = toricCodeCat3Bal26
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 27] = toricCodeCat3Bal27
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 28] = toricCodeCat3Bal28
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 29] = toricCodeCat3Bal29
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 30] = toricCodeCat3Bal30
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 31] = toricCodeCat3Bal31
 
toricCodeCat3 /: balancedCategory[toricCodeCat3, 32] = toricCodeCat3Bal32
 
braidedCategories[toricCodeCat3] ^= {toricCodeCat3Brd1, toricCodeCat3Brd2, 
    toricCodeCat3Brd3, toricCodeCat3Brd4, toricCodeCat3Brd5, 
    toricCodeCat3Brd6, toricCodeCat3Brd7, toricCodeCat3Brd8}
 
toricCodeCat3 /: braidedCategory[toricCodeCat3, 1] = toricCodeCat3Brd1
 
toricCodeCat3 /: braidedCategory[toricCodeCat3, 2] = toricCodeCat3Brd2
 
toricCodeCat3 /: braidedCategory[toricCodeCat3, 3] = toricCodeCat3Brd3
 
toricCodeCat3 /: braidedCategory[toricCodeCat3, 4] = toricCodeCat3Brd4
 
toricCodeCat3 /: braidedCategory[toricCodeCat3, 5] = toricCodeCat3Brd5
 
toricCodeCat3 /: braidedCategory[toricCodeCat3, 6] = toricCodeCat3Brd6
 
toricCodeCat3 /: braidedCategory[toricCodeCat3, 7] = toricCodeCat3Brd7
 
toricCodeCat3 /: braidedCategory[toricCodeCat3, 8] = toricCodeCat3Brd8
 
coeval[toricCodeCat3] ^= 1/sixJFunction[toricCodeCat3][#1, 
      dual[ring[toricCodeCat3]][#1], #1, #1, 0, 0] & 
 
eval[toricCodeCat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[toricCodeCat3] ^= toricCodeCat3FMatrixFunction
 
fusionCategory[toricCodeCat3] ^= toricCodeCat3
 
toricCodeCat3 /: modularCategory[toricCodeCat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[toricCodeCat3] ^= {toricCodeCat3Piv1, toricCodeCat3Piv2, 
    toricCodeCat3Piv3, toricCodeCat3Piv4}
 
toricCodeCat3 /: pivotalCategory[toricCodeCat3, 1] = toricCodeCat3Piv1
 
toricCodeCat3 /: pivotalCategory[toricCodeCat3, 2] = toricCodeCat3Piv2
 
toricCodeCat3 /: pivotalCategory[toricCodeCat3, 3] = toricCodeCat3Piv3
 
toricCodeCat3 /: pivotalCategory[toricCodeCat3, 4] = toricCodeCat3Piv4
 
toricCodeCat3 /: pivotalCategory[toricCodeCat3, {1, -1, -1, 1}] = 
    toricCodeCat3Piv2
 
toricCodeCat3 /: pivotalCategory[toricCodeCat3, {1, -1, 1, -1}] = 
    toricCodeCat3Piv4
 
toricCodeCat3 /: pivotalCategory[toricCodeCat3, {1, 1, -1, -1}] = 
    toricCodeCat3Piv3
 
toricCodeCat3 /: pivotalCategory[toricCodeCat3, {1, 1, 1, 1}] = 
    toricCodeCat3Piv1
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 1] = toricCodeCat3Bal1
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 2] = toricCodeCat3Bal2
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 3] = toricCodeCat3Bal3
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 4] = toricCodeCat3Bal4
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 5] = toricCodeCat3Bal5
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 6] = toricCodeCat3Bal6
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 7] = toricCodeCat3Bal7
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 8] = toricCodeCat3Bal8
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 9] = toricCodeCat3Bal9
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 10] = toricCodeCat3Bal10
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 11] = toricCodeCat3Bal11
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 12] = toricCodeCat3Bal12
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 13] = toricCodeCat3Bal13
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 14] = toricCodeCat3Bal14
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 15] = toricCodeCat3Bal15
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 16] = toricCodeCat3Bal16
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 17] = toricCodeCat3Bal17
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 18] = toricCodeCat3Bal18
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 19] = toricCodeCat3Bal19
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 20] = toricCodeCat3Bal20
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 21] = toricCodeCat3Bal21
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 22] = toricCodeCat3Bal22
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 23] = toricCodeCat3Bal23
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 24] = toricCodeCat3Bal24
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 25] = toricCodeCat3Bal25
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 26] = toricCodeCat3Bal26
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 27] = toricCodeCat3Bal27
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 28] = toricCodeCat3Bal28
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 29] = toricCodeCat3Bal29
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 30] = toricCodeCat3Bal30
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 31] = toricCodeCat3Bal31
 
toricCodeCat3 /: ribbonCategory[toricCodeCat3, 32] = toricCodeCat3Bal32
 
ring[toricCodeCat3] ^= toricCode
 
toricCodeCat3 /: sphericalCategory[toricCodeCat3, 1] = toricCodeCat3Piv1
 
toricCodeCat3 /: sphericalCategory[toricCodeCat3, 2] = toricCodeCat3Piv2
 
toricCodeCat3 /: sphericalCategory[toricCodeCat3, 3] = toricCodeCat3Piv3
 
toricCodeCat3 /: sphericalCategory[toricCodeCat3, 4] = toricCodeCat3Piv4
 
fusionCategoryIndex[toricCode][toricCodeCat3] ^= 3
balancedCategory[toricCodeCat3Bal1] ^= toricCodeCat3Bal1
 
braidedCategory[toricCodeCat3Bal1] ^= toricCodeCat3Brd1
 
fusionCategory[toricCodeCat3Bal1] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal1] ^= toricCodeCat3Piv1
 
ribbonCategory[toricCodeCat3Bal1] ^= toricCodeCat3Bal1
 
ring[toricCodeCat3Bal1] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal1] ^= toricCodeCat3Piv1
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd1]][
      balancedCategory[#1]] & )[toricCodeCat3Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv1]][
      balancedCategory[#1]] & )[toricCodeCat3Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd1]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv1]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal1] ^= 1
balancedCategory[toricCodeCat3Bal10] ^= toricCodeCat3Bal10
 
braidedCategory[toricCodeCat3Bal10] ^= toricCodeCat3Brd3
 
fusionCategory[toricCodeCat3Bal10] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal10] ^= toricCodeCat3Piv2
 
ribbonCategory[toricCodeCat3Bal10] ^= toricCodeCat3Bal10
 
ring[toricCodeCat3Bal10] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal10] ^= toricCodeCat3Piv2
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal10] ^= 2
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal10] ^= 10
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv2]][
      balancedCategory[#1]] & )[toricCodeCat3Bal10] ^= 3
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd3]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal10] ^= 2
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal10] ^= 10
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv2]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal10] ^= 3
balancedCategory[toricCodeCat3Bal11] ^= toricCodeCat3Bal11
 
braidedCategory[toricCodeCat3Bal11] ^= toricCodeCat3Brd3
 
fusionCategory[toricCodeCat3Bal11] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal11] ^= toricCodeCat3Piv3
 
ribbonCategory[toricCodeCat3Bal11] ^= toricCodeCat3Bal11
 
ring[toricCodeCat3Bal11] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal11] ^= toricCodeCat3Piv3
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal11] ^= 3
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal11] ^= 11
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal11] ^= 3
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd3]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal11] ^= 3
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal11] ^= 11
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv3]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal11] ^= 3
balancedCategory[toricCodeCat3Bal12] ^= toricCodeCat3Bal12
 
braidedCategory[toricCodeCat3Bal12] ^= toricCodeCat3Brd3
 
fusionCategory[toricCodeCat3Bal12] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal12] ^= toricCodeCat3Piv4
 
ribbonCategory[toricCodeCat3Bal12] ^= toricCodeCat3Bal12
 
ring[toricCodeCat3Bal12] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal12] ^= toricCodeCat3Piv4
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal12] ^= 4
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal12] ^= 12
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv4]][
      balancedCategory[#1]] & )[toricCodeCat3Bal12] ^= 3
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd3]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal12] ^= 4
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal12] ^= 12
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv4]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal12] ^= 3
balancedCategory[toricCodeCat3Bal13] ^= toricCodeCat3Bal13
 
braidedCategory[toricCodeCat3Bal13] ^= toricCodeCat3Brd4
 
fusionCategory[toricCodeCat3Bal13] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal13] ^= toricCodeCat3Piv1
 
ribbonCategory[toricCodeCat3Bal13] ^= toricCodeCat3Bal13
 
ring[toricCodeCat3Bal13] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal13] ^= toricCodeCat3Piv1
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd4]][
      balancedCategory[#1]] & )[toricCodeCat3Bal13] ^= 1
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal13] ^= 13
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv1]][
      balancedCategory[#1]] & )[toricCodeCat3Bal13] ^= 4
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd4]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal13] ^= 1
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal13] ^= 13
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv1]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal13] ^= 4
balancedCategory[toricCodeCat3Bal14] ^= toricCodeCat3Bal14
 
braidedCategory[toricCodeCat3Bal14] ^= toricCodeCat3Brd4
 
fusionCategory[toricCodeCat3Bal14] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal14] ^= toricCodeCat3Piv2
 
ribbonCategory[toricCodeCat3Bal14] ^= toricCodeCat3Bal14
 
ring[toricCodeCat3Bal14] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal14] ^= toricCodeCat3Piv2
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd4]][
      balancedCategory[#1]] & )[toricCodeCat3Bal14] ^= 2
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal14] ^= 14
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv2]][
      balancedCategory[#1]] & )[toricCodeCat3Bal14] ^= 4
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd4]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal14] ^= 2
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal14] ^= 14
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv2]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal14] ^= 4
balancedCategory[toricCodeCat3Bal15] ^= toricCodeCat3Bal15
 
braidedCategory[toricCodeCat3Bal15] ^= toricCodeCat3Brd4
 
fusionCategory[toricCodeCat3Bal15] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal15] ^= toricCodeCat3Piv3
 
ribbonCategory[toricCodeCat3Bal15] ^= toricCodeCat3Bal15
 
ring[toricCodeCat3Bal15] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal15] ^= toricCodeCat3Piv3
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd4]][
      balancedCategory[#1]] & )[toricCodeCat3Bal15] ^= 3
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal15] ^= 15
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal15] ^= 4
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd4]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal15] ^= 3
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal15] ^= 15
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv3]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal15] ^= 4
balancedCategory[toricCodeCat3Bal16] ^= toricCodeCat3Bal16
 
braidedCategory[toricCodeCat3Bal16] ^= toricCodeCat3Brd4
 
fusionCategory[toricCodeCat3Bal16] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal16] ^= toricCodeCat3Piv4
 
ribbonCategory[toricCodeCat3Bal16] ^= toricCodeCat3Bal16
 
ring[toricCodeCat3Bal16] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal16] ^= toricCodeCat3Piv4
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd4]][
      balancedCategory[#1]] & )[toricCodeCat3Bal16] ^= 4
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal16] ^= 16
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv4]][
      balancedCategory[#1]] & )[toricCodeCat3Bal16] ^= 4
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd4]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal16] ^= 4
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal16] ^= 16
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv4]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal16] ^= 4
balancedCategory[toricCodeCat3Bal17] ^= toricCodeCat3Bal17
 
braidedCategory[toricCodeCat3Bal17] ^= toricCodeCat3Brd5
 
fusionCategory[toricCodeCat3Bal17] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal17] ^= toricCodeCat3Piv1
 
ribbonCategory[toricCodeCat3Bal17] ^= toricCodeCat3Bal17
 
ring[toricCodeCat3Bal17] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal17] ^= toricCodeCat3Piv1
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd5]][
      balancedCategory[#1]] & )[toricCodeCat3Bal17] ^= 1
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal17] ^= 17
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv1]][
      balancedCategory[#1]] & )[toricCodeCat3Bal17] ^= 5
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd5]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal17] ^= 1
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal17] ^= 17
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv1]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal17] ^= 5
balancedCategory[toricCodeCat3Bal18] ^= toricCodeCat3Bal18
 
braidedCategory[toricCodeCat3Bal18] ^= toricCodeCat3Brd5
 
fusionCategory[toricCodeCat3Bal18] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal18] ^= toricCodeCat3Piv2
 
ribbonCategory[toricCodeCat3Bal18] ^= toricCodeCat3Bal18
 
ring[toricCodeCat3Bal18] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal18] ^= toricCodeCat3Piv2
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd5]][
      balancedCategory[#1]] & )[toricCodeCat3Bal18] ^= 2
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal18] ^= 18
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv2]][
      balancedCategory[#1]] & )[toricCodeCat3Bal18] ^= 5
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd5]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal18] ^= 2
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal18] ^= 18
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv2]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal18] ^= 5
balancedCategory[toricCodeCat3Bal19] ^= toricCodeCat3Bal19
 
braidedCategory[toricCodeCat3Bal19] ^= toricCodeCat3Brd5
 
fusionCategory[toricCodeCat3Bal19] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal19] ^= toricCodeCat3Piv3
 
ribbonCategory[toricCodeCat3Bal19] ^= toricCodeCat3Bal19
 
ring[toricCodeCat3Bal19] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal19] ^= toricCodeCat3Piv3
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd5]][
      balancedCategory[#1]] & )[toricCodeCat3Bal19] ^= 3
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal19] ^= 19
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal19] ^= 5
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd5]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal19] ^= 3
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal19] ^= 19
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv3]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal19] ^= 5
balancedCategory[toricCodeCat3Bal2] ^= toricCodeCat3Bal2
 
braidedCategory[toricCodeCat3Bal2] ^= toricCodeCat3Brd1
 
fusionCategory[toricCodeCat3Bal2] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal2] ^= toricCodeCat3Piv2
 
ribbonCategory[toricCodeCat3Bal2] ^= toricCodeCat3Bal2
 
ring[toricCodeCat3Bal2] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal2] ^= toricCodeCat3Piv2
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd1]][
      balancedCategory[#1]] & )[toricCodeCat3Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv2]][
      balancedCategory[#1]] & )[toricCodeCat3Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd1]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv2]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal2] ^= 1
balancedCategory[toricCodeCat3Bal20] ^= toricCodeCat3Bal20
 
braidedCategory[toricCodeCat3Bal20] ^= toricCodeCat3Brd5
 
fusionCategory[toricCodeCat3Bal20] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal20] ^= toricCodeCat3Piv4
 
ribbonCategory[toricCodeCat3Bal20] ^= toricCodeCat3Bal20
 
ring[toricCodeCat3Bal20] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal20] ^= toricCodeCat3Piv4
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd5]][
      balancedCategory[#1]] & )[toricCodeCat3Bal20] ^= 4
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal20] ^= 20
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv4]][
      balancedCategory[#1]] & )[toricCodeCat3Bal20] ^= 5
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd5]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal20] ^= 4
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal20] ^= 20
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv4]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal20] ^= 5
balancedCategory[toricCodeCat3Bal21] ^= toricCodeCat3Bal21
 
braidedCategory[toricCodeCat3Bal21] ^= toricCodeCat3Brd6
 
fusionCategory[toricCodeCat3Bal21] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal21] ^= toricCodeCat3Piv1
 
ribbonCategory[toricCodeCat3Bal21] ^= toricCodeCat3Bal21
 
ring[toricCodeCat3Bal21] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal21] ^= toricCodeCat3Piv1
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd6]][
      balancedCategory[#1]] & )[toricCodeCat3Bal21] ^= 1
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal21] ^= 21
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv1]][
      balancedCategory[#1]] & )[toricCodeCat3Bal21] ^= 6
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd6]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal21] ^= 1
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal21] ^= 21
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv1]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal21] ^= 6
balancedCategory[toricCodeCat3Bal22] ^= toricCodeCat3Bal22
 
braidedCategory[toricCodeCat3Bal22] ^= toricCodeCat3Brd6
 
fusionCategory[toricCodeCat3Bal22] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal22] ^= toricCodeCat3Piv2
 
ribbonCategory[toricCodeCat3Bal22] ^= toricCodeCat3Bal22
 
ring[toricCodeCat3Bal22] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal22] ^= toricCodeCat3Piv2
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd6]][
      balancedCategory[#1]] & )[toricCodeCat3Bal22] ^= 2
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal22] ^= 22
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv2]][
      balancedCategory[#1]] & )[toricCodeCat3Bal22] ^= 6
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd6]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal22] ^= 2
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal22] ^= 22
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv2]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal22] ^= 6
balancedCategory[toricCodeCat3Bal23] ^= toricCodeCat3Bal23
 
braidedCategory[toricCodeCat3Bal23] ^= toricCodeCat3Brd6
 
fusionCategory[toricCodeCat3Bal23] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal23] ^= toricCodeCat3Piv3
 
ribbonCategory[toricCodeCat3Bal23] ^= toricCodeCat3Bal23
 
ring[toricCodeCat3Bal23] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal23] ^= toricCodeCat3Piv3
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd6]][
      balancedCategory[#1]] & )[toricCodeCat3Bal23] ^= 3
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal23] ^= 23
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal23] ^= 6
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd6]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal23] ^= 3
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal23] ^= 23
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv3]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal23] ^= 6
balancedCategory[toricCodeCat3Bal24] ^= toricCodeCat3Bal24
 
braidedCategory[toricCodeCat3Bal24] ^= toricCodeCat3Brd6
 
fusionCategory[toricCodeCat3Bal24] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal24] ^= toricCodeCat3Piv4
 
ribbonCategory[toricCodeCat3Bal24] ^= toricCodeCat3Bal24
 
ring[toricCodeCat3Bal24] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal24] ^= toricCodeCat3Piv4
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd6]][
      balancedCategory[#1]] & )[toricCodeCat3Bal24] ^= 4
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal24] ^= 24
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv4]][
      balancedCategory[#1]] & )[toricCodeCat3Bal24] ^= 6
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd6]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal24] ^= 4
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal24] ^= 24
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv4]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal24] ^= 6
balancedCategory[toricCodeCat3Bal25] ^= toricCodeCat3Bal25
 
braidedCategory[toricCodeCat3Bal25] ^= toricCodeCat3Brd7
 
fusionCategory[toricCodeCat3Bal25] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal25] ^= toricCodeCat3Piv1
 
ribbonCategory[toricCodeCat3Bal25] ^= toricCodeCat3Bal25
 
ring[toricCodeCat3Bal25] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal25] ^= toricCodeCat3Piv1
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd7]][
      balancedCategory[#1]] & )[toricCodeCat3Bal25] ^= 1
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal25] ^= 25
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv1]][
      balancedCategory[#1]] & )[toricCodeCat3Bal25] ^= 7
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd7]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal25] ^= 1
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal25] ^= 25
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv1]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal25] ^= 7
balancedCategory[toricCodeCat3Bal26] ^= toricCodeCat3Bal26
 
braidedCategory[toricCodeCat3Bal26] ^= toricCodeCat3Brd7
 
fusionCategory[toricCodeCat3Bal26] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal26] ^= toricCodeCat3Piv2
 
ribbonCategory[toricCodeCat3Bal26] ^= toricCodeCat3Bal26
 
ring[toricCodeCat3Bal26] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal26] ^= toricCodeCat3Piv2
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd7]][
      balancedCategory[#1]] & )[toricCodeCat3Bal26] ^= 2
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal26] ^= 26
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv2]][
      balancedCategory[#1]] & )[toricCodeCat3Bal26] ^= 7
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd7]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal26] ^= 2
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal26] ^= 26
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv2]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal26] ^= 7
balancedCategory[toricCodeCat3Bal27] ^= toricCodeCat3Bal27
 
braidedCategory[toricCodeCat3Bal27] ^= toricCodeCat3Brd7
 
fusionCategory[toricCodeCat3Bal27] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal27] ^= toricCodeCat3Piv3
 
ribbonCategory[toricCodeCat3Bal27] ^= toricCodeCat3Bal27
 
ring[toricCodeCat3Bal27] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal27] ^= toricCodeCat3Piv3
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd7]][
      balancedCategory[#1]] & )[toricCodeCat3Bal27] ^= 3
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal27] ^= 27
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal27] ^= 7
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd7]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal27] ^= 3
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal27] ^= 27
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv3]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal27] ^= 7
balancedCategory[toricCodeCat3Bal28] ^= toricCodeCat3Bal28
 
braidedCategory[toricCodeCat3Bal28] ^= toricCodeCat3Brd7
 
fusionCategory[toricCodeCat3Bal28] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal28] ^= toricCodeCat3Piv4
 
ribbonCategory[toricCodeCat3Bal28] ^= toricCodeCat3Bal28
 
ring[toricCodeCat3Bal28] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal28] ^= toricCodeCat3Piv4
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd7]][
      balancedCategory[#1]] & )[toricCodeCat3Bal28] ^= 4
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal28] ^= 28
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv4]][
      balancedCategory[#1]] & )[toricCodeCat3Bal28] ^= 7
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd7]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal28] ^= 4
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal28] ^= 28
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv4]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal28] ^= 7
balancedCategory[toricCodeCat3Bal29] ^= toricCodeCat3Bal29
 
braidedCategory[toricCodeCat3Bal29] ^= toricCodeCat3Brd8
 
fusionCategory[toricCodeCat3Bal29] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal29] ^= toricCodeCat3Piv1
 
ribbonCategory[toricCodeCat3Bal29] ^= toricCodeCat3Bal29
 
ring[toricCodeCat3Bal29] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal29] ^= toricCodeCat3Piv1
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd8]][
      balancedCategory[#1]] & )[toricCodeCat3Bal29] ^= 1
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal29] ^= 29
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv1]][
      balancedCategory[#1]] & )[toricCodeCat3Bal29] ^= 8
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd8]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal29] ^= 1
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal29] ^= 29
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv1]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal29] ^= 8
balancedCategory[toricCodeCat3Bal3] ^= toricCodeCat3Bal3
 
braidedCategory[toricCodeCat3Bal3] ^= toricCodeCat3Brd1
 
fusionCategory[toricCodeCat3Bal3] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal3] ^= toricCodeCat3Piv3
 
ribbonCategory[toricCodeCat3Bal3] ^= toricCodeCat3Bal3
 
ring[toricCodeCat3Bal3] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal3] ^= toricCodeCat3Piv3
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd1]][
      balancedCategory[#1]] & )[toricCodeCat3Bal3] ^= 3
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal3] ^= 1
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd1]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal3] ^= 3
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv3]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal3] ^= 1
balancedCategory[toricCodeCat3Bal30] ^= toricCodeCat3Bal30
 
braidedCategory[toricCodeCat3Bal30] ^= toricCodeCat3Brd8
 
fusionCategory[toricCodeCat3Bal30] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal30] ^= toricCodeCat3Piv2
 
ribbonCategory[toricCodeCat3Bal30] ^= toricCodeCat3Bal30
 
ring[toricCodeCat3Bal30] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal30] ^= toricCodeCat3Piv2
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd8]][
      balancedCategory[#1]] & )[toricCodeCat3Bal30] ^= 2
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal30] ^= 30
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv2]][
      balancedCategory[#1]] & )[toricCodeCat3Bal30] ^= 8
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd8]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal30] ^= 2
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal30] ^= 30
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv2]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal30] ^= 8
balancedCategory[toricCodeCat3Bal31] ^= toricCodeCat3Bal31
 
braidedCategory[toricCodeCat3Bal31] ^= toricCodeCat3Brd8
 
fusionCategory[toricCodeCat3Bal31] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal31] ^= toricCodeCat3Piv3
 
ribbonCategory[toricCodeCat3Bal31] ^= toricCodeCat3Bal31
 
ring[toricCodeCat3Bal31] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal31] ^= toricCodeCat3Piv3
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd8]][
      balancedCategory[#1]] & )[toricCodeCat3Bal31] ^= 3
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal31] ^= 31
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal31] ^= 8
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd8]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal31] ^= 3
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal31] ^= 31
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv3]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal31] ^= 8
balancedCategory[toricCodeCat3Bal32] ^= toricCodeCat3Bal32
 
braidedCategory[toricCodeCat3Bal32] ^= toricCodeCat3Brd8
 
fusionCategory[toricCodeCat3Bal32] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal32] ^= toricCodeCat3Piv4
 
ribbonCategory[toricCodeCat3Bal32] ^= toricCodeCat3Bal32
 
ring[toricCodeCat3Bal32] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal32] ^= toricCodeCat3Piv4
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd8]][
      balancedCategory[#1]] & )[toricCodeCat3Bal32] ^= 4
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal32] ^= 32
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv4]][
      balancedCategory[#1]] & )[toricCodeCat3Bal32] ^= 8
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd8]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal32] ^= 4
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal32] ^= 32
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv4]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal32] ^= 8
balancedCategory[toricCodeCat3Bal4] ^= toricCodeCat3Bal4
 
braidedCategory[toricCodeCat3Bal4] ^= toricCodeCat3Brd1
 
fusionCategory[toricCodeCat3Bal4] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal4] ^= toricCodeCat3Piv4
 
ribbonCategory[toricCodeCat3Bal4] ^= toricCodeCat3Bal4
 
ring[toricCodeCat3Bal4] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal4] ^= toricCodeCat3Piv4
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd1]][
      balancedCategory[#1]] & )[toricCodeCat3Bal4] ^= 4
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv4]][
      balancedCategory[#1]] & )[toricCodeCat3Bal4] ^= 1
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd1]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal4] ^= 4
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv4]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal4] ^= 1
balancedCategory[toricCodeCat3Bal5] ^= toricCodeCat3Bal5
 
braidedCategory[toricCodeCat3Bal5] ^= toricCodeCat3Brd2
 
fusionCategory[toricCodeCat3Bal5] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal5] ^= toricCodeCat3Piv1
 
ribbonCategory[toricCodeCat3Bal5] ^= toricCodeCat3Bal5
 
ring[toricCodeCat3Bal5] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal5] ^= toricCodeCat3Piv1
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd2]][
      balancedCategory[#1]] & )[toricCodeCat3Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv1]][
      balancedCategory[#1]] & )[toricCodeCat3Bal5] ^= 2
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd2]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv1]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal5] ^= 2
balancedCategory[toricCodeCat3Bal6] ^= toricCodeCat3Bal6
 
braidedCategory[toricCodeCat3Bal6] ^= toricCodeCat3Brd2
 
fusionCategory[toricCodeCat3Bal6] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal6] ^= toricCodeCat3Piv2
 
ribbonCategory[toricCodeCat3Bal6] ^= toricCodeCat3Bal6
 
ring[toricCodeCat3Bal6] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal6] ^= toricCodeCat3Piv2
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd2]][
      balancedCategory[#1]] & )[toricCodeCat3Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv2]][
      balancedCategory[#1]] & )[toricCodeCat3Bal6] ^= 2
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd2]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv2]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal6] ^= 2
balancedCategory[toricCodeCat3Bal7] ^= toricCodeCat3Bal7
 
braidedCategory[toricCodeCat3Bal7] ^= toricCodeCat3Brd2
 
fusionCategory[toricCodeCat3Bal7] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal7] ^= toricCodeCat3Piv3
 
ribbonCategory[toricCodeCat3Bal7] ^= toricCodeCat3Bal7
 
ring[toricCodeCat3Bal7] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal7] ^= toricCodeCat3Piv3
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd2]][
      balancedCategory[#1]] & )[toricCodeCat3Bal7] ^= 3
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal7] ^= 2
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd2]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal7] ^= 3
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv3]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal7] ^= 2
balancedCategory[toricCodeCat3Bal8] ^= toricCodeCat3Bal8
 
braidedCategory[toricCodeCat3Bal8] ^= toricCodeCat3Brd2
 
fusionCategory[toricCodeCat3Bal8] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal8] ^= toricCodeCat3Piv4
 
ribbonCategory[toricCodeCat3Bal8] ^= toricCodeCat3Bal8
 
ring[toricCodeCat3Bal8] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal8] ^= toricCodeCat3Piv4
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd2]][
      balancedCategory[#1]] & )[toricCodeCat3Bal8] ^= 4
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv4]][
      balancedCategory[#1]] & )[toricCodeCat3Bal8] ^= 2
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd2]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal8] ^= 4
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv4]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal8] ^= 2
balancedCategory[toricCodeCat3Bal9] ^= toricCodeCat3Bal9
 
braidedCategory[toricCodeCat3Bal9] ^= toricCodeCat3Brd3
 
fusionCategory[toricCodeCat3Bal9] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Bal9] ^= toricCodeCat3Piv1
 
ribbonCategory[toricCodeCat3Bal9] ^= toricCodeCat3Bal9
 
ring[toricCodeCat3Bal9] ^= toricCode
 
sphericalCategory[toricCodeCat3Bal9] ^= toricCodeCat3Piv1
 
(balancedCategoryIndex[braidedCategory[toricCodeCat3Brd3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal9] ^= 1
 
(balancedCategoryIndex[fusionCategory[toricCodeCat3]][
      balancedCategory[#1]] & )[toricCodeCat3Bal9] ^= 9
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat3Piv1]][
      balancedCategory[#1]] & )[toricCodeCat3Bal9] ^= 3
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat3Brd3]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal9] ^= 1
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat3]][ribbonCategory[#1]] & )[
    toricCodeCat3Bal9] ^= 9
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat3Piv1]][
      ribbonCategory[#1]] & )[toricCodeCat3Bal9] ^= 3
balancedCategories[toricCodeCat3Brd1] ^= {toricCodeCat3Bal1, 
    toricCodeCat3Bal2, toricCodeCat3Bal3, toricCodeCat3Bal4}
 
toricCodeCat3Brd1 /: balancedCategory[toricCodeCat3Brd1, 1] = 
    toricCodeCat3Bal1
 
toricCodeCat3Brd1 /: balancedCategory[toricCodeCat3Brd1, 2] = 
    toricCodeCat3Bal2
 
toricCodeCat3Brd1 /: balancedCategory[toricCodeCat3Brd1, 3] = 
    toricCodeCat3Bal3
 
toricCodeCat3Brd1 /: balancedCategory[toricCodeCat3Brd1, 4] = 
    toricCodeCat3Bal4
 
braidedCategory[toricCodeCat3Brd1] ^= toricCodeCat3Brd1
 
fusionCategory[toricCodeCat3Brd1] ^= toricCodeCat3
 
toricCodeCat3Brd1 /: modularCategory[toricCodeCat3Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
toricCodeCat3Brd1 /: ribbonCategory[toricCodeCat3Brd1, 1] = toricCodeCat3Bal1
 
toricCodeCat3Brd1 /: ribbonCategory[toricCodeCat3Brd1, 2] = toricCodeCat3Bal2
 
toricCodeCat3Brd1 /: ribbonCategory[toricCodeCat3Brd1, 3] = toricCodeCat3Bal3
 
toricCodeCat3Brd1 /: ribbonCategory[toricCodeCat3Brd1, 4] = toricCodeCat3Bal4
 
ring[toricCodeCat3Brd1] ^= toricCode
 
rMatrixFunction[toricCodeCat3Brd1] ^= toricCodeCat3Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[toricCodeCat3]][braidedCategory[#1]] & )[
    toricCodeCat3Brd1] ^= 1
braidedCategory[toricCodeCat3Brd1RMatrixFunction] ^= toricCodeCat3Brd1
 
fusionCategory[toricCodeCat3Brd1RMatrixFunction] ^= toricCodeCat3
 
rMatrixFunction[toricCodeCat3Brd1RMatrixFunction] ^= 
   toricCodeCat3Brd1RMatrixFunction
 
toricCodeCat3Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
toricCodeCat3Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
toricCodeCat3Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
toricCodeCat3Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
toricCodeCat3Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
toricCodeCat3Brd1RMatrixFunction[1, 1, 0] = {{-I}}
 
toricCodeCat3Brd1RMatrixFunction[1, 2, 3] = {{1}}
 
toricCodeCat3Brd1RMatrixFunction[1, 3, 2] = {{-I}}
 
toricCodeCat3Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
toricCodeCat3Brd1RMatrixFunction[2, 1, 3] = {{1}}
 
toricCodeCat3Brd1RMatrixFunction[2, 2, 0] = {{-I}}
 
toricCodeCat3Brd1RMatrixFunction[2, 3, 1] = {{-I}}
 
toricCodeCat3Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
toricCodeCat3Brd1RMatrixFunction[3, 1, 2] = {{-I}}
 
toricCodeCat3Brd1RMatrixFunction[3, 2, 1] = {{-I}}
 
toricCodeCat3Brd1RMatrixFunction[3, 3, 0] = {{-1}}
balancedCategories[toricCodeCat3Brd2] ^= {toricCodeCat3Bal5, 
    toricCodeCat3Bal6, toricCodeCat3Bal7, toricCodeCat3Bal8}
 
toricCodeCat3Brd2 /: balancedCategory[toricCodeCat3Brd2, 1] = 
    toricCodeCat3Bal5
 
toricCodeCat3Brd2 /: balancedCategory[toricCodeCat3Brd2, 2] = 
    toricCodeCat3Bal6
 
toricCodeCat3Brd2 /: balancedCategory[toricCodeCat3Brd2, 3] = 
    toricCodeCat3Bal7
 
toricCodeCat3Brd2 /: balancedCategory[toricCodeCat3Brd2, 4] = 
    toricCodeCat3Bal8
 
braidedCategory[toricCodeCat3Brd2] ^= toricCodeCat3Brd2
 
fusionCategory[toricCodeCat3Brd2] ^= toricCodeCat3
 
toricCodeCat3Brd2 /: modularCategory[toricCodeCat3Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
toricCodeCat3Brd2 /: ribbonCategory[toricCodeCat3Brd2, 1] = toricCodeCat3Bal5
 
toricCodeCat3Brd2 /: ribbonCategory[toricCodeCat3Brd2, 2] = toricCodeCat3Bal6
 
toricCodeCat3Brd2 /: ribbonCategory[toricCodeCat3Brd2, 3] = toricCodeCat3Bal7
 
toricCodeCat3Brd2 /: ribbonCategory[toricCodeCat3Brd2, 4] = toricCodeCat3Bal8
 
ring[toricCodeCat3Brd2] ^= toricCode
 
rMatrixFunction[toricCodeCat3Brd2] ^= toricCodeCat3Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[toricCodeCat3]][braidedCategory[#1]] & )[
    toricCodeCat3Brd2] ^= 2
braidedCategory[toricCodeCat3Brd2RMatrixFunction] ^= toricCodeCat3Brd2
 
fusionCategory[toricCodeCat3Brd2RMatrixFunction] ^= toricCodeCat3
 
rMatrixFunction[toricCodeCat3Brd2RMatrixFunction] ^= 
   toricCodeCat3Brd2RMatrixFunction
 
toricCodeCat3Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
toricCodeCat3Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
toricCodeCat3Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
toricCodeCat3Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
toricCodeCat3Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
toricCodeCat3Brd2RMatrixFunction[1, 1, 0] = {{-I}}
 
toricCodeCat3Brd2RMatrixFunction[1, 2, 3] = {{-1}}
 
toricCodeCat3Brd2RMatrixFunction[1, 3, 2] = {{I}}
 
toricCodeCat3Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
toricCodeCat3Brd2RMatrixFunction[2, 1, 3] = {{1}}
 
toricCodeCat3Brd2RMatrixFunction[2, 2, 0] = {{-I}}
 
toricCodeCat3Brd2RMatrixFunction[2, 3, 1] = {{-I}}
 
toricCodeCat3Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
toricCodeCat3Brd2RMatrixFunction[3, 1, 2] = {{-I}}
 
toricCodeCat3Brd2RMatrixFunction[3, 2, 1] = {{I}}
 
toricCodeCat3Brd2RMatrixFunction[3, 3, 0] = {{1}}
balancedCategories[toricCodeCat3Brd3] ^= {toricCodeCat3Bal9, 
    toricCodeCat3Bal10, toricCodeCat3Bal11, toricCodeCat3Bal12}
 
toricCodeCat3Brd3 /: balancedCategory[toricCodeCat3Brd3, 1] = 
    toricCodeCat3Bal9
 
toricCodeCat3Brd3 /: balancedCategory[toricCodeCat3Brd3, 2] = 
    toricCodeCat3Bal10
 
toricCodeCat3Brd3 /: balancedCategory[toricCodeCat3Brd3, 3] = 
    toricCodeCat3Bal11
 
toricCodeCat3Brd3 /: balancedCategory[toricCodeCat3Brd3, 4] = 
    toricCodeCat3Bal12
 
braidedCategory[toricCodeCat3Brd3] ^= toricCodeCat3Brd3
 
fusionCategory[toricCodeCat3Brd3] ^= toricCodeCat3
 
toricCodeCat3Brd3 /: modularCategory[toricCodeCat3Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
toricCodeCat3Brd3 /: ribbonCategory[toricCodeCat3Brd3, 1] = toricCodeCat3Bal9
 
toricCodeCat3Brd3 /: ribbonCategory[toricCodeCat3Brd3, 2] = toricCodeCat3Bal10
 
toricCodeCat3Brd3 /: ribbonCategory[toricCodeCat3Brd3, 3] = toricCodeCat3Bal11
 
toricCodeCat3Brd3 /: ribbonCategory[toricCodeCat3Brd3, 4] = toricCodeCat3Bal12
 
ring[toricCodeCat3Brd3] ^= toricCode
 
rMatrixFunction[toricCodeCat3Brd3] ^= toricCodeCat3Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[toricCodeCat3]][braidedCategory[#1]] & )[
    toricCodeCat3Brd3] ^= 3
braidedCategory[toricCodeCat3Brd3RMatrixFunction] ^= toricCodeCat3Brd3
 
fusionCategory[toricCodeCat3Brd3RMatrixFunction] ^= toricCodeCat3
 
rMatrixFunction[toricCodeCat3Brd3RMatrixFunction] ^= 
   toricCodeCat3Brd3RMatrixFunction
 
toricCodeCat3Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
toricCodeCat3Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
toricCodeCat3Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
toricCodeCat3Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
toricCodeCat3Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
toricCodeCat3Brd3RMatrixFunction[1, 1, 0] = {{-I}}
 
toricCodeCat3Brd3RMatrixFunction[1, 2, 3] = {{1}}
 
toricCodeCat3Brd3RMatrixFunction[1, 3, 2] = {{-I}}
 
toricCodeCat3Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
toricCodeCat3Brd3RMatrixFunction[2, 1, 3] = {{-1}}
 
toricCodeCat3Brd3RMatrixFunction[2, 2, 0] = {{I}}
 
toricCodeCat3Brd3RMatrixFunction[2, 3, 1] = {{-I}}
 
toricCodeCat3Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
toricCodeCat3Brd3RMatrixFunction[3, 1, 2] = {{I}}
 
toricCodeCat3Brd3RMatrixFunction[3, 2, 1] = {{I}}
 
toricCodeCat3Brd3RMatrixFunction[3, 3, 0] = {{-1}}
balancedCategories[toricCodeCat3Brd4] ^= {toricCodeCat3Bal13, 
    toricCodeCat3Bal14, toricCodeCat3Bal15, toricCodeCat3Bal16}
 
toricCodeCat3Brd4 /: balancedCategory[toricCodeCat3Brd4, 1] = 
    toricCodeCat3Bal13
 
toricCodeCat3Brd4 /: balancedCategory[toricCodeCat3Brd4, 2] = 
    toricCodeCat3Bal14
 
toricCodeCat3Brd4 /: balancedCategory[toricCodeCat3Brd4, 3] = 
    toricCodeCat3Bal15
 
toricCodeCat3Brd4 /: balancedCategory[toricCodeCat3Brd4, 4] = 
    toricCodeCat3Bal16
 
braidedCategory[toricCodeCat3Brd4] ^= toricCodeCat3Brd4
 
fusionCategory[toricCodeCat3Brd4] ^= toricCodeCat3
 
toricCodeCat3Brd4 /: modularCategory[toricCodeCat3Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
toricCodeCat3Brd4 /: ribbonCategory[toricCodeCat3Brd4, 1] = toricCodeCat3Bal13
 
toricCodeCat3Brd4 /: ribbonCategory[toricCodeCat3Brd4, 2] = toricCodeCat3Bal14
 
toricCodeCat3Brd4 /: ribbonCategory[toricCodeCat3Brd4, 3] = toricCodeCat3Bal15
 
toricCodeCat3Brd4 /: ribbonCategory[toricCodeCat3Brd4, 4] = toricCodeCat3Bal16
 
ring[toricCodeCat3Brd4] ^= toricCode
 
rMatrixFunction[toricCodeCat3Brd4] ^= toricCodeCat3Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[toricCodeCat3]][braidedCategory[#1]] & )[
    toricCodeCat3Brd4] ^= 4
braidedCategory[toricCodeCat3Brd4RMatrixFunction] ^= toricCodeCat3Brd4
 
fusionCategory[toricCodeCat3Brd4RMatrixFunction] ^= toricCodeCat3
 
rMatrixFunction[toricCodeCat3Brd4RMatrixFunction] ^= 
   toricCodeCat3Brd4RMatrixFunction
 
toricCodeCat3Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
toricCodeCat3Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
toricCodeCat3Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
toricCodeCat3Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
toricCodeCat3Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
toricCodeCat3Brd4RMatrixFunction[1, 1, 0] = {{-I}}
 
toricCodeCat3Brd4RMatrixFunction[1, 2, 3] = {{-1}}
 
toricCodeCat3Brd4RMatrixFunction[1, 3, 2] = {{I}}
 
toricCodeCat3Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
toricCodeCat3Brd4RMatrixFunction[2, 1, 3] = {{-1}}
 
toricCodeCat3Brd4RMatrixFunction[2, 2, 0] = {{I}}
 
toricCodeCat3Brd4RMatrixFunction[2, 3, 1] = {{-I}}
 
toricCodeCat3Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
toricCodeCat3Brd4RMatrixFunction[3, 1, 2] = {{I}}
 
toricCodeCat3Brd4RMatrixFunction[3, 2, 1] = {{-I}}
 
toricCodeCat3Brd4RMatrixFunction[3, 3, 0] = {{1}}
balancedCategories[toricCodeCat3Brd5] ^= {toricCodeCat3Bal17, 
    toricCodeCat3Bal18, toricCodeCat3Bal19, toricCodeCat3Bal20}
 
toricCodeCat3Brd5 /: balancedCategory[toricCodeCat3Brd5, 1] = 
    toricCodeCat3Bal17
 
toricCodeCat3Brd5 /: balancedCategory[toricCodeCat3Brd5, 2] = 
    toricCodeCat3Bal18
 
toricCodeCat3Brd5 /: balancedCategory[toricCodeCat3Brd5, 3] = 
    toricCodeCat3Bal19
 
toricCodeCat3Brd5 /: balancedCategory[toricCodeCat3Brd5, 4] = 
    toricCodeCat3Bal20
 
braidedCategory[toricCodeCat3Brd5] ^= toricCodeCat3Brd5
 
fusionCategory[toricCodeCat3Brd5] ^= toricCodeCat3
 
toricCodeCat3Brd5 /: modularCategory[toricCodeCat3Brd5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
toricCodeCat3Brd5 /: ribbonCategory[toricCodeCat3Brd5, 1] = toricCodeCat3Bal17
 
toricCodeCat3Brd5 /: ribbonCategory[toricCodeCat3Brd5, 2] = toricCodeCat3Bal18
 
toricCodeCat3Brd5 /: ribbonCategory[toricCodeCat3Brd5, 3] = toricCodeCat3Bal19
 
toricCodeCat3Brd5 /: ribbonCategory[toricCodeCat3Brd5, 4] = toricCodeCat3Bal20
 
ring[toricCodeCat3Brd5] ^= toricCode
 
rMatrixFunction[toricCodeCat3Brd5] ^= toricCodeCat3Brd5RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[toricCodeCat3]][braidedCategory[#1]] & )[
    toricCodeCat3Brd5] ^= 5
braidedCategory[toricCodeCat3Brd5RMatrixFunction] ^= toricCodeCat3Brd5
 
fusionCategory[toricCodeCat3Brd5RMatrixFunction] ^= toricCodeCat3
 
rMatrixFunction[toricCodeCat3Brd5RMatrixFunction] ^= 
   toricCodeCat3Brd5RMatrixFunction
 
toricCodeCat3Brd5RMatrixFunction[0, 0, 0] = {{1}}
 
toricCodeCat3Brd5RMatrixFunction[0, 1, 1] = {{1}}
 
toricCodeCat3Brd5RMatrixFunction[0, 2, 2] = {{1}}
 
toricCodeCat3Brd5RMatrixFunction[0, 3, 3] = {{1}}
 
toricCodeCat3Brd5RMatrixFunction[1, 0, 1] = {{1}}
 
toricCodeCat3Brd5RMatrixFunction[1, 1, 0] = {{I}}
 
toricCodeCat3Brd5RMatrixFunction[1, 2, 3] = {{-1}}
 
toricCodeCat3Brd5RMatrixFunction[1, 3, 2] = {{-I}}
 
toricCodeCat3Brd5RMatrixFunction[2, 0, 2] = {{1}}
 
toricCodeCat3Brd5RMatrixFunction[2, 1, 3] = {{1}}
 
toricCodeCat3Brd5RMatrixFunction[2, 2, 0] = {{-I}}
 
toricCodeCat3Brd5RMatrixFunction[2, 3, 1] = {{-I}}
 
toricCodeCat3Brd5RMatrixFunction[3, 0, 3] = {{1}}
 
toricCodeCat3Brd5RMatrixFunction[3, 1, 2] = {{I}}
 
toricCodeCat3Brd5RMatrixFunction[3, 2, 1] = {{I}}
 
toricCodeCat3Brd5RMatrixFunction[3, 3, 0] = {{-1}}
balancedCategories[toricCodeCat3Brd6] ^= {toricCodeCat3Bal21, 
    toricCodeCat3Bal22, toricCodeCat3Bal23, toricCodeCat3Bal24}
 
toricCodeCat3Brd6 /: balancedCategory[toricCodeCat3Brd6, 1] = 
    toricCodeCat3Bal21
 
toricCodeCat3Brd6 /: balancedCategory[toricCodeCat3Brd6, 2] = 
    toricCodeCat3Bal22
 
toricCodeCat3Brd6 /: balancedCategory[toricCodeCat3Brd6, 3] = 
    toricCodeCat3Bal23
 
toricCodeCat3Brd6 /: balancedCategory[toricCodeCat3Brd6, 4] = 
    toricCodeCat3Bal24
 
braidedCategory[toricCodeCat3Brd6] ^= toricCodeCat3Brd6
 
fusionCategory[toricCodeCat3Brd6] ^= toricCodeCat3
 
toricCodeCat3Brd6 /: modularCategory[toricCodeCat3Brd6, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
toricCodeCat3Brd6 /: ribbonCategory[toricCodeCat3Brd6, 1] = toricCodeCat3Bal21
 
toricCodeCat3Brd6 /: ribbonCategory[toricCodeCat3Brd6, 2] = toricCodeCat3Bal22
 
toricCodeCat3Brd6 /: ribbonCategory[toricCodeCat3Brd6, 3] = toricCodeCat3Bal23
 
toricCodeCat3Brd6 /: ribbonCategory[toricCodeCat3Brd6, 4] = toricCodeCat3Bal24
 
ring[toricCodeCat3Brd6] ^= toricCode
 
rMatrixFunction[toricCodeCat3Brd6] ^= toricCodeCat3Brd6RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[toricCodeCat3]][braidedCategory[#1]] & )[
    toricCodeCat3Brd6] ^= 6
braidedCategory[toricCodeCat3Brd6RMatrixFunction] ^= toricCodeCat3Brd6
 
fusionCategory[toricCodeCat3Brd6RMatrixFunction] ^= toricCodeCat3
 
rMatrixFunction[toricCodeCat3Brd6RMatrixFunction] ^= 
   toricCodeCat3Brd6RMatrixFunction
 
toricCodeCat3Brd6RMatrixFunction[0, 0, 0] = {{1}}
 
toricCodeCat3Brd6RMatrixFunction[0, 1, 1] = {{1}}
 
toricCodeCat3Brd6RMatrixFunction[0, 2, 2] = {{1}}
 
toricCodeCat3Brd6RMatrixFunction[0, 3, 3] = {{1}}
 
toricCodeCat3Brd6RMatrixFunction[1, 0, 1] = {{1}}
 
toricCodeCat3Brd6RMatrixFunction[1, 1, 0] = {{I}}
 
toricCodeCat3Brd6RMatrixFunction[1, 2, 3] = {{1}}
 
toricCodeCat3Brd6RMatrixFunction[1, 3, 2] = {{I}}
 
toricCodeCat3Brd6RMatrixFunction[2, 0, 2] = {{1}}
 
toricCodeCat3Brd6RMatrixFunction[2, 1, 3] = {{1}}
 
toricCodeCat3Brd6RMatrixFunction[2, 2, 0] = {{-I}}
 
toricCodeCat3Brd6RMatrixFunction[2, 3, 1] = {{-I}}
 
toricCodeCat3Brd6RMatrixFunction[3, 0, 3] = {{1}}
 
toricCodeCat3Brd6RMatrixFunction[3, 1, 2] = {{I}}
 
toricCodeCat3Brd6RMatrixFunction[3, 2, 1] = {{-I}}
 
toricCodeCat3Brd6RMatrixFunction[3, 3, 0] = {{1}}
balancedCategories[toricCodeCat3Brd7] ^= {toricCodeCat3Bal25, 
    toricCodeCat3Bal26, toricCodeCat3Bal27, toricCodeCat3Bal28}
 
toricCodeCat3Brd7 /: balancedCategory[toricCodeCat3Brd7, 1] = 
    toricCodeCat3Bal25
 
toricCodeCat3Brd7 /: balancedCategory[toricCodeCat3Brd7, 2] = 
    toricCodeCat3Bal26
 
toricCodeCat3Brd7 /: balancedCategory[toricCodeCat3Brd7, 3] = 
    toricCodeCat3Bal27
 
toricCodeCat3Brd7 /: balancedCategory[toricCodeCat3Brd7, 4] = 
    toricCodeCat3Bal28
 
braidedCategory[toricCodeCat3Brd7] ^= toricCodeCat3Brd7
 
fusionCategory[toricCodeCat3Brd7] ^= toricCodeCat3
 
toricCodeCat3Brd7 /: modularCategory[toricCodeCat3Brd7, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
toricCodeCat3Brd7 /: ribbonCategory[toricCodeCat3Brd7, 1] = toricCodeCat3Bal25
 
toricCodeCat3Brd7 /: ribbonCategory[toricCodeCat3Brd7, 2] = toricCodeCat3Bal26
 
toricCodeCat3Brd7 /: ribbonCategory[toricCodeCat3Brd7, 3] = toricCodeCat3Bal27
 
toricCodeCat3Brd7 /: ribbonCategory[toricCodeCat3Brd7, 4] = toricCodeCat3Bal28
 
ring[toricCodeCat3Brd7] ^= toricCode
 
rMatrixFunction[toricCodeCat3Brd7] ^= toricCodeCat3Brd7RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[toricCodeCat3]][braidedCategory[#1]] & )[
    toricCodeCat3Brd7] ^= 7
braidedCategory[toricCodeCat3Brd7RMatrixFunction] ^= toricCodeCat3Brd7
 
fusionCategory[toricCodeCat3Brd7RMatrixFunction] ^= toricCodeCat3
 
rMatrixFunction[toricCodeCat3Brd7RMatrixFunction] ^= 
   toricCodeCat3Brd7RMatrixFunction
 
toricCodeCat3Brd7RMatrixFunction[0, 0, 0] = {{1}}
 
toricCodeCat3Brd7RMatrixFunction[0, 1, 1] = {{1}}
 
toricCodeCat3Brd7RMatrixFunction[0, 2, 2] = {{1}}
 
toricCodeCat3Brd7RMatrixFunction[0, 3, 3] = {{1}}
 
toricCodeCat3Brd7RMatrixFunction[1, 0, 1] = {{1}}
 
toricCodeCat3Brd7RMatrixFunction[1, 1, 0] = {{I}}
 
toricCodeCat3Brd7RMatrixFunction[1, 2, 3] = {{-1}}
 
toricCodeCat3Brd7RMatrixFunction[1, 3, 2] = {{-I}}
 
toricCodeCat3Brd7RMatrixFunction[2, 0, 2] = {{1}}
 
toricCodeCat3Brd7RMatrixFunction[2, 1, 3] = {{-1}}
 
toricCodeCat3Brd7RMatrixFunction[2, 2, 0] = {{I}}
 
toricCodeCat3Brd7RMatrixFunction[2, 3, 1] = {{-I}}
 
toricCodeCat3Brd7RMatrixFunction[3, 0, 3] = {{1}}
 
toricCodeCat3Brd7RMatrixFunction[3, 1, 2] = {{-I}}
 
toricCodeCat3Brd7RMatrixFunction[3, 2, 1] = {{-I}}
 
toricCodeCat3Brd7RMatrixFunction[3, 3, 0] = {{-1}}
balancedCategories[toricCodeCat3Brd8] ^= {toricCodeCat3Bal29, 
    toricCodeCat3Bal30, toricCodeCat3Bal31, toricCodeCat3Bal32}
 
toricCodeCat3Brd8 /: balancedCategory[toricCodeCat3Brd8, 1] = 
    toricCodeCat3Bal29
 
toricCodeCat3Brd8 /: balancedCategory[toricCodeCat3Brd8, 2] = 
    toricCodeCat3Bal30
 
toricCodeCat3Brd8 /: balancedCategory[toricCodeCat3Brd8, 3] = 
    toricCodeCat3Bal31
 
toricCodeCat3Brd8 /: balancedCategory[toricCodeCat3Brd8, 4] = 
    toricCodeCat3Bal32
 
braidedCategory[toricCodeCat3Brd8] ^= toricCodeCat3Brd8
 
fusionCategory[toricCodeCat3Brd8] ^= toricCodeCat3
 
toricCodeCat3Brd8 /: modularCategory[toricCodeCat3Brd8, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
toricCodeCat3Brd8 /: ribbonCategory[toricCodeCat3Brd8, 1] = toricCodeCat3Bal29
 
toricCodeCat3Brd8 /: ribbonCategory[toricCodeCat3Brd8, 2] = toricCodeCat3Bal30
 
toricCodeCat3Brd8 /: ribbonCategory[toricCodeCat3Brd8, 3] = toricCodeCat3Bal31
 
toricCodeCat3Brd8 /: ribbonCategory[toricCodeCat3Brd8, 4] = toricCodeCat3Bal32
 
ring[toricCodeCat3Brd8] ^= toricCode
 
rMatrixFunction[toricCodeCat3Brd8] ^= toricCodeCat3Brd8RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[toricCodeCat3]][braidedCategory[#1]] & )[
    toricCodeCat3Brd8] ^= 8
braidedCategory[toricCodeCat3Brd8RMatrixFunction] ^= toricCodeCat3Brd8
 
fusionCategory[toricCodeCat3Brd8RMatrixFunction] ^= toricCodeCat3
 
rMatrixFunction[toricCodeCat3Brd8RMatrixFunction] ^= 
   toricCodeCat3Brd8RMatrixFunction
 
toricCodeCat3Brd8RMatrixFunction[0, 0, 0] = {{1}}
 
toricCodeCat3Brd8RMatrixFunction[0, 1, 1] = {{1}}
 
toricCodeCat3Brd8RMatrixFunction[0, 2, 2] = {{1}}
 
toricCodeCat3Brd8RMatrixFunction[0, 3, 3] = {{1}}
 
toricCodeCat3Brd8RMatrixFunction[1, 0, 1] = {{1}}
 
toricCodeCat3Brd8RMatrixFunction[1, 1, 0] = {{I}}
 
toricCodeCat3Brd8RMatrixFunction[1, 2, 3] = {{1}}
 
toricCodeCat3Brd8RMatrixFunction[1, 3, 2] = {{I}}
 
toricCodeCat3Brd8RMatrixFunction[2, 0, 2] = {{1}}
 
toricCodeCat3Brd8RMatrixFunction[2, 1, 3] = {{-1}}
 
toricCodeCat3Brd8RMatrixFunction[2, 2, 0] = {{I}}
 
toricCodeCat3Brd8RMatrixFunction[2, 3, 1] = {{-I}}
 
toricCodeCat3Brd8RMatrixFunction[3, 0, 3] = {{1}}
 
toricCodeCat3Brd8RMatrixFunction[3, 1, 2] = {{-I}}
 
toricCodeCat3Brd8RMatrixFunction[3, 2, 1] = {{I}}
 
toricCodeCat3Brd8RMatrixFunction[3, 3, 0] = {{1}}
fMatrixFunction[toricCodeCat3FMatrixFunction] ^= toricCodeCat3FMatrixFunction
 
fusionCategory[toricCodeCat3FMatrixFunction] ^= toricCodeCat3
 
ring[toricCodeCat3FMatrixFunction] ^= toricCode
 
toricCodeCat3FMatrixFunction[1, 1, 1, 1] = {{-1}}
 
toricCodeCat3FMatrixFunction[1, 1, 3, 3] = {{-1}}
 
toricCodeCat3FMatrixFunction[1, 3, 1, 3] = {{-1}}
 
toricCodeCat3FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
toricCodeCat3FMatrixFunction[2, 2, 2, 2] = {{-1}}
 
toricCodeCat3FMatrixFunction[2, 2, 3, 3] = {{-1}}
 
toricCodeCat3FMatrixFunction[2, 3, 2, 3] = {{-1}}
 
toricCodeCat3FMatrixFunction[2, 3, 3, 2] = {{-1}}
 
toricCodeCat3FMatrixFunction[3, 1, 1, 3] = {{-1}}
 
toricCodeCat3FMatrixFunction[3, 1, 3, 1] = {{-1}}
 
toricCodeCat3FMatrixFunction[3, 2, 2, 3] = {{-1}}
 
toricCodeCat3FMatrixFunction[3, 2, 3, 2] = {{-1}}
 
toricCodeCat3FMatrixFunction[3, 3, 1, 1] = {{-1}}
 
toricCodeCat3FMatrixFunction[3, 3, 2, 2] = {{-1}}
 
toricCodeCat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[toricCodeCat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
toricCodeCat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[toricCodeCat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[toricCodeCat3Piv1] ^= {toricCodeCat3Bal1, 
    toricCodeCat3Bal5, toricCodeCat3Bal9, toricCodeCat3Bal13, 
    toricCodeCat3Bal17, toricCodeCat3Bal21, toricCodeCat3Bal25, 
    toricCodeCat3Bal29}
 
toricCodeCat3Piv1 /: balancedCategory[toricCodeCat3Piv1, 1] = 
    toricCodeCat3Bal1
 
toricCodeCat3Piv1 /: balancedCategory[toricCodeCat3Piv1, 2] = 
    toricCodeCat3Bal5
 
toricCodeCat3Piv1 /: balancedCategory[toricCodeCat3Piv1, 3] = 
    toricCodeCat3Bal9
 
toricCodeCat3Piv1 /: balancedCategory[toricCodeCat3Piv1, 4] = 
    toricCodeCat3Bal13
 
toricCodeCat3Piv1 /: balancedCategory[toricCodeCat3Piv1, 5] = 
    toricCodeCat3Bal17
 
toricCodeCat3Piv1 /: balancedCategory[toricCodeCat3Piv1, 6] = 
    toricCodeCat3Bal21
 
toricCodeCat3Piv1 /: balancedCategory[toricCodeCat3Piv1, 7] = 
    toricCodeCat3Bal25
 
toricCodeCat3Piv1 /: balancedCategory[toricCodeCat3Piv1, 8] = 
    toricCodeCat3Bal29
 
fusionCategory[toricCodeCat3Piv1] ^= toricCodeCat3
 
toricCodeCat3Piv1 /: modularCategory[toricCodeCat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[toricCodeCat3Piv1] ^= toricCodeCat3Piv1
 
pivotalIsomorphism[toricCodeCat3Piv1] ^= toricCodeCat3Piv1PivotalIsomorphism
 
toricCodeCat3Piv1 /: ribbonCategory[toricCodeCat3Piv1, 1] = toricCodeCat3Bal1
 
toricCodeCat3Piv1 /: ribbonCategory[toricCodeCat3Piv1, 2] = toricCodeCat3Bal5
 
toricCodeCat3Piv1 /: ribbonCategory[toricCodeCat3Piv1, 3] = toricCodeCat3Bal9
 
toricCodeCat3Piv1 /: ribbonCategory[toricCodeCat3Piv1, 4] = toricCodeCat3Bal13
 
toricCodeCat3Piv1 /: ribbonCategory[toricCodeCat3Piv1, 5] = toricCodeCat3Bal17
 
toricCodeCat3Piv1 /: ribbonCategory[toricCodeCat3Piv1, 6] = toricCodeCat3Bal21
 
toricCodeCat3Piv1 /: ribbonCategory[toricCodeCat3Piv1, 7] = toricCodeCat3Bal25
 
toricCodeCat3Piv1 /: ribbonCategory[toricCodeCat3Piv1, 8] = toricCodeCat3Bal29
 
ring[toricCodeCat3Piv1] ^= toricCode
 
sphericalCategory[toricCodeCat3Piv1] ^= toricCodeCat3Piv1
 
(pivotalCategoryIndex[fusionCategory[toricCodeCat3]][pivotalCategory[#1]] & )[
    toricCodeCat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[toricCodeCat3]][
      sphericalCategory[#1]] & )[toricCodeCat3Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[toricCodeCat3Piv1PivotalIsomorphism] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Piv1PivotalIsomorphism] ^= toricCodeCat3Piv1
 
pivotalIsomorphism[toricCodeCat3Piv1PivotalIsomorphism] ^= 
   toricCodeCat3Piv1PivotalIsomorphism
 
toricCodeCat3Piv1PivotalIsomorphism[0] = 1
 
toricCodeCat3Piv1PivotalIsomorphism[1] = 1
 
toricCodeCat3Piv1PivotalIsomorphism[2] = 1
 
toricCodeCat3Piv1PivotalIsomorphism[3] = 1
balancedCategories[toricCodeCat3Piv2] ^= {toricCodeCat3Bal2, 
    toricCodeCat3Bal6, toricCodeCat3Bal10, toricCodeCat3Bal14, 
    toricCodeCat3Bal18, toricCodeCat3Bal22, toricCodeCat3Bal26, 
    toricCodeCat3Bal30}
 
toricCodeCat3Piv2 /: balancedCategory[toricCodeCat3Piv2, 1] = 
    toricCodeCat3Bal2
 
toricCodeCat3Piv2 /: balancedCategory[toricCodeCat3Piv2, 2] = 
    toricCodeCat3Bal6
 
toricCodeCat3Piv2 /: balancedCategory[toricCodeCat3Piv2, 3] = 
    toricCodeCat3Bal10
 
toricCodeCat3Piv2 /: balancedCategory[toricCodeCat3Piv2, 4] = 
    toricCodeCat3Bal14
 
toricCodeCat3Piv2 /: balancedCategory[toricCodeCat3Piv2, 5] = 
    toricCodeCat3Bal18
 
toricCodeCat3Piv2 /: balancedCategory[toricCodeCat3Piv2, 6] = 
    toricCodeCat3Bal22
 
toricCodeCat3Piv2 /: balancedCategory[toricCodeCat3Piv2, 7] = 
    toricCodeCat3Bal26
 
toricCodeCat3Piv2 /: balancedCategory[toricCodeCat3Piv2, 8] = 
    toricCodeCat3Bal30
 
fusionCategory[toricCodeCat3Piv2] ^= toricCodeCat3
 
toricCodeCat3Piv2 /: modularCategory[toricCodeCat3Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[toricCodeCat3Piv2] ^= toricCodeCat3Piv2
 
pivotalIsomorphism[toricCodeCat3Piv2] ^= toricCodeCat3Piv2PivotalIsomorphism
 
toricCodeCat3Piv2 /: ribbonCategory[toricCodeCat3Piv2, 1] = toricCodeCat3Bal2
 
toricCodeCat3Piv2 /: ribbonCategory[toricCodeCat3Piv2, 2] = toricCodeCat3Bal6
 
toricCodeCat3Piv2 /: ribbonCategory[toricCodeCat3Piv2, 3] = toricCodeCat3Bal10
 
toricCodeCat3Piv2 /: ribbonCategory[toricCodeCat3Piv2, 4] = toricCodeCat3Bal14
 
toricCodeCat3Piv2 /: ribbonCategory[toricCodeCat3Piv2, 5] = toricCodeCat3Bal18
 
toricCodeCat3Piv2 /: ribbonCategory[toricCodeCat3Piv2, 6] = toricCodeCat3Bal22
 
toricCodeCat3Piv2 /: ribbonCategory[toricCodeCat3Piv2, 7] = toricCodeCat3Bal26
 
toricCodeCat3Piv2 /: ribbonCategory[toricCodeCat3Piv2, 8] = toricCodeCat3Bal30
 
ring[toricCodeCat3Piv2] ^= toricCode
 
sphericalCategory[toricCodeCat3Piv2] ^= toricCodeCat3Piv2
 
(pivotalCategoryIndex[fusionCategory[toricCodeCat3]][pivotalCategory[#1]] & )[
    toricCodeCat3Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[toricCodeCat3]][
      sphericalCategory[#1]] & )[toricCodeCat3Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[toricCodeCat3Piv2PivotalIsomorphism] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Piv2PivotalIsomorphism] ^= toricCodeCat3Piv2
 
pivotalIsomorphism[toricCodeCat3Piv2PivotalIsomorphism] ^= 
   toricCodeCat3Piv2PivotalIsomorphism
 
toricCodeCat3Piv2PivotalIsomorphism[0] = 1
 
toricCodeCat3Piv2PivotalIsomorphism[1] = -1
 
toricCodeCat3Piv2PivotalIsomorphism[2] = -1
 
toricCodeCat3Piv2PivotalIsomorphism[3] = 1
balancedCategories[toricCodeCat3Piv3] ^= {toricCodeCat3Bal3, 
    toricCodeCat3Bal7, toricCodeCat3Bal11, toricCodeCat3Bal15, 
    toricCodeCat3Bal19, toricCodeCat3Bal23, toricCodeCat3Bal27, 
    toricCodeCat3Bal31}
 
toricCodeCat3Piv3 /: balancedCategory[toricCodeCat3Piv3, 1] = 
    toricCodeCat3Bal3
 
toricCodeCat3Piv3 /: balancedCategory[toricCodeCat3Piv3, 2] = 
    toricCodeCat3Bal7
 
toricCodeCat3Piv3 /: balancedCategory[toricCodeCat3Piv3, 3] = 
    toricCodeCat3Bal11
 
toricCodeCat3Piv3 /: balancedCategory[toricCodeCat3Piv3, 4] = 
    toricCodeCat3Bal15
 
toricCodeCat3Piv3 /: balancedCategory[toricCodeCat3Piv3, 5] = 
    toricCodeCat3Bal19
 
toricCodeCat3Piv3 /: balancedCategory[toricCodeCat3Piv3, 6] = 
    toricCodeCat3Bal23
 
toricCodeCat3Piv3 /: balancedCategory[toricCodeCat3Piv3, 7] = 
    toricCodeCat3Bal27
 
toricCodeCat3Piv3 /: balancedCategory[toricCodeCat3Piv3, 8] = 
    toricCodeCat3Bal31
 
fusionCategory[toricCodeCat3Piv3] ^= toricCodeCat3
 
toricCodeCat3Piv3 /: modularCategory[toricCodeCat3Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[toricCodeCat3Piv3] ^= toricCodeCat3Piv3
 
pivotalIsomorphism[toricCodeCat3Piv3] ^= toricCodeCat3Piv3PivotalIsomorphism
 
toricCodeCat3Piv3 /: ribbonCategory[toricCodeCat3Piv3, 1] = toricCodeCat3Bal3
 
toricCodeCat3Piv3 /: ribbonCategory[toricCodeCat3Piv3, 2] = toricCodeCat3Bal7
 
toricCodeCat3Piv3 /: ribbonCategory[toricCodeCat3Piv3, 3] = toricCodeCat3Bal11
 
toricCodeCat3Piv3 /: ribbonCategory[toricCodeCat3Piv3, 4] = toricCodeCat3Bal15
 
toricCodeCat3Piv3 /: ribbonCategory[toricCodeCat3Piv3, 5] = toricCodeCat3Bal19
 
toricCodeCat3Piv3 /: ribbonCategory[toricCodeCat3Piv3, 6] = toricCodeCat3Bal23
 
toricCodeCat3Piv3 /: ribbonCategory[toricCodeCat3Piv3, 7] = toricCodeCat3Bal27
 
toricCodeCat3Piv3 /: ribbonCategory[toricCodeCat3Piv3, 8] = toricCodeCat3Bal31
 
ring[toricCodeCat3Piv3] ^= toricCode
 
sphericalCategory[toricCodeCat3Piv3] ^= toricCodeCat3Piv3
 
(pivotalCategoryIndex[fusionCategory[toricCodeCat3]][pivotalCategory[#1]] & )[
    toricCodeCat3Piv3] ^= 3
 
(sphericalCategoryIndex[fusionCategory[toricCodeCat3]][
      sphericalCategory[#1]] & )[toricCodeCat3Piv3] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[toricCodeCat3Piv3PivotalIsomorphism] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Piv3PivotalIsomorphism] ^= toricCodeCat3Piv3
 
pivotalIsomorphism[toricCodeCat3Piv3PivotalIsomorphism] ^= 
   toricCodeCat3Piv3PivotalIsomorphism
 
toricCodeCat3Piv3PivotalIsomorphism[0] = 1
 
toricCodeCat3Piv3PivotalIsomorphism[1] = 1
 
toricCodeCat3Piv3PivotalIsomorphism[2] = -1
 
toricCodeCat3Piv3PivotalIsomorphism[3] = -1
balancedCategories[toricCodeCat3Piv4] ^= {toricCodeCat3Bal4, 
    toricCodeCat3Bal8, toricCodeCat3Bal12, toricCodeCat3Bal16, 
    toricCodeCat3Bal20, toricCodeCat3Bal24, toricCodeCat3Bal28, 
    toricCodeCat3Bal32}
 
toricCodeCat3Piv4 /: balancedCategory[toricCodeCat3Piv4, 1] = 
    toricCodeCat3Bal4
 
toricCodeCat3Piv4 /: balancedCategory[toricCodeCat3Piv4, 2] = 
    toricCodeCat3Bal8
 
toricCodeCat3Piv4 /: balancedCategory[toricCodeCat3Piv4, 3] = 
    toricCodeCat3Bal12
 
toricCodeCat3Piv4 /: balancedCategory[toricCodeCat3Piv4, 4] = 
    toricCodeCat3Bal16
 
toricCodeCat3Piv4 /: balancedCategory[toricCodeCat3Piv4, 5] = 
    toricCodeCat3Bal20
 
toricCodeCat3Piv4 /: balancedCategory[toricCodeCat3Piv4, 6] = 
    toricCodeCat3Bal24
 
toricCodeCat3Piv4 /: balancedCategory[toricCodeCat3Piv4, 7] = 
    toricCodeCat3Bal28
 
toricCodeCat3Piv4 /: balancedCategory[toricCodeCat3Piv4, 8] = 
    toricCodeCat3Bal32
 
fusionCategory[toricCodeCat3Piv4] ^= toricCodeCat3
 
toricCodeCat3Piv4 /: modularCategory[toricCodeCat3Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[toricCodeCat3Piv4] ^= toricCodeCat3Piv4
 
pivotalIsomorphism[toricCodeCat3Piv4] ^= toricCodeCat3Piv4PivotalIsomorphism
 
toricCodeCat3Piv4 /: ribbonCategory[toricCodeCat3Piv4, 1] = toricCodeCat3Bal4
 
toricCodeCat3Piv4 /: ribbonCategory[toricCodeCat3Piv4, 2] = toricCodeCat3Bal8
 
toricCodeCat3Piv4 /: ribbonCategory[toricCodeCat3Piv4, 3] = toricCodeCat3Bal12
 
toricCodeCat3Piv4 /: ribbonCategory[toricCodeCat3Piv4, 4] = toricCodeCat3Bal16
 
toricCodeCat3Piv4 /: ribbonCategory[toricCodeCat3Piv4, 5] = toricCodeCat3Bal20
 
toricCodeCat3Piv4 /: ribbonCategory[toricCodeCat3Piv4, 6] = toricCodeCat3Bal24
 
toricCodeCat3Piv4 /: ribbonCategory[toricCodeCat3Piv4, 7] = toricCodeCat3Bal28
 
toricCodeCat3Piv4 /: ribbonCategory[toricCodeCat3Piv4, 8] = toricCodeCat3Bal32
 
ring[toricCodeCat3Piv4] ^= toricCode
 
sphericalCategory[toricCodeCat3Piv4] ^= toricCodeCat3Piv4
 
(pivotalCategoryIndex[fusionCategory[toricCodeCat3]][pivotalCategory[#1]] & )[
    toricCodeCat3Piv4] ^= 4
 
(sphericalCategoryIndex[fusionCategory[toricCodeCat3]][
      sphericalCategory[#1]] & )[toricCodeCat3Piv4] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[toricCodeCat3Piv4PivotalIsomorphism] ^= toricCodeCat3
 
pivotalCategory[toricCodeCat3Piv4PivotalIsomorphism] ^= toricCodeCat3Piv4
 
pivotalIsomorphism[toricCodeCat3Piv4PivotalIsomorphism] ^= 
   toricCodeCat3Piv4PivotalIsomorphism
 
toricCodeCat3Piv4PivotalIsomorphism[0] = 1
 
toricCodeCat3Piv4PivotalIsomorphism[1] = -1
 
toricCodeCat3Piv4PivotalIsomorphism[2] = 1
 
toricCodeCat3Piv4PivotalIsomorphism[3] = -1
balancedCategories[toricCodeCat4] ^= {toricCodeCat4Bal1, toricCodeCat4Bal2, 
    toricCodeCat4Bal3, toricCodeCat4Bal4, toricCodeCat4Bal5, 
    toricCodeCat4Bal6, toricCodeCat4Bal7, toricCodeCat4Bal8, 
    toricCodeCat4Bal9, toricCodeCat4Bal10, toricCodeCat4Bal11, 
    toricCodeCat4Bal12, toricCodeCat4Bal13, toricCodeCat4Bal14, 
    toricCodeCat4Bal15, toricCodeCat4Bal16, toricCodeCat4Bal17, 
    toricCodeCat4Bal18, toricCodeCat4Bal19, toricCodeCat4Bal20, 
    toricCodeCat4Bal21, toricCodeCat4Bal22, toricCodeCat4Bal23, 
    toricCodeCat4Bal24, toricCodeCat4Bal25, toricCodeCat4Bal26, 
    toricCodeCat4Bal27, toricCodeCat4Bal28, toricCodeCat4Bal29, 
    toricCodeCat4Bal30, toricCodeCat4Bal31, toricCodeCat4Bal32}
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 1] = toricCodeCat4Bal1
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 2] = toricCodeCat4Bal2
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 3] = toricCodeCat4Bal3
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 4] = toricCodeCat4Bal4
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 5] = toricCodeCat4Bal5
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 6] = toricCodeCat4Bal6
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 7] = toricCodeCat4Bal7
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 8] = toricCodeCat4Bal8
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 9] = toricCodeCat4Bal9
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 10] = toricCodeCat4Bal10
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 11] = toricCodeCat4Bal11
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 12] = toricCodeCat4Bal12
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 13] = toricCodeCat4Bal13
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 14] = toricCodeCat4Bal14
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 15] = toricCodeCat4Bal15
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 16] = toricCodeCat4Bal16
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 17] = toricCodeCat4Bal17
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 18] = toricCodeCat4Bal18
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 19] = toricCodeCat4Bal19
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 20] = toricCodeCat4Bal20
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 21] = toricCodeCat4Bal21
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 22] = toricCodeCat4Bal22
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 23] = toricCodeCat4Bal23
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 24] = toricCodeCat4Bal24
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 25] = toricCodeCat4Bal25
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 26] = toricCodeCat4Bal26
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 27] = toricCodeCat4Bal27
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 28] = toricCodeCat4Bal28
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 29] = toricCodeCat4Bal29
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 30] = toricCodeCat4Bal30
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 31] = toricCodeCat4Bal31
 
toricCodeCat4 /: balancedCategory[toricCodeCat4, 32] = toricCodeCat4Bal32
 
braidedCategories[toricCodeCat4] ^= {toricCodeCat4Brd1, toricCodeCat4Brd2, 
    toricCodeCat4Brd3, toricCodeCat4Brd4, toricCodeCat4Brd5, 
    toricCodeCat4Brd6, toricCodeCat4Brd7, toricCodeCat4Brd8}
 
toricCodeCat4 /: braidedCategory[toricCodeCat4, 1] = toricCodeCat4Brd1
 
toricCodeCat4 /: braidedCategory[toricCodeCat4, 2] = toricCodeCat4Brd2
 
toricCodeCat4 /: braidedCategory[toricCodeCat4, 3] = toricCodeCat4Brd3
 
toricCodeCat4 /: braidedCategory[toricCodeCat4, 4] = toricCodeCat4Brd4
 
toricCodeCat4 /: braidedCategory[toricCodeCat4, 5] = toricCodeCat4Brd5
 
toricCodeCat4 /: braidedCategory[toricCodeCat4, 6] = toricCodeCat4Brd6
 
toricCodeCat4 /: braidedCategory[toricCodeCat4, 7] = toricCodeCat4Brd7
 
toricCodeCat4 /: braidedCategory[toricCodeCat4, 8] = toricCodeCat4Brd8
 
coeval[toricCodeCat4] ^= 1/sixJFunction[toricCodeCat4][#1, 
      dual[ring[toricCodeCat4]][#1], #1, #1, 0, 0] & 
 
eval[toricCodeCat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[toricCodeCat4] ^= toricCodeCat4FMatrixFunction
 
fusionCategory[toricCodeCat4] ^= toricCodeCat4
 
toricCodeCat4 /: modularCategory[toricCodeCat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[toricCodeCat4] ^= {toricCodeCat4Piv1, toricCodeCat4Piv2, 
    toricCodeCat4Piv3, toricCodeCat4Piv4}
 
toricCodeCat4 /: pivotalCategory[toricCodeCat4, 1] = toricCodeCat4Piv1
 
toricCodeCat4 /: pivotalCategory[toricCodeCat4, 2] = toricCodeCat4Piv2
 
toricCodeCat4 /: pivotalCategory[toricCodeCat4, 3] = toricCodeCat4Piv3
 
toricCodeCat4 /: pivotalCategory[toricCodeCat4, 4] = toricCodeCat4Piv4
 
toricCodeCat4 /: pivotalCategory[toricCodeCat4, {1, -1, -1, 1}] = 
    toricCodeCat4Piv2
 
toricCodeCat4 /: pivotalCategory[toricCodeCat4, {1, -1, 1, -1}] = 
    toricCodeCat4Piv4
 
toricCodeCat4 /: pivotalCategory[toricCodeCat4, {1, 1, -1, -1}] = 
    toricCodeCat4Piv3
 
toricCodeCat4 /: pivotalCategory[toricCodeCat4, {1, 1, 1, 1}] = 
    toricCodeCat4Piv1
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 1] = toricCodeCat4Bal1
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 2] = toricCodeCat4Bal2
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 3] = toricCodeCat4Bal3
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 4] = toricCodeCat4Bal4
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 5] = toricCodeCat4Bal5
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 6] = toricCodeCat4Bal6
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 7] = toricCodeCat4Bal7
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 8] = toricCodeCat4Bal8
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 9] = toricCodeCat4Bal9
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 10] = toricCodeCat4Bal10
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 11] = toricCodeCat4Bal11
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 12] = toricCodeCat4Bal12
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 13] = toricCodeCat4Bal13
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 14] = toricCodeCat4Bal14
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 15] = toricCodeCat4Bal15
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 16] = toricCodeCat4Bal16
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 17] = toricCodeCat4Bal17
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 18] = toricCodeCat4Bal18
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 19] = toricCodeCat4Bal19
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 20] = toricCodeCat4Bal20
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 21] = toricCodeCat4Bal21
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 22] = toricCodeCat4Bal22
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 23] = toricCodeCat4Bal23
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 24] = toricCodeCat4Bal24
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 25] = toricCodeCat4Bal25
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 26] = toricCodeCat4Bal26
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 27] = toricCodeCat4Bal27
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 28] = toricCodeCat4Bal28
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 29] = toricCodeCat4Bal29
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 30] = toricCodeCat4Bal30
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 31] = toricCodeCat4Bal31
 
toricCodeCat4 /: ribbonCategory[toricCodeCat4, 32] = toricCodeCat4Bal32
 
ring[toricCodeCat4] ^= toricCode
 
toricCodeCat4 /: sphericalCategory[toricCodeCat4, 1] = toricCodeCat4Piv1
 
toricCodeCat4 /: sphericalCategory[toricCodeCat4, 2] = toricCodeCat4Piv2
 
toricCodeCat4 /: sphericalCategory[toricCodeCat4, 3] = toricCodeCat4Piv3
 
toricCodeCat4 /: sphericalCategory[toricCodeCat4, 4] = toricCodeCat4Piv4
 
toricCodeCat4 /: symmetricCategory[toricCodeCat4, 1] = toricCodeCat4Brd2
 
toricCodeCat4 /: symmetricCategory[toricCodeCat4, 2] = toricCodeCat4Brd3
 
toricCodeCat4 /: symmetricCategory[toricCodeCat4, 3] = toricCodeCat4Brd5
 
toricCodeCat4 /: symmetricCategory[toricCodeCat4, 4] = toricCodeCat4Brd8
 
fusionCategoryIndex[toricCode][toricCodeCat4] ^= 4
balancedCategory[toricCodeCat4Bal1] ^= toricCodeCat4Bal1
 
braidedCategory[toricCodeCat4Bal1] ^= toricCodeCat4Brd1
 
fusionCategory[toricCodeCat4Bal1] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal1] ^= toricCodeCat4Piv1
 
ribbonCategory[toricCodeCat4Bal1] ^= toricCodeCat4Bal1
 
ring[toricCodeCat4Bal1] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal1] ^= toricCodeCat4Piv1
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd1]][
      balancedCategory[#1]] & )[toricCodeCat4Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv1]][
      balancedCategory[#1]] & )[toricCodeCat4Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd1]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv1]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal1] ^= 1
balancedCategory[toricCodeCat4Bal10] ^= toricCodeCat4Bal10
 
braidedCategory[toricCodeCat4Bal10] ^= toricCodeCat4Brd3
 
fusionCategory[toricCodeCat4Bal10] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal10] ^= toricCodeCat4Piv2
 
ribbonCategory[toricCodeCat4Bal10] ^= toricCodeCat4Bal10
 
ring[toricCodeCat4Bal10] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal10] ^= toricCodeCat4Piv2
 
symmetricCategory[toricCodeCat4Bal10] ^= toricCodeCat4Brd3
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd3]][
      balancedCategory[#1]] & )[toricCodeCat4Bal10] ^= 2
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal10] ^= 10
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv2]][
      balancedCategory[#1]] & )[toricCodeCat4Bal10] ^= 3
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd3]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal10] ^= 2
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal10] ^= 10
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv2]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal10] ^= 3
balancedCategory[toricCodeCat4Bal11] ^= toricCodeCat4Bal11
 
braidedCategory[toricCodeCat4Bal11] ^= toricCodeCat4Brd3
 
fusionCategory[toricCodeCat4Bal11] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal11] ^= toricCodeCat4Piv3
 
ribbonCategory[toricCodeCat4Bal11] ^= toricCodeCat4Bal11
 
ring[toricCodeCat4Bal11] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal11] ^= toricCodeCat4Piv3
 
symmetricCategory[toricCodeCat4Bal11] ^= toricCodeCat4Brd3
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd3]][
      balancedCategory[#1]] & )[toricCodeCat4Bal11] ^= 3
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal11] ^= 11
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv3]][
      balancedCategory[#1]] & )[toricCodeCat4Bal11] ^= 3
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd3]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal11] ^= 3
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal11] ^= 11
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv3]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal11] ^= 3
balancedCategory[toricCodeCat4Bal12] ^= toricCodeCat4Bal12
 
braidedCategory[toricCodeCat4Bal12] ^= toricCodeCat4Brd3
 
fusionCategory[toricCodeCat4Bal12] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal12] ^= toricCodeCat4Piv4
 
ribbonCategory[toricCodeCat4Bal12] ^= toricCodeCat4Bal12
 
ring[toricCodeCat4Bal12] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal12] ^= toricCodeCat4Piv4
 
symmetricCategory[toricCodeCat4Bal12] ^= toricCodeCat4Brd3
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd3]][
      balancedCategory[#1]] & )[toricCodeCat4Bal12] ^= 4
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal12] ^= 12
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal12] ^= 3
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd3]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal12] ^= 4
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal12] ^= 12
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv4]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal12] ^= 3
balancedCategory[toricCodeCat4Bal13] ^= toricCodeCat4Bal13
 
braidedCategory[toricCodeCat4Bal13] ^= toricCodeCat4Brd4
 
fusionCategory[toricCodeCat4Bal13] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal13] ^= toricCodeCat4Piv1
 
ribbonCategory[toricCodeCat4Bal13] ^= toricCodeCat4Bal13
 
ring[toricCodeCat4Bal13] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal13] ^= toricCodeCat4Piv1
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal13] ^= 1
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal13] ^= 13
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv1]][
      balancedCategory[#1]] & )[toricCodeCat4Bal13] ^= 4
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd4]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal13] ^= 1
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal13] ^= 13
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv1]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal13] ^= 4
balancedCategory[toricCodeCat4Bal14] ^= toricCodeCat4Bal14
 
braidedCategory[toricCodeCat4Bal14] ^= toricCodeCat4Brd4
 
fusionCategory[toricCodeCat4Bal14] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal14] ^= toricCodeCat4Piv2
 
ribbonCategory[toricCodeCat4Bal14] ^= toricCodeCat4Bal14
 
ring[toricCodeCat4Bal14] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal14] ^= toricCodeCat4Piv2
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal14] ^= 2
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal14] ^= 14
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv2]][
      balancedCategory[#1]] & )[toricCodeCat4Bal14] ^= 4
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd4]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal14] ^= 2
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal14] ^= 14
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv2]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal14] ^= 4
balancedCategory[toricCodeCat4Bal15] ^= toricCodeCat4Bal15
 
braidedCategory[toricCodeCat4Bal15] ^= toricCodeCat4Brd4
 
fusionCategory[toricCodeCat4Bal15] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal15] ^= toricCodeCat4Piv3
 
ribbonCategory[toricCodeCat4Bal15] ^= toricCodeCat4Bal15
 
ring[toricCodeCat4Bal15] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal15] ^= toricCodeCat4Piv3
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal15] ^= 3
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal15] ^= 15
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv3]][
      balancedCategory[#1]] & )[toricCodeCat4Bal15] ^= 4
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd4]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal15] ^= 3
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal15] ^= 15
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv3]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal15] ^= 4
balancedCategory[toricCodeCat4Bal16] ^= toricCodeCat4Bal16
 
braidedCategory[toricCodeCat4Bal16] ^= toricCodeCat4Brd4
 
fusionCategory[toricCodeCat4Bal16] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal16] ^= toricCodeCat4Piv4
 
ribbonCategory[toricCodeCat4Bal16] ^= toricCodeCat4Bal16
 
ring[toricCodeCat4Bal16] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal16] ^= toricCodeCat4Piv4
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal16] ^= 4
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal16] ^= 16
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal16] ^= 4
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd4]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal16] ^= 4
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal16] ^= 16
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv4]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal16] ^= 4
balancedCategory[toricCodeCat4Bal17] ^= toricCodeCat4Bal17
 
braidedCategory[toricCodeCat4Bal17] ^= toricCodeCat4Brd5
 
fusionCategory[toricCodeCat4Bal17] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal17] ^= toricCodeCat4Piv1
 
ribbonCategory[toricCodeCat4Bal17] ^= toricCodeCat4Bal17
 
ring[toricCodeCat4Bal17] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal17] ^= toricCodeCat4Piv1
 
symmetricCategory[toricCodeCat4Bal17] ^= toricCodeCat4Brd5
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd5]][
      balancedCategory[#1]] & )[toricCodeCat4Bal17] ^= 1
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal17] ^= 17
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv1]][
      balancedCategory[#1]] & )[toricCodeCat4Bal17] ^= 5
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd5]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal17] ^= 1
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal17] ^= 17
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv1]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal17] ^= 5
balancedCategory[toricCodeCat4Bal18] ^= toricCodeCat4Bal18
 
braidedCategory[toricCodeCat4Bal18] ^= toricCodeCat4Brd5
 
fusionCategory[toricCodeCat4Bal18] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal18] ^= toricCodeCat4Piv2
 
ribbonCategory[toricCodeCat4Bal18] ^= toricCodeCat4Bal18
 
ring[toricCodeCat4Bal18] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal18] ^= toricCodeCat4Piv2
 
symmetricCategory[toricCodeCat4Bal18] ^= toricCodeCat4Brd5
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd5]][
      balancedCategory[#1]] & )[toricCodeCat4Bal18] ^= 2
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal18] ^= 18
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv2]][
      balancedCategory[#1]] & )[toricCodeCat4Bal18] ^= 5
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd5]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal18] ^= 2
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal18] ^= 18
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv2]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal18] ^= 5
balancedCategory[toricCodeCat4Bal19] ^= toricCodeCat4Bal19
 
braidedCategory[toricCodeCat4Bal19] ^= toricCodeCat4Brd5
 
fusionCategory[toricCodeCat4Bal19] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal19] ^= toricCodeCat4Piv3
 
ribbonCategory[toricCodeCat4Bal19] ^= toricCodeCat4Bal19
 
ring[toricCodeCat4Bal19] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal19] ^= toricCodeCat4Piv3
 
symmetricCategory[toricCodeCat4Bal19] ^= toricCodeCat4Brd5
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd5]][
      balancedCategory[#1]] & )[toricCodeCat4Bal19] ^= 3
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal19] ^= 19
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv3]][
      balancedCategory[#1]] & )[toricCodeCat4Bal19] ^= 5
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd5]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal19] ^= 3
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal19] ^= 19
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv3]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal19] ^= 5
balancedCategory[toricCodeCat4Bal2] ^= toricCodeCat4Bal2
 
braidedCategory[toricCodeCat4Bal2] ^= toricCodeCat4Brd1
 
fusionCategory[toricCodeCat4Bal2] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal2] ^= toricCodeCat4Piv2
 
ribbonCategory[toricCodeCat4Bal2] ^= toricCodeCat4Bal2
 
ring[toricCodeCat4Bal2] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal2] ^= toricCodeCat4Piv2
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd1]][
      balancedCategory[#1]] & )[toricCodeCat4Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv2]][
      balancedCategory[#1]] & )[toricCodeCat4Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd1]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv2]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal2] ^= 1
balancedCategory[toricCodeCat4Bal20] ^= toricCodeCat4Bal20
 
braidedCategory[toricCodeCat4Bal20] ^= toricCodeCat4Brd5
 
fusionCategory[toricCodeCat4Bal20] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal20] ^= toricCodeCat4Piv4
 
ribbonCategory[toricCodeCat4Bal20] ^= toricCodeCat4Bal20
 
ring[toricCodeCat4Bal20] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal20] ^= toricCodeCat4Piv4
 
symmetricCategory[toricCodeCat4Bal20] ^= toricCodeCat4Brd5
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd5]][
      balancedCategory[#1]] & )[toricCodeCat4Bal20] ^= 4
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal20] ^= 20
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal20] ^= 5
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd5]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal20] ^= 4
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal20] ^= 20
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv4]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal20] ^= 5
balancedCategory[toricCodeCat4Bal21] ^= toricCodeCat4Bal21
 
braidedCategory[toricCodeCat4Bal21] ^= toricCodeCat4Brd6
 
fusionCategory[toricCodeCat4Bal21] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal21] ^= toricCodeCat4Piv1
 
ribbonCategory[toricCodeCat4Bal21] ^= toricCodeCat4Bal21
 
ring[toricCodeCat4Bal21] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal21] ^= toricCodeCat4Piv1
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd6]][
      balancedCategory[#1]] & )[toricCodeCat4Bal21] ^= 1
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal21] ^= 21
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv1]][
      balancedCategory[#1]] & )[toricCodeCat4Bal21] ^= 6
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd6]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal21] ^= 1
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal21] ^= 21
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv1]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal21] ^= 6
balancedCategory[toricCodeCat4Bal22] ^= toricCodeCat4Bal22
 
braidedCategory[toricCodeCat4Bal22] ^= toricCodeCat4Brd6
 
fusionCategory[toricCodeCat4Bal22] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal22] ^= toricCodeCat4Piv2
 
ribbonCategory[toricCodeCat4Bal22] ^= toricCodeCat4Bal22
 
ring[toricCodeCat4Bal22] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal22] ^= toricCodeCat4Piv2
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd6]][
      balancedCategory[#1]] & )[toricCodeCat4Bal22] ^= 2
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal22] ^= 22
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv2]][
      balancedCategory[#1]] & )[toricCodeCat4Bal22] ^= 6
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd6]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal22] ^= 2
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal22] ^= 22
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv2]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal22] ^= 6
balancedCategory[toricCodeCat4Bal23] ^= toricCodeCat4Bal23
 
braidedCategory[toricCodeCat4Bal23] ^= toricCodeCat4Brd6
 
fusionCategory[toricCodeCat4Bal23] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal23] ^= toricCodeCat4Piv3
 
ribbonCategory[toricCodeCat4Bal23] ^= toricCodeCat4Bal23
 
ring[toricCodeCat4Bal23] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal23] ^= toricCodeCat4Piv3
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd6]][
      balancedCategory[#1]] & )[toricCodeCat4Bal23] ^= 3
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal23] ^= 23
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv3]][
      balancedCategory[#1]] & )[toricCodeCat4Bal23] ^= 6
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd6]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal23] ^= 3
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal23] ^= 23
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv3]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal23] ^= 6
balancedCategory[toricCodeCat4Bal24] ^= toricCodeCat4Bal24
 
braidedCategory[toricCodeCat4Bal24] ^= toricCodeCat4Brd6
 
fusionCategory[toricCodeCat4Bal24] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal24] ^= toricCodeCat4Piv4
 
ribbonCategory[toricCodeCat4Bal24] ^= toricCodeCat4Bal24
 
ring[toricCodeCat4Bal24] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal24] ^= toricCodeCat4Piv4
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd6]][
      balancedCategory[#1]] & )[toricCodeCat4Bal24] ^= 4
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal24] ^= 24
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal24] ^= 6
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd6]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal24] ^= 4
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal24] ^= 24
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv4]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal24] ^= 6
balancedCategory[toricCodeCat4Bal25] ^= toricCodeCat4Bal25
 
braidedCategory[toricCodeCat4Bal25] ^= toricCodeCat4Brd7
 
fusionCategory[toricCodeCat4Bal25] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal25] ^= toricCodeCat4Piv1
 
ribbonCategory[toricCodeCat4Bal25] ^= toricCodeCat4Bal25
 
ring[toricCodeCat4Bal25] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal25] ^= toricCodeCat4Piv1
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd7]][
      balancedCategory[#1]] & )[toricCodeCat4Bal25] ^= 1
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal25] ^= 25
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv1]][
      balancedCategory[#1]] & )[toricCodeCat4Bal25] ^= 7
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd7]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal25] ^= 1
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal25] ^= 25
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv1]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal25] ^= 7
balancedCategory[toricCodeCat4Bal26] ^= toricCodeCat4Bal26
 
braidedCategory[toricCodeCat4Bal26] ^= toricCodeCat4Brd7
 
fusionCategory[toricCodeCat4Bal26] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal26] ^= toricCodeCat4Piv2
 
ribbonCategory[toricCodeCat4Bal26] ^= toricCodeCat4Bal26
 
ring[toricCodeCat4Bal26] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal26] ^= toricCodeCat4Piv2
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd7]][
      balancedCategory[#1]] & )[toricCodeCat4Bal26] ^= 2
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal26] ^= 26
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv2]][
      balancedCategory[#1]] & )[toricCodeCat4Bal26] ^= 7
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd7]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal26] ^= 2
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal26] ^= 26
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv2]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal26] ^= 7
balancedCategory[toricCodeCat4Bal27] ^= toricCodeCat4Bal27
 
braidedCategory[toricCodeCat4Bal27] ^= toricCodeCat4Brd7
 
fusionCategory[toricCodeCat4Bal27] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal27] ^= toricCodeCat4Piv3
 
ribbonCategory[toricCodeCat4Bal27] ^= toricCodeCat4Bal27
 
ring[toricCodeCat4Bal27] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal27] ^= toricCodeCat4Piv3
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd7]][
      balancedCategory[#1]] & )[toricCodeCat4Bal27] ^= 3
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal27] ^= 27
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv3]][
      balancedCategory[#1]] & )[toricCodeCat4Bal27] ^= 7
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd7]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal27] ^= 3
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal27] ^= 27
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv3]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal27] ^= 7
balancedCategory[toricCodeCat4Bal28] ^= toricCodeCat4Bal28
 
braidedCategory[toricCodeCat4Bal28] ^= toricCodeCat4Brd7
 
fusionCategory[toricCodeCat4Bal28] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal28] ^= toricCodeCat4Piv4
 
ribbonCategory[toricCodeCat4Bal28] ^= toricCodeCat4Bal28
 
ring[toricCodeCat4Bal28] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal28] ^= toricCodeCat4Piv4
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd7]][
      balancedCategory[#1]] & )[toricCodeCat4Bal28] ^= 4
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal28] ^= 28
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal28] ^= 7
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd7]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal28] ^= 4
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal28] ^= 28
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv4]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal28] ^= 7
balancedCategory[toricCodeCat4Bal29] ^= toricCodeCat4Bal29
 
braidedCategory[toricCodeCat4Bal29] ^= toricCodeCat4Brd8
 
fusionCategory[toricCodeCat4Bal29] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal29] ^= toricCodeCat4Piv1
 
ribbonCategory[toricCodeCat4Bal29] ^= toricCodeCat4Bal29
 
ring[toricCodeCat4Bal29] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal29] ^= toricCodeCat4Piv1
 
symmetricCategory[toricCodeCat4Bal29] ^= toricCodeCat4Brd8
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd8]][
      balancedCategory[#1]] & )[toricCodeCat4Bal29] ^= 1
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal29] ^= 29
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv1]][
      balancedCategory[#1]] & )[toricCodeCat4Bal29] ^= 8
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd8]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal29] ^= 1
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal29] ^= 29
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv1]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal29] ^= 8
balancedCategory[toricCodeCat4Bal3] ^= toricCodeCat4Bal3
 
braidedCategory[toricCodeCat4Bal3] ^= toricCodeCat4Brd1
 
fusionCategory[toricCodeCat4Bal3] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal3] ^= toricCodeCat4Piv3
 
ribbonCategory[toricCodeCat4Bal3] ^= toricCodeCat4Bal3
 
ring[toricCodeCat4Bal3] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal3] ^= toricCodeCat4Piv3
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd1]][
      balancedCategory[#1]] & )[toricCodeCat4Bal3] ^= 3
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv3]][
      balancedCategory[#1]] & )[toricCodeCat4Bal3] ^= 1
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd1]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal3] ^= 3
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv3]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal3] ^= 1
balancedCategory[toricCodeCat4Bal30] ^= toricCodeCat4Bal30
 
braidedCategory[toricCodeCat4Bal30] ^= toricCodeCat4Brd8
 
fusionCategory[toricCodeCat4Bal30] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal30] ^= toricCodeCat4Piv2
 
ribbonCategory[toricCodeCat4Bal30] ^= toricCodeCat4Bal30
 
ring[toricCodeCat4Bal30] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal30] ^= toricCodeCat4Piv2
 
symmetricCategory[toricCodeCat4Bal30] ^= toricCodeCat4Brd8
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd8]][
      balancedCategory[#1]] & )[toricCodeCat4Bal30] ^= 2
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal30] ^= 30
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv2]][
      balancedCategory[#1]] & )[toricCodeCat4Bal30] ^= 8
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd8]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal30] ^= 2
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal30] ^= 30
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv2]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal30] ^= 8
balancedCategory[toricCodeCat4Bal31] ^= toricCodeCat4Bal31
 
braidedCategory[toricCodeCat4Bal31] ^= toricCodeCat4Brd8
 
fusionCategory[toricCodeCat4Bal31] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal31] ^= toricCodeCat4Piv3
 
ribbonCategory[toricCodeCat4Bal31] ^= toricCodeCat4Bal31
 
ring[toricCodeCat4Bal31] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal31] ^= toricCodeCat4Piv3
 
symmetricCategory[toricCodeCat4Bal31] ^= toricCodeCat4Brd8
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd8]][
      balancedCategory[#1]] & )[toricCodeCat4Bal31] ^= 3
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal31] ^= 31
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv3]][
      balancedCategory[#1]] & )[toricCodeCat4Bal31] ^= 8
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd8]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal31] ^= 3
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal31] ^= 31
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv3]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal31] ^= 8
balancedCategory[toricCodeCat4Bal32] ^= toricCodeCat4Bal32
 
braidedCategory[toricCodeCat4Bal32] ^= toricCodeCat4Brd8
 
fusionCategory[toricCodeCat4Bal32] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal32] ^= toricCodeCat4Piv4
 
ribbonCategory[toricCodeCat4Bal32] ^= toricCodeCat4Bal32
 
ring[toricCodeCat4Bal32] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal32] ^= toricCodeCat4Piv4
 
symmetricCategory[toricCodeCat4Bal32] ^= toricCodeCat4Brd8
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd8]][
      balancedCategory[#1]] & )[toricCodeCat4Bal32] ^= 4
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal32] ^= 32
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal32] ^= 8
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd8]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal32] ^= 4
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal32] ^= 32
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv4]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal32] ^= 8
balancedCategory[toricCodeCat4Bal4] ^= toricCodeCat4Bal4
 
braidedCategory[toricCodeCat4Bal4] ^= toricCodeCat4Brd1
 
fusionCategory[toricCodeCat4Bal4] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal4] ^= toricCodeCat4Piv4
 
ribbonCategory[toricCodeCat4Bal4] ^= toricCodeCat4Bal4
 
ring[toricCodeCat4Bal4] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal4] ^= toricCodeCat4Piv4
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd1]][
      balancedCategory[#1]] & )[toricCodeCat4Bal4] ^= 4
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal4] ^= 1
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd1]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal4] ^= 4
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv4]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal4] ^= 1
balancedCategory[toricCodeCat4Bal5] ^= toricCodeCat4Bal5
 
braidedCategory[toricCodeCat4Bal5] ^= toricCodeCat4Brd2
 
fusionCategory[toricCodeCat4Bal5] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal5] ^= toricCodeCat4Piv1
 
ribbonCategory[toricCodeCat4Bal5] ^= toricCodeCat4Bal5
 
ring[toricCodeCat4Bal5] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal5] ^= toricCodeCat4Piv1
 
symmetricCategory[toricCodeCat4Bal5] ^= toricCodeCat4Brd2
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd2]][
      balancedCategory[#1]] & )[toricCodeCat4Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv1]][
      balancedCategory[#1]] & )[toricCodeCat4Bal5] ^= 2
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd2]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv1]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal5] ^= 2
balancedCategory[toricCodeCat4Bal6] ^= toricCodeCat4Bal6
 
braidedCategory[toricCodeCat4Bal6] ^= toricCodeCat4Brd2
 
fusionCategory[toricCodeCat4Bal6] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal6] ^= toricCodeCat4Piv2
 
ribbonCategory[toricCodeCat4Bal6] ^= toricCodeCat4Bal6
 
ring[toricCodeCat4Bal6] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal6] ^= toricCodeCat4Piv2
 
symmetricCategory[toricCodeCat4Bal6] ^= toricCodeCat4Brd2
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd2]][
      balancedCategory[#1]] & )[toricCodeCat4Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv2]][
      balancedCategory[#1]] & )[toricCodeCat4Bal6] ^= 2
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd2]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv2]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal6] ^= 2
balancedCategory[toricCodeCat4Bal7] ^= toricCodeCat4Bal7
 
braidedCategory[toricCodeCat4Bal7] ^= toricCodeCat4Brd2
 
fusionCategory[toricCodeCat4Bal7] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal7] ^= toricCodeCat4Piv3
 
ribbonCategory[toricCodeCat4Bal7] ^= toricCodeCat4Bal7
 
ring[toricCodeCat4Bal7] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal7] ^= toricCodeCat4Piv3
 
symmetricCategory[toricCodeCat4Bal7] ^= toricCodeCat4Brd2
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd2]][
      balancedCategory[#1]] & )[toricCodeCat4Bal7] ^= 3
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv3]][
      balancedCategory[#1]] & )[toricCodeCat4Bal7] ^= 2
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd2]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal7] ^= 3
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv3]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal7] ^= 2
balancedCategory[toricCodeCat4Bal8] ^= toricCodeCat4Bal8
 
braidedCategory[toricCodeCat4Bal8] ^= toricCodeCat4Brd2
 
fusionCategory[toricCodeCat4Bal8] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal8] ^= toricCodeCat4Piv4
 
ribbonCategory[toricCodeCat4Bal8] ^= toricCodeCat4Bal8
 
ring[toricCodeCat4Bal8] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal8] ^= toricCodeCat4Piv4
 
symmetricCategory[toricCodeCat4Bal8] ^= toricCodeCat4Brd2
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd2]][
      balancedCategory[#1]] & )[toricCodeCat4Bal8] ^= 4
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal8] ^= 2
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd2]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal8] ^= 4
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv4]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal8] ^= 2
balancedCategory[toricCodeCat4Bal9] ^= toricCodeCat4Bal9
 
braidedCategory[toricCodeCat4Bal9] ^= toricCodeCat4Brd3
 
fusionCategory[toricCodeCat4Bal9] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Bal9] ^= toricCodeCat4Piv1
 
ribbonCategory[toricCodeCat4Bal9] ^= toricCodeCat4Bal9
 
ring[toricCodeCat4Bal9] ^= toricCode
 
sphericalCategory[toricCodeCat4Bal9] ^= toricCodeCat4Piv1
 
symmetricCategory[toricCodeCat4Bal9] ^= toricCodeCat4Brd3
 
(balancedCategoryIndex[braidedCategory[toricCodeCat4Brd3]][
      balancedCategory[#1]] & )[toricCodeCat4Bal9] ^= 1
 
(balancedCategoryIndex[fusionCategory[toricCodeCat4]][
      balancedCategory[#1]] & )[toricCodeCat4Bal9] ^= 9
 
(balancedCategoryIndex[pivotalCategory[toricCodeCat4Piv1]][
      balancedCategory[#1]] & )[toricCodeCat4Bal9] ^= 3
 
(ribbonCategoryIndex[braidedCategory[toricCodeCat4Brd3]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal9] ^= 1
 
(ribbonCategoryIndex[fusionCategory[toricCodeCat4]][ribbonCategory[#1]] & )[
    toricCodeCat4Bal9] ^= 9
 
(ribbonCategoryIndex[sphericalCategory[toricCodeCat4Piv1]][
      ribbonCategory[#1]] & )[toricCodeCat4Bal9] ^= 3
balancedCategories[toricCodeCat4Brd1] ^= {toricCodeCat4Bal1, 
    toricCodeCat4Bal2, toricCodeCat4Bal3, toricCodeCat4Bal4}
 
toricCodeCat4Brd1 /: balancedCategory[toricCodeCat4Brd1, 1] = 
    toricCodeCat4Bal1
 
toricCodeCat4Brd1 /: balancedCategory[toricCodeCat4Brd1, 2] = 
    toricCodeCat4Bal2
 
toricCodeCat4Brd1 /: balancedCategory[toricCodeCat4Brd1, 3] = 
    toricCodeCat4Bal3
 
toricCodeCat4Brd1 /: balancedCategory[toricCodeCat4Brd1, 4] = 
    toricCodeCat4Bal4
 
braidedCategory[toricCodeCat4Brd1] ^= toricCodeCat4Brd1
 
fusionCategory[toricCodeCat4Brd1] ^= toricCodeCat4
 
toricCodeCat4Brd1 /: modularCategory[toricCodeCat4Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
toricCodeCat4Brd1 /: ribbonCategory[toricCodeCat4Brd1, 1] = toricCodeCat4Bal1
 
toricCodeCat4Brd1 /: ribbonCategory[toricCodeCat4Brd1, 2] = toricCodeCat4Bal2
 
toricCodeCat4Brd1 /: ribbonCategory[toricCodeCat4Brd1, 3] = toricCodeCat4Bal3
 
toricCodeCat4Brd1 /: ribbonCategory[toricCodeCat4Brd1, 4] = toricCodeCat4Bal4
 
ring[toricCodeCat4Brd1] ^= toricCode
 
rMatrixFunction[toricCodeCat4Brd1] ^= toricCodeCat4Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[toricCodeCat4]][braidedCategory[#1]] & )[
    toricCodeCat4Brd1] ^= 1
braidedCategory[toricCodeCat4Brd1RMatrixFunction] ^= toricCodeCat4Brd1
 
fusionCategory[toricCodeCat4Brd1RMatrixFunction] ^= toricCodeCat4
 
rMatrixFunction[toricCodeCat4Brd1RMatrixFunction] ^= 
   toricCodeCat4Brd1RMatrixFunction
 
toricCodeCat4Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
toricCodeCat4Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
toricCodeCat4Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
toricCodeCat4Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
toricCodeCat4Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
toricCodeCat4Brd1RMatrixFunction[1, 1, 0] = {{-1}}
 
toricCodeCat4Brd1RMatrixFunction[1, 2, 3] = {{-1}}
 
toricCodeCat4Brd1RMatrixFunction[1, 3, 2] = {{1}}
 
toricCodeCat4Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
toricCodeCat4Brd1RMatrixFunction[2, 1, 3] = {{1}}
 
toricCodeCat4Brd1RMatrixFunction[2, 2, 0] = {{-1}}
 
toricCodeCat4Brd1RMatrixFunction[2, 3, 1] = {{-1}}
 
toricCodeCat4Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
toricCodeCat4Brd1RMatrixFunction[3, 1, 2] = {{-1}}
 
toricCodeCat4Brd1RMatrixFunction[3, 2, 1] = {{1}}
 
toricCodeCat4Brd1RMatrixFunction[3, 3, 0] = {{-1}}
balancedCategories[toricCodeCat4Brd2] ^= {toricCodeCat4Bal5, 
    toricCodeCat4Bal6, toricCodeCat4Bal7, toricCodeCat4Bal8}
 
toricCodeCat4Brd2 /: balancedCategory[toricCodeCat4Brd2, 1] = 
    toricCodeCat4Bal5
 
toricCodeCat4Brd2 /: balancedCategory[toricCodeCat4Brd2, 2] = 
    toricCodeCat4Bal6
 
toricCodeCat4Brd2 /: balancedCategory[toricCodeCat4Brd2, 3] = 
    toricCodeCat4Bal7
 
toricCodeCat4Brd2 /: balancedCategory[toricCodeCat4Brd2, 4] = 
    toricCodeCat4Bal8
 
braidedCategory[toricCodeCat4Brd2] ^= toricCodeCat4Brd2
 
fusionCategory[toricCodeCat4Brd2] ^= toricCodeCat4
 
toricCodeCat4Brd2 /: modularCategory[toricCodeCat4Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
toricCodeCat4Brd2 /: ribbonCategory[toricCodeCat4Brd2, 1] = toricCodeCat4Bal5
 
toricCodeCat4Brd2 /: ribbonCategory[toricCodeCat4Brd2, 2] = toricCodeCat4Bal6
 
toricCodeCat4Brd2 /: ribbonCategory[toricCodeCat4Brd2, 3] = toricCodeCat4Bal7
 
toricCodeCat4Brd2 /: ribbonCategory[toricCodeCat4Brd2, 4] = toricCodeCat4Bal8
 
ring[toricCodeCat4Brd2] ^= toricCode
 
rMatrixFunction[toricCodeCat4Brd2] ^= toricCodeCat4Brd2RMatrixFunction
 
symmetricCategory[toricCodeCat4Brd2] ^= toricCodeCat4Brd2
 
(braidedCategoryIndex[fusionCategory[toricCodeCat4]][braidedCategory[#1]] & )[
    toricCodeCat4Brd2] ^= 2
 
(symmetricCategoryIndex[fusionCategory[toricCodeCat4]][
      symmetricCategory[#1]] & )[toricCodeCat4Brd2] ^= 1
braidedCategory[toricCodeCat4Brd2RMatrixFunction] ^= toricCodeCat4Brd2
 
fusionCategory[toricCodeCat4Brd2RMatrixFunction] ^= toricCodeCat4
 
rMatrixFunction[toricCodeCat4Brd2RMatrixFunction] ^= 
   toricCodeCat4Brd2RMatrixFunction
 
toricCodeCat4Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
toricCodeCat4Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
toricCodeCat4Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
toricCodeCat4Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
toricCodeCat4Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
toricCodeCat4Brd2RMatrixFunction[1, 1, 0] = {{-1}}
 
toricCodeCat4Brd2RMatrixFunction[1, 2, 3] = {{1}}
 
toricCodeCat4Brd2RMatrixFunction[1, 3, 2] = {{-1}}
 
toricCodeCat4Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
toricCodeCat4Brd2RMatrixFunction[2, 1, 3] = {{1}}
 
toricCodeCat4Brd2RMatrixFunction[2, 2, 0] = {{-1}}
 
toricCodeCat4Brd2RMatrixFunction[2, 3, 1] = {{-1}}
 
toricCodeCat4Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
toricCodeCat4Brd2RMatrixFunction[3, 1, 2] = {{-1}}
 
toricCodeCat4Brd2RMatrixFunction[3, 2, 1] = {{-1}}
 
toricCodeCat4Brd2RMatrixFunction[3, 3, 0] = {{1}}
balancedCategories[toricCodeCat4Brd3] ^= {toricCodeCat4Bal9, 
    toricCodeCat4Bal10, toricCodeCat4Bal11, toricCodeCat4Bal12}
 
toricCodeCat4Brd3 /: balancedCategory[toricCodeCat4Brd3, 1] = 
    toricCodeCat4Bal9
 
toricCodeCat4Brd3 /: balancedCategory[toricCodeCat4Brd3, 2] = 
    toricCodeCat4Bal10
 
toricCodeCat4Brd3 /: balancedCategory[toricCodeCat4Brd3, 3] = 
    toricCodeCat4Bal11
 
toricCodeCat4Brd3 /: balancedCategory[toricCodeCat4Brd3, 4] = 
    toricCodeCat4Bal12
 
braidedCategory[toricCodeCat4Brd3] ^= toricCodeCat4Brd3
 
fusionCategory[toricCodeCat4Brd3] ^= toricCodeCat4
 
toricCodeCat4Brd3 /: modularCategory[toricCodeCat4Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
toricCodeCat4Brd3 /: ribbonCategory[toricCodeCat4Brd3, 1] = toricCodeCat4Bal9
 
toricCodeCat4Brd3 /: ribbonCategory[toricCodeCat4Brd3, 2] = toricCodeCat4Bal10
 
toricCodeCat4Brd3 /: ribbonCategory[toricCodeCat4Brd3, 3] = toricCodeCat4Bal11
 
toricCodeCat4Brd3 /: ribbonCategory[toricCodeCat4Brd3, 4] = toricCodeCat4Bal12
 
ring[toricCodeCat4Brd3] ^= toricCode
 
rMatrixFunction[toricCodeCat4Brd3] ^= toricCodeCat4Brd3RMatrixFunction
 
symmetricCategory[toricCodeCat4Brd3] ^= toricCodeCat4Brd3
 
(braidedCategoryIndex[fusionCategory[toricCodeCat4]][braidedCategory[#1]] & )[
    toricCodeCat4Brd3] ^= 3
 
(symmetricCategoryIndex[fusionCategory[toricCodeCat4]][
      symmetricCategory[#1]] & )[toricCodeCat4Brd3] ^= 2
braidedCategory[toricCodeCat4Brd3RMatrixFunction] ^= toricCodeCat4Brd3
 
fusionCategory[toricCodeCat4Brd3RMatrixFunction] ^= toricCodeCat4
 
rMatrixFunction[toricCodeCat4Brd3RMatrixFunction] ^= 
   toricCodeCat4Brd3RMatrixFunction
 
toricCodeCat4Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
toricCodeCat4Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
toricCodeCat4Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
toricCodeCat4Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
toricCodeCat4Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
toricCodeCat4Brd3RMatrixFunction[1, 1, 0] = {{-1}}
 
toricCodeCat4Brd3RMatrixFunction[1, 2, 3] = {{-1}}
 
toricCodeCat4Brd3RMatrixFunction[1, 3, 2] = {{1}}
 
toricCodeCat4Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
toricCodeCat4Brd3RMatrixFunction[2, 1, 3] = {{-1}}
 
toricCodeCat4Brd3RMatrixFunction[2, 2, 0] = {{1}}
 
toricCodeCat4Brd3RMatrixFunction[2, 3, 1] = {{-1}}
 
toricCodeCat4Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
toricCodeCat4Brd3RMatrixFunction[3, 1, 2] = {{1}}
 
toricCodeCat4Brd3RMatrixFunction[3, 2, 1] = {{-1}}
 
toricCodeCat4Brd3RMatrixFunction[3, 3, 0] = {{-1}}
balancedCategories[toricCodeCat4Brd4] ^= {toricCodeCat4Bal13, 
    toricCodeCat4Bal14, toricCodeCat4Bal15, toricCodeCat4Bal16}
 
toricCodeCat4Brd4 /: balancedCategory[toricCodeCat4Brd4, 1] = 
    toricCodeCat4Bal13
 
toricCodeCat4Brd4 /: balancedCategory[toricCodeCat4Brd4, 2] = 
    toricCodeCat4Bal14
 
toricCodeCat4Brd4 /: balancedCategory[toricCodeCat4Brd4, 3] = 
    toricCodeCat4Bal15
 
toricCodeCat4Brd4 /: balancedCategory[toricCodeCat4Brd4, 4] = 
    toricCodeCat4Bal16
 
braidedCategory[toricCodeCat4Brd4] ^= toricCodeCat4Brd4
 
fusionCategory[toricCodeCat4Brd4] ^= toricCodeCat4
 
toricCodeCat4Brd4 /: modularCategory[toricCodeCat4Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
toricCodeCat4Brd4 /: ribbonCategory[toricCodeCat4Brd4, 1] = toricCodeCat4Bal13
 
toricCodeCat4Brd4 /: ribbonCategory[toricCodeCat4Brd4, 2] = toricCodeCat4Bal14
 
toricCodeCat4Brd4 /: ribbonCategory[toricCodeCat4Brd4, 3] = toricCodeCat4Bal15
 
toricCodeCat4Brd4 /: ribbonCategory[toricCodeCat4Brd4, 4] = toricCodeCat4Bal16
 
ring[toricCodeCat4Brd4] ^= toricCode
 
rMatrixFunction[toricCodeCat4Brd4] ^= toricCodeCat4Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[toricCodeCat4]][braidedCategory[#1]] & )[
    toricCodeCat4Brd4] ^= 4
braidedCategory[toricCodeCat4Brd4RMatrixFunction] ^= toricCodeCat4Brd4
 
fusionCategory[toricCodeCat4Brd4RMatrixFunction] ^= toricCodeCat4
 
rMatrixFunction[toricCodeCat4Brd4RMatrixFunction] ^= 
   toricCodeCat4Brd4RMatrixFunction
 
toricCodeCat4Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
toricCodeCat4Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
toricCodeCat4Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
toricCodeCat4Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
toricCodeCat4Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
toricCodeCat4Brd4RMatrixFunction[1, 1, 0] = {{-1}}
 
toricCodeCat4Brd4RMatrixFunction[1, 2, 3] = {{1}}
 
toricCodeCat4Brd4RMatrixFunction[1, 3, 2] = {{-1}}
 
toricCodeCat4Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
toricCodeCat4Brd4RMatrixFunction[2, 1, 3] = {{-1}}
 
toricCodeCat4Brd4RMatrixFunction[2, 2, 0] = {{1}}
 
toricCodeCat4Brd4RMatrixFunction[2, 3, 1] = {{-1}}
 
toricCodeCat4Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
toricCodeCat4Brd4RMatrixFunction[3, 1, 2] = {{1}}
 
toricCodeCat4Brd4RMatrixFunction[3, 2, 1] = {{1}}
 
toricCodeCat4Brd4RMatrixFunction[3, 3, 0] = {{1}}
balancedCategories[toricCodeCat4Brd5] ^= {toricCodeCat4Bal17, 
    toricCodeCat4Bal18, toricCodeCat4Bal19, toricCodeCat4Bal20}
 
toricCodeCat4Brd5 /: balancedCategory[toricCodeCat4Brd5, 1] = 
    toricCodeCat4Bal17
 
toricCodeCat4Brd5 /: balancedCategory[toricCodeCat4Brd5, 2] = 
    toricCodeCat4Bal18
 
toricCodeCat4Brd5 /: balancedCategory[toricCodeCat4Brd5, 3] = 
    toricCodeCat4Bal19
 
toricCodeCat4Brd5 /: balancedCategory[toricCodeCat4Brd5, 4] = 
    toricCodeCat4Bal20
 
braidedCategory[toricCodeCat4Brd5] ^= toricCodeCat4Brd5
 
fusionCategory[toricCodeCat4Brd5] ^= toricCodeCat4
 
toricCodeCat4Brd5 /: modularCategory[toricCodeCat4Brd5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
toricCodeCat4Brd5 /: ribbonCategory[toricCodeCat4Brd5, 1] = toricCodeCat4Bal17
 
toricCodeCat4Brd5 /: ribbonCategory[toricCodeCat4Brd5, 2] = toricCodeCat4Bal18
 
toricCodeCat4Brd5 /: ribbonCategory[toricCodeCat4Brd5, 3] = toricCodeCat4Bal19
 
toricCodeCat4Brd5 /: ribbonCategory[toricCodeCat4Brd5, 4] = toricCodeCat4Bal20
 
ring[toricCodeCat4Brd5] ^= toricCode
 
rMatrixFunction[toricCodeCat4Brd5] ^= toricCodeCat4Brd5RMatrixFunction
 
symmetricCategory[toricCodeCat4Brd5] ^= toricCodeCat4Brd5
 
(braidedCategoryIndex[fusionCategory[toricCodeCat4]][braidedCategory[#1]] & )[
    toricCodeCat4Brd5] ^= 5
 
(symmetricCategoryIndex[fusionCategory[toricCodeCat4]][
      symmetricCategory[#1]] & )[toricCodeCat4Brd5] ^= 3
braidedCategory[toricCodeCat4Brd5RMatrixFunction] ^= toricCodeCat4Brd5
 
fusionCategory[toricCodeCat4Brd5RMatrixFunction] ^= toricCodeCat4
 
rMatrixFunction[toricCodeCat4Brd5RMatrixFunction] ^= 
   toricCodeCat4Brd5RMatrixFunction
 
toricCodeCat4Brd5RMatrixFunction[0, 0, 0] = {{1}}
 
toricCodeCat4Brd5RMatrixFunction[0, 1, 1] = {{1}}
 
toricCodeCat4Brd5RMatrixFunction[0, 2, 2] = {{1}}
 
toricCodeCat4Brd5RMatrixFunction[0, 3, 3] = {{1}}
 
toricCodeCat4Brd5RMatrixFunction[1, 0, 1] = {{1}}
 
toricCodeCat4Brd5RMatrixFunction[1, 1, 0] = {{1}}
 
toricCodeCat4Brd5RMatrixFunction[1, 2, 3] = {{1}}
 
toricCodeCat4Brd5RMatrixFunction[1, 3, 2] = {{1}}
 
toricCodeCat4Brd5RMatrixFunction[2, 0, 2] = {{1}}
 
toricCodeCat4Brd5RMatrixFunction[2, 1, 3] = {{1}}
 
toricCodeCat4Brd5RMatrixFunction[2, 2, 0] = {{-1}}
 
toricCodeCat4Brd5RMatrixFunction[2, 3, 1] = {{-1}}
 
toricCodeCat4Brd5RMatrixFunction[3, 0, 3] = {{1}}
 
toricCodeCat4Brd5RMatrixFunction[3, 1, 2] = {{1}}
 
toricCodeCat4Brd5RMatrixFunction[3, 2, 1] = {{-1}}
 
toricCodeCat4Brd5RMatrixFunction[3, 3, 0] = {{-1}}
balancedCategories[toricCodeCat4Brd6] ^= {toricCodeCat4Bal21, 
    toricCodeCat4Bal22, toricCodeCat4Bal23, toricCodeCat4Bal24}
 
toricCodeCat4Brd6 /: balancedCategory[toricCodeCat4Brd6, 1] = 
    toricCodeCat4Bal21
 
toricCodeCat4Brd6 /: balancedCategory[toricCodeCat4Brd6, 2] = 
    toricCodeCat4Bal22
 
toricCodeCat4Brd6 /: balancedCategory[toricCodeCat4Brd6, 3] = 
    toricCodeCat4Bal23
 
toricCodeCat4Brd6 /: balancedCategory[toricCodeCat4Brd6, 4] = 
    toricCodeCat4Bal24
 
braidedCategory[toricCodeCat4Brd6] ^= toricCodeCat4Brd6
 
fusionCategory[toricCodeCat4Brd6] ^= toricCodeCat4
 
toricCodeCat4Brd6 /: modularCategory[toricCodeCat4Brd6, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
toricCodeCat4Brd6 /: ribbonCategory[toricCodeCat4Brd6, 1] = toricCodeCat4Bal21
 
toricCodeCat4Brd6 /: ribbonCategory[toricCodeCat4Brd6, 2] = toricCodeCat4Bal22
 
toricCodeCat4Brd6 /: ribbonCategory[toricCodeCat4Brd6, 3] = toricCodeCat4Bal23
 
toricCodeCat4Brd6 /: ribbonCategory[toricCodeCat4Brd6, 4] = toricCodeCat4Bal24
 
ring[toricCodeCat4Brd6] ^= toricCode
 
rMatrixFunction[toricCodeCat4Brd6] ^= toricCodeCat4Brd6RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[toricCodeCat4]][braidedCategory[#1]] & )[
    toricCodeCat4Brd6] ^= 6
braidedCategory[toricCodeCat4Brd6RMatrixFunction] ^= toricCodeCat4Brd6
 
fusionCategory[toricCodeCat4Brd6RMatrixFunction] ^= toricCodeCat4
 
rMatrixFunction[toricCodeCat4Brd6RMatrixFunction] ^= 
   toricCodeCat4Brd6RMatrixFunction
 
toricCodeCat4Brd6RMatrixFunction[0, 0, 0] = {{1}}
 
toricCodeCat4Brd6RMatrixFunction[0, 1, 1] = {{1}}
 
toricCodeCat4Brd6RMatrixFunction[0, 2, 2] = {{1}}
 
toricCodeCat4Brd6RMatrixFunction[0, 3, 3] = {{1}}
 
toricCodeCat4Brd6RMatrixFunction[1, 0, 1] = {{1}}
 
toricCodeCat4Brd6RMatrixFunction[1, 1, 0] = {{1}}
 
toricCodeCat4Brd6RMatrixFunction[1, 2, 3] = {{-1}}
 
toricCodeCat4Brd6RMatrixFunction[1, 3, 2] = {{-1}}
 
toricCodeCat4Brd6RMatrixFunction[2, 0, 2] = {{1}}
 
toricCodeCat4Brd6RMatrixFunction[2, 1, 3] = {{1}}
 
toricCodeCat4Brd6RMatrixFunction[2, 2, 0] = {{-1}}
 
toricCodeCat4Brd6RMatrixFunction[2, 3, 1] = {{-1}}
 
toricCodeCat4Brd6RMatrixFunction[3, 0, 3] = {{1}}
 
toricCodeCat4Brd6RMatrixFunction[3, 1, 2] = {{1}}
 
toricCodeCat4Brd6RMatrixFunction[3, 2, 1] = {{1}}
 
toricCodeCat4Brd6RMatrixFunction[3, 3, 0] = {{1}}
balancedCategories[toricCodeCat4Brd7] ^= {toricCodeCat4Bal25, 
    toricCodeCat4Bal26, toricCodeCat4Bal27, toricCodeCat4Bal28}
 
toricCodeCat4Brd7 /: balancedCategory[toricCodeCat4Brd7, 1] = 
    toricCodeCat4Bal25
 
toricCodeCat4Brd7 /: balancedCategory[toricCodeCat4Brd7, 2] = 
    toricCodeCat4Bal26
 
toricCodeCat4Brd7 /: balancedCategory[toricCodeCat4Brd7, 3] = 
    toricCodeCat4Bal27
 
toricCodeCat4Brd7 /: balancedCategory[toricCodeCat4Brd7, 4] = 
    toricCodeCat4Bal28
 
braidedCategory[toricCodeCat4Brd7] ^= toricCodeCat4Brd7
 
fusionCategory[toricCodeCat4Brd7] ^= toricCodeCat4
 
toricCodeCat4Brd7 /: modularCategory[toricCodeCat4Brd7, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
toricCodeCat4Brd7 /: ribbonCategory[toricCodeCat4Brd7, 1] = toricCodeCat4Bal25
 
toricCodeCat4Brd7 /: ribbonCategory[toricCodeCat4Brd7, 2] = toricCodeCat4Bal26
 
toricCodeCat4Brd7 /: ribbonCategory[toricCodeCat4Brd7, 3] = toricCodeCat4Bal27
 
toricCodeCat4Brd7 /: ribbonCategory[toricCodeCat4Brd7, 4] = toricCodeCat4Bal28
 
ring[toricCodeCat4Brd7] ^= toricCode
 
rMatrixFunction[toricCodeCat4Brd7] ^= toricCodeCat4Brd7RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[toricCodeCat4]][braidedCategory[#1]] & )[
    toricCodeCat4Brd7] ^= 7
braidedCategory[toricCodeCat4Brd7RMatrixFunction] ^= toricCodeCat4Brd7
 
fusionCategory[toricCodeCat4Brd7RMatrixFunction] ^= toricCodeCat4
 
rMatrixFunction[toricCodeCat4Brd7RMatrixFunction] ^= 
   toricCodeCat4Brd7RMatrixFunction
 
toricCodeCat4Brd7RMatrixFunction[0, 0, 0] = {{1}}
 
toricCodeCat4Brd7RMatrixFunction[0, 1, 1] = {{1}}
 
toricCodeCat4Brd7RMatrixFunction[0, 2, 2] = {{1}}
 
toricCodeCat4Brd7RMatrixFunction[0, 3, 3] = {{1}}
 
toricCodeCat4Brd7RMatrixFunction[1, 0, 1] = {{1}}
 
toricCodeCat4Brd7RMatrixFunction[1, 1, 0] = {{1}}
 
toricCodeCat4Brd7RMatrixFunction[1, 2, 3] = {{1}}
 
toricCodeCat4Brd7RMatrixFunction[1, 3, 2] = {{1}}
 
toricCodeCat4Brd7RMatrixFunction[2, 0, 2] = {{1}}
 
toricCodeCat4Brd7RMatrixFunction[2, 1, 3] = {{-1}}
 
toricCodeCat4Brd7RMatrixFunction[2, 2, 0] = {{1}}
 
toricCodeCat4Brd7RMatrixFunction[2, 3, 1] = {{-1}}
 
toricCodeCat4Brd7RMatrixFunction[3, 0, 3] = {{1}}
 
toricCodeCat4Brd7RMatrixFunction[3, 1, 2] = {{-1}}
 
toricCodeCat4Brd7RMatrixFunction[3, 2, 1] = {{1}}
 
toricCodeCat4Brd7RMatrixFunction[3, 3, 0] = {{-1}}
balancedCategories[toricCodeCat4Brd8] ^= {toricCodeCat4Bal29, 
    toricCodeCat4Bal30, toricCodeCat4Bal31, toricCodeCat4Bal32}
 
toricCodeCat4Brd8 /: balancedCategory[toricCodeCat4Brd8, 1] = 
    toricCodeCat4Bal29
 
toricCodeCat4Brd8 /: balancedCategory[toricCodeCat4Brd8, 2] = 
    toricCodeCat4Bal30
 
toricCodeCat4Brd8 /: balancedCategory[toricCodeCat4Brd8, 3] = 
    toricCodeCat4Bal31
 
toricCodeCat4Brd8 /: balancedCategory[toricCodeCat4Brd8, 4] = 
    toricCodeCat4Bal32
 
braidedCategory[toricCodeCat4Brd8] ^= toricCodeCat4Brd8
 
fusionCategory[toricCodeCat4Brd8] ^= toricCodeCat4
 
toricCodeCat4Brd8 /: modularCategory[toricCodeCat4Brd8, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
toricCodeCat4Brd8 /: ribbonCategory[toricCodeCat4Brd8, 1] = toricCodeCat4Bal29
 
toricCodeCat4Brd8 /: ribbonCategory[toricCodeCat4Brd8, 2] = toricCodeCat4Bal30
 
toricCodeCat4Brd8 /: ribbonCategory[toricCodeCat4Brd8, 3] = toricCodeCat4Bal31
 
toricCodeCat4Brd8 /: ribbonCategory[toricCodeCat4Brd8, 4] = toricCodeCat4Bal32
 
ring[toricCodeCat4Brd8] ^= toricCode
 
rMatrixFunction[toricCodeCat4Brd8] ^= toricCodeCat4Brd8RMatrixFunction
 
symmetricCategory[toricCodeCat4Brd8] ^= toricCodeCat4Brd8
 
(braidedCategoryIndex[fusionCategory[toricCodeCat4]][braidedCategory[#1]] & )[
    toricCodeCat4Brd8] ^= 8
 
(symmetricCategoryIndex[fusionCategory[toricCodeCat4]][
      symmetricCategory[#1]] & )[toricCodeCat4Brd8] ^= 4
braidedCategory[toricCodeCat4Brd8RMatrixFunction] ^= toricCodeCat4Brd8
 
fusionCategory[toricCodeCat4Brd8RMatrixFunction] ^= toricCodeCat4
 
rMatrixFunction[toricCodeCat4Brd8RMatrixFunction] ^= 
   toricCodeCat4Brd8RMatrixFunction
 
toricCodeCat4Brd8RMatrixFunction[0, 0, 0] = {{1}}
 
toricCodeCat4Brd8RMatrixFunction[0, 1, 1] = {{1}}
 
toricCodeCat4Brd8RMatrixFunction[0, 2, 2] = {{1}}
 
toricCodeCat4Brd8RMatrixFunction[0, 3, 3] = {{1}}
 
toricCodeCat4Brd8RMatrixFunction[1, 0, 1] = {{1}}
 
toricCodeCat4Brd8RMatrixFunction[1, 1, 0] = {{1}}
 
toricCodeCat4Brd8RMatrixFunction[1, 2, 3] = {{-1}}
 
toricCodeCat4Brd8RMatrixFunction[1, 3, 2] = {{-1}}
 
toricCodeCat4Brd8RMatrixFunction[2, 0, 2] = {{1}}
 
toricCodeCat4Brd8RMatrixFunction[2, 1, 3] = {{-1}}
 
toricCodeCat4Brd8RMatrixFunction[2, 2, 0] = {{1}}
 
toricCodeCat4Brd8RMatrixFunction[2, 3, 1] = {{-1}}
 
toricCodeCat4Brd8RMatrixFunction[3, 0, 3] = {{1}}
 
toricCodeCat4Brd8RMatrixFunction[3, 1, 2] = {{-1}}
 
toricCodeCat4Brd8RMatrixFunction[3, 2, 1] = {{-1}}
 
toricCodeCat4Brd8RMatrixFunction[3, 3, 0] = {{1}}
fMatrixFunction[toricCodeCat4FMatrixFunction] ^= toricCodeCat4FMatrixFunction
 
fusionCategory[toricCodeCat4FMatrixFunction] ^= toricCodeCat4
 
ring[toricCodeCat4FMatrixFunction] ^= toricCode
 
toricCodeCat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[toricCodeCat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
toricCodeCat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[toricCodeCat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[toricCodeCat4Piv1] ^= {toricCodeCat4Bal1, 
    toricCodeCat4Bal5, toricCodeCat4Bal9, toricCodeCat4Bal13, 
    toricCodeCat4Bal17, toricCodeCat4Bal21, toricCodeCat4Bal25, 
    toricCodeCat4Bal29}
 
toricCodeCat4Piv1 /: balancedCategory[toricCodeCat4Piv1, 1] = 
    toricCodeCat4Bal1
 
toricCodeCat4Piv1 /: balancedCategory[toricCodeCat4Piv1, 2] = 
    toricCodeCat4Bal5
 
toricCodeCat4Piv1 /: balancedCategory[toricCodeCat4Piv1, 3] = 
    toricCodeCat4Bal9
 
toricCodeCat4Piv1 /: balancedCategory[toricCodeCat4Piv1, 4] = 
    toricCodeCat4Bal13
 
toricCodeCat4Piv1 /: balancedCategory[toricCodeCat4Piv1, 5] = 
    toricCodeCat4Bal17
 
toricCodeCat4Piv1 /: balancedCategory[toricCodeCat4Piv1, 6] = 
    toricCodeCat4Bal21
 
toricCodeCat4Piv1 /: balancedCategory[toricCodeCat4Piv1, 7] = 
    toricCodeCat4Bal25
 
toricCodeCat4Piv1 /: balancedCategory[toricCodeCat4Piv1, 8] = 
    toricCodeCat4Bal29
 
fusionCategory[toricCodeCat4Piv1] ^= toricCodeCat4
 
toricCodeCat4Piv1 /: modularCategory[toricCodeCat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[toricCodeCat4Piv1] ^= toricCodeCat4Piv1
 
pivotalIsomorphism[toricCodeCat4Piv1] ^= toricCodeCat4Piv1PivotalIsomorphism
 
toricCodeCat4Piv1 /: ribbonCategory[toricCodeCat4Piv1, 1] = toricCodeCat4Bal1
 
toricCodeCat4Piv1 /: ribbonCategory[toricCodeCat4Piv1, 2] = toricCodeCat4Bal5
 
toricCodeCat4Piv1 /: ribbonCategory[toricCodeCat4Piv1, 3] = toricCodeCat4Bal9
 
toricCodeCat4Piv1 /: ribbonCategory[toricCodeCat4Piv1, 4] = toricCodeCat4Bal13
 
toricCodeCat4Piv1 /: ribbonCategory[toricCodeCat4Piv1, 5] = toricCodeCat4Bal17
 
toricCodeCat4Piv1 /: ribbonCategory[toricCodeCat4Piv1, 6] = toricCodeCat4Bal21
 
toricCodeCat4Piv1 /: ribbonCategory[toricCodeCat4Piv1, 7] = toricCodeCat4Bal25
 
toricCodeCat4Piv1 /: ribbonCategory[toricCodeCat4Piv1, 8] = toricCodeCat4Bal29
 
ring[toricCodeCat4Piv1] ^= toricCode
 
sphericalCategory[toricCodeCat4Piv1] ^= toricCodeCat4Piv1
 
(pivotalCategoryIndex[fusionCategory[toricCodeCat4]][pivotalCategory[#1]] & )[
    toricCodeCat4Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[toricCodeCat4]][
      sphericalCategory[#1]] & )[toricCodeCat4Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[toricCodeCat4Piv1PivotalIsomorphism] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Piv1PivotalIsomorphism] ^= toricCodeCat4Piv1
 
pivotalIsomorphism[toricCodeCat4Piv1PivotalIsomorphism] ^= 
   toricCodeCat4Piv1PivotalIsomorphism
 
toricCodeCat4Piv1PivotalIsomorphism[0] = 1
 
toricCodeCat4Piv1PivotalIsomorphism[1] = 1
 
toricCodeCat4Piv1PivotalIsomorphism[2] = 1
 
toricCodeCat4Piv1PivotalIsomorphism[3] = 1
balancedCategories[toricCodeCat4Piv2] ^= {toricCodeCat4Bal2, 
    toricCodeCat4Bal6, toricCodeCat4Bal10, toricCodeCat4Bal14, 
    toricCodeCat4Bal18, toricCodeCat4Bal22, toricCodeCat4Bal26, 
    toricCodeCat4Bal30}
 
toricCodeCat4Piv2 /: balancedCategory[toricCodeCat4Piv2, 1] = 
    toricCodeCat4Bal2
 
toricCodeCat4Piv2 /: balancedCategory[toricCodeCat4Piv2, 2] = 
    toricCodeCat4Bal6
 
toricCodeCat4Piv2 /: balancedCategory[toricCodeCat4Piv2, 3] = 
    toricCodeCat4Bal10
 
toricCodeCat4Piv2 /: balancedCategory[toricCodeCat4Piv2, 4] = 
    toricCodeCat4Bal14
 
toricCodeCat4Piv2 /: balancedCategory[toricCodeCat4Piv2, 5] = 
    toricCodeCat4Bal18
 
toricCodeCat4Piv2 /: balancedCategory[toricCodeCat4Piv2, 6] = 
    toricCodeCat4Bal22
 
toricCodeCat4Piv2 /: balancedCategory[toricCodeCat4Piv2, 7] = 
    toricCodeCat4Bal26
 
toricCodeCat4Piv2 /: balancedCategory[toricCodeCat4Piv2, 8] = 
    toricCodeCat4Bal30
 
fusionCategory[toricCodeCat4Piv2] ^= toricCodeCat4
 
toricCodeCat4Piv2 /: modularCategory[toricCodeCat4Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[toricCodeCat4Piv2] ^= toricCodeCat4Piv2
 
pivotalIsomorphism[toricCodeCat4Piv2] ^= toricCodeCat4Piv2PivotalIsomorphism
 
toricCodeCat4Piv2 /: ribbonCategory[toricCodeCat4Piv2, 1] = toricCodeCat4Bal2
 
toricCodeCat4Piv2 /: ribbonCategory[toricCodeCat4Piv2, 2] = toricCodeCat4Bal6
 
toricCodeCat4Piv2 /: ribbonCategory[toricCodeCat4Piv2, 3] = toricCodeCat4Bal10
 
toricCodeCat4Piv2 /: ribbonCategory[toricCodeCat4Piv2, 4] = toricCodeCat4Bal14
 
toricCodeCat4Piv2 /: ribbonCategory[toricCodeCat4Piv2, 5] = toricCodeCat4Bal18
 
toricCodeCat4Piv2 /: ribbonCategory[toricCodeCat4Piv2, 6] = toricCodeCat4Bal22
 
toricCodeCat4Piv2 /: ribbonCategory[toricCodeCat4Piv2, 7] = toricCodeCat4Bal26
 
toricCodeCat4Piv2 /: ribbonCategory[toricCodeCat4Piv2, 8] = toricCodeCat4Bal30
 
ring[toricCodeCat4Piv2] ^= toricCode
 
sphericalCategory[toricCodeCat4Piv2] ^= toricCodeCat4Piv2
 
(pivotalCategoryIndex[fusionCategory[toricCodeCat4]][pivotalCategory[#1]] & )[
    toricCodeCat4Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[toricCodeCat4]][
      sphericalCategory[#1]] & )[toricCodeCat4Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[toricCodeCat4Piv2PivotalIsomorphism] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Piv2PivotalIsomorphism] ^= toricCodeCat4Piv2
 
pivotalIsomorphism[toricCodeCat4Piv2PivotalIsomorphism] ^= 
   toricCodeCat4Piv2PivotalIsomorphism
 
toricCodeCat4Piv2PivotalIsomorphism[0] = 1
 
toricCodeCat4Piv2PivotalIsomorphism[1] = -1
 
toricCodeCat4Piv2PivotalIsomorphism[2] = -1
 
toricCodeCat4Piv2PivotalIsomorphism[3] = 1
balancedCategories[toricCodeCat4Piv3] ^= {toricCodeCat4Bal3, 
    toricCodeCat4Bal7, toricCodeCat4Bal11, toricCodeCat4Bal15, 
    toricCodeCat4Bal19, toricCodeCat4Bal23, toricCodeCat4Bal27, 
    toricCodeCat4Bal31}
 
toricCodeCat4Piv3 /: balancedCategory[toricCodeCat4Piv3, 1] = 
    toricCodeCat4Bal3
 
toricCodeCat4Piv3 /: balancedCategory[toricCodeCat4Piv3, 2] = 
    toricCodeCat4Bal7
 
toricCodeCat4Piv3 /: balancedCategory[toricCodeCat4Piv3, 3] = 
    toricCodeCat4Bal11
 
toricCodeCat4Piv3 /: balancedCategory[toricCodeCat4Piv3, 4] = 
    toricCodeCat4Bal15
 
toricCodeCat4Piv3 /: balancedCategory[toricCodeCat4Piv3, 5] = 
    toricCodeCat4Bal19
 
toricCodeCat4Piv3 /: balancedCategory[toricCodeCat4Piv3, 6] = 
    toricCodeCat4Bal23
 
toricCodeCat4Piv3 /: balancedCategory[toricCodeCat4Piv3, 7] = 
    toricCodeCat4Bal27
 
toricCodeCat4Piv3 /: balancedCategory[toricCodeCat4Piv3, 8] = 
    toricCodeCat4Bal31
 
fusionCategory[toricCodeCat4Piv3] ^= toricCodeCat4
 
toricCodeCat4Piv3 /: modularCategory[toricCodeCat4Piv3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[toricCodeCat4Piv3] ^= toricCodeCat4Piv3
 
pivotalIsomorphism[toricCodeCat4Piv3] ^= toricCodeCat4Piv3PivotalIsomorphism
 
toricCodeCat4Piv3 /: ribbonCategory[toricCodeCat4Piv3, 1] = toricCodeCat4Bal3
 
toricCodeCat4Piv3 /: ribbonCategory[toricCodeCat4Piv3, 2] = toricCodeCat4Bal7
 
toricCodeCat4Piv3 /: ribbonCategory[toricCodeCat4Piv3, 3] = toricCodeCat4Bal11
 
toricCodeCat4Piv3 /: ribbonCategory[toricCodeCat4Piv3, 4] = toricCodeCat4Bal15
 
toricCodeCat4Piv3 /: ribbonCategory[toricCodeCat4Piv3, 5] = toricCodeCat4Bal19
 
toricCodeCat4Piv3 /: ribbonCategory[toricCodeCat4Piv3, 6] = toricCodeCat4Bal23
 
toricCodeCat4Piv3 /: ribbonCategory[toricCodeCat4Piv3, 7] = toricCodeCat4Bal27
 
toricCodeCat4Piv3 /: ribbonCategory[toricCodeCat4Piv3, 8] = toricCodeCat4Bal31
 
ring[toricCodeCat4Piv3] ^= toricCode
 
sphericalCategory[toricCodeCat4Piv3] ^= toricCodeCat4Piv3
 
(pivotalCategoryIndex[fusionCategory[toricCodeCat4]][pivotalCategory[#1]] & )[
    toricCodeCat4Piv3] ^= 3
 
(sphericalCategoryIndex[fusionCategory[toricCodeCat4]][
      sphericalCategory[#1]] & )[toricCodeCat4Piv3] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[toricCodeCat4Piv3PivotalIsomorphism] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Piv3PivotalIsomorphism] ^= toricCodeCat4Piv3
 
pivotalIsomorphism[toricCodeCat4Piv3PivotalIsomorphism] ^= 
   toricCodeCat4Piv3PivotalIsomorphism
 
toricCodeCat4Piv3PivotalIsomorphism[0] = 1
 
toricCodeCat4Piv3PivotalIsomorphism[1] = 1
 
toricCodeCat4Piv3PivotalIsomorphism[2] = -1
 
toricCodeCat4Piv3PivotalIsomorphism[3] = -1
balancedCategories[toricCodeCat4Piv4] ^= {toricCodeCat4Bal4, 
    toricCodeCat4Bal8, toricCodeCat4Bal12, toricCodeCat4Bal16, 
    toricCodeCat4Bal20, toricCodeCat4Bal24, toricCodeCat4Bal28, 
    toricCodeCat4Bal32}
 
toricCodeCat4Piv4 /: balancedCategory[toricCodeCat4Piv4, 1] = 
    toricCodeCat4Bal4
 
toricCodeCat4Piv4 /: balancedCategory[toricCodeCat4Piv4, 2] = 
    toricCodeCat4Bal8
 
toricCodeCat4Piv4 /: balancedCategory[toricCodeCat4Piv4, 3] = 
    toricCodeCat4Bal12
 
toricCodeCat4Piv4 /: balancedCategory[toricCodeCat4Piv4, 4] = 
    toricCodeCat4Bal16
 
toricCodeCat4Piv4 /: balancedCategory[toricCodeCat4Piv4, 5] = 
    toricCodeCat4Bal20
 
toricCodeCat4Piv4 /: balancedCategory[toricCodeCat4Piv4, 6] = 
    toricCodeCat4Bal24
 
toricCodeCat4Piv4 /: balancedCategory[toricCodeCat4Piv4, 7] = 
    toricCodeCat4Bal28
 
toricCodeCat4Piv4 /: balancedCategory[toricCodeCat4Piv4, 8] = 
    toricCodeCat4Bal32
 
fusionCategory[toricCodeCat4Piv4] ^= toricCodeCat4
 
toricCodeCat4Piv4 /: modularCategory[toricCodeCat4Piv4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[toricCodeCat4Piv4] ^= toricCodeCat4Piv4
 
pivotalIsomorphism[toricCodeCat4Piv4] ^= toricCodeCat4Piv4PivotalIsomorphism
 
toricCodeCat4Piv4 /: ribbonCategory[toricCodeCat4Piv4, 1] = toricCodeCat4Bal4
 
toricCodeCat4Piv4 /: ribbonCategory[toricCodeCat4Piv4, 2] = toricCodeCat4Bal8
 
toricCodeCat4Piv4 /: ribbonCategory[toricCodeCat4Piv4, 3] = toricCodeCat4Bal12
 
toricCodeCat4Piv4 /: ribbonCategory[toricCodeCat4Piv4, 4] = toricCodeCat4Bal16
 
toricCodeCat4Piv4 /: ribbonCategory[toricCodeCat4Piv4, 5] = toricCodeCat4Bal20
 
toricCodeCat4Piv4 /: ribbonCategory[toricCodeCat4Piv4, 6] = toricCodeCat4Bal24
 
toricCodeCat4Piv4 /: ribbonCategory[toricCodeCat4Piv4, 7] = toricCodeCat4Bal28
 
toricCodeCat4Piv4 /: ribbonCategory[toricCodeCat4Piv4, 8] = toricCodeCat4Bal32
 
ring[toricCodeCat4Piv4] ^= toricCode
 
sphericalCategory[toricCodeCat4Piv4] ^= toricCodeCat4Piv4
 
(pivotalCategoryIndex[fusionCategory[toricCodeCat4]][pivotalCategory[#1]] & )[
    toricCodeCat4Piv4] ^= 4
 
(sphericalCategoryIndex[fusionCategory[toricCodeCat4]][
      sphericalCategory[#1]] & )[toricCodeCat4Piv4] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[toricCodeCat4Piv4PivotalIsomorphism] ^= toricCodeCat4
 
pivotalCategory[toricCodeCat4Piv4PivotalIsomorphism] ^= toricCodeCat4Piv4
 
pivotalIsomorphism[toricCodeCat4Piv4PivotalIsomorphism] ^= 
   toricCodeCat4Piv4PivotalIsomorphism
 
toricCodeCat4Piv4PivotalIsomorphism[0] = 1
 
toricCodeCat4Piv4PivotalIsomorphism[1] = -1
 
toricCodeCat4Piv4PivotalIsomorphism[2] = 1
 
toricCodeCat4Piv4PivotalIsomorphism[3] = -1
ring[toricCodeNFunction] ^= toricCode
 
toricCodeNFunction[0, 0, 0] = 1
 
toricCodeNFunction[0, 0, 1] = 0
 
toricCodeNFunction[0, 0, 2] = 0
 
toricCodeNFunction[0, 0, 3] = 0
 
toricCodeNFunction[0, 1, 0] = 0
 
toricCodeNFunction[0, 1, 1] = 1
 
toricCodeNFunction[0, 1, 2] = 0
 
toricCodeNFunction[0, 1, 3] = 0
 
toricCodeNFunction[0, 2, 0] = 0
 
toricCodeNFunction[0, 2, 1] = 0
 
toricCodeNFunction[0, 2, 2] = 1
 
toricCodeNFunction[0, 2, 3] = 0
 
toricCodeNFunction[0, 3, 0] = 0
 
toricCodeNFunction[0, 3, 1] = 0
 
toricCodeNFunction[0, 3, 2] = 0
 
toricCodeNFunction[0, 3, 3] = 1
 
toricCodeNFunction[1, 0, 0] = 0
 
toricCodeNFunction[1, 0, 1] = 1
 
toricCodeNFunction[1, 0, 2] = 0
 
toricCodeNFunction[1, 0, 3] = 0
 
toricCodeNFunction[1, 1, 0] = 1
 
toricCodeNFunction[1, 1, 1] = 0
 
toricCodeNFunction[1, 1, 2] = 0
 
toricCodeNFunction[1, 1, 3] = 0
 
toricCodeNFunction[1, 2, 0] = 0
 
toricCodeNFunction[1, 2, 1] = 0
 
toricCodeNFunction[1, 2, 2] = 0
 
toricCodeNFunction[1, 2, 3] = 1
 
toricCodeNFunction[1, 3, 0] = 0
 
toricCodeNFunction[1, 3, 1] = 0
 
toricCodeNFunction[1, 3, 2] = 1
 
toricCodeNFunction[1, 3, 3] = 0
 
toricCodeNFunction[2, 0, 0] = 0
 
toricCodeNFunction[2, 0, 1] = 0
 
toricCodeNFunction[2, 0, 2] = 1
 
toricCodeNFunction[2, 0, 3] = 0
 
toricCodeNFunction[2, 1, 0] = 0
 
toricCodeNFunction[2, 1, 1] = 0
 
toricCodeNFunction[2, 1, 2] = 0
 
toricCodeNFunction[2, 1, 3] = 1
 
toricCodeNFunction[2, 2, 0] = 1
 
toricCodeNFunction[2, 2, 1] = 0
 
toricCodeNFunction[2, 2, 2] = 0
 
toricCodeNFunction[2, 2, 3] = 0
 
toricCodeNFunction[2, 3, 0] = 0
 
toricCodeNFunction[2, 3, 1] = 1
 
toricCodeNFunction[2, 3, 2] = 0
 
toricCodeNFunction[2, 3, 3] = 0
 
toricCodeNFunction[3, 0, 0] = 0
 
toricCodeNFunction[3, 0, 1] = 0
 
toricCodeNFunction[3, 0, 2] = 0
 
toricCodeNFunction[3, 0, 3] = 1
 
toricCodeNFunction[3, 1, 0] = 0
 
toricCodeNFunction[3, 1, 1] = 0
 
toricCodeNFunction[3, 1, 2] = 1
 
toricCodeNFunction[3, 1, 3] = 0
 
toricCodeNFunction[3, 2, 0] = 0
 
toricCodeNFunction[3, 2, 1] = 1
 
toricCodeNFunction[3, 2, 2] = 0
 
toricCodeNFunction[3, 2, 3] = 0
 
toricCodeNFunction[3, 3, 0] = 1
 
toricCodeNFunction[3, 3, 1] = 0
 
toricCodeNFunction[3, 3, 2] = 0
 
toricCodeNFunction[3, 3, 3] = 0
 
toricCodeNFunction[FusionCategories`Data`toricCode`Private`a_, FusionCategories`Data`toricCode`Private`b_, FusionCategories`Data`toricCode`Private`c_] := 0


 EndPackage[]
