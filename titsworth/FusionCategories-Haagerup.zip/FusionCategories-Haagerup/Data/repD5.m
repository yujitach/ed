BeginPackage["FusionCategories`Data`repD5`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[repD5] ^= {repD5Cat1, repD5Cat2, repD5Cat3}
 
repD5 /: fusionCategory[repD5, 1] = repD5Cat1
 
repD5 /: fusionCategory[repD5, 2] = repD5Cat2
 
repD5 /: fusionCategory[repD5, 3] = repD5Cat3
 
nFunction[repD5] ^= repD5NFunction
 
noMultiplicities[repD5] ^= True
 
rank[repD5] ^= 4
 
ring[repD5] ^= repD5
balancedCategories[repD5Cat1] ^= {repD5Cat1Bal1, repD5Cat1Bal2, 
    repD5Cat1Bal3, repD5Cat1Bal4, repD5Cat1Bal5}
 
repD5Cat1 /: balancedCategory[repD5Cat1, 1] = repD5Cat1Bal1
 
repD5Cat1 /: balancedCategory[repD5Cat1, 2] = repD5Cat1Bal2
 
repD5Cat1 /: balancedCategory[repD5Cat1, 3] = repD5Cat1Bal3
 
repD5Cat1 /: balancedCategory[repD5Cat1, 4] = repD5Cat1Bal4
 
repD5Cat1 /: balancedCategory[repD5Cat1, 5] = repD5Cat1Bal5
 
braidedCategories[repD5Cat1] ^= {repD5Cat1Brd1, repD5Cat1Brd2, repD5Cat1Brd3, 
    repD5Cat1Brd4, repD5Cat1Brd5}
 
repD5Cat1 /: braidedCategory[repD5Cat1, 1] = repD5Cat1Brd1
 
repD5Cat1 /: braidedCategory[repD5Cat1, 2] = repD5Cat1Brd2
 
repD5Cat1 /: braidedCategory[repD5Cat1, 3] = repD5Cat1Brd3
 
repD5Cat1 /: braidedCategory[repD5Cat1, 4] = repD5Cat1Brd4
 
repD5Cat1 /: braidedCategory[repD5Cat1, 5] = repD5Cat1Brd5
 
coeval[repD5Cat1] ^= 1/sixJFunction[repD5Cat1][#1, dual[ring[repD5Cat1]][#1], 
      #1, #1, 0, 0] & 
 
eval[repD5Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[repD5Cat1] ^= repD5Cat1FMatrixFunction
 
fusionCategory[repD5Cat1] ^= repD5Cat1
 
repD5Cat1 /: modularCategory[repD5Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[repD5Cat1] ^= {repD5Cat1Piv1}
 
repD5Cat1 /: pivotalCategory[repD5Cat1, 1] = repD5Cat1Piv1
 
repD5Cat1 /: pivotalCategory[repD5Cat1, {1, 1, 1, 1}] = repD5Cat1Piv1
 
repD5Cat1 /: ribbonCategory[repD5Cat1, 1] = repD5Cat1Bal1
 
repD5Cat1 /: ribbonCategory[repD5Cat1, 2] = repD5Cat1Bal2
 
repD5Cat1 /: ribbonCategory[repD5Cat1, 3] = repD5Cat1Bal3
 
repD5Cat1 /: ribbonCategory[repD5Cat1, 4] = repD5Cat1Bal4
 
repD5Cat1 /: ribbonCategory[repD5Cat1, 5] = repD5Cat1Bal5
 
ring[repD5Cat1] ^= repD5
 
repD5Cat1 /: sphericalCategory[repD5Cat1, 1] = repD5Cat1Piv1
 
repD5Cat1 /: symmetricCategory[repD5Cat1, 1] = repD5Cat1Brd1
 
fusionCategoryIndex[repD5][repD5Cat1] ^= 1
balancedCategory[repD5Cat1Bal1] ^= repD5Cat1Bal1
 
braidedCategory[repD5Cat1Bal1] ^= repD5Cat1Brd1
 
fusionCategory[repD5Cat1Bal1] ^= repD5Cat1
 
pivotalCategory[repD5Cat1Bal1] ^= repD5Cat1Piv1
 
ribbonCategory[repD5Cat1Bal1] ^= repD5Cat1Bal1
 
ring[repD5Cat1Bal1] ^= repD5
 
sphericalCategory[repD5Cat1Bal1] ^= repD5Cat1Piv1
 
symmetricCategory[repD5Cat1Bal1] ^= repD5Cat1Brd1
 
(balancedCategoryIndex[braidedCategory[repD5Cat1Brd1]][
      balancedCategory[#1]] & )[repD5Cat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD5Cat1]][balancedCategory[#1]] & )[
    repD5Cat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[repD5Cat1Piv1]][
      balancedCategory[#1]] & )[repD5Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[repD5Cat1Brd1]][ribbonCategory[#1]] & )[
    repD5Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD5Cat1]][ribbonCategory[#1]] & )[
    repD5Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[repD5Cat1Piv1]][
      ribbonCategory[#1]] & )[repD5Cat1Bal1] ^= 1
balancedCategory[repD5Cat1Bal2] ^= repD5Cat1Bal2
 
braidedCategory[repD5Cat1Bal2] ^= repD5Cat1Brd2
 
fusionCategory[repD5Cat1Bal2] ^= repD5Cat1
 
pivotalCategory[repD5Cat1Bal2] ^= repD5Cat1Piv1
 
ribbonCategory[repD5Cat1Bal2] ^= repD5Cat1Bal2
 
ring[repD5Cat1Bal2] ^= repD5
 
sphericalCategory[repD5Cat1Bal2] ^= repD5Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[repD5Cat1Brd2]][
      balancedCategory[#1]] & )[repD5Cat1Bal2] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD5Cat1]][balancedCategory[#1]] & )[
    repD5Cat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[repD5Cat1Piv1]][
      balancedCategory[#1]] & )[repD5Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[braidedCategory[repD5Cat1Brd2]][ribbonCategory[#1]] & )[
    repD5Cat1Bal2] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD5Cat1]][ribbonCategory[#1]] & )[
    repD5Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[repD5Cat1Piv1]][
      ribbonCategory[#1]] & )[repD5Cat1Bal2] ^= 2
balancedCategory[repD5Cat1Bal3] ^= repD5Cat1Bal3
 
braidedCategory[repD5Cat1Bal3] ^= repD5Cat1Brd3
 
fusionCategory[repD5Cat1Bal3] ^= repD5Cat1
 
pivotalCategory[repD5Cat1Bal3] ^= repD5Cat1Piv1
 
ribbonCategory[repD5Cat1Bal3] ^= repD5Cat1Bal3
 
ring[repD5Cat1Bal3] ^= repD5
 
sphericalCategory[repD5Cat1Bal3] ^= repD5Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[repD5Cat1Brd3]][
      balancedCategory[#1]] & )[repD5Cat1Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD5Cat1]][balancedCategory[#1]] & )[
    repD5Cat1Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[repD5Cat1Piv1]][
      balancedCategory[#1]] & )[repD5Cat1Bal3] ^= 3
 
(ribbonCategoryIndex[braidedCategory[repD5Cat1Brd3]][ribbonCategory[#1]] & )[
    repD5Cat1Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD5Cat1]][ribbonCategory[#1]] & )[
    repD5Cat1Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[repD5Cat1Piv1]][
      ribbonCategory[#1]] & )[repD5Cat1Bal3] ^= 3
balancedCategory[repD5Cat1Bal4] ^= repD5Cat1Bal4
 
braidedCategory[repD5Cat1Bal4] ^= repD5Cat1Brd4
 
fusionCategory[repD5Cat1Bal4] ^= repD5Cat1
 
pivotalCategory[repD5Cat1Bal4] ^= repD5Cat1Piv1
 
ribbonCategory[repD5Cat1Bal4] ^= repD5Cat1Bal4
 
ring[repD5Cat1Bal4] ^= repD5
 
sphericalCategory[repD5Cat1Bal4] ^= repD5Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[repD5Cat1Brd4]][
      balancedCategory[#1]] & )[repD5Cat1Bal4] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD5Cat1]][balancedCategory[#1]] & )[
    repD5Cat1Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[repD5Cat1Piv1]][
      balancedCategory[#1]] & )[repD5Cat1Bal4] ^= 4
 
(ribbonCategoryIndex[braidedCategory[repD5Cat1Brd4]][ribbonCategory[#1]] & )[
    repD5Cat1Bal4] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD5Cat1]][ribbonCategory[#1]] & )[
    repD5Cat1Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[repD5Cat1Piv1]][
      ribbonCategory[#1]] & )[repD5Cat1Bal4] ^= 4
balancedCategory[repD5Cat1Bal5] ^= repD5Cat1Bal5
 
braidedCategory[repD5Cat1Bal5] ^= repD5Cat1Brd5
 
fusionCategory[repD5Cat1Bal5] ^= repD5Cat1
 
pivotalCategory[repD5Cat1Bal5] ^= repD5Cat1Piv1
 
ribbonCategory[repD5Cat1Bal5] ^= repD5Cat1Bal5
 
ring[repD5Cat1Bal5] ^= repD5
 
sphericalCategory[repD5Cat1Bal5] ^= repD5Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[repD5Cat1Brd5]][
      balancedCategory[#1]] & )[repD5Cat1Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD5Cat1]][balancedCategory[#1]] & )[
    repD5Cat1Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[repD5Cat1Piv1]][
      balancedCategory[#1]] & )[repD5Cat1Bal5] ^= 5
 
(ribbonCategoryIndex[braidedCategory[repD5Cat1Brd5]][ribbonCategory[#1]] & )[
    repD5Cat1Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD5Cat1]][ribbonCategory[#1]] & )[
    repD5Cat1Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[repD5Cat1Piv1]][
      ribbonCategory[#1]] & )[repD5Cat1Bal5] ^= 5
balancedCategories[repD5Cat1Brd1] ^= {repD5Cat1Bal1}
 
repD5Cat1Brd1 /: balancedCategory[repD5Cat1Brd1, 1] = repD5Cat1Bal1
 
braidedCategory[repD5Cat1Brd1] ^= repD5Cat1Brd1
 
fusionCategory[repD5Cat1Brd1] ^= repD5Cat1
 
repD5Cat1Brd1 /: modularCategory[repD5Cat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD5Cat1Brd1 /: ribbonCategory[repD5Cat1Brd1, 1] = repD5Cat1Bal1
 
ring[repD5Cat1Brd1] ^= repD5
 
rMatrixFunction[repD5Cat1Brd1] ^= repD5Cat1Brd1RMatrixFunction
 
symmetricCategory[repD5Cat1Brd1] ^= repD5Cat1Brd1
 
(braidedCategoryIndex[fusionCategory[repD5Cat1]][braidedCategory[#1]] & )[
    repD5Cat1Brd1] ^= 1
 
(symmetricCategoryIndex[fusionCategory[repD5Cat1]][symmetricCategory[#1]] & )[
    repD5Cat1Brd1] ^= 1
braidedCategory[repD5Cat1Brd1RMatrixFunction] ^= repD5Cat1Brd1
 
fusionCategory[repD5Cat1Brd1RMatrixFunction] ^= repD5Cat1
 
rMatrixFunction[repD5Cat1Brd1RMatrixFunction] ^= repD5Cat1Brd1RMatrixFunction
 
repD5Cat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[1, 1, 0] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[1, 2, 2] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[1, 3, 3] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[2, 1, 2] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[2, 2, 0] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[2, 2, 1] = {{-1}}
 
repD5Cat1Brd1RMatrixFunction[2, 2, 3] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[2, 3, 2] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[2, 3, 3] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[3, 1, 3] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[3, 2, 2] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[3, 2, 3] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[3, 3, 0] = {{1}}
 
repD5Cat1Brd1RMatrixFunction[3, 3, 1] = {{-1}}
 
repD5Cat1Brd1RMatrixFunction[3, 3, 2] = {{1}}
balancedCategories[repD5Cat1Brd2] ^= {repD5Cat1Bal2}
 
repD5Cat1Brd2 /: balancedCategory[repD5Cat1Brd2, 1] = repD5Cat1Bal2
 
braidedCategory[repD5Cat1Brd2] ^= repD5Cat1Brd2
 
fusionCategory[repD5Cat1Brd2] ^= repD5Cat1
 
repD5Cat1Brd2 /: modularCategory[repD5Cat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD5Cat1Brd2 /: ribbonCategory[repD5Cat1Brd2, 1] = repD5Cat1Bal2
 
ring[repD5Cat1Brd2] ^= repD5
 
rMatrixFunction[repD5Cat1Brd2] ^= repD5Cat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD5Cat1]][braidedCategory[#1]] & )[
    repD5Cat1Brd2] ^= 2
braidedCategory[repD5Cat1Brd2RMatrixFunction] ^= repD5Cat1Brd2
 
fusionCategory[repD5Cat1Brd2RMatrixFunction] ^= repD5Cat1
 
rMatrixFunction[repD5Cat1Brd2RMatrixFunction] ^= repD5Cat1Brd2RMatrixFunction
 
repD5Cat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
repD5Cat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
repD5Cat1Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
repD5Cat1Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
repD5Cat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
repD5Cat1Brd2RMatrixFunction[1, 1, 0] = {{1}}
 
repD5Cat1Brd2RMatrixFunction[1, 2, 2] = {{1}}
 
repD5Cat1Brd2RMatrixFunction[1, 3, 3] = {{1}}
 
repD5Cat1Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
repD5Cat1Brd2RMatrixFunction[2, 1, 2] = {{1}}
 
repD5Cat1Brd2RMatrixFunction[2, 2, 0] = {{-(-1)^(3/5)}}
 
repD5Cat1Brd2RMatrixFunction[2, 2, 1] = {{(-1)^(3/5)}}
 
repD5Cat1Brd2RMatrixFunction[2, 2, 3] = {{(-1)^(2/5)}}
 
repD5Cat1Brd2RMatrixFunction[2, 3, 2] = {{-(-1)^(1/5)}}
 
repD5Cat1Brd2RMatrixFunction[2, 3, 3] = {{(-1)^(4/5)}}
 
repD5Cat1Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
repD5Cat1Brd2RMatrixFunction[3, 1, 3] = {{1}}
 
repD5Cat1Brd2RMatrixFunction[3, 2, 2] = {{-(-1)^(1/5)}}
 
repD5Cat1Brd2RMatrixFunction[3, 2, 3] = {{(-1)^(4/5)}}
 
repD5Cat1Brd2RMatrixFunction[3, 3, 0] = 
   {{-(1 - (-1)^(1/5) + (-1)^(2/5) + (-1)^(4/5))^(-1)}}
 
repD5Cat1Brd2RMatrixFunction[3, 3, 1] = 
   {{(1 - (-1)^(1/5) + (-1)^(2/5) + (-1)^(4/5))^(-1)}}
 
repD5Cat1Brd2RMatrixFunction[3, 3, 2] = 
   {{-1 + (-1)^(1/5) - (-1)^(2/5) - (-1)^(4/5)}}
balancedCategories[repD5Cat1Brd3] ^= {repD5Cat1Bal3}
 
repD5Cat1Brd3 /: balancedCategory[repD5Cat1Brd3, 1] = repD5Cat1Bal3
 
braidedCategory[repD5Cat1Brd3] ^= repD5Cat1Brd3
 
fusionCategory[repD5Cat1Brd3] ^= repD5Cat1
 
repD5Cat1Brd3 /: modularCategory[repD5Cat1Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD5Cat1Brd3 /: ribbonCategory[repD5Cat1Brd3, 1] = repD5Cat1Bal3
 
ring[repD5Cat1Brd3] ^= repD5
 
rMatrixFunction[repD5Cat1Brd3] ^= repD5Cat1Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD5Cat1]][braidedCategory[#1]] & )[
    repD5Cat1Brd3] ^= 3
braidedCategory[repD5Cat1Brd3RMatrixFunction] ^= repD5Cat1Brd3
 
fusionCategory[repD5Cat1Brd3RMatrixFunction] ^= repD5Cat1
 
rMatrixFunction[repD5Cat1Brd3RMatrixFunction] ^= repD5Cat1Brd3RMatrixFunction
 
repD5Cat1Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
repD5Cat1Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
repD5Cat1Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
repD5Cat1Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
repD5Cat1Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
repD5Cat1Brd3RMatrixFunction[1, 1, 0] = {{1}}
 
repD5Cat1Brd3RMatrixFunction[1, 2, 2] = {{1}}
 
repD5Cat1Brd3RMatrixFunction[1, 3, 3] = {{1}}
 
repD5Cat1Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
repD5Cat1Brd3RMatrixFunction[2, 1, 2] = {{1}}
 
repD5Cat1Brd3RMatrixFunction[2, 2, 0] = {{-(-1)^(1/5)}}
 
repD5Cat1Brd3RMatrixFunction[2, 2, 1] = {{(-1)^(1/5)}}
 
repD5Cat1Brd3RMatrixFunction[2, 2, 3] = {{(-1)^(4/5)}}
 
repD5Cat1Brd3RMatrixFunction[2, 3, 2] = {{(-1)^(2/5)}}
 
repD5Cat1Brd3RMatrixFunction[2, 3, 3] = {{-(-1)^(3/5)}}
 
repD5Cat1Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
repD5Cat1Brd3RMatrixFunction[3, 1, 3] = {{1}}
 
repD5Cat1Brd3RMatrixFunction[3, 2, 2] = {{(-1)^(2/5)}}
 
repD5Cat1Brd3RMatrixFunction[3, 2, 3] = {{-(-1)^(3/5)}}
 
repD5Cat1Brd3RMatrixFunction[3, 3, 0] = 
   {{-(1 + (-1)^(2/5) - (-1)^(3/5) + (-1)^(4/5))^(-1)}}
 
repD5Cat1Brd3RMatrixFunction[3, 3, 1] = 
   {{(1 + (-1)^(2/5) - (-1)^(3/5) + (-1)^(4/5))^(-1)}}
 
repD5Cat1Brd3RMatrixFunction[3, 3, 2] = 
   {{-1 - (-1)^(2/5) + (-1)^(3/5) - (-1)^(4/5)}}
balancedCategories[repD5Cat1Brd4] ^= {repD5Cat1Bal4}
 
repD5Cat1Brd4 /: balancedCategory[repD5Cat1Brd4, 1] = repD5Cat1Bal4
 
braidedCategory[repD5Cat1Brd4] ^= repD5Cat1Brd4
 
fusionCategory[repD5Cat1Brd4] ^= repD5Cat1
 
repD5Cat1Brd4 /: modularCategory[repD5Cat1Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD5Cat1Brd4 /: ribbonCategory[repD5Cat1Brd4, 1] = repD5Cat1Bal4
 
ring[repD5Cat1Brd4] ^= repD5
 
rMatrixFunction[repD5Cat1Brd4] ^= repD5Cat1Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD5Cat1]][braidedCategory[#1]] & )[
    repD5Cat1Brd4] ^= 4
braidedCategory[repD5Cat1Brd4RMatrixFunction] ^= repD5Cat1Brd4
 
fusionCategory[repD5Cat1Brd4RMatrixFunction] ^= repD5Cat1
 
rMatrixFunction[repD5Cat1Brd4RMatrixFunction] ^= repD5Cat1Brd4RMatrixFunction
 
repD5Cat1Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
repD5Cat1Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
repD5Cat1Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
repD5Cat1Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
repD5Cat1Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
repD5Cat1Brd4RMatrixFunction[1, 1, 0] = {{1}}
 
repD5Cat1Brd4RMatrixFunction[1, 2, 2] = {{1}}
 
repD5Cat1Brd4RMatrixFunction[1, 3, 3] = {{1}}
 
repD5Cat1Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
repD5Cat1Brd4RMatrixFunction[2, 1, 2] = {{1}}
 
repD5Cat1Brd4RMatrixFunction[2, 2, 0] = {{(-1)^(4/5)}}
 
repD5Cat1Brd4RMatrixFunction[2, 2, 1] = {{-(-1)^(4/5)}}
 
repD5Cat1Brd4RMatrixFunction[2, 2, 3] = {{-(-1)^(1/5)}}
 
repD5Cat1Brd4RMatrixFunction[2, 3, 2] = {{-(-1)^(3/5)}}
 
repD5Cat1Brd4RMatrixFunction[2, 3, 3] = {{(-1)^(2/5)}}
 
repD5Cat1Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
repD5Cat1Brd4RMatrixFunction[3, 1, 3] = {{1}}
 
repD5Cat1Brd4RMatrixFunction[3, 2, 2] = {{-(-1)^(3/5)}}
 
repD5Cat1Brd4RMatrixFunction[3, 2, 3] = {{(-1)^(2/5)}}
 
repD5Cat1Brd4RMatrixFunction[3, 3, 0] = 
   {{(-1 + (-1)^(1/5) - (-1)^(2/5) + (-1)^(3/5))^(-1)}}
 
repD5Cat1Brd4RMatrixFunction[3, 3, 1] = 
   {{(1 - (-1)^(1/5) + (-1)^(2/5) - (-1)^(3/5))^(-1)}}
 
repD5Cat1Brd4RMatrixFunction[3, 3, 2] = 
   {{-1 + (-1)^(1/5) - (-1)^(2/5) + (-1)^(3/5)}}
balancedCategories[repD5Cat1Brd5] ^= {repD5Cat1Bal5}
 
repD5Cat1Brd5 /: balancedCategory[repD5Cat1Brd5, 1] = repD5Cat1Bal5
 
braidedCategory[repD5Cat1Brd5] ^= repD5Cat1Brd5
 
fusionCategory[repD5Cat1Brd5] ^= repD5Cat1
 
repD5Cat1Brd5 /: modularCategory[repD5Cat1Brd5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD5Cat1Brd5 /: ribbonCategory[repD5Cat1Brd5, 1] = repD5Cat1Bal5
 
ring[repD5Cat1Brd5] ^= repD5
 
rMatrixFunction[repD5Cat1Brd5] ^= repD5Cat1Brd5RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD5Cat1]][braidedCategory[#1]] & )[
    repD5Cat1Brd5] ^= 5
braidedCategory[repD5Cat1Brd5RMatrixFunction] ^= repD5Cat1Brd5
 
fusionCategory[repD5Cat1Brd5RMatrixFunction] ^= repD5Cat1
 
rMatrixFunction[repD5Cat1Brd5RMatrixFunction] ^= repD5Cat1Brd5RMatrixFunction
 
repD5Cat1Brd5RMatrixFunction[0, 0, 0] = {{1}}
 
repD5Cat1Brd5RMatrixFunction[0, 1, 1] = {{1}}
 
repD5Cat1Brd5RMatrixFunction[0, 2, 2] = {{1}}
 
repD5Cat1Brd5RMatrixFunction[0, 3, 3] = {{1}}
 
repD5Cat1Brd5RMatrixFunction[1, 0, 1] = {{1}}
 
repD5Cat1Brd5RMatrixFunction[1, 1, 0] = {{1}}
 
repD5Cat1Brd5RMatrixFunction[1, 2, 2] = {{1}}
 
repD5Cat1Brd5RMatrixFunction[1, 3, 3] = {{1}}
 
repD5Cat1Brd5RMatrixFunction[2, 0, 2] = {{1}}
 
repD5Cat1Brd5RMatrixFunction[2, 1, 2] = {{1}}
 
repD5Cat1Brd5RMatrixFunction[2, 2, 0] = {{(-1)^(2/5)}}
 
repD5Cat1Brd5RMatrixFunction[2, 2, 1] = {{-(-1)^(2/5)}}
 
repD5Cat1Brd5RMatrixFunction[2, 2, 3] = {{-(-1)^(3/5)}}
 
repD5Cat1Brd5RMatrixFunction[2, 3, 2] = {{(-1)^(4/5)}}
 
repD5Cat1Brd5RMatrixFunction[2, 3, 3] = {{-(-1)^(1/5)}}
 
repD5Cat1Brd5RMatrixFunction[3, 0, 3] = {{1}}
 
repD5Cat1Brd5RMatrixFunction[3, 1, 3] = {{1}}
 
repD5Cat1Brd5RMatrixFunction[3, 2, 2] = {{(-1)^(4/5)}}
 
repD5Cat1Brd5RMatrixFunction[3, 2, 3] = {{-(-1)^(1/5)}}
 
repD5Cat1Brd5RMatrixFunction[3, 3, 0] = 
   {{(-1 + (-1)^(1/5) + (-1)^(3/5) - (-1)^(4/5))^(-1)}}
 
repD5Cat1Brd5RMatrixFunction[3, 3, 1] = 
   {{(1 - (-1)^(1/5) - (-1)^(3/5) + (-1)^(4/5))^(-1)}}
 
repD5Cat1Brd5RMatrixFunction[3, 3, 2] = 
   {{-1 + (-1)^(1/5) + (-1)^(3/5) - (-1)^(4/5)}}
fMatrixFunction[repD5Cat1FMatrixFunction] ^= repD5Cat1FMatrixFunction
 
fusionCategory[repD5Cat1FMatrixFunction] ^= repD5Cat1
 
ring[repD5Cat1FMatrixFunction] ^= repD5
 
repD5Cat1FMatrixFunction[1, 2, 2, 3] = {{-1}}
 
repD5Cat1FMatrixFunction[1, 2, 3, 2] = {{-1}}
 
repD5Cat1FMatrixFunction[1, 3, 2, 2] = {{-1}}
 
repD5Cat1FMatrixFunction[1, 3, 2, 3] = {{-1}}
 
repD5Cat1FMatrixFunction[1, 3, 3, 0] = {{-1}}
 
repD5Cat1FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
repD5Cat1FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
repD5Cat1FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
repD5Cat1FMatrixFunction[2, 1, 3, 3] = {{-1}}
 
repD5Cat1FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
repD5Cat1FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
repD5Cat1FMatrixFunction[2, 2, 1, 3] = {{-1}}
 
repD5Cat1FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {-1/2, -1/2, 1/Sqrt[2]}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
repD5Cat1FMatrixFunction[2, 2, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
repD5Cat1FMatrixFunction[2, 3, 1, 2] = {{-1}}
 
repD5Cat1FMatrixFunction[2, 3, 1, 3] = {{-1}}
 
repD5Cat1FMatrixFunction[2, 3, 2, 1] = {{-1}}
 
repD5Cat1FMatrixFunction[2, 3, 2, 3] = {{0, 1}, {1, 0}}
 
repD5Cat1FMatrixFunction[2, 3, 3, 1] = {{-1}}
 
repD5Cat1FMatrixFunction[2, 3, 3, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
repD5Cat1FMatrixFunction[3, 1, 2, 3] = {{-1}}
 
repD5Cat1FMatrixFunction[3, 1, 3, 0] = {{-1}}
 
repD5Cat1FMatrixFunction[3, 1, 3, 1] = {{-1}}
 
repD5Cat1FMatrixFunction[3, 2, 1, 2] = {{-1}}
 
repD5Cat1FMatrixFunction[3, 2, 2, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repD5Cat1FMatrixFunction[3, 2, 3, 1] = {{-1}}
 
repD5Cat1FMatrixFunction[3, 2, 3, 2] = {{0, 1}, {1, 0}}
 
repD5Cat1FMatrixFunction[3, 3, 2, 1] = {{-1}}
 
repD5Cat1FMatrixFunction[3, 3, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repD5Cat1FMatrixFunction[3, 3, 3, 3] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {1/2, -1/2, -(1/Sqrt[2])}, {1/Sqrt[2], 1/Sqrt[2], 0}}
 
repD5Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repD5Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
repD5Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repD5Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[repD5Cat1Piv1] ^= {repD5Cat1Bal1, repD5Cat1Bal2, 
    repD5Cat1Bal3, repD5Cat1Bal4, repD5Cat1Bal5}
 
repD5Cat1Piv1 /: balancedCategory[repD5Cat1Piv1, 1] = repD5Cat1Bal1
 
repD5Cat1Piv1 /: balancedCategory[repD5Cat1Piv1, 2] = repD5Cat1Bal2
 
repD5Cat1Piv1 /: balancedCategory[repD5Cat1Piv1, 3] = repD5Cat1Bal3
 
repD5Cat1Piv1 /: balancedCategory[repD5Cat1Piv1, 4] = repD5Cat1Bal4
 
repD5Cat1Piv1 /: balancedCategory[repD5Cat1Piv1, 5] = repD5Cat1Bal5
 
fusionCategory[repD5Cat1Piv1] ^= repD5Cat1
 
repD5Cat1Piv1 /: modularCategory[repD5Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repD5Cat1Piv1] ^= repD5Cat1Piv1
 
pivotalIsomorphism[repD5Cat1Piv1] ^= repD5Cat1Piv1PivotalIsomorphism
 
repD5Cat1Piv1 /: ribbonCategory[repD5Cat1Piv1, 1] = repD5Cat1Bal1
 
repD5Cat1Piv1 /: ribbonCategory[repD5Cat1Piv1, 2] = repD5Cat1Bal2
 
repD5Cat1Piv1 /: ribbonCategory[repD5Cat1Piv1, 3] = repD5Cat1Bal3
 
repD5Cat1Piv1 /: ribbonCategory[repD5Cat1Piv1, 4] = repD5Cat1Bal4
 
repD5Cat1Piv1 /: ribbonCategory[repD5Cat1Piv1, 5] = repD5Cat1Bal5
 
ring[repD5Cat1Piv1] ^= repD5
 
sphericalCategory[repD5Cat1Piv1] ^= repD5Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[repD5Cat1]][pivotalCategory[#1]] & )[
    repD5Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[repD5Cat1]][sphericalCategory[#1]] & )[
    repD5Cat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[repD5Cat1Piv1PivotalIsomorphism] ^= repD5Cat1
 
pivotalCategory[repD5Cat1Piv1PivotalIsomorphism] ^= repD5Cat1Piv1
 
pivotalIsomorphism[repD5Cat1Piv1PivotalIsomorphism] ^= 
   repD5Cat1Piv1PivotalIsomorphism
 
repD5Cat1Piv1PivotalIsomorphism[0] = 1
 
repD5Cat1Piv1PivotalIsomorphism[1] = 1
 
repD5Cat1Piv1PivotalIsomorphism[2] = 1
 
repD5Cat1Piv1PivotalIsomorphism[3] = 1
balancedCategories[repD5Cat2] ^= {}
 
braidedCategories[repD5Cat2] ^= {}
 
coeval[repD5Cat2] ^= 1/sixJFunction[repD5Cat2][#1, dual[ring[repD5Cat2]][#1], 
      #1, #1, 0, 0] & 
 
eval[repD5Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[repD5Cat2] ^= repD5Cat2FMatrixFunction
 
fusionCategory[repD5Cat2] ^= repD5Cat2
 
repD5Cat2 /: modularCategory[repD5Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[repD5Cat2] ^= {repD5Cat2Piv1}
 
repD5Cat2 /: pivotalCategory[repD5Cat2, 1] = repD5Cat2Piv1
 
repD5Cat2 /: pivotalCategory[repD5Cat2, {1, 1, 1, 1}] = repD5Cat2Piv1
 
ring[repD5Cat2] ^= repD5
 
repD5Cat2 /: sphericalCategory[repD5Cat2, 1] = repD5Cat2Piv1
 
fusionCategoryIndex[repD5][repD5Cat2] ^= 2
fMatrixFunction[repD5Cat2FMatrixFunction] ^= repD5Cat2FMatrixFunction
 
fusionCategory[repD5Cat2FMatrixFunction] ^= repD5Cat2
 
ring[repD5Cat2FMatrixFunction] ^= repD5
 
repD5Cat2FMatrixFunction[1, 2, 2, 3] = {{-1}}
 
repD5Cat2FMatrixFunction[1, 2, 3, 2] = {{-1}}
 
repD5Cat2FMatrixFunction[1, 3, 2, 2] = {{-1}}
 
repD5Cat2FMatrixFunction[1, 3, 2, 3] = {{-1}}
 
repD5Cat2FMatrixFunction[1, 3, 3, 0] = {{-1}}
 
repD5Cat2FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
repD5Cat2FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
repD5Cat2FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
repD5Cat2FMatrixFunction[2, 1, 3, 3] = {{-1}}
 
repD5Cat2FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
repD5Cat2FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
repD5Cat2FMatrixFunction[2, 2, 1, 3] = {{-1}}
 
repD5Cat2FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {-1/2, -1/2, 1/Sqrt[2]}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
repD5Cat2FMatrixFunction[2, 2, 2, 3] = {{-(-1)^(1/5)}}
 
repD5Cat2FMatrixFunction[2, 2, 3, 2] = {{(-1)^(4/5)}}
 
repD5Cat2FMatrixFunction[2, 2, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
repD5Cat2FMatrixFunction[2, 3, 1, 2] = {{-1}}
 
repD5Cat2FMatrixFunction[2, 3, 1, 3] = {{-1}}
 
repD5Cat2FMatrixFunction[2, 3, 2, 1] = {{-1}}
 
repD5Cat2FMatrixFunction[2, 3, 2, 2] = {{-(-1)^(1/5)}}
 
repD5Cat2FMatrixFunction[2, 3, 2, 3] = {{0, (-1)^(4/5)}, {(-1)^(4/5), 0}}
 
repD5Cat2FMatrixFunction[2, 3, 3, 1] = {{-1}}
 
repD5Cat2FMatrixFunction[2, 3, 3, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
repD5Cat2FMatrixFunction[2, 3, 3, 3] = {{-(-1)^(1/5)}}
 
repD5Cat2FMatrixFunction[3, 1, 2, 3] = {{-1}}
 
repD5Cat2FMatrixFunction[3, 1, 3, 0] = {{-1}}
 
repD5Cat2FMatrixFunction[3, 1, 3, 1] = {{-1}}
 
repD5Cat2FMatrixFunction[3, 2, 1, 2] = {{-1}}
 
repD5Cat2FMatrixFunction[3, 2, 2, 2] = {{(-1)^(4/5)}}
 
repD5Cat2FMatrixFunction[3, 2, 2, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repD5Cat2FMatrixFunction[3, 2, 3, 1] = {{-1}}
 
repD5Cat2FMatrixFunction[3, 2, 3, 2] = {{0, -(-1)^(1/5)}, {-(-1)^(1/5), 0}}
 
repD5Cat2FMatrixFunction[3, 2, 3, 3] = {{(-1)^(4/5)}}
 
repD5Cat2FMatrixFunction[3, 3, 2, 1] = {{-1}}
 
repD5Cat2FMatrixFunction[3, 3, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repD5Cat2FMatrixFunction[3, 3, 2, 3] = {{-(-1)^(1/5)}}
 
repD5Cat2FMatrixFunction[3, 3, 3, 2] = {{(-1)^(4/5)}}
 
repD5Cat2FMatrixFunction[3, 3, 3, 3] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {1/2, -1/2, -(1/Sqrt[2])}, {1/Sqrt[2], 1/Sqrt[2], 0}}
 
repD5Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repD5Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
repD5Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repD5Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[repD5Cat2Piv1] ^= {}
 
fusionCategory[repD5Cat2Piv1] ^= repD5Cat2
 
repD5Cat2Piv1 /: modularCategory[repD5Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repD5Cat2Piv1] ^= repD5Cat2Piv1
 
pivotalIsomorphism[repD5Cat2Piv1] ^= repD5Cat2Piv1PivotalIsomorphism
 
ring[repD5Cat2Piv1] ^= repD5
 
sphericalCategory[repD5Cat2Piv1] ^= repD5Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[repD5Cat2]][pivotalCategory[#1]] & )[
    repD5Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[repD5Cat2]][sphericalCategory[#1]] & )[
    repD5Cat2Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[repD5Cat2Piv1PivotalIsomorphism] ^= repD5Cat2
 
pivotalCategory[repD5Cat2Piv1PivotalIsomorphism] ^= repD5Cat2Piv1
 
pivotalIsomorphism[repD5Cat2Piv1PivotalIsomorphism] ^= 
   repD5Cat2Piv1PivotalIsomorphism
 
repD5Cat2Piv1PivotalIsomorphism[0] = 1
 
repD5Cat2Piv1PivotalIsomorphism[1] = 1
 
repD5Cat2Piv1PivotalIsomorphism[2] = 1
 
repD5Cat2Piv1PivotalIsomorphism[3] = 1
balancedCategories[repD5Cat3] ^= {}
 
braidedCategories[repD5Cat3] ^= {}
 
coeval[repD5Cat3] ^= 1/sixJFunction[repD5Cat3][#1, dual[ring[repD5Cat3]][#1], 
      #1, #1, 0, 0] & 
 
eval[repD5Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[repD5Cat3] ^= repD5Cat3FMatrixFunction
 
fusionCategory[repD5Cat3] ^= repD5Cat3
 
repD5Cat3 /: modularCategory[repD5Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[repD5Cat3] ^= {repD5Cat3Piv1}
 
repD5Cat3 /: pivotalCategory[repD5Cat3, 1] = repD5Cat3Piv1
 
repD5Cat3 /: pivotalCategory[repD5Cat3, {1, 1, 1, 1}] = repD5Cat3Piv1
 
ring[repD5Cat3] ^= repD5
 
repD5Cat3 /: sphericalCategory[repD5Cat3, 1] = repD5Cat3Piv1
 
fusionCategoryIndex[repD5][repD5Cat3] ^= 3
fMatrixFunction[repD5Cat3FMatrixFunction] ^= repD5Cat3FMatrixFunction
 
fusionCategory[repD5Cat3FMatrixFunction] ^= repD5Cat3
 
ring[repD5Cat3FMatrixFunction] ^= repD5
 
repD5Cat3FMatrixFunction[1, 2, 2, 3] = {{-1}}
 
repD5Cat3FMatrixFunction[1, 2, 3, 2] = {{-1}}
 
repD5Cat3FMatrixFunction[1, 3, 2, 2] = {{-1}}
 
repD5Cat3FMatrixFunction[1, 3, 2, 3] = {{-1}}
 
repD5Cat3FMatrixFunction[1, 3, 3, 0] = {{-1}}
 
repD5Cat3FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
repD5Cat3FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
repD5Cat3FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
repD5Cat3FMatrixFunction[2, 1, 3, 3] = {{-1}}
 
repD5Cat3FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
repD5Cat3FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
repD5Cat3FMatrixFunction[2, 2, 1, 3] = {{-1}}
 
repD5Cat3FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {-1/2, -1/2, 1/Sqrt[2]}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
repD5Cat3FMatrixFunction[2, 2, 2, 3] = {{(-1)^(2/5)}}
 
repD5Cat3FMatrixFunction[2, 2, 3, 2] = {{-(-1)^(3/5)}}
 
repD5Cat3FMatrixFunction[2, 2, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
repD5Cat3FMatrixFunction[2, 3, 1, 2] = {{-1}}
 
repD5Cat3FMatrixFunction[2, 3, 1, 3] = {{-1}}
 
repD5Cat3FMatrixFunction[2, 3, 2, 1] = {{-1}}
 
repD5Cat3FMatrixFunction[2, 3, 2, 2] = {{(-1)^(2/5)}}
 
repD5Cat3FMatrixFunction[2, 3, 2, 3] = {{0, -(-1)^(3/5)}, {-(-1)^(3/5), 0}}
 
repD5Cat3FMatrixFunction[2, 3, 3, 1] = {{-1}}
 
repD5Cat3FMatrixFunction[2, 3, 3, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
repD5Cat3FMatrixFunction[2, 3, 3, 3] = {{(-1)^(2/5)}}
 
repD5Cat3FMatrixFunction[3, 1, 2, 3] = {{-1}}
 
repD5Cat3FMatrixFunction[3, 1, 3, 0] = {{-1}}
 
repD5Cat3FMatrixFunction[3, 1, 3, 1] = {{-1}}
 
repD5Cat3FMatrixFunction[3, 2, 1, 2] = {{-1}}
 
repD5Cat3FMatrixFunction[3, 2, 2, 2] = {{-(-1)^(3/5)}}
 
repD5Cat3FMatrixFunction[3, 2, 2, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repD5Cat3FMatrixFunction[3, 2, 3, 1] = {{-1}}
 
repD5Cat3FMatrixFunction[3, 2, 3, 2] = {{0, (-1)^(2/5)}, {(-1)^(2/5), 0}}
 
repD5Cat3FMatrixFunction[3, 2, 3, 3] = {{-(-1)^(3/5)}}
 
repD5Cat3FMatrixFunction[3, 3, 2, 1] = {{-1}}
 
repD5Cat3FMatrixFunction[3, 3, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repD5Cat3FMatrixFunction[3, 3, 2, 3] = {{(-1)^(2/5)}}
 
repD5Cat3FMatrixFunction[3, 3, 3, 2] = {{-(-1)^(3/5)}}
 
repD5Cat3FMatrixFunction[3, 3, 3, 3] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {1/2, -1/2, -(1/Sqrt[2])}, {1/Sqrt[2], 1/Sqrt[2], 0}}
 
repD5Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repD5Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
repD5Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repD5Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[repD5Cat3Piv1] ^= {}
 
fusionCategory[repD5Cat3Piv1] ^= repD5Cat3
 
repD5Cat3Piv1 /: modularCategory[repD5Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repD5Cat3Piv1] ^= repD5Cat3Piv1
 
pivotalIsomorphism[repD5Cat3Piv1] ^= repD5Cat3Piv1PivotalIsomorphism
 
ring[repD5Cat3Piv1] ^= repD5
 
sphericalCategory[repD5Cat3Piv1] ^= repD5Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[repD5Cat3]][pivotalCategory[#1]] & )[
    repD5Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[repD5Cat3]][sphericalCategory[#1]] & )[
    repD5Cat3Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[repD5Cat3Piv1PivotalIsomorphism] ^= repD5Cat3
 
pivotalCategory[repD5Cat3Piv1PivotalIsomorphism] ^= repD5Cat3Piv1
 
pivotalIsomorphism[repD5Cat3Piv1PivotalIsomorphism] ^= 
   repD5Cat3Piv1PivotalIsomorphism
 
repD5Cat3Piv1PivotalIsomorphism[0] = 1
 
repD5Cat3Piv1PivotalIsomorphism[1] = 1
 
repD5Cat3Piv1PivotalIsomorphism[2] = 1
 
repD5Cat3Piv1PivotalIsomorphism[3] = 1
ring[repD5NFunction] ^= repD5
 
repD5NFunction[0, 0, 0] = 1
 
repD5NFunction[0, 0, 1] = 0
 
repD5NFunction[0, 0, 2] = 0
 
repD5NFunction[0, 0, 3] = 0
 
repD5NFunction[0, 1, 0] = 0
 
repD5NFunction[0, 1, 1] = 1
 
repD5NFunction[0, 1, 2] = 0
 
repD5NFunction[0, 1, 3] = 0
 
repD5NFunction[0, 2, 0] = 0
 
repD5NFunction[0, 2, 1] = 0
 
repD5NFunction[0, 2, 2] = 1
 
repD5NFunction[0, 2, 3] = 0
 
repD5NFunction[0, 3, 0] = 0
 
repD5NFunction[0, 3, 1] = 0
 
repD5NFunction[0, 3, 2] = 0
 
repD5NFunction[0, 3, 3] = 1
 
repD5NFunction[1, 0, 0] = 0
 
repD5NFunction[1, 0, 1] = 1
 
repD5NFunction[1, 0, 2] = 0
 
repD5NFunction[1, 0, 3] = 0
 
repD5NFunction[1, 1, 0] = 1
 
repD5NFunction[1, 1, 1] = 0
 
repD5NFunction[1, 1, 2] = 0
 
repD5NFunction[1, 1, 3] = 0
 
repD5NFunction[1, 2, 0] = 0
 
repD5NFunction[1, 2, 1] = 0
 
repD5NFunction[1, 2, 2] = 1
 
repD5NFunction[1, 2, 3] = 0
 
repD5NFunction[1, 3, 0] = 0
 
repD5NFunction[1, 3, 1] = 0
 
repD5NFunction[1, 3, 2] = 0
 
repD5NFunction[1, 3, 3] = 1
 
repD5NFunction[2, 0, 0] = 0
 
repD5NFunction[2, 0, 1] = 0
 
repD5NFunction[2, 0, 2] = 1
 
repD5NFunction[2, 0, 3] = 0
 
repD5NFunction[2, 1, 0] = 0
 
repD5NFunction[2, 1, 1] = 0
 
repD5NFunction[2, 1, 2] = 1
 
repD5NFunction[2, 1, 3] = 0
 
repD5NFunction[2, 2, 0] = 1
 
repD5NFunction[2, 2, 1] = 1
 
repD5NFunction[2, 2, 2] = 0
 
repD5NFunction[2, 2, 3] = 1
 
repD5NFunction[2, 3, 0] = 0
 
repD5NFunction[2, 3, 1] = 0
 
repD5NFunction[2, 3, 2] = 1
 
repD5NFunction[2, 3, 3] = 1
 
repD5NFunction[3, 0, 0] = 0
 
repD5NFunction[3, 0, 1] = 0
 
repD5NFunction[3, 0, 2] = 0
 
repD5NFunction[3, 0, 3] = 1
 
repD5NFunction[3, 1, 0] = 0
 
repD5NFunction[3, 1, 1] = 0
 
repD5NFunction[3, 1, 2] = 0
 
repD5NFunction[3, 1, 3] = 1
 
repD5NFunction[3, 2, 0] = 0
 
repD5NFunction[3, 2, 1] = 0
 
repD5NFunction[3, 2, 2] = 1
 
repD5NFunction[3, 2, 3] = 1
 
repD5NFunction[3, 3, 0] = 1
 
repD5NFunction[3, 3, 1] = 1
 
repD5NFunction[3, 3, 2] = 1
 
repD5NFunction[3, 3, 3] = 0
 
repD5NFunction[a_, b_, c_] := 0


 EndPackage[]