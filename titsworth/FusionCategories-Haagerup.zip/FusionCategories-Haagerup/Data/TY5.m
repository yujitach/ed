BeginPackage["FusionCategories`Data`TY5`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[TY5] ^= {TY5Cat1, TY5Cat2, TY5Cat3, TY5Cat4}
 
TY5 /: fusionCategory[TY5, 1] = TY5Cat1
 
TY5 /: fusionCategory[TY5, 2] = TY5Cat2
 
TY5 /: fusionCategory[TY5, 3] = TY5Cat3
 
TY5 /: fusionCategory[TY5, 4] = TY5Cat4
 
nFunction[TY5] ^= TY5NFunction
 
noMultiplicities[TY5] ^= True
 
rank[TY5] ^= 6
 
ring[TY5] ^= TY5
balancedCategories[TY5Cat1] ^= {}
 
braidedCategories[TY5Cat1] ^= {}
 
coeval[TY5Cat1] ^= 1/sixJFunction[TY5Cat1][#1, dual[ring[TY5Cat1]][#1], #1, 
      #1, 0, 0] & 
 
eval[TY5Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TY5Cat1] ^= TY5Cat1FMatrixFunction
 
fusionCategory[TY5Cat1] ^= TY5Cat1
 
TY5Cat1 /: modularCategory[TY5Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TY5Cat1] ^= {TY5Cat1Piv1, TY5Cat1Piv2}
 
TY5Cat1 /: pivotalCategory[TY5Cat1, 1] = TY5Cat1Piv1
 
TY5Cat1 /: pivotalCategory[TY5Cat1, 2] = TY5Cat1Piv2
 
TY5Cat1 /: pivotalCategory[TY5Cat1, {1, 1, 1, 1, 1, -1}] = TY5Cat1Piv2
 
TY5Cat1 /: pivotalCategory[TY5Cat1, {1, 1, 1, 1, 1, 1}] = TY5Cat1Piv1
 
ring[TY5Cat1] ^= TY5
 
TY5Cat1 /: sphericalCategory[TY5Cat1, 1] = TY5Cat1Piv1
 
TY5Cat1 /: sphericalCategory[TY5Cat1, 2] = TY5Cat1Piv2
 
fusionCategoryIndex[TY5][TY5Cat1] ^= 1
fMatrixFunction[TY5Cat1FMatrixFunction] ^= TY5Cat1FMatrixFunction
 
fusionCategory[TY5Cat1FMatrixFunction] ^= TY5Cat1
 
ring[TY5Cat1FMatrixFunction] ^= TY5
 
TY5Cat1FMatrixFunction[1, 5, 1, 5] = {{-(-1)^(3/5)}}
 
TY5Cat1FMatrixFunction[1, 5, 2, 5] = {{-(-1)^(1/5)}}
 
TY5Cat1FMatrixFunction[1, 5, 3, 5] = {{(-1)^(4/5)}}
 
TY5Cat1FMatrixFunction[1, 5, 4, 5] = {{(-1)^(2/5)}}
 
TY5Cat1FMatrixFunction[2, 5, 1, 5] = {{-(-1)^(1/5)}}
 
TY5Cat1FMatrixFunction[2, 5, 2, 5] = {{(-1)^(2/5)}}
 
TY5Cat1FMatrixFunction[2, 5, 3, 5] = {{-(-1)^(3/5)}}
 
TY5Cat1FMatrixFunction[2, 5, 4, 5] = {{(-1)^(4/5)}}
 
TY5Cat1FMatrixFunction[3, 5, 1, 5] = {{(-1)^(4/5)}}
 
TY5Cat1FMatrixFunction[3, 5, 2, 5] = {{-(-1)^(3/5)}}
 
TY5Cat1FMatrixFunction[3, 5, 3, 5] = {{(-1)^(2/5)}}
 
TY5Cat1FMatrixFunction[3, 5, 4, 5] = {{-(-1)^(1/5)}}
 
TY5Cat1FMatrixFunction[4, 5, 1, 5] = {{(-1)^(2/5)}}
 
TY5Cat1FMatrixFunction[4, 5, 2, 5] = {{(-1)^(4/5)}}
 
TY5Cat1FMatrixFunction[4, 5, 3, 5] = {{-(-1)^(1/5)}}
 
TY5Cat1FMatrixFunction[4, 5, 4, 5] = {{-(-1)^(3/5)}}
 
TY5Cat1FMatrixFunction[5, 1, 5, 1] = {{-(-1)^(3/5)}}
 
TY5Cat1FMatrixFunction[5, 1, 5, 2] = {{-(-1)^(1/5)}}
 
TY5Cat1FMatrixFunction[5, 1, 5, 3] = {{(-1)^(4/5)}}
 
TY5Cat1FMatrixFunction[5, 1, 5, 4] = {{(-1)^(2/5)}}
 
TY5Cat1FMatrixFunction[5, 2, 5, 1] = {{-(-1)^(1/5)}}
 
TY5Cat1FMatrixFunction[5, 2, 5, 2] = {{(-1)^(2/5)}}
 
TY5Cat1FMatrixFunction[5, 2, 5, 3] = {{-(-1)^(3/5)}}
 
TY5Cat1FMatrixFunction[5, 2, 5, 4] = {{(-1)^(4/5)}}
 
TY5Cat1FMatrixFunction[5, 3, 5, 1] = {{(-1)^(4/5)}}
 
TY5Cat1FMatrixFunction[5, 3, 5, 2] = {{-(-1)^(3/5)}}
 
TY5Cat1FMatrixFunction[5, 3, 5, 3] = {{(-1)^(2/5)}}
 
TY5Cat1FMatrixFunction[5, 3, 5, 4] = {{-(-1)^(1/5)}}
 
TY5Cat1FMatrixFunction[5, 4, 5, 1] = {{(-1)^(2/5)}}
 
TY5Cat1FMatrixFunction[5, 4, 5, 2] = {{(-1)^(4/5)}}
 
TY5Cat1FMatrixFunction[5, 4, 5, 3] = {{-(-1)^(1/5)}}
 
TY5Cat1FMatrixFunction[5, 4, 5, 4] = {{-(-1)^(3/5)}}
 
TY5Cat1FMatrixFunction[5, 5, 5, 5] = 
   {{-(1/Sqrt[5]), -(1/Sqrt[5]), -(1/Sqrt[5]), -(1/Sqrt[5]), -(1/Sqrt[5])}, 
    {-(1/Sqrt[5]), Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 3, 0], 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 3, 0], 
     (5 + Sqrt[5] + I*Sqrt[50 - 10*Sqrt[5]])/20, 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 4, 0]}, 
    {-(1/Sqrt[5]), Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 3, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 4, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 3, 0], 
     (5 + Sqrt[5] + I*Sqrt[50 - 10*Sqrt[5]])/20}, 
    {-(1/Sqrt[5]), (5 + Sqrt[5] + I*Sqrt[50 - 10*Sqrt[5]])/20, 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 3, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 4, 0], 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 3, 0]}, 
    {-(1/Sqrt[5]), Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 4, 0], 
     (5 + Sqrt[5] + I*Sqrt[50 - 10*Sqrt[5]])/20, 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 3, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 3, 0]}}
 
TY5Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY5Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TY5Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY5Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TY5Cat1Piv1] ^= {}
 
fusionCategory[TY5Cat1Piv1] ^= TY5Cat1
 
TY5Cat1Piv1 /: modularCategory[TY5Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY5Cat1Piv1] ^= TY5Cat1Piv1
 
pivotalIsomorphism[TY5Cat1Piv1] ^= TY5Cat1Piv1PivotalIsomorphism
 
ring[TY5Cat1Piv1] ^= TY5
 
sphericalCategory[TY5Cat1Piv1] ^= TY5Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[TY5Cat1]][pivotalCategory[#1]] & )[
    TY5Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TY5Cat1]][sphericalCategory[#1]] & )[
    TY5Cat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY5Cat1Piv1PivotalIsomorphism] ^= TY5Cat1
 
pivotalCategory[TY5Cat1Piv1PivotalIsomorphism] ^= TY5Cat1Piv1
 
pivotalIsomorphism[TY5Cat1Piv1PivotalIsomorphism] ^= 
   TY5Cat1Piv1PivotalIsomorphism
 
TY5Cat1Piv1PivotalIsomorphism[0] = 1
 
TY5Cat1Piv1PivotalIsomorphism[1] = 1
 
TY5Cat1Piv1PivotalIsomorphism[2] = 1
 
TY5Cat1Piv1PivotalIsomorphism[3] = 1
 
TY5Cat1Piv1PivotalIsomorphism[4] = 1
 
TY5Cat1Piv1PivotalIsomorphism[5] = 1
balancedCategories[TY5Cat1Piv2] ^= {}
 
fusionCategory[TY5Cat1Piv2] ^= TY5Cat1
 
TY5Cat1Piv2 /: modularCategory[TY5Cat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY5Cat1Piv2] ^= TY5Cat1Piv2
 
pivotalIsomorphism[TY5Cat1Piv2] ^= TY5Cat1Piv2PivotalIsomorphism
 
ring[TY5Cat1Piv2] ^= TY5
 
sphericalCategory[TY5Cat1Piv2] ^= TY5Cat1Piv2
 
(pivotalCategoryIndex[fusionCategory[TY5Cat1]][pivotalCategory[#1]] & )[
    TY5Cat1Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TY5Cat1]][sphericalCategory[#1]] & )[
    TY5Cat1Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY5Cat1Piv2PivotalIsomorphism] ^= TY5Cat1
 
pivotalCategory[TY5Cat1Piv2PivotalIsomorphism] ^= TY5Cat1Piv2
 
pivotalIsomorphism[TY5Cat1Piv2PivotalIsomorphism] ^= 
   TY5Cat1Piv2PivotalIsomorphism
 
TY5Cat1Piv2PivotalIsomorphism[0] = 1
 
TY5Cat1Piv2PivotalIsomorphism[1] = 1
 
TY5Cat1Piv2PivotalIsomorphism[2] = 1
 
TY5Cat1Piv2PivotalIsomorphism[3] = 1
 
TY5Cat1Piv2PivotalIsomorphism[4] = 1
 
TY5Cat1Piv2PivotalIsomorphism[5] = -1
balancedCategories[TY5Cat2] ^= {}
 
braidedCategories[TY5Cat2] ^= {}
 
coeval[TY5Cat2] ^= 1/sixJFunction[TY5Cat2][#1, dual[ring[TY5Cat2]][#1], #1, 
      #1, 0, 0] & 
 
eval[TY5Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TY5Cat2] ^= TY5Cat2FMatrixFunction
 
fusionCategory[TY5Cat2] ^= TY5Cat2
 
TY5Cat2 /: modularCategory[TY5Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TY5Cat2] ^= {TY5Cat2Piv1, TY5Cat2Piv2}
 
TY5Cat2 /: pivotalCategory[TY5Cat2, 1] = TY5Cat2Piv1
 
TY5Cat2 /: pivotalCategory[TY5Cat2, 2] = TY5Cat2Piv2
 
TY5Cat2 /: pivotalCategory[TY5Cat2, {1, 1, 1, 1, 1, -1}] = TY5Cat2Piv2
 
TY5Cat2 /: pivotalCategory[TY5Cat2, {1, 1, 1, 1, 1, 1}] = TY5Cat2Piv1
 
ring[TY5Cat2] ^= TY5
 
TY5Cat2 /: sphericalCategory[TY5Cat2, 1] = TY5Cat2Piv1
 
TY5Cat2 /: sphericalCategory[TY5Cat2, 2] = TY5Cat2Piv2
 
fusionCategoryIndex[TY5][TY5Cat2] ^= 2
fMatrixFunction[TY5Cat2FMatrixFunction] ^= TY5Cat2FMatrixFunction
 
fusionCategory[TY5Cat2FMatrixFunction] ^= TY5Cat2
 
ring[TY5Cat2FMatrixFunction] ^= TY5
 
TY5Cat2FMatrixFunction[1, 5, 1, 5] = {{(-1)^(4/5)}}
 
TY5Cat2FMatrixFunction[1, 5, 2, 5] = {{-(-1)^(3/5)}}
 
TY5Cat2FMatrixFunction[1, 5, 3, 5] = {{(-1)^(2/5)}}
 
TY5Cat2FMatrixFunction[1, 5, 4, 5] = {{-(-1)^(1/5)}}
 
TY5Cat2FMatrixFunction[2, 5, 1, 5] = {{-(-1)^(3/5)}}
 
TY5Cat2FMatrixFunction[2, 5, 2, 5] = {{-(-1)^(1/5)}}
 
TY5Cat2FMatrixFunction[2, 5, 3, 5] = {{(-1)^(4/5)}}
 
TY5Cat2FMatrixFunction[2, 5, 4, 5] = {{(-1)^(2/5)}}
 
TY5Cat2FMatrixFunction[3, 5, 1, 5] = {{(-1)^(2/5)}}
 
TY5Cat2FMatrixFunction[3, 5, 2, 5] = {{(-1)^(4/5)}}
 
TY5Cat2FMatrixFunction[3, 5, 3, 5] = {{-(-1)^(1/5)}}
 
TY5Cat2FMatrixFunction[3, 5, 4, 5] = {{-(-1)^(3/5)}}
 
TY5Cat2FMatrixFunction[4, 5, 1, 5] = {{-(-1)^(1/5)}}
 
TY5Cat2FMatrixFunction[4, 5, 2, 5] = {{(-1)^(2/5)}}
 
TY5Cat2FMatrixFunction[4, 5, 3, 5] = {{-(-1)^(3/5)}}
 
TY5Cat2FMatrixFunction[4, 5, 4, 5] = {{(-1)^(4/5)}}
 
TY5Cat2FMatrixFunction[5, 1, 5, 1] = {{(-1)^(4/5)}}
 
TY5Cat2FMatrixFunction[5, 1, 5, 2] = {{-(-1)^(3/5)}}
 
TY5Cat2FMatrixFunction[5, 1, 5, 3] = {{(-1)^(2/5)}}
 
TY5Cat2FMatrixFunction[5, 1, 5, 4] = {{-(-1)^(1/5)}}
 
TY5Cat2FMatrixFunction[5, 2, 5, 1] = {{-(-1)^(3/5)}}
 
TY5Cat2FMatrixFunction[5, 2, 5, 2] = {{-(-1)^(1/5)}}
 
TY5Cat2FMatrixFunction[5, 2, 5, 3] = {{(-1)^(4/5)}}
 
TY5Cat2FMatrixFunction[5, 2, 5, 4] = {{(-1)^(2/5)}}
 
TY5Cat2FMatrixFunction[5, 3, 5, 1] = {{(-1)^(2/5)}}
 
TY5Cat2FMatrixFunction[5, 3, 5, 2] = {{(-1)^(4/5)}}
 
TY5Cat2FMatrixFunction[5, 3, 5, 3] = {{-(-1)^(1/5)}}
 
TY5Cat2FMatrixFunction[5, 3, 5, 4] = {{-(-1)^(3/5)}}
 
TY5Cat2FMatrixFunction[5, 4, 5, 1] = {{-(-1)^(1/5)}}
 
TY5Cat2FMatrixFunction[5, 4, 5, 2] = {{(-1)^(2/5)}}
 
TY5Cat2FMatrixFunction[5, 4, 5, 3] = {{-(-1)^(3/5)}}
 
TY5Cat2FMatrixFunction[5, 4, 5, 4] = {{(-1)^(4/5)}}
 
TY5Cat2FMatrixFunction[5, 5, 5, 5] = 
   {{-(1/Sqrt[5]), -(1/Sqrt[5]), -(1/Sqrt[5]), -(1/Sqrt[5]), -(1/Sqrt[5])}, 
    {-(1/Sqrt[5]), (5 + Sqrt[5] + I*Sqrt[50 - 10*Sqrt[5]])/20, 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 3, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 4, 0], 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 3, 0]}, 
    {-(1/Sqrt[5]), Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 3, 0], 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 3, 0], 
     (5 + Sqrt[5] + I*Sqrt[50 - 10*Sqrt[5]])/20, 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 4, 0]}, 
    {-(1/Sqrt[5]), Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 4, 0], 
     (5 + Sqrt[5] + I*Sqrt[50 - 10*Sqrt[5]])/20, 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 3, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 3, 0]}, 
    {-(1/Sqrt[5]), Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 3, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 4, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 3, 0], 
     (5 + Sqrt[5] + I*Sqrt[50 - 10*Sqrt[5]])/20}}
 
TY5Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY5Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TY5Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY5Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TY5Cat2Piv1] ^= {}
 
fusionCategory[TY5Cat2Piv1] ^= TY5Cat2
 
TY5Cat2Piv1 /: modularCategory[TY5Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY5Cat2Piv1] ^= TY5Cat2Piv1
 
pivotalIsomorphism[TY5Cat2Piv1] ^= TY5Cat2Piv1PivotalIsomorphism
 
ring[TY5Cat2Piv1] ^= TY5
 
sphericalCategory[TY5Cat2Piv1] ^= TY5Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[TY5Cat2]][pivotalCategory[#1]] & )[
    TY5Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TY5Cat2]][sphericalCategory[#1]] & )[
    TY5Cat2Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY5Cat2Piv1PivotalIsomorphism] ^= TY5Cat2
 
pivotalCategory[TY5Cat2Piv1PivotalIsomorphism] ^= TY5Cat2Piv1
 
pivotalIsomorphism[TY5Cat2Piv1PivotalIsomorphism] ^= 
   TY5Cat2Piv1PivotalIsomorphism
 
TY5Cat2Piv1PivotalIsomorphism[0] = 1
 
TY5Cat2Piv1PivotalIsomorphism[1] = 1
 
TY5Cat2Piv1PivotalIsomorphism[2] = 1
 
TY5Cat2Piv1PivotalIsomorphism[3] = 1
 
TY5Cat2Piv1PivotalIsomorphism[4] = 1
 
TY5Cat2Piv1PivotalIsomorphism[5] = 1
balancedCategories[TY5Cat2Piv2] ^= {}
 
fusionCategory[TY5Cat2Piv2] ^= TY5Cat2
 
TY5Cat2Piv2 /: modularCategory[TY5Cat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY5Cat2Piv2] ^= TY5Cat2Piv2
 
pivotalIsomorphism[TY5Cat2Piv2] ^= TY5Cat2Piv2PivotalIsomorphism
 
ring[TY5Cat2Piv2] ^= TY5
 
sphericalCategory[TY5Cat2Piv2] ^= TY5Cat2Piv2
 
(pivotalCategoryIndex[fusionCategory[TY5Cat2]][pivotalCategory[#1]] & )[
    TY5Cat2Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TY5Cat2]][sphericalCategory[#1]] & )[
    TY5Cat2Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY5Cat2Piv2PivotalIsomorphism] ^= TY5Cat2
 
pivotalCategory[TY5Cat2Piv2PivotalIsomorphism] ^= TY5Cat2Piv2
 
pivotalIsomorphism[TY5Cat2Piv2PivotalIsomorphism] ^= 
   TY5Cat2Piv2PivotalIsomorphism
 
TY5Cat2Piv2PivotalIsomorphism[0] = 1
 
TY5Cat2Piv2PivotalIsomorphism[1] = 1
 
TY5Cat2Piv2PivotalIsomorphism[2] = 1
 
TY5Cat2Piv2PivotalIsomorphism[3] = 1
 
TY5Cat2Piv2PivotalIsomorphism[4] = 1
 
TY5Cat2Piv2PivotalIsomorphism[5] = -1
balancedCategories[TY5Cat3] ^= {}
 
braidedCategories[TY5Cat3] ^= {}
 
coeval[TY5Cat3] ^= 1/sixJFunction[TY5Cat3][#1, dual[ring[TY5Cat3]][#1], #1, 
      #1, 0, 0] & 
 
eval[TY5Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TY5Cat3] ^= TY5Cat3FMatrixFunction
 
fusionCategory[TY5Cat3] ^= TY5Cat3
 
TY5Cat3 /: modularCategory[TY5Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TY5Cat3] ^= {TY5Cat3Piv1, TY5Cat3Piv2}
 
TY5Cat3 /: pivotalCategory[TY5Cat3, 1] = TY5Cat3Piv1
 
TY5Cat3 /: pivotalCategory[TY5Cat3, 2] = TY5Cat3Piv2
 
TY5Cat3 /: pivotalCategory[TY5Cat3, {1, 1, 1, 1, 1, -1}] = TY5Cat3Piv2
 
TY5Cat3 /: pivotalCategory[TY5Cat3, {1, 1, 1, 1, 1, 1}] = TY5Cat3Piv1
 
ring[TY5Cat3] ^= TY5
 
TY5Cat3 /: sphericalCategory[TY5Cat3, 1] = TY5Cat3Piv1
 
TY5Cat3 /: sphericalCategory[TY5Cat3, 2] = TY5Cat3Piv2
 
fusionCategoryIndex[TY5][TY5Cat3] ^= 3
fMatrixFunction[TY5Cat3FMatrixFunction] ^= TY5Cat3FMatrixFunction
 
fusionCategory[TY5Cat3FMatrixFunction] ^= TY5Cat3
 
ring[TY5Cat3FMatrixFunction] ^= TY5
 
TY5Cat3FMatrixFunction[1, 5, 1, 5] = {{-(-1)^(3/5)}}
 
TY5Cat3FMatrixFunction[1, 5, 2, 5] = {{-(-1)^(1/5)}}
 
TY5Cat3FMatrixFunction[1, 5, 3, 5] = {{(-1)^(4/5)}}
 
TY5Cat3FMatrixFunction[1, 5, 4, 5] = {{(-1)^(2/5)}}
 
TY5Cat3FMatrixFunction[2, 5, 1, 5] = {{-(-1)^(1/5)}}
 
TY5Cat3FMatrixFunction[2, 5, 2, 5] = {{(-1)^(2/5)}}
 
TY5Cat3FMatrixFunction[2, 5, 3, 5] = {{-(-1)^(3/5)}}
 
TY5Cat3FMatrixFunction[2, 5, 4, 5] = {{(-1)^(4/5)}}
 
TY5Cat3FMatrixFunction[3, 5, 1, 5] = {{(-1)^(4/5)}}
 
TY5Cat3FMatrixFunction[3, 5, 2, 5] = {{-(-1)^(3/5)}}
 
TY5Cat3FMatrixFunction[3, 5, 3, 5] = {{(-1)^(2/5)}}
 
TY5Cat3FMatrixFunction[3, 5, 4, 5] = {{-(-1)^(1/5)}}
 
TY5Cat3FMatrixFunction[4, 5, 1, 5] = {{(-1)^(2/5)}}
 
TY5Cat3FMatrixFunction[4, 5, 2, 5] = {{(-1)^(4/5)}}
 
TY5Cat3FMatrixFunction[4, 5, 3, 5] = {{-(-1)^(1/5)}}
 
TY5Cat3FMatrixFunction[4, 5, 4, 5] = {{-(-1)^(3/5)}}
 
TY5Cat3FMatrixFunction[5, 1, 5, 1] = {{-(-1)^(3/5)}}
 
TY5Cat3FMatrixFunction[5, 1, 5, 2] = {{-(-1)^(1/5)}}
 
TY5Cat3FMatrixFunction[5, 1, 5, 3] = {{(-1)^(4/5)}}
 
TY5Cat3FMatrixFunction[5, 1, 5, 4] = {{(-1)^(2/5)}}
 
TY5Cat3FMatrixFunction[5, 2, 5, 1] = {{-(-1)^(1/5)}}
 
TY5Cat3FMatrixFunction[5, 2, 5, 2] = {{(-1)^(2/5)}}
 
TY5Cat3FMatrixFunction[5, 2, 5, 3] = {{-(-1)^(3/5)}}
 
TY5Cat3FMatrixFunction[5, 2, 5, 4] = {{(-1)^(4/5)}}
 
TY5Cat3FMatrixFunction[5, 3, 5, 1] = {{(-1)^(4/5)}}
 
TY5Cat3FMatrixFunction[5, 3, 5, 2] = {{-(-1)^(3/5)}}
 
TY5Cat3FMatrixFunction[5, 3, 5, 3] = {{(-1)^(2/5)}}
 
TY5Cat3FMatrixFunction[5, 3, 5, 4] = {{-(-1)^(1/5)}}
 
TY5Cat3FMatrixFunction[5, 4, 5, 1] = {{(-1)^(2/5)}}
 
TY5Cat3FMatrixFunction[5, 4, 5, 2] = {{(-1)^(4/5)}}
 
TY5Cat3FMatrixFunction[5, 4, 5, 3] = {{-(-1)^(1/5)}}
 
TY5Cat3FMatrixFunction[5, 4, 5, 4] = {{-(-1)^(3/5)}}
 
TY5Cat3FMatrixFunction[5, 5, 5, 5] = {{1/Sqrt[5], 1/Sqrt[5], 1/Sqrt[5], 
     1/Sqrt[5], 1/Sqrt[5]}, {1/Sqrt[5], 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 2, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 2, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 1, 0], 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 1, 0]}, 
    {1/Sqrt[5], Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 2, 0], 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 1, 0], 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 2, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 1, 0]}, 
    {1/Sqrt[5], Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 1, 0], 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 2, 0], 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 1, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 2, 0]}, 
    {1/Sqrt[5], Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 1, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 1, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 2, 0], 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 2, 0]}}
 
TY5Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY5Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TY5Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY5Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TY5Cat3Piv1] ^= {}
 
fusionCategory[TY5Cat3Piv1] ^= TY5Cat3
 
TY5Cat3Piv1 /: modularCategory[TY5Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY5Cat3Piv1] ^= TY5Cat3Piv1
 
pivotalIsomorphism[TY5Cat3Piv1] ^= TY5Cat3Piv1PivotalIsomorphism
 
ring[TY5Cat3Piv1] ^= TY5
 
sphericalCategory[TY5Cat3Piv1] ^= TY5Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[TY5Cat3]][pivotalCategory[#1]] & )[
    TY5Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TY5Cat3]][sphericalCategory[#1]] & )[
    TY5Cat3Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY5Cat3Piv1PivotalIsomorphism] ^= TY5Cat3
 
pivotalCategory[TY5Cat3Piv1PivotalIsomorphism] ^= TY5Cat3Piv1
 
pivotalIsomorphism[TY5Cat3Piv1PivotalIsomorphism] ^= 
   TY5Cat3Piv1PivotalIsomorphism
 
TY5Cat3Piv1PivotalIsomorphism[0] = 1
 
TY5Cat3Piv1PivotalIsomorphism[1] = 1
 
TY5Cat3Piv1PivotalIsomorphism[2] = 1
 
TY5Cat3Piv1PivotalIsomorphism[3] = 1
 
TY5Cat3Piv1PivotalIsomorphism[4] = 1
 
TY5Cat3Piv1PivotalIsomorphism[5] = 1
balancedCategories[TY5Cat3Piv2] ^= {}
 
fusionCategory[TY5Cat3Piv2] ^= TY5Cat3
 
TY5Cat3Piv2 /: modularCategory[TY5Cat3Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY5Cat3Piv2] ^= TY5Cat3Piv2
 
pivotalIsomorphism[TY5Cat3Piv2] ^= TY5Cat3Piv2PivotalIsomorphism
 
ring[TY5Cat3Piv2] ^= TY5
 
sphericalCategory[TY5Cat3Piv2] ^= TY5Cat3Piv2
 
(pivotalCategoryIndex[fusionCategory[TY5Cat3]][pivotalCategory[#1]] & )[
    TY5Cat3Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TY5Cat3]][sphericalCategory[#1]] & )[
    TY5Cat3Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY5Cat3Piv2PivotalIsomorphism] ^= TY5Cat3
 
pivotalCategory[TY5Cat3Piv2PivotalIsomorphism] ^= TY5Cat3Piv2
 
pivotalIsomorphism[TY5Cat3Piv2PivotalIsomorphism] ^= 
   TY5Cat3Piv2PivotalIsomorphism
 
TY5Cat3Piv2PivotalIsomorphism[0] = 1
 
TY5Cat3Piv2PivotalIsomorphism[1] = 1
 
TY5Cat3Piv2PivotalIsomorphism[2] = 1
 
TY5Cat3Piv2PivotalIsomorphism[3] = 1
 
TY5Cat3Piv2PivotalIsomorphism[4] = 1
 
TY5Cat3Piv2PivotalIsomorphism[5] = -1
balancedCategories[TY5Cat4] ^= {}
 
braidedCategories[TY5Cat4] ^= {}
 
coeval[TY5Cat4] ^= 1/sixJFunction[TY5Cat4][#1, dual[ring[TY5Cat4]][#1], #1, 
      #1, 0, 0] & 
 
eval[TY5Cat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TY5Cat4] ^= TY5Cat4FMatrixFunction
 
fusionCategory[TY5Cat4] ^= TY5Cat4
 
TY5Cat4 /: modularCategory[TY5Cat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TY5Cat4] ^= {TY5Cat4Piv1, TY5Cat4Piv2}
 
TY5Cat4 /: pivotalCategory[TY5Cat4, 1] = TY5Cat4Piv1
 
TY5Cat4 /: pivotalCategory[TY5Cat4, 2] = TY5Cat4Piv2
 
TY5Cat4 /: pivotalCategory[TY5Cat4, {1, 1, 1, 1, 1, -1}] = TY5Cat4Piv2
 
TY5Cat4 /: pivotalCategory[TY5Cat4, {1, 1, 1, 1, 1, 1}] = TY5Cat4Piv1
 
ring[TY5Cat4] ^= TY5
 
TY5Cat4 /: sphericalCategory[TY5Cat4, 1] = TY5Cat4Piv1
 
TY5Cat4 /: sphericalCategory[TY5Cat4, 2] = TY5Cat4Piv2
 
fusionCategoryIndex[TY5][TY5Cat4] ^= 4
fMatrixFunction[TY5Cat4FMatrixFunction] ^= TY5Cat4FMatrixFunction
 
fusionCategory[TY5Cat4FMatrixFunction] ^= TY5Cat4
 
ring[TY5Cat4FMatrixFunction] ^= TY5
 
TY5Cat4FMatrixFunction[1, 5, 1, 5] = {{(-1)^(4/5)}}
 
TY5Cat4FMatrixFunction[1, 5, 2, 5] = {{-(-1)^(3/5)}}
 
TY5Cat4FMatrixFunction[1, 5, 3, 5] = {{(-1)^(2/5)}}
 
TY5Cat4FMatrixFunction[1, 5, 4, 5] = {{-(-1)^(1/5)}}
 
TY5Cat4FMatrixFunction[2, 5, 1, 5] = {{-(-1)^(3/5)}}
 
TY5Cat4FMatrixFunction[2, 5, 2, 5] = {{-(-1)^(1/5)}}
 
TY5Cat4FMatrixFunction[2, 5, 3, 5] = {{(-1)^(4/5)}}
 
TY5Cat4FMatrixFunction[2, 5, 4, 5] = {{(-1)^(2/5)}}
 
TY5Cat4FMatrixFunction[3, 5, 1, 5] = {{(-1)^(2/5)}}
 
TY5Cat4FMatrixFunction[3, 5, 2, 5] = {{(-1)^(4/5)}}
 
TY5Cat4FMatrixFunction[3, 5, 3, 5] = {{-(-1)^(1/5)}}
 
TY5Cat4FMatrixFunction[3, 5, 4, 5] = {{-(-1)^(3/5)}}
 
TY5Cat4FMatrixFunction[4, 5, 1, 5] = {{-(-1)^(1/5)}}
 
TY5Cat4FMatrixFunction[4, 5, 2, 5] = {{(-1)^(2/5)}}
 
TY5Cat4FMatrixFunction[4, 5, 3, 5] = {{-(-1)^(3/5)}}
 
TY5Cat4FMatrixFunction[4, 5, 4, 5] = {{(-1)^(4/5)}}
 
TY5Cat4FMatrixFunction[5, 1, 5, 1] = {{(-1)^(4/5)}}
 
TY5Cat4FMatrixFunction[5, 1, 5, 2] = {{-(-1)^(3/5)}}
 
TY5Cat4FMatrixFunction[5, 1, 5, 3] = {{(-1)^(2/5)}}
 
TY5Cat4FMatrixFunction[5, 1, 5, 4] = {{-(-1)^(1/5)}}
 
TY5Cat4FMatrixFunction[5, 2, 5, 1] = {{-(-1)^(3/5)}}
 
TY5Cat4FMatrixFunction[5, 2, 5, 2] = {{-(-1)^(1/5)}}
 
TY5Cat4FMatrixFunction[5, 2, 5, 3] = {{(-1)^(4/5)}}
 
TY5Cat4FMatrixFunction[5, 2, 5, 4] = {{(-1)^(2/5)}}
 
TY5Cat4FMatrixFunction[5, 3, 5, 1] = {{(-1)^(2/5)}}
 
TY5Cat4FMatrixFunction[5, 3, 5, 2] = {{(-1)^(4/5)}}
 
TY5Cat4FMatrixFunction[5, 3, 5, 3] = {{-(-1)^(1/5)}}
 
TY5Cat4FMatrixFunction[5, 3, 5, 4] = {{-(-1)^(3/5)}}
 
TY5Cat4FMatrixFunction[5, 4, 5, 1] = {{-(-1)^(1/5)}}
 
TY5Cat4FMatrixFunction[5, 4, 5, 2] = {{(-1)^(2/5)}}
 
TY5Cat4FMatrixFunction[5, 4, 5, 3] = {{-(-1)^(3/5)}}
 
TY5Cat4FMatrixFunction[5, 4, 5, 4] = {{(-1)^(4/5)}}
 
TY5Cat4FMatrixFunction[5, 5, 5, 5] = {{1/Sqrt[5], 1/Sqrt[5], 1/Sqrt[5], 
     1/Sqrt[5], 1/Sqrt[5]}, {1/Sqrt[5], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 1, 0], 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 2, 0], 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 1, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 2, 0]}, 
    {1/Sqrt[5], Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 2, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 2, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 1, 0], 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 1, 0]}, 
    {1/Sqrt[5], Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 1, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 1, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 2, 0], 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 2, 0]}, 
    {1/Sqrt[5], Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 2, 0], 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 1, 0], 
     Root[1 - 5*#1 + 15*#1^2 - 25*#1^3 + 25*#1^4 & , 2, 0], 
     Root[1 + 5*#1 + 15*#1^2 + 25*#1^3 + 25*#1^4 & , 1, 0]}}
 
TY5Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY5Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TY5Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY5Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TY5Cat4Piv1] ^= {}
 
fusionCategory[TY5Cat4Piv1] ^= TY5Cat4
 
TY5Cat4Piv1 /: modularCategory[TY5Cat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY5Cat4Piv1] ^= TY5Cat4Piv1
 
pivotalIsomorphism[TY5Cat4Piv1] ^= TY5Cat4Piv1PivotalIsomorphism
 
ring[TY5Cat4Piv1] ^= TY5
 
sphericalCategory[TY5Cat4Piv1] ^= TY5Cat4Piv1
 
(pivotalCategoryIndex[fusionCategory[TY5Cat4]][pivotalCategory[#1]] & )[
    TY5Cat4Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TY5Cat4]][sphericalCategory[#1]] & )[
    TY5Cat4Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY5Cat4Piv1PivotalIsomorphism] ^= TY5Cat4
 
pivotalCategory[TY5Cat4Piv1PivotalIsomorphism] ^= TY5Cat4Piv1
 
pivotalIsomorphism[TY5Cat4Piv1PivotalIsomorphism] ^= 
   TY5Cat4Piv1PivotalIsomorphism
 
TY5Cat4Piv1PivotalIsomorphism[0] = 1
 
TY5Cat4Piv1PivotalIsomorphism[1] = 1
 
TY5Cat4Piv1PivotalIsomorphism[2] = 1
 
TY5Cat4Piv1PivotalIsomorphism[3] = 1
 
TY5Cat4Piv1PivotalIsomorphism[4] = 1
 
TY5Cat4Piv1PivotalIsomorphism[5] = 1
balancedCategories[TY5Cat4Piv2] ^= {}
 
fusionCategory[TY5Cat4Piv2] ^= TY5Cat4
 
TY5Cat4Piv2 /: modularCategory[TY5Cat4Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY5Cat4Piv2] ^= TY5Cat4Piv2
 
pivotalIsomorphism[TY5Cat4Piv2] ^= TY5Cat4Piv2PivotalIsomorphism
 
ring[TY5Cat4Piv2] ^= TY5
 
sphericalCategory[TY5Cat4Piv2] ^= TY5Cat4Piv2
 
(pivotalCategoryIndex[fusionCategory[TY5Cat4]][pivotalCategory[#1]] & )[
    TY5Cat4Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TY5Cat4]][sphericalCategory[#1]] & )[
    TY5Cat4Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY5Cat4Piv2PivotalIsomorphism] ^= TY5Cat4
 
pivotalCategory[TY5Cat4Piv2PivotalIsomorphism] ^= TY5Cat4Piv2
 
pivotalIsomorphism[TY5Cat4Piv2PivotalIsomorphism] ^= 
   TY5Cat4Piv2PivotalIsomorphism
 
TY5Cat4Piv2PivotalIsomorphism[0] = 1
 
TY5Cat4Piv2PivotalIsomorphism[1] = 1
 
TY5Cat4Piv2PivotalIsomorphism[2] = 1
 
TY5Cat4Piv2PivotalIsomorphism[3] = 1
 
TY5Cat4Piv2PivotalIsomorphism[4] = 1
 
TY5Cat4Piv2PivotalIsomorphism[5] = -1
ring[TY5NFunction] ^= TY5
 
TY5NFunction[0, 0, 0] = 1
 
TY5NFunction[0, 0, 1] = 0
 
TY5NFunction[0, 0, 2] = 0
 
TY5NFunction[0, 0, 3] = 0
 
TY5NFunction[0, 0, 4] = 0
 
TY5NFunction[0, 0, 5] = 0
 
TY5NFunction[0, 1, 0] = 0
 
TY5NFunction[0, 1, 1] = 1
 
TY5NFunction[0, 1, 2] = 0
 
TY5NFunction[0, 1, 3] = 0
 
TY5NFunction[0, 1, 4] = 0
 
TY5NFunction[0, 1, 5] = 0
 
TY5NFunction[0, 2, 0] = 0
 
TY5NFunction[0, 2, 1] = 0
 
TY5NFunction[0, 2, 2] = 1
 
TY5NFunction[0, 2, 3] = 0
 
TY5NFunction[0, 2, 4] = 0
 
TY5NFunction[0, 2, 5] = 0
 
TY5NFunction[0, 3, 0] = 0
 
TY5NFunction[0, 3, 1] = 0
 
TY5NFunction[0, 3, 2] = 0
 
TY5NFunction[0, 3, 3] = 1
 
TY5NFunction[0, 3, 4] = 0
 
TY5NFunction[0, 3, 5] = 0
 
TY5NFunction[0, 4, 0] = 0
 
TY5NFunction[0, 4, 1] = 0
 
TY5NFunction[0, 4, 2] = 0
 
TY5NFunction[0, 4, 3] = 0
 
TY5NFunction[0, 4, 4] = 1
 
TY5NFunction[0, 4, 5] = 0
 
TY5NFunction[0, 5, 0] = 0
 
TY5NFunction[0, 5, 1] = 0
 
TY5NFunction[0, 5, 2] = 0
 
TY5NFunction[0, 5, 3] = 0
 
TY5NFunction[0, 5, 4] = 0
 
TY5NFunction[0, 5, 5] = 1
 
TY5NFunction[1, 0, 0] = 0
 
TY5NFunction[1, 0, 1] = 1
 
TY5NFunction[1, 0, 2] = 0
 
TY5NFunction[1, 0, 3] = 0
 
TY5NFunction[1, 0, 4] = 0
 
TY5NFunction[1, 0, 5] = 0
 
TY5NFunction[1, 1, 0] = 0
 
TY5NFunction[1, 1, 1] = 0
 
TY5NFunction[1, 1, 2] = 1
 
TY5NFunction[1, 1, 3] = 0
 
TY5NFunction[1, 1, 4] = 0
 
TY5NFunction[1, 1, 5] = 0
 
TY5NFunction[1, 2, 0] = 0
 
TY5NFunction[1, 2, 1] = 0
 
TY5NFunction[1, 2, 2] = 0
 
TY5NFunction[1, 2, 3] = 1
 
TY5NFunction[1, 2, 4] = 0
 
TY5NFunction[1, 2, 5] = 0
 
TY5NFunction[1, 3, 0] = 0
 
TY5NFunction[1, 3, 1] = 0
 
TY5NFunction[1, 3, 2] = 0
 
TY5NFunction[1, 3, 3] = 0
 
TY5NFunction[1, 3, 4] = 1
 
TY5NFunction[1, 3, 5] = 0
 
TY5NFunction[1, 4, 0] = 1
 
TY5NFunction[1, 4, 1] = 0
 
TY5NFunction[1, 4, 2] = 0
 
TY5NFunction[1, 4, 3] = 0
 
TY5NFunction[1, 4, 4] = 0
 
TY5NFunction[1, 4, 5] = 0
 
TY5NFunction[1, 5, 0] = 0
 
TY5NFunction[1, 5, 1] = 0
 
TY5NFunction[1, 5, 2] = 0
 
TY5NFunction[1, 5, 3] = 0
 
TY5NFunction[1, 5, 4] = 0
 
TY5NFunction[1, 5, 5] = 1
 
TY5NFunction[2, 0, 0] = 0
 
TY5NFunction[2, 0, 1] = 0
 
TY5NFunction[2, 0, 2] = 1
 
TY5NFunction[2, 0, 3] = 0
 
TY5NFunction[2, 0, 4] = 0
 
TY5NFunction[2, 0, 5] = 0
 
TY5NFunction[2, 1, 0] = 0
 
TY5NFunction[2, 1, 1] = 0
 
TY5NFunction[2, 1, 2] = 0
 
TY5NFunction[2, 1, 3] = 1
 
TY5NFunction[2, 1, 4] = 0
 
TY5NFunction[2, 1, 5] = 0
 
TY5NFunction[2, 2, 0] = 0
 
TY5NFunction[2, 2, 1] = 0
 
TY5NFunction[2, 2, 2] = 0
 
TY5NFunction[2, 2, 3] = 0
 
TY5NFunction[2, 2, 4] = 1
 
TY5NFunction[2, 2, 5] = 0
 
TY5NFunction[2, 3, 0] = 1
 
TY5NFunction[2, 3, 1] = 0
 
TY5NFunction[2, 3, 2] = 0
 
TY5NFunction[2, 3, 3] = 0
 
TY5NFunction[2, 3, 4] = 0
 
TY5NFunction[2, 3, 5] = 0
 
TY5NFunction[2, 4, 0] = 0
 
TY5NFunction[2, 4, 1] = 1
 
TY5NFunction[2, 4, 2] = 0
 
TY5NFunction[2, 4, 3] = 0
 
TY5NFunction[2, 4, 4] = 0
 
TY5NFunction[2, 4, 5] = 0
 
TY5NFunction[2, 5, 0] = 0
 
TY5NFunction[2, 5, 1] = 0
 
TY5NFunction[2, 5, 2] = 0
 
TY5NFunction[2, 5, 3] = 0
 
TY5NFunction[2, 5, 4] = 0
 
TY5NFunction[2, 5, 5] = 1
 
TY5NFunction[3, 0, 0] = 0
 
TY5NFunction[3, 0, 1] = 0
 
TY5NFunction[3, 0, 2] = 0
 
TY5NFunction[3, 0, 3] = 1
 
TY5NFunction[3, 0, 4] = 0
 
TY5NFunction[3, 0, 5] = 0
 
TY5NFunction[3, 1, 0] = 0
 
TY5NFunction[3, 1, 1] = 0
 
TY5NFunction[3, 1, 2] = 0
 
TY5NFunction[3, 1, 3] = 0
 
TY5NFunction[3, 1, 4] = 1
 
TY5NFunction[3, 1, 5] = 0
 
TY5NFunction[3, 2, 0] = 1
 
TY5NFunction[3, 2, 1] = 0
 
TY5NFunction[3, 2, 2] = 0
 
TY5NFunction[3, 2, 3] = 0
 
TY5NFunction[3, 2, 4] = 0
 
TY5NFunction[3, 2, 5] = 0
 
TY5NFunction[3, 3, 0] = 0
 
TY5NFunction[3, 3, 1] = 1
 
TY5NFunction[3, 3, 2] = 0
 
TY5NFunction[3, 3, 3] = 0
 
TY5NFunction[3, 3, 4] = 0
 
TY5NFunction[3, 3, 5] = 0
 
TY5NFunction[3, 4, 0] = 0
 
TY5NFunction[3, 4, 1] = 0
 
TY5NFunction[3, 4, 2] = 1
 
TY5NFunction[3, 4, 3] = 0
 
TY5NFunction[3, 4, 4] = 0
 
TY5NFunction[3, 4, 5] = 0
 
TY5NFunction[3, 5, 0] = 0
 
TY5NFunction[3, 5, 1] = 0
 
TY5NFunction[3, 5, 2] = 0
 
TY5NFunction[3, 5, 3] = 0
 
TY5NFunction[3, 5, 4] = 0
 
TY5NFunction[3, 5, 5] = 1
 
TY5NFunction[4, 0, 0] = 0
 
TY5NFunction[4, 0, 1] = 0
 
TY5NFunction[4, 0, 2] = 0
 
TY5NFunction[4, 0, 3] = 0
 
TY5NFunction[4, 0, 4] = 1
 
TY5NFunction[4, 0, 5] = 0
 
TY5NFunction[4, 1, 0] = 1
 
TY5NFunction[4, 1, 1] = 0
 
TY5NFunction[4, 1, 2] = 0
 
TY5NFunction[4, 1, 3] = 0
 
TY5NFunction[4, 1, 4] = 0
 
TY5NFunction[4, 1, 5] = 0
 
TY5NFunction[4, 2, 0] = 0
 
TY5NFunction[4, 2, 1] = 1
 
TY5NFunction[4, 2, 2] = 0
 
TY5NFunction[4, 2, 3] = 0
 
TY5NFunction[4, 2, 4] = 0
 
TY5NFunction[4, 2, 5] = 0
 
TY5NFunction[4, 3, 0] = 0
 
TY5NFunction[4, 3, 1] = 0
 
TY5NFunction[4, 3, 2] = 1
 
TY5NFunction[4, 3, 3] = 0
 
TY5NFunction[4, 3, 4] = 0
 
TY5NFunction[4, 3, 5] = 0
 
TY5NFunction[4, 4, 0] = 0
 
TY5NFunction[4, 4, 1] = 0
 
TY5NFunction[4, 4, 2] = 0
 
TY5NFunction[4, 4, 3] = 1
 
TY5NFunction[4, 4, 4] = 0
 
TY5NFunction[4, 4, 5] = 0
 
TY5NFunction[4, 5, 0] = 0
 
TY5NFunction[4, 5, 1] = 0
 
TY5NFunction[4, 5, 2] = 0
 
TY5NFunction[4, 5, 3] = 0
 
TY5NFunction[4, 5, 4] = 0
 
TY5NFunction[4, 5, 5] = 1
 
TY5NFunction[5, 0, 0] = 0
 
TY5NFunction[5, 0, 1] = 0
 
TY5NFunction[5, 0, 2] = 0
 
TY5NFunction[5, 0, 3] = 0
 
TY5NFunction[5, 0, 4] = 0
 
TY5NFunction[5, 0, 5] = 1
 
TY5NFunction[5, 1, 0] = 0
 
TY5NFunction[5, 1, 1] = 0
 
TY5NFunction[5, 1, 2] = 0
 
TY5NFunction[5, 1, 3] = 0
 
TY5NFunction[5, 1, 4] = 0
 
TY5NFunction[5, 1, 5] = 1
 
TY5NFunction[5, 2, 0] = 0
 
TY5NFunction[5, 2, 1] = 0
 
TY5NFunction[5, 2, 2] = 0
 
TY5NFunction[5, 2, 3] = 0
 
TY5NFunction[5, 2, 4] = 0
 
TY5NFunction[5, 2, 5] = 1
 
TY5NFunction[5, 3, 0] = 0
 
TY5NFunction[5, 3, 1] = 0
 
TY5NFunction[5, 3, 2] = 0
 
TY5NFunction[5, 3, 3] = 0
 
TY5NFunction[5, 3, 4] = 0
 
TY5NFunction[5, 3, 5] = 1
 
TY5NFunction[5, 4, 0] = 0
 
TY5NFunction[5, 4, 1] = 0
 
TY5NFunction[5, 4, 2] = 0
 
TY5NFunction[5, 4, 3] = 0
 
TY5NFunction[5, 4, 4] = 0
 
TY5NFunction[5, 4, 5] = 1
 
TY5NFunction[5, 5, 0] = 1
 
TY5NFunction[5, 5, 1] = 1
 
TY5NFunction[5, 5, 2] = 1
 
TY5NFunction[5, 5, 3] = 1
 
TY5NFunction[5, 5, 4] = 1
 
TY5NFunction[5, 5, 5] = 0
 
TY5NFunction[FusionCategories`Data`TY5`Private`a_, FusionCategories`Data`TY5`Private`b_, FusionCategories`Data`TY5`Private`c_] := 0


 EndPackage[]
