BeginPackage["FusionCategories`Data`fibo`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[fibo] ^= {fiboCat1, fiboCat2}
 
fibo /: fusionCategory[fibo, 1] = fiboCat1
 
fibo /: fusionCategory[fibo, 2] = fiboCat2
 
nFunction[fibo] ^= fiboNFunction
 
noMultiplicities[fibo] ^= True
 
rank[fibo] ^= 2
 
ring[fibo] ^= fibo
balancedCategories[fiboCat1] ^= {fiboCat1Bal1, fiboCat1Bal2}
 
fiboCat1 /: balancedCategory[fiboCat1, 1] = fiboCat1Bal1
 
fiboCat1 /: balancedCategory[fiboCat1, 2] = fiboCat1Bal2
 
braidedCategories[fiboCat1] ^= {fiboCat1Brd1, fiboCat1Brd2}
 
fiboCat1 /: braidedCategory[fiboCat1, 1] = fiboCat1Brd1
 
fiboCat1 /: braidedCategory[fiboCat1, 2] = fiboCat1Brd2
 
coeval[fiboCat1] ^= 1/sixJFunction[fiboCat1][#1, dual[ring[fiboCat1]][#1], 
      #1, #1, 0, 0] & 
 
eval[fiboCat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[fiboCat1] ^= fiboCat1FMatrixFunction
 
fusionCategory[fiboCat1] ^= fiboCat1
 
fiboCat1 /: modularCategory[fiboCat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[fiboCat1] ^= {fiboCat1Piv1}
 
fiboCat1 /: pivotalCategory[fiboCat1, 1] = fiboCat1Piv1
 
fiboCat1 /: pivotalCategory[fiboCat1, {1, 1}] = fiboCat1Piv1
 
fiboCat1 /: ribbonCategory[fiboCat1, 1] = fiboCat1Bal1
 
fiboCat1 /: ribbonCategory[fiboCat1, 2] = fiboCat1Bal2
 
ring[fiboCat1] ^= fibo
 
fiboCat1 /: sphericalCategory[fiboCat1, 1] = fiboCat1Piv1
 
fusionCategoryIndex[fibo][fiboCat1] ^= 1
balancedCategory[fiboCat1Bal1] ^= fiboCat1Bal1
 
braidedCategory[fiboCat1Bal1] ^= fiboCat1Brd1
 
fusionCategory[fiboCat1Bal1] ^= fiboCat1
 
pivotalCategory[fiboCat1Bal1] ^= fiboCat1Piv1
 
ribbonCategory[fiboCat1Bal1] ^= fiboCat1Bal1
 
ring[fiboCat1Bal1] ^= fibo
 
sphericalCategory[fiboCat1Bal1] ^= fiboCat1Piv1
 
(balancedCategoryIndex[braidedCategory[fiboCat1Brd1]][
      balancedCategory[#1]] & )[fiboCat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[fiboCat1]][balancedCategory[#1]] & )[
    fiboCat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[fiboCat1Piv1]][
      balancedCategory[#1]] & )[fiboCat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[fiboCat1Brd1]][ribbonCategory[#1]] & )[
    fiboCat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[fiboCat1]][ribbonCategory[#1]] & )[
    fiboCat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[fiboCat1Piv1]][ribbonCategory[#1]] & )[
    fiboCat1Bal1] ^= 1
balancedCategory[fiboCat1Bal2] ^= fiboCat1Bal2
 
braidedCategory[fiboCat1Bal2] ^= fiboCat1Brd2
 
fusionCategory[fiboCat1Bal2] ^= fiboCat1
 
pivotalCategory[fiboCat1Bal2] ^= fiboCat1Piv1
 
ribbonCategory[fiboCat1Bal2] ^= fiboCat1Bal2
 
ring[fiboCat1Bal2] ^= fibo
 
sphericalCategory[fiboCat1Bal2] ^= fiboCat1Piv1
 
(balancedCategoryIndex[braidedCategory[fiboCat1Brd2]][
      balancedCategory[#1]] & )[fiboCat1Bal2] ^= 1
 
(balancedCategoryIndex[fusionCategory[fiboCat1]][balancedCategory[#1]] & )[
    fiboCat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[fiboCat1Piv1]][
      balancedCategory[#1]] & )[fiboCat1Bal2] ^= 2
 
(ribbonCategoryIndex[braidedCategory[fiboCat1Brd2]][ribbonCategory[#1]] & )[
    fiboCat1Bal2] ^= 1
 
(ribbonCategoryIndex[fusionCategory[fiboCat1]][ribbonCategory[#1]] & )[
    fiboCat1Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[fiboCat1Piv1]][ribbonCategory[#1]] & )[
    fiboCat1Bal2] ^= 2
balancedCategories[fiboCat1Brd1] ^= {fiboCat1Bal1}
 
fiboCat1Brd1 /: balancedCategory[fiboCat1Brd1, 1] = fiboCat1Bal1
 
braidedCategory[fiboCat1Brd1] ^= fiboCat1Brd1
 
fusionCategory[fiboCat1Brd1] ^= fiboCat1
 
fiboCat1Brd1 /: modularCategory[fiboCat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
fiboCat1Brd1 /: ribbonCategory[fiboCat1Brd1, 1] = fiboCat1Bal1
 
ring[fiboCat1Brd1] ^= fibo
 
rMatrixFunction[fiboCat1Brd1] ^= fiboCat1Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[fiboCat1]][braidedCategory[#1]] & )[
    fiboCat1Brd1] ^= 1
braidedCategory[fiboCat1Brd1RMatrixFunction] ^= fiboCat1Brd1
 
fusionCategory[fiboCat1Brd1RMatrixFunction] ^= fiboCat1
 
rMatrixFunction[fiboCat1Brd1RMatrixFunction] ^= fiboCat1Brd1RMatrixFunction
 
fiboCat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
fiboCat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
fiboCat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
fiboCat1Brd1RMatrixFunction[1, 1, 0] = {{(-1)^(4/5)}}
 
fiboCat1Brd1RMatrixFunction[1, 1, 1] = {{-(-1)^(2/5)}}
balancedCategories[fiboCat1Brd2] ^= {fiboCat1Bal2}
 
fiboCat1Brd2 /: balancedCategory[fiboCat1Brd2, 1] = fiboCat1Bal2
 
braidedCategory[fiboCat1Brd2] ^= fiboCat1Brd2
 
fusionCategory[fiboCat1Brd2] ^= fiboCat1
 
fiboCat1Brd2 /: modularCategory[fiboCat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
fiboCat1Brd2 /: ribbonCategory[fiboCat1Brd2, 1] = fiboCat1Bal2
 
ring[fiboCat1Brd2] ^= fibo
 
rMatrixFunction[fiboCat1Brd2] ^= fiboCat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[fiboCat1]][braidedCategory[#1]] & )[
    fiboCat1Brd2] ^= 2
braidedCategory[fiboCat1Brd2RMatrixFunction] ^= fiboCat1Brd2
 
fusionCategory[fiboCat1Brd2RMatrixFunction] ^= fiboCat1
 
rMatrixFunction[fiboCat1Brd2RMatrixFunction] ^= fiboCat1Brd2RMatrixFunction
 
fiboCat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
fiboCat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
fiboCat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
fiboCat1Brd2RMatrixFunction[1, 1, 0] = {{-(-1)^(1/5)}}
 
fiboCat1Brd2RMatrixFunction[1, 1, 1] = {{(-1)^(3/5)}}
fMatrixFunction[fiboCat1FMatrixFunction] ^= fiboCat1FMatrixFunction
 
fusionCategory[fiboCat1FMatrixFunction] ^= fiboCat1
 
ring[fiboCat1FMatrixFunction] ^= fibo
 
fiboCat1FMatrixFunction[1, 1, 1, 1] = 
   {{2/(1 + Sqrt[5]), Sqrt[2/(1 + Sqrt[5])]}, {Sqrt[2/(1 + Sqrt[5])], 
     -2/(1 + Sqrt[5])}}
 
fiboCat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[fiboCat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
fiboCat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[fiboCat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[fiboCat1Piv1] ^= {fiboCat1Bal1, fiboCat1Bal2}
 
fiboCat1Piv1 /: balancedCategory[fiboCat1Piv1, 1] = fiboCat1Bal1
 
fiboCat1Piv1 /: balancedCategory[fiboCat1Piv1, 2] = fiboCat1Bal2
 
fusionCategory[fiboCat1Piv1] ^= fiboCat1
 
fiboCat1Piv1 /: modularCategory[fiboCat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[fiboCat1Piv1] ^= fiboCat1Piv1
 
pivotalIsomorphism[fiboCat1Piv1] ^= fiboCat1Piv1PivotalIsomorphism
 
fiboCat1Piv1 /: ribbonCategory[fiboCat1Piv1, 1] = fiboCat1Bal1
 
fiboCat1Piv1 /: ribbonCategory[fiboCat1Piv1, 2] = fiboCat1Bal2
 
ring[fiboCat1Piv1] ^= fibo
 
sphericalCategory[fiboCat1Piv1] ^= fiboCat1Piv1
 
(pivotalCategoryIndex[fusionCategory[fiboCat1]][pivotalCategory[#1]] & )[
    fiboCat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[fiboCat1]][sphericalCategory[#1]] & )[
    fiboCat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[fiboCat1Piv1PivotalIsomorphism] ^= fiboCat1
 
pivotalCategory[fiboCat1Piv1PivotalIsomorphism] ^= fiboCat1Piv1
 
pivotalIsomorphism[fiboCat1Piv1PivotalIsomorphism] ^= 
   fiboCat1Piv1PivotalIsomorphism
 
fiboCat1Piv1PivotalIsomorphism[0] = 1
 
fiboCat1Piv1PivotalIsomorphism[1] = 1
balancedCategories[fiboCat2] ^= {fiboCat2Bal1, fiboCat2Bal2}
 
fiboCat2 /: balancedCategory[fiboCat2, 1] = fiboCat2Bal1
 
fiboCat2 /: balancedCategory[fiboCat2, 2] = fiboCat2Bal2
 
braidedCategories[fiboCat2] ^= {fiboCat2Brd1, fiboCat2Brd2}
 
fiboCat2 /: braidedCategory[fiboCat2, 1] = fiboCat2Brd1
 
fiboCat2 /: braidedCategory[fiboCat2, 2] = fiboCat2Brd2
 
coeval[fiboCat2] ^= 1/sixJFunction[fiboCat2][#1, dual[ring[fiboCat2]][#1], 
      #1, #1, 0, 0] & 
 
eval[fiboCat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[fiboCat2] ^= fiboCat2FMatrixFunction
 
fusionCategory[fiboCat2] ^= fiboCat2
 
fiboCat2 /: modularCategory[fiboCat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[fiboCat2] ^= {fiboCat2Piv1}
 
fiboCat2 /: pivotalCategory[fiboCat2, 1] = fiboCat2Piv1
 
fiboCat2 /: pivotalCategory[fiboCat2, {1, 1}] = fiboCat2Piv1
 
fiboCat2 /: ribbonCategory[fiboCat2, 1] = fiboCat2Bal1
 
fiboCat2 /: ribbonCategory[fiboCat2, 2] = fiboCat2Bal2
 
ring[fiboCat2] ^= fibo
 
fiboCat2 /: sphericalCategory[fiboCat2, 1] = fiboCat2Piv1
 
fusionCategoryIndex[fibo][fiboCat2] ^= 2
balancedCategory[fiboCat2Bal1] ^= fiboCat2Bal1
 
braidedCategory[fiboCat2Bal1] ^= fiboCat2Brd1
 
fusionCategory[fiboCat2Bal1] ^= fiboCat2
 
pivotalCategory[fiboCat2Bal1] ^= fiboCat2Piv1
 
ribbonCategory[fiboCat2Bal1] ^= fiboCat2Bal1
 
ring[fiboCat2Bal1] ^= fibo
 
sphericalCategory[fiboCat2Bal1] ^= fiboCat2Piv1
 
(balancedCategoryIndex[braidedCategory[fiboCat2Brd1]][
      balancedCategory[#1]] & )[fiboCat2Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[fiboCat2]][balancedCategory[#1]] & )[
    fiboCat2Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[fiboCat2Piv1]][
      balancedCategory[#1]] & )[fiboCat2Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[fiboCat2Brd1]][ribbonCategory[#1]] & )[
    fiboCat2Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[fiboCat2]][ribbonCategory[#1]] & )[
    fiboCat2Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[fiboCat2Piv1]][ribbonCategory[#1]] & )[
    fiboCat2Bal1] ^= 1
balancedCategory[fiboCat2Bal2] ^= fiboCat2Bal2
 
braidedCategory[fiboCat2Bal2] ^= fiboCat2Brd2
 
fusionCategory[fiboCat2Bal2] ^= fiboCat2
 
pivotalCategory[fiboCat2Bal2] ^= fiboCat2Piv1
 
ribbonCategory[fiboCat2Bal2] ^= fiboCat2Bal2
 
ring[fiboCat2Bal2] ^= fibo
 
sphericalCategory[fiboCat2Bal2] ^= fiboCat2Piv1
 
(balancedCategoryIndex[braidedCategory[fiboCat2Brd2]][
      balancedCategory[#1]] & )[fiboCat2Bal2] ^= 1
 
(balancedCategoryIndex[fusionCategory[fiboCat2]][balancedCategory[#1]] & )[
    fiboCat2Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[fiboCat2Piv1]][
      balancedCategory[#1]] & )[fiboCat2Bal2] ^= 2
 
(ribbonCategoryIndex[braidedCategory[fiboCat2Brd2]][ribbonCategory[#1]] & )[
    fiboCat2Bal2] ^= 1
 
(ribbonCategoryIndex[fusionCategory[fiboCat2]][ribbonCategory[#1]] & )[
    fiboCat2Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[fiboCat2Piv1]][ribbonCategory[#1]] & )[
    fiboCat2Bal2] ^= 2
balancedCategories[fiboCat2Brd1] ^= {fiboCat2Bal1}
 
fiboCat2Brd1 /: balancedCategory[fiboCat2Brd1, 1] = fiboCat2Bal1
 
braidedCategory[fiboCat2Brd1] ^= fiboCat2Brd1
 
fusionCategory[fiboCat2Brd1] ^= fiboCat2
 
fiboCat2Brd1 /: modularCategory[fiboCat2Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
fiboCat2Brd1 /: ribbonCategory[fiboCat2Brd1, 1] = fiboCat2Bal1
 
ring[fiboCat2Brd1] ^= fibo
 
rMatrixFunction[fiboCat2Brd1] ^= fiboCat2Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[fiboCat2]][braidedCategory[#1]] & )[
    fiboCat2Brd1] ^= 1
braidedCategory[fiboCat2Brd1RMatrixFunction] ^= fiboCat2Brd1
 
fusionCategory[fiboCat2Brd1RMatrixFunction] ^= fiboCat2
 
rMatrixFunction[fiboCat2Brd1RMatrixFunction] ^= fiboCat2Brd1RMatrixFunction
 
fiboCat2Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
fiboCat2Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
fiboCat2Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
fiboCat2Brd1RMatrixFunction[1, 1, 0] = {{-(-1)^(3/5)}}
 
fiboCat2Brd1RMatrixFunction[1, 1, 1] = {{-(-1)^(4/5)}}
balancedCategories[fiboCat2Brd2] ^= {fiboCat2Bal2}
 
fiboCat2Brd2 /: balancedCategory[fiboCat2Brd2, 1] = fiboCat2Bal2
 
braidedCategory[fiboCat2Brd2] ^= fiboCat2Brd2
 
fusionCategory[fiboCat2Brd2] ^= fiboCat2
 
fiboCat2Brd2 /: modularCategory[fiboCat2Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
fiboCat2Brd2 /: ribbonCategory[fiboCat2Brd2, 1] = fiboCat2Bal2
 
ring[fiboCat2Brd2] ^= fibo
 
rMatrixFunction[fiboCat2Brd2] ^= fiboCat2Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[fiboCat2]][braidedCategory[#1]] & )[
    fiboCat2Brd2] ^= 2
braidedCategory[fiboCat2Brd2RMatrixFunction] ^= fiboCat2Brd2
 
fusionCategory[fiboCat2Brd2RMatrixFunction] ^= fiboCat2
 
rMatrixFunction[fiboCat2Brd2RMatrixFunction] ^= fiboCat2Brd2RMatrixFunction
 
fiboCat2Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
fiboCat2Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
fiboCat2Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
fiboCat2Brd2RMatrixFunction[1, 1, 0] = {{(-1)^(2/5)}}
 
fiboCat2Brd2RMatrixFunction[1, 1, 1] = {{(-1)^(1/5)}}
fMatrixFunction[fiboCat2FMatrixFunction] ^= fiboCat2FMatrixFunction
 
fusionCategory[fiboCat2FMatrixFunction] ^= fiboCat2
 
ring[fiboCat2FMatrixFunction] ^= fibo
 
fiboCat2FMatrixFunction[1, 1, 1, 1] = {{(-1 - Sqrt[5])/2, 1}, 
    {(-1 - Sqrt[5])/2, (1 + Sqrt[5])/2}}
 
fiboCat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[fiboCat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
fiboCat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[fiboCat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[fiboCat2Piv1] ^= {fiboCat2Bal1, fiboCat2Bal2}
 
fiboCat2Piv1 /: balancedCategory[fiboCat2Piv1, 1] = fiboCat2Bal1
 
fiboCat2Piv1 /: balancedCategory[fiboCat2Piv1, 2] = fiboCat2Bal2
 
fusionCategory[fiboCat2Piv1] ^= fiboCat2
 
fiboCat2Piv1 /: modularCategory[fiboCat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[fiboCat2Piv1] ^= fiboCat2Piv1
 
pivotalIsomorphism[fiboCat2Piv1] ^= fiboCat2Piv1PivotalIsomorphism
 
fiboCat2Piv1 /: ribbonCategory[fiboCat2Piv1, 1] = fiboCat2Bal1
 
fiboCat2Piv1 /: ribbonCategory[fiboCat2Piv1, 2] = fiboCat2Bal2
 
ring[fiboCat2Piv1] ^= fibo
 
sphericalCategory[fiboCat2Piv1] ^= fiboCat2Piv1
 
(pivotalCategoryIndex[fusionCategory[fiboCat2]][pivotalCategory[#1]] & )[
    fiboCat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[fiboCat2]][sphericalCategory[#1]] & )[
    fiboCat2Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[fiboCat2Piv1PivotalIsomorphism] ^= fiboCat2
 
pivotalCategory[fiboCat2Piv1PivotalIsomorphism] ^= fiboCat2Piv1
 
pivotalIsomorphism[fiboCat2Piv1PivotalIsomorphism] ^= 
   fiboCat2Piv1PivotalIsomorphism
 
fiboCat2Piv1PivotalIsomorphism[0] = 1
 
fiboCat2Piv1PivotalIsomorphism[1] = 1
ring[fiboNFunction] ^= fibo
 
fiboNFunction[0, 0, 0] = 1
 
fiboNFunction[0, 0, 1] = 0
 
fiboNFunction[0, 1, 0] = 0
 
fiboNFunction[0, 1, 1] = 1
 
fiboNFunction[1, 0, 0] = 0
 
fiboNFunction[1, 0, 1] = 1
 
fiboNFunction[1, 1, 0] = 1
 
fiboNFunction[1, 1, 1] = 1
 
fiboNFunction[FusionCategories`Data`fibo`Private`a_, FusionCategories`Data`fibo`Private`b_, FusionCategories`Data`fibo`Private`c_] := 0


 EndPackage[]
