BeginPackage["FusionCategories`Data`repS3`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[repS3] ^= {repS3Cat1, repS3Cat2, repS3Cat3}
 
repS3 /: fusionCategory[repS3, 1] = repS3Cat1
 
repS3 /: fusionCategory[repS3, 2] = repS3Cat2
 
repS3 /: fusionCategory[repS3, 3] = repS3Cat3
 
nFunction[repS3] ^= repS3NFunction
 
noMultiplicities[repS3] ^= True
 
rank[repS3] ^= 3
 
ring[repS3] ^= repS3
balancedCategories[repS3Cat1] ^= {repS3Cat1Bal1, repS3Cat1Bal2, repS3Cat1Bal3}
 
repS3Cat1 /: balancedCategory[repS3Cat1, 1] = repS3Cat1Bal1
 
repS3Cat1 /: balancedCategory[repS3Cat1, 2] = repS3Cat1Bal2
 
repS3Cat1 /: balancedCategory[repS3Cat1, 3] = repS3Cat1Bal3
 
braidedCategories[repS3Cat1] ^= {repS3Cat1Brd1, repS3Cat1Brd2, repS3Cat1Brd3}
 
repS3Cat1 /: braidedCategory[repS3Cat1, 1] = repS3Cat1Brd1
 
repS3Cat1 /: braidedCategory[repS3Cat1, 2] = repS3Cat1Brd2
 
repS3Cat1 /: braidedCategory[repS3Cat1, 3] = repS3Cat1Brd3
 
coeval[repS3Cat1] ^= 1/sixJFunction[repS3Cat1][#1, dual[ring[repS3Cat1]][#1], 
      #1, #1, 0, 0] & 
 
eval[repS3Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[repS3Cat1] ^= repS3Cat1FMatrixFunction
 
fusionCategory[repS3Cat1] ^= repS3Cat1
 
repS3Cat1 /: modularCategory[repS3Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[repS3Cat1] ^= {repS3Cat1Piv1}
 
repS3Cat1 /: pivotalCategory[repS3Cat1, 1] = repS3Cat1Piv1
 
repS3Cat1 /: pivotalCategory[repS3Cat1, {1, 1, 1}] = repS3Cat1Piv1
 
repS3Cat1 /: ribbonCategory[repS3Cat1, 1] = repS3Cat1Bal1
 
repS3Cat1 /: ribbonCategory[repS3Cat1, 2] = repS3Cat1Bal2
 
repS3Cat1 /: ribbonCategory[repS3Cat1, 3] = repS3Cat1Bal3
 
ring[repS3Cat1] ^= repS3
 
repS3Cat1 /: sphericalCategory[repS3Cat1, 1] = repS3Cat1Piv1
 
repS3Cat1 /: symmetricCategory[repS3Cat1, 1] = repS3Cat1Brd1
 
fusionCategoryIndex[repS3][repS3Cat1] ^= 1
balancedCategory[repS3Cat1Bal1] ^= repS3Cat1Bal1
 
braidedCategory[repS3Cat1Bal1] ^= repS3Cat1Brd1
 
fusionCategory[repS3Cat1Bal1] ^= repS3Cat1
 
pivotalCategory[repS3Cat1Bal1] ^= repS3Cat1Piv1
 
ribbonCategory[repS3Cat1Bal1] ^= repS3Cat1Bal1
 
ring[repS3Cat1Bal1] ^= repS3
 
sphericalCategory[repS3Cat1Bal1] ^= repS3Cat1Piv1
 
symmetricCategory[repS3Cat1Bal1] ^= repS3Cat1Brd1
 
(balancedCategoryIndex[braidedCategory[repS3Cat1Brd1]][
      balancedCategory[#1]] & )[repS3Cat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[repS3Cat1]][balancedCategory[#1]] & )[
    repS3Cat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[repS3Cat1Piv1]][
      balancedCategory[#1]] & )[repS3Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[repS3Cat1Brd1]][ribbonCategory[#1]] & )[
    repS3Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repS3Cat1]][ribbonCategory[#1]] & )[
    repS3Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[repS3Cat1Piv1]][
      ribbonCategory[#1]] & )[repS3Cat1Bal1] ^= 1
balancedCategory[repS3Cat1Bal2] ^= repS3Cat1Bal2
 
braidedCategory[repS3Cat1Bal2] ^= repS3Cat1Brd2
 
fusionCategory[repS3Cat1Bal2] ^= repS3Cat1
 
pivotalCategory[repS3Cat1Bal2] ^= repS3Cat1Piv1
 
ribbonCategory[repS3Cat1Bal2] ^= repS3Cat1Bal2
 
ring[repS3Cat1Bal2] ^= repS3
 
sphericalCategory[repS3Cat1Bal2] ^= repS3Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[repS3Cat1Brd2]][
      balancedCategory[#1]] & )[repS3Cat1Bal2] ^= 1
 
(balancedCategoryIndex[fusionCategory[repS3Cat1]][balancedCategory[#1]] & )[
    repS3Cat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[repS3Cat1Piv1]][
      balancedCategory[#1]] & )[repS3Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[braidedCategory[repS3Cat1Brd2]][ribbonCategory[#1]] & )[
    repS3Cat1Bal2] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repS3Cat1]][ribbonCategory[#1]] & )[
    repS3Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[repS3Cat1Piv1]][
      ribbonCategory[#1]] & )[repS3Cat1Bal2] ^= 2
balancedCategory[repS3Cat1Bal3] ^= repS3Cat1Bal3
 
braidedCategory[repS3Cat1Bal3] ^= repS3Cat1Brd3
 
fusionCategory[repS3Cat1Bal3] ^= repS3Cat1
 
pivotalCategory[repS3Cat1Bal3] ^= repS3Cat1Piv1
 
ribbonCategory[repS3Cat1Bal3] ^= repS3Cat1Bal3
 
ring[repS3Cat1Bal3] ^= repS3
 
sphericalCategory[repS3Cat1Bal3] ^= repS3Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[repS3Cat1Brd3]][
      balancedCategory[#1]] & )[repS3Cat1Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[repS3Cat1]][balancedCategory[#1]] & )[
    repS3Cat1Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[repS3Cat1Piv1]][
      balancedCategory[#1]] & )[repS3Cat1Bal3] ^= 3
 
(ribbonCategoryIndex[braidedCategory[repS3Cat1Brd3]][ribbonCategory[#1]] & )[
    repS3Cat1Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repS3Cat1]][ribbonCategory[#1]] & )[
    repS3Cat1Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[repS3Cat1Piv1]][
      ribbonCategory[#1]] & )[repS3Cat1Bal3] ^= 3
balancedCategories[repS3Cat1Brd1] ^= {repS3Cat1Bal1}
 
repS3Cat1Brd1 /: balancedCategory[repS3Cat1Brd1, 1] = repS3Cat1Bal1
 
braidedCategory[repS3Cat1Brd1] ^= repS3Cat1Brd1
 
fusionCategory[repS3Cat1Brd1] ^= repS3Cat1
 
repS3Cat1Brd1 /: modularCategory[repS3Cat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repS3Cat1Brd1 /: ribbonCategory[repS3Cat1Brd1, 1] = repS3Cat1Bal1
 
ring[repS3Cat1Brd1] ^= repS3
 
rMatrixFunction[repS3Cat1Brd1] ^= repS3Cat1Brd1RMatrixFunction
 
symmetricCategory[repS3Cat1Brd1] ^= repS3Cat1Brd1
 
(braidedCategoryIndex[fusionCategory[repS3Cat1]][braidedCategory[#1]] & )[
    repS3Cat1Brd1] ^= 1
 
(symmetricCategoryIndex[fusionCategory[repS3Cat1]][symmetricCategory[#1]] & )[
    repS3Cat1Brd1] ^= 1
braidedCategory[repS3Cat1Brd1RMatrixFunction] ^= repS3Cat1Brd1
 
fusionCategory[repS3Cat1Brd1RMatrixFunction] ^= repS3Cat1
 
rMatrixFunction[repS3Cat1Brd1RMatrixFunction] ^= repS3Cat1Brd1RMatrixFunction
 
repS3Cat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
repS3Cat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
repS3Cat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
repS3Cat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
repS3Cat1Brd1RMatrixFunction[1, 1, 0] = {{1}}
 
repS3Cat1Brd1RMatrixFunction[1, 2, 2] = {{1}}
 
repS3Cat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
repS3Cat1Brd1RMatrixFunction[2, 1, 2] = {{1}}
 
repS3Cat1Brd1RMatrixFunction[2, 2, 0] = {{1}}
 
repS3Cat1Brd1RMatrixFunction[2, 2, 1] = {{-1}}
 
repS3Cat1Brd1RMatrixFunction[2, 2, 2] = {{1}}
balancedCategories[repS3Cat1Brd2] ^= {repS3Cat1Bal2}
 
repS3Cat1Brd2 /: balancedCategory[repS3Cat1Brd2, 1] = repS3Cat1Bal2
 
braidedCategory[repS3Cat1Brd2] ^= repS3Cat1Brd2
 
fusionCategory[repS3Cat1Brd2] ^= repS3Cat1
 
repS3Cat1Brd2 /: modularCategory[repS3Cat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repS3Cat1Brd2 /: ribbonCategory[repS3Cat1Brd2, 1] = repS3Cat1Bal2
 
ring[repS3Cat1Brd2] ^= repS3
 
rMatrixFunction[repS3Cat1Brd2] ^= repS3Cat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repS3Cat1]][braidedCategory[#1]] & )[
    repS3Cat1Brd2] ^= 2
braidedCategory[repS3Cat1Brd2RMatrixFunction] ^= repS3Cat1Brd2
 
fusionCategory[repS3Cat1Brd2RMatrixFunction] ^= repS3Cat1
 
rMatrixFunction[repS3Cat1Brd2RMatrixFunction] ^= repS3Cat1Brd2RMatrixFunction
 
repS3Cat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
repS3Cat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
repS3Cat1Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
repS3Cat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
repS3Cat1Brd2RMatrixFunction[1, 1, 0] = {{1}}
 
repS3Cat1Brd2RMatrixFunction[1, 2, 2] = {{1}}
 
repS3Cat1Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
repS3Cat1Brd2RMatrixFunction[2, 1, 2] = {{1}}
 
repS3Cat1Brd2RMatrixFunction[2, 2, 0] = {{(-1)^(2/3)}}
 
repS3Cat1Brd2RMatrixFunction[2, 2, 1] = {{-(-1)^(2/3)}}
 
repS3Cat1Brd2RMatrixFunction[2, 2, 2] = {{-(-1)^(1/3)}}
balancedCategories[repS3Cat1Brd3] ^= {repS3Cat1Bal3}
 
repS3Cat1Brd3 /: balancedCategory[repS3Cat1Brd3, 1] = repS3Cat1Bal3
 
braidedCategory[repS3Cat1Brd3] ^= repS3Cat1Brd3
 
fusionCategory[repS3Cat1Brd3] ^= repS3Cat1
 
repS3Cat1Brd3 /: modularCategory[repS3Cat1Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repS3Cat1Brd3 /: ribbonCategory[repS3Cat1Brd3, 1] = repS3Cat1Bal3
 
ring[repS3Cat1Brd3] ^= repS3
 
rMatrixFunction[repS3Cat1Brd3] ^= repS3Cat1Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repS3Cat1]][braidedCategory[#1]] & )[
    repS3Cat1Brd3] ^= 3
braidedCategory[repS3Cat1Brd3RMatrixFunction] ^= repS3Cat1Brd3
 
fusionCategory[repS3Cat1Brd3RMatrixFunction] ^= repS3Cat1
 
rMatrixFunction[repS3Cat1Brd3RMatrixFunction] ^= repS3Cat1Brd3RMatrixFunction
 
repS3Cat1Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
repS3Cat1Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
repS3Cat1Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
repS3Cat1Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
repS3Cat1Brd3RMatrixFunction[1, 1, 0] = {{1}}
 
repS3Cat1Brd3RMatrixFunction[1, 2, 2] = {{1}}
 
repS3Cat1Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
repS3Cat1Brd3RMatrixFunction[2, 1, 2] = {{1}}
 
repS3Cat1Brd3RMatrixFunction[2, 2, 0] = {{-(-1)^(1/3)}}
 
repS3Cat1Brd3RMatrixFunction[2, 2, 1] = {{(-1)^(1/3)}}
 
repS3Cat1Brd3RMatrixFunction[2, 2, 2] = {{(-1)^(2/3)}}
fMatrixFunction[repS3Cat1FMatrixFunction] ^= repS3Cat1FMatrixFunction
 
fusionCategory[repS3Cat1FMatrixFunction] ^= repS3Cat1
 
ring[repS3Cat1FMatrixFunction] ^= repS3
 
repS3Cat1FMatrixFunction[1, 2, 2, 2] = {{-1}}
 
repS3Cat1FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
repS3Cat1FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
repS3Cat1FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
repS3Cat1FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
repS3Cat1FMatrixFunction[2, 2, 1, 2] = {{-1}}
 
repS3Cat1FMatrixFunction[2, 2, 2, 1] = {{-1}}
 
repS3Cat1FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1}, {-1/2, -1/2, 1}, 
    {1/2, -1/2, 0}}
 
repS3Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repS3Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
repS3Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repS3Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[repS3Cat1Piv1] ^= {repS3Cat1Bal1, repS3Cat1Bal2, 
    repS3Cat1Bal3}
 
repS3Cat1Piv1 /: balancedCategory[repS3Cat1Piv1, 1] = repS3Cat1Bal1
 
repS3Cat1Piv1 /: balancedCategory[repS3Cat1Piv1, 2] = repS3Cat1Bal2
 
repS3Cat1Piv1 /: balancedCategory[repS3Cat1Piv1, 3] = repS3Cat1Bal3
 
fusionCategory[repS3Cat1Piv1] ^= repS3Cat1
 
repS3Cat1Piv1 /: modularCategory[repS3Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repS3Cat1Piv1] ^= repS3Cat1Piv1
 
pivotalIsomorphism[repS3Cat1Piv1] ^= repS3Cat1Piv1PivotalIsomorphism
 
repS3Cat1Piv1 /: ribbonCategory[repS3Cat1Piv1, 1] = repS3Cat1Bal1
 
repS3Cat1Piv1 /: ribbonCategory[repS3Cat1Piv1, 2] = repS3Cat1Bal2
 
repS3Cat1Piv1 /: ribbonCategory[repS3Cat1Piv1, 3] = repS3Cat1Bal3
 
ring[repS3Cat1Piv1] ^= repS3
 
sphericalCategory[repS3Cat1Piv1] ^= repS3Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[repS3Cat1]][pivotalCategory[#1]] & )[
    repS3Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[repS3Cat1]][sphericalCategory[#1]] & )[
    repS3Cat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[repS3Cat1Piv1PivotalIsomorphism] ^= repS3Cat1
 
pivotalCategory[repS3Cat1Piv1PivotalIsomorphism] ^= repS3Cat1Piv1
 
pivotalIsomorphism[repS3Cat1Piv1PivotalIsomorphism] ^= 
   repS3Cat1Piv1PivotalIsomorphism
 
repS3Cat1Piv1PivotalIsomorphism[0] = 1
 
repS3Cat1Piv1PivotalIsomorphism[1] = 1
 
repS3Cat1Piv1PivotalIsomorphism[2] = 1
balancedCategories[repS3Cat2] ^= {}
 
braidedCategories[repS3Cat2] ^= {}
 
coeval[repS3Cat2] ^= 1/sixJFunction[repS3Cat2][#1, dual[ring[repS3Cat2]][#1], 
      #1, #1, 0, 0] & 
 
eval[repS3Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[repS3Cat2] ^= repS3Cat2FMatrixFunction
 
fusionCategory[repS3Cat2] ^= repS3Cat2
 
repS3Cat2 /: modularCategory[repS3Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[repS3Cat2] ^= {repS3Cat2Piv1}
 
repS3Cat2 /: pivotalCategory[repS3Cat2, 1] = repS3Cat2Piv1
 
repS3Cat2 /: pivotalCategory[repS3Cat2, {1, 1, 1}] = repS3Cat2Piv1
 
ring[repS3Cat2] ^= repS3
 
repS3Cat2 /: sphericalCategory[repS3Cat2, 1] = repS3Cat2Piv1
 
fusionCategoryIndex[repS3][repS3Cat2] ^= 2
fMatrixFunction[repS3Cat2FMatrixFunction] ^= repS3Cat2FMatrixFunction
 
fusionCategory[repS3Cat2FMatrixFunction] ^= repS3Cat2
 
ring[repS3Cat2FMatrixFunction] ^= repS3
 
repS3Cat2FMatrixFunction[1, 2, 2, 2] = {{-1}}
 
repS3Cat2FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
repS3Cat2FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
repS3Cat2FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
repS3Cat2FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
repS3Cat2FMatrixFunction[2, 2, 1, 2] = {{-1}}
 
repS3Cat2FMatrixFunction[2, 2, 2, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
repS3Cat2FMatrixFunction[2, 2, 2, 1] = {{(1 + I*Sqrt[3])/2}}
 
repS3Cat2FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1}, {-1/2, -1/2, 1}, 
    {(I/4)*(I + Sqrt[3]), (1 - I*Sqrt[3])/4, 0}}
 
repS3Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repS3Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
repS3Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repS3Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[repS3Cat2Piv1] ^= {}
 
fusionCategory[repS3Cat2Piv1] ^= repS3Cat2
 
repS3Cat2Piv1 /: modularCategory[repS3Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repS3Cat2Piv1] ^= repS3Cat2Piv1
 
pivotalIsomorphism[repS3Cat2Piv1] ^= repS3Cat2Piv1PivotalIsomorphism
 
ring[repS3Cat2Piv1] ^= repS3
 
sphericalCategory[repS3Cat2Piv1] ^= repS3Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[repS3Cat2]][pivotalCategory[#1]] & )[
    repS3Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[repS3Cat2]][sphericalCategory[#1]] & )[
    repS3Cat2Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[repS3Cat2Piv1PivotalIsomorphism] ^= repS3Cat2
 
pivotalCategory[repS3Cat2Piv1PivotalIsomorphism] ^= repS3Cat2Piv1
 
pivotalIsomorphism[repS3Cat2Piv1PivotalIsomorphism] ^= 
   repS3Cat2Piv1PivotalIsomorphism
 
repS3Cat2Piv1PivotalIsomorphism[0] = 1
 
repS3Cat2Piv1PivotalIsomorphism[1] = 1
 
repS3Cat2Piv1PivotalIsomorphism[2] = 1
balancedCategories[repS3Cat3] ^= {}
 
braidedCategories[repS3Cat3] ^= {}
 
coeval[repS3Cat3] ^= 1/sixJFunction[repS3Cat3][#1, dual[ring[repS3Cat3]][#1], 
      #1, #1, 0, 0] & 
 
eval[repS3Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[repS3Cat3] ^= repS3Cat3FMatrixFunction
 
fusionCategory[repS3Cat3] ^= repS3Cat3
 
repS3Cat3 /: modularCategory[repS3Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[repS3Cat3] ^= {repS3Cat3Piv1}
 
repS3Cat3 /: pivotalCategory[repS3Cat3, 1] = repS3Cat3Piv1
 
repS3Cat3 /: pivotalCategory[repS3Cat3, {1, 1, 1}] = repS3Cat3Piv1
 
ring[repS3Cat3] ^= repS3
 
repS3Cat3 /: sphericalCategory[repS3Cat3, 1] = repS3Cat3Piv1
 
fusionCategoryIndex[repS3][repS3Cat3] ^= 3
fMatrixFunction[repS3Cat3FMatrixFunction] ^= repS3Cat3FMatrixFunction
 
fusionCategory[repS3Cat3FMatrixFunction] ^= repS3Cat3
 
ring[repS3Cat3FMatrixFunction] ^= repS3
 
repS3Cat3FMatrixFunction[1, 2, 2, 2] = {{-1}}
 
repS3Cat3FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
repS3Cat3FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
repS3Cat3FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
repS3Cat3FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
repS3Cat3FMatrixFunction[2, 2, 1, 2] = {{-1}}
 
repS3Cat3FMatrixFunction[2, 2, 2, 0] = {{(I/2)*(I + Sqrt[3])}}
 
repS3Cat3FMatrixFunction[2, 2, 2, 1] = {{(1 - I*Sqrt[3])/2}}
 
repS3Cat3FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1}, {-1/2, -1/2, 1}, 
    {(-I/4)*(-I + Sqrt[3]), (1 + I*Sqrt[3])/4, 0}}
 
repS3Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repS3Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
repS3Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repS3Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[repS3Cat3Piv1] ^= {}
 
fusionCategory[repS3Cat3Piv1] ^= repS3Cat3
 
repS3Cat3Piv1 /: modularCategory[repS3Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repS3Cat3Piv1] ^= repS3Cat3Piv1
 
pivotalIsomorphism[repS3Cat3Piv1] ^= repS3Cat3Piv1PivotalIsomorphism
 
ring[repS3Cat3Piv1] ^= repS3
 
sphericalCategory[repS3Cat3Piv1] ^= repS3Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[repS3Cat3]][pivotalCategory[#1]] & )[
    repS3Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[repS3Cat3]][sphericalCategory[#1]] & )[
    repS3Cat3Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[repS3Cat3Piv1PivotalIsomorphism] ^= repS3Cat3
 
pivotalCategory[repS3Cat3Piv1PivotalIsomorphism] ^= repS3Cat3Piv1
 
pivotalIsomorphism[repS3Cat3Piv1PivotalIsomorphism] ^= 
   repS3Cat3Piv1PivotalIsomorphism
 
repS3Cat3Piv1PivotalIsomorphism[0] = 1
 
repS3Cat3Piv1PivotalIsomorphism[1] = 1
 
repS3Cat3Piv1PivotalIsomorphism[2] = 1
ring[repS3NFunction] ^= repS3
 
repS3NFunction[0, 0, 0] = 1
 
repS3NFunction[0, 0, 1] = 0
 
repS3NFunction[0, 0, 2] = 0
 
repS3NFunction[0, 1, 0] = 0
 
repS3NFunction[0, 1, 1] = 1
 
repS3NFunction[0, 1, 2] = 0
 
repS3NFunction[0, 2, 0] = 0
 
repS3NFunction[0, 2, 1] = 0
 
repS3NFunction[0, 2, 2] = 1
 
repS3NFunction[1, 0, 0] = 0
 
repS3NFunction[1, 0, 1] = 1
 
repS3NFunction[1, 0, 2] = 0
 
repS3NFunction[1, 1, 0] = 1
 
repS3NFunction[1, 1, 1] = 0
 
repS3NFunction[1, 1, 2] = 0
 
repS3NFunction[1, 2, 0] = 0
 
repS3NFunction[1, 2, 1] = 0
 
repS3NFunction[1, 2, 2] = 1
 
repS3NFunction[2, 0, 0] = 0
 
repS3NFunction[2, 0, 1] = 0
 
repS3NFunction[2, 0, 2] = 1
 
repS3NFunction[2, 1, 0] = 0
 
repS3NFunction[2, 1, 1] = 0
 
repS3NFunction[2, 1, 2] = 1
 
repS3NFunction[2, 2, 0] = 1
 
repS3NFunction[2, 2, 1] = 1
 
repS3NFunction[2, 2, 2] = 1
 
repS3NFunction[FusionCategories`Data`repS3`Private`a_, FusionCategories`Data`repS3`Private`b_, FusionCategories`Data`repS3`Private`c_] := 0


 EndPackage[]
