(* ::Package:: *)

BeginPackage["FusionCategories`Data`doubleS3`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[doubleS3] ^= {doubleS3Cat1, doubleS3Cat2, doubleS3Cat3, 
    doubleS3Cat4, doubleS3Cat5}
 
doubleS3 /: fusionCategory[doubleS3, 1] = doubleS3Cat1
 
doubleS3 /: fusionCategory[doubleS3, 2] = doubleS3Cat2
 
doubleS3 /: fusionCategory[doubleS3, 3] = doubleS3Cat3
 
doubleS3 /: fusionCategory[doubleS3, 4] = doubleS3Cat4
 
doubleS3 /: fusionCategory[doubleS3, 5] = doubleS3Cat5
 
nFunction[doubleS3] ^= doubleS3NFunction
 
noMultiplicities[doubleS3] ^= True
 
rank[doubleS3] ^= 8
 
ring[doubleS3] ^= doubleS3
balancedCategories[doubleS3Cat1] ^= {doubleS3Cat1Bal1, doubleS3Cat1Bal2}
 
doubleS3Cat1 /: balancedCategory[doubleS3Cat1, 1] = doubleS3Cat1Bal1
 
doubleS3Cat1 /: balancedCategory[doubleS3Cat1, 2] = doubleS3Cat1Bal2
 
braidedCategories[doubleS3Cat1] ^= {doubleS3Cat1Brd1}
 
doubleS3Cat1 /: braidedCategory[doubleS3Cat1, 1] = doubleS3Cat1Brd1
 
coeval[doubleS3Cat1] ^= 1/sixJFunction[doubleS3Cat1][#1, 
      dual[ring[doubleS3Cat1]][#1], #1, #1, 0, 0] & 
 
eval[doubleS3Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[doubleS3Cat1] ^= doubleS3Cat1FMatrixFunction
 
fusionCategory[doubleS3Cat1] ^= doubleS3Cat1
 
doubleS3Cat1 /: modularCategory[doubleS3Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[doubleS3Cat1] ^= {doubleS3Cat1Piv1, doubleS3Cat1Piv2}
 
doubleS3Cat1 /: pivotalCategory[doubleS3Cat1, 1] = doubleS3Cat1Piv1
 
doubleS3Cat1 /: pivotalCategory[doubleS3Cat1, 2] = doubleS3Cat1Piv2
 
doubleS3Cat1 /: pivotalCategory[doubleS3Cat1, {1, 1, 1, -1, -1, 1, 1, 1}] = 
    doubleS3Cat1Piv2
 
doubleS3Cat1 /: pivotalCategory[doubleS3Cat1, {1, 1, 1, 1, 1, 1, 1, 1}] = 
    doubleS3Cat1Piv1
 
doubleS3Cat1 /: ribbonCategory[doubleS3Cat1, 1] = doubleS3Cat1Bal1
 
doubleS3Cat1 /: ribbonCategory[doubleS3Cat1, 2] = doubleS3Cat1Bal2
 
ring[doubleS3Cat1] ^= doubleS3
 
doubleS3Cat1 /: sphericalCategory[doubleS3Cat1, 1] = doubleS3Cat1Piv1
 
doubleS3Cat1 /: sphericalCategory[doubleS3Cat1, 2] = doubleS3Cat1Piv2
 
fusionCategoryIndex[doubleS3][doubleS3Cat1] ^= 1
balancedCategory[doubleS3Cat1Bal1] ^= doubleS3Cat1Bal1
 
braidedCategory[doubleS3Cat1Bal1] ^= doubleS3Cat1Brd1
 
fusionCategory[doubleS3Cat1Bal1] ^= doubleS3Cat1
 
pivotalCategory[doubleS3Cat1Bal1] ^= doubleS3Cat1Piv1
 
ribbonCategory[doubleS3Cat1Bal1] ^= doubleS3Cat1Bal1
 
ring[doubleS3Cat1Bal1] ^= doubleS3
 
sphericalCategory[doubleS3Cat1Bal1] ^= doubleS3Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[doubleS3Cat1Brd1]][
      balancedCategory[#1]] & )[doubleS3Cat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[doubleS3Cat1]][
      balancedCategory[#1]] & )[doubleS3Cat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[doubleS3Cat1Piv1]][
      balancedCategory[#1]] & )[doubleS3Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[doubleS3Cat1Brd1]][
      ribbonCategory[#1]] & )[doubleS3Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[doubleS3Cat1]][ribbonCategory[#1]] & )[
    doubleS3Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[doubleS3Cat1Piv1]][
      ribbonCategory[#1]] & )[doubleS3Cat1Bal1] ^= 1
balancedCategory[doubleS3Cat1Bal2] ^= doubleS3Cat1Bal2
 
braidedCategory[doubleS3Cat1Bal2] ^= doubleS3Cat1Brd1
 
fusionCategory[doubleS3Cat1Bal2] ^= doubleS3Cat1
 
pivotalCategory[doubleS3Cat1Bal2] ^= doubleS3Cat1Piv2
 
ribbonCategory[doubleS3Cat1Bal2] ^= doubleS3Cat1Bal2
 
ring[doubleS3Cat1Bal2] ^= doubleS3
 
sphericalCategory[doubleS3Cat1Bal2] ^= doubleS3Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[doubleS3Cat1Brd1]][
      balancedCategory[#1]] & )[doubleS3Cat1Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[doubleS3Cat1]][
      balancedCategory[#1]] & )[doubleS3Cat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[doubleS3Cat1Piv2]][
      balancedCategory[#1]] & )[doubleS3Cat1Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[doubleS3Cat1Brd1]][
      ribbonCategory[#1]] & )[doubleS3Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[doubleS3Cat1]][ribbonCategory[#1]] & )[
    doubleS3Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[doubleS3Cat1Piv2]][
      ribbonCategory[#1]] & )[doubleS3Cat1Bal2] ^= 1
balancedCategories[doubleS3Cat1Brd1] ^= {doubleS3Cat1Bal1, doubleS3Cat1Bal2}
 
doubleS3Cat1Brd1 /: balancedCategory[doubleS3Cat1Brd1, 1] = doubleS3Cat1Bal1
 
doubleS3Cat1Brd1 /: balancedCategory[doubleS3Cat1Brd1, 2] = doubleS3Cat1Bal2
 
braidedCategory[doubleS3Cat1Brd1] ^= doubleS3Cat1Brd1
 
fusionCategory[doubleS3Cat1Brd1] ^= doubleS3Cat1
 
doubleS3Cat1Brd1 /: modularCategory[doubleS3Cat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
doubleS3Cat1Brd1 /: ribbonCategory[doubleS3Cat1Brd1, 1] = doubleS3Cat1Bal1
 
doubleS3Cat1Brd1 /: ribbonCategory[doubleS3Cat1Brd1, 2] = doubleS3Cat1Bal2
 
ring[doubleS3Cat1Brd1] ^= doubleS3
 
rMatrixFunction[doubleS3Cat1Brd1] ^= doubleS3Cat1Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[doubleS3Cat1]][braidedCategory[#1]] & )[
    doubleS3Cat1Brd1] ^= 1
braidedCategory[doubleS3Cat1Brd1RMatrixFunction] ^= doubleS3Cat1Brd1
 
fusionCategory[doubleS3Cat1Brd1RMatrixFunction] ^= doubleS3Cat1
 
rMatrixFunction[doubleS3Cat1Brd1RMatrixFunction] ^= 
   doubleS3Cat1Brd1RMatrixFunction
 
doubleS3Cat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[0, 5, 5] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[0, 6, 6] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[0, 7, 7] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[1, 1, 0] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[1, 2, 2] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[1, 3, 4] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[1, 4, 3] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[1, 5, 5] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[1, 6, 6] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[1, 7, 7] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[2, 1, 2] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[2, 2, 0] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[2, 2, 1] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3Cat1Brd1RMatrixFunction[2, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[2, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[2, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[2, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[2, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[2, 5, 6] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[2, 5, 7] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[2, 6, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[2, 6, 7] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[2, 7, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[2, 7, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 1, 4] = {{-1}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 3, 0] = {{I}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 3, 2] = {{-(-1)^(1/6)}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 3, 5] = {{-(-1)^(5/6)}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 3, 6] = {{I}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 3, 7] = {{I}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 4, 1] = {{-I}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 4, 2] = {{(-1)^(1/6)}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 4, 5] = {{(-1)^(5/6)}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 4, 6] = {{-I}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 4, 7] = {{-I}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 6, 3] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 6, 4] = {{-1}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 7, 3] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[3, 7, 4] = {{-1}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 1, 3] = {{-1}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 2, 3] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 3, 1] = {{I}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 3, 2] = {{-(-1)^(1/6)}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 3, 5] = {{-(-1)^(5/6)}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 3, 6] = {{I}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 3, 7] = {{I}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 4, 0] = {{-I}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 4, 2] = {{(-1)^(1/6)}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 4, 5] = {{(-1)^(5/6)}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 4, 6] = {{-I}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 4, 7] = {{-I}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 5, 3] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 6, 3] = {{-1}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 6, 4] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 7, 3] = {{-1}}
 
doubleS3Cat1Brd1RMatrixFunction[4, 7, 4] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[5, 0, 5] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[5, 1, 5] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[5, 2, 6] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[5, 2, 7] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[5, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[5, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[5, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[5, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[5, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[5, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3Cat1Brd1RMatrixFunction[5, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[5, 6, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[5, 6, 7] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[5, 7, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[5, 7, 6] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[6, 0, 6] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[6, 1, 6] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[6, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[6, 2, 7] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[6, 3, 3] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[6, 3, 4] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[6, 4, 3] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[6, 4, 4] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[6, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[6, 5, 7] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[6, 6, 0] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[6, 6, 1] = {{-1}}
 
doubleS3Cat1Brd1RMatrixFunction[6, 6, 6] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[6, 7, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[6, 7, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[7, 0, 7] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[7, 1, 7] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[7, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[7, 2, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[7, 3, 3] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[7, 3, 4] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[7, 4, 3] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[7, 4, 4] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[7, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[7, 5, 6] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[7, 6, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[7, 6, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat1Brd1RMatrixFunction[7, 7, 0] = {{1}}
 
doubleS3Cat1Brd1RMatrixFunction[7, 7, 1] = {{-1}}
 
doubleS3Cat1Brd1RMatrixFunction[7, 7, 7] = {{1}}
fMatrixFunction[doubleS3Cat1FMatrixFunction] ^= doubleS3Cat1FMatrixFunction
 
fusionCategory[doubleS3Cat1FMatrixFunction] ^= doubleS3Cat1
 
ring[doubleS3Cat1FMatrixFunction] ^= doubleS3
 
doubleS3Cat1FMatrixFunction[1, 2, 2, 2] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 2, 6, 7] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 2, 7, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 2, 7, 6] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 3, 3, 2] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 3, 3, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 3, 3, 6] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 3, 3, 7] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 3, 4, 2] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 3, 4, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 3, 4, 6] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 3, 4, 7] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 4, 3, 2] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 4, 3, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 4, 3, 6] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 4, 3, 7] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 4, 4, 2] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 4, 4, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 4, 4, 6] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 4, 4, 7] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 5, 2, 6] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 5, 5, 0] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 5, 5, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 5, 5, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 5, 6, 7] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 5, 7, 2] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 6, 2, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 6, 2, 7] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 6, 6, 0] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 6, 6, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 6, 6, 6] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 6, 7, 2] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 7, 2, 6] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 7, 6, 2] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 7, 6, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 7, 7, 0] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 7, 7, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[1, 7, 7, 7] = {{-1}}
 
doubleS3Cat1FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
doubleS3Cat1FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[2, 1, 5, 6] = {{-1}}
 
doubleS3Cat1FMatrixFunction[2, 1, 6, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[2, 1, 7, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
doubleS3Cat1FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[2, 2, 1, 2] = {{-1}}
 
doubleS3Cat1FMatrixFunction[2, 2, 2, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, -(1/Sqrt[2])}, 
    {-1/2, -1/2, -(1/Sqrt[2])}, {-(1/Sqrt[2]), 1/Sqrt[2], 0}}
 
doubleS3Cat1FMatrixFunction[2, 2, 3, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 2, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[2, 2, 4, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[2, 2, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 2, 5, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 2, 6, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 2, 7, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 3, 2, 3] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[2, 3, 2, 4] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[2, 3, 3, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 3, 3, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 3, 3, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 3, 3, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 3, 4, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[2, 3, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 3, 4, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[2, 3, 4, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[2, 3, 5, 3] = {{1, 0}, {0, 1}}
 
doubleS3Cat1FMatrixFunction[2, 3, 5, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[2, 3, 6, 3] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[2, 3, 6, 4] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[2, 3, 7, 3] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[2, 3, 7, 4] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[2, 4, 2, 3] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[2, 4, 2, 4] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[2, 4, 3, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[2, 4, 3, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 4, 3, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[2, 4, 3, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[2, 4, 4, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 4, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 4, 4, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 4, 4, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 4, 5, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[2, 4, 5, 4] = {{1, 0}, {0, 1}}
 
doubleS3Cat1FMatrixFunction[2, 4, 6, 3] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[2, 4, 6, 4] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[2, 4, 7, 3] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[2, 4, 7, 4] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[2, 5, 1, 6] = {{-1}}
 
doubleS3Cat1FMatrixFunction[2, 5, 2, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[2, 5, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 5, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 5, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 5, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 5, 5, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 5, 6, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[2, 5, 7, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[2, 6, 1, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[2, 6, 1, 7] = {{-1}}
 
doubleS3Cat1FMatrixFunction[2, 6, 2, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[2, 6, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 6, 3, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[2, 6, 4, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[2, 6, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 6, 5, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[2, 6, 6, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 7, 1, 6] = {{-1}}
 
doubleS3Cat1FMatrixFunction[2, 7, 2, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[2, 7, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 7, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[2, 7, 4, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[2, 7, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[2, 7, 7, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 2, 2, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 2, 2, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 2, 3, 2] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[3, 2, 3, 5] = {{1, 0}, {0, 1}}
 
doubleS3Cat1FMatrixFunction[3, 2, 3, 6] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[3, 2, 3, 7] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[3, 2, 4, 2] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[3, 2, 4, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[3, 2, 4, 6] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[3, 2, 4, 7] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[3, 2, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 2, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 2, 6, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 2, 6, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 2, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 2, 7, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 3, 1, 2] = {{-1}}
 
doubleS3Cat1FMatrixFunction[3, 3, 1, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[3, 3, 1, 6] = {{-1}}
 
doubleS3Cat1FMatrixFunction[3, 3, 1, 7] = {{-1}}
 
doubleS3Cat1FMatrixFunction[3, 3, 2, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[3, 3, 2, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 3, 2, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 3, 2, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 3, 2, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 3, 3, 3] = 
   {{-1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, {Sqrt[2]/3, -2/3, 1/3, 1/3, 1/3}, 
    {Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}, {Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}}
 
doubleS3Cat1FMatrixFunction[3, 3, 3, 4] = 
   {{I/Sqrt[3], 0, I/Sqrt[3], I/Sqrt[3]}, {0, (-I)/Sqrt[3], I/Sqrt[3], 
     (-I)/Sqrt[3]}, {I/Sqrt[3], I/Sqrt[3], 0, (-I)/Sqrt[3]}, 
    {I/Sqrt[3], (-I)/Sqrt[3], (-I)/Sqrt[3], 0}}
 
doubleS3Cat1FMatrixFunction[3, 3, 4, 3] = 
   {{(-I)/Sqrt[3], 0, (-I)/Sqrt[3], (-I)/Sqrt[3]}, 
    {0, I/Sqrt[3], (-I)/Sqrt[3], I/Sqrt[3]}, {(-I)/Sqrt[3], (-I)/Sqrt[3], 0, 
     I/Sqrt[3]}, {(-I)/Sqrt[3], I/Sqrt[3], I/Sqrt[3], 0}}
 
doubleS3Cat1FMatrixFunction[3, 3, 4, 4] = 
   {{-1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {-Sqrt[2]/3, -1/3, 2/3, -1/3, -1/3}, {-Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, 
    {-Sqrt[2]/3, -1/3, -1/3, 2/3, -1/3}, {-Sqrt[2]/3, -1/3, -1/3, -1/3, 2/3}}
 
doubleS3Cat1FMatrixFunction[3, 3, 5, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 3, 5, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 3, 5, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 3, 5, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 3, 6, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 3, 6, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 3, 6, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 3, 6, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 3, 7, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 3, 7, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 3, 7, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 3, 7, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 4, 1, 2] = {{-1}}
 
doubleS3Cat1FMatrixFunction[3, 4, 1, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[3, 4, 1, 6] = {{-1}}
 
doubleS3Cat1FMatrixFunction[3, 4, 1, 7] = {{-1}}
 
doubleS3Cat1FMatrixFunction[3, 4, 2, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[3, 4, 2, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 4, 2, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 4, 2, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 4, 2, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 4, 3, 3] = 
   {{I/Sqrt[3], 0, I/Sqrt[3], I/Sqrt[3]}, {0, (-I)/Sqrt[3], I/Sqrt[3], 
     (-I)/Sqrt[3]}, {I/Sqrt[3], I/Sqrt[3], 0, (-I)/Sqrt[3]}, 
    {I/Sqrt[3], (-I)/Sqrt[3], (-I)/Sqrt[3], 0}}
 
doubleS3Cat1FMatrixFunction[3, 4, 3, 4] = 
   {{-1/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {-Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, {-Sqrt[2]/3, -2/3, 1/3, 1/3, 1/3}, 
    {-Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}, {-Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}}
 
doubleS3Cat1FMatrixFunction[3, 4, 4, 3] = 
   {{-1/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {Sqrt[2]/3, -1/3, 2/3, -1/3, -1/3}, {Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, 
    {Sqrt[2]/3, -1/3, -1/3, 2/3, -1/3}, {Sqrt[2]/3, -1/3, -1/3, -1/3, 2/3}}
 
doubleS3Cat1FMatrixFunction[3, 4, 4, 4] = 
   {{(-I)/Sqrt[3], 0, (-I)/Sqrt[3], (-I)/Sqrt[3]}, 
    {0, I/Sqrt[3], (-I)/Sqrt[3], I/Sqrt[3]}, {(-I)/Sqrt[3], (-I)/Sqrt[3], 0, 
     I/Sqrt[3]}, {(-I)/Sqrt[3], I/Sqrt[3], I/Sqrt[3], 0}}
 
doubleS3Cat1FMatrixFunction[3, 4, 5, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 4, 5, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 4, 5, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 4, 5, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 4, 6, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 4, 6, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 4, 6, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 4, 6, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 4, 7, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 4, 7, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 4, 7, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 4, 7, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 5, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 5, 2, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 5, 3, 2] = {{1, 0}, {0, 1}}
 
doubleS3Cat1FMatrixFunction[3, 5, 3, 5] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[3, 5, 3, 6] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[3, 5, 3, 7] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[3, 5, 4, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[3, 5, 4, 5] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[3, 5, 4, 6] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[3, 5, 4, 7] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[3, 5, 5, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 5, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 5, 6, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 5, 6, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 5, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 5, 7, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 6, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 6, 2, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 6, 3, 2] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[3, 6, 3, 5] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[3, 6, 3, 6] = {{1, 0}, {0, 1}}
 
doubleS3Cat1FMatrixFunction[3, 6, 3, 7] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[3, 6, 4, 2] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[3, 6, 4, 5] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[3, 6, 4, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[3, 6, 4, 7] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[3, 6, 5, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 6, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 6, 6, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 6, 6, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 6, 7, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 6, 7, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 7, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 7, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 7, 3, 2] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[3, 7, 3, 5] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[3, 7, 3, 6] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[3, 7, 3, 7] = {{1, 0}, {0, 1}}
 
doubleS3Cat1FMatrixFunction[3, 7, 4, 2] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[3, 7, 4, 5] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[3, 7, 4, 6] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[3, 7, 4, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[3, 7, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 7, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 7, 6, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 7, 6, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[3, 7, 7, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[3, 7, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 2, 2, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 2, 2, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 2, 3, 2] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[4, 2, 3, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[4, 2, 3, 6] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[4, 2, 3, 7] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[4, 2, 4, 2] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[4, 2, 4, 5] = {{1, 0}, {0, 1}}
 
doubleS3Cat1FMatrixFunction[4, 2, 4, 6] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[4, 2, 4, 7] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[4, 2, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 2, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 2, 6, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 2, 6, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 2, 7, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 2, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 3, 1, 2] = {{-1}}
 
doubleS3Cat1FMatrixFunction[4, 3, 1, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[4, 3, 1, 6] = {{-1}}
 
doubleS3Cat1FMatrixFunction[4, 3, 1, 7] = {{-1}}
 
doubleS3Cat1FMatrixFunction[4, 3, 2, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[4, 3, 2, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 3, 2, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 3, 2, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 3, 2, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 3, 3, 3] = 
   {{(-I)/Sqrt[3], 0, (-I)/Sqrt[3], (-I)/Sqrt[3]}, 
    {0, I/Sqrt[3], (-I)/Sqrt[3], I/Sqrt[3]}, {(-I)/Sqrt[3], (-I)/Sqrt[3], 0, 
     I/Sqrt[3]}, {(-I)/Sqrt[3], I/Sqrt[3], I/Sqrt[3], 0}}
 
doubleS3Cat1FMatrixFunction[4, 3, 3, 4] = 
   {{-1/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {Sqrt[2]/3, -1/3, 2/3, -1/3, -1/3}, {Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, 
    {Sqrt[2]/3, -1/3, -1/3, 2/3, -1/3}, {Sqrt[2]/3, -1/3, -1/3, -1/3, 2/3}}
 
doubleS3Cat1FMatrixFunction[4, 3, 4, 3] = 
   {{-1/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {-Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, {-Sqrt[2]/3, -2/3, 1/3, 1/3, 1/3}, 
    {-Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}, {-Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}}
 
doubleS3Cat1FMatrixFunction[4, 3, 4, 4] = 
   {{I/Sqrt[3], 0, I/Sqrt[3], I/Sqrt[3]}, {0, (-I)/Sqrt[3], I/Sqrt[3], 
     (-I)/Sqrt[3]}, {I/Sqrt[3], I/Sqrt[3], 0, (-I)/Sqrt[3]}, 
    {I/Sqrt[3], (-I)/Sqrt[3], (-I)/Sqrt[3], 0}}
 
doubleS3Cat1FMatrixFunction[4, 3, 5, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 3, 5, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 3, 5, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 3, 5, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 3, 6, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 3, 6, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 3, 6, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 3, 6, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 3, 7, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 3, 7, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 3, 7, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 3, 7, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 4, 1, 2] = {{-1}}
 
doubleS3Cat1FMatrixFunction[4, 4, 1, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[4, 4, 1, 6] = {{-1}}
 
doubleS3Cat1FMatrixFunction[4, 4, 1, 7] = {{-1}}
 
doubleS3Cat1FMatrixFunction[4, 4, 2, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[4, 4, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 4, 2, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 4, 2, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 4, 2, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 4, 3, 3] = 
   {{-1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {-Sqrt[2]/3, -1/3, 2/3, -1/3, -1/3}, {-Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, 
    {-Sqrt[2]/3, -1/3, -1/3, 2/3, -1/3}, {-Sqrt[2]/3, -1/3, -1/3, -1/3, 2/3}}
 
doubleS3Cat1FMatrixFunction[4, 4, 3, 4] = 
   {{(-I)/Sqrt[3], 0, (-I)/Sqrt[3], (-I)/Sqrt[3]}, 
    {0, I/Sqrt[3], (-I)/Sqrt[3], I/Sqrt[3]}, {(-I)/Sqrt[3], (-I)/Sqrt[3], 0, 
     I/Sqrt[3]}, {(-I)/Sqrt[3], I/Sqrt[3], I/Sqrt[3], 0}}
 
doubleS3Cat1FMatrixFunction[4, 4, 4, 3] = 
   {{I/Sqrt[3], 0, I/Sqrt[3], I/Sqrt[3]}, {0, (-I)/Sqrt[3], I/Sqrt[3], 
     (-I)/Sqrt[3]}, {I/Sqrt[3], I/Sqrt[3], 0, (-I)/Sqrt[3]}, 
    {I/Sqrt[3], (-I)/Sqrt[3], (-I)/Sqrt[3], 0}}
 
doubleS3Cat1FMatrixFunction[4, 4, 4, 4] = 
   {{-1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, {Sqrt[2]/3, -2/3, 1/3, 1/3, 1/3}, 
    {Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}, {Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}}
 
doubleS3Cat1FMatrixFunction[4, 4, 5, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 4, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 4, 5, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 4, 5, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 4, 6, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 4, 6, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 4, 6, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 4, 6, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 4, 7, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 4, 7, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 4, 7, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 4, 7, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 5, 2, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 5, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 5, 3, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[4, 5, 3, 5] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[4, 5, 3, 6] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[4, 5, 3, 7] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[4, 5, 4, 2] = {{1, 0}, {0, 1}}
 
doubleS3Cat1FMatrixFunction[4, 5, 4, 5] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[4, 5, 4, 6] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[4, 5, 4, 7] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[4, 5, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 5, 5, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 5, 6, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 5, 6, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 5, 7, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 5, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 6, 2, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 6, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 6, 3, 2] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[4, 6, 3, 5] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[4, 6, 3, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[4, 6, 3, 7] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[4, 6, 4, 2] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[4, 6, 4, 5] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[4, 6, 4, 6] = {{1, 0}, {0, 1}}
 
doubleS3Cat1FMatrixFunction[4, 6, 4, 7] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[4, 6, 5, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 6, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 6, 6, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 6, 6, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 6, 7, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 6, 7, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 7, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 7, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 7, 3, 2] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[4, 7, 3, 5] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[4, 7, 3, 6] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[4, 7, 3, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[4, 7, 4, 2] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[4, 7, 4, 5] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[4, 7, 4, 6] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[4, 7, 4, 7] = {{1, 0}, {0, 1}}
 
doubleS3Cat1FMatrixFunction[4, 7, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 7, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 7, 6, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 7, 6, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[4, 7, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[4, 7, 7, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 1, 2, 6] = {{-1}}
 
doubleS3Cat1FMatrixFunction[5, 1, 5, 0] = {{-1}}
 
doubleS3Cat1FMatrixFunction[5, 1, 5, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[5, 1, 6, 7] = {{-1}}
 
doubleS3Cat1FMatrixFunction[5, 1, 7, 2] = {{-1}}
 
doubleS3Cat1FMatrixFunction[5, 2, 2, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[5, 2, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[5, 2, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[5, 2, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[5, 2, 5, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[5, 2, 6, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[5, 3, 2, 3] = {{1, 0}, {0, 1}}
 
doubleS3Cat1FMatrixFunction[5, 3, 2, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[5, 3, 3, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[5, 3, 3, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[5, 3, 3, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 3, 3, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[5, 3, 3, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 3, 4, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[5, 3, 4, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[5, 3, 4, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[5, 3, 4, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[5, 3, 4, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 3, 5, 3] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[5, 3, 5, 4] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[5, 3, 6, 3] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[5, 3, 6, 4] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[5, 3, 7, 3] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[5, 3, 7, 4] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[5, 4, 2, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[5, 4, 2, 4] = {{1, 0}, {0, 1}}
 
doubleS3Cat1FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[5, 4, 3, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[5, 4, 3, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[5, 4, 3, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 4, 3, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 4, 4, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[5, 4, 4, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[5, 4, 4, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 4, 4, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 4, 4, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 4, 5, 3] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[5, 4, 5, 4] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[5, 4, 6, 3] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[5, 4, 6, 4] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[5, 4, 7, 3] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[5, 4, 7, 4] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[5, 5, 1, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[5, 5, 2, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 5, 3, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 5, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[5, 5, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[5, 5, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 5, 5, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[5, 5, 5, 5] = {{1/2, -1/2, -(1/Sqrt[2])}, 
    {1/2, -1/2, 1/Sqrt[2]}, {-(1/Sqrt[2]), -(1/Sqrt[2]), 0}}
 
doubleS3Cat1FMatrixFunction[5, 5, 6, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[5, 5, 7, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 6, 2, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[5, 6, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[5, 6, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 6, 4, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[5, 6, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 6, 5, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[5, 6, 6, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 6, 7, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[5, 7, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 7, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 7, 4, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 7, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[5, 7, 5, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[5, 7, 7, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 1, 2, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[6, 1, 5, 7] = {{-1}}
 
doubleS3Cat1FMatrixFunction[6, 1, 6, 0] = {{-1}}
 
doubleS3Cat1FMatrixFunction[6, 1, 6, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[6, 1, 7, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[6, 2, 1, 7] = {{-1}}
 
doubleS3Cat1FMatrixFunction[6, 2, 2, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 2, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 2, 4, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 2, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 2, 5, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[6, 2, 6, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[6, 2, 7, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[6, 3, 2, 3] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[6, 3, 2, 4] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[6, 3, 3, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[6, 3, 3, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 3, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 3, 3, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 3, 3, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 3, 4, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[6, 3, 4, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 3, 4, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 3, 4, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 3, 4, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 3, 5, 3] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[6, 3, 5, 4] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[6, 3, 6, 3] = {{1, 0}, {0, 1}}
 
doubleS3Cat1FMatrixFunction[6, 3, 6, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[6, 3, 7, 3] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[6, 3, 7, 4] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[6, 4, 2, 3] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[6, 4, 2, 4] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[6, 4, 3, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[6, 4, 3, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 4, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 4, 3, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 4, 3, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 4, 4, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[6, 4, 4, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 4, 4, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 4, 4, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 4, 4, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 4, 5, 3] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[6, 4, 5, 4] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[6, 4, 6, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[6, 4, 6, 4] = {{1, 0}, {0, 1}}
 
doubleS3Cat1FMatrixFunction[6, 4, 7, 3] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[6, 4, 7, 4] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[6, 5, 1, 7] = {{-1}}
 
doubleS3Cat1FMatrixFunction[6, 5, 2, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[6, 5, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 5, 3, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 5, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 5, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 5, 5, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 5, 6, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[6, 6, 1, 6] = {{-1}}
 
doubleS3Cat1FMatrixFunction[6, 6, 2, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 6, 3, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 6, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 6, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 6, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 6, 5, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 6, 6, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[6, 6, 6, 6] = {{1/2, -1/2, -(1/Sqrt[2])}, 
    {1/2, -1/2, 1/Sqrt[2]}, {-(1/Sqrt[2]), -(1/Sqrt[2]), 0}}
 
doubleS3Cat1FMatrixFunction[6, 6, 7, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 7, 1, 2] = {{-1}}
 
doubleS3Cat1FMatrixFunction[6, 7, 1, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[6, 7, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 7, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[6, 7, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 7, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[6, 7, 6, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[6, 7, 7, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 1, 2, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[7, 1, 5, 2] = {{-1}}
 
doubleS3Cat1FMatrixFunction[7, 1, 6, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[7, 1, 7, 0] = {{-1}}
 
doubleS3Cat1FMatrixFunction[7, 1, 7, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[7, 2, 1, 5] = {{-1}}
 
doubleS3Cat1FMatrixFunction[7, 2, 1, 6] = {{-1}}
 
doubleS3Cat1FMatrixFunction[7, 2, 2, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[7, 2, 3, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 2, 4, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 2, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[7, 2, 6, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[7, 2, 7, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[7, 3, 2, 3] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[7, 3, 2, 4] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[7, 3, 3, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[7, 3, 3, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[7, 3, 3, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 3, 3, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[7, 3, 3, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 3, 4, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[7, 3, 4, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 3, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 3, 4, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[7, 3, 4, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[7, 3, 5, 3] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[7, 3, 5, 4] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[7, 3, 6, 3] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[7, 3, 6, 4] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[7, 3, 7, 3] = {{1, 0}, {0, 1}}
 
doubleS3Cat1FMatrixFunction[7, 3, 7, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[7, 4, 2, 3] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[7, 4, 2, 4] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[7, 4, 3, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[7, 4, 3, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 4, 3, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 4, 3, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 4, 3, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[7, 4, 4, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[7, 4, 4, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[7, 4, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 4, 4, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 4, 4, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 4, 5, 3] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[7, 4, 5, 4] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[7, 4, 6, 3] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat1FMatrixFunction[7, 4, 6, 4] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat1FMatrixFunction[7, 4, 7, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[7, 4, 7, 4] = {{1, 0}, {0, 1}}
 
doubleS3Cat1FMatrixFunction[7, 5, 1, 2] = {{-1}}
 
doubleS3Cat1FMatrixFunction[7, 5, 2, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[7, 5, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 5, 3, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 5, 4, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 5, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 5, 5, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[7, 5, 7, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[7, 6, 1, 2] = {{-1}}
 
doubleS3Cat1FMatrixFunction[7, 6, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[7, 6, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 6, 4, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[7, 6, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 6, 5, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[7, 6, 6, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 6, 7, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat1FMatrixFunction[7, 7, 1, 7] = {{-1}}
 
doubleS3Cat1FMatrixFunction[7, 7, 2, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 7, 3, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 7, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[7, 7, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[7, 7, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 7, 5, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat1FMatrixFunction[7, 7, 6, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat1FMatrixFunction[7, 7, 7, 1] = {{-1}}
 
doubleS3Cat1FMatrixFunction[7, 7, 7, 7] = {{1/2, -1/2, -(1/Sqrt[2])}, 
    {1/2, -1/2, 1/Sqrt[2]}, {-(1/Sqrt[2]), -(1/Sqrt[2]), 0}}
 
doubleS3Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
doubleS3Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[doubleS3Cat1Piv1] ^= {doubleS3Cat1Bal1}
 
doubleS3Cat1Piv1 /: balancedCategory[doubleS3Cat1Piv1, 1] = doubleS3Cat1Bal1
 
fusionCategory[doubleS3Cat1Piv1] ^= doubleS3Cat1
 
doubleS3Cat1Piv1 /: modularCategory[doubleS3Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[doubleS3Cat1Piv1] ^= doubleS3Cat1Piv1
 
pivotalIsomorphism[doubleS3Cat1Piv1] ^= doubleS3Cat1Piv1PivotalIsomorphism
 
doubleS3Cat1Piv1 /: ribbonCategory[doubleS3Cat1Piv1, 1] = doubleS3Cat1Bal1
 
ring[doubleS3Cat1Piv1] ^= doubleS3
 
sphericalCategory[doubleS3Cat1Piv1] ^= doubleS3Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[doubleS3Cat1]][pivotalCategory[#1]] & )[
    doubleS3Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[doubleS3Cat1]][
      sphericalCategory[#1]] & )[doubleS3Cat1Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[doubleS3Cat1Piv1PivotalIsomorphism] ^= doubleS3Cat1
 
pivotalCategory[doubleS3Cat1Piv1PivotalIsomorphism] ^= doubleS3Cat1Piv1
 
pivotalIsomorphism[doubleS3Cat1Piv1PivotalIsomorphism] ^= 
   doubleS3Cat1Piv1PivotalIsomorphism
 
doubleS3Cat1Piv1PivotalIsomorphism[0] = 1
 
doubleS3Cat1Piv1PivotalIsomorphism[1] = 1
 
doubleS3Cat1Piv1PivotalIsomorphism[2] = 1
 
doubleS3Cat1Piv1PivotalIsomorphism[3] = 1
 
doubleS3Cat1Piv1PivotalIsomorphism[4] = 1
 
doubleS3Cat1Piv1PivotalIsomorphism[5] = 1
 
doubleS3Cat1Piv1PivotalIsomorphism[6] = 1
 
doubleS3Cat1Piv1PivotalIsomorphism[7] = 1
balancedCategories[doubleS3Cat1Piv2] ^= {doubleS3Cat1Bal2}
 
doubleS3Cat1Piv2 /: balancedCategory[doubleS3Cat1Piv2, 1] = doubleS3Cat1Bal2
 
fusionCategory[doubleS3Cat1Piv2] ^= doubleS3Cat1
 
doubleS3Cat1Piv2 /: modularCategory[doubleS3Cat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[doubleS3Cat1Piv2] ^= doubleS3Cat1Piv2
 
pivotalIsomorphism[doubleS3Cat1Piv2] ^= doubleS3Cat1Piv2PivotalIsomorphism
 
doubleS3Cat1Piv2 /: ribbonCategory[doubleS3Cat1Piv2, 1] = doubleS3Cat1Bal2
 
ring[doubleS3Cat1Piv2] ^= doubleS3
 
sphericalCategory[doubleS3Cat1Piv2] ^= doubleS3Cat1Piv2
 
(pivotalCategoryIndex[fusionCategory[doubleS3Cat1]][pivotalCategory[#1]] & )[
    doubleS3Cat1Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[doubleS3Cat1]][
      sphericalCategory[#1]] & )[doubleS3Cat1Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[doubleS3Cat1Piv2PivotalIsomorphism] ^= doubleS3Cat1
 
pivotalCategory[doubleS3Cat1Piv2PivotalIsomorphism] ^= doubleS3Cat1Piv2
 
pivotalIsomorphism[doubleS3Cat1Piv2PivotalIsomorphism] ^= 
   doubleS3Cat1Piv2PivotalIsomorphism
 
doubleS3Cat1Piv2PivotalIsomorphism[0] = 1
 
doubleS3Cat1Piv2PivotalIsomorphism[1] = 1
 
doubleS3Cat1Piv2PivotalIsomorphism[2] = 1
 
doubleS3Cat1Piv2PivotalIsomorphism[3] = -1
 
doubleS3Cat1Piv2PivotalIsomorphism[4] = -1
 
doubleS3Cat1Piv2PivotalIsomorphism[5] = 1
 
doubleS3Cat1Piv2PivotalIsomorphism[6] = 1
 
doubleS3Cat1Piv2PivotalIsomorphism[7] = 1
balancedCategories[doubleS3Cat2] ^= {doubleS3Cat2Bal1, doubleS3Cat2Bal2}
 
doubleS3Cat2 /: balancedCategory[doubleS3Cat2, 1] = doubleS3Cat2Bal1
 
doubleS3Cat2 /: balancedCategory[doubleS3Cat2, 2] = doubleS3Cat2Bal2
 
braidedCategories[doubleS3Cat2] ^= {doubleS3Cat2Brd1}
 
doubleS3Cat2 /: braidedCategory[doubleS3Cat2, 1] = doubleS3Cat2Brd1
 
coeval[doubleS3Cat2] ^= 1/sixJFunction[doubleS3Cat2][#1, 
      dual[ring[doubleS3Cat2]][#1], #1, #1, 0, 0] & 
 
eval[doubleS3Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[doubleS3Cat2] ^= doubleS3Cat2FMatrixFunction
 
fusionCategory[doubleS3Cat2] ^= doubleS3Cat2
 
doubleS3Cat2 /: modularCategory[doubleS3Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[doubleS3Cat2] ^= {doubleS3Cat2Piv1, doubleS3Cat2Piv2}
 
doubleS3Cat2 /: pivotalCategory[doubleS3Cat2, 1] = doubleS3Cat2Piv1
 
doubleS3Cat2 /: pivotalCategory[doubleS3Cat2, 2] = doubleS3Cat2Piv2
 
doubleS3Cat2 /: pivotalCategory[doubleS3Cat2, {1, 1, 1, -1, -1, 1, 1, 1}] = 
    doubleS3Cat2Piv2
 
doubleS3Cat2 /: pivotalCategory[doubleS3Cat2, {1, 1, 1, 1, 1, 1, 1, 1}] = 
    doubleS3Cat2Piv1
 
doubleS3Cat2 /: ribbonCategory[doubleS3Cat2, 1] = doubleS3Cat2Bal1
 
doubleS3Cat2 /: ribbonCategory[doubleS3Cat2, 2] = doubleS3Cat2Bal2
 
ring[doubleS3Cat2] ^= doubleS3
 
doubleS3Cat2 /: sphericalCategory[doubleS3Cat2, 1] = doubleS3Cat2Piv1
 
doubleS3Cat2 /: sphericalCategory[doubleS3Cat2, 2] = doubleS3Cat2Piv2
 
fusionCategoryIndex[doubleS3][doubleS3Cat2] ^= 2
balancedCategory[doubleS3Cat2Bal1] ^= doubleS3Cat2Bal1
 
braidedCategory[doubleS3Cat2Bal1] ^= doubleS3Cat2Brd1
 
fusionCategory[doubleS3Cat2Bal1] ^= doubleS3Cat2
 
pivotalCategory[doubleS3Cat2Bal1] ^= doubleS3Cat2Piv1
 
ribbonCategory[doubleS3Cat2Bal1] ^= doubleS3Cat2Bal1
 
ring[doubleS3Cat2Bal1] ^= doubleS3
 
sphericalCategory[doubleS3Cat2Bal1] ^= doubleS3Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[doubleS3Cat2Brd1]][
      balancedCategory[#1]] & )[doubleS3Cat2Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[doubleS3Cat2]][
      balancedCategory[#1]] & )[doubleS3Cat2Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[doubleS3Cat2Piv1]][
      balancedCategory[#1]] & )[doubleS3Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[doubleS3Cat2Brd1]][
      ribbonCategory[#1]] & )[doubleS3Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[doubleS3Cat2]][ribbonCategory[#1]] & )[
    doubleS3Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[doubleS3Cat2Piv1]][
      ribbonCategory[#1]] & )[doubleS3Cat2Bal1] ^= 1
balancedCategory[doubleS3Cat2Bal2] ^= doubleS3Cat2Bal2
 
braidedCategory[doubleS3Cat2Bal2] ^= doubleS3Cat2Brd1
 
fusionCategory[doubleS3Cat2Bal2] ^= doubleS3Cat2
 
pivotalCategory[doubleS3Cat2Bal2] ^= doubleS3Cat2Piv2
 
ribbonCategory[doubleS3Cat2Bal2] ^= doubleS3Cat2Bal2
 
ring[doubleS3Cat2Bal2] ^= doubleS3
 
sphericalCategory[doubleS3Cat2Bal2] ^= doubleS3Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[doubleS3Cat2Brd1]][
      balancedCategory[#1]] & )[doubleS3Cat2Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[doubleS3Cat2]][
      balancedCategory[#1]] & )[doubleS3Cat2Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[doubleS3Cat2Piv2]][
      balancedCategory[#1]] & )[doubleS3Cat2Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[doubleS3Cat2Brd1]][
      ribbonCategory[#1]] & )[doubleS3Cat2Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[doubleS3Cat2]][ribbonCategory[#1]] & )[
    doubleS3Cat2Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[doubleS3Cat2Piv2]][
      ribbonCategory[#1]] & )[doubleS3Cat2Bal2] ^= 1
balancedCategories[doubleS3Cat2Brd1] ^= {doubleS3Cat2Bal1, doubleS3Cat2Bal2}
 
doubleS3Cat2Brd1 /: balancedCategory[doubleS3Cat2Brd1, 1] = doubleS3Cat2Bal1
 
doubleS3Cat2Brd1 /: balancedCategory[doubleS3Cat2Brd1, 2] = doubleS3Cat2Bal2
 
braidedCategory[doubleS3Cat2Brd1] ^= doubleS3Cat2Brd1
 
fusionCategory[doubleS3Cat2Brd1] ^= doubleS3Cat2
 
doubleS3Cat2Brd1 /: modularCategory[doubleS3Cat2Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
doubleS3Cat2Brd1 /: ribbonCategory[doubleS3Cat2Brd1, 1] = doubleS3Cat2Bal1
 
doubleS3Cat2Brd1 /: ribbonCategory[doubleS3Cat2Brd1, 2] = doubleS3Cat2Bal2
 
ring[doubleS3Cat2Brd1] ^= doubleS3
 
rMatrixFunction[doubleS3Cat2Brd1] ^= doubleS3Cat2Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[doubleS3Cat2]][braidedCategory[#1]] & )[
    doubleS3Cat2Brd1] ^= 1
braidedCategory[doubleS3Cat2Brd1RMatrixFunction] ^= doubleS3Cat2Brd1
 
fusionCategory[doubleS3Cat2Brd1RMatrixFunction] ^= doubleS3Cat2
 
rMatrixFunction[doubleS3Cat2Brd1RMatrixFunction] ^= 
   doubleS3Cat2Brd1RMatrixFunction
 
doubleS3Cat2Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[0, 5, 5] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[0, 6, 6] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[0, 7, 7] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[1, 1, 0] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[1, 2, 2] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[1, 3, 4] = {{-1}}
 
doubleS3Cat2Brd1RMatrixFunction[1, 4, 3] = {{-1}}
 
doubleS3Cat2Brd1RMatrixFunction[1, 5, 5] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[1, 6, 6] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[1, 7, 7] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[2, 1, 2] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[2, 2, 0] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[2, 2, 1] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3Cat2Brd1RMatrixFunction[2, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[2, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[2, 3, 4] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3Cat2Brd1RMatrixFunction[2, 4, 3] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3Cat2Brd1RMatrixFunction[2, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[2, 5, 6] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[2, 5, 7] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[2, 6, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[2, 6, 7] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[2, 7, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[2, 7, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 1, 4] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 3, 0] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 3, 6] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 3, 7] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 4, 1] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 4, 6] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 4, 7] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 6, 3] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 6, 4] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 7, 3] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[3, 7, 4] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 1, 3] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 3, 1] = {{-1}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 3, 5] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 3, 6] = {{-1}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 3, 7] = {{-1}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 4, 0] = {{-1}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 4, 2] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 4, 6] = {{-1}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 4, 7] = {{-1}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 6, 3] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 6, 4] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 7, 3] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[4, 7, 4] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[5, 0, 5] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[5, 1, 5] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[5, 2, 6] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[5, 2, 7] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[5, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[5, 3, 4] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3Cat2Brd1RMatrixFunction[5, 4, 3] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3Cat2Brd1RMatrixFunction[5, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[5, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[5, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3Cat2Brd1RMatrixFunction[5, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[5, 6, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[5, 6, 7] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[5, 7, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[5, 7, 6] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[6, 0, 6] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[6, 1, 6] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[6, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[6, 2, 7] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[6, 3, 3] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[6, 3, 4] = {{-1}}
 
doubleS3Cat2Brd1RMatrixFunction[6, 4, 3] = {{-1}}
 
doubleS3Cat2Brd1RMatrixFunction[6, 4, 4] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[6, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[6, 5, 7] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[6, 6, 0] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[6, 6, 1] = {{-1}}
 
doubleS3Cat2Brd1RMatrixFunction[6, 6, 6] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[6, 7, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[6, 7, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[7, 0, 7] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[7, 1, 7] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[7, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[7, 2, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[7, 3, 3] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[7, 3, 4] = {{-1}}
 
doubleS3Cat2Brd1RMatrixFunction[7, 4, 3] = {{-1}}
 
doubleS3Cat2Brd1RMatrixFunction[7, 4, 4] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[7, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[7, 5, 6] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[7, 6, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[7, 6, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat2Brd1RMatrixFunction[7, 7, 0] = {{1}}
 
doubleS3Cat2Brd1RMatrixFunction[7, 7, 1] = {{-1}}
 
doubleS3Cat2Brd1RMatrixFunction[7, 7, 7] = {{1}}
fMatrixFunction[doubleS3Cat2FMatrixFunction] ^= doubleS3Cat2FMatrixFunction
 
fusionCategory[doubleS3Cat2FMatrixFunction] ^= doubleS3Cat2
 
ring[doubleS3Cat2FMatrixFunction] ^= doubleS3
 
doubleS3Cat2FMatrixFunction[1, 2, 2, 2] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 2, 6, 7] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 2, 7, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 2, 7, 6] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 3, 3, 2] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 3, 3, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 3, 3, 6] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 3, 3, 7] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 3, 4, 2] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 3, 4, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 3, 4, 6] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 3, 4, 7] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 4, 3, 2] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 4, 3, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 4, 3, 6] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 4, 3, 7] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 4, 4, 2] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 4, 4, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 4, 4, 6] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 4, 4, 7] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 5, 2, 6] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 5, 5, 0] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 5, 5, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 5, 5, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 5, 6, 7] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 5, 7, 2] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 6, 2, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 6, 2, 7] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 6, 6, 0] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 6, 6, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 6, 6, 6] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 6, 7, 2] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 7, 2, 6] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 7, 6, 2] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 7, 6, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 7, 7, 0] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 7, 7, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[1, 7, 7, 7] = {{-1}}
 
doubleS3Cat2FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
doubleS3Cat2FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[2, 1, 5, 6] = {{-1}}
 
doubleS3Cat2FMatrixFunction[2, 1, 6, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[2, 1, 7, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
doubleS3Cat2FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[2, 2, 1, 2] = {{-1}}
 
doubleS3Cat2FMatrixFunction[2, 2, 2, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, -(1/Sqrt[2])}, 
    {-1/2, -1/2, -(1/Sqrt[2])}, {-(1/Sqrt[2]), 1/Sqrt[2], 0}}
 
doubleS3Cat2FMatrixFunction[2, 2, 3, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 2, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[2, 2, 4, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[2, 2, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 2, 5, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 2, 6, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 2, 7, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 3, 2, 3] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[2, 3, 2, 4] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[2, 3, 3, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 3, 3, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 3, 3, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 3, 3, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 3, 4, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[2, 3, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 3, 4, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[2, 3, 4, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[2, 3, 5, 3] = {{1, 0}, {0, 1}}
 
doubleS3Cat2FMatrixFunction[2, 3, 5, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[2, 3, 6, 3] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[2, 3, 6, 4] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[2, 3, 7, 3] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[2, 3, 7, 4] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[2, 4, 2, 3] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[2, 4, 2, 4] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[2, 4, 3, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[2, 4, 3, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 4, 3, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[2, 4, 3, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[2, 4, 4, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 4, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 4, 4, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 4, 4, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 4, 5, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[2, 4, 5, 4] = {{1, 0}, {0, 1}}
 
doubleS3Cat2FMatrixFunction[2, 4, 6, 3] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[2, 4, 6, 4] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[2, 4, 7, 3] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[2, 4, 7, 4] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[2, 5, 1, 6] = {{-1}}
 
doubleS3Cat2FMatrixFunction[2, 5, 2, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[2, 5, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 5, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 5, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 5, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 5, 5, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 5, 6, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[2, 5, 7, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[2, 6, 1, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[2, 6, 1, 7] = {{-1}}
 
doubleS3Cat2FMatrixFunction[2, 6, 2, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[2, 6, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 6, 3, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[2, 6, 4, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[2, 6, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 6, 5, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[2, 6, 6, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 7, 1, 6] = {{-1}}
 
doubleS3Cat2FMatrixFunction[2, 7, 2, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[2, 7, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 7, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[2, 7, 4, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[2, 7, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[2, 7, 7, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 2, 2, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 2, 2, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 2, 3, 2] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[3, 2, 3, 5] = {{1, 0}, {0, 1}}
 
doubleS3Cat2FMatrixFunction[3, 2, 3, 6] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[3, 2, 3, 7] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[3, 2, 4, 2] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[3, 2, 4, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[3, 2, 4, 6] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[3, 2, 4, 7] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[3, 2, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 2, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 2, 6, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 2, 6, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 2, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 2, 7, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 3, 1, 2] = {{-1}}
 
doubleS3Cat2FMatrixFunction[3, 3, 1, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[3, 3, 1, 6] = {{-1}}
 
doubleS3Cat2FMatrixFunction[3, 3, 1, 7] = {{-1}}
 
doubleS3Cat2FMatrixFunction[3, 3, 2, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[3, 3, 2, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 3, 2, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 3, 2, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 3, 2, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 3, 3, 3] = 
   {{1/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {-Sqrt[2]/3, -1/3, 2/3, -1/3, -1/3}, {-Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, 
    {-Sqrt[2]/3, -1/3, -1/3, 2/3, -1/3}, {-Sqrt[2]/3, -1/3, -1/3, -1/3, 2/3}}
 
doubleS3Cat2FMatrixFunction[3, 3, 3, 4] = 
   {{I/Sqrt[3], 0, I/Sqrt[3], I/Sqrt[3]}, {0, (-I)/Sqrt[3], I/Sqrt[3], 
     (-I)/Sqrt[3]}, {I/Sqrt[3], I/Sqrt[3], 0, (-I)/Sqrt[3]}, 
    {I/Sqrt[3], (-I)/Sqrt[3], (-I)/Sqrt[3], 0}}
 
doubleS3Cat2FMatrixFunction[3, 3, 4, 3] = 
   {{(-I)/Sqrt[3], 0, (-I)/Sqrt[3], (-I)/Sqrt[3]}, 
    {0, I/Sqrt[3], (-I)/Sqrt[3], I/Sqrt[3]}, {(-I)/Sqrt[3], (-I)/Sqrt[3], 0, 
     I/Sqrt[3]}, {(-I)/Sqrt[3], I/Sqrt[3], I/Sqrt[3], 0}}
 
doubleS3Cat2FMatrixFunction[3, 3, 4, 4] = 
   {{1/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, {Sqrt[2]/3, -2/3, 1/3, 1/3, 1/3}, 
    {Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}, {Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}}
 
doubleS3Cat2FMatrixFunction[3, 3, 5, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 3, 5, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 3, 5, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 3, 5, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 3, 6, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 3, 6, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 3, 6, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 3, 6, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 3, 7, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 3, 7, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 3, 7, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 3, 7, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 4, 1, 2] = {{-1}}
 
doubleS3Cat2FMatrixFunction[3, 4, 1, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[3, 4, 1, 6] = {{-1}}
 
doubleS3Cat2FMatrixFunction[3, 4, 1, 7] = {{-1}}
 
doubleS3Cat2FMatrixFunction[3, 4, 2, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[3, 4, 2, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 4, 2, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 4, 2, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 4, 2, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 4, 3, 3] = 
   {{I/Sqrt[3], 0, I/Sqrt[3], I/Sqrt[3]}, {0, (-I)/Sqrt[3], I/Sqrt[3], 
     (-I)/Sqrt[3]}, {I/Sqrt[3], I/Sqrt[3], 0, (-I)/Sqrt[3]}, 
    {I/Sqrt[3], (-I)/Sqrt[3], (-I)/Sqrt[3], 0}}
 
doubleS3Cat2FMatrixFunction[3, 4, 3, 4] = 
   {{1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {Sqrt[2]/3, -1/3, 2/3, -1/3, -1/3}, {Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, 
    {Sqrt[2]/3, -1/3, -1/3, 2/3, -1/3}, {Sqrt[2]/3, -1/3, -1/3, -1/3, 2/3}}
 
doubleS3Cat2FMatrixFunction[3, 4, 4, 3] = 
   {{1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {-Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, {-Sqrt[2]/3, -2/3, 1/3, 1/3, 1/3}, 
    {-Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}, {-Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}}
 
doubleS3Cat2FMatrixFunction[3, 4, 4, 4] = 
   {{(-I)/Sqrt[3], 0, (-I)/Sqrt[3], (-I)/Sqrt[3]}, 
    {0, I/Sqrt[3], (-I)/Sqrt[3], I/Sqrt[3]}, {(-I)/Sqrt[3], (-I)/Sqrt[3], 0, 
     I/Sqrt[3]}, {(-I)/Sqrt[3], I/Sqrt[3], I/Sqrt[3], 0}}
 
doubleS3Cat2FMatrixFunction[3, 4, 5, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 4, 5, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 4, 5, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 4, 5, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 4, 6, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 4, 6, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 4, 6, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 4, 6, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 4, 7, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 4, 7, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 4, 7, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 4, 7, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 5, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 5, 2, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 5, 3, 2] = {{1, 0}, {0, 1}}
 
doubleS3Cat2FMatrixFunction[3, 5, 3, 5] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[3, 5, 3, 6] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[3, 5, 3, 7] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[3, 5, 4, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[3, 5, 4, 5] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[3, 5, 4, 6] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[3, 5, 4, 7] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[3, 5, 5, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 5, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 5, 6, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 5, 6, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 5, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 5, 7, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 6, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 6, 2, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 6, 3, 2] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[3, 6, 3, 5] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[3, 6, 3, 6] = {{1, 0}, {0, 1}}
 
doubleS3Cat2FMatrixFunction[3, 6, 3, 7] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[3, 6, 4, 2] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[3, 6, 4, 5] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[3, 6, 4, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[3, 6, 4, 7] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[3, 6, 5, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 6, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 6, 6, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 6, 6, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 6, 7, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 6, 7, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 7, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 7, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 7, 3, 2] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[3, 7, 3, 5] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[3, 7, 3, 6] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[3, 7, 3, 7] = {{1, 0}, {0, 1}}
 
doubleS3Cat2FMatrixFunction[3, 7, 4, 2] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[3, 7, 4, 5] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[3, 7, 4, 6] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[3, 7, 4, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[3, 7, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 7, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 7, 6, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 7, 6, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[3, 7, 7, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[3, 7, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 2, 2, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 2, 2, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 2, 3, 2] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[4, 2, 3, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[4, 2, 3, 6] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[4, 2, 3, 7] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[4, 2, 4, 2] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[4, 2, 4, 5] = {{1, 0}, {0, 1}}
 
doubleS3Cat2FMatrixFunction[4, 2, 4, 6] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[4, 2, 4, 7] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[4, 2, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 2, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 2, 6, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 2, 6, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 2, 7, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 2, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 3, 1, 2] = {{-1}}
 
doubleS3Cat2FMatrixFunction[4, 3, 1, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[4, 3, 1, 6] = {{-1}}
 
doubleS3Cat2FMatrixFunction[4, 3, 1, 7] = {{-1}}
 
doubleS3Cat2FMatrixFunction[4, 3, 2, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[4, 3, 2, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 3, 2, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 3, 2, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 3, 2, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 3, 3, 3] = 
   {{(-I)/Sqrt[3], 0, (-I)/Sqrt[3], (-I)/Sqrt[3]}, 
    {0, I/Sqrt[3], (-I)/Sqrt[3], I/Sqrt[3]}, {(-I)/Sqrt[3], (-I)/Sqrt[3], 0, 
     I/Sqrt[3]}, {(-I)/Sqrt[3], I/Sqrt[3], I/Sqrt[3], 0}}
 
doubleS3Cat2FMatrixFunction[4, 3, 3, 4] = 
   {{1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {-Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, {-Sqrt[2]/3, -2/3, 1/3, 1/3, 1/3}, 
    {-Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}, {-Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}}
 
doubleS3Cat2FMatrixFunction[4, 3, 4, 3] = 
   {{1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {Sqrt[2]/3, -1/3, 2/3, -1/3, -1/3}, {Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, 
    {Sqrt[2]/3, -1/3, -1/3, 2/3, -1/3}, {Sqrt[2]/3, -1/3, -1/3, -1/3, 2/3}}
 
doubleS3Cat2FMatrixFunction[4, 3, 4, 4] = 
   {{I/Sqrt[3], 0, I/Sqrt[3], I/Sqrt[3]}, {0, (-I)/Sqrt[3], I/Sqrt[3], 
     (-I)/Sqrt[3]}, {I/Sqrt[3], I/Sqrt[3], 0, (-I)/Sqrt[3]}, 
    {I/Sqrt[3], (-I)/Sqrt[3], (-I)/Sqrt[3], 0}}
 
doubleS3Cat2FMatrixFunction[4, 3, 5, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 3, 5, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 3, 5, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 3, 5, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 3, 6, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 3, 6, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 3, 6, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 3, 6, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 3, 7, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 3, 7, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 3, 7, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 3, 7, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 4, 1, 2] = {{-1}}
 
doubleS3Cat2FMatrixFunction[4, 4, 1, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[4, 4, 1, 6] = {{-1}}
 
doubleS3Cat2FMatrixFunction[4, 4, 1, 7] = {{-1}}
 
doubleS3Cat2FMatrixFunction[4, 4, 2, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[4, 4, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 4, 2, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 4, 2, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 4, 2, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 4, 3, 3] = 
   {{1/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, {Sqrt[2]/3, -2/3, 1/3, 1/3, 1/3}, 
    {Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}, {Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}}
 
doubleS3Cat2FMatrixFunction[4, 4, 3, 4] = 
   {{(-I)/Sqrt[3], 0, (-I)/Sqrt[3], (-I)/Sqrt[3]}, 
    {0, I/Sqrt[3], (-I)/Sqrt[3], I/Sqrt[3]}, {(-I)/Sqrt[3], (-I)/Sqrt[3], 0, 
     I/Sqrt[3]}, {(-I)/Sqrt[3], I/Sqrt[3], I/Sqrt[3], 0}}
 
doubleS3Cat2FMatrixFunction[4, 4, 4, 3] = 
   {{I/Sqrt[3], 0, I/Sqrt[3], I/Sqrt[3]}, {0, (-I)/Sqrt[3], I/Sqrt[3], 
     (-I)/Sqrt[3]}, {I/Sqrt[3], I/Sqrt[3], 0, (-I)/Sqrt[3]}, 
    {I/Sqrt[3], (-I)/Sqrt[3], (-I)/Sqrt[3], 0}}
 
doubleS3Cat2FMatrixFunction[4, 4, 4, 4] = 
   {{1/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {-Sqrt[2]/3, -1/3, 2/3, -1/3, -1/3}, {-Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, 
    {-Sqrt[2]/3, -1/3, -1/3, 2/3, -1/3}, {-Sqrt[2]/3, -1/3, -1/3, -1/3, 2/3}}
 
doubleS3Cat2FMatrixFunction[4, 4, 5, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 4, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 4, 5, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 4, 5, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 4, 6, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 4, 6, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 4, 6, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 4, 6, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 4, 7, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 4, 7, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 4, 7, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 4, 7, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 5, 2, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 5, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 5, 3, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[4, 5, 3, 5] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[4, 5, 3, 6] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[4, 5, 3, 7] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[4, 5, 4, 2] = {{1, 0}, {0, 1}}
 
doubleS3Cat2FMatrixFunction[4, 5, 4, 5] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[4, 5, 4, 6] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[4, 5, 4, 7] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[4, 5, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 5, 5, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 5, 6, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 5, 6, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 5, 7, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 5, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 6, 2, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 6, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 6, 3, 2] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[4, 6, 3, 5] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[4, 6, 3, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[4, 6, 3, 7] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[4, 6, 4, 2] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[4, 6, 4, 5] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[4, 6, 4, 6] = {{1, 0}, {0, 1}}
 
doubleS3Cat2FMatrixFunction[4, 6, 4, 7] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[4, 6, 5, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 6, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 6, 6, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 6, 6, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 6, 7, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 6, 7, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 7, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 7, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 7, 3, 2] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[4, 7, 3, 5] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[4, 7, 3, 6] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[4, 7, 3, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[4, 7, 4, 2] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[4, 7, 4, 5] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[4, 7, 4, 6] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[4, 7, 4, 7] = {{1, 0}, {0, 1}}
 
doubleS3Cat2FMatrixFunction[4, 7, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 7, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 7, 6, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 7, 6, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[4, 7, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[4, 7, 7, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 1, 2, 6] = {{-1}}
 
doubleS3Cat2FMatrixFunction[5, 1, 5, 0] = {{-1}}
 
doubleS3Cat2FMatrixFunction[5, 1, 5, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[5, 1, 6, 7] = {{-1}}
 
doubleS3Cat2FMatrixFunction[5, 1, 7, 2] = {{-1}}
 
doubleS3Cat2FMatrixFunction[5, 2, 2, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[5, 2, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[5, 2, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[5, 2, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[5, 2, 5, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[5, 2, 6, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[5, 3, 2, 3] = {{1, 0}, {0, 1}}
 
doubleS3Cat2FMatrixFunction[5, 3, 2, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[5, 3, 3, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[5, 3, 3, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[5, 3, 3, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 3, 3, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[5, 3, 3, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 3, 4, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[5, 3, 4, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[5, 3, 4, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[5, 3, 4, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[5, 3, 4, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 3, 5, 3] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[5, 3, 5, 4] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[5, 3, 6, 3] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[5, 3, 6, 4] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[5, 3, 7, 3] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[5, 3, 7, 4] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[5, 4, 2, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[5, 4, 2, 4] = {{1, 0}, {0, 1}}
 
doubleS3Cat2FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[5, 4, 3, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[5, 4, 3, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[5, 4, 3, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 4, 3, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 4, 4, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[5, 4, 4, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[5, 4, 4, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 4, 4, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 4, 4, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 4, 5, 3] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[5, 4, 5, 4] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[5, 4, 6, 3] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[5, 4, 6, 4] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[5, 4, 7, 3] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[5, 4, 7, 4] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[5, 5, 1, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[5, 5, 2, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 5, 3, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 5, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[5, 5, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[5, 5, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 5, 5, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[5, 5, 5, 5] = {{1/2, -1/2, -(1/Sqrt[2])}, 
    {1/2, -1/2, 1/Sqrt[2]}, {-(1/Sqrt[2]), -(1/Sqrt[2]), 0}}
 
doubleS3Cat2FMatrixFunction[5, 5, 6, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[5, 5, 7, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 6, 2, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[5, 6, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[5, 6, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 6, 4, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[5, 6, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 6, 5, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[5, 6, 6, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 6, 7, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[5, 7, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 7, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 7, 4, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 7, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[5, 7, 5, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[5, 7, 7, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 1, 2, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[6, 1, 5, 7] = {{-1}}
 
doubleS3Cat2FMatrixFunction[6, 1, 6, 0] = {{-1}}
 
doubleS3Cat2FMatrixFunction[6, 1, 6, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[6, 1, 7, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[6, 2, 1, 7] = {{-1}}
 
doubleS3Cat2FMatrixFunction[6, 2, 2, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 2, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 2, 4, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 2, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 2, 5, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[6, 2, 6, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[6, 2, 7, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[6, 3, 2, 3] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[6, 3, 2, 4] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[6, 3, 3, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[6, 3, 3, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 3, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 3, 3, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 3, 3, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 3, 4, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[6, 3, 4, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 3, 4, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 3, 4, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 3, 4, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 3, 5, 3] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[6, 3, 5, 4] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[6, 3, 6, 3] = {{1, 0}, {0, 1}}
 
doubleS3Cat2FMatrixFunction[6, 3, 6, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[6, 3, 7, 3] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[6, 3, 7, 4] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[6, 4, 2, 3] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[6, 4, 2, 4] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[6, 4, 3, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[6, 4, 3, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 4, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 4, 3, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 4, 3, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 4, 4, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[6, 4, 4, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 4, 4, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 4, 4, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 4, 4, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 4, 5, 3] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[6, 4, 5, 4] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[6, 4, 6, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[6, 4, 6, 4] = {{1, 0}, {0, 1}}
 
doubleS3Cat2FMatrixFunction[6, 4, 7, 3] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[6, 4, 7, 4] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[6, 5, 1, 7] = {{-1}}
 
doubleS3Cat2FMatrixFunction[6, 5, 2, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[6, 5, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 5, 3, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 5, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 5, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 5, 5, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 5, 6, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[6, 6, 1, 6] = {{-1}}
 
doubleS3Cat2FMatrixFunction[6, 6, 2, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 6, 3, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 6, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 6, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 6, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 6, 5, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 6, 6, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[6, 6, 6, 6] = {{1/2, -1/2, -(1/Sqrt[2])}, 
    {1/2, -1/2, 1/Sqrt[2]}, {-(1/Sqrt[2]), -(1/Sqrt[2]), 0}}
 
doubleS3Cat2FMatrixFunction[6, 6, 7, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 7, 1, 2] = {{-1}}
 
doubleS3Cat2FMatrixFunction[6, 7, 1, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[6, 7, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 7, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[6, 7, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 7, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[6, 7, 6, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[6, 7, 7, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 1, 2, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[7, 1, 5, 2] = {{-1}}
 
doubleS3Cat2FMatrixFunction[7, 1, 6, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[7, 1, 7, 0] = {{-1}}
 
doubleS3Cat2FMatrixFunction[7, 1, 7, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[7, 2, 1, 5] = {{-1}}
 
doubleS3Cat2FMatrixFunction[7, 2, 1, 6] = {{-1}}
 
doubleS3Cat2FMatrixFunction[7, 2, 2, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[7, 2, 3, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 2, 4, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 2, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[7, 2, 6, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[7, 2, 7, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[7, 3, 2, 3] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[7, 3, 2, 4] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[7, 3, 3, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[7, 3, 3, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[7, 3, 3, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 3, 3, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[7, 3, 3, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 3, 4, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[7, 3, 4, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 3, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 3, 4, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[7, 3, 4, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[7, 3, 5, 3] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[7, 3, 5, 4] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[7, 3, 6, 3] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[7, 3, 6, 4] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[7, 3, 7, 3] = {{1, 0}, {0, 1}}
 
doubleS3Cat2FMatrixFunction[7, 3, 7, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[7, 4, 2, 3] = {{(-I/2)*Sqrt[3], -1/2}, 
    {-1/2, (-I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[7, 4, 2, 4] = {{-1/2, (-I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[7, 4, 3, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[7, 4, 3, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 4, 3, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 4, 3, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 4, 3, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[7, 4, 4, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[7, 4, 4, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[7, 4, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 4, 4, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 4, 4, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 4, 5, 3] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[7, 4, 5, 4] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[7, 4, 6, 3] = {{(I/2)*Sqrt[3], -1/2}, 
    {-1/2, (I/2)*Sqrt[3]}}
 
doubleS3Cat2FMatrixFunction[7, 4, 6, 4] = {{-1/2, (I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], -1/2}}
 
doubleS3Cat2FMatrixFunction[7, 4, 7, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[7, 4, 7, 4] = {{1, 0}, {0, 1}}
 
doubleS3Cat2FMatrixFunction[7, 5, 1, 2] = {{-1}}
 
doubleS3Cat2FMatrixFunction[7, 5, 2, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[7, 5, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 5, 3, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 5, 4, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 5, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 5, 5, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[7, 5, 7, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[7, 6, 1, 2] = {{-1}}
 
doubleS3Cat2FMatrixFunction[7, 6, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[7, 6, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 6, 4, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[7, 6, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 6, 5, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[7, 6, 6, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 6, 7, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat2FMatrixFunction[7, 7, 1, 7] = {{-1}}
 
doubleS3Cat2FMatrixFunction[7, 7, 2, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 7, 3, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 7, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[7, 7, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[7, 7, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 7, 5, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat2FMatrixFunction[7, 7, 6, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat2FMatrixFunction[7, 7, 7, 1] = {{-1}}
 
doubleS3Cat2FMatrixFunction[7, 7, 7, 7] = {{1/2, -1/2, -(1/Sqrt[2])}, 
    {1/2, -1/2, 1/Sqrt[2]}, {-(1/Sqrt[2]), -(1/Sqrt[2]), 0}}
 
doubleS3Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
doubleS3Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[doubleS3Cat2Piv1] ^= {doubleS3Cat2Bal1}
 
doubleS3Cat2Piv1 /: balancedCategory[doubleS3Cat2Piv1, 1] = doubleS3Cat2Bal1
 
fusionCategory[doubleS3Cat2Piv1] ^= doubleS3Cat2
 
doubleS3Cat2Piv1 /: modularCategory[doubleS3Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[doubleS3Cat2Piv1] ^= doubleS3Cat2Piv1
 
pivotalIsomorphism[doubleS3Cat2Piv1] ^= doubleS3Cat2Piv1PivotalIsomorphism
 
doubleS3Cat2Piv1 /: ribbonCategory[doubleS3Cat2Piv1, 1] = doubleS3Cat2Bal1
 
ring[doubleS3Cat2Piv1] ^= doubleS3
 
sphericalCategory[doubleS3Cat2Piv1] ^= doubleS3Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[doubleS3Cat2]][pivotalCategory[#1]] & )[
    doubleS3Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[doubleS3Cat2]][
      sphericalCategory[#1]] & )[doubleS3Cat2Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[doubleS3Cat2Piv1PivotalIsomorphism] ^= doubleS3Cat2
 
pivotalCategory[doubleS3Cat2Piv1PivotalIsomorphism] ^= doubleS3Cat2Piv1
 
pivotalIsomorphism[doubleS3Cat2Piv1PivotalIsomorphism] ^= 
   doubleS3Cat2Piv1PivotalIsomorphism
 
doubleS3Cat2Piv1PivotalIsomorphism[0] = 1
 
doubleS3Cat2Piv1PivotalIsomorphism[1] = 1
 
doubleS3Cat2Piv1PivotalIsomorphism[2] = 1
 
doubleS3Cat2Piv1PivotalIsomorphism[3] = 1
 
doubleS3Cat2Piv1PivotalIsomorphism[4] = 1
 
doubleS3Cat2Piv1PivotalIsomorphism[5] = 1
 
doubleS3Cat2Piv1PivotalIsomorphism[6] = 1
 
doubleS3Cat2Piv1PivotalIsomorphism[7] = 1
balancedCategories[doubleS3Cat2Piv2] ^= {doubleS3Cat2Bal2}
 
doubleS3Cat2Piv2 /: balancedCategory[doubleS3Cat2Piv2, 1] = doubleS3Cat2Bal2
 
fusionCategory[doubleS3Cat2Piv2] ^= doubleS3Cat2
 
doubleS3Cat2Piv2 /: modularCategory[doubleS3Cat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[doubleS3Cat2Piv2] ^= doubleS3Cat2Piv2
 
pivotalIsomorphism[doubleS3Cat2Piv2] ^= doubleS3Cat2Piv2PivotalIsomorphism
 
doubleS3Cat2Piv2 /: ribbonCategory[doubleS3Cat2Piv2, 1] = doubleS3Cat2Bal2
 
ring[doubleS3Cat2Piv2] ^= doubleS3
 
sphericalCategory[doubleS3Cat2Piv2] ^= doubleS3Cat2Piv2
 
(pivotalCategoryIndex[fusionCategory[doubleS3Cat2]][pivotalCategory[#1]] & )[
    doubleS3Cat2Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[doubleS3Cat2]][
      sphericalCategory[#1]] & )[doubleS3Cat2Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[doubleS3Cat2Piv2PivotalIsomorphism] ^= doubleS3Cat2
 
pivotalCategory[doubleS3Cat2Piv2PivotalIsomorphism] ^= doubleS3Cat2Piv2
 
pivotalIsomorphism[doubleS3Cat2Piv2PivotalIsomorphism] ^= 
   doubleS3Cat2Piv2PivotalIsomorphism
 
doubleS3Cat2Piv2PivotalIsomorphism[0] = 1
 
doubleS3Cat2Piv2PivotalIsomorphism[1] = 1
 
doubleS3Cat2Piv2PivotalIsomorphism[2] = 1
 
doubleS3Cat2Piv2PivotalIsomorphism[3] = -1
 
doubleS3Cat2Piv2PivotalIsomorphism[4] = -1
 
doubleS3Cat2Piv2PivotalIsomorphism[5] = 1
 
doubleS3Cat2Piv2PivotalIsomorphism[6] = 1
 
doubleS3Cat2Piv2PivotalIsomorphism[7] = 1
balancedCategories[doubleS3Cat3] ^= {doubleS3Cat3Bal1, doubleS3Cat3Bal2}
 
doubleS3Cat3 /: balancedCategory[doubleS3Cat3, 1] = doubleS3Cat3Bal1
 
doubleS3Cat3 /: balancedCategory[doubleS3Cat3, 2] = doubleS3Cat3Bal2
 
braidedCategories[doubleS3Cat3] ^= {doubleS3Cat3Brd1}
 
doubleS3Cat3 /: braidedCategory[doubleS3Cat3, 1] = doubleS3Cat3Brd1
 
coeval[doubleS3Cat3] ^= 1/sixJFunction[doubleS3Cat3][#1, 
      dual[ring[doubleS3Cat3]][#1], #1, #1, 0, 0] & 
 
eval[doubleS3Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[doubleS3Cat3] ^= doubleS3Cat3FMatrixFunction
 
fusionCategory[doubleS3Cat3] ^= doubleS3Cat3
 
doubleS3Cat3 /: modularCategory[doubleS3Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[doubleS3Cat3] ^= {doubleS3Cat3Piv1, doubleS3Cat3Piv2}
 
doubleS3Cat3 /: pivotalCategory[doubleS3Cat3, 1] = doubleS3Cat3Piv1
 
doubleS3Cat3 /: pivotalCategory[doubleS3Cat3, 2] = doubleS3Cat3Piv2
 
doubleS3Cat3 /: pivotalCategory[doubleS3Cat3, {1, 1, 1, -1, -1, 1, 1, 1}] = 
    doubleS3Cat3Piv2
 
doubleS3Cat3 /: pivotalCategory[doubleS3Cat3, {1, 1, 1, 1, 1, 1, 1, 1}] = 
    doubleS3Cat3Piv1
 
doubleS3Cat3 /: ribbonCategory[doubleS3Cat3, 1] = doubleS3Cat3Bal1
 
doubleS3Cat3 /: ribbonCategory[doubleS3Cat3, 2] = doubleS3Cat3Bal2
 
ring[doubleS3Cat3] ^= doubleS3
 
doubleS3Cat3 /: sphericalCategory[doubleS3Cat3, 1] = doubleS3Cat3Piv1
 
doubleS3Cat3 /: sphericalCategory[doubleS3Cat3, 2] = doubleS3Cat3Piv2
 
fusionCategoryIndex[doubleS3][doubleS3Cat3] ^= 3
balancedCategory[doubleS3Cat3Bal1] ^= doubleS3Cat3Bal1
 
braidedCategory[doubleS3Cat3Bal1] ^= doubleS3Cat3Brd1
 
fusionCategory[doubleS3Cat3Bal1] ^= doubleS3Cat3
 
pivotalCategory[doubleS3Cat3Bal1] ^= doubleS3Cat3Piv1
 
ribbonCategory[doubleS3Cat3Bal1] ^= doubleS3Cat3Bal1
 
ring[doubleS3Cat3Bal1] ^= doubleS3
 
sphericalCategory[doubleS3Cat3Bal1] ^= doubleS3Cat3Piv1
 
(balancedCategoryIndex[braidedCategory[doubleS3Cat3Brd1]][
      balancedCategory[#1]] & )[doubleS3Cat3Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[doubleS3Cat3]][
      balancedCategory[#1]] & )[doubleS3Cat3Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[doubleS3Cat3Piv1]][
      balancedCategory[#1]] & )[doubleS3Cat3Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[doubleS3Cat3Brd1]][
      ribbonCategory[#1]] & )[doubleS3Cat3Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[doubleS3Cat3]][ribbonCategory[#1]] & )[
    doubleS3Cat3Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[doubleS3Cat3Piv1]][
      ribbonCategory[#1]] & )[doubleS3Cat3Bal1] ^= 1
balancedCategory[doubleS3Cat3Bal2] ^= doubleS3Cat3Bal2
 
braidedCategory[doubleS3Cat3Bal2] ^= doubleS3Cat3Brd1
 
fusionCategory[doubleS3Cat3Bal2] ^= doubleS3Cat3
 
pivotalCategory[doubleS3Cat3Bal2] ^= doubleS3Cat3Piv2
 
ribbonCategory[doubleS3Cat3Bal2] ^= doubleS3Cat3Bal2
 
ring[doubleS3Cat3Bal2] ^= doubleS3
 
sphericalCategory[doubleS3Cat3Bal2] ^= doubleS3Cat3Piv2
 
(balancedCategoryIndex[braidedCategory[doubleS3Cat3Brd1]][
      balancedCategory[#1]] & )[doubleS3Cat3Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[doubleS3Cat3]][
      balancedCategory[#1]] & )[doubleS3Cat3Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[doubleS3Cat3Piv2]][
      balancedCategory[#1]] & )[doubleS3Cat3Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[doubleS3Cat3Brd1]][
      ribbonCategory[#1]] & )[doubleS3Cat3Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[doubleS3Cat3]][ribbonCategory[#1]] & )[
    doubleS3Cat3Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[doubleS3Cat3Piv2]][
      ribbonCategory[#1]] & )[doubleS3Cat3Bal2] ^= 1
balancedCategories[doubleS3Cat3Brd1] ^= {doubleS3Cat3Bal1, doubleS3Cat3Bal2}
 
doubleS3Cat3Brd1 /: balancedCategory[doubleS3Cat3Brd1, 1] = doubleS3Cat3Bal1
 
doubleS3Cat3Brd1 /: balancedCategory[doubleS3Cat3Brd1, 2] = doubleS3Cat3Bal2
 
braidedCategory[doubleS3Cat3Brd1] ^= doubleS3Cat3Brd1
 
fusionCategory[doubleS3Cat3Brd1] ^= doubleS3Cat3
 
doubleS3Cat3Brd1 /: modularCategory[doubleS3Cat3Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
doubleS3Cat3Brd1 /: ribbonCategory[doubleS3Cat3Brd1, 1] = doubleS3Cat3Bal1
 
doubleS3Cat3Brd1 /: ribbonCategory[doubleS3Cat3Brd1, 2] = doubleS3Cat3Bal2
 
ring[doubleS3Cat3Brd1] ^= doubleS3
 
rMatrixFunction[doubleS3Cat3Brd1] ^= doubleS3Cat3Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[doubleS3Cat3]][braidedCategory[#1]] & )[
    doubleS3Cat3Brd1] ^= 1
braidedCategory[doubleS3Cat3Brd1RMatrixFunction] ^= doubleS3Cat3Brd1
 
fusionCategory[doubleS3Cat3Brd1RMatrixFunction] ^= doubleS3Cat3
 
rMatrixFunction[doubleS3Cat3Brd1RMatrixFunction] ^= 
   doubleS3Cat3Brd1RMatrixFunction
 
doubleS3Cat3Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[0, 5, 5] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[0, 6, 6] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[0, 7, 7] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[1, 1, 0] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[1, 2, 2] = {{-1}}
 
doubleS3Cat3Brd1RMatrixFunction[1, 3, 4] = {{I}}
 
doubleS3Cat3Brd1RMatrixFunction[1, 4, 3] = {{-I}}
 
doubleS3Cat3Brd1RMatrixFunction[1, 5, 5] = {{-1}}
 
doubleS3Cat3Brd1RMatrixFunction[1, 6, 6] = {{-1}}
 
doubleS3Cat3Brd1RMatrixFunction[1, 7, 7] = {{-1}}
 
doubleS3Cat3Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[2, 1, 2] = {{-1}}
 
doubleS3Cat3Brd1RMatrixFunction[2, 2, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[2, 2, 1] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3Cat3Brd1RMatrixFunction[2, 2, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[2, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[2, 3, 4] = {{(-1)^(1/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[2, 4, 3] = {{-(-1)^(1/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[2, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[2, 5, 6] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[2, 5, 7] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[2, 6, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[2, 6, 7] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[2, 7, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[2, 7, 6] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 1, 4] = {{I}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 2, 4] = {{(-1)^(1/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 3, 0] = {{-I}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 3, 2] = {{(-1)^(5/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 3, 5] = {{(-1)^(5/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 3, 6] = {{(-1)^(1/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 3, 7] = {{(-1)^(1/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 4, 1] = {{-1}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 4, 6] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 4, 7] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 5, 4] = {{(-1)^(1/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 6, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 6, 4] = {{(-1)^(5/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 7, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[3, 7, 4] = {{(-1)^(5/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 1, 3] = {{-I}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 2, 3] = {{-(-1)^(1/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 3, 1] = {{-1}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 3, 6] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 3, 7] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 4, 0] = {{I}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 4, 2] = {{-(-1)^(5/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 4, 5] = {{-(-1)^(5/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 4, 6] = {{-(-1)^(1/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 4, 7] = {{-(-1)^(1/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 5, 3] = {{-(-1)^(1/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 6, 3] = {{-(-1)^(5/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 6, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 7, 3] = {{-(-1)^(5/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[4, 7, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[5, 0, 5] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[5, 1, 5] = {{-1}}
 
doubleS3Cat3Brd1RMatrixFunction[5, 2, 6] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[5, 2, 7] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[5, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[5, 3, 4] = {{(-1)^(1/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[5, 4, 3] = {{-(-1)^(1/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[5, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[5, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[5, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3Cat3Brd1RMatrixFunction[5, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[5, 6, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[5, 6, 7] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[5, 7, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[5, 7, 6] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[6, 0, 6] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[6, 1, 6] = {{-1}}
 
doubleS3Cat3Brd1RMatrixFunction[6, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[6, 2, 7] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[6, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[6, 3, 4] = {{(-1)^(5/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[6, 4, 3] = {{-(-1)^(5/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[6, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[6, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[6, 5, 7] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[6, 6, 0] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[6, 6, 1] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3Cat3Brd1RMatrixFunction[6, 6, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[6, 7, 2] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[6, 7, 5] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[7, 0, 7] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[7, 1, 7] = {{-1}}
 
doubleS3Cat3Brd1RMatrixFunction[7, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[7, 2, 6] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[7, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[7, 3, 4] = {{(-1)^(5/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[7, 4, 3] = {{-(-1)^(5/6)}}
 
doubleS3Cat3Brd1RMatrixFunction[7, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[7, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[7, 5, 6] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[7, 6, 2] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[7, 6, 5] = {{1}}
 
doubleS3Cat3Brd1RMatrixFunction[7, 7, 0] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat3Brd1RMatrixFunction[7, 7, 1] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3Cat3Brd1RMatrixFunction[7, 7, 7] = {{(-I/2)*(-I + Sqrt[3])}}
fMatrixFunction[doubleS3Cat3FMatrixFunction] ^= doubleS3Cat3FMatrixFunction
 
fusionCategory[doubleS3Cat3FMatrixFunction] ^= doubleS3Cat3
 
ring[doubleS3Cat3FMatrixFunction] ^= doubleS3
 
doubleS3Cat3FMatrixFunction[1, 2, 2, 2] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 2, 3, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 2, 3, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 2, 4, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 2, 4, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 2, 5, 6] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 2, 6, 5] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 2, 6, 7] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 3, 1, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 3, 2, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 3, 4, 2] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 3, 4, 5] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 3, 4, 6] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 3, 4, 7] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 3, 5, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 3, 6, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 3, 7, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 4, 1, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 4, 2, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 4, 3, 0] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 4, 4, 2] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 4, 4, 5] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 4, 4, 6] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 4, 4, 7] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 4, 6, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 4, 7, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 5, 2, 6] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 5, 2, 7] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 5, 3, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 5, 3, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 5, 4, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 5, 4, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 5, 5, 5] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 5, 6, 2] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 6, 2, 5] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 6, 3, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 6, 3, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 6, 4, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 6, 4, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 6, 5, 2] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 6, 5, 7] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 6, 6, 6] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 7, 2, 5] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 7, 3, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 7, 3, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 7, 4, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 7, 4, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 7, 5, 6] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 7, 6, 2] = {{-1}}
 
doubleS3Cat3FMatrixFunction[1, 7, 7, 7] = {{-1}}
 
doubleS3Cat3FMatrixFunction[2, 1, 2, 2] = {{-1}}
 
doubleS3Cat3FMatrixFunction[2, 1, 5, 6] = {{-1}}
 
doubleS3Cat3FMatrixFunction[2, 1, 6, 5] = {{-1}}
 
doubleS3Cat3FMatrixFunction[2, 1, 7, 6] = {{-1}}
 
doubleS3Cat3FMatrixFunction[2, 2, 1, 2] = {{-1}}
 
doubleS3Cat3FMatrixFunction[2, 2, 2, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
doubleS3Cat3FMatrixFunction[2, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 2, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[2, 2, 4, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[2, 2, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 2, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 2, 6, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 2, 7, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[2, 3, 1, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[2, 3, 2, 3] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[2, 3, 2, 4] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[2, 3, 3, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 3, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[2, 3, 3, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[2, 3, 3, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 3, 4, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[2, 3, 4, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 3, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[2, 3, 4, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 3, 4, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[2, 3, 5, 3] = {{1, 0}, {0, -1}}
 
doubleS3Cat3FMatrixFunction[2, 3, 5, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[2, 3, 6, 3] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[2, 3, 6, 4] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[2, 3, 7, 3] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[2, 3, 7, 4] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[2, 4, 1, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[2, 4, 2, 3] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[2, 4, 2, 4] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[2, 4, 3, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[2, 4, 3, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[2, 4, 3, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 4, 3, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 4, 4, 0] = {{-1}}
 
doubleS3Cat3FMatrixFunction[2, 4, 4, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 4, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 4, 4, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 4, 4, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 4, 5, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[2, 4, 5, 4] = {{-1, 0}, {0, 1}}
 
doubleS3Cat3FMatrixFunction[2, 4, 6, 3] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[2, 4, 6, 4] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[2, 4, 7, 3] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[2, 4, 7, 4] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[2, 5, 1, 6] = {{-1}}
 
doubleS3Cat3FMatrixFunction[2, 5, 1, 7] = {{-1}}
 
doubleS3Cat3FMatrixFunction[2, 5, 2, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[2, 5, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[2, 5, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[2, 5, 4, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 5, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 5, 5, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 5, 6, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[2, 6, 1, 5] = {{-1}}
 
doubleS3Cat3FMatrixFunction[2, 6, 2, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[2, 6, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[2, 6, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 6, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[2, 6, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 6, 5, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[2, 6, 6, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 6, 7, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[2, 7, 1, 5] = {{-1}}
 
doubleS3Cat3FMatrixFunction[2, 7, 2, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[2, 7, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 7, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 7, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 7, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[2, 7, 7, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 1, 3, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[3, 1, 4, 0] = {{-1}}
 
doubleS3Cat3FMatrixFunction[3, 2, 1, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[3, 2, 1, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[3, 2, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 2, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 2, 3, 2] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[3, 2, 3, 5] = {{1, 0}, {0, -1}}
 
doubleS3Cat3FMatrixFunction[3, 2, 3, 6] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[3, 2, 3, 7] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[3, 2, 4, 2] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[3, 2, 4, 5] = {{0, -1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[3, 2, 4, 6] = {{Sqrt[3]/2, 1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[3, 2, 4, 7] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[3, 2, 5, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 2, 5, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 2, 6, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 2, 6, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 2, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 2, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 3, 1, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[3, 3, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 3, 2, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 3, 2, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 3, 2, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 3, 3, 3] = 
   {{1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {Sqrt[2]/3, -1/3, 2/3, -1/3, -1/3}, {Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, 
    {Sqrt[2]/3, -1/3, -1/3, -1/3, 2/3}, {Sqrt[2]/3, -1/3, -1/3, 2/3, -1/3}}
 
doubleS3Cat3FMatrixFunction[3, 3, 3, 4] = 
   {{-(1/Sqrt[3]), 0, 1/Sqrt[3], -(1/Sqrt[3])}, {0, -(1/Sqrt[3]), 1/Sqrt[3], 
     1/Sqrt[3]}, {1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3], 0}, 
    {-(1/Sqrt[3]), 1/Sqrt[3], 0, 1/Sqrt[3]}}
 
doubleS3Cat3FMatrixFunction[3, 3, 4, 3] = 
   {{-(1/Sqrt[3]), 0, 1/Sqrt[3], -(1/Sqrt[3])}, {0, -(1/Sqrt[3]), 1/Sqrt[3], 
     1/Sqrt[3]}, {1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3], 0}, 
    {-(1/Sqrt[3]), 1/Sqrt[3], 0, 1/Sqrt[3]}}
 
doubleS3Cat3FMatrixFunction[3, 3, 4, 4] = 
   {{-1/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {-Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, {-Sqrt[2]/3, -2/3, 1/3, 1/3, 1/3}, 
    {-Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}, {-Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}}
 
doubleS3Cat3FMatrixFunction[3, 3, 5, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 3, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 3, 5, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 3, 5, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 3, 6, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 3, 6, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 3, 6, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 3, 6, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 3, 7, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 3, 7, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 3, 7, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 3, 7, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 4, 1, 0] = {{-1}}
 
doubleS3Cat3FMatrixFunction[3, 4, 2, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 4, 2, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 4, 2, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 4, 2, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 4, 3, 3] = 
   {{-(1/Sqrt[3]), 0, 1/Sqrt[3], -(1/Sqrt[3])}, {0, -(1/Sqrt[3]), 1/Sqrt[3], 
     1/Sqrt[3]}, {1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3], 0}, 
    {-(1/Sqrt[3]), 1/Sqrt[3], 0, 1/Sqrt[3]}}
 
doubleS3Cat3FMatrixFunction[3, 4, 3, 4] = 
   {{-1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, {Sqrt[2]/3, -2/3, 1/3, 1/3, 1/3}, 
    {Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}, {Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}}
 
doubleS3Cat3FMatrixFunction[3, 4, 4, 3] = 
   {{1/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {-Sqrt[2]/3, -1/3, 2/3, -1/3, -1/3}, {-Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, 
    {-Sqrt[2]/3, -1/3, -1/3, -1/3, 2/3}, {-Sqrt[2]/3, -1/3, -1/3, 2/3, -1/3}}
 
doubleS3Cat3FMatrixFunction[3, 4, 4, 4] = 
   {{-(1/Sqrt[3]), 0, 1/Sqrt[3], -(1/Sqrt[3])}, {0, -(1/Sqrt[3]), 1/Sqrt[3], 
     1/Sqrt[3]}, {1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3], 0}, 
    {-(1/Sqrt[3]), 1/Sqrt[3], 0, 1/Sqrt[3]}}
 
doubleS3Cat3FMatrixFunction[3, 4, 5, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 4, 5, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 4, 5, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 4, 5, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 4, 6, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 4, 6, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 4, 6, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 4, 6, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 4, 7, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 4, 7, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 4, 7, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 4, 7, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 5, 1, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[3, 5, 1, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[3, 5, 2, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 5, 2, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 5, 3, 2] = {{1, 0}, {0, -1}}
 
doubleS3Cat3FMatrixFunction[3, 5, 3, 5] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[3, 5, 3, 6] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[3, 5, 3, 7] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[3, 5, 4, 2] = {{0, -1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[3, 5, 4, 5] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[3, 5, 4, 6] = {{Sqrt[3]/2, 1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[3, 5, 4, 7] = {{Sqrt[3]/2, 1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[3, 5, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 5, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 5, 6, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 5, 6, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 5, 7, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 5, 7, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 6, 1, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[3, 6, 1, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[3, 6, 2, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 6, 2, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 6, 3, 2] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[3, 6, 3, 5] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[3, 6, 3, 6] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[3, 6, 3, 7] = {{1, 0}, {0, -1}}
 
doubleS3Cat3FMatrixFunction[3, 6, 4, 2] = {{Sqrt[3]/2, 1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[3, 6, 4, 5] = {{Sqrt[3]/2, 1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[3, 6, 4, 6] = {{Sqrt[3]/2, 1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[3, 6, 4, 7] = {{0, -1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[3, 6, 5, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 6, 5, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 6, 6, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 6, 6, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 6, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 6, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 7, 1, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[3, 7, 1, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[3, 7, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 7, 2, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 7, 3, 2] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[3, 7, 3, 5] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[3, 7, 3, 6] = {{1, 0}, {0, -1}}
 
doubleS3Cat3FMatrixFunction[3, 7, 3, 7] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[3, 7, 4, 2] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[3, 7, 4, 5] = {{Sqrt[3]/2, 1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[3, 7, 4, 6] = {{0, -1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[3, 7, 4, 7] = {{Sqrt[3]/2, 1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[3, 7, 5, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 7, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[3, 7, 6, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 7, 6, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 7, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[3, 7, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 1, 3, 0] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 1, 4, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 2, 1, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 2, 1, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 2, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 2, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 2, 3, 2] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[4, 2, 3, 5] = {{0, 1}, {-1, 0}}
 
doubleS3Cat3FMatrixFunction[4, 2, 3, 6] = {{Sqrt[3]/2, -1/2}, 
    {1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[4, 2, 3, 7] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[4, 2, 4, 2] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[4, 2, 4, 5] = {{-1, 0}, {0, 1}}
 
doubleS3Cat3FMatrixFunction[4, 2, 4, 6] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[4, 2, 4, 7] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[4, 2, 5, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 2, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 2, 6, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 2, 6, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 2, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 2, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 3, 1, 2] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 3, 1, 5] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 3, 1, 6] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 3, 1, 7] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 3, 2, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 3, 2, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 3, 2, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 3, 2, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 3, 2, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 3, 3, 3] = 
   {{-(1/Sqrt[3]), 0, 1/Sqrt[3], -(1/Sqrt[3])}, {0, -(1/Sqrt[3]), 1/Sqrt[3], 
     1/Sqrt[3]}, {1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3], 0}, 
    {-(1/Sqrt[3]), 1/Sqrt[3], 0, 1/Sqrt[3]}}
 
doubleS3Cat3FMatrixFunction[4, 3, 3, 4] = 
   {{-1/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {-Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, {-Sqrt[2]/3, -2/3, 1/3, 1/3, 1/3}, 
    {-Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}, {-Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}}
 
doubleS3Cat3FMatrixFunction[4, 3, 4, 3] = 
   {{-1/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {-Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, {-Sqrt[2]/3, -2/3, 1/3, 1/3, 1/3}, 
    {-Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}, {-Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}}
 
doubleS3Cat3FMatrixFunction[4, 3, 4, 4] = 
   {{1/Sqrt[3], 0, -(1/Sqrt[3]), 1/Sqrt[3]}, {0, 1/Sqrt[3], -(1/Sqrt[3]), 
     -(1/Sqrt[3])}, {-(1/Sqrt[3]), -(1/Sqrt[3]), -(1/Sqrt[3]), 0}, 
    {1/Sqrt[3], -(1/Sqrt[3]), 0, -(1/Sqrt[3])}}
 
doubleS3Cat3FMatrixFunction[4, 3, 5, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 3, 5, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 3, 5, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 3, 5, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 3, 5, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 3, 6, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 3, 6, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 3, 6, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 3, 6, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 3, 6, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 3, 7, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 3, 7, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 3, 7, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 3, 7, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 3, 7, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 4, 1, 2] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 4, 1, 5] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 4, 1, 6] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 4, 1, 7] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 4, 2, 0] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 4, 2, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 4, 2, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 4, 2, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 4, 2, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 4, 3, 3] = 
   {{1/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {-Sqrt[2]/3, -1/3, 2/3, -1/3, -1/3}, {-Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, 
    {-Sqrt[2]/3, -1/3, -1/3, -1/3, 2/3}, {-Sqrt[2]/3, -1/3, -1/3, 2/3, -1/3}}
 
doubleS3Cat3FMatrixFunction[4, 4, 3, 4] = 
   {{-(1/Sqrt[3]), 0, 1/Sqrt[3], -(1/Sqrt[3])}, {0, -(1/Sqrt[3]), 1/Sqrt[3], 
     1/Sqrt[3]}, {1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3], 0}, 
    {-(1/Sqrt[3]), 1/Sqrt[3], 0, 1/Sqrt[3]}}
 
doubleS3Cat3FMatrixFunction[4, 4, 4, 3] = 
   {{1/Sqrt[3], 0, -(1/Sqrt[3]), 1/Sqrt[3]}, {0, 1/Sqrt[3], -(1/Sqrt[3]), 
     -(1/Sqrt[3])}, {-(1/Sqrt[3]), -(1/Sqrt[3]), -(1/Sqrt[3]), 0}, 
    {1/Sqrt[3], -(1/Sqrt[3]), 0, -(1/Sqrt[3])}}
 
doubleS3Cat3FMatrixFunction[4, 4, 4, 4] = 
   {{1/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {-Sqrt[2]/3, -1/3, 2/3, -1/3, -1/3}, {-Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, 
    {-Sqrt[2]/3, -1/3, -1/3, -1/3, 2/3}, {-Sqrt[2]/3, -1/3, -1/3, 2/3, -1/3}}
 
doubleS3Cat3FMatrixFunction[4, 4, 5, 0] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 4, 5, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 4, 5, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 4, 5, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 4, 5, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 4, 6, 0] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 4, 6, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 4, 6, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 4, 6, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 4, 6, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 4, 7, 0] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 4, 7, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 4, 7, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 4, 7, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 4, 7, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 5, 1, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 5, 1, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 5, 2, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 5, 2, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 5, 3, 2] = {{0, 1}, {-1, 0}}
 
doubleS3Cat3FMatrixFunction[4, 5, 3, 5] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[4, 5, 3, 6] = {{Sqrt[3]/2, -1/2}, 
    {1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[4, 5, 3, 7] = {{Sqrt[3]/2, -1/2}, 
    {1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[4, 5, 4, 2] = {{-1, 0}, {0, 1}}
 
doubleS3Cat3FMatrixFunction[4, 5, 4, 5] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[4, 5, 4, 6] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[4, 5, 4, 7] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[4, 5, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 5, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 5, 6, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 5, 6, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 5, 7, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 5, 7, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 6, 1, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 6, 1, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 6, 2, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 6, 2, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 6, 3, 2] = {{Sqrt[3]/2, -1/2}, 
    {1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[4, 6, 3, 5] = {{Sqrt[3]/2, -1/2}, 
    {1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[4, 6, 3, 6] = {{Sqrt[3]/2, -1/2}, 
    {1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[4, 6, 3, 7] = {{0, 1}, {-1, 0}}
 
doubleS3Cat3FMatrixFunction[4, 6, 4, 2] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[4, 6, 4, 5] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[4, 6, 4, 6] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[4, 6, 4, 7] = {{-1, 0}, {0, 1}}
 
doubleS3Cat3FMatrixFunction[4, 6, 5, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 6, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 6, 6, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 6, 6, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 6, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 6, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 7, 1, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 7, 1, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[4, 7, 2, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 7, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 7, 3, 2] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[4, 7, 3, 5] = {{Sqrt[3]/2, -1/2}, 
    {1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[4, 7, 3, 6] = {{0, 1}, {-1, 0}}
 
doubleS3Cat3FMatrixFunction[4, 7, 3, 7] = {{Sqrt[3]/2, -1/2}, 
    {1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[4, 7, 4, 2] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[4, 7, 4, 5] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[4, 7, 4, 6] = {{-1, 0}, {0, 1}}
 
doubleS3Cat3FMatrixFunction[4, 7, 4, 7] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[4, 7, 5, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 7, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 7, 6, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 7, 6, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[4, 7, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[4, 7, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[5, 1, 2, 6] = {{-1}}
 
doubleS3Cat3FMatrixFunction[5, 1, 5, 5] = {{-1}}
 
doubleS3Cat3FMatrixFunction[5, 1, 6, 2] = {{-1}}
 
doubleS3Cat3FMatrixFunction[5, 1, 7, 2] = {{-1}}
 
doubleS3Cat3FMatrixFunction[5, 2, 1, 6] = {{-1}}
 
doubleS3Cat3FMatrixFunction[5, 2, 2, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[5, 2, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 2, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[5, 2, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 2, 5, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[5, 2, 6, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[5, 2, 7, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[5, 3, 1, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[5, 3, 2, 3] = {{1, 0}, {0, -1}}
 
doubleS3Cat3FMatrixFunction[5, 3, 2, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[5, 3, 3, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[5, 3, 3, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[5, 3, 3, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 3, 3, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 3, 4, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[5, 3, 4, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 3, 4, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[5, 3, 4, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 3, 4, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 3, 5, 3] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[5, 3, 5, 4] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[5, 3, 6, 3] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[5, 3, 6, 4] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[5, 3, 7, 3] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[5, 3, 7, 4] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[5, 4, 1, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[5, 4, 2, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[5, 4, 2, 4] = {{-1, 0}, {0, 1}}
 
doubleS3Cat3FMatrixFunction[5, 4, 3, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 4, 3, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 4, 3, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 4, 3, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 4, 4, 0] = {{-1}}
 
doubleS3Cat3FMatrixFunction[5, 4, 4, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 4, 4, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[5, 4, 4, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[5, 4, 4, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[5, 4, 5, 3] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[5, 4, 5, 4] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[5, 4, 6, 3] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[5, 4, 6, 4] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[5, 4, 7, 3] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[5, 4, 7, 4] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[5, 5, 1, 5] = {{-1}}
 
doubleS3Cat3FMatrixFunction[5, 5, 2, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 5, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[5, 5, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 5, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 5, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[5, 5, 5, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[5, 5, 5, 5] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
doubleS3Cat3FMatrixFunction[5, 5, 6, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 5, 7, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 6, 1, 2] = {{-1}}
 
doubleS3Cat3FMatrixFunction[5, 6, 1, 7] = {{-1}}
 
doubleS3Cat3FMatrixFunction[5, 6, 2, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[5, 6, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 6, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 6, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[5, 6, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[5, 6, 5, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[5, 6, 6, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 7, 1, 6] = {{-1}}
 
doubleS3Cat3FMatrixFunction[5, 7, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 7, 3, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[5, 7, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[5, 7, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[5, 7, 5, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[5, 7, 7, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[6, 1, 2, 5] = {{-1}}
 
doubleS3Cat3FMatrixFunction[6, 1, 5, 2] = {{-1}}
 
doubleS3Cat3FMatrixFunction[6, 1, 6, 6] = {{-1}}
 
doubleS3Cat3FMatrixFunction[6, 1, 7, 5] = {{-1}}
 
doubleS3Cat3FMatrixFunction[6, 2, 1, 5] = {{-1}}
 
doubleS3Cat3FMatrixFunction[6, 2, 1, 7] = {{-1}}
 
doubleS3Cat3FMatrixFunction[6, 2, 2, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[6, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 2, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 2, 4, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[6, 2, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[6, 2, 5, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[6, 2, 6, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[6, 3, 1, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[6, 3, 2, 3] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[6, 3, 2, 4] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[6, 3, 3, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 3, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[6, 3, 3, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 3, 3, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 3, 4, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[6, 3, 4, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 3, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 3, 4, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 3, 4, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[6, 3, 5, 3] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[6, 3, 5, 4] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[6, 3, 6, 3] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[6, 3, 6, 4] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[6, 3, 7, 3] = {{1, 0}, {0, -1}}
 
doubleS3Cat3FMatrixFunction[6, 3, 7, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[6, 4, 1, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[6, 4, 2, 3] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[6, 4, 2, 4] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[6, 4, 3, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 4, 3, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 4, 3, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[6, 4, 3, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 4, 4, 0] = {{-1}}
 
doubleS3Cat3FMatrixFunction[6, 4, 4, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[6, 4, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 4, 4, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 4, 4, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 4, 5, 3] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[6, 4, 5, 4] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[6, 4, 6, 3] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[6, 4, 6, 4] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[6, 4, 7, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[6, 4, 7, 4] = {{-1, 0}, {0, 1}}
 
doubleS3Cat3FMatrixFunction[6, 5, 1, 2] = {{-1}}
 
doubleS3Cat3FMatrixFunction[6, 5, 2, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[6, 5, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[6, 5, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 5, 4, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[6, 5, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 5, 5, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[6, 5, 6, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[6, 5, 7, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[6, 6, 1, 6] = {{-1}}
 
doubleS3Cat3FMatrixFunction[6, 6, 2, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[6, 6, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 6, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[6, 6, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[6, 6, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 6, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[6, 6, 6, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[6, 6, 6, 6] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
doubleS3Cat3FMatrixFunction[6, 6, 7, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 7, 1, 2] = {{-1}}
 
doubleS3Cat3FMatrixFunction[6, 7, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 7, 3, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 7, 4, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 7, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[6, 7, 6, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[6, 7, 7, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 1, 2, 6] = {{-1}}
 
doubleS3Cat3FMatrixFunction[7, 1, 5, 2] = {{-1}}
 
doubleS3Cat3FMatrixFunction[7, 1, 6, 5] = {{-1}}
 
doubleS3Cat3FMatrixFunction[7, 1, 7, 7] = {{-1}}
 
doubleS3Cat3FMatrixFunction[7, 2, 2, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[7, 2, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[7, 2, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[7, 2, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[7, 2, 5, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[7, 2, 7, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[7, 3, 1, 3] = {{-1}}
 
doubleS3Cat3FMatrixFunction[7, 3, 2, 3] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[7, 3, 2, 4] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[7, 3, 3, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[7, 3, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[7, 3, 3, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 3, 3, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 3, 4, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[7, 3, 4, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 3, 4, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 3, 4, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[7, 3, 4, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 3, 5, 3] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[7, 3, 5, 4] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[7, 3, 6, 3] = {{1, 0}, {0, -1}}
 
doubleS3Cat3FMatrixFunction[7, 3, 6, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[7, 3, 7, 3] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat3FMatrixFunction[7, 3, 7, 4] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[7, 4, 1, 4] = {{-1}}
 
doubleS3Cat3FMatrixFunction[7, 4, 2, 3] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[7, 4, 2, 4] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[7, 4, 3, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[7, 4, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 4, 3, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 4, 3, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[7, 4, 4, 0] = {{-1}}
 
doubleS3Cat3FMatrixFunction[7, 4, 4, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[7, 4, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 4, 4, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 4, 4, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 4, 5, 3] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[7, 4, 5, 4] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[7, 4, 6, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[7, 4, 6, 4] = {{-1, 0}, {0, 1}}
 
doubleS3Cat3FMatrixFunction[7, 4, 7, 3] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat3FMatrixFunction[7, 4, 7, 4] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat3FMatrixFunction[7, 5, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[7, 5, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 5, 4, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[7, 5, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 5, 5, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[7, 5, 6, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[7, 5, 7, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[7, 6, 2, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[7, 6, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 6, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 6, 4, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 6, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 6, 6, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 6, 7, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat3FMatrixFunction[7, 7, 1, 7] = {{-1}}
 
doubleS3Cat3FMatrixFunction[7, 7, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 7, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 7, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[7, 7, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[7, 7, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 7, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat3FMatrixFunction[7, 7, 6, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat3FMatrixFunction[7, 7, 7, 1] = {{-1}}
 
doubleS3Cat3FMatrixFunction[7, 7, 7, 7] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
doubleS3Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
doubleS3Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[doubleS3Cat3Piv1] ^= {doubleS3Cat3Bal1}
 
doubleS3Cat3Piv1 /: balancedCategory[doubleS3Cat3Piv1, 1] = doubleS3Cat3Bal1
 
fusionCategory[doubleS3Cat3Piv1] ^= doubleS3Cat3
 
doubleS3Cat3Piv1 /: modularCategory[doubleS3Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[doubleS3Cat3Piv1] ^= doubleS3Cat3Piv1
 
pivotalIsomorphism[doubleS3Cat3Piv1] ^= doubleS3Cat3Piv1PivotalIsomorphism
 
doubleS3Cat3Piv1 /: ribbonCategory[doubleS3Cat3Piv1, 1] = doubleS3Cat3Bal1
 
ring[doubleS3Cat3Piv1] ^= doubleS3
 
sphericalCategory[doubleS3Cat3Piv1] ^= doubleS3Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[doubleS3Cat3]][pivotalCategory[#1]] & )[
    doubleS3Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[doubleS3Cat3]][
      sphericalCategory[#1]] & )[doubleS3Cat3Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[doubleS3Cat3Piv1PivotalIsomorphism] ^= doubleS3Cat3
 
pivotalCategory[doubleS3Cat3Piv1PivotalIsomorphism] ^= doubleS3Cat3Piv1
 
pivotalIsomorphism[doubleS3Cat3Piv1PivotalIsomorphism] ^= 
   doubleS3Cat3Piv1PivotalIsomorphism
 
doubleS3Cat3Piv1PivotalIsomorphism[0] = 1
 
doubleS3Cat3Piv1PivotalIsomorphism[1] = 1
 
doubleS3Cat3Piv1PivotalIsomorphism[2] = 1
 
doubleS3Cat3Piv1PivotalIsomorphism[3] = 1
 
doubleS3Cat3Piv1PivotalIsomorphism[4] = 1
 
doubleS3Cat3Piv1PivotalIsomorphism[5] = 1
 
doubleS3Cat3Piv1PivotalIsomorphism[6] = 1
 
doubleS3Cat3Piv1PivotalIsomorphism[7] = 1
balancedCategories[doubleS3Cat3Piv2] ^= {doubleS3Cat3Bal2}
 
doubleS3Cat3Piv2 /: balancedCategory[doubleS3Cat3Piv2, 1] = doubleS3Cat3Bal2
 
fusionCategory[doubleS3Cat3Piv2] ^= doubleS3Cat3
 
doubleS3Cat3Piv2 /: modularCategory[doubleS3Cat3Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[doubleS3Cat3Piv2] ^= doubleS3Cat3Piv2
 
pivotalIsomorphism[doubleS3Cat3Piv2] ^= doubleS3Cat3Piv2PivotalIsomorphism
 
doubleS3Cat3Piv2 /: ribbonCategory[doubleS3Cat3Piv2, 1] = doubleS3Cat3Bal2
 
ring[doubleS3Cat3Piv2] ^= doubleS3
 
sphericalCategory[doubleS3Cat3Piv2] ^= doubleS3Cat3Piv2
 
(pivotalCategoryIndex[fusionCategory[doubleS3Cat3]][pivotalCategory[#1]] & )[
    doubleS3Cat3Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[doubleS3Cat3]][
      sphericalCategory[#1]] & )[doubleS3Cat3Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[doubleS3Cat3Piv2PivotalIsomorphism] ^= doubleS3Cat3
 
pivotalCategory[doubleS3Cat3Piv2PivotalIsomorphism] ^= doubleS3Cat3Piv2
 
pivotalIsomorphism[doubleS3Cat3Piv2PivotalIsomorphism] ^= 
   doubleS3Cat3Piv2PivotalIsomorphism
 
doubleS3Cat3Piv2PivotalIsomorphism[0] = 1
 
doubleS3Cat3Piv2PivotalIsomorphism[1] = 1
 
doubleS3Cat3Piv2PivotalIsomorphism[2] = 1
 
doubleS3Cat3Piv2PivotalIsomorphism[3] = -1
 
doubleS3Cat3Piv2PivotalIsomorphism[4] = -1
 
doubleS3Cat3Piv2PivotalIsomorphism[5] = 1
 
doubleS3Cat3Piv2PivotalIsomorphism[6] = 1
 
doubleS3Cat3Piv2PivotalIsomorphism[7] = 1
balancedCategories[doubleS3Cat4] ^= {doubleS3Cat4Bal1, doubleS3Cat4Bal2}
 
doubleS3Cat4 /: balancedCategory[doubleS3Cat4, 1] = doubleS3Cat4Bal1
 
doubleS3Cat4 /: balancedCategory[doubleS3Cat4, 2] = doubleS3Cat4Bal2
 
braidedCategories[doubleS3Cat4] ^= {doubleS3Cat4Brd1}
 
doubleS3Cat4 /: braidedCategory[doubleS3Cat4, 1] = doubleS3Cat4Brd1
 
coeval[doubleS3Cat4] ^= 1/sixJFunction[doubleS3Cat4][#1, 
      dual[ring[doubleS3Cat4]][#1], #1, #1, 0, 0] & 
 
eval[doubleS3Cat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[doubleS3Cat4] ^= doubleS3Cat4FMatrixFunction
 
fusionCategory[doubleS3Cat4] ^= doubleS3Cat4
 
doubleS3Cat4 /: modularCategory[doubleS3Cat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[doubleS3Cat4] ^= {doubleS3Cat4Piv1, doubleS3Cat4Piv2}
 
doubleS3Cat4 /: pivotalCategory[doubleS3Cat4, 1] = doubleS3Cat4Piv1
 
doubleS3Cat4 /: pivotalCategory[doubleS3Cat4, 2] = doubleS3Cat4Piv2
 
doubleS3Cat4 /: pivotalCategory[doubleS3Cat4, {1, 1, 1, -1, -1, 1, 1, 1}] = 
    doubleS3Cat4Piv2
 
doubleS3Cat4 /: pivotalCategory[doubleS3Cat4, {1, 1, 1, 1, 1, 1, 1, 1}] = 
    doubleS3Cat4Piv1
 
doubleS3Cat4 /: ribbonCategory[doubleS3Cat4, 1] = doubleS3Cat4Bal1
 
doubleS3Cat4 /: ribbonCategory[doubleS3Cat4, 2] = doubleS3Cat4Bal2
 
ring[doubleS3Cat4] ^= doubleS3
 
doubleS3Cat4 /: sphericalCategory[doubleS3Cat4, 1] = doubleS3Cat4Piv1
 
doubleS3Cat4 /: sphericalCategory[doubleS3Cat4, 2] = doubleS3Cat4Piv2
 
fusionCategoryIndex[doubleS3][doubleS3Cat4] ^= 4
balancedCategory[doubleS3Cat4Bal1] ^= doubleS3Cat4Bal1
 
braidedCategory[doubleS3Cat4Bal1] ^= doubleS3Cat4Brd1
 
fusionCategory[doubleS3Cat4Bal1] ^= doubleS3Cat4
 
pivotalCategory[doubleS3Cat4Bal1] ^= doubleS3Cat4Piv1
 
ribbonCategory[doubleS3Cat4Bal1] ^= doubleS3Cat4Bal1
 
ring[doubleS3Cat4Bal1] ^= doubleS3
 
sphericalCategory[doubleS3Cat4Bal1] ^= doubleS3Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[doubleS3Cat4Brd1]][
      balancedCategory[#1]] & )[doubleS3Cat4Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[doubleS3Cat4]][
      balancedCategory[#1]] & )[doubleS3Cat4Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[doubleS3Cat4Piv1]][
      balancedCategory[#1]] & )[doubleS3Cat4Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[doubleS3Cat4Brd1]][
      ribbonCategory[#1]] & )[doubleS3Cat4Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[doubleS3Cat4]][ribbonCategory[#1]] & )[
    doubleS3Cat4Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[doubleS3Cat4Piv1]][
      ribbonCategory[#1]] & )[doubleS3Cat4Bal1] ^= 1
balancedCategory[doubleS3Cat4Bal2] ^= doubleS3Cat4Bal2
 
braidedCategory[doubleS3Cat4Bal2] ^= doubleS3Cat4Brd1
 
fusionCategory[doubleS3Cat4Bal2] ^= doubleS3Cat4
 
pivotalCategory[doubleS3Cat4Bal2] ^= doubleS3Cat4Piv2
 
ribbonCategory[doubleS3Cat4Bal2] ^= doubleS3Cat4Bal2
 
ring[doubleS3Cat4Bal2] ^= doubleS3
 
sphericalCategory[doubleS3Cat4Bal2] ^= doubleS3Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[doubleS3Cat4Brd1]][
      balancedCategory[#1]] & )[doubleS3Cat4Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[doubleS3Cat4]][
      balancedCategory[#1]] & )[doubleS3Cat4Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[doubleS3Cat4Piv2]][
      balancedCategory[#1]] & )[doubleS3Cat4Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[doubleS3Cat4Brd1]][
      ribbonCategory[#1]] & )[doubleS3Cat4Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[doubleS3Cat4]][ribbonCategory[#1]] & )[
    doubleS3Cat4Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[doubleS3Cat4Piv2]][
      ribbonCategory[#1]] & )[doubleS3Cat4Bal2] ^= 1
balancedCategories[doubleS3Cat4Brd1] ^= {doubleS3Cat4Bal1, doubleS3Cat4Bal2}
 
doubleS3Cat4Brd1 /: balancedCategory[doubleS3Cat4Brd1, 1] = doubleS3Cat4Bal1
 
doubleS3Cat4Brd1 /: balancedCategory[doubleS3Cat4Brd1, 2] = doubleS3Cat4Bal2
 
braidedCategory[doubleS3Cat4Brd1] ^= doubleS3Cat4Brd1
 
fusionCategory[doubleS3Cat4Brd1] ^= doubleS3Cat4
 
doubleS3Cat4Brd1 /: modularCategory[doubleS3Cat4Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
doubleS3Cat4Brd1 /: ribbonCategory[doubleS3Cat4Brd1, 1] = doubleS3Cat4Bal1
 
doubleS3Cat4Brd1 /: ribbonCategory[doubleS3Cat4Brd1, 2] = doubleS3Cat4Bal2
 
ring[doubleS3Cat4Brd1] ^= doubleS3
 
rMatrixFunction[doubleS3Cat4Brd1] ^= doubleS3Cat4Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[doubleS3Cat4]][braidedCategory[#1]] & )[
    doubleS3Cat4Brd1] ^= 1
braidedCategory[doubleS3Cat4Brd1RMatrixFunction] ^= doubleS3Cat4Brd1
 
fusionCategory[doubleS3Cat4Brd1RMatrixFunction] ^= doubleS3Cat4
 
rMatrixFunction[doubleS3Cat4Brd1RMatrixFunction] ^= 
   doubleS3Cat4Brd1RMatrixFunction
 
doubleS3Cat4Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[0, 5, 5] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[0, 6, 6] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[0, 7, 7] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[1, 1, 0] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[1, 2, 2] = {{-1}}
 
doubleS3Cat4Brd1RMatrixFunction[1, 3, 4] = {{I}}
 
doubleS3Cat4Brd1RMatrixFunction[1, 4, 3] = {{-I}}
 
doubleS3Cat4Brd1RMatrixFunction[1, 5, 5] = {{-1}}
 
doubleS3Cat4Brd1RMatrixFunction[1, 6, 6] = {{-1}}
 
doubleS3Cat4Brd1RMatrixFunction[1, 7, 7] = {{-1}}
 
doubleS3Cat4Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[2, 1, 2] = {{-1}}
 
doubleS3Cat4Brd1RMatrixFunction[2, 2, 0] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[2, 2, 1] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3Cat4Brd1RMatrixFunction[2, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[2, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[2, 3, 4] = {{(-1)^(5/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[2, 4, 3] = {{-(-1)^(5/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[2, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[2, 5, 6] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[2, 5, 7] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[2, 6, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[2, 6, 7] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[2, 7, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[2, 7, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 1, 4] = {{I}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 2, 4] = {{(-1)^(5/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 3, 0] = {{-1}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 3, 5] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 3, 6] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 3, 7] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 4, 1] = {{I}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 4, 2] = {{(-1)^(1/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 4, 5] = {{(-1)^(1/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 4, 6] = {{(-1)^(5/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 4, 7] = {{(-1)^(5/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 5, 4] = {{(-1)^(5/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 6, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 6, 4] = {{(-1)^(1/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 7, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[3, 7, 4] = {{(-1)^(1/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 1, 3] = {{-I}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 2, 3] = {{-(-1)^(5/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 3, 1] = {{I}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 3, 2] = {{(-1)^(1/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 3, 5] = {{(-1)^(1/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 3, 6] = {{(-1)^(5/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 3, 7] = {{(-1)^(5/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 4, 0] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 4, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 4, 7] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 5, 3] = {{-(-1)^(5/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 6, 3] = {{-(-1)^(1/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 6, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 7, 3] = {{-(-1)^(1/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[4, 7, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[5, 0, 5] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[5, 1, 5] = {{-1}}
 
doubleS3Cat4Brd1RMatrixFunction[5, 2, 6] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[5, 2, 7] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[5, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[5, 3, 4] = {{(-1)^(5/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[5, 4, 3] = {{-(-1)^(5/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[5, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[5, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[5, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3Cat4Brd1RMatrixFunction[5, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[5, 6, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[5, 6, 7] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[5, 7, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[5, 7, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[6, 0, 6] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[6, 1, 6] = {{-1}}
 
doubleS3Cat4Brd1RMatrixFunction[6, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[6, 2, 7] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[6, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[6, 3, 4] = {{(-1)^(1/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[6, 4, 3] = {{-(-1)^(1/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[6, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[6, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[6, 5, 7] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[6, 6, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[6, 6, 1] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3Cat4Brd1RMatrixFunction[6, 6, 6] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[6, 7, 2] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[6, 7, 5] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[7, 0, 7] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[7, 1, 7] = {{-1}}
 
doubleS3Cat4Brd1RMatrixFunction[7, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[7, 2, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[7, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[7, 3, 4] = {{(-1)^(1/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[7, 4, 3] = {{-(-1)^(1/6)}}
 
doubleS3Cat4Brd1RMatrixFunction[7, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[7, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[7, 5, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[7, 6, 2] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[7, 6, 5] = {{1}}
 
doubleS3Cat4Brd1RMatrixFunction[7, 7, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3Cat4Brd1RMatrixFunction[7, 7, 1] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3Cat4Brd1RMatrixFunction[7, 7, 7] = {{(I/2)*(I + Sqrt[3])}}
fMatrixFunction[doubleS3Cat4FMatrixFunction] ^= doubleS3Cat4FMatrixFunction
 
fusionCategory[doubleS3Cat4FMatrixFunction] ^= doubleS3Cat4
 
ring[doubleS3Cat4FMatrixFunction] ^= doubleS3
 
doubleS3Cat4FMatrixFunction[1, 2, 2, 2] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 2, 3, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 2, 3, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 2, 4, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 2, 4, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 2, 5, 6] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 2, 6, 5] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 2, 6, 7] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 3, 1, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 3, 2, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 3, 4, 2] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 3, 4, 5] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 3, 4, 6] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 3, 4, 7] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 3, 5, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 3, 6, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 3, 7, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 4, 1, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 4, 2, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 4, 3, 0] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 4, 4, 2] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 4, 4, 5] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 4, 4, 6] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 4, 4, 7] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 4, 6, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 4, 7, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 5, 2, 6] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 5, 2, 7] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 5, 3, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 5, 3, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 5, 4, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 5, 4, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 5, 5, 5] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 5, 6, 2] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 6, 2, 5] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 6, 3, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 6, 3, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 6, 4, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 6, 4, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 6, 5, 2] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 6, 5, 7] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 6, 6, 6] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 7, 2, 5] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 7, 3, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 7, 3, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 7, 4, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 7, 4, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 7, 5, 6] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 7, 6, 2] = {{-1}}
 
doubleS3Cat4FMatrixFunction[1, 7, 7, 7] = {{-1}}
 
doubleS3Cat4FMatrixFunction[2, 1, 2, 2] = {{-1}}
 
doubleS3Cat4FMatrixFunction[2, 1, 5, 6] = {{-1}}
 
doubleS3Cat4FMatrixFunction[2, 1, 6, 5] = {{-1}}
 
doubleS3Cat4FMatrixFunction[2, 1, 7, 6] = {{-1}}
 
doubleS3Cat4FMatrixFunction[2, 2, 1, 2] = {{-1}}
 
doubleS3Cat4FMatrixFunction[2, 2, 2, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
doubleS3Cat4FMatrixFunction[2, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 2, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[2, 2, 4, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[2, 2, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 2, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 2, 6, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 2, 7, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[2, 3, 1, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[2, 3, 2, 3] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[2, 3, 2, 4] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[2, 3, 3, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 3, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[2, 3, 3, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[2, 3, 3, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 3, 4, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[2, 3, 4, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 3, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[2, 3, 4, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 3, 4, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[2, 3, 5, 3] = {{1, 0}, {0, -1}}
 
doubleS3Cat4FMatrixFunction[2, 3, 5, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[2, 3, 6, 3] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[2, 3, 6, 4] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[2, 3, 7, 3] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[2, 3, 7, 4] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[2, 4, 1, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[2, 4, 2, 3] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[2, 4, 2, 4] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[2, 4, 3, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[2, 4, 3, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[2, 4, 3, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 4, 3, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 4, 4, 0] = {{-1}}
 
doubleS3Cat4FMatrixFunction[2, 4, 4, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 4, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 4, 4, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 4, 4, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 4, 5, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[2, 4, 5, 4] = {{-1, 0}, {0, 1}}
 
doubleS3Cat4FMatrixFunction[2, 4, 6, 3] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[2, 4, 6, 4] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[2, 4, 7, 3] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[2, 4, 7, 4] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[2, 5, 1, 6] = {{-1}}
 
doubleS3Cat4FMatrixFunction[2, 5, 1, 7] = {{-1}}
 
doubleS3Cat4FMatrixFunction[2, 5, 2, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[2, 5, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[2, 5, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[2, 5, 4, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 5, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 5, 5, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 5, 6, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[2, 6, 1, 5] = {{-1}}
 
doubleS3Cat4FMatrixFunction[2, 6, 2, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[2, 6, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[2, 6, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 6, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[2, 6, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 6, 5, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[2, 6, 6, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 6, 7, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[2, 7, 1, 5] = {{-1}}
 
doubleS3Cat4FMatrixFunction[2, 7, 2, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[2, 7, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 7, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 7, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 7, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[2, 7, 7, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 1, 3, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[3, 1, 4, 0] = {{-1}}
 
doubleS3Cat4FMatrixFunction[3, 2, 1, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[3, 2, 1, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[3, 2, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 2, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 2, 3, 2] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[3, 2, 3, 5] = {{1, 0}, {0, -1}}
 
doubleS3Cat4FMatrixFunction[3, 2, 3, 6] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[3, 2, 3, 7] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[3, 2, 4, 2] = {{Sqrt[3]/2, 1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[3, 2, 4, 5] = {{0, -1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[3, 2, 4, 6] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[3, 2, 4, 7] = {{Sqrt[3]/2, 1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[3, 2, 5, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 2, 5, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 2, 6, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 2, 6, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 2, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 2, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 3, 1, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[3, 3, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 3, 2, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 3, 2, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 3, 2, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 3, 3, 3] = 
   {{-1/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {-Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, {-Sqrt[2]/3, -2/3, 1/3, 1/3, 1/3}, 
    {-Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}, {-Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}}
 
doubleS3Cat4FMatrixFunction[3, 3, 3, 4] = 
   {{-(1/Sqrt[3]), 0, 1/Sqrt[3], -(1/Sqrt[3])}, {0, -(1/Sqrt[3]), 1/Sqrt[3], 
     1/Sqrt[3]}, {1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3], 0}, 
    {-(1/Sqrt[3]), 1/Sqrt[3], 0, 1/Sqrt[3]}}
 
doubleS3Cat4FMatrixFunction[3, 3, 4, 3] = 
   {{-(1/Sqrt[3]), 0, 1/Sqrt[3], -(1/Sqrt[3])}, {0, -(1/Sqrt[3]), 1/Sqrt[3], 
     1/Sqrt[3]}, {1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3], 0}, 
    {-(1/Sqrt[3]), 1/Sqrt[3], 0, 1/Sqrt[3]}}
 
doubleS3Cat4FMatrixFunction[3, 3, 4, 4] = 
   {{1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {Sqrt[2]/3, -1/3, 2/3, -1/3, -1/3}, {Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, 
    {Sqrt[2]/3, -1/3, -1/3, -1/3, 2/3}, {Sqrt[2]/3, -1/3, -1/3, 2/3, -1/3}}
 
doubleS3Cat4FMatrixFunction[3, 3, 5, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 3, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 3, 5, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 3, 5, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 3, 6, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 3, 6, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 3, 6, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 3, 6, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 3, 7, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 3, 7, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 3, 7, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 3, 7, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 4, 1, 0] = {{-1}}
 
doubleS3Cat4FMatrixFunction[3, 4, 2, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 4, 2, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 4, 2, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 4, 2, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 4, 3, 3] = 
   {{-(1/Sqrt[3]), 0, 1/Sqrt[3], -(1/Sqrt[3])}, {0, -(1/Sqrt[3]), 1/Sqrt[3], 
     1/Sqrt[3]}, {1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3], 0}, 
    {-(1/Sqrt[3]), 1/Sqrt[3], 0, 1/Sqrt[3]}}
 
doubleS3Cat4FMatrixFunction[3, 4, 3, 4] = 
   {{1/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {-Sqrt[2]/3, -1/3, 2/3, -1/3, -1/3}, {-Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, 
    {-Sqrt[2]/3, -1/3, -1/3, -1/3, 2/3}, {-Sqrt[2]/3, -1/3, -1/3, 2/3, -1/3}}
 
doubleS3Cat4FMatrixFunction[3, 4, 4, 3] = 
   {{-1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, {Sqrt[2]/3, -2/3, 1/3, 1/3, 1/3}, 
    {Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}, {Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}}
 
doubleS3Cat4FMatrixFunction[3, 4, 4, 4] = 
   {{-(1/Sqrt[3]), 0, 1/Sqrt[3], -(1/Sqrt[3])}, {0, -(1/Sqrt[3]), 1/Sqrt[3], 
     1/Sqrt[3]}, {1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3], 0}, 
    {-(1/Sqrt[3]), 1/Sqrt[3], 0, 1/Sqrt[3]}}
 
doubleS3Cat4FMatrixFunction[3, 4, 5, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 4, 5, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 4, 5, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 4, 5, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 4, 6, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 4, 6, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 4, 6, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 4, 6, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 4, 7, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 4, 7, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 4, 7, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 4, 7, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 5, 1, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[3, 5, 1, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[3, 5, 2, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 5, 2, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 5, 3, 2] = {{1, 0}, {0, -1}}
 
doubleS3Cat4FMatrixFunction[3, 5, 3, 5] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[3, 5, 3, 6] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[3, 5, 3, 7] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[3, 5, 4, 2] = {{0, -1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[3, 5, 4, 5] = {{Sqrt[3]/2, 1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[3, 5, 4, 6] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[3, 5, 4, 7] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[3, 5, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 5, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 5, 6, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 5, 6, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 5, 7, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 5, 7, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 6, 1, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[3, 6, 1, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[3, 6, 2, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 6, 2, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 6, 3, 2] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[3, 6, 3, 5] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[3, 6, 3, 6] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[3, 6, 3, 7] = {{1, 0}, {0, -1}}
 
doubleS3Cat4FMatrixFunction[3, 6, 4, 2] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[3, 6, 4, 5] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[3, 6, 4, 6] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[3, 6, 4, 7] = {{0, -1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[3, 6, 5, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 6, 5, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 6, 6, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 6, 6, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 6, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 6, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 7, 1, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[3, 7, 1, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[3, 7, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 7, 2, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 7, 3, 2] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[3, 7, 3, 5] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[3, 7, 3, 6] = {{1, 0}, {0, -1}}
 
doubleS3Cat4FMatrixFunction[3, 7, 3, 7] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[3, 7, 4, 2] = {{Sqrt[3]/2, 1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[3, 7, 4, 5] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[3, 7, 4, 6] = {{0, -1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[3, 7, 4, 7] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[3, 7, 5, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 7, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[3, 7, 6, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 7, 6, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 7, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[3, 7, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 1, 3, 0] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 1, 4, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 2, 1, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 2, 1, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 2, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 2, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 2, 3, 2] = {{Sqrt[3]/2, -1/2}, 
    {1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[4, 2, 3, 5] = {{0, 1}, {-1, 0}}
 
doubleS3Cat4FMatrixFunction[4, 2, 3, 6] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[4, 2, 3, 7] = {{Sqrt[3]/2, -1/2}, 
    {1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[4, 2, 4, 2] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[4, 2, 4, 5] = {{-1, 0}, {0, 1}}
 
doubleS3Cat4FMatrixFunction[4, 2, 4, 6] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[4, 2, 4, 7] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[4, 2, 5, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 2, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 2, 6, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 2, 6, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 2, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 2, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 3, 1, 2] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 3, 1, 5] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 3, 1, 6] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 3, 1, 7] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 3, 2, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 3, 2, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 3, 2, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 3, 2, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 3, 2, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 3, 3, 3] = 
   {{-(1/Sqrt[3]), 0, 1/Sqrt[3], -(1/Sqrt[3])}, {0, -(1/Sqrt[3]), 1/Sqrt[3], 
     1/Sqrt[3]}, {1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3], 0}, 
    {-(1/Sqrt[3]), 1/Sqrt[3], 0, 1/Sqrt[3]}}
 
doubleS3Cat4FMatrixFunction[4, 3, 3, 4] = 
   {{1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {Sqrt[2]/3, -1/3, 2/3, -1/3, -1/3}, {Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, 
    {Sqrt[2]/3, -1/3, -1/3, -1/3, 2/3}, {Sqrt[2]/3, -1/3, -1/3, 2/3, -1/3}}
 
doubleS3Cat4FMatrixFunction[4, 3, 4, 3] = 
   {{1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {Sqrt[2]/3, -1/3, 2/3, -1/3, -1/3}, {Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, 
    {Sqrt[2]/3, -1/3, -1/3, -1/3, 2/3}, {Sqrt[2]/3, -1/3, -1/3, 2/3, -1/3}}
 
doubleS3Cat4FMatrixFunction[4, 3, 4, 4] = 
   {{1/Sqrt[3], 0, -(1/Sqrt[3]), 1/Sqrt[3]}, {0, 1/Sqrt[3], -(1/Sqrt[3]), 
     -(1/Sqrt[3])}, {-(1/Sqrt[3]), -(1/Sqrt[3]), -(1/Sqrt[3]), 0}, 
    {1/Sqrt[3], -(1/Sqrt[3]), 0, -(1/Sqrt[3])}}
 
doubleS3Cat4FMatrixFunction[4, 3, 5, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 3, 5, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 3, 5, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 3, 5, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 3, 5, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 3, 6, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 3, 6, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 3, 6, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 3, 6, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 3, 6, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 3, 7, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 3, 7, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 3, 7, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 3, 7, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 3, 7, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 4, 1, 2] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 4, 1, 5] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 4, 1, 6] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 4, 1, 7] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 4, 2, 0] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 4, 2, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 4, 2, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 4, 2, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 4, 2, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 4, 3, 3] = 
   {{-1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, {Sqrt[2]/3, -2/3, 1/3, 1/3, 1/3}, 
    {Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}, {Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}}
 
doubleS3Cat4FMatrixFunction[4, 4, 3, 4] = 
   {{-(1/Sqrt[3]), 0, 1/Sqrt[3], -(1/Sqrt[3])}, {0, -(1/Sqrt[3]), 1/Sqrt[3], 
     1/Sqrt[3]}, {1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3], 0}, 
    {-(1/Sqrt[3]), 1/Sqrt[3], 0, 1/Sqrt[3]}}
 
doubleS3Cat4FMatrixFunction[4, 4, 4, 3] = 
   {{1/Sqrt[3], 0, -(1/Sqrt[3]), 1/Sqrt[3]}, {0, 1/Sqrt[3], -(1/Sqrt[3]), 
     -(1/Sqrt[3])}, {-(1/Sqrt[3]), -(1/Sqrt[3]), -(1/Sqrt[3]), 0}, 
    {1/Sqrt[3], -(1/Sqrt[3]), 0, -(1/Sqrt[3])}}
 
doubleS3Cat4FMatrixFunction[4, 4, 4, 4] = 
   {{-1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, {Sqrt[2]/3, -2/3, 1/3, 1/3, 1/3}, 
    {Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}, {Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}}
 
doubleS3Cat4FMatrixFunction[4, 4, 5, 0] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 4, 5, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 4, 5, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 4, 5, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 4, 5, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 4, 6, 0] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 4, 6, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 4, 6, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 4, 6, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 4, 6, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 4, 7, 0] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 4, 7, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 4, 7, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 4, 7, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 4, 7, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 5, 1, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 5, 1, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 5, 2, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 5, 2, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 5, 3, 2] = {{0, 1}, {-1, 0}}
 
doubleS3Cat4FMatrixFunction[4, 5, 3, 5] = {{Sqrt[3]/2, -1/2}, 
    {1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[4, 5, 3, 6] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[4, 5, 3, 7] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[4, 5, 4, 2] = {{-1, 0}, {0, 1}}
 
doubleS3Cat4FMatrixFunction[4, 5, 4, 5] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[4, 5, 4, 6] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[4, 5, 4, 7] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[4, 5, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 5, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 5, 6, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 5, 6, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 5, 7, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 5, 7, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 6, 1, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 6, 1, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 6, 2, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 6, 2, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 6, 3, 2] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[4, 6, 3, 5] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[4, 6, 3, 6] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[4, 6, 3, 7] = {{0, 1}, {-1, 0}}
 
doubleS3Cat4FMatrixFunction[4, 6, 4, 2] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[4, 6, 4, 5] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[4, 6, 4, 6] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[4, 6, 4, 7] = {{-1, 0}, {0, 1}}
 
doubleS3Cat4FMatrixFunction[4, 6, 5, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 6, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 6, 6, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 6, 6, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 6, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 6, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 7, 1, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 7, 1, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[4, 7, 2, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 7, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 7, 3, 2] = {{Sqrt[3]/2, -1/2}, 
    {1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[4, 7, 3, 5] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[4, 7, 3, 6] = {{0, 1}, {-1, 0}}
 
doubleS3Cat4FMatrixFunction[4, 7, 3, 7] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[4, 7, 4, 2] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[4, 7, 4, 5] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[4, 7, 4, 6] = {{-1, 0}, {0, 1}}
 
doubleS3Cat4FMatrixFunction[4, 7, 4, 7] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[4, 7, 5, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 7, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 7, 6, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 7, 6, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[4, 7, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[4, 7, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[5, 1, 2, 6] = {{-1}}
 
doubleS3Cat4FMatrixFunction[5, 1, 5, 5] = {{-1}}
 
doubleS3Cat4FMatrixFunction[5, 1, 6, 2] = {{-1}}
 
doubleS3Cat4FMatrixFunction[5, 1, 7, 2] = {{-1}}
 
doubleS3Cat4FMatrixFunction[5, 2, 1, 6] = {{-1}}
 
doubleS3Cat4FMatrixFunction[5, 2, 2, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[5, 2, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 2, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[5, 2, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 2, 5, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[5, 2, 6, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[5, 2, 7, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[5, 3, 1, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[5, 3, 2, 3] = {{1, 0}, {0, -1}}
 
doubleS3Cat4FMatrixFunction[5, 3, 2, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[5, 3, 3, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[5, 3, 3, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[5, 3, 3, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 3, 3, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 3, 4, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[5, 3, 4, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 3, 4, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[5, 3, 4, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 3, 4, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 3, 5, 3] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[5, 3, 5, 4] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[5, 3, 6, 3] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[5, 3, 6, 4] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[5, 3, 7, 3] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[5, 3, 7, 4] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[5, 4, 1, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[5, 4, 2, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[5, 4, 2, 4] = {{-1, 0}, {0, 1}}
 
doubleS3Cat4FMatrixFunction[5, 4, 3, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 4, 3, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 4, 3, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 4, 3, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 4, 4, 0] = {{-1}}
 
doubleS3Cat4FMatrixFunction[5, 4, 4, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 4, 4, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[5, 4, 4, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[5, 4, 4, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[5, 4, 5, 3] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[5, 4, 5, 4] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[5, 4, 6, 3] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[5, 4, 6, 4] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[5, 4, 7, 3] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[5, 4, 7, 4] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[5, 5, 1, 5] = {{-1}}
 
doubleS3Cat4FMatrixFunction[5, 5, 2, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 5, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[5, 5, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 5, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 5, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[5, 5, 5, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[5, 5, 5, 5] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
doubleS3Cat4FMatrixFunction[5, 5, 6, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 5, 7, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 6, 1, 2] = {{-1}}
 
doubleS3Cat4FMatrixFunction[5, 6, 1, 7] = {{-1}}
 
doubleS3Cat4FMatrixFunction[5, 6, 2, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[5, 6, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 6, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 6, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[5, 6, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[5, 6, 5, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[5, 6, 6, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 7, 1, 6] = {{-1}}
 
doubleS3Cat4FMatrixFunction[5, 7, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 7, 3, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[5, 7, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[5, 7, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[5, 7, 5, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[5, 7, 7, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[6, 1, 2, 5] = {{-1}}
 
doubleS3Cat4FMatrixFunction[6, 1, 5, 2] = {{-1}}
 
doubleS3Cat4FMatrixFunction[6, 1, 6, 6] = {{-1}}
 
doubleS3Cat4FMatrixFunction[6, 1, 7, 5] = {{-1}}
 
doubleS3Cat4FMatrixFunction[6, 2, 1, 5] = {{-1}}
 
doubleS3Cat4FMatrixFunction[6, 2, 1, 7] = {{-1}}
 
doubleS3Cat4FMatrixFunction[6, 2, 2, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[6, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 2, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 2, 4, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[6, 2, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[6, 2, 5, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[6, 2, 6, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[6, 3, 1, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[6, 3, 2, 3] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[6, 3, 2, 4] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[6, 3, 3, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 3, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[6, 3, 3, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 3, 3, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 3, 4, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[6, 3, 4, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 3, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 3, 4, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 3, 4, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[6, 3, 5, 3] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[6, 3, 5, 4] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[6, 3, 6, 3] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[6, 3, 6, 4] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[6, 3, 7, 3] = {{1, 0}, {0, -1}}
 
doubleS3Cat4FMatrixFunction[6, 3, 7, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[6, 4, 1, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[6, 4, 2, 3] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[6, 4, 2, 4] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[6, 4, 3, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 4, 3, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 4, 3, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[6, 4, 3, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 4, 4, 0] = {{-1}}
 
doubleS3Cat4FMatrixFunction[6, 4, 4, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[6, 4, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 4, 4, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 4, 4, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 4, 5, 3] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[6, 4, 5, 4] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[6, 4, 6, 3] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[6, 4, 6, 4] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[6, 4, 7, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[6, 4, 7, 4] = {{-1, 0}, {0, 1}}
 
doubleS3Cat4FMatrixFunction[6, 5, 1, 2] = {{-1}}
 
doubleS3Cat4FMatrixFunction[6, 5, 2, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[6, 5, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[6, 5, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 5, 4, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[6, 5, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 5, 5, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[6, 5, 6, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[6, 5, 7, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[6, 6, 1, 6] = {{-1}}
 
doubleS3Cat4FMatrixFunction[6, 6, 2, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[6, 6, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 6, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[6, 6, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[6, 6, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 6, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[6, 6, 6, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[6, 6, 6, 6] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
doubleS3Cat4FMatrixFunction[6, 6, 7, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 7, 1, 2] = {{-1}}
 
doubleS3Cat4FMatrixFunction[6, 7, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 7, 3, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 7, 4, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 7, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[6, 7, 6, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[6, 7, 7, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 1, 2, 6] = {{-1}}
 
doubleS3Cat4FMatrixFunction[7, 1, 5, 2] = {{-1}}
 
doubleS3Cat4FMatrixFunction[7, 1, 6, 5] = {{-1}}
 
doubleS3Cat4FMatrixFunction[7, 1, 7, 7] = {{-1}}
 
doubleS3Cat4FMatrixFunction[7, 2, 2, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[7, 2, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[7, 2, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[7, 2, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[7, 2, 5, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[7, 2, 7, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[7, 3, 1, 3] = {{-1}}
 
doubleS3Cat4FMatrixFunction[7, 3, 2, 3] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[7, 3, 2, 4] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[7, 3, 3, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[7, 3, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[7, 3, 3, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 3, 3, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 3, 4, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[7, 3, 4, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 3, 4, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 3, 4, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[7, 3, 4, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 3, 5, 3] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[7, 3, 5, 4] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[7, 3, 6, 3] = {{1, 0}, {0, -1}}
 
doubleS3Cat4FMatrixFunction[7, 3, 6, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[7, 3, 7, 3] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat4FMatrixFunction[7, 3, 7, 4] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[7, 4, 1, 4] = {{-1}}
 
doubleS3Cat4FMatrixFunction[7, 4, 2, 3] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[7, 4, 2, 4] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[7, 4, 3, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[7, 4, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 4, 3, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 4, 3, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[7, 4, 4, 0] = {{-1}}
 
doubleS3Cat4FMatrixFunction[7, 4, 4, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[7, 4, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 4, 4, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 4, 4, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 4, 5, 3] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[7, 4, 5, 4] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[7, 4, 6, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[7, 4, 6, 4] = {{-1, 0}, {0, 1}}
 
doubleS3Cat4FMatrixFunction[7, 4, 7, 3] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat4FMatrixFunction[7, 4, 7, 4] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat4FMatrixFunction[7, 5, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[7, 5, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 5, 4, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[7, 5, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 5, 5, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[7, 5, 6, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[7, 5, 7, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[7, 6, 2, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[7, 6, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 6, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 6, 4, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 6, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 6, 6, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 6, 7, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat4FMatrixFunction[7, 7, 1, 7] = {{-1}}
 
doubleS3Cat4FMatrixFunction[7, 7, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 7, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 7, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[7, 7, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[7, 7, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 7, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat4FMatrixFunction[7, 7, 6, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat4FMatrixFunction[7, 7, 7, 1] = {{-1}}
 
doubleS3Cat4FMatrixFunction[7, 7, 7, 7] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
doubleS3Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
doubleS3Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[doubleS3Cat4Piv1] ^= {doubleS3Cat4Bal1}
 
doubleS3Cat4Piv1 /: balancedCategory[doubleS3Cat4Piv1, 1] = doubleS3Cat4Bal1
 
fusionCategory[doubleS3Cat4Piv1] ^= doubleS3Cat4
 
doubleS3Cat4Piv1 /: modularCategory[doubleS3Cat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[doubleS3Cat4Piv1] ^= doubleS3Cat4Piv1
 
pivotalIsomorphism[doubleS3Cat4Piv1] ^= doubleS3Cat4Piv1PivotalIsomorphism
 
doubleS3Cat4Piv1 /: ribbonCategory[doubleS3Cat4Piv1, 1] = doubleS3Cat4Bal1
 
ring[doubleS3Cat4Piv1] ^= doubleS3
 
sphericalCategory[doubleS3Cat4Piv1] ^= doubleS3Cat4Piv1
 
(pivotalCategoryIndex[fusionCategory[doubleS3Cat4]][pivotalCategory[#1]] & )[
    doubleS3Cat4Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[doubleS3Cat4]][
      sphericalCategory[#1]] & )[doubleS3Cat4Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[doubleS3Cat4Piv1PivotalIsomorphism] ^= doubleS3Cat4
 
pivotalCategory[doubleS3Cat4Piv1PivotalIsomorphism] ^= doubleS3Cat4Piv1
 
pivotalIsomorphism[doubleS3Cat4Piv1PivotalIsomorphism] ^= 
   doubleS3Cat4Piv1PivotalIsomorphism
 
doubleS3Cat4Piv1PivotalIsomorphism[0] = 1
 
doubleS3Cat4Piv1PivotalIsomorphism[1] = 1
 
doubleS3Cat4Piv1PivotalIsomorphism[2] = 1
 
doubleS3Cat4Piv1PivotalIsomorphism[3] = 1
 
doubleS3Cat4Piv1PivotalIsomorphism[4] = 1
 
doubleS3Cat4Piv1PivotalIsomorphism[5] = 1
 
doubleS3Cat4Piv1PivotalIsomorphism[6] = 1
 
doubleS3Cat4Piv1PivotalIsomorphism[7] = 1
balancedCategories[doubleS3Cat4Piv2] ^= {doubleS3Cat4Bal2}
 
doubleS3Cat4Piv2 /: balancedCategory[doubleS3Cat4Piv2, 1] = doubleS3Cat4Bal2
 
fusionCategory[doubleS3Cat4Piv2] ^= doubleS3Cat4
 
doubleS3Cat4Piv2 /: modularCategory[doubleS3Cat4Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[doubleS3Cat4Piv2] ^= doubleS3Cat4Piv2
 
pivotalIsomorphism[doubleS3Cat4Piv2] ^= doubleS3Cat4Piv2PivotalIsomorphism
 
doubleS3Cat4Piv2 /: ribbonCategory[doubleS3Cat4Piv2, 1] = doubleS3Cat4Bal2
 
ring[doubleS3Cat4Piv2] ^= doubleS3
 
sphericalCategory[doubleS3Cat4Piv2] ^= doubleS3Cat4Piv2
 
(pivotalCategoryIndex[fusionCategory[doubleS3Cat4]][pivotalCategory[#1]] & )[
    doubleS3Cat4Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[doubleS3Cat4]][
      sphericalCategory[#1]] & )[doubleS3Cat4Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[doubleS3Cat4Piv2PivotalIsomorphism] ^= doubleS3Cat4
 
pivotalCategory[doubleS3Cat4Piv2PivotalIsomorphism] ^= doubleS3Cat4Piv2
 
pivotalIsomorphism[doubleS3Cat4Piv2PivotalIsomorphism] ^= 
   doubleS3Cat4Piv2PivotalIsomorphism
 
doubleS3Cat4Piv2PivotalIsomorphism[0] = 1
 
doubleS3Cat4Piv2PivotalIsomorphism[1] = 1
 
doubleS3Cat4Piv2PivotalIsomorphism[2] = 1
 
doubleS3Cat4Piv2PivotalIsomorphism[3] = -1
 
doubleS3Cat4Piv2PivotalIsomorphism[4] = -1
 
doubleS3Cat4Piv2PivotalIsomorphism[5] = 1
 
doubleS3Cat4Piv2PivotalIsomorphism[6] = 1
 
doubleS3Cat4Piv2PivotalIsomorphism[7] = 1
balancedCategories[doubleS3Cat5] ^= {}
 
braidedCategories[doubleS3Cat5] ^= {}
 
coeval[doubleS3Cat5] ^= 1/sixJFunction[doubleS3Cat5][#1, 
      dual[ring[doubleS3Cat5]][#1], #1, #1, 0, 0] & 
 
eval[doubleS3Cat5] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[doubleS3Cat5] ^= doubleS3Cat5FMatrixFunction
 
fusionCategory[doubleS3Cat5] ^= doubleS3Cat5
 
doubleS3Cat5 /: modularCategory[doubleS3Cat5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[doubleS3Cat5] ^= {doubleS3Cat5Piv1, doubleS3Cat5Piv2}
 
doubleS3Cat5 /: pivotalCategory[doubleS3Cat5, 1] = doubleS3Cat5Piv1
 
doubleS3Cat5 /: pivotalCategory[doubleS3Cat5, 2] = doubleS3Cat5Piv2
 
doubleS3Cat5 /: pivotalCategory[doubleS3Cat5, {1, 1, 1, -1, 1, 1, 1, 1}] = 
    doubleS3Cat5Piv2
 
doubleS3Cat5 /: pivotalCategory[doubleS3Cat5, {1, 1, 1, 1, -1, 1, 1, 1}] = 
    doubleS3Cat5Piv1
 
ring[doubleS3Cat5] ^= doubleS3
 
doubleS3Cat5 /: sphericalCategory[doubleS3Cat5, 1] = doubleS3Cat5Piv1
 
doubleS3Cat5 /: sphericalCategory[doubleS3Cat5, 2] = doubleS3Cat5Piv2
 
fusionCategoryIndex[doubleS3][doubleS3Cat5] ^= 5
fMatrixFunction[doubleS3Cat5FMatrixFunction] ^= doubleS3Cat5FMatrixFunction
 
fusionCategory[doubleS3Cat5FMatrixFunction] ^= doubleS3Cat5
 
ring[doubleS3Cat5FMatrixFunction] ^= doubleS3
 
doubleS3Cat5FMatrixFunction[1, 2, 2, 2] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 2, 3, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 2, 3, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 2, 4, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 2, 4, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 2, 5, 6] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 2, 6, 7] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 2, 7, 5] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 3, 1, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 3, 2, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 3, 3, 5] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 3, 3, 6] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 3, 3, 7] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 3, 4, 2] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 3, 5, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 3, 6, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 3, 7, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 4, 1, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 4, 2, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 4, 3, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 4, 3, 5] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 4, 3, 6] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 4, 3, 7] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 4, 4, 2] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 4, 6, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 4, 7, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 5, 3, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 5, 3, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 5, 4, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 5, 4, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 5, 5, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 5, 5, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 5, 5, 5] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 5, 6, 7] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 5, 7, 2] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 5, 7, 6] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 6, 3, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 6, 3, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 6, 4, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 6, 4, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 6, 5, 2] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 6, 5, 7] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 6, 6, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 6, 6, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 6, 6, 6] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 6, 7, 5] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 7, 3, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 7, 3, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 7, 4, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 7, 4, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 7, 5, 6] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 7, 6, 2] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 7, 6, 5] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 7, 7, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 7, 7, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[1, 7, 7, 7] = {{-1}}
 
doubleS3Cat5FMatrixFunction[2, 1, 2, 2] = {{-1}}
 
doubleS3Cat5FMatrixFunction[2, 1, 5, 7] = {{-1}}
 
doubleS3Cat5FMatrixFunction[2, 1, 6, 5] = {{-1}}
 
doubleS3Cat5FMatrixFunction[2, 1, 7, 6] = {{-1}}
 
doubleS3Cat5FMatrixFunction[2, 2, 1, 2] = {{-1}}
 
doubleS3Cat5FMatrixFunction[2, 2, 2, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
doubleS3Cat5FMatrixFunction[2, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 2, 3, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[2, 2, 4, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[2, 2, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 2, 5, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[2, 2, 6, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 2, 7, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[2, 3, 1, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[2, 3, 2, 3] = {{1, 0}, {0, -1}}
 
doubleS3Cat5FMatrixFunction[2, 3, 2, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[2, 3, 3, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 3, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[2, 3, 3, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 3, 3, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[2, 3, 4, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[2, 3, 4, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 3, 4, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 3, 4, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[2, 3, 4, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 3, 5, 3] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[2, 3, 5, 4] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[2, 3, 6, 3] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[2, 3, 6, 4] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[2, 3, 7, 3] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[2, 3, 7, 4] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[2, 4, 1, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[2, 4, 2, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[2, 4, 2, 4] = {{-1, 0}, {0, 1}}
 
doubleS3Cat5FMatrixFunction[2, 4, 3, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[2, 4, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 4, 3, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 4, 3, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 4, 4, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[2, 4, 4, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 4, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 4, 4, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 4, 4, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 4, 5, 3] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[2, 4, 5, 4] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[2, 4, 6, 3] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[2, 4, 6, 4] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[2, 4, 7, 3] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[2, 4, 7, 4] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[2, 5, 2, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[2, 5, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 5, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 5, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 5, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 5, 5, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 5, 7, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[2, 6, 2, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[2, 6, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[2, 6, 3, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 6, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[2, 6, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 6, 5, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[2, 6, 6, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[2, 7, 2, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[2, 7, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 7, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 7, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 7, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[2, 7, 6, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[2, 7, 7, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 1, 3, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[3, 1, 4, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[3, 2, 1, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[3, 2, 1, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[3, 2, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 2, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 2, 3, 2] = {{1, 0}, {0, -1}}
 
doubleS3Cat5FMatrixFunction[3, 2, 3, 5] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[3, 2, 3, 6] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[3, 2, 3, 7] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[3, 2, 4, 2] = {{0, -1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[3, 2, 4, 5] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[3, 2, 4, 6] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[3, 2, 4, 7] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[3, 2, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 2, 5, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 2, 6, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 2, 6, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 2, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 2, 7, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 3, 1, 2] = {{-1}}
 
doubleS3Cat5FMatrixFunction[3, 3, 2, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[3, 3, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 3, 2, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 3, 2, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 3, 2, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 3, 3, 3] = 
   {{1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, {Sqrt[2]/3, -1/3, 2/3, -1/3, -1/3}, 
    {Sqrt[2]/3, -1/3, -1/3, 2/3, -1/3}, {Sqrt[2]/3, -1/3, -1/3, -1/3, 2/3}}
 
doubleS3Cat5FMatrixFunction[3, 3, 3, 4] = 
   {{0, 1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3]}, {-(1/Sqrt[3]), 0, 1/Sqrt[3], 
     -(1/Sqrt[3])}, {-(1/Sqrt[3]), -(1/Sqrt[3]), 0, 1/Sqrt[3]}, 
    {-(1/Sqrt[3]), 1/Sqrt[3], -(1/Sqrt[3]), 0}}
 
doubleS3Cat5FMatrixFunction[3, 3, 4, 3] = 
   {{0, -(1/Sqrt[3]), -(1/Sqrt[3]), -(1/Sqrt[3])}, 
    {-(1/Sqrt[3]), 0, 1/Sqrt[3], -(1/Sqrt[3])}, {-(1/Sqrt[3]), -(1/Sqrt[3]), 
     0, 1/Sqrt[3]}, {-(1/Sqrt[3]), 1/Sqrt[3], -(1/Sqrt[3]), 0}}
 
doubleS3Cat5FMatrixFunction[3, 3, 4, 4] = 
   {{1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, {-Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, 
    {-Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}, {-Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}}
 
doubleS3Cat5FMatrixFunction[3, 3, 5, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 3, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 3, 5, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 3, 5, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 3, 6, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 3, 6, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 3, 6, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 3, 6, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 3, 7, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 3, 7, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 3, 7, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 3, 7, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 4, 1, 2] = {{-1}}
 
doubleS3Cat5FMatrixFunction[3, 4, 2, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[3, 4, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 4, 2, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 4, 2, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 4, 2, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 4, 3, 3] = 
   {{0, -(1/Sqrt[3]), -(1/Sqrt[3]), -(1/Sqrt[3])}, 
    {1/Sqrt[3], 0, 1/Sqrt[3], -(1/Sqrt[3])}, {1/Sqrt[3], -(1/Sqrt[3]), 0, 
     1/Sqrt[3]}, {1/Sqrt[3], 1/Sqrt[3], -(1/Sqrt[3]), 0}}
 
doubleS3Cat5FMatrixFunction[3, 4, 3, 4] = 
   {{-1/3, Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {Sqrt[2]/3, -2/3, -1/3, -1/3, -1/3}, {-Sqrt[2]/3, -1/3, -2/3, 1/3, 1/3}, 
    {-Sqrt[2]/3, -1/3, 1/3, -2/3, 1/3}, {-Sqrt[2]/3, -1/3, 1/3, 1/3, -2/3}}
 
doubleS3Cat5FMatrixFunction[3, 4, 4, 3] = 
   {{-1/3, Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {Sqrt[2]/3, -2/3, -1/3, -1/3, -1/3}, {Sqrt[2]/3, 1/3, 2/3, -1/3, -1/3}, 
    {Sqrt[2]/3, 1/3, -1/3, 2/3, -1/3}, {Sqrt[2]/3, 1/3, -1/3, -1/3, 2/3}}
 
doubleS3Cat5FMatrixFunction[3, 4, 4, 4] = 
   {{0, 1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3]}, {1/Sqrt[3], 0, 1/Sqrt[3], 
     -(1/Sqrt[3])}, {1/Sqrt[3], -(1/Sqrt[3]), 0, 1/Sqrt[3]}, 
    {1/Sqrt[3], 1/Sqrt[3], -(1/Sqrt[3]), 0}}
 
doubleS3Cat5FMatrixFunction[3, 4, 5, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 4, 5, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 4, 5, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 4, 5, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 4, 6, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 4, 6, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 4, 6, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 4, 6, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 4, 7, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 4, 7, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 4, 7, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 4, 7, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 5, 1, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[3, 5, 1, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[3, 5, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 5, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 5, 3, 2] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[3, 5, 3, 5] = {{1, 0}, {0, -1}}
 
doubleS3Cat5FMatrixFunction[3, 5, 3, 6] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[3, 5, 3, 7] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[3, 5, 4, 2] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[3, 5, 4, 5] = {{0, -1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[3, 5, 4, 6] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[3, 5, 4, 7] = {{Sqrt[3]/2, 1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[3, 5, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 5, 5, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 5, 6, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 5, 6, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 5, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 5, 7, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 6, 1, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[3, 6, 1, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[3, 6, 2, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 6, 2, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 6, 3, 2] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[3, 6, 3, 5] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[3, 6, 3, 6] = {{1, 0}, {0, -1}}
 
doubleS3Cat5FMatrixFunction[3, 6, 3, 7] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[3, 6, 4, 2] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[3, 6, 4, 5] = {{Sqrt[3]/2, 1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[3, 6, 4, 6] = {{0, -1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[3, 6, 4, 7] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[3, 6, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 6, 5, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 6, 6, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 6, 6, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 6, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 6, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 7, 1, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[3, 7, 1, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[3, 7, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 7, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 7, 3, 2] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[3, 7, 3, 5] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[3, 7, 3, 6] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[3, 7, 3, 7] = {{1, 0}, {0, -1}}
 
doubleS3Cat5FMatrixFunction[3, 7, 4, 2] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[3, 7, 4, 5] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[3, 7, 4, 6] = {{Sqrt[3]/2, 1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[3, 7, 4, 7] = {{0, -1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[3, 7, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 7, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 7, 6, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 7, 6, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[3, 7, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[3, 7, 7, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 1, 3, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 1, 4, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 2, 1, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 2, 1, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 2, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 2, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 2, 3, 2] = {{0, 1}, {-1, 0}}
 
doubleS3Cat5FMatrixFunction[4, 2, 3, 5] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[4, 2, 3, 6] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[4, 2, 3, 7] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[4, 2, 4, 2] = {{-1, 0}, {0, 1}}
 
doubleS3Cat5FMatrixFunction[4, 2, 4, 5] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[4, 2, 4, 6] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[4, 2, 4, 7] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[4, 2, 5, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 2, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 2, 6, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 2, 6, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 2, 7, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 2, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 3, 1, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 3, 1, 5] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 3, 1, 6] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 3, 1, 7] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 3, 2, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 3, 2, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 3, 2, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 3, 2, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 3, 2, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 3, 2, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 3, 3, 3] = 
   {{0, -(1/Sqrt[3]), -(1/Sqrt[3]), -(1/Sqrt[3])}, 
    {-(1/Sqrt[3]), 0, -(1/Sqrt[3]), 1/Sqrt[3]}, {-(1/Sqrt[3]), 1/Sqrt[3], 0, 
     -(1/Sqrt[3])}, {-(1/Sqrt[3]), -(1/Sqrt[3]), 1/Sqrt[3], 0}}
 
doubleS3Cat5FMatrixFunction[4, 3, 3, 4] = 
   {{-1/3, -Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {-Sqrt[2]/3, -2/3, -1/3, -1/3, -1/3}, {-Sqrt[2]/3, 1/3, 2/3, -1/3, -1/3}, 
    {-Sqrt[2]/3, 1/3, -1/3, 2/3, -1/3}, {-Sqrt[2]/3, 1/3, -1/3, -1/3, 2/3}}
 
doubleS3Cat5FMatrixFunction[4, 3, 4, 3] = 
   {{1/3, Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {Sqrt[2]/3, 2/3, 1/3, 1/3, 1/3}, {-Sqrt[2]/3, 1/3, 2/3, -1/3, -1/3}, 
    {-Sqrt[2]/3, 1/3, -1/3, 2/3, -1/3}, {-Sqrt[2]/3, 1/3, -1/3, -1/3, 2/3}}
 
doubleS3Cat5FMatrixFunction[4, 3, 4, 4] = 
   {{0, -(1/Sqrt[3]), -(1/Sqrt[3]), -(1/Sqrt[3])}, 
    {1/Sqrt[3], 0, 1/Sqrt[3], -(1/Sqrt[3])}, {1/Sqrt[3], -(1/Sqrt[3]), 0, 
     1/Sqrt[3]}, {1/Sqrt[3], 1/Sqrt[3], -(1/Sqrt[3]), 0}}
 
doubleS3Cat5FMatrixFunction[4, 3, 5, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 3, 5, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 3, 5, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 3, 5, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 3, 5, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 3, 6, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 3, 6, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 3, 6, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 3, 6, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 3, 6, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 3, 7, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 3, 7, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 3, 7, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 3, 7, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 3, 7, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 4, 1, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 4, 1, 5] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 4, 1, 6] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 4, 1, 7] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 4, 2, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 4, 2, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 4, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 4, 2, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 4, 2, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 4, 2, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 4, 3, 3] = 
   {{1/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3, -Sqrt[2]/3}, 
    {-Sqrt[2]/3, 2/3, -1/3, -1/3, -1/3}, {Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, 
    {Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}, {Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}}
 
doubleS3Cat5FMatrixFunction[4, 4, 3, 4] = 
   {{0, 1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3]}, {1/Sqrt[3], 0, -(1/Sqrt[3]), 
     1/Sqrt[3]}, {1/Sqrt[3], 1/Sqrt[3], 0, -(1/Sqrt[3])}, 
    {1/Sqrt[3], -(1/Sqrt[3]), 1/Sqrt[3], 0}}
 
doubleS3Cat5FMatrixFunction[4, 4, 4, 3] = 
   {{0, 1/Sqrt[3], 1/Sqrt[3], 1/Sqrt[3]}, {-(1/Sqrt[3]), 0, 1/Sqrt[3], 
     -(1/Sqrt[3])}, {-(1/Sqrt[3]), -(1/Sqrt[3]), 0, 1/Sqrt[3]}, 
    {-(1/Sqrt[3]), 1/Sqrt[3], -(1/Sqrt[3]), 0}}
 
doubleS3Cat5FMatrixFunction[4, 4, 4, 4] = 
   {{-1/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3, Sqrt[2]/3}, 
    {Sqrt[2]/3, -2/3, 1/3, 1/3, 1/3}, {Sqrt[2]/3, 1/3, -2/3, 1/3, 1/3}, 
    {Sqrt[2]/3, 1/3, 1/3, -2/3, 1/3}, {Sqrt[2]/3, 1/3, 1/3, 1/3, -2/3}}
 
doubleS3Cat5FMatrixFunction[4, 4, 5, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 4, 5, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 4, 5, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 4, 5, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 4, 5, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 4, 6, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 4, 6, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 4, 6, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 4, 6, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 4, 6, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 4, 7, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 4, 7, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 4, 7, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 4, 7, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 4, 7, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 5, 1, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 5, 1, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 5, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 5, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 5, 3, 2] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[4, 5, 3, 5] = {{0, 1}, {-1, 0}}
 
doubleS3Cat5FMatrixFunction[4, 5, 3, 6] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[4, 5, 3, 7] = {{Sqrt[3]/2, -1/2}, 
    {1/2, Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[4, 5, 4, 2] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[4, 5, 4, 5] = {{-1, 0}, {0, 1}}
 
doubleS3Cat5FMatrixFunction[4, 5, 4, 6] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[4, 5, 4, 7] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[4, 5, 5, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 5, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 5, 6, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 5, 6, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 5, 7, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 5, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 6, 1, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 6, 1, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 6, 2, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 6, 2, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 6, 3, 2] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[4, 6, 3, 5] = {{Sqrt[3]/2, -1/2}, 
    {1/2, Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[4, 6, 3, 6] = {{0, 1}, {-1, 0}}
 
doubleS3Cat5FMatrixFunction[4, 6, 3, 7] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[4, 6, 4, 2] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[4, 6, 4, 5] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[4, 6, 4, 6] = {{-1, 0}, {0, 1}}
 
doubleS3Cat5FMatrixFunction[4, 6, 4, 7] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[4, 6, 5, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 6, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 6, 6, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 6, 6, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 6, 7, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 6, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 7, 1, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 7, 1, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[4, 7, 2, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 7, 2, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 7, 3, 2] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[4, 7, 3, 5] = {{-Sqrt[3]/2, -1/2}, 
    {1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[4, 7, 3, 6] = {{Sqrt[3]/2, -1/2}, 
    {1/2, Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[4, 7, 3, 7] = {{0, 1}, {-1, 0}}
 
doubleS3Cat5FMatrixFunction[4, 7, 4, 2] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[4, 7, 4, 5] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[4, 7, 4, 6] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[4, 7, 4, 7] = {{-1, 0}, {0, 1}}
 
doubleS3Cat5FMatrixFunction[4, 7, 5, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 7, 5, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 7, 6, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 7, 6, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[4, 7, 7, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[4, 7, 7, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[5, 1, 2, 7] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 1, 5, 5] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 1, 6, 7] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 1, 7, 6] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 2, 1, 6] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 2, 2, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[5, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 2, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 2, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 2, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 2, 5, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[5, 3, 1, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 3, 2, 3] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[5, 3, 2, 4] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[5, 3, 3, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 3, 3, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 3, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 3, 3, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 3, 3, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 3, 4, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 3, 4, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 3, 4, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 3, 4, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 3, 4, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 3, 4, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 3, 5, 3] = {{1, 0}, {0, -1}}
 
doubleS3Cat5FMatrixFunction[5, 3, 5, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[5, 3, 6, 3] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[5, 3, 6, 4] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[5, 3, 7, 3] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[5, 3, 7, 4] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[5, 4, 1, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 4, 2, 3] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[5, 4, 2, 4] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[5, 4, 3, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 4, 3, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[5, 4, 3, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 4, 3, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 4, 3, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 4, 4, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 4, 4, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 4, 4, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 4, 4, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[5, 4, 4, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[5, 4, 4, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[5, 4, 5, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[5, 4, 5, 4] = {{-1, 0}, {0, 1}}
 
doubleS3Cat5FMatrixFunction[5, 4, 6, 3] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[5, 4, 6, 4] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[5, 4, 7, 3] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[5, 4, 7, 4] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[5, 5, 1, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 5, 1, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 5, 1, 5] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 5, 2, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 5, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[5, 5, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 5, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 5, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[5, 5, 5, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 5, 5, 5] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {-1/2, 1/2, 1/Sqrt[2]}, {1/Sqrt[2], 1/Sqrt[2], 0}}
 
doubleS3Cat5FMatrixFunction[5, 5, 6, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 5, 7, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 6, 1, 2] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 6, 1, 7] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 6, 2, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 6, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[5, 6, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 6, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 6, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[5, 6, 5, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[5, 6, 6, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 6, 7, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 7, 1, 6] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 7, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[5, 7, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 7, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[5, 7, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[5, 7, 5, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[5, 7, 6, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[5, 7, 7, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 1, 2, 5] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 1, 5, 7] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 1, 6, 6] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 1, 7, 5] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 2, 1, 7] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 2, 2, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[6, 2, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[6, 2, 4, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 2, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 2, 6, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[6, 3, 1, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 3, 2, 3] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[6, 3, 2, 4] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[6, 3, 3, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 3, 3, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[6, 3, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 3, 3, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 3, 3, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 3, 4, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 3, 4, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 3, 4, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 3, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 3, 4, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 3, 4, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 3, 5, 3] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[6, 3, 5, 4] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[6, 3, 6, 3] = {{1, 0}, {0, -1}}
 
doubleS3Cat5FMatrixFunction[6, 3, 6, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[6, 3, 7, 3] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[6, 3, 7, 4] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[6, 4, 1, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 4, 2, 3] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[6, 4, 2, 4] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[6, 4, 3, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 4, 3, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 4, 3, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 4, 3, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 4, 3, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 4, 4, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 4, 4, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 4, 4, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 4, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[6, 4, 4, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[6, 4, 4, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[6, 4, 5, 3] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[6, 4, 5, 4] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[6, 4, 6, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[6, 4, 6, 4] = {{-1, 0}, {0, 1}}
 
doubleS3Cat5FMatrixFunction[6, 4, 7, 3] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[6, 4, 7, 4] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[6, 5, 1, 7] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 5, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[6, 5, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 5, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 5, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[6, 5, 5, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 5, 6, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[6, 5, 7, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 6, 1, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 6, 1, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 6, 1, 6] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 6, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[6, 6, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[6, 6, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 6, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 6, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[6, 6, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 6, 6, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 6, 6, 6] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {-1/2, 1/2, 1/Sqrt[2]}, {1/Sqrt[2], 1/Sqrt[2], 0}}
 
doubleS3Cat5FMatrixFunction[6, 6, 7, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 7, 1, 2] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 7, 1, 5] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 7, 2, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 7, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[6, 7, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 7, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[6, 7, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[6, 7, 5, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[6, 7, 6, 7] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[6, 7, 7, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 1, 2, 6] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 1, 5, 6] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 1, 6, 5] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 1, 7, 7] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 2, 1, 5] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 2, 2, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[7, 2, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 2, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 2, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 2, 4, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 2, 7, 2] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[7, 3, 1, 3] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 3, 2, 3] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[7, 3, 2, 4] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[7, 3, 3, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 3, 3, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 3, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 3, 3, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 3, 3, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 3, 4, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 3, 4, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 3, 4, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 3, 4, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 3, 4, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 3, 4, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 3, 5, 3] = {{-1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[7, 3, 5, 4] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[7, 3, 6, 3] = {{-1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, 1/2}}
 
doubleS3Cat5FMatrixFunction[7, 3, 6, 4] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[7, 3, 7, 3] = {{1, 0}, {0, -1}}
 
doubleS3Cat5FMatrixFunction[7, 3, 7, 4] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[7, 4, 1, 4] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 4, 2, 3] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[7, 4, 2, 4] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[7, 4, 3, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 4, 3, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[7, 4, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 4, 3, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 4, 3, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 4, 4, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 4, 4, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 4, 4, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 4, 4, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[7, 4, 4, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[7, 4, 4, 7] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[7, 4, 5, 3] = {{-Sqrt[3]/2, -1/2}, 
    {-1/2, Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[7, 4, 5, 4] = {{1/2, -Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[7, 4, 6, 3] = {{Sqrt[3]/2, -1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
doubleS3Cat5FMatrixFunction[7, 4, 6, 4] = {{1/2, Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
doubleS3Cat5FMatrixFunction[7, 4, 7, 3] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[7, 4, 7, 4] = {{-1, 0}, {0, 1}}
 
doubleS3Cat5FMatrixFunction[7, 5, 1, 2] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 5, 1, 6] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 5, 2, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 5, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[7, 5, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 5, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 5, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[7, 5, 5, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 5, 6, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 5, 7, 5] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[7, 6, 1, 5] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 6, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[7, 6, 3, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 6, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 6, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[7, 6, 5, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 6, 6, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 6, 7, 6] = {{0, 1}, {1, 0}}
 
doubleS3Cat5FMatrixFunction[7, 7, 1, 0] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 7, 1, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 7, 1, 7] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 7, 2, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 7, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[7, 7, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 7, 4, 3] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 7, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3Cat5FMatrixFunction[7, 7, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 7, 6, 6] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3Cat5FMatrixFunction[7, 7, 7, 1] = {{-1}}
 
doubleS3Cat5FMatrixFunction[7, 7, 7, 7] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {-1/2, 1/2, 1/Sqrt[2]}, {1/Sqrt[2], 1/Sqrt[2], 0}}
 
doubleS3Cat5FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3Cat5], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
doubleS3Cat5FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3Cat5], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[doubleS3Cat5Piv1] ^= {}
 
fusionCategory[doubleS3Cat5Piv1] ^= doubleS3Cat5
 
doubleS3Cat5Piv1 /: modularCategory[doubleS3Cat5Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[doubleS3Cat5Piv1] ^= doubleS3Cat5Piv1
 
pivotalIsomorphism[doubleS3Cat5Piv1] ^= doubleS3Cat5Piv1PivotalIsomorphism
 
ring[doubleS3Cat5Piv1] ^= doubleS3
 
sphericalCategory[doubleS3Cat5Piv1] ^= doubleS3Cat5Piv1
 
(pivotalCategoryIndex[fusionCategory[doubleS3Cat5]][pivotalCategory[#1]] & )[
    doubleS3Cat5Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[doubleS3Cat5]][
      sphericalCategory[#1]] & )[doubleS3Cat5Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[doubleS3Cat5Piv1PivotalIsomorphism] ^= doubleS3Cat5
 
pivotalCategory[doubleS3Cat5Piv1PivotalIsomorphism] ^= doubleS3Cat5Piv1
 
pivotalIsomorphism[doubleS3Cat5Piv1PivotalIsomorphism] ^= 
   doubleS3Cat5Piv1PivotalIsomorphism
 
doubleS3Cat5Piv1PivotalIsomorphism[0] = 1
 
doubleS3Cat5Piv1PivotalIsomorphism[1] = 1
 
doubleS3Cat5Piv1PivotalIsomorphism[2] = 1
 
doubleS3Cat5Piv1PivotalIsomorphism[3] = 1
 
doubleS3Cat5Piv1PivotalIsomorphism[4] = -1
 
doubleS3Cat5Piv1PivotalIsomorphism[5] = 1
 
doubleS3Cat5Piv1PivotalIsomorphism[6] = 1
 
doubleS3Cat5Piv1PivotalIsomorphism[7] = 1
balancedCategories[doubleS3Cat5Piv2] ^= {}
 
fusionCategory[doubleS3Cat5Piv2] ^= doubleS3Cat5
 
doubleS3Cat5Piv2 /: modularCategory[doubleS3Cat5Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[doubleS3Cat5Piv2] ^= doubleS3Cat5Piv2
 
pivotalIsomorphism[doubleS3Cat5Piv2] ^= doubleS3Cat5Piv2PivotalIsomorphism
 
ring[doubleS3Cat5Piv2] ^= doubleS3
 
sphericalCategory[doubleS3Cat5Piv2] ^= doubleS3Cat5Piv2
 
(pivotalCategoryIndex[fusionCategory[doubleS3Cat5]][pivotalCategory[#1]] & )[
    doubleS3Cat5Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[doubleS3Cat5]][
      sphericalCategory[#1]] & )[doubleS3Cat5Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[doubleS3Cat5Piv2PivotalIsomorphism] ^= doubleS3Cat5
 
pivotalCategory[doubleS3Cat5Piv2PivotalIsomorphism] ^= doubleS3Cat5Piv2
 
pivotalIsomorphism[doubleS3Cat5Piv2PivotalIsomorphism] ^= 
   doubleS3Cat5Piv2PivotalIsomorphism
 
doubleS3Cat5Piv2PivotalIsomorphism[0] = 1
 
doubleS3Cat5Piv2PivotalIsomorphism[1] = 1
 
doubleS3Cat5Piv2PivotalIsomorphism[2] = 1
 
doubleS3Cat5Piv2PivotalIsomorphism[3] = -1
 
doubleS3Cat5Piv2PivotalIsomorphism[4] = 1
 
doubleS3Cat5Piv2PivotalIsomorphism[5] = 1
 
doubleS3Cat5Piv2PivotalIsomorphism[6] = 1
 
doubleS3Cat5Piv2PivotalIsomorphism[7] = 1
ring[doubleS3NFunction] ^= doubleS3
 
doubleS3NFunction[0, 0, 0] = 1
 
doubleS3NFunction[0, 0, 1] = 0
 
doubleS3NFunction[0, 0, 2] = 0
 
doubleS3NFunction[0, 0, 3] = 0
 
doubleS3NFunction[0, 0, 4] = 0
 
doubleS3NFunction[0, 0, 5] = 0
 
doubleS3NFunction[0, 0, 6] = 0
 
doubleS3NFunction[0, 0, 7] = 0
 
doubleS3NFunction[0, 1, 0] = 0
 
doubleS3NFunction[0, 1, 1] = 1
 
doubleS3NFunction[0, 1, 2] = 0
 
doubleS3NFunction[0, 1, 3] = 0
 
doubleS3NFunction[0, 1, 4] = 0
 
doubleS3NFunction[0, 1, 5] = 0
 
doubleS3NFunction[0, 1, 6] = 0
 
doubleS3NFunction[0, 1, 7] = 0
 
doubleS3NFunction[0, 2, 0] = 0
 
doubleS3NFunction[0, 2, 1] = 0
 
doubleS3NFunction[0, 2, 2] = 1
 
doubleS3NFunction[0, 2, 3] = 0
 
doubleS3NFunction[0, 2, 4] = 0
 
doubleS3NFunction[0, 2, 5] = 0
 
doubleS3NFunction[0, 2, 6] = 0
 
doubleS3NFunction[0, 2, 7] = 0
 
doubleS3NFunction[0, 3, 0] = 0
 
doubleS3NFunction[0, 3, 1] = 0
 
doubleS3NFunction[0, 3, 2] = 0
 
doubleS3NFunction[0, 3, 3] = 1
 
doubleS3NFunction[0, 3, 4] = 0
 
doubleS3NFunction[0, 3, 5] = 0
 
doubleS3NFunction[0, 3, 6] = 0
 
doubleS3NFunction[0, 3, 7] = 0
 
doubleS3NFunction[0, 4, 0] = 0
 
doubleS3NFunction[0, 4, 1] = 0
 
doubleS3NFunction[0, 4, 2] = 0
 
doubleS3NFunction[0, 4, 3] = 0
 
doubleS3NFunction[0, 4, 4] = 1
 
doubleS3NFunction[0, 4, 5] = 0
 
doubleS3NFunction[0, 4, 6] = 0
 
doubleS3NFunction[0, 4, 7] = 0
 
doubleS3NFunction[0, 5, 0] = 0
 
doubleS3NFunction[0, 5, 1] = 0
 
doubleS3NFunction[0, 5, 2] = 0
 
doubleS3NFunction[0, 5, 3] = 0
 
doubleS3NFunction[0, 5, 4] = 0
 
doubleS3NFunction[0, 5, 5] = 1
 
doubleS3NFunction[0, 5, 6] = 0
 
doubleS3NFunction[0, 5, 7] = 0
 
doubleS3NFunction[0, 6, 0] = 0
 
doubleS3NFunction[0, 6, 1] = 0
 
doubleS3NFunction[0, 6, 2] = 0
 
doubleS3NFunction[0, 6, 3] = 0
 
doubleS3NFunction[0, 6, 4] = 0
 
doubleS3NFunction[0, 6, 5] = 0
 
doubleS3NFunction[0, 6, 6] = 1
 
doubleS3NFunction[0, 6, 7] = 0
 
doubleS3NFunction[0, 7, 0] = 0
 
doubleS3NFunction[0, 7, 1] = 0
 
doubleS3NFunction[0, 7, 2] = 0
 
doubleS3NFunction[0, 7, 3] = 0
 
doubleS3NFunction[0, 7, 4] = 0
 
doubleS3NFunction[0, 7, 5] = 0
 
doubleS3NFunction[0, 7, 6] = 0
 
doubleS3NFunction[0, 7, 7] = 1
 
doubleS3NFunction[1, 0, 0] = 0
 
doubleS3NFunction[1, 0, 1] = 1
 
doubleS3NFunction[1, 0, 2] = 0
 
doubleS3NFunction[1, 0, 3] = 0
 
doubleS3NFunction[1, 0, 4] = 0
 
doubleS3NFunction[1, 0, 5] = 0
 
doubleS3NFunction[1, 0, 6] = 0
 
doubleS3NFunction[1, 0, 7] = 0
 
doubleS3NFunction[1, 1, 0] = 1
 
doubleS3NFunction[1, 1, 1] = 0
 
doubleS3NFunction[1, 1, 2] = 0
 
doubleS3NFunction[1, 1, 3] = 0
 
doubleS3NFunction[1, 1, 4] = 0
 
doubleS3NFunction[1, 1, 5] = 0
 
doubleS3NFunction[1, 1, 6] = 0
 
doubleS3NFunction[1, 1, 7] = 0
 
doubleS3NFunction[1, 2, 0] = 0
 
doubleS3NFunction[1, 2, 1] = 0
 
doubleS3NFunction[1, 2, 2] = 1
 
doubleS3NFunction[1, 2, 3] = 0
 
doubleS3NFunction[1, 2, 4] = 0
 
doubleS3NFunction[1, 2, 5] = 0
 
doubleS3NFunction[1, 2, 6] = 0
 
doubleS3NFunction[1, 2, 7] = 0
 
doubleS3NFunction[1, 3, 0] = 0
 
doubleS3NFunction[1, 3, 1] = 0
 
doubleS3NFunction[1, 3, 2] = 0
 
doubleS3NFunction[1, 3, 3] = 0
 
doubleS3NFunction[1, 3, 4] = 1
 
doubleS3NFunction[1, 3, 5] = 0
 
doubleS3NFunction[1, 3, 6] = 0
 
doubleS3NFunction[1, 3, 7] = 0
 
doubleS3NFunction[1, 4, 0] = 0
 
doubleS3NFunction[1, 4, 1] = 0
 
doubleS3NFunction[1, 4, 2] = 0
 
doubleS3NFunction[1, 4, 3] = 1
 
doubleS3NFunction[1, 4, 4] = 0
 
doubleS3NFunction[1, 4, 5] = 0
 
doubleS3NFunction[1, 4, 6] = 0
 
doubleS3NFunction[1, 4, 7] = 0
 
doubleS3NFunction[1, 5, 0] = 0
 
doubleS3NFunction[1, 5, 1] = 0
 
doubleS3NFunction[1, 5, 2] = 0
 
doubleS3NFunction[1, 5, 3] = 0
 
doubleS3NFunction[1, 5, 4] = 0
 
doubleS3NFunction[1, 5, 5] = 1
 
doubleS3NFunction[1, 5, 6] = 0
 
doubleS3NFunction[1, 5, 7] = 0
 
doubleS3NFunction[1, 6, 0] = 0
 
doubleS3NFunction[1, 6, 1] = 0
 
doubleS3NFunction[1, 6, 2] = 0
 
doubleS3NFunction[1, 6, 3] = 0
 
doubleS3NFunction[1, 6, 4] = 0
 
doubleS3NFunction[1, 6, 5] = 0
 
doubleS3NFunction[1, 6, 6] = 1
 
doubleS3NFunction[1, 6, 7] = 0
 
doubleS3NFunction[1, 7, 0] = 0
 
doubleS3NFunction[1, 7, 1] = 0
 
doubleS3NFunction[1, 7, 2] = 0
 
doubleS3NFunction[1, 7, 3] = 0
 
doubleS3NFunction[1, 7, 4] = 0
 
doubleS3NFunction[1, 7, 5] = 0
 
doubleS3NFunction[1, 7, 6] = 0
 
doubleS3NFunction[1, 7, 7] = 1
 
doubleS3NFunction[2, 0, 0] = 0
 
doubleS3NFunction[2, 0, 1] = 0
 
doubleS3NFunction[2, 0, 2] = 1
 
doubleS3NFunction[2, 0, 3] = 0
 
doubleS3NFunction[2, 0, 4] = 0
 
doubleS3NFunction[2, 0, 5] = 0
 
doubleS3NFunction[2, 0, 6] = 0
 
doubleS3NFunction[2, 0, 7] = 0
 
doubleS3NFunction[2, 1, 0] = 0
 
doubleS3NFunction[2, 1, 1] = 0
 
doubleS3NFunction[2, 1, 2] = 1
 
doubleS3NFunction[2, 1, 3] = 0
 
doubleS3NFunction[2, 1, 4] = 0
 
doubleS3NFunction[2, 1, 5] = 0
 
doubleS3NFunction[2, 1, 6] = 0
 
doubleS3NFunction[2, 1, 7] = 0
 
doubleS3NFunction[2, 2, 0] = 1
 
doubleS3NFunction[2, 2, 1] = 1
 
doubleS3NFunction[2, 2, 2] = 1
 
doubleS3NFunction[2, 2, 3] = 0
 
doubleS3NFunction[2, 2, 4] = 0
 
doubleS3NFunction[2, 2, 5] = 0
 
doubleS3NFunction[2, 2, 6] = 0
 
doubleS3NFunction[2, 2, 7] = 0
 
doubleS3NFunction[2, 3, 0] = 0
 
doubleS3NFunction[2, 3, 1] = 0
 
doubleS3NFunction[2, 3, 2] = 0
 
doubleS3NFunction[2, 3, 3] = 1
 
doubleS3NFunction[2, 3, 4] = 1
 
doubleS3NFunction[2, 3, 5] = 0
 
doubleS3NFunction[2, 3, 6] = 0
 
doubleS3NFunction[2, 3, 7] = 0
 
doubleS3NFunction[2, 4, 0] = 0
 
doubleS3NFunction[2, 4, 1] = 0
 
doubleS3NFunction[2, 4, 2] = 0
 
doubleS3NFunction[2, 4, 3] = 1
 
doubleS3NFunction[2, 4, 4] = 1
 
doubleS3NFunction[2, 4, 5] = 0
 
doubleS3NFunction[2, 4, 6] = 0
 
doubleS3NFunction[2, 4, 7] = 0
 
doubleS3NFunction[2, 5, 0] = 0
 
doubleS3NFunction[2, 5, 1] = 0
 
doubleS3NFunction[2, 5, 2] = 0
 
doubleS3NFunction[2, 5, 3] = 0
 
doubleS3NFunction[2, 5, 4] = 0
 
doubleS3NFunction[2, 5, 5] = 0
 
doubleS3NFunction[2, 5, 6] = 1
 
doubleS3NFunction[2, 5, 7] = 1
 
doubleS3NFunction[2, 6, 0] = 0
 
doubleS3NFunction[2, 6, 1] = 0
 
doubleS3NFunction[2, 6, 2] = 0
 
doubleS3NFunction[2, 6, 3] = 0
 
doubleS3NFunction[2, 6, 4] = 0
 
doubleS3NFunction[2, 6, 5] = 1
 
doubleS3NFunction[2, 6, 6] = 0
 
doubleS3NFunction[2, 6, 7] = 1
 
doubleS3NFunction[2, 7, 0] = 0
 
doubleS3NFunction[2, 7, 1] = 0
 
doubleS3NFunction[2, 7, 2] = 0
 
doubleS3NFunction[2, 7, 3] = 0
 
doubleS3NFunction[2, 7, 4] = 0
 
doubleS3NFunction[2, 7, 5] = 1
 
doubleS3NFunction[2, 7, 6] = 1
 
doubleS3NFunction[2, 7, 7] = 0
 
doubleS3NFunction[3, 0, 0] = 0
 
doubleS3NFunction[3, 0, 1] = 0
 
doubleS3NFunction[3, 0, 2] = 0
 
doubleS3NFunction[3, 0, 3] = 1
 
doubleS3NFunction[3, 0, 4] = 0
 
doubleS3NFunction[3, 0, 5] = 0
 
doubleS3NFunction[3, 0, 6] = 0
 
doubleS3NFunction[3, 0, 7] = 0
 
doubleS3NFunction[3, 1, 0] = 0
 
doubleS3NFunction[3, 1, 1] = 0
 
doubleS3NFunction[3, 1, 2] = 0
 
doubleS3NFunction[3, 1, 3] = 0
 
doubleS3NFunction[3, 1, 4] = 1
 
doubleS3NFunction[3, 1, 5] = 0
 
doubleS3NFunction[3, 1, 6] = 0
 
doubleS3NFunction[3, 1, 7] = 0
 
doubleS3NFunction[3, 2, 0] = 0
 
doubleS3NFunction[3, 2, 1] = 0
 
doubleS3NFunction[3, 2, 2] = 0
 
doubleS3NFunction[3, 2, 3] = 1
 
doubleS3NFunction[3, 2, 4] = 1
 
doubleS3NFunction[3, 2, 5] = 0
 
doubleS3NFunction[3, 2, 6] = 0
 
doubleS3NFunction[3, 2, 7] = 0
 
doubleS3NFunction[3, 3, 0] = 1
 
doubleS3NFunction[3, 3, 1] = 0
 
doubleS3NFunction[3, 3, 2] = 1
 
doubleS3NFunction[3, 3, 3] = 0
 
doubleS3NFunction[3, 3, 4] = 0
 
doubleS3NFunction[3, 3, 5] = 1
 
doubleS3NFunction[3, 3, 6] = 1
 
doubleS3NFunction[3, 3, 7] = 1
 
doubleS3NFunction[3, 4, 0] = 0
 
doubleS3NFunction[3, 4, 1] = 1
 
doubleS3NFunction[3, 4, 2] = 1
 
doubleS3NFunction[3, 4, 3] = 0
 
doubleS3NFunction[3, 4, 4] = 0
 
doubleS3NFunction[3, 4, 5] = 1
 
doubleS3NFunction[3, 4, 6] = 1
 
doubleS3NFunction[3, 4, 7] = 1
 
doubleS3NFunction[3, 5, 0] = 0
 
doubleS3NFunction[3, 5, 1] = 0
 
doubleS3NFunction[3, 5, 2] = 0
 
doubleS3NFunction[3, 5, 3] = 1
 
doubleS3NFunction[3, 5, 4] = 1
 
doubleS3NFunction[3, 5, 5] = 0
 
doubleS3NFunction[3, 5, 6] = 0
 
doubleS3NFunction[3, 5, 7] = 0
 
doubleS3NFunction[3, 6, 0] = 0
 
doubleS3NFunction[3, 6, 1] = 0
 
doubleS3NFunction[3, 6, 2] = 0
 
doubleS3NFunction[3, 6, 3] = 1
 
doubleS3NFunction[3, 6, 4] = 1
 
doubleS3NFunction[3, 6, 5] = 0
 
doubleS3NFunction[3, 6, 6] = 0
 
doubleS3NFunction[3, 6, 7] = 0
 
doubleS3NFunction[3, 7, 0] = 0
 
doubleS3NFunction[3, 7, 1] = 0
 
doubleS3NFunction[3, 7, 2] = 0
 
doubleS3NFunction[3, 7, 3] = 1
 
doubleS3NFunction[3, 7, 4] = 1
 
doubleS3NFunction[3, 7, 5] = 0
 
doubleS3NFunction[3, 7, 6] = 0
 
doubleS3NFunction[3, 7, 7] = 0
 
doubleS3NFunction[4, 0, 0] = 0
 
doubleS3NFunction[4, 0, 1] = 0
 
doubleS3NFunction[4, 0, 2] = 0
 
doubleS3NFunction[4, 0, 3] = 0
 
doubleS3NFunction[4, 0, 4] = 1
 
doubleS3NFunction[4, 0, 5] = 0
 
doubleS3NFunction[4, 0, 6] = 0
 
doubleS3NFunction[4, 0, 7] = 0
 
doubleS3NFunction[4, 1, 0] = 0
 
doubleS3NFunction[4, 1, 1] = 0
 
doubleS3NFunction[4, 1, 2] = 0
 
doubleS3NFunction[4, 1, 3] = 1
 
doubleS3NFunction[4, 1, 4] = 0
 
doubleS3NFunction[4, 1, 5] = 0
 
doubleS3NFunction[4, 1, 6] = 0
 
doubleS3NFunction[4, 1, 7] = 0
 
doubleS3NFunction[4, 2, 0] = 0
 
doubleS3NFunction[4, 2, 1] = 0
 
doubleS3NFunction[4, 2, 2] = 0
 
doubleS3NFunction[4, 2, 3] = 1
 
doubleS3NFunction[4, 2, 4] = 1
 
doubleS3NFunction[4, 2, 5] = 0
 
doubleS3NFunction[4, 2, 6] = 0
 
doubleS3NFunction[4, 2, 7] = 0
 
doubleS3NFunction[4, 3, 0] = 0
 
doubleS3NFunction[4, 3, 1] = 1
 
doubleS3NFunction[4, 3, 2] = 1
 
doubleS3NFunction[4, 3, 3] = 0
 
doubleS3NFunction[4, 3, 4] = 0
 
doubleS3NFunction[4, 3, 5] = 1
 
doubleS3NFunction[4, 3, 6] = 1
 
doubleS3NFunction[4, 3, 7] = 1
 
doubleS3NFunction[4, 4, 0] = 1
 
doubleS3NFunction[4, 4, 1] = 0
 
doubleS3NFunction[4, 4, 2] = 1
 
doubleS3NFunction[4, 4, 3] = 0
 
doubleS3NFunction[4, 4, 4] = 0
 
doubleS3NFunction[4, 4, 5] = 1
 
doubleS3NFunction[4, 4, 6] = 1
 
doubleS3NFunction[4, 4, 7] = 1
 
doubleS3NFunction[4, 5, 0] = 0
 
doubleS3NFunction[4, 5, 1] = 0
 
doubleS3NFunction[4, 5, 2] = 0
 
doubleS3NFunction[4, 5, 3] = 1
 
doubleS3NFunction[4, 5, 4] = 1
 
doubleS3NFunction[4, 5, 5] = 0
 
doubleS3NFunction[4, 5, 6] = 0
 
doubleS3NFunction[4, 5, 7] = 0
 
doubleS3NFunction[4, 6, 0] = 0
 
doubleS3NFunction[4, 6, 1] = 0
 
doubleS3NFunction[4, 6, 2] = 0
 
doubleS3NFunction[4, 6, 3] = 1
 
doubleS3NFunction[4, 6, 4] = 1
 
doubleS3NFunction[4, 6, 5] = 0
 
doubleS3NFunction[4, 6, 6] = 0
 
doubleS3NFunction[4, 6, 7] = 0
 
doubleS3NFunction[4, 7, 0] = 0
 
doubleS3NFunction[4, 7, 1] = 0
 
doubleS3NFunction[4, 7, 2] = 0
 
doubleS3NFunction[4, 7, 3] = 1
 
doubleS3NFunction[4, 7, 4] = 1
 
doubleS3NFunction[4, 7, 5] = 0
 
doubleS3NFunction[4, 7, 6] = 0
 
doubleS3NFunction[4, 7, 7] = 0
 
doubleS3NFunction[5, 0, 0] = 0
 
doubleS3NFunction[5, 0, 1] = 0
 
doubleS3NFunction[5, 0, 2] = 0
 
doubleS3NFunction[5, 0, 3] = 0
 
doubleS3NFunction[5, 0, 4] = 0
 
doubleS3NFunction[5, 0, 5] = 1
 
doubleS3NFunction[5, 0, 6] = 0
 
doubleS3NFunction[5, 0, 7] = 0
 
doubleS3NFunction[5, 1, 0] = 0
 
doubleS3NFunction[5, 1, 1] = 0
 
doubleS3NFunction[5, 1, 2] = 0
 
doubleS3NFunction[5, 1, 3] = 0
 
doubleS3NFunction[5, 1, 4] = 0
 
doubleS3NFunction[5, 1, 5] = 1
 
doubleS3NFunction[5, 1, 6] = 0
 
doubleS3NFunction[5, 1, 7] = 0
 
doubleS3NFunction[5, 2, 0] = 0
 
doubleS3NFunction[5, 2, 1] = 0
 
doubleS3NFunction[5, 2, 2] = 0
 
doubleS3NFunction[5, 2, 3] = 0
 
doubleS3NFunction[5, 2, 4] = 0
 
doubleS3NFunction[5, 2, 5] = 0
 
doubleS3NFunction[5, 2, 6] = 1
 
doubleS3NFunction[5, 2, 7] = 1
 
doubleS3NFunction[5, 3, 0] = 0
 
doubleS3NFunction[5, 3, 1] = 0
 
doubleS3NFunction[5, 3, 2] = 0
 
doubleS3NFunction[5, 3, 3] = 1
 
doubleS3NFunction[5, 3, 4] = 1
 
doubleS3NFunction[5, 3, 5] = 0
 
doubleS3NFunction[5, 3, 6] = 0
 
doubleS3NFunction[5, 3, 7] = 0
 
doubleS3NFunction[5, 4, 0] = 0
 
doubleS3NFunction[5, 4, 1] = 0
 
doubleS3NFunction[5, 4, 2] = 0
 
doubleS3NFunction[5, 4, 3] = 1
 
doubleS3NFunction[5, 4, 4] = 1
 
doubleS3NFunction[5, 4, 5] = 0
 
doubleS3NFunction[5, 4, 6] = 0
 
doubleS3NFunction[5, 4, 7] = 0
 
doubleS3NFunction[5, 5, 0] = 1
 
doubleS3NFunction[5, 5, 1] = 1
 
doubleS3NFunction[5, 5, 2] = 0
 
doubleS3NFunction[5, 5, 3] = 0
 
doubleS3NFunction[5, 5, 4] = 0
 
doubleS3NFunction[5, 5, 5] = 1
 
doubleS3NFunction[5, 5, 6] = 0
 
doubleS3NFunction[5, 5, 7] = 0
 
doubleS3NFunction[5, 6, 0] = 0
 
doubleS3NFunction[5, 6, 1] = 0
 
doubleS3NFunction[5, 6, 2] = 1
 
doubleS3NFunction[5, 6, 3] = 0
 
doubleS3NFunction[5, 6, 4] = 0
 
doubleS3NFunction[5, 6, 5] = 0
 
doubleS3NFunction[5, 6, 6] = 0
 
doubleS3NFunction[5, 6, 7] = 1
 
doubleS3NFunction[5, 7, 0] = 0
 
doubleS3NFunction[5, 7, 1] = 0
 
doubleS3NFunction[5, 7, 2] = 1
 
doubleS3NFunction[5, 7, 3] = 0
 
doubleS3NFunction[5, 7, 4] = 0
 
doubleS3NFunction[5, 7, 5] = 0
 
doubleS3NFunction[5, 7, 6] = 1
 
doubleS3NFunction[5, 7, 7] = 0
 
doubleS3NFunction[6, 0, 0] = 0
 
doubleS3NFunction[6, 0, 1] = 0
 
doubleS3NFunction[6, 0, 2] = 0
 
doubleS3NFunction[6, 0, 3] = 0
 
doubleS3NFunction[6, 0, 4] = 0
 
doubleS3NFunction[6, 0, 5] = 0
 
doubleS3NFunction[6, 0, 6] = 1
 
doubleS3NFunction[6, 0, 7] = 0
 
doubleS3NFunction[6, 1, 0] = 0
 
doubleS3NFunction[6, 1, 1] = 0
 
doubleS3NFunction[6, 1, 2] = 0
 
doubleS3NFunction[6, 1, 3] = 0
 
doubleS3NFunction[6, 1, 4] = 0
 
doubleS3NFunction[6, 1, 5] = 0
 
doubleS3NFunction[6, 1, 6] = 1
 
doubleS3NFunction[6, 1, 7] = 0
 
doubleS3NFunction[6, 2, 0] = 0
 
doubleS3NFunction[6, 2, 1] = 0
 
doubleS3NFunction[6, 2, 2] = 0
 
doubleS3NFunction[6, 2, 3] = 0
 
doubleS3NFunction[6, 2, 4] = 0
 
doubleS3NFunction[6, 2, 5] = 1
 
doubleS3NFunction[6, 2, 6] = 0
 
doubleS3NFunction[6, 2, 7] = 1
 
doubleS3NFunction[6, 3, 0] = 0
 
doubleS3NFunction[6, 3, 1] = 0
 
doubleS3NFunction[6, 3, 2] = 0
 
doubleS3NFunction[6, 3, 3] = 1
 
doubleS3NFunction[6, 3, 4] = 1
 
doubleS3NFunction[6, 3, 5] = 0
 
doubleS3NFunction[6, 3, 6] = 0
 
doubleS3NFunction[6, 3, 7] = 0
 
doubleS3NFunction[6, 4, 0] = 0
 
doubleS3NFunction[6, 4, 1] = 0
 
doubleS3NFunction[6, 4, 2] = 0
 
doubleS3NFunction[6, 4, 3] = 1
 
doubleS3NFunction[6, 4, 4] = 1
 
doubleS3NFunction[6, 4, 5] = 0
 
doubleS3NFunction[6, 4, 6] = 0
 
doubleS3NFunction[6, 4, 7] = 0
 
doubleS3NFunction[6, 5, 0] = 0
 
doubleS3NFunction[6, 5, 1] = 0
 
doubleS3NFunction[6, 5, 2] = 1
 
doubleS3NFunction[6, 5, 3] = 0
 
doubleS3NFunction[6, 5, 4] = 0
 
doubleS3NFunction[6, 5, 5] = 0
 
doubleS3NFunction[6, 5, 6] = 0
 
doubleS3NFunction[6, 5, 7] = 1
 
doubleS3NFunction[6, 6, 0] = 1
 
doubleS3NFunction[6, 6, 1] = 1
 
doubleS3NFunction[6, 6, 2] = 0
 
doubleS3NFunction[6, 6, 3] = 0
 
doubleS3NFunction[6, 6, 4] = 0
 
doubleS3NFunction[6, 6, 5] = 0
 
doubleS3NFunction[6, 6, 6] = 1
 
doubleS3NFunction[6, 6, 7] = 0
 
doubleS3NFunction[6, 7, 0] = 0
 
doubleS3NFunction[6, 7, 1] = 0
 
doubleS3NFunction[6, 7, 2] = 1
 
doubleS3NFunction[6, 7, 3] = 0
 
doubleS3NFunction[6, 7, 4] = 0
 
doubleS3NFunction[6, 7, 5] = 1
 
doubleS3NFunction[6, 7, 6] = 0
 
doubleS3NFunction[6, 7, 7] = 0
 
doubleS3NFunction[7, 0, 0] = 0
 
doubleS3NFunction[7, 0, 1] = 0
 
doubleS3NFunction[7, 0, 2] = 0
 
doubleS3NFunction[7, 0, 3] = 0
 
doubleS3NFunction[7, 0, 4] = 0
 
doubleS3NFunction[7, 0, 5] = 0
 
doubleS3NFunction[7, 0, 6] = 0
 
doubleS3NFunction[7, 0, 7] = 1
 
doubleS3NFunction[7, 1, 0] = 0
 
doubleS3NFunction[7, 1, 1] = 0
 
doubleS3NFunction[7, 1, 2] = 0
 
doubleS3NFunction[7, 1, 3] = 0
 
doubleS3NFunction[7, 1, 4] = 0
 
doubleS3NFunction[7, 1, 5] = 0
 
doubleS3NFunction[7, 1, 6] = 0
 
doubleS3NFunction[7, 1, 7] = 1
 
doubleS3NFunction[7, 2, 0] = 0
 
doubleS3NFunction[7, 2, 1] = 0
 
doubleS3NFunction[7, 2, 2] = 0
 
doubleS3NFunction[7, 2, 3] = 0
 
doubleS3NFunction[7, 2, 4] = 0
 
doubleS3NFunction[7, 2, 5] = 1
 
doubleS3NFunction[7, 2, 6] = 1
 
doubleS3NFunction[7, 2, 7] = 0
 
doubleS3NFunction[7, 3, 0] = 0
 
doubleS3NFunction[7, 3, 1] = 0
 
doubleS3NFunction[7, 3, 2] = 0
 
doubleS3NFunction[7, 3, 3] = 1
 
doubleS3NFunction[7, 3, 4] = 1
 
doubleS3NFunction[7, 3, 5] = 0
 
doubleS3NFunction[7, 3, 6] = 0
 
doubleS3NFunction[7, 3, 7] = 0
 
doubleS3NFunction[7, 4, 0] = 0
 
doubleS3NFunction[7, 4, 1] = 0
 
doubleS3NFunction[7, 4, 2] = 0
 
doubleS3NFunction[7, 4, 3] = 1
 
doubleS3NFunction[7, 4, 4] = 1
 
doubleS3NFunction[7, 4, 5] = 0
 
doubleS3NFunction[7, 4, 6] = 0
 
doubleS3NFunction[7, 4, 7] = 0
 
doubleS3NFunction[7, 5, 0] = 0
 
doubleS3NFunction[7, 5, 1] = 0
 
doubleS3NFunction[7, 5, 2] = 1
 
doubleS3NFunction[7, 5, 3] = 0
 
doubleS3NFunction[7, 5, 4] = 0
 
doubleS3NFunction[7, 5, 5] = 0
 
doubleS3NFunction[7, 5, 6] = 1
 
doubleS3NFunction[7, 5, 7] = 0
 
doubleS3NFunction[7, 6, 0] = 0
 
doubleS3NFunction[7, 6, 1] = 0
 
doubleS3NFunction[7, 6, 2] = 1
 
doubleS3NFunction[7, 6, 3] = 0
 
doubleS3NFunction[7, 6, 4] = 0
 
doubleS3NFunction[7, 6, 5] = 1
 
doubleS3NFunction[7, 6, 6] = 0
 
doubleS3NFunction[7, 6, 7] = 0
 
doubleS3NFunction[7, 7, 0] = 1
 
doubleS3NFunction[7, 7, 1] = 1
 
doubleS3NFunction[7, 7, 2] = 0
 
doubleS3NFunction[7, 7, 3] = 0
 
doubleS3NFunction[7, 7, 4] = 0
 
doubleS3NFunction[7, 7, 5] = 0
 
doubleS3NFunction[7, 7, 6] = 0
 
doubleS3NFunction[7, 7, 7] = 1
 
doubleS3NFunction[FusionCategories`Data`doubleS3`Private`a_, FusionCategories`Data`doubleS3`Private`b_, FusionCategories`Data`doubleS3`Private`c_] := 0


 EndPackage[]
