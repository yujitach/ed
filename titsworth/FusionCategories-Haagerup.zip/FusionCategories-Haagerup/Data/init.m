(* ::Package:: *)

(* soOddLevel2 family *)

DeclarePackage["FusionCategories`Data`soOddLevel2`",{"soOddLevel2", "soOddLevel2Cat", "soOddLevel2Brd", "soOddLevel2Piv", "soOddLevel2Bal"} 
]

DeclarPackage["FusionCategories`Data`DFib`",{"DFib","DFibCat1", "DFibCat2", "DFibCat3", "DFibCat1Piv1", "DFibCat2Piv1",
 "DFibCat3Piv1", "DFibCat1Brd1", "DFibCat1Brd2", "DFibCat1Brd3", "DFibCat1Brd4", "DFibCat2Brd1", "DFibCat2Brd2", 
 "DFibCat2Brd3", "DFibCat2Brd4", "DFibCat1Bal1", "DFibCat1Bal2", "DFibCat1Bal3", "DFibCat1Bal4", "DFibCat2Bal1", 
 "DFibCat2Bal2", "DFibCat2Bal3", "DFibCat2Bal4"}
]

(* Rank 2 *)
DeclarePackage["FusionCategories`Data`Z2`",{"Z2", "Z2Cat1", "Z2Cat2", "Z2Cat1Piv1", "Z2Cat1Piv2", "Z2Cat2Piv1", 
 "Z2Cat2Piv2", "Z2Cat1Brd1", "Z2Cat1Brd2", "Z2Cat2Brd1", "Z2Cat2Brd2", 
 "Z2Cat1Bal1", "Z2Cat1Bal2", "Z2Cat1Bal3", "Z2Cat1Bal4", "Z2Cat2Bal1", 
 "Z2Cat2Bal2", "Z2Cat2Bal3", "Z2Cat2Bal4"}
] 

DeclarePackage["FusionCategories`Data`fibo`",{"fibo", "fiboCat1", "fiboCat2", "fiboCat1Piv1", "fiboCat2Piv1", 
 "fiboCat1Brd1", "fiboCat1Brd2", "fiboCat2Brd1", "fiboCat2Brd2", 
 "fiboCat1Bal1", "fiboCat1Bal2", "fiboCat2Bal1", "fiboCat2Bal2"}
] 

(* Rank 3 *)
DeclarePackage["FusionCategories`Data`repS3`",{"repS3", "repS3Cat1", "repS3Cat2", "repS3Cat3", "repS3Cat1Piv1", 
 "repS3Cat2Piv1", "repS3Cat3Piv1", "repS3Cat1Brd1", "repS3Cat1Brd2", 
 "repS3Cat1Brd3", "repS3Cat1Bal1", "repS3Cat1Bal2", "repS3Cat1Bal3"}
] 

DeclarePackage["FusionCategories`Data`halfE6`",{"halfE6", "halfE6Cat1", "halfE6Cat2", "halfE6Cat3", "halfE6Cat4", 
 "halfE6Cat1Piv1", "halfE6Cat2Piv1", "halfE6Cat3Piv1", "halfE6Cat4Piv1"}
] 

DeclarePackage["FusionCategories`Data`Ising`",{"Ising", "IsingCat1", "IsingCat2", "IsingCat1Piv1", "IsingCat1Piv2", 
 "IsingCat2Piv1", "IsingCat2Piv2", "IsingCat1Brd1", "IsingCat1Brd2", 
 "IsingCat1Brd3", "IsingCat1Brd4", "IsingCat2Brd1", "IsingCat2Brd2", 
 "IsingCat2Brd3", "IsingCat2Brd4", "IsingCat1Bal1", "IsingCat1Bal2", 
 "IsingCat1Bal3", "IsingCat1Bal4", "IsingCat1Bal5", "IsingCat1Bal6", 
 "IsingCat1Bal7", "IsingCat1Bal8", "IsingCat2Bal1", "IsingCat2Bal2", 
 "IsingCat2Bal3", "IsingCat2Bal4", "IsingCat2Bal5", "IsingCat2Bal6", 
 "IsingCat2Bal7", "IsingCat2Bal8"}
] 

DeclarePackage["FusionCategories`Data`SO35`",{"SO35", "SO35Cat1", "SO35Cat2", "SO35Cat3", "SO35Cat1Piv1", "SO35Cat2Piv1", 
 "SO35Cat3Piv1", "SO35Cat1Brd1", "SO35Cat1Brd2", "SO35Cat2Brd1", 
 "SO35Cat2Brd2", "SO35Cat3Brd1", "SO35Cat3Brd2", "SO35Cat1Bal1", 
 "SO35Cat1Bal2", "SO35Cat2Bal1", "SO35Cat2Bal2", "SO35Cat3Bal1", 
 "SO35Cat3Bal2"}
] 

DeclarePackage["FusionCategories`Data`Z3`",{"Z3", "Z3Cat1", "Z3Cat2", "Z3Cat3", "Z3Cat1Piv1", "Z3Cat1Piv2", 
 "Z3Cat1Piv3", "Z3Cat2Piv1", "Z3Cat2Piv2", "Z3Cat2Piv3", "Z3Cat3Piv1", 
 "Z3Cat3Piv2", "Z3Cat3Piv3", "Z3Cat1Brd1", "Z3Cat1Brd2", "Z3Cat1Brd3", 
 "Z3Cat1Bal1", "Z3Cat1Bal2", "Z3Cat1Bal3", "Z3Cat1Bal4", "Z3Cat1Bal5", 
 "Z3Cat1Bal6", "Z3Cat1Bal7", "Z3Cat1Bal8", "Z3Cat1Bal9"}
] 

(* Rank 4 *)
DeclarePackage["FusionCategories`Data`toricCode`",{"toricCode", "toricCodeCat1", "toricCodeCat2", "toricCodeCat3", 
 "toricCodeCat4", "toricCodeCat1Piv1", "toricCodeCat1Piv2", 
 "toricCodeCat1Piv3", "toricCodeCat1Piv4", "toricCodeCat2Piv1", 
 "toricCodeCat2Piv2", "toricCodeCat2Piv3", "toricCodeCat2Piv4", 
 "toricCodeCat3Piv1", "toricCodeCat3Piv2", "toricCodeCat3Piv3", 
 "toricCodeCat3Piv4", "toricCodeCat4Piv1", "toricCodeCat4Piv2", 
 "toricCodeCat4Piv3", "toricCodeCat4Piv4", "toricCodeCat3Brd1", 
 "toricCodeCat3Brd2", "toricCodeCat3Brd3", "toricCodeCat3Brd4", 
 "toricCodeCat3Brd5", "toricCodeCat3Brd6", "toricCodeCat3Brd7", 
 "toricCodeCat3Brd8", "toricCodeCat4Brd1", "toricCodeCat4Brd2", 
 "toricCodeCat4Brd3", "toricCodeCat4Brd4", "toricCodeCat4Brd5", 
 "toricCodeCat4Brd6", "toricCodeCat4Brd7", "toricCodeCat4Brd8", 
 "toricCodeCat3Bal1", "toricCodeCat3Bal2", "toricCodeCat3Bal3", 
 "toricCodeCat3Bal4", "toricCodeCat3Bal5", "toricCodeCat3Bal6", 
 "toricCodeCat3Bal7", "toricCodeCat3Bal8", "toricCodeCat3Bal9", 
 "toricCodeCat3Bal10", "toricCodeCat3Bal11", "toricCodeCat3Bal12", 
 "toricCodeCat3Bal13", "toricCodeCat3Bal14", "toricCodeCat3Bal15", 
 "toricCodeCat3Bal16", "toricCodeCat3Bal17", "toricCodeCat3Bal18", 
 "toricCodeCat3Bal19", "toricCodeCat3Bal20", "toricCodeCat3Bal21", 
 "toricCodeCat3Bal22", "toricCodeCat3Bal23", "toricCodeCat3Bal24", 
 "toricCodeCat3Bal25", "toricCodeCat3Bal26", "toricCodeCat3Bal27", 
 "toricCodeCat3Bal28", "toricCodeCat3Bal29", "toricCodeCat3Bal30", 
 "toricCodeCat3Bal31", "toricCodeCat3Bal32", "toricCodeCat4Bal1", 
 "toricCodeCat4Bal2", "toricCodeCat4Bal3", "toricCodeCat4Bal4", 
 "toricCodeCat4Bal5", "toricCodeCat4Bal6", "toricCodeCat4Bal7", 
 "toricCodeCat4Bal8", "toricCodeCat4Bal9", "toricCodeCat4Bal10", 
 "toricCodeCat4Bal11", "toricCodeCat4Bal12", "toricCodeCat4Bal13", 
 "toricCodeCat4Bal14", "toricCodeCat4Bal15", "toricCodeCat4Bal16", 
 "toricCodeCat4Bal17", "toricCodeCat4Bal18", "toricCodeCat4Bal19", 
 "toricCodeCat4Bal20", "toricCodeCat4Bal21", "toricCodeCat4Bal22", 
 "toricCodeCat4Bal23", "toricCodeCat4Bal24", "toricCodeCat4Bal25", 
 "toricCodeCat4Bal26", "toricCodeCat4Bal27", "toricCodeCat4Bal28", 
 "toricCodeCat4Bal29", "toricCodeCat4Bal30", "toricCodeCat4Bal31", 
 "toricCodeCat4Bal32"}
] 

DeclarePackage["FusionCategories`Data`SU23`",{"SU23", "SU23Cat1", "SU23Cat2", "SU23Cat3", "SU23Cat4", "SU23Cat1Piv1", 
 "SU23Cat1Piv2", "SU23Cat2Piv1", "SU23Cat2Piv2", "SU23Cat3Piv1", 
 "SU23Cat3Piv2", "SU23Cat4Piv1", "SU23Cat4Piv2", "SU23Cat1Brd1", 
 "SU23Cat1Brd2", "SU23Cat1Brd3", "SU23Cat1Brd4", "SU23Cat2Brd1", 
 "SU23Cat2Brd2", "SU23Cat2Brd3", "SU23Cat2Brd4", "SU23Cat3Brd1", 
 "SU23Cat3Brd2", "SU23Cat3Brd3", "SU23Cat3Brd4", "SU23Cat4Brd1", 
 "SU23Cat4Brd2", "SU23Cat4Brd3", "SU23Cat4Brd4", "SU23Cat1Bal1", 
 "SU23Cat1Bal2", "SU23Cat1Bal3", "SU23Cat1Bal4", "SU23Cat1Bal5", 
 "SU23Cat1Bal6", "SU23Cat1Bal7", "SU23Cat1Bal8", "SU23Cat2Bal1", 
 "SU23Cat2Bal2", "SU23Cat2Bal3", "SU23Cat2Bal4", "SU23Cat2Bal5", 
 "SU23Cat2Bal6", "SU23Cat2Bal7", "SU23Cat2Bal8", "SU23Cat3Bal1", 
 "SU23Cat3Bal2", "SU23Cat3Bal3", "SU23Cat3Bal4", "SU23Cat3Bal5", 
 "SU23Cat3Bal6", "SU23Cat3Bal7", "SU23Cat3Bal8", "SU23Cat4Bal1", 
 "SU23Cat4Bal2", "SU23Cat4Bal3", "SU23Cat4Bal4", "SU23Cat4Bal5", 
 "SU23Cat4Bal6", "SU23Cat4Bal7", "SU23Cat4Bal8"}
] 

DeclarePackage["FusionCategories`Data`SO36`",{"SO36", "SO36Cat1", "SO36Cat2", "SO36Cat1Piv1", "SO36Cat2Piv1", 
 "SO36Cat1Brd1", "SO36Cat1Brd2", "SO36Cat1Brd3", "SO36Cat1Brd4", 
 "SO36Cat1Bal1", "SO36Cat1Bal2", "SO36Cat1Bal3", "SO36Cat1Bal4"}
] 

DeclarePackage["FusionCategories`Data`Z4`",{"Z4", "Z4Cat1", "Z4Cat2", "Z4Cat3", "Z4Cat4", "Z4Cat1Piv1", "Z4Cat1Piv2", 
 "Z4Cat1Piv3", "Z4Cat1Piv4", "Z4Cat2Piv1", "Z4Cat2Piv2", "Z4Cat2Piv3", 
 "Z4Cat2Piv4", "Z4Cat3Piv1", "Z4Cat3Piv2", "Z4Cat3Piv3", "Z4Cat3Piv4", 
 "Z4Cat4Piv1", "Z4Cat4Piv2", "Z4Cat4Piv3", "Z4Cat4Piv4", "Z4Cat1Brd1", 
 "Z4Cat1Brd2", "Z4Cat1Brd3", "Z4Cat1Brd4", "Z4Cat2Brd1", "Z4Cat2Brd2", 
 "Z4Cat2Brd3", "Z4Cat2Brd4", "Z4Cat1Bal1", "Z4Cat1Bal2", "Z4Cat1Bal3", 
 "Z4Cat1Bal4", "Z4Cat1Bal5", "Z4Cat1Bal6", "Z4Cat1Bal7", "Z4Cat1Bal8", 
 "Z4Cat1Bal9", "Z4Cat1Bal10", "Z4Cat1Bal11", "Z4Cat1Bal12", "Z4Cat1Bal13", 
 "Z4Cat1Bal14", "Z4Cat1Bal15", "Z4Cat1Bal16", "Z4Cat2Bal1", "Z4Cat2Bal2", 
 "Z4Cat2Bal3", "Z4Cat2Bal4", "Z4Cat2Bal5", "Z4Cat2Bal6", "Z4Cat2Bal7", 
 "Z4Cat2Bal8", "Z4Cat2Bal9", "Z4Cat2Bal10", "Z4Cat2Bal11", "Z4Cat2Bal12", 
 "Z4Cat2Bal13", "Z4Cat2Bal14", "Z4Cat2Bal15", "Z4Cat2Bal16"}
] 

DeclarePackage["FusionCategories`Data`TY3`",{"TY3", "TY3Cat1", "TY3Cat2", "TY3Cat3", "TY3Cat4", "TY3Cat1Piv1", 
 "TY3Cat1Piv2", "TY3Cat2Piv1", "TY3Cat2Piv2", "TY3Cat3Piv1", "TY3Cat3Piv2", 
 "TY3Cat4Piv1", "TY3Cat4Piv2"}
] 

DeclarePackage["FusionCategories`Data`LarsonK21`",{"LarsonK21", "LarsonK21Cat1", "LarsonK21Cat2", "LarsonK21Cat3", 
 "LarsonK21Cat4", "LarsonK21Cat1Piv1", "LarsonK21Cat2Piv1", 
 "LarsonK21Cat3Piv1", "LarsonK21Cat4Piv1"}
] 


(* Rank 5 *)
DeclarePackage["FusionCategories`Data`TYZ2Z2`",{"TYZ2Z2", "TYZ2Z2Cat1", "TYZ2Z2Cat2", "TYZ2Z2Cat3", "TYZ2Z2Cat4", 
 "TYZ2Z2Cat1Piv1", "TYZ2Z2Cat1Piv2", "TYZ2Z2Cat2Piv1", "TYZ2Z2Cat2Piv2", 
 "TYZ2Z2Cat3Piv1", "TYZ2Z2Cat3Piv2", "TYZ2Z2Cat4Piv1", "TYZ2Z2Cat4Piv2", 
 "TYZ2Z2Cat1Brd1", "TYZ2Z2Cat1Brd2", "TYZ2Z2Cat1Brd3", "TYZ2Z2Cat1Brd4", 
 "TYZ2Z2Cat1Brd5", "TYZ2Z2Cat1Brd6", "TYZ2Z2Cat1Brd7", "TYZ2Z2Cat1Brd8", 
 "TYZ2Z2Cat2Brd1", "TYZ2Z2Cat2Brd2", "TYZ2Z2Cat2Brd3", "TYZ2Z2Cat2Brd4", 
 "TYZ2Z2Cat2Brd5", "TYZ2Z2Cat2Brd6", "TYZ2Z2Cat2Brd7", "TYZ2Z2Cat2Brd8", 
 "TYZ2Z2Cat3Brd1", "TYZ2Z2Cat3Brd2", "TYZ2Z2Cat3Brd3", "TYZ2Z2Cat3Brd4", 
 "TYZ2Z2Cat3Brd5", "TYZ2Z2Cat3Brd6", "TYZ2Z2Cat3Brd7", "TYZ2Z2Cat3Brd8", 
 "TYZ2Z2Cat4Brd1", "TYZ2Z2Cat4Brd2", "TYZ2Z2Cat4Brd3", "TYZ2Z2Cat4Brd4", 
 "TYZ2Z2Cat4Brd5", "TYZ2Z2Cat4Brd6", "TYZ2Z2Cat4Brd7", "TYZ2Z2Cat4Brd8", 
 "TYZ2Z2Cat1Bal1", "TYZ2Z2Cat1Bal2", "TYZ2Z2Cat1Bal3", "TYZ2Z2Cat1Bal4", 
 "TYZ2Z2Cat1Bal5", "TYZ2Z2Cat1Bal6", "TYZ2Z2Cat1Bal7", "TYZ2Z2Cat1Bal8", 
 "TYZ2Z2Cat1Bal9", "TYZ2Z2Cat1Bal10", "TYZ2Z2Cat1Bal11", "TYZ2Z2Cat1Bal12", 
 "TYZ2Z2Cat1Bal13", "TYZ2Z2Cat1Bal14", "TYZ2Z2Cat1Bal15", "TYZ2Z2Cat1Bal16", 
 "TYZ2Z2Cat2Bal1", "TYZ2Z2Cat2Bal2", "TYZ2Z2Cat2Bal3", "TYZ2Z2Cat2Bal4", 
 "TYZ2Z2Cat2Bal5", "TYZ2Z2Cat2Bal6", "TYZ2Z2Cat2Bal7", "TYZ2Z2Cat2Bal8", 
 "TYZ2Z2Cat2Bal9", "TYZ2Z2Cat2Bal10", "TYZ2Z2Cat2Bal11", "TYZ2Z2Cat2Bal12", 
 "TYZ2Z2Cat2Bal13", "TYZ2Z2Cat2Bal14", "TYZ2Z2Cat2Bal15", "TYZ2Z2Cat2Bal16", 
 "TYZ2Z2Cat3Bal1", "TYZ2Z2Cat3Bal2", "TYZ2Z2Cat3Bal3", "TYZ2Z2Cat3Bal4", 
 "TYZ2Z2Cat3Bal5", "TYZ2Z2Cat3Bal6", "TYZ2Z2Cat3Bal7", "TYZ2Z2Cat3Bal8", 
 "TYZ2Z2Cat3Bal9", "TYZ2Z2Cat3Bal10", "TYZ2Z2Cat3Bal11", "TYZ2Z2Cat3Bal12", 
 "TYZ2Z2Cat3Bal13", "TYZ2Z2Cat3Bal14", "TYZ2Z2Cat3Bal15", "TYZ2Z2Cat3Bal16", 
 "TYZ2Z2Cat4Bal1", "TYZ2Z2Cat4Bal2", "TYZ2Z2Cat4Bal3", "TYZ2Z2Cat4Bal4", 
 "TYZ2Z2Cat4Bal5", "TYZ2Z2Cat4Bal6", "TYZ2Z2Cat4Bal7", "TYZ2Z2Cat4Bal8", 
 "TYZ2Z2Cat4Bal9", "TYZ2Z2Cat4Bal10", "TYZ2Z2Cat4Bal11", "TYZ2Z2Cat4Bal12", 
 "TYZ2Z2Cat4Bal13", "TYZ2Z2Cat4Bal14", "TYZ2Z2Cat4Bal15", "TYZ2Z2Cat4Bal16"}
] 

DeclarePackage["FusionCategories`Data`SU2sub4`",{"SU2sub4", "SU2sub4Cat1", "SU2sub4Cat2", "SU2sub4Cat1Piv1", 
 "SU2sub4Cat1Piv2", "SU2sub4Cat2Piv1", "SU2sub4Cat2Piv2", "SU2sub4Cat1Brd1", 
 "SU2sub4Cat1Brd2", "SU2sub4Cat1Brd3", "SU2sub4Cat1Brd4", "SU2sub4Cat2Brd1", 
 "SU2sub4Cat2Brd2", "SU2sub4Cat2Brd3", "SU2sub4Cat2Brd4", "SU2sub4Cat1Bal1", 
 "SU2sub4Cat1Bal2", "SU2sub4Cat1Bal3", "SU2sub4Cat1Bal4", "SU2sub4Cat1Bal5", 
 "SU2sub4Cat1Bal6", "SU2sub4Cat1Bal7", "SU2sub4Cat1Bal8", "SU2sub4Cat2Bal1", 
 "SU2sub4Cat2Bal2", "SU2sub4Cat2Bal3", "SU2sub4Cat2Bal4", "SU2sub4Cat2Bal5", 
 "SU2sub4Cat2Bal6", "SU2sub4Cat2Bal7", "SU2sub4Cat2Bal8"}
] 

DeclarePackage["FusionCategories`Data`Z5`",{"Z5", "Z5Cat1", "Z5Cat2", "Z5Cat3", "Z5Cat4", "Z5Cat5", "Z5Cat1Piv1", 
 "Z5Cat1Piv2", "Z5Cat1Piv3", "Z5Cat1Piv4", "Z5Cat1Piv5", "Z5Cat2Piv1", 
 "Z5Cat2Piv2", "Z5Cat2Piv3", "Z5Cat2Piv4", "Z5Cat2Piv5", "Z5Cat3Piv1", 
 "Z5Cat3Piv2", "Z5Cat3Piv3", "Z5Cat3Piv4", "Z5Cat3Piv5", "Z5Cat4Piv1", 
 "Z5Cat4Piv2", "Z5Cat4Piv3", "Z5Cat4Piv4", "Z5Cat4Piv5", "Z5Cat5Piv1", 
 "Z5Cat5Piv2", "Z5Cat5Piv3", "Z5Cat5Piv4", "Z5Cat5Piv5", "Z5Cat1Brd1", 
 "Z5Cat1Brd2", "Z5Cat1Brd3", "Z5Cat1Brd4", "Z5Cat1Brd5", "Z5Cat1Bal1", 
 "Z5Cat1Bal2", "Z5Cat1Bal3", "Z5Cat1Bal4", "Z5Cat1Bal5", "Z5Cat1Bal6", 
 "Z5Cat1Bal7", "Z5Cat1Bal8", "Z5Cat1Bal9", "Z5Cat1Bal10", "Z5Cat1Bal11", 
 "Z5Cat1Bal12", "Z5Cat1Bal13", "Z5Cat1Bal14", "Z5Cat1Bal15", "Z5Cat1Bal16", 
 "Z5Cat1Bal17", "Z5Cat1Bal18", "Z5Cat1Bal19", "Z5Cat1Bal20", "Z5Cat1Bal21", 
 "Z5Cat1Bal22", "Z5Cat1Bal23", "Z5Cat1Bal24", "Z5Cat1Bal25"}
] 

(* Rank 6 *)
DeclarePackage["FusionCategories`Data`fermionic5Halves`",{"fermionic5Halves", "fermionic5HalvesCat1", "fermionic5HalvesCat2", 
 "fermionic5HalvesCat1Piv1", "fermionic5HalvesCat1Piv2", 
 "fermionic5HalvesCat1Piv3", "fermionic5HalvesCat1Piv4", 
 "fermionic5HalvesCat2Piv1", "fermionic5HalvesCat2Piv2", 
 "fermionic5HalvesCat2Piv3", "fermionic5HalvesCat2Piv4", 
 "fermionic5HalvesCat1Brd1", "fermionic5HalvesCat1Brd2", 
 "fermionic5HalvesCat1Brd3", "fermionic5HalvesCat1Brd4", 
 "fermionic5HalvesCat1Brd5", "fermionic5HalvesCat1Brd6", 
 "fermionic5HalvesCat1Brd7", "fermionic5HalvesCat1Brd8", 
 "fermionic5HalvesCat1Bal1", "fermionic5HalvesCat1Bal2", 
 "fermionic5HalvesCat1Bal3", "fermionic5HalvesCat1Bal4", 
 "fermionic5HalvesCat1Bal5", "fermionic5HalvesCat1Bal6", 
 "fermionic5HalvesCat1Bal7", "fermionic5HalvesCat1Bal8", 
 "fermionic5HalvesCat1Bal9", "fermionic5HalvesCat1Bal10", 
 "fermionic5HalvesCat1Bal11", "fermionic5HalvesCat1Bal12", 
 "fermionic5HalvesCat1Bal13", "fermionic5HalvesCat1Bal14", 
 "fermionic5HalvesCat1Bal15", "fermionic5HalvesCat1Bal16", 
 "fermionic5HalvesCat1Bal17", "fermionic5HalvesCat1Bal18", 
 "fermionic5HalvesCat1Bal19", "fermionic5HalvesCat1Bal20", 
 "fermionic5HalvesCat1Bal21", "fermionic5HalvesCat1Bal22", 
 "fermionic5HalvesCat1Bal23", "fermionic5HalvesCat1Bal24", 
 "fermionic5HalvesCat1Bal25", "fermionic5HalvesCat1Bal26", 
 "fermionic5HalvesCat1Bal27", "fermionic5HalvesCat1Bal28", 
 "fermionic5HalvesCat1Bal29", "fermionic5HalvesCat1Bal30", 
 "fermionic5HalvesCat1Bal31", "fermionic5HalvesCat1Bal32"}
] 

DeclarePackage["FusionCategories`Data`S3`",{"S3", "S3Cat1", "S3Cat2", "S3Cat3", "S3Cat4", "S3Cat5", "S3Cat6", 
 "S3Cat1Piv1", "S3Cat1Piv2", "S3Cat2Piv1", "S3Cat2Piv2", "S3Cat3Piv1", 
 "S3Cat3Piv2", "S3Cat4Piv1", "S3Cat4Piv2", "S3Cat5Piv1", "S3Cat5Piv2", 
 "S3Cat6Piv1", "S3Cat6Piv2"}
] 

DeclarePackage["FusionCategories`Data`TY5`",{"TY5", "TY5Cat1", "TY5Cat2", "TY5Cat3", "TY5Cat4", "TY5Cat1Piv1", 
 "TY5Cat1Piv2", "TY5Cat2Piv1", "TY5Cat2Piv2", "TY5Cat3Piv1", "TY5Cat3Piv2", 
 "TY5Cat4Piv1", "TY5Cat4Piv2"}
] 

(* Rank 7 *)
DeclarePackage["FusionCategories`Data`TY6`",{"TY6", "TY6Cat1", "TY6Cat2", "TY6Cat3", "TY6Cat4", "TY6Cat1Piv1", 
 "TY6Cat1Piv2", "TY6Cat2Piv1", "TY6Cat2Piv2", "TY6Cat3Piv1", "TY6Cat3Piv2", 
 "TY6Cat4Piv1", "TY6Cat4Piv2"}
] 

(* Rank 8 *)
DeclarePackage["FusionCategories`Data`doubleS3`",{"doubleS3", "doubleS3Cat1", "doubleS3Cat2", "doubleS3Cat3", "doubleS3Cat4", 
 "doubleS3Cat5", "doubleS3Cat1Piv1", "doubleS3Cat1Piv2", "doubleS3Cat2Piv1", 
 "doubleS3Cat2Piv2", "doubleS3Cat3Piv1", "doubleS3Cat3Piv2", 
 "doubleS3Cat4Piv1", "doubleS3Cat4Piv2", "doubleS3Cat5Piv1", 
 "doubleS3Cat5Piv2", "doubleS3Cat1Brd1", "doubleS3Cat2Brd1", 
 "doubleS3Cat3Brd1", "doubleS3Cat4Brd1", "doubleS3Cat1Bal1", 
 "doubleS3Cat1Bal2", "doubleS3Cat2Bal1", "doubleS3Cat2Bal2", 
 "doubleS3Cat3Bal1", "doubleS3Cat3Bal2", "doubleS3Cat4Bal1", 
 "doubleS3Cat4Bal2"}
] 

DeclarePackage["FusionCategories`Data`TY7`",{"TY7", "TY7Cat1", "TY7Cat2", "TY7Cat3", "TY7Cat4", "TY7Cat1Piv1", 
 "TY7Cat1Piv2", "TY7Cat2Piv1", "TY7Cat2Piv2", "TY7Cat3Piv1", "TY7Cat3Piv2", 
 "TY7Cat4Piv1", "TY7Cat4Piv2"}
] 

(* Rank 9 *)
DeclarePackage["FusionCategories`Data`TY8`",{"TY8", "TY8Cat1", "TY8Cat2", "TY8Cat3", "TY8Cat4", "TY8Cat5", "TY8Cat6", 
 "TY8Cat7", "TY8Cat8", "TY8Cat1Piv1", "TY8Cat1Piv2", "TY8Cat2Piv1", 
 "TY8Cat2Piv2", "TY8Cat3Piv1", "TY8Cat3Piv2", "TY8Cat4Piv1", "TY8Cat4Piv2", 
 "TY8Cat5Piv1", "TY8Cat5Piv2", "TY8Cat6Piv1", "TY8Cat6Piv2", "TY8Cat7Piv1", 
 "TY8Cat7Piv2", "TY8Cat8Piv1", "TY8Cat8Piv2"}
] 

DeclarePackage["FusionCategories`Data`DIsing`",{"DIsing", "DIsingCat1", "DIsingCat2", "DIsingCat3", "DIsingCat4", 
 "DIsingCat5", "DIsingCat6", "DIsingCat1Piv1", "DIsingCat1Piv2", 
 "DIsingCat1Piv3", "DIsingCat1Piv4", "DIsingCat2Piv1", "DIsingCat2Piv2", 
 "DIsingCat2Piv3", "DIsingCat2Piv4", "DIsingCat3Piv1", "DIsingCat3Piv2", 
 "DIsingCat3Piv3", "DIsingCat3Piv4", "DIsingCat4Piv1", "DIsingCat4Piv2", 
 "DIsingCat4Piv3", "DIsingCat4Piv4", "DIsingCat5Piv1", "DIsingCat5Piv2", 
 "DIsingCat5Piv3", "DIsingCat5Piv4", "DIsingCat6Piv1", "DIsingCat6Piv2", 
 "DIsingCat6Piv3", "DIsingCat6Piv4", "DIsingCat4Brd1", "DIsingCat4Brd2", 
 "DIsingCat4Brd3", "DIsingCat4Brd4", "DIsingCat4Brd5", "DIsingCat4Brd6", 
 "DIsingCat4Brd7", "DIsingCat4Brd8", "DIsingCat4Brd9", "DIsingCat4Brd10", 
 "DIsingCat4Brd11", "DIsingCat4Brd12", "DIsingCat4Brd13", "DIsingCat4Brd14", 
 "DIsingCat4Brd15", "DIsingCat4Brd16", "DIsingCat4Brd17", "DIsingCat4Brd18", 
 "DIsingCat4Brd19", "DIsingCat4Brd20", "DIsingCat4Brd21", "DIsingCat4Brd22", 
 "DIsingCat4Brd23", "DIsingCat4Brd24", "DIsingCat4Brd25", "DIsingCat4Brd26", 
 "DIsingCat4Brd27", "DIsingCat4Brd28", "DIsingCat4Brd29", "DIsingCat4Brd30", 
 "DIsingCat4Brd31", "DIsingCat4Brd32", "DIsingCat5Brd1", "DIsingCat5Brd2", 
 "DIsingCat5Brd3", "DIsingCat5Brd4", "DIsingCat5Brd5", "DIsingCat5Brd6", 
 "DIsingCat5Brd7", "DIsingCat5Brd8", "DIsingCat5Brd9", "DIsingCat5Brd10", 
 "DIsingCat5Brd11", "DIsingCat5Brd12", "DIsingCat5Brd13", "DIsingCat5Brd14", 
 "DIsingCat5Brd15", "DIsingCat5Brd16", "DIsingCat5Brd17", "DIsingCat5Brd18", 
 "DIsingCat5Brd19", "DIsingCat5Brd20", "DIsingCat5Brd21", "DIsingCat5Brd22", 
 "DIsingCat5Brd23", "DIsingCat5Brd24", "DIsingCat5Brd25", "DIsingCat5Brd26", 
 "DIsingCat5Brd27", "DIsingCat5Brd28", "DIsingCat5Brd29", "DIsingCat5Brd30", 
 "DIsingCat5Brd31", "DIsingCat5Brd32", "DIsingCat6Brd1", "DIsingCat6Brd2", 
 "DIsingCat6Brd3", "DIsingCat6Brd4", "DIsingCat6Brd5", "DIsingCat6Brd6", 
 "DIsingCat6Brd7", "DIsingCat6Brd8", "DIsingCat6Brd9", "DIsingCat6Brd10", 
 "DIsingCat6Brd11", "DIsingCat6Brd12", "DIsingCat6Brd13", "DIsingCat6Brd14", 
 "DIsingCat6Brd15", "DIsingCat6Brd16", "DIsingCat6Brd17", "DIsingCat6Brd18", 
 "DIsingCat6Brd19", "DIsingCat6Brd20", "DIsingCat6Brd21", "DIsingCat6Brd22", 
 "DIsingCat6Brd23", "DIsingCat6Brd24", "DIsingCat6Brd25", "DIsingCat6Brd26", 
 "DIsingCat6Brd27", "DIsingCat6Brd28", "DIsingCat6Brd29", "DIsingCat6Brd30", 
 "DIsingCat6Brd31", "DIsingCat6Brd32", "DIsingCat4Bal1", "DIsingCat4Bal2", 
 "DIsingCat4Bal3", "DIsingCat4Bal4", "DIsingCat4Bal5", "DIsingCat4Bal6", 
 "DIsingCat4Bal7", "DIsingCat4Bal8", "DIsingCat4Bal9", "DIsingCat4Bal10", 
 "DIsingCat4Bal11", "DIsingCat4Bal12", "DIsingCat4Bal13", "DIsingCat4Bal14", 
 "DIsingCat4Bal15", "DIsingCat4Bal16", "DIsingCat4Bal17", "DIsingCat4Bal18", 
 "DIsingCat4Bal19", "DIsingCat4Bal20", "DIsingCat4Bal21", "DIsingCat4Bal22", 
 "DIsingCat4Bal23", "DIsingCat4Bal24", "DIsingCat4Bal25", "DIsingCat4Bal26", 
 "DIsingCat4Bal27", "DIsingCat4Bal28", "DIsingCat4Bal29", "DIsingCat4Bal30", 
 "DIsingCat4Bal31", "DIsingCat4Bal32", "DIsingCat4Bal33", "DIsingCat4Bal34", 
 "DIsingCat4Bal35", "DIsingCat4Bal36", "DIsingCat4Bal37", "DIsingCat4Bal38", 
 "DIsingCat4Bal39", "DIsingCat4Bal40", "DIsingCat4Bal41", "DIsingCat4Bal42", 
 "DIsingCat4Bal43", "DIsingCat4Bal44", "DIsingCat4Bal45", "DIsingCat4Bal46", 
 "DIsingCat4Bal47", "DIsingCat4Bal48", "DIsingCat4Bal49", "DIsingCat4Bal50", 
 "DIsingCat4Bal51", "DIsingCat4Bal52", "DIsingCat4Bal53", "DIsingCat4Bal54", 
 "DIsingCat4Bal55", "DIsingCat4Bal56", "DIsingCat4Bal57", "DIsingCat4Bal58", 
 "DIsingCat4Bal59", "DIsingCat4Bal60", "DIsingCat4Bal61", "DIsingCat4Bal62", 
 "DIsingCat4Bal63", "DIsingCat4Bal64", "DIsingCat4Bal65", "DIsingCat4Bal66", 
 "DIsingCat4Bal67", "DIsingCat4Bal68", "DIsingCat4Bal69", "DIsingCat4Bal70", 
 "DIsingCat4Bal71", "DIsingCat4Bal72", "DIsingCat4Bal73", "DIsingCat4Bal74", 
 "DIsingCat4Bal75", "DIsingCat4Bal76", "DIsingCat4Bal77", "DIsingCat4Bal78", 
 "DIsingCat4Bal79", "DIsingCat4Bal80", "DIsingCat4Bal81", "DIsingCat4Bal82", 
 "DIsingCat4Bal83", "DIsingCat4Bal84", "DIsingCat4Bal85", "DIsingCat4Bal86", 
 "DIsingCat4Bal87", "DIsingCat4Bal88", "DIsingCat4Bal89", "DIsingCat4Bal90", 
 "DIsingCat4Bal91", "DIsingCat4Bal92", "DIsingCat4Bal93", "DIsingCat4Bal94", 
 "DIsingCat4Bal95", "DIsingCat4Bal96", "DIsingCat4Bal97", "DIsingCat4Bal98", 
 "DIsingCat4Bal99", "DIsingCat4Bal100", "DIsingCat4Bal101", 
 "DIsingCat4Bal102", "DIsingCat4Bal103", "DIsingCat4Bal104", 
 "DIsingCat4Bal105", "DIsingCat4Bal106", "DIsingCat4Bal107", 
 "DIsingCat4Bal108", "DIsingCat4Bal109", "DIsingCat4Bal110", 
 "DIsingCat4Bal111", "DIsingCat4Bal112", "DIsingCat4Bal113", 
 "DIsingCat4Bal114", "DIsingCat4Bal115", "DIsingCat4Bal116", 
 "DIsingCat4Bal117", "DIsingCat4Bal118", "DIsingCat4Bal119", 
 "DIsingCat4Bal120", "DIsingCat4Bal121", "DIsingCat4Bal122", 
 "DIsingCat4Bal123", "DIsingCat4Bal124", "DIsingCat4Bal125", 
 "DIsingCat4Bal126", "DIsingCat4Bal127", "DIsingCat4Bal128", 
 "DIsingCat5Bal1", "DIsingCat5Bal2", "DIsingCat5Bal3", "DIsingCat5Bal4", 
 "DIsingCat5Bal5", "DIsingCat5Bal6", "DIsingCat5Bal7", "DIsingCat5Bal8", 
 "DIsingCat5Bal9", "DIsingCat5Bal10", "DIsingCat5Bal11", "DIsingCat5Bal12", 
 "DIsingCat5Bal13", "DIsingCat5Bal14", "DIsingCat5Bal15", "DIsingCat5Bal16", 
 "DIsingCat5Bal17", "DIsingCat5Bal18", "DIsingCat5Bal19", "DIsingCat5Bal20", 
 "DIsingCat5Bal21", "DIsingCat5Bal22", "DIsingCat5Bal23", "DIsingCat5Bal24", 
 "DIsingCat5Bal25", "DIsingCat5Bal26", "DIsingCat5Bal27", "DIsingCat5Bal28", 
 "DIsingCat5Bal29", "DIsingCat5Bal30", "DIsingCat5Bal31", "DIsingCat5Bal32", 
 "DIsingCat5Bal33", "DIsingCat5Bal34", "DIsingCat5Bal35", "DIsingCat5Bal36", 
 "DIsingCat5Bal37", "DIsingCat5Bal38", "DIsingCat5Bal39", "DIsingCat5Bal40", 
 "DIsingCat5Bal41", "DIsingCat5Bal42", "DIsingCat5Bal43", "DIsingCat5Bal44", 
 "DIsingCat5Bal45", "DIsingCat5Bal46", "DIsingCat5Bal47", "DIsingCat5Bal48", 
 "DIsingCat5Bal49", "DIsingCat5Bal50", "DIsingCat5Bal51", "DIsingCat5Bal52", 
 "DIsingCat5Bal53", "DIsingCat5Bal54", "DIsingCat5Bal55", "DIsingCat5Bal56", 
 "DIsingCat5Bal57", "DIsingCat5Bal58", "DIsingCat5Bal59", "DIsingCat5Bal60", 
 "DIsingCat5Bal61", "DIsingCat5Bal62", "DIsingCat5Bal63", "DIsingCat5Bal64", 
 "DIsingCat5Bal65", "DIsingCat5Bal66", "DIsingCat5Bal67", "DIsingCat5Bal68", 
 "DIsingCat5Bal69", "DIsingCat5Bal70", "DIsingCat5Bal71", "DIsingCat5Bal72", 
 "DIsingCat5Bal73", "DIsingCat5Bal74", "DIsingCat5Bal75", "DIsingCat5Bal76", 
 "DIsingCat5Bal77", "DIsingCat5Bal78", "DIsingCat5Bal79", "DIsingCat5Bal80", 
 "DIsingCat5Bal81", "DIsingCat5Bal82", "DIsingCat5Bal83", "DIsingCat5Bal84", 
 "DIsingCat5Bal85", "DIsingCat5Bal86", "DIsingCat5Bal87", "DIsingCat5Bal88", 
 "DIsingCat5Bal89", "DIsingCat5Bal90", "DIsingCat5Bal91", "DIsingCat5Bal92", 
 "DIsingCat5Bal93", "DIsingCat5Bal94", "DIsingCat5Bal95", "DIsingCat5Bal96", 
 "DIsingCat5Bal97", "DIsingCat5Bal98", "DIsingCat5Bal99", "DIsingCat5Bal100", 
 "DIsingCat5Bal101", "DIsingCat5Bal102", "DIsingCat5Bal103", 
 "DIsingCat5Bal104", "DIsingCat5Bal105", "DIsingCat5Bal106", 
 "DIsingCat5Bal107", "DIsingCat5Bal108", "DIsingCat5Bal109", 
 "DIsingCat5Bal110", "DIsingCat5Bal111", "DIsingCat5Bal112", 
 "DIsingCat5Bal113", "DIsingCat5Bal114", "DIsingCat5Bal115", 
 "DIsingCat5Bal116", "DIsingCat5Bal117", "DIsingCat5Bal118", 
 "DIsingCat5Bal119", "DIsingCat5Bal120", "DIsingCat5Bal121", 
 "DIsingCat5Bal122", "DIsingCat5Bal123", "DIsingCat5Bal124", 
 "DIsingCat5Bal125", "DIsingCat5Bal126", "DIsingCat5Bal127", 
 "DIsingCat5Bal128", "DIsingCat6Bal1", "DIsingCat6Bal2", "DIsingCat6Bal3", 
 "DIsingCat6Bal4", "DIsingCat6Bal5", "DIsingCat6Bal6", "DIsingCat6Bal7", 
 "DIsingCat6Bal8", "DIsingCat6Bal9", "DIsingCat6Bal10", "DIsingCat6Bal11", 
 "DIsingCat6Bal12", "DIsingCat6Bal13", "DIsingCat6Bal14", "DIsingCat6Bal15", 
 "DIsingCat6Bal16", "DIsingCat6Bal17", "DIsingCat6Bal18", "DIsingCat6Bal19", 
 "DIsingCat6Bal20", "DIsingCat6Bal21", "DIsingCat6Bal22", "DIsingCat6Bal23", 
 "DIsingCat6Bal24", "DIsingCat6Bal25", "DIsingCat6Bal26", "DIsingCat6Bal27", 
 "DIsingCat6Bal28", "DIsingCat6Bal29", "DIsingCat6Bal30", "DIsingCat6Bal31", 
 "DIsingCat6Bal32", "DIsingCat6Bal33", "DIsingCat6Bal34", "DIsingCat6Bal35", 
 "DIsingCat6Bal36", "DIsingCat6Bal37", "DIsingCat6Bal38", "DIsingCat6Bal39", 
 "DIsingCat6Bal40", "DIsingCat6Bal41", "DIsingCat6Bal42", "DIsingCat6Bal43", 
 "DIsingCat6Bal44", "DIsingCat6Bal45", "DIsingCat6Bal46", "DIsingCat6Bal47", 
 "DIsingCat6Bal48", "DIsingCat6Bal49", "DIsingCat6Bal50", "DIsingCat6Bal51", 
 "DIsingCat6Bal52", "DIsingCat6Bal53", "DIsingCat6Bal54", "DIsingCat6Bal55", 
 "DIsingCat6Bal56", "DIsingCat6Bal57", "DIsingCat6Bal58", "DIsingCat6Bal59", 
 "DIsingCat6Bal60", "DIsingCat6Bal61", "DIsingCat6Bal62", "DIsingCat6Bal63", 
 "DIsingCat6Bal64", "DIsingCat6Bal65", "DIsingCat6Bal66", "DIsingCat6Bal67", 
 "DIsingCat6Bal68", "DIsingCat6Bal69", "DIsingCat6Bal70", "DIsingCat6Bal71", 
 "DIsingCat6Bal72", "DIsingCat6Bal73", "DIsingCat6Bal74", "DIsingCat6Bal75", 
 "DIsingCat6Bal76", "DIsingCat6Bal77", "DIsingCat6Bal78", "DIsingCat6Bal79", 
 "DIsingCat6Bal80", "DIsingCat6Bal81", "DIsingCat6Bal82", "DIsingCat6Bal83", 
 "DIsingCat6Bal84", "DIsingCat6Bal85", "DIsingCat6Bal86", "DIsingCat6Bal87", 
 "DIsingCat6Bal88", "DIsingCat6Bal89", "DIsingCat6Bal90", "DIsingCat6Bal91", 
 "DIsingCat6Bal92", "DIsingCat6Bal93", "DIsingCat6Bal94", "DIsingCat6Bal95", 
 "DIsingCat6Bal96", "DIsingCat6Bal97", "DIsingCat6Bal98", "DIsingCat6Bal99", 
 "DIsingCat6Bal100", "DIsingCat6Bal101", "DIsingCat6Bal102", 
 "DIsingCat6Bal103", "DIsingCat6Bal104", "DIsingCat6Bal105", 
 "DIsingCat6Bal106", "DIsingCat6Bal107", "DIsingCat6Bal108", 
 "DIsingCat6Bal109", "DIsingCat6Bal110", "DIsingCat6Bal111", 
 "DIsingCat6Bal112", "DIsingCat6Bal113", "DIsingCat6Bal114", 
 "DIsingCat6Bal115", "DIsingCat6Bal116", "DIsingCat6Bal117", 
 "DIsingCat6Bal118", "DIsingCat6Bal119", "DIsingCat6Bal120", 
 "DIsingCat6Bal121", "DIsingCat6Bal122", "DIsingCat6Bal123", 
 "DIsingCat6Bal124", "DIsingCat6Bal125", "DIsingCat6Bal126", 
 "DIsingCat6Bal127", "DIsingCat6Bal128"}
] 

DeclarePackage["FusionCategories`Data`SO510`",{"SO510", "SO510Cat1", "SO510Cat2", "SO510Cat3", "SO510Cat1Piv1", 
 "SO510Cat2Piv1", "SO510Cat3Piv1", "SO510Cat1Brd1", "SO510Cat1Brd2", 
 "SO510Cat1Brd3", "SO510Cat1Brd4", "SO510Cat1Brd5", "SO510Cat1Bal1", 
 "SO510Cat1Bal2", "SO510Cat1Bal3", "SO510Cat1Bal4", "SO510Cat1Bal5"}
] 

DeclarePackage["FusionCategories`Data`z2Xz4`",{"z2Xz4", "z2Xz4Cat1", "z2Xz4Cat2", "z2Xz4Cat3", "z2Xz4Cat4", "z2Xz4Cat5", 
 "z2Xz4Cat6", "z2Xz4Cat1Piv1", "z2Xz4Cat1Piv2", "z2Xz4Cat1Piv3", 
 "z2Xz4Cat1Piv4", "z2Xz4Cat2Piv1", "z2Xz4Cat2Piv2", "z2Xz4Cat2Piv3", 
 "z2Xz4Cat2Piv4", "z2Xz4Cat3Piv1", "z2Xz4Cat3Piv2", "z2Xz4Cat3Piv3", 
 "z2Xz4Cat3Piv4", "z2Xz4Cat4Piv1", "z2Xz4Cat4Piv2", "z2Xz4Cat4Piv3", 
 "z2Xz4Cat4Piv4", "z2Xz4Cat5Piv1", "z2Xz4Cat5Piv2", "z2Xz4Cat5Piv3", 
 "z2Xz4Cat5Piv4", "z2Xz4Cat6Piv1", "z2Xz4Cat6Piv2", "z2Xz4Cat6Piv3", 
 "z2Xz4Cat6Piv4"}
] 

DeclarePackage["FusionCategories`Data`repD10`",{"repD10", "repD10Cat1", "repD10Cat2", "repD10Cat3", "repD10Cat4", 
 "repD10Cat5", "repD10Cat6", "repD10Cat1Piv1", "repD10Cat1Piv2", 
 "repD10Cat2Piv1", "repD10Cat2Piv2", "repD10Cat3Piv1", "repD10Cat3Piv2", 
 "repD10Cat4Piv1", "repD10Cat4Piv2", "repD10Cat5Piv1", "repD10Cat5Piv2", 
 "repD10Cat6Piv1", "repD10Cat6Piv2", "repD10Cat1Brd1", "repD10Cat1Brd2", 
 "repD10Cat1Brd3", "repD10Cat1Brd4", "repD10Cat1Brd5", "repD10Cat1Brd6", 
 "repD10Cat1Brd7", "repD10Cat1Brd8", "repD10Cat1Brd9", "repD10Cat1Brd10", 
 "repD10Cat4Brd1", "repD10Cat4Brd2", "repD10Cat4Brd3", "repD10Cat4Brd4", 
 "repD10Cat4Brd5", "repD10Cat4Brd6", "repD10Cat4Brd7", "repD10Cat4Brd8", 
 "repD10Cat4Brd9", "repD10Cat4Brd10", "repD10Cat1Bal1", "repD10Cat1Bal2", 
 "repD10Cat1Bal3", "repD10Cat1Bal4", "repD10Cat1Bal5", "repD10Cat1Bal6", 
 "repD10Cat1Bal7", "repD10Cat1Bal8", "repD10Cat1Bal9", "repD10Cat1Bal10", 
 "repD10Cat1Bal11", "repD10Cat1Bal12", "repD10Cat1Bal13", "repD10Cat1Bal14", 
 "repD10Cat1Bal15", "repD10Cat1Bal16", "repD10Cat1Bal17", "repD10Cat1Bal18", 
 "repD10Cat1Bal19", "repD10Cat1Bal20", "repD10Cat4Bal1", "repD10Cat4Bal2", 
 "repD10Cat4Bal3", "repD10Cat4Bal4", "repD10Cat4Bal5", "repD10Cat4Bal6", 
 "repD10Cat4Bal7", "repD10Cat4Bal8", "repD10Cat4Bal9", "repD10Cat4Bal10", 
 "repD10Cat4Bal11", "repD10Cat4Bal12", "repD10Cat4Bal13", "repD10Cat4Bal14", 
 "repD10Cat4Bal15", "repD10Cat4Bal16", "repD10Cat4Bal17", "repD10Cat4Bal18", 
 "repD10Cat4Bal19", "repD10Cat4Bal20"}
] 

DeclarePackage["FusionCategories`Data`repD5`",{"repD5", "repD5Cat1", "repD5Cat2", "repD5Cat3", "repD5Cat1Piv1", 
 "repD5Cat2Piv1", "repD5Cat3Piv1", "repD5Cat1Brd1", "repD5Cat1Brd2", 
 "repD5Cat1Brd3", "repD5Cat1Brd4", "repD5Cat1Brd5", "repD5Cat1Bal1", 
 "repD5Cat1Bal2", "repD5Cat1Bal3", "repD5Cat1Bal4", "repD5Cat1Bal5"}
] 

DeclarePackage["FusionCategories`Data`SOlevel23`",{"SOlevel23", "SOlevel23Cat1", "SOlevel23Cat2", "SOlevel23Cat1Piv1", 
 "SOlevel23Cat1Piv2", "SOlevel23Cat2Piv1", "SOlevel23Cat2Piv2", 
 "SOlevel23Cat1Brd1", "SOlevel23Cat1Brd2", "SOlevel23Cat1Brd3", 
 "SOlevel23Cat1Brd4", "SOlevel23Cat2Brd1", "SOlevel23Cat2Brd2", 
 "SOlevel23Cat2Brd3", "SOlevel23Cat2Brd4", "SOlevel23Cat1Bal1", 
 "SOlevel23Cat1Bal2", "SOlevel23Cat1Bal3", "SOlevel23Cat1Bal4", 
 "SOlevel23Cat1Bal5", "SOlevel23Cat1Bal6", "SOlevel23Cat1Bal7", 
 "SOlevel23Cat1Bal8", "SOlevel23Cat2Bal1", "SOlevel23Cat2Bal2", 
 "SOlevel23Cat2Bal3", "SOlevel23Cat2Bal4", "SOlevel23Cat2Bal5", 
 "SOlevel23Cat2Bal6", "SOlevel23Cat2Bal7", "SOlevel23Cat2Bal8"}
] 

DeclarePackage["FusionCategories`Data`SOlevel25`",{"SOlevel25", "SOlevel25Cat1", "SOlevel25Cat2", "SOlevel25Cat3", 
 "SOlevel25Cat4", "SOlevel25Cat1Piv1", "SOlevel25Cat1Piv2", 
 "SOlevel25Cat2Piv1", "SOlevel25Cat2Piv2", "SOlevel25Cat3Piv1", 
 "SOlevel25Cat3Piv2", "SOlevel25Cat4Piv1", "SOlevel25Cat4Piv2", 
 "SOlevel25Cat1Brd1", "SOlevel25Cat1Brd2", "SOlevel25Cat1Brd3", 
 "SOlevel25Cat1Brd4", "SOlevel25Cat2Brd1", "SOlevel25Cat2Brd2", 
 "SOlevel25Cat2Brd3", "SOlevel25Cat2Brd4", "SOlevel25Cat3Brd1", 
 "SOlevel25Cat3Brd2", "SOlevel25Cat3Brd3", "SOlevel25Cat3Brd4", 
 "SOlevel25Cat4Brd1", "SOlevel25Cat4Brd2", "SOlevel25Cat4Brd3", 
 "SOlevel25Cat4Brd4", "SOlevel25Cat1Bal1", "SOlevel25Cat1Bal2", 
 "SOlevel25Cat1Bal3", "SOlevel25Cat1Bal4", "SOlevel25Cat1Bal5", 
 "SOlevel25Cat1Bal6", "SOlevel25Cat1Bal7", "SOlevel25Cat1Bal8", 
 "SOlevel25Cat2Bal1", "SOlevel25Cat2Bal2", "SOlevel25Cat2Bal3", 
 "SOlevel25Cat2Bal4", "SOlevel25Cat2Bal5", "SOlevel25Cat2Bal6", 
 "SOlevel25Cat2Bal7", "SOlevel25Cat2Bal8", "SOlevel25Cat3Bal1", 
 "SOlevel25Cat3Bal2", "SOlevel25Cat3Bal3", "SOlevel25Cat3Bal4", 
 "SOlevel25Cat3Bal5", "SOlevel25Cat3Bal6", "SOlevel25Cat3Bal7", 
 "SOlevel25Cat3Bal8", "SOlevel25Cat4Bal1", "SOlevel25Cat4Bal2", 
 "SOlevel25Cat4Bal3", "SOlevel25Cat4Bal4", "SOlevel25Cat4Bal5", 
 "SOlevel25Cat4Bal6", "SOlevel25Cat4Bal7", "SOlevel25Cat4Bal8"}
] 

DeclarePackage["FusionCategories`Data`SU24`",{"SU24", "SU24Cat1", "SU24Cat2", "SU24Cat1Piv1", "SU24Cat1Piv2", 
 "SU24Cat2Piv1", "SU24Cat2Piv2", "SU24Cat1Brd1", "SU24Cat1Brd2", 
 "SU24Cat1Brd3", "SU24Cat1Brd4", "SU24Cat2Brd1", "SU24Cat2Brd2", 
 "SU24Cat2Brd3", "SU24Cat2Brd4", "SU24Cat1Bal1", "SU24Cat1Bal2", 
 "SU24Cat1Bal3", "SU24Cat1Bal4", "SU24Cat1Bal5", "SU24Cat1Bal6", 
 "SU24Cat1Bal7", "SU24Cat1Bal8", "SU24Cat2Bal1", "SU24Cat2Bal2", 
 "SU24Cat2Bal3", "SU24Cat2Bal4", "SU24Cat2Bal5", "SU24Cat2Bal6", 
 "SU24Cat2Bal7", "SU24Cat2Bal8"}
] 


DeclarePackage["FusionCategories`Data`doubleS3sub6`",{"doubleS3sub6", "doubleS3sub6Cat1", "doubleS3sub6Cat2", "doubleS3sub6Cat3", 
 "doubleS3sub6Cat4", "doubleS3sub6Cat5", "doubleS3sub6Cat1Piv1", 
 "doubleS3sub6Cat2Piv1", "doubleS3sub6Cat3Piv1", "doubleS3sub6Cat4Piv1", 
 "doubleS3sub6Cat5Piv1", "doubleS3sub6Cat1Brd1", "doubleS3sub6Cat1Brd2", 
 "doubleS3sub6Cat1Brd3", "doubleS3sub6Cat1Brd4", "doubleS3sub6Cat1Brd5", 
 "doubleS3sub6Cat1Bal1", "doubleS3sub6Cat1Bal2", "doubleS3sub6Cat1Bal3", 
 "doubleS3sub6Cat1Bal4", "doubleS3sub6Cat1Bal5"}
] 

DeclarePackage["FusionCategories`Data`fourStatePotts`",{"fourStatePotts", "fourStatePottsCat1", "fourStatePottsCat2", 
 "fourStatePottsCat3", "fourStatePottsCat4", "fourStatePottsCat5", 
 "fourStatePottsCat6", "fourStatePottsCat7", "fourStatePottsCat8", 
 "fourStatePottsCat1Piv1", "fourStatePottsCat1Piv2", 
 "fourStatePottsCat1Piv3", "fourStatePottsCat1Piv4", 
 "fourStatePottsCat2Piv1", "fourStatePottsCat2Piv2", 
 "fourStatePottsCat2Piv3", "fourStatePottsCat2Piv4", 
 "fourStatePottsCat3Piv1", "fourStatePottsCat3Piv2", 
 "fourStatePottsCat3Piv3", "fourStatePottsCat3Piv4", 
 "fourStatePottsCat4Piv1", "fourStatePottsCat4Piv2", 
 "fourStatePottsCat4Piv3", "fourStatePottsCat4Piv4", 
 "fourStatePottsCat5Piv1", "fourStatePottsCat5Piv2", 
 "fourStatePottsCat5Piv3", "fourStatePottsCat5Piv4", 
 "fourStatePottsCat6Piv1", "fourStatePottsCat6Piv2", 
 "fourStatePottsCat6Piv3", "fourStatePottsCat6Piv4", 
 "fourStatePottsCat7Piv1", "fourStatePottsCat7Piv2", 
 "fourStatePottsCat7Piv3", "fourStatePottsCat7Piv4", 
 "fourStatePottsCat8Piv1", "fourStatePottsCat8Piv2", 
 "fourStatePottsCat8Piv3", "fourStatePottsCat8Piv4", 
 "fourStatePottsCat1Brd1", "fourStatePottsCat1Brd2", 
 "fourStatePottsCat4Brd1", "fourStatePottsCat4Brd2", 
 "fourStatePottsCat5Brd1", "fourStatePottsCat5Brd2", 
 "fourStatePottsCat8Brd1", "fourStatePottsCat8Brd2", 
 "fourStatePottsCat1Bal1", "fourStatePottsCat1Bal2", 
 "fourStatePottsCat1Bal3", "fourStatePottsCat1Bal4", 
 "fourStatePottsCat1Bal5", "fourStatePottsCat1Bal6", 
 "fourStatePottsCat1Bal7", "fourStatePottsCat1Bal8", 
 "fourStatePottsCat4Bal1", "fourStatePottsCat4Bal2", 
 "fourStatePottsCat4Bal3", "fourStatePottsCat4Bal4", 
 "fourStatePottsCat4Bal5", "fourStatePottsCat4Bal6", 
 "fourStatePottsCat4Bal7", "fourStatePottsCat4Bal8", 
 "fourStatePottsCat5Bal1", "fourStatePottsCat5Bal2", 
 "fourStatePottsCat5Bal3", "fourStatePottsCat5Bal4", 
 "fourStatePottsCat5Bal5", "fourStatePottsCat5Bal6", 
 "fourStatePottsCat5Bal7", "fourStatePottsCat5Bal8", 
 "fourStatePottsCat8Bal1", "fourStatePottsCat8Bal2", 
 "fourStatePottsCat8Bal3", "fourStatePottsCat8Bal4", 
 "fourStatePottsCat8Bal5", "fourStatePottsCat8Bal6", 
 "fourStatePottsCat8Bal7", "fourStatePottsCat8Bal8"}
] 

DeclarePackage["FusionCategories`Data`haargrup6`",{"haargrup6", "haargrup6Cat1", "haargrup6Cat2", "haargrup6Cat3", 
 "haargrup6Cat4", "haargrup6Cat5", "haargrup6Cat6", "haargrup6Cat7", 
 "haargrup6Cat8", "haargrup6Cat1Piv1", "haargrup6Cat2Piv1", 
 "haargrup6Cat3Piv1", "haargrup6Cat4Piv1", "haargrup6Cat5Piv1", 
 "haargrup6Cat6Piv1", "haargrup6Cat7Piv1", "haargrup6Cat8Piv1"}
] 

DeclarePackage["FusionCategories`Data`haagerup6`",{"haagerup6", "haagerup6Cat1", "haagerup6Cat2", "haagerup6Cat3", 
 "haagerup6Cat4", "haagerup6Cat5", "haagerup6Cat6", "haagerup6Cat7", 
 "haagerup6Cat8", "haagerup6Cat1Piv1", "haagerup6Cat2Piv1", 
 "haagerup6Cat3Piv1", "haagerup6Cat4Piv1", "haagerup6Cat5Piv1", 
 "haagerup6Cat6Piv1", "haagerup6Cat7Piv1", "haagerup6Cat8Piv1"}
] 

DeclarePackage["FusionCategories`Data`TY33`",{"TY33", "TY33Cat1", "TY33Cat2", "TY33Cat3", "TY33Cat4", "TY33Cat1Piv1", 
 "TY33Cat1Piv2", "TY33Cat2Piv1", "TY33Cat2Piv2", "TY33Cat3Piv1", 
 "TY33Cat3Piv2", "TY33Cat4Piv1", "TY33Cat4Piv2"}
] 

DeclarePackage["FusionCategories`Data`repDOdd7`",{"repDOdd7", "repDOdd7Cat1", "repDOdd7Cat2", "repDOdd7Cat3", 
 "repDOdd7Cat1Piv1", "repDOdd7Cat2Piv1", "repDOdd7Cat3Piv1", 
 "repDOdd7Cat1Brd1", "repDOdd7Cat1Brd2", "repDOdd7Cat1Brd3", 
 "repDOdd7Cat1Bal1", "repDOdd7Cat1Bal2", "repDOdd7Cat1Bal3"}
] 
DeclarePackage["FusionCategories`Data`haagerup6`",{"haagerup6", "haagerup6Cat1", "haagerup6Cat2", "haagerup6Cat3", 
 "haagerup6Cat4", "haagerup6Cat5", "haagerup6Cat6", "haagerup6Cat7", 
 "haagerup6Cat8", "haagerup6Cat1Unitary", "haagerup6Cat3Unitary", 
 "haagerup6Cat5Unitary", "haagerup6Cat7Unitary", "haagerup6Cat1Piv1", 
 "haagerup6Cat2Piv1", "haagerup6Cat3Piv1", "haagerup6Cat4Piv1", 
 "haagerup6Cat5Piv1", "haagerup6Cat6Piv1", "haagerup6Cat7Piv1", 
 "haagerup6Cat8Piv1", "haagerup6Cat1UnitaryPiv1", "haagerup6Cat3UnitaryPiv1", 
 "haagerup6Cat5UnitaryPiv1", "haagerup6Cat7UnitaryPiv1", 
 "braidedCategories[haagerup6Cat1Unitary]", 
 "braidedCategories[haagerup6Cat3Unitary]", 
 "braidedCategories[haagerup6Cat5Unitary]", 
 "braidedCategories[haagerup6Cat7Unitary]", 
 "balancedCategories[haagerup6Cat1Unitary]", 
 "balancedCategories[haagerup6Cat3Unitary]", 
 "balancedCategories[haagerup6Cat5Unitary]", 
 "balancedCategories[haagerup6Cat7Unitary]"}
] 

