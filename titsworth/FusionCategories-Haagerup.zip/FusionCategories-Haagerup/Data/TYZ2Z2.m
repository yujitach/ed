BeginPackage["FusionCategories`Data`TYZ2Z2`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[TYZ2Z2] ^= {TYZ2Z2Cat1, TYZ2Z2Cat2, TYZ2Z2Cat3, TYZ2Z2Cat4}
 
TYZ2Z2 /: fusionCategory[TYZ2Z2, 1] = TYZ2Z2Cat1
 
TYZ2Z2 /: fusionCategory[TYZ2Z2, 2] = TYZ2Z2Cat2
 
TYZ2Z2 /: fusionCategory[TYZ2Z2, 3] = TYZ2Z2Cat3
 
TYZ2Z2 /: fusionCategory[TYZ2Z2, 4] = TYZ2Z2Cat4
 
nFunction[TYZ2Z2] ^= TYZ2Z2NFunction
 
noMultiplicities[TYZ2Z2] ^= True
 
rank[TYZ2Z2] ^= 5
 
ring[TYZ2Z2] ^= TYZ2Z2
balancedCategories[TYZ2Z2Cat1] ^= {TYZ2Z2Cat1Bal1, TYZ2Z2Cat1Bal2, 
    TYZ2Z2Cat1Bal3, TYZ2Z2Cat1Bal4, TYZ2Z2Cat1Bal5, TYZ2Z2Cat1Bal6, 
    TYZ2Z2Cat1Bal7, TYZ2Z2Cat1Bal8, TYZ2Z2Cat1Bal9, TYZ2Z2Cat1Bal10, 
    TYZ2Z2Cat1Bal11, TYZ2Z2Cat1Bal12, TYZ2Z2Cat1Bal13, TYZ2Z2Cat1Bal14, 
    TYZ2Z2Cat1Bal15, TYZ2Z2Cat1Bal16}
 
TYZ2Z2Cat1 /: balancedCategory[TYZ2Z2Cat1, 1] = TYZ2Z2Cat1Bal1
 
TYZ2Z2Cat1 /: balancedCategory[TYZ2Z2Cat1, 2] = TYZ2Z2Cat1Bal2
 
TYZ2Z2Cat1 /: balancedCategory[TYZ2Z2Cat1, 3] = TYZ2Z2Cat1Bal3
 
TYZ2Z2Cat1 /: balancedCategory[TYZ2Z2Cat1, 4] = TYZ2Z2Cat1Bal4
 
TYZ2Z2Cat1 /: balancedCategory[TYZ2Z2Cat1, 5] = TYZ2Z2Cat1Bal5
 
TYZ2Z2Cat1 /: balancedCategory[TYZ2Z2Cat1, 6] = TYZ2Z2Cat1Bal6
 
TYZ2Z2Cat1 /: balancedCategory[TYZ2Z2Cat1, 7] = TYZ2Z2Cat1Bal7
 
TYZ2Z2Cat1 /: balancedCategory[TYZ2Z2Cat1, 8] = TYZ2Z2Cat1Bal8
 
TYZ2Z2Cat1 /: balancedCategory[TYZ2Z2Cat1, 9] = TYZ2Z2Cat1Bal9
 
TYZ2Z2Cat1 /: balancedCategory[TYZ2Z2Cat1, 10] = TYZ2Z2Cat1Bal10
 
TYZ2Z2Cat1 /: balancedCategory[TYZ2Z2Cat1, 11] = TYZ2Z2Cat1Bal11
 
TYZ2Z2Cat1 /: balancedCategory[TYZ2Z2Cat1, 12] = TYZ2Z2Cat1Bal12
 
TYZ2Z2Cat1 /: balancedCategory[TYZ2Z2Cat1, 13] = TYZ2Z2Cat1Bal13
 
TYZ2Z2Cat1 /: balancedCategory[TYZ2Z2Cat1, 14] = TYZ2Z2Cat1Bal14
 
TYZ2Z2Cat1 /: balancedCategory[TYZ2Z2Cat1, 15] = TYZ2Z2Cat1Bal15
 
TYZ2Z2Cat1 /: balancedCategory[TYZ2Z2Cat1, 16] = TYZ2Z2Cat1Bal16
 
braidedCategories[TYZ2Z2Cat1] ^= {TYZ2Z2Cat1Brd1, TYZ2Z2Cat1Brd2, 
    TYZ2Z2Cat1Brd3, TYZ2Z2Cat1Brd4, TYZ2Z2Cat1Brd5, TYZ2Z2Cat1Brd6, 
    TYZ2Z2Cat1Brd7, TYZ2Z2Cat1Brd8}
 
TYZ2Z2Cat1 /: braidedCategory[TYZ2Z2Cat1, 1] = TYZ2Z2Cat1Brd1
 
TYZ2Z2Cat1 /: braidedCategory[TYZ2Z2Cat1, 2] = TYZ2Z2Cat1Brd2
 
TYZ2Z2Cat1 /: braidedCategory[TYZ2Z2Cat1, 3] = TYZ2Z2Cat1Brd3
 
TYZ2Z2Cat1 /: braidedCategory[TYZ2Z2Cat1, 4] = TYZ2Z2Cat1Brd4
 
TYZ2Z2Cat1 /: braidedCategory[TYZ2Z2Cat1, 5] = TYZ2Z2Cat1Brd5
 
TYZ2Z2Cat1 /: braidedCategory[TYZ2Z2Cat1, 6] = TYZ2Z2Cat1Brd6
 
TYZ2Z2Cat1 /: braidedCategory[TYZ2Z2Cat1, 7] = TYZ2Z2Cat1Brd7
 
TYZ2Z2Cat1 /: braidedCategory[TYZ2Z2Cat1, 8] = TYZ2Z2Cat1Brd8
 
coeval[TYZ2Z2Cat1] ^= 1/sixJFunction[TYZ2Z2Cat1][#1, 
      dual[ring[TYZ2Z2Cat1]][#1], #1, #1, 0, 0] & 
 
eval[TYZ2Z2Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TYZ2Z2Cat1] ^= TYZ2Z2Cat1FMatrixFunction
 
fusionCategory[TYZ2Z2Cat1] ^= TYZ2Z2Cat1
 
TYZ2Z2Cat1 /: modularCategory[TYZ2Z2Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TYZ2Z2Cat1] ^= {TYZ2Z2Cat1Piv1, TYZ2Z2Cat1Piv2}
 
TYZ2Z2Cat1 /: pivotalCategory[TYZ2Z2Cat1, 1] = TYZ2Z2Cat1Piv1
 
TYZ2Z2Cat1 /: pivotalCategory[TYZ2Z2Cat1, 2] = TYZ2Z2Cat1Piv2
 
TYZ2Z2Cat1 /: pivotalCategory[TYZ2Z2Cat1, {1, 1, 1, 1, -1}] = TYZ2Z2Cat1Piv2
 
TYZ2Z2Cat1 /: pivotalCategory[TYZ2Z2Cat1, {1, 1, 1, 1, 1}] = TYZ2Z2Cat1Piv1
 
TYZ2Z2Cat1 /: ribbonCategory[TYZ2Z2Cat1, 1] = TYZ2Z2Cat1Bal1
 
TYZ2Z2Cat1 /: ribbonCategory[TYZ2Z2Cat1, 2] = TYZ2Z2Cat1Bal2
 
TYZ2Z2Cat1 /: ribbonCategory[TYZ2Z2Cat1, 3] = TYZ2Z2Cat1Bal3
 
TYZ2Z2Cat1 /: ribbonCategory[TYZ2Z2Cat1, 4] = TYZ2Z2Cat1Bal4
 
TYZ2Z2Cat1 /: ribbonCategory[TYZ2Z2Cat1, 5] = TYZ2Z2Cat1Bal5
 
TYZ2Z2Cat1 /: ribbonCategory[TYZ2Z2Cat1, 6] = TYZ2Z2Cat1Bal6
 
TYZ2Z2Cat1 /: ribbonCategory[TYZ2Z2Cat1, 7] = TYZ2Z2Cat1Bal7
 
TYZ2Z2Cat1 /: ribbonCategory[TYZ2Z2Cat1, 8] = TYZ2Z2Cat1Bal8
 
TYZ2Z2Cat1 /: ribbonCategory[TYZ2Z2Cat1, 9] = TYZ2Z2Cat1Bal9
 
TYZ2Z2Cat1 /: ribbonCategory[TYZ2Z2Cat1, 10] = TYZ2Z2Cat1Bal10
 
TYZ2Z2Cat1 /: ribbonCategory[TYZ2Z2Cat1, 11] = TYZ2Z2Cat1Bal11
 
TYZ2Z2Cat1 /: ribbonCategory[TYZ2Z2Cat1, 12] = TYZ2Z2Cat1Bal12
 
TYZ2Z2Cat1 /: ribbonCategory[TYZ2Z2Cat1, 13] = TYZ2Z2Cat1Bal13
 
TYZ2Z2Cat1 /: ribbonCategory[TYZ2Z2Cat1, 14] = TYZ2Z2Cat1Bal14
 
TYZ2Z2Cat1 /: ribbonCategory[TYZ2Z2Cat1, 15] = TYZ2Z2Cat1Bal15
 
TYZ2Z2Cat1 /: ribbonCategory[TYZ2Z2Cat1, 16] = TYZ2Z2Cat1Bal16
 
ring[TYZ2Z2Cat1] ^= TYZ2Z2
 
TYZ2Z2Cat1 /: sphericalCategory[TYZ2Z2Cat1, 1] = TYZ2Z2Cat1Piv1
 
TYZ2Z2Cat1 /: sphericalCategory[TYZ2Z2Cat1, 2] = TYZ2Z2Cat1Piv2
 
fusionCategoryIndex[TYZ2Z2][TYZ2Z2Cat1] ^= 1
balancedCategory[TYZ2Z2Cat1Bal1] ^= TYZ2Z2Cat1Bal1
 
braidedCategory[TYZ2Z2Cat1Bal1] ^= TYZ2Z2Cat1Brd1
 
fusionCategory[TYZ2Z2Cat1Bal1] ^= TYZ2Z2Cat1
 
pivotalCategory[TYZ2Z2Cat1Bal1] ^= TYZ2Z2Cat1Piv1
 
ribbonCategory[TYZ2Z2Cat1Bal1] ^= TYZ2Z2Cat1Bal1
 
ring[TYZ2Z2Cat1Bal1] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat1Bal1] ^= TYZ2Z2Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][balancedCategory[#1]] & )[
    TYZ2Z2Cat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat1Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat1Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat1Bal1] ^= 1
balancedCategory[TYZ2Z2Cat1Bal10] ^= TYZ2Z2Cat1Bal10
 
braidedCategory[TYZ2Z2Cat1Bal10] ^= TYZ2Z2Cat1Brd5
 
fusionCategory[TYZ2Z2Cat1Bal10] ^= TYZ2Z2Cat1
 
pivotalCategory[TYZ2Z2Cat1Bal10] ^= TYZ2Z2Cat1Piv2
 
ribbonCategory[TYZ2Z2Cat1Bal10] ^= TYZ2Z2Cat1Bal10
 
ring[TYZ2Z2Cat1Bal10] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat1Bal10] ^= TYZ2Z2Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd5]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal10] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][balancedCategory[#1]] & )[
    TYZ2Z2Cat1Bal10] ^= 10
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat1Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal10] ^= 5
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd5]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal10] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal10] ^= 10
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat1Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat1Bal10] ^= 5
balancedCategory[TYZ2Z2Cat1Bal11] ^= TYZ2Z2Cat1Bal11
 
braidedCategory[TYZ2Z2Cat1Bal11] ^= TYZ2Z2Cat1Brd6
 
fusionCategory[TYZ2Z2Cat1Bal11] ^= TYZ2Z2Cat1
 
pivotalCategory[TYZ2Z2Cat1Bal11] ^= TYZ2Z2Cat1Piv1
 
ribbonCategory[TYZ2Z2Cat1Bal11] ^= TYZ2Z2Cat1Bal11
 
ring[TYZ2Z2Cat1Bal11] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat1Bal11] ^= TYZ2Z2Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd6]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal11] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][balancedCategory[#1]] & )[
    TYZ2Z2Cat1Bal11] ^= 11
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat1Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal11] ^= 6
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd6]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal11] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal11] ^= 11
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat1Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat1Bal11] ^= 6
balancedCategory[TYZ2Z2Cat1Bal12] ^= TYZ2Z2Cat1Bal12
 
braidedCategory[TYZ2Z2Cat1Bal12] ^= TYZ2Z2Cat1Brd6
 
fusionCategory[TYZ2Z2Cat1Bal12] ^= TYZ2Z2Cat1
 
pivotalCategory[TYZ2Z2Cat1Bal12] ^= TYZ2Z2Cat1Piv2
 
ribbonCategory[TYZ2Z2Cat1Bal12] ^= TYZ2Z2Cat1Bal12
 
ring[TYZ2Z2Cat1Bal12] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat1Bal12] ^= TYZ2Z2Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd6]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal12] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][balancedCategory[#1]] & )[
    TYZ2Z2Cat1Bal12] ^= 12
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat1Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal12] ^= 6
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd6]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal12] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal12] ^= 12
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat1Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat1Bal12] ^= 6
balancedCategory[TYZ2Z2Cat1Bal13] ^= TYZ2Z2Cat1Bal13
 
braidedCategory[TYZ2Z2Cat1Bal13] ^= TYZ2Z2Cat1Brd7
 
fusionCategory[TYZ2Z2Cat1Bal13] ^= TYZ2Z2Cat1
 
pivotalCategory[TYZ2Z2Cat1Bal13] ^= TYZ2Z2Cat1Piv1
 
ribbonCategory[TYZ2Z2Cat1Bal13] ^= TYZ2Z2Cat1Bal13
 
ring[TYZ2Z2Cat1Bal13] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat1Bal13] ^= TYZ2Z2Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd7]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal13] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][balancedCategory[#1]] & )[
    TYZ2Z2Cat1Bal13] ^= 13
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat1Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal13] ^= 7
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd7]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal13] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal13] ^= 13
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat1Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat1Bal13] ^= 7
balancedCategory[TYZ2Z2Cat1Bal14] ^= TYZ2Z2Cat1Bal14
 
braidedCategory[TYZ2Z2Cat1Bal14] ^= TYZ2Z2Cat1Brd7
 
fusionCategory[TYZ2Z2Cat1Bal14] ^= TYZ2Z2Cat1
 
pivotalCategory[TYZ2Z2Cat1Bal14] ^= TYZ2Z2Cat1Piv2
 
ribbonCategory[TYZ2Z2Cat1Bal14] ^= TYZ2Z2Cat1Bal14
 
ring[TYZ2Z2Cat1Bal14] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat1Bal14] ^= TYZ2Z2Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd7]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal14] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][balancedCategory[#1]] & )[
    TYZ2Z2Cat1Bal14] ^= 14
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat1Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal14] ^= 7
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd7]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal14] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal14] ^= 14
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat1Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat1Bal14] ^= 7
balancedCategory[TYZ2Z2Cat1Bal15] ^= TYZ2Z2Cat1Bal15
 
braidedCategory[TYZ2Z2Cat1Bal15] ^= TYZ2Z2Cat1Brd8
 
fusionCategory[TYZ2Z2Cat1Bal15] ^= TYZ2Z2Cat1
 
pivotalCategory[TYZ2Z2Cat1Bal15] ^= TYZ2Z2Cat1Piv1
 
ribbonCategory[TYZ2Z2Cat1Bal15] ^= TYZ2Z2Cat1Bal15
 
ring[TYZ2Z2Cat1Bal15] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat1Bal15] ^= TYZ2Z2Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd8]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal15] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][balancedCategory[#1]] & )[
    TYZ2Z2Cat1Bal15] ^= 15
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat1Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal15] ^= 8
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd8]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal15] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal15] ^= 15
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat1Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat1Bal15] ^= 8
balancedCategory[TYZ2Z2Cat1Bal16] ^= TYZ2Z2Cat1Bal16
 
braidedCategory[TYZ2Z2Cat1Bal16] ^= TYZ2Z2Cat1Brd8
 
fusionCategory[TYZ2Z2Cat1Bal16] ^= TYZ2Z2Cat1
 
pivotalCategory[TYZ2Z2Cat1Bal16] ^= TYZ2Z2Cat1Piv2
 
ribbonCategory[TYZ2Z2Cat1Bal16] ^= TYZ2Z2Cat1Bal16
 
ring[TYZ2Z2Cat1Bal16] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat1Bal16] ^= TYZ2Z2Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd8]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal16] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][balancedCategory[#1]] & )[
    TYZ2Z2Cat1Bal16] ^= 16
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat1Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal16] ^= 8
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd8]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal16] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal16] ^= 16
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat1Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat1Bal16] ^= 8
balancedCategory[TYZ2Z2Cat1Bal2] ^= TYZ2Z2Cat1Bal2
 
braidedCategory[TYZ2Z2Cat1Bal2] ^= TYZ2Z2Cat1Brd1
 
fusionCategory[TYZ2Z2Cat1Bal2] ^= TYZ2Z2Cat1
 
pivotalCategory[TYZ2Z2Cat1Bal2] ^= TYZ2Z2Cat1Piv2
 
ribbonCategory[TYZ2Z2Cat1Bal2] ^= TYZ2Z2Cat1Bal2
 
ring[TYZ2Z2Cat1Bal2] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat1Bal2] ^= TYZ2Z2Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][balancedCategory[#1]] & )[
    TYZ2Z2Cat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat1Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat1Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat1Bal2] ^= 1
balancedCategory[TYZ2Z2Cat1Bal3] ^= TYZ2Z2Cat1Bal3
 
braidedCategory[TYZ2Z2Cat1Bal3] ^= TYZ2Z2Cat1Brd2
 
fusionCategory[TYZ2Z2Cat1Bal3] ^= TYZ2Z2Cat1
 
pivotalCategory[TYZ2Z2Cat1Bal3] ^= TYZ2Z2Cat1Piv1
 
ribbonCategory[TYZ2Z2Cat1Bal3] ^= TYZ2Z2Cat1Bal3
 
ring[TYZ2Z2Cat1Bal3] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat1Bal3] ^= TYZ2Z2Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][balancedCategory[#1]] & )[
    TYZ2Z2Cat1Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat1Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat1Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat1Bal3] ^= 2
balancedCategory[TYZ2Z2Cat1Bal4] ^= TYZ2Z2Cat1Bal4
 
braidedCategory[TYZ2Z2Cat1Bal4] ^= TYZ2Z2Cat1Brd2
 
fusionCategory[TYZ2Z2Cat1Bal4] ^= TYZ2Z2Cat1
 
pivotalCategory[TYZ2Z2Cat1Bal4] ^= TYZ2Z2Cat1Piv2
 
ribbonCategory[TYZ2Z2Cat1Bal4] ^= TYZ2Z2Cat1Bal4
 
ring[TYZ2Z2Cat1Bal4] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat1Bal4] ^= TYZ2Z2Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][balancedCategory[#1]] & )[
    TYZ2Z2Cat1Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat1Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat1Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat1Bal4] ^= 2
balancedCategory[TYZ2Z2Cat1Bal5] ^= TYZ2Z2Cat1Bal5
 
braidedCategory[TYZ2Z2Cat1Bal5] ^= TYZ2Z2Cat1Brd3
 
fusionCategory[TYZ2Z2Cat1Bal5] ^= TYZ2Z2Cat1
 
pivotalCategory[TYZ2Z2Cat1Bal5] ^= TYZ2Z2Cat1Piv1
 
ribbonCategory[TYZ2Z2Cat1Bal5] ^= TYZ2Z2Cat1Bal5
 
ring[TYZ2Z2Cat1Bal5] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat1Bal5] ^= TYZ2Z2Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd3]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][balancedCategory[#1]] & )[
    TYZ2Z2Cat1Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat1Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal5] ^= 3
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat1Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat1Bal5] ^= 3
balancedCategory[TYZ2Z2Cat1Bal6] ^= TYZ2Z2Cat1Bal6
 
braidedCategory[TYZ2Z2Cat1Bal6] ^= TYZ2Z2Cat1Brd3
 
fusionCategory[TYZ2Z2Cat1Bal6] ^= TYZ2Z2Cat1
 
pivotalCategory[TYZ2Z2Cat1Bal6] ^= TYZ2Z2Cat1Piv2
 
ribbonCategory[TYZ2Z2Cat1Bal6] ^= TYZ2Z2Cat1Bal6
 
ring[TYZ2Z2Cat1Bal6] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat1Bal6] ^= TYZ2Z2Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd3]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][balancedCategory[#1]] & )[
    TYZ2Z2Cat1Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat1Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal6] ^= 3
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat1Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat1Bal6] ^= 3
balancedCategory[TYZ2Z2Cat1Bal7] ^= TYZ2Z2Cat1Bal7
 
braidedCategory[TYZ2Z2Cat1Bal7] ^= TYZ2Z2Cat1Brd4
 
fusionCategory[TYZ2Z2Cat1Bal7] ^= TYZ2Z2Cat1
 
pivotalCategory[TYZ2Z2Cat1Bal7] ^= TYZ2Z2Cat1Piv1
 
ribbonCategory[TYZ2Z2Cat1Bal7] ^= TYZ2Z2Cat1Bal7
 
ring[TYZ2Z2Cat1Bal7] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat1Bal7] ^= TYZ2Z2Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd4]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][balancedCategory[#1]] & )[
    TYZ2Z2Cat1Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat1Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal7] ^= 4
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat1Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat1Bal7] ^= 4
balancedCategory[TYZ2Z2Cat1Bal8] ^= TYZ2Z2Cat1Bal8
 
braidedCategory[TYZ2Z2Cat1Bal8] ^= TYZ2Z2Cat1Brd4
 
fusionCategory[TYZ2Z2Cat1Bal8] ^= TYZ2Z2Cat1
 
pivotalCategory[TYZ2Z2Cat1Bal8] ^= TYZ2Z2Cat1Piv2
 
ribbonCategory[TYZ2Z2Cat1Bal8] ^= TYZ2Z2Cat1Bal8
 
ring[TYZ2Z2Cat1Bal8] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat1Bal8] ^= TYZ2Z2Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd4]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][balancedCategory[#1]] & )[
    TYZ2Z2Cat1Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat1Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal8] ^= 4
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat1Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat1Bal8] ^= 4
balancedCategory[TYZ2Z2Cat1Bal9] ^= TYZ2Z2Cat1Bal9
 
braidedCategory[TYZ2Z2Cat1Bal9] ^= TYZ2Z2Cat1Brd5
 
fusionCategory[TYZ2Z2Cat1Bal9] ^= TYZ2Z2Cat1
 
pivotalCategory[TYZ2Z2Cat1Bal9] ^= TYZ2Z2Cat1Piv1
 
ribbonCategory[TYZ2Z2Cat1Bal9] ^= TYZ2Z2Cat1Bal9
 
ring[TYZ2Z2Cat1Bal9] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat1Bal9] ^= TYZ2Z2Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd5]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal9] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][balancedCategory[#1]] & )[
    TYZ2Z2Cat1Bal9] ^= 9
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat1Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat1Bal9] ^= 5
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat1Brd5]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal9] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat1Bal9] ^= 9
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat1Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat1Bal9] ^= 5
balancedCategories[TYZ2Z2Cat1Brd1] ^= {TYZ2Z2Cat1Bal1, TYZ2Z2Cat1Bal2}
 
TYZ2Z2Cat1Brd1 /: balancedCategory[TYZ2Z2Cat1Brd1, 1] = TYZ2Z2Cat1Bal1
 
TYZ2Z2Cat1Brd1 /: balancedCategory[TYZ2Z2Cat1Brd1, 2] = TYZ2Z2Cat1Bal2
 
braidedCategory[TYZ2Z2Cat1Brd1] ^= TYZ2Z2Cat1Brd1
 
fusionCategory[TYZ2Z2Cat1Brd1] ^= TYZ2Z2Cat1
 
TYZ2Z2Cat1Brd1 /: modularCategory[TYZ2Z2Cat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat1Brd1 /: ribbonCategory[TYZ2Z2Cat1Brd1, 1] = TYZ2Z2Cat1Bal1
 
TYZ2Z2Cat1Brd1 /: ribbonCategory[TYZ2Z2Cat1Brd1, 2] = TYZ2Z2Cat1Bal2
 
ring[TYZ2Z2Cat1Brd1] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat1Brd1] ^= TYZ2Z2Cat1Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][braidedCategory[#1]] & )[
    TYZ2Z2Cat1Brd1] ^= 1
braidedCategory[TYZ2Z2Cat1Brd1RMatrixFunction] ^= TYZ2Z2Cat1Brd1
 
fusionCategory[TYZ2Z2Cat1Brd1RMatrixFunction] ^= TYZ2Z2Cat1
 
rMatrixFunction[TYZ2Z2Cat1Brd1RMatrixFunction] ^= 
   TYZ2Z2Cat1Brd1RMatrixFunction
 
TYZ2Z2Cat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[1, 1, 0] = {{-1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[1, 2, 3] = {{1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[1, 4, 4] = {{-I}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[2, 1, 3] = {{1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[2, 2, 0] = {{-1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[2, 4, 4] = {{-I}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[3, 4, 4] = {{-1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[4, 1, 4] = {{-I}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[4, 2, 4] = {{-I}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[4, 3, 4] = {{-1}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[4, 4, 0] = {{-(-1)^(1/4)}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[4, 4, 1] = {{-(-1)^(3/4)}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[4, 4, 2] = {{-(-1)^(3/4)}}
 
TYZ2Z2Cat1Brd1RMatrixFunction[4, 4, 3] = {{(-1)^(1/4)}}
balancedCategories[TYZ2Z2Cat1Brd2] ^= {TYZ2Z2Cat1Bal3, TYZ2Z2Cat1Bal4}
 
TYZ2Z2Cat1Brd2 /: balancedCategory[TYZ2Z2Cat1Brd2, 1] = TYZ2Z2Cat1Bal3
 
TYZ2Z2Cat1Brd2 /: balancedCategory[TYZ2Z2Cat1Brd2, 2] = TYZ2Z2Cat1Bal4
 
braidedCategory[TYZ2Z2Cat1Brd2] ^= TYZ2Z2Cat1Brd2
 
fusionCategory[TYZ2Z2Cat1Brd2] ^= TYZ2Z2Cat1
 
TYZ2Z2Cat1Brd2 /: modularCategory[TYZ2Z2Cat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat1Brd2 /: ribbonCategory[TYZ2Z2Cat1Brd2, 1] = TYZ2Z2Cat1Bal3
 
TYZ2Z2Cat1Brd2 /: ribbonCategory[TYZ2Z2Cat1Brd2, 2] = TYZ2Z2Cat1Bal4
 
ring[TYZ2Z2Cat1Brd2] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat1Brd2] ^= TYZ2Z2Cat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][braidedCategory[#1]] & )[
    TYZ2Z2Cat1Brd2] ^= 2
braidedCategory[TYZ2Z2Cat1Brd2RMatrixFunction] ^= TYZ2Z2Cat1Brd2
 
fusionCategory[TYZ2Z2Cat1Brd2RMatrixFunction] ^= TYZ2Z2Cat1
 
rMatrixFunction[TYZ2Z2Cat1Brd2RMatrixFunction] ^= 
   TYZ2Z2Cat1Brd2RMatrixFunction
 
TYZ2Z2Cat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[1, 1, 0] = {{-1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[1, 2, 3] = {{1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[1, 4, 4] = {{-I}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[2, 1, 3] = {{1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[2, 2, 0] = {{-1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[2, 4, 4] = {{-I}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[3, 4, 4] = {{-1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[4, 1, 4] = {{-I}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[4, 2, 4] = {{-I}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[4, 3, 4] = {{-1}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[4, 4, 0] = {{(-1)^(1/4)}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[4, 4, 1] = {{(-1)^(3/4)}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[4, 4, 2] = {{(-1)^(3/4)}}
 
TYZ2Z2Cat1Brd2RMatrixFunction[4, 4, 3] = {{-(-1)^(1/4)}}
balancedCategories[TYZ2Z2Cat1Brd3] ^= {TYZ2Z2Cat1Bal5, TYZ2Z2Cat1Bal6}
 
TYZ2Z2Cat1Brd3 /: balancedCategory[TYZ2Z2Cat1Brd3, 1] = TYZ2Z2Cat1Bal5
 
TYZ2Z2Cat1Brd3 /: balancedCategory[TYZ2Z2Cat1Brd3, 2] = TYZ2Z2Cat1Bal6
 
braidedCategory[TYZ2Z2Cat1Brd3] ^= TYZ2Z2Cat1Brd3
 
fusionCategory[TYZ2Z2Cat1Brd3] ^= TYZ2Z2Cat1
 
TYZ2Z2Cat1Brd3 /: modularCategory[TYZ2Z2Cat1Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat1Brd3 /: ribbonCategory[TYZ2Z2Cat1Brd3, 1] = TYZ2Z2Cat1Bal5
 
TYZ2Z2Cat1Brd3 /: ribbonCategory[TYZ2Z2Cat1Brd3, 2] = TYZ2Z2Cat1Bal6
 
ring[TYZ2Z2Cat1Brd3] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat1Brd3] ^= TYZ2Z2Cat1Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][braidedCategory[#1]] & )[
    TYZ2Z2Cat1Brd3] ^= 3
braidedCategory[TYZ2Z2Cat1Brd3RMatrixFunction] ^= TYZ2Z2Cat1Brd3
 
fusionCategory[TYZ2Z2Cat1Brd3RMatrixFunction] ^= TYZ2Z2Cat1
 
rMatrixFunction[TYZ2Z2Cat1Brd3RMatrixFunction] ^= 
   TYZ2Z2Cat1Brd3RMatrixFunction
 
TYZ2Z2Cat1Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[1, 1, 0] = {{-1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[1, 2, 3] = {{1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[1, 4, 4] = {{-I}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[2, 1, 3] = {{1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[2, 2, 0] = {{-1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[2, 4, 4] = {{I}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[3, 4, 4] = {{1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[4, 1, 4] = {{-I}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[4, 2, 4] = {{I}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[4, 3, 4] = {{1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[4, 4, 0] = {{-I}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[4, 4, 1] = {{1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[4, 4, 2] = {{-1}}
 
TYZ2Z2Cat1Brd3RMatrixFunction[4, 4, 3] = {{-I}}
balancedCategories[TYZ2Z2Cat1Brd4] ^= {TYZ2Z2Cat1Bal7, TYZ2Z2Cat1Bal8}
 
TYZ2Z2Cat1Brd4 /: balancedCategory[TYZ2Z2Cat1Brd4, 1] = TYZ2Z2Cat1Bal7
 
TYZ2Z2Cat1Brd4 /: balancedCategory[TYZ2Z2Cat1Brd4, 2] = TYZ2Z2Cat1Bal8
 
braidedCategory[TYZ2Z2Cat1Brd4] ^= TYZ2Z2Cat1Brd4
 
fusionCategory[TYZ2Z2Cat1Brd4] ^= TYZ2Z2Cat1
 
TYZ2Z2Cat1Brd4 /: modularCategory[TYZ2Z2Cat1Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat1Brd4 /: ribbonCategory[TYZ2Z2Cat1Brd4, 1] = TYZ2Z2Cat1Bal7
 
TYZ2Z2Cat1Brd4 /: ribbonCategory[TYZ2Z2Cat1Brd4, 2] = TYZ2Z2Cat1Bal8
 
ring[TYZ2Z2Cat1Brd4] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat1Brd4] ^= TYZ2Z2Cat1Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][braidedCategory[#1]] & )[
    TYZ2Z2Cat1Brd4] ^= 4
braidedCategory[TYZ2Z2Cat1Brd4RMatrixFunction] ^= TYZ2Z2Cat1Brd4
 
fusionCategory[TYZ2Z2Cat1Brd4RMatrixFunction] ^= TYZ2Z2Cat1
 
rMatrixFunction[TYZ2Z2Cat1Brd4RMatrixFunction] ^= 
   TYZ2Z2Cat1Brd4RMatrixFunction
 
TYZ2Z2Cat1Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[1, 1, 0] = {{-1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[1, 2, 3] = {{1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[1, 4, 4] = {{-I}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[2, 1, 3] = {{1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[2, 2, 0] = {{-1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[2, 4, 4] = {{I}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[3, 4, 4] = {{1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[4, 1, 4] = {{-I}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[4, 2, 4] = {{I}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[4, 3, 4] = {{1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[4, 4, 0] = {{I}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[4, 4, 1] = {{-1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[4, 4, 2] = {{1}}
 
TYZ2Z2Cat1Brd4RMatrixFunction[4, 4, 3] = {{I}}
balancedCategories[TYZ2Z2Cat1Brd5] ^= {TYZ2Z2Cat1Bal9, TYZ2Z2Cat1Bal10}
 
TYZ2Z2Cat1Brd5 /: balancedCategory[TYZ2Z2Cat1Brd5, 1] = TYZ2Z2Cat1Bal9
 
TYZ2Z2Cat1Brd5 /: balancedCategory[TYZ2Z2Cat1Brd5, 2] = TYZ2Z2Cat1Bal10
 
braidedCategory[TYZ2Z2Cat1Brd5] ^= TYZ2Z2Cat1Brd5
 
fusionCategory[TYZ2Z2Cat1Brd5] ^= TYZ2Z2Cat1
 
TYZ2Z2Cat1Brd5 /: modularCategory[TYZ2Z2Cat1Brd5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat1Brd5 /: ribbonCategory[TYZ2Z2Cat1Brd5, 1] = TYZ2Z2Cat1Bal9
 
TYZ2Z2Cat1Brd5 /: ribbonCategory[TYZ2Z2Cat1Brd5, 2] = TYZ2Z2Cat1Bal10
 
ring[TYZ2Z2Cat1Brd5] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat1Brd5] ^= TYZ2Z2Cat1Brd5RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][braidedCategory[#1]] & )[
    TYZ2Z2Cat1Brd5] ^= 5
braidedCategory[TYZ2Z2Cat1Brd5RMatrixFunction] ^= TYZ2Z2Cat1Brd5
 
fusionCategory[TYZ2Z2Cat1Brd5RMatrixFunction] ^= TYZ2Z2Cat1
 
rMatrixFunction[TYZ2Z2Cat1Brd5RMatrixFunction] ^= 
   TYZ2Z2Cat1Brd5RMatrixFunction
 
TYZ2Z2Cat1Brd5RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[1, 1, 0] = {{-1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[1, 2, 3] = {{1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[1, 4, 4] = {{I}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[2, 1, 3] = {{1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[2, 2, 0] = {{-1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[2, 4, 4] = {{-I}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[3, 4, 4] = {{1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[4, 1, 4] = {{I}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[4, 2, 4] = {{-I}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[4, 3, 4] = {{1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[4, 4, 0] = {{-I}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[4, 4, 1] = {{-1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[4, 4, 2] = {{1}}
 
TYZ2Z2Cat1Brd5RMatrixFunction[4, 4, 3] = {{-I}}
balancedCategories[TYZ2Z2Cat1Brd6] ^= {TYZ2Z2Cat1Bal11, TYZ2Z2Cat1Bal12}
 
TYZ2Z2Cat1Brd6 /: balancedCategory[TYZ2Z2Cat1Brd6, 1] = TYZ2Z2Cat1Bal11
 
TYZ2Z2Cat1Brd6 /: balancedCategory[TYZ2Z2Cat1Brd6, 2] = TYZ2Z2Cat1Bal12
 
braidedCategory[TYZ2Z2Cat1Brd6] ^= TYZ2Z2Cat1Brd6
 
fusionCategory[TYZ2Z2Cat1Brd6] ^= TYZ2Z2Cat1
 
TYZ2Z2Cat1Brd6 /: modularCategory[TYZ2Z2Cat1Brd6, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat1Brd6 /: ribbonCategory[TYZ2Z2Cat1Brd6, 1] = TYZ2Z2Cat1Bal11
 
TYZ2Z2Cat1Brd6 /: ribbonCategory[TYZ2Z2Cat1Brd6, 2] = TYZ2Z2Cat1Bal12
 
ring[TYZ2Z2Cat1Brd6] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat1Brd6] ^= TYZ2Z2Cat1Brd6RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][braidedCategory[#1]] & )[
    TYZ2Z2Cat1Brd6] ^= 6
braidedCategory[TYZ2Z2Cat1Brd6RMatrixFunction] ^= TYZ2Z2Cat1Brd6
 
fusionCategory[TYZ2Z2Cat1Brd6RMatrixFunction] ^= TYZ2Z2Cat1
 
rMatrixFunction[TYZ2Z2Cat1Brd6RMatrixFunction] ^= 
   TYZ2Z2Cat1Brd6RMatrixFunction
 
TYZ2Z2Cat1Brd6RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[1, 1, 0] = {{-1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[1, 2, 3] = {{1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[1, 4, 4] = {{I}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[2, 1, 3] = {{1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[2, 2, 0] = {{-1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[2, 4, 4] = {{-I}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[3, 4, 4] = {{1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[4, 1, 4] = {{I}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[4, 2, 4] = {{-I}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[4, 3, 4] = {{1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[4, 4, 0] = {{I}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[4, 4, 1] = {{1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[4, 4, 2] = {{-1}}
 
TYZ2Z2Cat1Brd6RMatrixFunction[4, 4, 3] = {{I}}
balancedCategories[TYZ2Z2Cat1Brd7] ^= {TYZ2Z2Cat1Bal13, TYZ2Z2Cat1Bal14}
 
TYZ2Z2Cat1Brd7 /: balancedCategory[TYZ2Z2Cat1Brd7, 1] = TYZ2Z2Cat1Bal13
 
TYZ2Z2Cat1Brd7 /: balancedCategory[TYZ2Z2Cat1Brd7, 2] = TYZ2Z2Cat1Bal14
 
braidedCategory[TYZ2Z2Cat1Brd7] ^= TYZ2Z2Cat1Brd7
 
fusionCategory[TYZ2Z2Cat1Brd7] ^= TYZ2Z2Cat1
 
TYZ2Z2Cat1Brd7 /: modularCategory[TYZ2Z2Cat1Brd7, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat1Brd7 /: ribbonCategory[TYZ2Z2Cat1Brd7, 1] = TYZ2Z2Cat1Bal13
 
TYZ2Z2Cat1Brd7 /: ribbonCategory[TYZ2Z2Cat1Brd7, 2] = TYZ2Z2Cat1Bal14
 
ring[TYZ2Z2Cat1Brd7] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat1Brd7] ^= TYZ2Z2Cat1Brd7RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][braidedCategory[#1]] & )[
    TYZ2Z2Cat1Brd7] ^= 7
braidedCategory[TYZ2Z2Cat1Brd7RMatrixFunction] ^= TYZ2Z2Cat1Brd7
 
fusionCategory[TYZ2Z2Cat1Brd7RMatrixFunction] ^= TYZ2Z2Cat1
 
rMatrixFunction[TYZ2Z2Cat1Brd7RMatrixFunction] ^= 
   TYZ2Z2Cat1Brd7RMatrixFunction
 
TYZ2Z2Cat1Brd7RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[1, 1, 0] = {{-1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[1, 2, 3] = {{1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[1, 4, 4] = {{I}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[2, 1, 3] = {{1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[2, 2, 0] = {{-1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[2, 4, 4] = {{I}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[3, 4, 4] = {{-1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[4, 1, 4] = {{I}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[4, 2, 4] = {{I}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[4, 3, 4] = {{-1}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[4, 4, 0] = {{-(-1)^(3/4)}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[4, 4, 1] = {{-(-1)^(1/4)}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[4, 4, 2] = {{-(-1)^(1/4)}}
 
TYZ2Z2Cat1Brd7RMatrixFunction[4, 4, 3] = {{(-1)^(3/4)}}
balancedCategories[TYZ2Z2Cat1Brd8] ^= {TYZ2Z2Cat1Bal15, TYZ2Z2Cat1Bal16}
 
TYZ2Z2Cat1Brd8 /: balancedCategory[TYZ2Z2Cat1Brd8, 1] = TYZ2Z2Cat1Bal15
 
TYZ2Z2Cat1Brd8 /: balancedCategory[TYZ2Z2Cat1Brd8, 2] = TYZ2Z2Cat1Bal16
 
braidedCategory[TYZ2Z2Cat1Brd8] ^= TYZ2Z2Cat1Brd8
 
fusionCategory[TYZ2Z2Cat1Brd8] ^= TYZ2Z2Cat1
 
TYZ2Z2Cat1Brd8 /: modularCategory[TYZ2Z2Cat1Brd8, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat1Brd8 /: ribbonCategory[TYZ2Z2Cat1Brd8, 1] = TYZ2Z2Cat1Bal15
 
TYZ2Z2Cat1Brd8 /: ribbonCategory[TYZ2Z2Cat1Brd8, 2] = TYZ2Z2Cat1Bal16
 
ring[TYZ2Z2Cat1Brd8] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat1Brd8] ^= TYZ2Z2Cat1Brd8RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat1]][braidedCategory[#1]] & )[
    TYZ2Z2Cat1Brd8] ^= 8
braidedCategory[TYZ2Z2Cat1Brd8RMatrixFunction] ^= TYZ2Z2Cat1Brd8
 
fusionCategory[TYZ2Z2Cat1Brd8RMatrixFunction] ^= TYZ2Z2Cat1
 
rMatrixFunction[TYZ2Z2Cat1Brd8RMatrixFunction] ^= 
   TYZ2Z2Cat1Brd8RMatrixFunction
 
TYZ2Z2Cat1Brd8RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[1, 1, 0] = {{-1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[1, 2, 3] = {{1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[1, 4, 4] = {{I}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[2, 1, 3] = {{1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[2, 2, 0] = {{-1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[2, 4, 4] = {{I}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[3, 4, 4] = {{-1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[4, 1, 4] = {{I}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[4, 2, 4] = {{I}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[4, 3, 4] = {{-1}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[4, 4, 0] = {{(-1)^(3/4)}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[4, 4, 1] = {{(-1)^(1/4)}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[4, 4, 2] = {{(-1)^(1/4)}}
 
TYZ2Z2Cat1Brd8RMatrixFunction[4, 4, 3] = {{-(-1)^(3/4)}}
fMatrixFunction[TYZ2Z2Cat1FMatrixFunction] ^= TYZ2Z2Cat1FMatrixFunction
 
fusionCategory[TYZ2Z2Cat1FMatrixFunction] ^= TYZ2Z2Cat1
 
ring[TYZ2Z2Cat1FMatrixFunction] ^= TYZ2Z2
 
TYZ2Z2Cat1FMatrixFunction[1, 4, 1, 4] = {{-1}}
 
TYZ2Z2Cat1FMatrixFunction[1, 4, 3, 4] = {{-1}}
 
TYZ2Z2Cat1FMatrixFunction[2, 4, 2, 4] = {{-1}}
 
TYZ2Z2Cat1FMatrixFunction[2, 4, 3, 4] = {{-1}}
 
TYZ2Z2Cat1FMatrixFunction[3, 4, 1, 4] = {{-1}}
 
TYZ2Z2Cat1FMatrixFunction[3, 4, 2, 4] = {{-1}}
 
TYZ2Z2Cat1FMatrixFunction[4, 1, 4, 1] = {{-1}}
 
TYZ2Z2Cat1FMatrixFunction[4, 1, 4, 3] = {{-1}}
 
TYZ2Z2Cat1FMatrixFunction[4, 2, 4, 2] = {{-1}}
 
TYZ2Z2Cat1FMatrixFunction[4, 2, 4, 3] = {{-1}}
 
TYZ2Z2Cat1FMatrixFunction[4, 3, 4, 1] = {{-1}}
 
TYZ2Z2Cat1FMatrixFunction[4, 3, 4, 2] = {{-1}}
 
TYZ2Z2Cat1FMatrixFunction[4, 4, 4, 4] = {{-1/2, -1/2, -1/2, -1/2}, 
    {-1/2, 1/2, -1/2, 1/2}, {-1/2, -1/2, 1/2, 1/2}, {-1/2, 1/2, 1/2, -1/2}}
 
TYZ2Z2Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TYZ2Z2Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TYZ2Z2Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TYZ2Z2Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TYZ2Z2Cat1Piv1] ^= {TYZ2Z2Cat1Bal1, TYZ2Z2Cat1Bal3, 
    TYZ2Z2Cat1Bal5, TYZ2Z2Cat1Bal7, TYZ2Z2Cat1Bal9, TYZ2Z2Cat1Bal11, 
    TYZ2Z2Cat1Bal13, TYZ2Z2Cat1Bal15}
 
TYZ2Z2Cat1Piv1 /: balancedCategory[TYZ2Z2Cat1Piv1, 1] = TYZ2Z2Cat1Bal1
 
TYZ2Z2Cat1Piv1 /: balancedCategory[TYZ2Z2Cat1Piv1, 2] = TYZ2Z2Cat1Bal3
 
TYZ2Z2Cat1Piv1 /: balancedCategory[TYZ2Z2Cat1Piv1, 3] = TYZ2Z2Cat1Bal5
 
TYZ2Z2Cat1Piv1 /: balancedCategory[TYZ2Z2Cat1Piv1, 4] = TYZ2Z2Cat1Bal7
 
TYZ2Z2Cat1Piv1 /: balancedCategory[TYZ2Z2Cat1Piv1, 5] = TYZ2Z2Cat1Bal9
 
TYZ2Z2Cat1Piv1 /: balancedCategory[TYZ2Z2Cat1Piv1, 6] = TYZ2Z2Cat1Bal11
 
TYZ2Z2Cat1Piv1 /: balancedCategory[TYZ2Z2Cat1Piv1, 7] = TYZ2Z2Cat1Bal13
 
TYZ2Z2Cat1Piv1 /: balancedCategory[TYZ2Z2Cat1Piv1, 8] = TYZ2Z2Cat1Bal15
 
fusionCategory[TYZ2Z2Cat1Piv1] ^= TYZ2Z2Cat1
 
TYZ2Z2Cat1Piv1 /: modularCategory[TYZ2Z2Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TYZ2Z2Cat1Piv1] ^= TYZ2Z2Cat1Piv1
 
pivotalIsomorphism[TYZ2Z2Cat1Piv1] ^= TYZ2Z2Cat1Piv1PivotalIsomorphism
 
TYZ2Z2Cat1Piv1 /: ribbonCategory[TYZ2Z2Cat1Piv1, 1] = TYZ2Z2Cat1Bal1
 
TYZ2Z2Cat1Piv1 /: ribbonCategory[TYZ2Z2Cat1Piv1, 2] = TYZ2Z2Cat1Bal3
 
TYZ2Z2Cat1Piv1 /: ribbonCategory[TYZ2Z2Cat1Piv1, 3] = TYZ2Z2Cat1Bal5
 
TYZ2Z2Cat1Piv1 /: ribbonCategory[TYZ2Z2Cat1Piv1, 4] = TYZ2Z2Cat1Bal7
 
TYZ2Z2Cat1Piv1 /: ribbonCategory[TYZ2Z2Cat1Piv1, 5] = TYZ2Z2Cat1Bal9
 
TYZ2Z2Cat1Piv1 /: ribbonCategory[TYZ2Z2Cat1Piv1, 6] = TYZ2Z2Cat1Bal11
 
TYZ2Z2Cat1Piv1 /: ribbonCategory[TYZ2Z2Cat1Piv1, 7] = TYZ2Z2Cat1Bal13
 
TYZ2Z2Cat1Piv1 /: ribbonCategory[TYZ2Z2Cat1Piv1, 8] = TYZ2Z2Cat1Bal15
 
ring[TYZ2Z2Cat1Piv1] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat1Piv1] ^= TYZ2Z2Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[TYZ2Z2Cat1]][pivotalCategory[#1]] & )[
    TYZ2Z2Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TYZ2Z2Cat1]][
      sphericalCategory[#1]] & )[TYZ2Z2Cat1Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[TYZ2Z2Cat1Piv1PivotalIsomorphism] ^= TYZ2Z2Cat1
 
pivotalCategory[TYZ2Z2Cat1Piv1PivotalIsomorphism] ^= TYZ2Z2Cat1Piv1
 
pivotalIsomorphism[TYZ2Z2Cat1Piv1PivotalIsomorphism] ^= 
   TYZ2Z2Cat1Piv1PivotalIsomorphism
 
TYZ2Z2Cat1Piv1PivotalIsomorphism[0] = 1
 
TYZ2Z2Cat1Piv1PivotalIsomorphism[1] = 1
 
TYZ2Z2Cat1Piv1PivotalIsomorphism[2] = 1
 
TYZ2Z2Cat1Piv1PivotalIsomorphism[3] = 1
 
TYZ2Z2Cat1Piv1PivotalIsomorphism[4] = 1
balancedCategories[TYZ2Z2Cat1Piv2] ^= {TYZ2Z2Cat1Bal2, TYZ2Z2Cat1Bal4, 
    TYZ2Z2Cat1Bal6, TYZ2Z2Cat1Bal8, TYZ2Z2Cat1Bal10, TYZ2Z2Cat1Bal12, 
    TYZ2Z2Cat1Bal14, TYZ2Z2Cat1Bal16}
 
TYZ2Z2Cat1Piv2 /: balancedCategory[TYZ2Z2Cat1Piv2, 1] = TYZ2Z2Cat1Bal2
 
TYZ2Z2Cat1Piv2 /: balancedCategory[TYZ2Z2Cat1Piv2, 2] = TYZ2Z2Cat1Bal4
 
TYZ2Z2Cat1Piv2 /: balancedCategory[TYZ2Z2Cat1Piv2, 3] = TYZ2Z2Cat1Bal6
 
TYZ2Z2Cat1Piv2 /: balancedCategory[TYZ2Z2Cat1Piv2, 4] = TYZ2Z2Cat1Bal8
 
TYZ2Z2Cat1Piv2 /: balancedCategory[TYZ2Z2Cat1Piv2, 5] = TYZ2Z2Cat1Bal10
 
TYZ2Z2Cat1Piv2 /: balancedCategory[TYZ2Z2Cat1Piv2, 6] = TYZ2Z2Cat1Bal12
 
TYZ2Z2Cat1Piv2 /: balancedCategory[TYZ2Z2Cat1Piv2, 7] = TYZ2Z2Cat1Bal14
 
TYZ2Z2Cat1Piv2 /: balancedCategory[TYZ2Z2Cat1Piv2, 8] = TYZ2Z2Cat1Bal16
 
fusionCategory[TYZ2Z2Cat1Piv2] ^= TYZ2Z2Cat1
 
TYZ2Z2Cat1Piv2 /: modularCategory[TYZ2Z2Cat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TYZ2Z2Cat1Piv2] ^= TYZ2Z2Cat1Piv2
 
pivotalIsomorphism[TYZ2Z2Cat1Piv2] ^= TYZ2Z2Cat1Piv2PivotalIsomorphism
 
TYZ2Z2Cat1Piv2 /: ribbonCategory[TYZ2Z2Cat1Piv2, 1] = TYZ2Z2Cat1Bal2
 
TYZ2Z2Cat1Piv2 /: ribbonCategory[TYZ2Z2Cat1Piv2, 2] = TYZ2Z2Cat1Bal4
 
TYZ2Z2Cat1Piv2 /: ribbonCategory[TYZ2Z2Cat1Piv2, 3] = TYZ2Z2Cat1Bal6
 
TYZ2Z2Cat1Piv2 /: ribbonCategory[TYZ2Z2Cat1Piv2, 4] = TYZ2Z2Cat1Bal8
 
TYZ2Z2Cat1Piv2 /: ribbonCategory[TYZ2Z2Cat1Piv2, 5] = TYZ2Z2Cat1Bal10
 
TYZ2Z2Cat1Piv2 /: ribbonCategory[TYZ2Z2Cat1Piv2, 6] = TYZ2Z2Cat1Bal12
 
TYZ2Z2Cat1Piv2 /: ribbonCategory[TYZ2Z2Cat1Piv2, 7] = TYZ2Z2Cat1Bal14
 
TYZ2Z2Cat1Piv2 /: ribbonCategory[TYZ2Z2Cat1Piv2, 8] = TYZ2Z2Cat1Bal16
 
ring[TYZ2Z2Cat1Piv2] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat1Piv2] ^= TYZ2Z2Cat1Piv2
 
(pivotalCategoryIndex[fusionCategory[TYZ2Z2Cat1]][pivotalCategory[#1]] & )[
    TYZ2Z2Cat1Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TYZ2Z2Cat1]][
      sphericalCategory[#1]] & )[TYZ2Z2Cat1Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[TYZ2Z2Cat1Piv2PivotalIsomorphism] ^= TYZ2Z2Cat1
 
pivotalCategory[TYZ2Z2Cat1Piv2PivotalIsomorphism] ^= TYZ2Z2Cat1Piv2
 
pivotalIsomorphism[TYZ2Z2Cat1Piv2PivotalIsomorphism] ^= 
   TYZ2Z2Cat1Piv2PivotalIsomorphism
 
TYZ2Z2Cat1Piv2PivotalIsomorphism[0] = 1
 
TYZ2Z2Cat1Piv2PivotalIsomorphism[1] = 1
 
TYZ2Z2Cat1Piv2PivotalIsomorphism[2] = 1
 
TYZ2Z2Cat1Piv2PivotalIsomorphism[3] = 1
 
TYZ2Z2Cat1Piv2PivotalIsomorphism[4] = -1
balancedCategories[TYZ2Z2Cat2] ^= {TYZ2Z2Cat2Bal1, TYZ2Z2Cat2Bal2, 
    TYZ2Z2Cat2Bal3, TYZ2Z2Cat2Bal4, TYZ2Z2Cat2Bal5, TYZ2Z2Cat2Bal6, 
    TYZ2Z2Cat2Bal7, TYZ2Z2Cat2Bal8, TYZ2Z2Cat2Bal9, TYZ2Z2Cat2Bal10, 
    TYZ2Z2Cat2Bal11, TYZ2Z2Cat2Bal12, TYZ2Z2Cat2Bal13, TYZ2Z2Cat2Bal14, 
    TYZ2Z2Cat2Bal15, TYZ2Z2Cat2Bal16}
 
TYZ2Z2Cat2 /: balancedCategory[TYZ2Z2Cat2, 1] = TYZ2Z2Cat2Bal1
 
TYZ2Z2Cat2 /: balancedCategory[TYZ2Z2Cat2, 2] = TYZ2Z2Cat2Bal2
 
TYZ2Z2Cat2 /: balancedCategory[TYZ2Z2Cat2, 3] = TYZ2Z2Cat2Bal3
 
TYZ2Z2Cat2 /: balancedCategory[TYZ2Z2Cat2, 4] = TYZ2Z2Cat2Bal4
 
TYZ2Z2Cat2 /: balancedCategory[TYZ2Z2Cat2, 5] = TYZ2Z2Cat2Bal5
 
TYZ2Z2Cat2 /: balancedCategory[TYZ2Z2Cat2, 6] = TYZ2Z2Cat2Bal6
 
TYZ2Z2Cat2 /: balancedCategory[TYZ2Z2Cat2, 7] = TYZ2Z2Cat2Bal7
 
TYZ2Z2Cat2 /: balancedCategory[TYZ2Z2Cat2, 8] = TYZ2Z2Cat2Bal8
 
TYZ2Z2Cat2 /: balancedCategory[TYZ2Z2Cat2, 9] = TYZ2Z2Cat2Bal9
 
TYZ2Z2Cat2 /: balancedCategory[TYZ2Z2Cat2, 10] = TYZ2Z2Cat2Bal10
 
TYZ2Z2Cat2 /: balancedCategory[TYZ2Z2Cat2, 11] = TYZ2Z2Cat2Bal11
 
TYZ2Z2Cat2 /: balancedCategory[TYZ2Z2Cat2, 12] = TYZ2Z2Cat2Bal12
 
TYZ2Z2Cat2 /: balancedCategory[TYZ2Z2Cat2, 13] = TYZ2Z2Cat2Bal13
 
TYZ2Z2Cat2 /: balancedCategory[TYZ2Z2Cat2, 14] = TYZ2Z2Cat2Bal14
 
TYZ2Z2Cat2 /: balancedCategory[TYZ2Z2Cat2, 15] = TYZ2Z2Cat2Bal15
 
TYZ2Z2Cat2 /: balancedCategory[TYZ2Z2Cat2, 16] = TYZ2Z2Cat2Bal16
 
braidedCategories[TYZ2Z2Cat2] ^= {TYZ2Z2Cat2Brd1, TYZ2Z2Cat2Brd2, 
    TYZ2Z2Cat2Brd3, TYZ2Z2Cat2Brd4, TYZ2Z2Cat2Brd5, TYZ2Z2Cat2Brd6, 
    TYZ2Z2Cat2Brd7, TYZ2Z2Cat2Brd8}
 
TYZ2Z2Cat2 /: braidedCategory[TYZ2Z2Cat2, 1] = TYZ2Z2Cat2Brd1
 
TYZ2Z2Cat2 /: braidedCategory[TYZ2Z2Cat2, 2] = TYZ2Z2Cat2Brd2
 
TYZ2Z2Cat2 /: braidedCategory[TYZ2Z2Cat2, 3] = TYZ2Z2Cat2Brd3
 
TYZ2Z2Cat2 /: braidedCategory[TYZ2Z2Cat2, 4] = TYZ2Z2Cat2Brd4
 
TYZ2Z2Cat2 /: braidedCategory[TYZ2Z2Cat2, 5] = TYZ2Z2Cat2Brd5
 
TYZ2Z2Cat2 /: braidedCategory[TYZ2Z2Cat2, 6] = TYZ2Z2Cat2Brd6
 
TYZ2Z2Cat2 /: braidedCategory[TYZ2Z2Cat2, 7] = TYZ2Z2Cat2Brd7
 
TYZ2Z2Cat2 /: braidedCategory[TYZ2Z2Cat2, 8] = TYZ2Z2Cat2Brd8
 
coeval[TYZ2Z2Cat2] ^= 1/sixJFunction[TYZ2Z2Cat2][#1, 
      dual[ring[TYZ2Z2Cat2]][#1], #1, #1, 0, 0] & 
 
eval[TYZ2Z2Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TYZ2Z2Cat2] ^= TYZ2Z2Cat2FMatrixFunction
 
fusionCategory[TYZ2Z2Cat2] ^= TYZ2Z2Cat2
 
TYZ2Z2Cat2 /: modularCategory[TYZ2Z2Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TYZ2Z2Cat2] ^= {TYZ2Z2Cat2Piv1, TYZ2Z2Cat2Piv2}
 
TYZ2Z2Cat2 /: pivotalCategory[TYZ2Z2Cat2, 1] = TYZ2Z2Cat2Piv1
 
TYZ2Z2Cat2 /: pivotalCategory[TYZ2Z2Cat2, 2] = TYZ2Z2Cat2Piv2
 
TYZ2Z2Cat2 /: pivotalCategory[TYZ2Z2Cat2, {1, 1, 1, 1, -1}] = TYZ2Z2Cat2Piv2
 
TYZ2Z2Cat2 /: pivotalCategory[TYZ2Z2Cat2, {1, 1, 1, 1, 1}] = TYZ2Z2Cat2Piv1
 
TYZ2Z2Cat2 /: ribbonCategory[TYZ2Z2Cat2, 1] = TYZ2Z2Cat2Bal1
 
TYZ2Z2Cat2 /: ribbonCategory[TYZ2Z2Cat2, 2] = TYZ2Z2Cat2Bal2
 
TYZ2Z2Cat2 /: ribbonCategory[TYZ2Z2Cat2, 3] = TYZ2Z2Cat2Bal3
 
TYZ2Z2Cat2 /: ribbonCategory[TYZ2Z2Cat2, 4] = TYZ2Z2Cat2Bal4
 
TYZ2Z2Cat2 /: ribbonCategory[TYZ2Z2Cat2, 5] = TYZ2Z2Cat2Bal5
 
TYZ2Z2Cat2 /: ribbonCategory[TYZ2Z2Cat2, 6] = TYZ2Z2Cat2Bal6
 
TYZ2Z2Cat2 /: ribbonCategory[TYZ2Z2Cat2, 7] = TYZ2Z2Cat2Bal7
 
TYZ2Z2Cat2 /: ribbonCategory[TYZ2Z2Cat2, 8] = TYZ2Z2Cat2Bal8
 
TYZ2Z2Cat2 /: ribbonCategory[TYZ2Z2Cat2, 9] = TYZ2Z2Cat2Bal9
 
TYZ2Z2Cat2 /: ribbonCategory[TYZ2Z2Cat2, 10] = TYZ2Z2Cat2Bal10
 
TYZ2Z2Cat2 /: ribbonCategory[TYZ2Z2Cat2, 11] = TYZ2Z2Cat2Bal11
 
TYZ2Z2Cat2 /: ribbonCategory[TYZ2Z2Cat2, 12] = TYZ2Z2Cat2Bal12
 
TYZ2Z2Cat2 /: ribbonCategory[TYZ2Z2Cat2, 13] = TYZ2Z2Cat2Bal13
 
TYZ2Z2Cat2 /: ribbonCategory[TYZ2Z2Cat2, 14] = TYZ2Z2Cat2Bal14
 
TYZ2Z2Cat2 /: ribbonCategory[TYZ2Z2Cat2, 15] = TYZ2Z2Cat2Bal15
 
TYZ2Z2Cat2 /: ribbonCategory[TYZ2Z2Cat2, 16] = TYZ2Z2Cat2Bal16
 
ring[TYZ2Z2Cat2] ^= TYZ2Z2
 
TYZ2Z2Cat2 /: sphericalCategory[TYZ2Z2Cat2, 1] = TYZ2Z2Cat2Piv1
 
TYZ2Z2Cat2 /: sphericalCategory[TYZ2Z2Cat2, 2] = TYZ2Z2Cat2Piv2
 
fusionCategoryIndex[TYZ2Z2][TYZ2Z2Cat2] ^= 2
balancedCategory[TYZ2Z2Cat2Bal1] ^= TYZ2Z2Cat2Bal1
 
braidedCategory[TYZ2Z2Cat2Bal1] ^= TYZ2Z2Cat2Brd1
 
fusionCategory[TYZ2Z2Cat2Bal1] ^= TYZ2Z2Cat2
 
pivotalCategory[TYZ2Z2Cat2Bal1] ^= TYZ2Z2Cat2Piv1
 
ribbonCategory[TYZ2Z2Cat2Bal1] ^= TYZ2Z2Cat2Bal1
 
ring[TYZ2Z2Cat2Bal1] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat2Bal1] ^= TYZ2Z2Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][balancedCategory[#1]] & )[
    TYZ2Z2Cat2Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat2Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat2Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat2Bal1] ^= 1
balancedCategory[TYZ2Z2Cat2Bal10] ^= TYZ2Z2Cat2Bal10
 
braidedCategory[TYZ2Z2Cat2Bal10] ^= TYZ2Z2Cat2Brd5
 
fusionCategory[TYZ2Z2Cat2Bal10] ^= TYZ2Z2Cat2
 
pivotalCategory[TYZ2Z2Cat2Bal10] ^= TYZ2Z2Cat2Piv2
 
ribbonCategory[TYZ2Z2Cat2Bal10] ^= TYZ2Z2Cat2Bal10
 
ring[TYZ2Z2Cat2Bal10] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat2Bal10] ^= TYZ2Z2Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd5]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal10] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][balancedCategory[#1]] & )[
    TYZ2Z2Cat2Bal10] ^= 10
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat2Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal10] ^= 5
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd5]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal10] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal10] ^= 10
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat2Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat2Bal10] ^= 5
balancedCategory[TYZ2Z2Cat2Bal11] ^= TYZ2Z2Cat2Bal11
 
braidedCategory[TYZ2Z2Cat2Bal11] ^= TYZ2Z2Cat2Brd6
 
fusionCategory[TYZ2Z2Cat2Bal11] ^= TYZ2Z2Cat2
 
pivotalCategory[TYZ2Z2Cat2Bal11] ^= TYZ2Z2Cat2Piv1
 
ribbonCategory[TYZ2Z2Cat2Bal11] ^= TYZ2Z2Cat2Bal11
 
ring[TYZ2Z2Cat2Bal11] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat2Bal11] ^= TYZ2Z2Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd6]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal11] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][balancedCategory[#1]] & )[
    TYZ2Z2Cat2Bal11] ^= 11
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat2Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal11] ^= 6
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd6]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal11] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal11] ^= 11
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat2Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat2Bal11] ^= 6
balancedCategory[TYZ2Z2Cat2Bal12] ^= TYZ2Z2Cat2Bal12
 
braidedCategory[TYZ2Z2Cat2Bal12] ^= TYZ2Z2Cat2Brd6
 
fusionCategory[TYZ2Z2Cat2Bal12] ^= TYZ2Z2Cat2
 
pivotalCategory[TYZ2Z2Cat2Bal12] ^= TYZ2Z2Cat2Piv2
 
ribbonCategory[TYZ2Z2Cat2Bal12] ^= TYZ2Z2Cat2Bal12
 
ring[TYZ2Z2Cat2Bal12] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat2Bal12] ^= TYZ2Z2Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd6]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal12] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][balancedCategory[#1]] & )[
    TYZ2Z2Cat2Bal12] ^= 12
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat2Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal12] ^= 6
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd6]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal12] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal12] ^= 12
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat2Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat2Bal12] ^= 6
balancedCategory[TYZ2Z2Cat2Bal13] ^= TYZ2Z2Cat2Bal13
 
braidedCategory[TYZ2Z2Cat2Bal13] ^= TYZ2Z2Cat2Brd7
 
fusionCategory[TYZ2Z2Cat2Bal13] ^= TYZ2Z2Cat2
 
pivotalCategory[TYZ2Z2Cat2Bal13] ^= TYZ2Z2Cat2Piv1
 
ribbonCategory[TYZ2Z2Cat2Bal13] ^= TYZ2Z2Cat2Bal13
 
ring[TYZ2Z2Cat2Bal13] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat2Bal13] ^= TYZ2Z2Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd7]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal13] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][balancedCategory[#1]] & )[
    TYZ2Z2Cat2Bal13] ^= 13
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat2Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal13] ^= 7
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd7]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal13] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal13] ^= 13
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat2Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat2Bal13] ^= 7
balancedCategory[TYZ2Z2Cat2Bal14] ^= TYZ2Z2Cat2Bal14
 
braidedCategory[TYZ2Z2Cat2Bal14] ^= TYZ2Z2Cat2Brd7
 
fusionCategory[TYZ2Z2Cat2Bal14] ^= TYZ2Z2Cat2
 
pivotalCategory[TYZ2Z2Cat2Bal14] ^= TYZ2Z2Cat2Piv2
 
ribbonCategory[TYZ2Z2Cat2Bal14] ^= TYZ2Z2Cat2Bal14
 
ring[TYZ2Z2Cat2Bal14] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat2Bal14] ^= TYZ2Z2Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd7]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal14] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][balancedCategory[#1]] & )[
    TYZ2Z2Cat2Bal14] ^= 14
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat2Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal14] ^= 7
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd7]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal14] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal14] ^= 14
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat2Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat2Bal14] ^= 7
balancedCategory[TYZ2Z2Cat2Bal15] ^= TYZ2Z2Cat2Bal15
 
braidedCategory[TYZ2Z2Cat2Bal15] ^= TYZ2Z2Cat2Brd8
 
fusionCategory[TYZ2Z2Cat2Bal15] ^= TYZ2Z2Cat2
 
pivotalCategory[TYZ2Z2Cat2Bal15] ^= TYZ2Z2Cat2Piv1
 
ribbonCategory[TYZ2Z2Cat2Bal15] ^= TYZ2Z2Cat2Bal15
 
ring[TYZ2Z2Cat2Bal15] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat2Bal15] ^= TYZ2Z2Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd8]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal15] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][balancedCategory[#1]] & )[
    TYZ2Z2Cat2Bal15] ^= 15
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat2Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal15] ^= 8
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd8]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal15] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal15] ^= 15
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat2Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat2Bal15] ^= 8
balancedCategory[TYZ2Z2Cat2Bal16] ^= TYZ2Z2Cat2Bal16
 
braidedCategory[TYZ2Z2Cat2Bal16] ^= TYZ2Z2Cat2Brd8
 
fusionCategory[TYZ2Z2Cat2Bal16] ^= TYZ2Z2Cat2
 
pivotalCategory[TYZ2Z2Cat2Bal16] ^= TYZ2Z2Cat2Piv2
 
ribbonCategory[TYZ2Z2Cat2Bal16] ^= TYZ2Z2Cat2Bal16
 
ring[TYZ2Z2Cat2Bal16] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat2Bal16] ^= TYZ2Z2Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd8]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal16] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][balancedCategory[#1]] & )[
    TYZ2Z2Cat2Bal16] ^= 16
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat2Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal16] ^= 8
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd8]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal16] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal16] ^= 16
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat2Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat2Bal16] ^= 8
balancedCategory[TYZ2Z2Cat2Bal2] ^= TYZ2Z2Cat2Bal2
 
braidedCategory[TYZ2Z2Cat2Bal2] ^= TYZ2Z2Cat2Brd1
 
fusionCategory[TYZ2Z2Cat2Bal2] ^= TYZ2Z2Cat2
 
pivotalCategory[TYZ2Z2Cat2Bal2] ^= TYZ2Z2Cat2Piv2
 
ribbonCategory[TYZ2Z2Cat2Bal2] ^= TYZ2Z2Cat2Bal2
 
ring[TYZ2Z2Cat2Bal2] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat2Bal2] ^= TYZ2Z2Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][balancedCategory[#1]] & )[
    TYZ2Z2Cat2Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat2Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat2Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat2Bal2] ^= 1
balancedCategory[TYZ2Z2Cat2Bal3] ^= TYZ2Z2Cat2Bal3
 
braidedCategory[TYZ2Z2Cat2Bal3] ^= TYZ2Z2Cat2Brd2
 
fusionCategory[TYZ2Z2Cat2Bal3] ^= TYZ2Z2Cat2
 
pivotalCategory[TYZ2Z2Cat2Bal3] ^= TYZ2Z2Cat2Piv1
 
ribbonCategory[TYZ2Z2Cat2Bal3] ^= TYZ2Z2Cat2Bal3
 
ring[TYZ2Z2Cat2Bal3] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat2Bal3] ^= TYZ2Z2Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][balancedCategory[#1]] & )[
    TYZ2Z2Cat2Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat2Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat2Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat2Bal3] ^= 2
balancedCategory[TYZ2Z2Cat2Bal4] ^= TYZ2Z2Cat2Bal4
 
braidedCategory[TYZ2Z2Cat2Bal4] ^= TYZ2Z2Cat2Brd2
 
fusionCategory[TYZ2Z2Cat2Bal4] ^= TYZ2Z2Cat2
 
pivotalCategory[TYZ2Z2Cat2Bal4] ^= TYZ2Z2Cat2Piv2
 
ribbonCategory[TYZ2Z2Cat2Bal4] ^= TYZ2Z2Cat2Bal4
 
ring[TYZ2Z2Cat2Bal4] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat2Bal4] ^= TYZ2Z2Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][balancedCategory[#1]] & )[
    TYZ2Z2Cat2Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat2Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat2Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat2Bal4] ^= 2
balancedCategory[TYZ2Z2Cat2Bal5] ^= TYZ2Z2Cat2Bal5
 
braidedCategory[TYZ2Z2Cat2Bal5] ^= TYZ2Z2Cat2Brd3
 
fusionCategory[TYZ2Z2Cat2Bal5] ^= TYZ2Z2Cat2
 
pivotalCategory[TYZ2Z2Cat2Bal5] ^= TYZ2Z2Cat2Piv1
 
ribbonCategory[TYZ2Z2Cat2Bal5] ^= TYZ2Z2Cat2Bal5
 
ring[TYZ2Z2Cat2Bal5] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat2Bal5] ^= TYZ2Z2Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd3]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][balancedCategory[#1]] & )[
    TYZ2Z2Cat2Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat2Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal5] ^= 3
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat2Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat2Bal5] ^= 3
balancedCategory[TYZ2Z2Cat2Bal6] ^= TYZ2Z2Cat2Bal6
 
braidedCategory[TYZ2Z2Cat2Bal6] ^= TYZ2Z2Cat2Brd3
 
fusionCategory[TYZ2Z2Cat2Bal6] ^= TYZ2Z2Cat2
 
pivotalCategory[TYZ2Z2Cat2Bal6] ^= TYZ2Z2Cat2Piv2
 
ribbonCategory[TYZ2Z2Cat2Bal6] ^= TYZ2Z2Cat2Bal6
 
ring[TYZ2Z2Cat2Bal6] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat2Bal6] ^= TYZ2Z2Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd3]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][balancedCategory[#1]] & )[
    TYZ2Z2Cat2Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat2Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal6] ^= 3
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat2Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat2Bal6] ^= 3
balancedCategory[TYZ2Z2Cat2Bal7] ^= TYZ2Z2Cat2Bal7
 
braidedCategory[TYZ2Z2Cat2Bal7] ^= TYZ2Z2Cat2Brd4
 
fusionCategory[TYZ2Z2Cat2Bal7] ^= TYZ2Z2Cat2
 
pivotalCategory[TYZ2Z2Cat2Bal7] ^= TYZ2Z2Cat2Piv1
 
ribbonCategory[TYZ2Z2Cat2Bal7] ^= TYZ2Z2Cat2Bal7
 
ring[TYZ2Z2Cat2Bal7] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat2Bal7] ^= TYZ2Z2Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd4]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][balancedCategory[#1]] & )[
    TYZ2Z2Cat2Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat2Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal7] ^= 4
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat2Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat2Bal7] ^= 4
balancedCategory[TYZ2Z2Cat2Bal8] ^= TYZ2Z2Cat2Bal8
 
braidedCategory[TYZ2Z2Cat2Bal8] ^= TYZ2Z2Cat2Brd4
 
fusionCategory[TYZ2Z2Cat2Bal8] ^= TYZ2Z2Cat2
 
pivotalCategory[TYZ2Z2Cat2Bal8] ^= TYZ2Z2Cat2Piv2
 
ribbonCategory[TYZ2Z2Cat2Bal8] ^= TYZ2Z2Cat2Bal8
 
ring[TYZ2Z2Cat2Bal8] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat2Bal8] ^= TYZ2Z2Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd4]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][balancedCategory[#1]] & )[
    TYZ2Z2Cat2Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat2Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal8] ^= 4
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat2Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat2Bal8] ^= 4
balancedCategory[TYZ2Z2Cat2Bal9] ^= TYZ2Z2Cat2Bal9
 
braidedCategory[TYZ2Z2Cat2Bal9] ^= TYZ2Z2Cat2Brd5
 
fusionCategory[TYZ2Z2Cat2Bal9] ^= TYZ2Z2Cat2
 
pivotalCategory[TYZ2Z2Cat2Bal9] ^= TYZ2Z2Cat2Piv1
 
ribbonCategory[TYZ2Z2Cat2Bal9] ^= TYZ2Z2Cat2Bal9
 
ring[TYZ2Z2Cat2Bal9] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat2Bal9] ^= TYZ2Z2Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd5]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal9] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][balancedCategory[#1]] & )[
    TYZ2Z2Cat2Bal9] ^= 9
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat2Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat2Bal9] ^= 5
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat2Brd5]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal9] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat2Bal9] ^= 9
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat2Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat2Bal9] ^= 5
balancedCategories[TYZ2Z2Cat2Brd1] ^= {TYZ2Z2Cat2Bal1, TYZ2Z2Cat2Bal2}
 
TYZ2Z2Cat2Brd1 /: balancedCategory[TYZ2Z2Cat2Brd1, 1] = TYZ2Z2Cat2Bal1
 
TYZ2Z2Cat2Brd1 /: balancedCategory[TYZ2Z2Cat2Brd1, 2] = TYZ2Z2Cat2Bal2
 
braidedCategory[TYZ2Z2Cat2Brd1] ^= TYZ2Z2Cat2Brd1
 
fusionCategory[TYZ2Z2Cat2Brd1] ^= TYZ2Z2Cat2
 
TYZ2Z2Cat2Brd1 /: modularCategory[TYZ2Z2Cat2Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat2Brd1 /: ribbonCategory[TYZ2Z2Cat2Brd1, 1] = TYZ2Z2Cat2Bal1
 
TYZ2Z2Cat2Brd1 /: ribbonCategory[TYZ2Z2Cat2Brd1, 2] = TYZ2Z2Cat2Bal2
 
ring[TYZ2Z2Cat2Brd1] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat2Brd1] ^= TYZ2Z2Cat2Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][braidedCategory[#1]] & )[
    TYZ2Z2Cat2Brd1] ^= 1
braidedCategory[TYZ2Z2Cat2Brd1RMatrixFunction] ^= TYZ2Z2Cat2Brd1
 
fusionCategory[TYZ2Z2Cat2Brd1RMatrixFunction] ^= TYZ2Z2Cat2
 
rMatrixFunction[TYZ2Z2Cat2Brd1RMatrixFunction] ^= 
   TYZ2Z2Cat2Brd1RMatrixFunction
 
TYZ2Z2Cat2Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[1, 1, 0] = {{-1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[1, 3, 2] = {{1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[1, 4, 4] = {{-I}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[2, 4, 4] = {{-1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[3, 1, 2] = {{1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[3, 3, 0] = {{-1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[3, 4, 4] = {{-I}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[4, 1, 4] = {{-I}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[4, 2, 4] = {{-1}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[4, 3, 4] = {{-I}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[4, 4, 0] = {{-(-1)^(3/4)}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[4, 4, 1] = {{(-1)^(1/4)}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[4, 4, 2] = {{(-1)^(3/4)}}
 
TYZ2Z2Cat2Brd1RMatrixFunction[4, 4, 3] = {{(-1)^(1/4)}}
balancedCategories[TYZ2Z2Cat2Brd2] ^= {TYZ2Z2Cat2Bal3, TYZ2Z2Cat2Bal4}
 
TYZ2Z2Cat2Brd2 /: balancedCategory[TYZ2Z2Cat2Brd2, 1] = TYZ2Z2Cat2Bal3
 
TYZ2Z2Cat2Brd2 /: balancedCategory[TYZ2Z2Cat2Brd2, 2] = TYZ2Z2Cat2Bal4
 
braidedCategory[TYZ2Z2Cat2Brd2] ^= TYZ2Z2Cat2Brd2
 
fusionCategory[TYZ2Z2Cat2Brd2] ^= TYZ2Z2Cat2
 
TYZ2Z2Cat2Brd2 /: modularCategory[TYZ2Z2Cat2Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat2Brd2 /: ribbonCategory[TYZ2Z2Cat2Brd2, 1] = TYZ2Z2Cat2Bal3
 
TYZ2Z2Cat2Brd2 /: ribbonCategory[TYZ2Z2Cat2Brd2, 2] = TYZ2Z2Cat2Bal4
 
ring[TYZ2Z2Cat2Brd2] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat2Brd2] ^= TYZ2Z2Cat2Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][braidedCategory[#1]] & )[
    TYZ2Z2Cat2Brd2] ^= 2
braidedCategory[TYZ2Z2Cat2Brd2RMatrixFunction] ^= TYZ2Z2Cat2Brd2
 
fusionCategory[TYZ2Z2Cat2Brd2RMatrixFunction] ^= TYZ2Z2Cat2
 
rMatrixFunction[TYZ2Z2Cat2Brd2RMatrixFunction] ^= 
   TYZ2Z2Cat2Brd2RMatrixFunction
 
TYZ2Z2Cat2Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[1, 1, 0] = {{-1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[1, 3, 2] = {{1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[1, 4, 4] = {{-I}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[2, 4, 4] = {{-1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[3, 1, 2] = {{1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[3, 3, 0] = {{-1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[3, 4, 4] = {{-I}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[4, 1, 4] = {{-I}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[4, 2, 4] = {{-1}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[4, 3, 4] = {{-I}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[4, 4, 0] = {{(-1)^(3/4)}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[4, 4, 1] = {{-(-1)^(1/4)}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[4, 4, 2] = {{-(-1)^(3/4)}}
 
TYZ2Z2Cat2Brd2RMatrixFunction[4, 4, 3] = {{-(-1)^(1/4)}}
balancedCategories[TYZ2Z2Cat2Brd3] ^= {TYZ2Z2Cat2Bal5, TYZ2Z2Cat2Bal6}
 
TYZ2Z2Cat2Brd3 /: balancedCategory[TYZ2Z2Cat2Brd3, 1] = TYZ2Z2Cat2Bal5
 
TYZ2Z2Cat2Brd3 /: balancedCategory[TYZ2Z2Cat2Brd3, 2] = TYZ2Z2Cat2Bal6
 
braidedCategory[TYZ2Z2Cat2Brd3] ^= TYZ2Z2Cat2Brd3
 
fusionCategory[TYZ2Z2Cat2Brd3] ^= TYZ2Z2Cat2
 
TYZ2Z2Cat2Brd3 /: modularCategory[TYZ2Z2Cat2Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat2Brd3 /: ribbonCategory[TYZ2Z2Cat2Brd3, 1] = TYZ2Z2Cat2Bal5
 
TYZ2Z2Cat2Brd3 /: ribbonCategory[TYZ2Z2Cat2Brd3, 2] = TYZ2Z2Cat2Bal6
 
ring[TYZ2Z2Cat2Brd3] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat2Brd3] ^= TYZ2Z2Cat2Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][braidedCategory[#1]] & )[
    TYZ2Z2Cat2Brd3] ^= 3
braidedCategory[TYZ2Z2Cat2Brd3RMatrixFunction] ^= TYZ2Z2Cat2Brd3
 
fusionCategory[TYZ2Z2Cat2Brd3RMatrixFunction] ^= TYZ2Z2Cat2
 
rMatrixFunction[TYZ2Z2Cat2Brd3RMatrixFunction] ^= 
   TYZ2Z2Cat2Brd3RMatrixFunction
 
TYZ2Z2Cat2Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[1, 1, 0] = {{-1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[1, 3, 2] = {{1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[1, 4, 4] = {{-I}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[2, 4, 4] = {{1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[3, 1, 2] = {{1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[3, 3, 0] = {{-1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[3, 4, 4] = {{I}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[4, 1, 4] = {{-I}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[4, 2, 4] = {{1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[4, 3, 4] = {{I}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[4, 4, 0] = {{-1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[4, 4, 1] = {{-I}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[4, 4, 2] = {{-1}}
 
TYZ2Z2Cat2Brd3RMatrixFunction[4, 4, 3] = {{I}}
balancedCategories[TYZ2Z2Cat2Brd4] ^= {TYZ2Z2Cat2Bal7, TYZ2Z2Cat2Bal8}
 
TYZ2Z2Cat2Brd4 /: balancedCategory[TYZ2Z2Cat2Brd4, 1] = TYZ2Z2Cat2Bal7
 
TYZ2Z2Cat2Brd4 /: balancedCategory[TYZ2Z2Cat2Brd4, 2] = TYZ2Z2Cat2Bal8
 
braidedCategory[TYZ2Z2Cat2Brd4] ^= TYZ2Z2Cat2Brd4
 
fusionCategory[TYZ2Z2Cat2Brd4] ^= TYZ2Z2Cat2
 
TYZ2Z2Cat2Brd4 /: modularCategory[TYZ2Z2Cat2Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat2Brd4 /: ribbonCategory[TYZ2Z2Cat2Brd4, 1] = TYZ2Z2Cat2Bal7
 
TYZ2Z2Cat2Brd4 /: ribbonCategory[TYZ2Z2Cat2Brd4, 2] = TYZ2Z2Cat2Bal8
 
ring[TYZ2Z2Cat2Brd4] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat2Brd4] ^= TYZ2Z2Cat2Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][braidedCategory[#1]] & )[
    TYZ2Z2Cat2Brd4] ^= 4
braidedCategory[TYZ2Z2Cat2Brd4RMatrixFunction] ^= TYZ2Z2Cat2Brd4
 
fusionCategory[TYZ2Z2Cat2Brd4RMatrixFunction] ^= TYZ2Z2Cat2
 
rMatrixFunction[TYZ2Z2Cat2Brd4RMatrixFunction] ^= 
   TYZ2Z2Cat2Brd4RMatrixFunction
 
TYZ2Z2Cat2Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[1, 1, 0] = {{-1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[1, 3, 2] = {{1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[1, 4, 4] = {{-I}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[2, 4, 4] = {{1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[3, 1, 2] = {{1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[3, 3, 0] = {{-1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[3, 4, 4] = {{I}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[4, 1, 4] = {{-I}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[4, 2, 4] = {{1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[4, 3, 4] = {{I}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[4, 4, 0] = {{1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[4, 4, 1] = {{I}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[4, 4, 2] = {{1}}
 
TYZ2Z2Cat2Brd4RMatrixFunction[4, 4, 3] = {{-I}}
balancedCategories[TYZ2Z2Cat2Brd5] ^= {TYZ2Z2Cat2Bal9, TYZ2Z2Cat2Bal10}
 
TYZ2Z2Cat2Brd5 /: balancedCategory[TYZ2Z2Cat2Brd5, 1] = TYZ2Z2Cat2Bal9
 
TYZ2Z2Cat2Brd5 /: balancedCategory[TYZ2Z2Cat2Brd5, 2] = TYZ2Z2Cat2Bal10
 
braidedCategory[TYZ2Z2Cat2Brd5] ^= TYZ2Z2Cat2Brd5
 
fusionCategory[TYZ2Z2Cat2Brd5] ^= TYZ2Z2Cat2
 
TYZ2Z2Cat2Brd5 /: modularCategory[TYZ2Z2Cat2Brd5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat2Brd5 /: ribbonCategory[TYZ2Z2Cat2Brd5, 1] = TYZ2Z2Cat2Bal9
 
TYZ2Z2Cat2Brd5 /: ribbonCategory[TYZ2Z2Cat2Brd5, 2] = TYZ2Z2Cat2Bal10
 
ring[TYZ2Z2Cat2Brd5] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat2Brd5] ^= TYZ2Z2Cat2Brd5RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][braidedCategory[#1]] & )[
    TYZ2Z2Cat2Brd5] ^= 5
braidedCategory[TYZ2Z2Cat2Brd5RMatrixFunction] ^= TYZ2Z2Cat2Brd5
 
fusionCategory[TYZ2Z2Cat2Brd5RMatrixFunction] ^= TYZ2Z2Cat2
 
rMatrixFunction[TYZ2Z2Cat2Brd5RMatrixFunction] ^= 
   TYZ2Z2Cat2Brd5RMatrixFunction
 
TYZ2Z2Cat2Brd5RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[1, 1, 0] = {{-1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[1, 3, 2] = {{1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[1, 4, 4] = {{I}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[2, 4, 4] = {{-1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[3, 1, 2] = {{1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[3, 3, 0] = {{-1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[3, 4, 4] = {{I}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[4, 1, 4] = {{I}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[4, 2, 4] = {{-1}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[4, 3, 4] = {{I}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[4, 4, 0] = {{-(-1)^(1/4)}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[4, 4, 1] = {{(-1)^(3/4)}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[4, 4, 2] = {{(-1)^(1/4)}}
 
TYZ2Z2Cat2Brd5RMatrixFunction[4, 4, 3] = {{(-1)^(3/4)}}
balancedCategories[TYZ2Z2Cat2Brd6] ^= {TYZ2Z2Cat2Bal11, TYZ2Z2Cat2Bal12}
 
TYZ2Z2Cat2Brd6 /: balancedCategory[TYZ2Z2Cat2Brd6, 1] = TYZ2Z2Cat2Bal11
 
TYZ2Z2Cat2Brd6 /: balancedCategory[TYZ2Z2Cat2Brd6, 2] = TYZ2Z2Cat2Bal12
 
braidedCategory[TYZ2Z2Cat2Brd6] ^= TYZ2Z2Cat2Brd6
 
fusionCategory[TYZ2Z2Cat2Brd6] ^= TYZ2Z2Cat2
 
TYZ2Z2Cat2Brd6 /: modularCategory[TYZ2Z2Cat2Brd6, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat2Brd6 /: ribbonCategory[TYZ2Z2Cat2Brd6, 1] = TYZ2Z2Cat2Bal11
 
TYZ2Z2Cat2Brd6 /: ribbonCategory[TYZ2Z2Cat2Brd6, 2] = TYZ2Z2Cat2Bal12
 
ring[TYZ2Z2Cat2Brd6] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat2Brd6] ^= TYZ2Z2Cat2Brd6RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][braidedCategory[#1]] & )[
    TYZ2Z2Cat2Brd6] ^= 6
braidedCategory[TYZ2Z2Cat2Brd6RMatrixFunction] ^= TYZ2Z2Cat2Brd6
 
fusionCategory[TYZ2Z2Cat2Brd6RMatrixFunction] ^= TYZ2Z2Cat2
 
rMatrixFunction[TYZ2Z2Cat2Brd6RMatrixFunction] ^= 
   TYZ2Z2Cat2Brd6RMatrixFunction
 
TYZ2Z2Cat2Brd6RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[1, 1, 0] = {{-1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[1, 3, 2] = {{1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[1, 4, 4] = {{I}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[2, 4, 4] = {{-1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[3, 1, 2] = {{1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[3, 3, 0] = {{-1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[3, 4, 4] = {{I}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[4, 1, 4] = {{I}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[4, 2, 4] = {{-1}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[4, 3, 4] = {{I}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[4, 4, 0] = {{(-1)^(1/4)}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[4, 4, 1] = {{-(-1)^(3/4)}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[4, 4, 2] = {{-(-1)^(1/4)}}
 
TYZ2Z2Cat2Brd6RMatrixFunction[4, 4, 3] = {{-(-1)^(3/4)}}
balancedCategories[TYZ2Z2Cat2Brd7] ^= {TYZ2Z2Cat2Bal13, TYZ2Z2Cat2Bal14}
 
TYZ2Z2Cat2Brd7 /: balancedCategory[TYZ2Z2Cat2Brd7, 1] = TYZ2Z2Cat2Bal13
 
TYZ2Z2Cat2Brd7 /: balancedCategory[TYZ2Z2Cat2Brd7, 2] = TYZ2Z2Cat2Bal14
 
braidedCategory[TYZ2Z2Cat2Brd7] ^= TYZ2Z2Cat2Brd7
 
fusionCategory[TYZ2Z2Cat2Brd7] ^= TYZ2Z2Cat2
 
TYZ2Z2Cat2Brd7 /: modularCategory[TYZ2Z2Cat2Brd7, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat2Brd7 /: ribbonCategory[TYZ2Z2Cat2Brd7, 1] = TYZ2Z2Cat2Bal13
 
TYZ2Z2Cat2Brd7 /: ribbonCategory[TYZ2Z2Cat2Brd7, 2] = TYZ2Z2Cat2Bal14
 
ring[TYZ2Z2Cat2Brd7] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat2Brd7] ^= TYZ2Z2Cat2Brd7RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][braidedCategory[#1]] & )[
    TYZ2Z2Cat2Brd7] ^= 7
braidedCategory[TYZ2Z2Cat2Brd7RMatrixFunction] ^= TYZ2Z2Cat2Brd7
 
fusionCategory[TYZ2Z2Cat2Brd7RMatrixFunction] ^= TYZ2Z2Cat2
 
rMatrixFunction[TYZ2Z2Cat2Brd7RMatrixFunction] ^= 
   TYZ2Z2Cat2Brd7RMatrixFunction
 
TYZ2Z2Cat2Brd7RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[1, 1, 0] = {{-1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[1, 3, 2] = {{1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[1, 4, 4] = {{I}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[2, 4, 4] = {{1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[3, 1, 2] = {{1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[3, 3, 0] = {{-1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[3, 4, 4] = {{-I}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[4, 1, 4] = {{I}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[4, 2, 4] = {{1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[4, 3, 4] = {{-I}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[4, 4, 0] = {{-1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[4, 4, 1] = {{I}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[4, 4, 2] = {{-1}}
 
TYZ2Z2Cat2Brd7RMatrixFunction[4, 4, 3] = {{-I}}
balancedCategories[TYZ2Z2Cat2Brd8] ^= {TYZ2Z2Cat2Bal15, TYZ2Z2Cat2Bal16}
 
TYZ2Z2Cat2Brd8 /: balancedCategory[TYZ2Z2Cat2Brd8, 1] = TYZ2Z2Cat2Bal15
 
TYZ2Z2Cat2Brd8 /: balancedCategory[TYZ2Z2Cat2Brd8, 2] = TYZ2Z2Cat2Bal16
 
braidedCategory[TYZ2Z2Cat2Brd8] ^= TYZ2Z2Cat2Brd8
 
fusionCategory[TYZ2Z2Cat2Brd8] ^= TYZ2Z2Cat2
 
TYZ2Z2Cat2Brd8 /: modularCategory[TYZ2Z2Cat2Brd8, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat2Brd8 /: ribbonCategory[TYZ2Z2Cat2Brd8, 1] = TYZ2Z2Cat2Bal15
 
TYZ2Z2Cat2Brd8 /: ribbonCategory[TYZ2Z2Cat2Brd8, 2] = TYZ2Z2Cat2Bal16
 
ring[TYZ2Z2Cat2Brd8] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat2Brd8] ^= TYZ2Z2Cat2Brd8RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat2]][braidedCategory[#1]] & )[
    TYZ2Z2Cat2Brd8] ^= 8
braidedCategory[TYZ2Z2Cat2Brd8RMatrixFunction] ^= TYZ2Z2Cat2Brd8
 
fusionCategory[TYZ2Z2Cat2Brd8RMatrixFunction] ^= TYZ2Z2Cat2
 
rMatrixFunction[TYZ2Z2Cat2Brd8RMatrixFunction] ^= 
   TYZ2Z2Cat2Brd8RMatrixFunction
 
TYZ2Z2Cat2Brd8RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[1, 1, 0] = {{-1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[1, 3, 2] = {{1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[1, 4, 4] = {{I}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[2, 4, 4] = {{1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[3, 1, 2] = {{1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[3, 3, 0] = {{-1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[3, 4, 4] = {{-I}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[4, 1, 4] = {{I}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[4, 2, 4] = {{1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[4, 3, 4] = {{-I}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[4, 4, 0] = {{1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[4, 4, 1] = {{-I}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[4, 4, 2] = {{1}}
 
TYZ2Z2Cat2Brd8RMatrixFunction[4, 4, 3] = {{I}}
fMatrixFunction[TYZ2Z2Cat2FMatrixFunction] ^= TYZ2Z2Cat2FMatrixFunction
 
fusionCategory[TYZ2Z2Cat2FMatrixFunction] ^= TYZ2Z2Cat2
 
ring[TYZ2Z2Cat2FMatrixFunction] ^= TYZ2Z2
 
TYZ2Z2Cat2FMatrixFunction[1, 4, 1, 4] = {{-1}}
 
TYZ2Z2Cat2FMatrixFunction[1, 4, 2, 4] = {{-1}}
 
TYZ2Z2Cat2FMatrixFunction[2, 4, 1, 4] = {{-1}}
 
TYZ2Z2Cat2FMatrixFunction[2, 4, 3, 4] = {{-1}}
 
TYZ2Z2Cat2FMatrixFunction[3, 4, 2, 4] = {{-1}}
 
TYZ2Z2Cat2FMatrixFunction[3, 4, 3, 4] = {{-1}}
 
TYZ2Z2Cat2FMatrixFunction[4, 1, 4, 1] = {{-1}}
 
TYZ2Z2Cat2FMatrixFunction[4, 1, 4, 2] = {{-1}}
 
TYZ2Z2Cat2FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
TYZ2Z2Cat2FMatrixFunction[4, 2, 4, 3] = {{-1}}
 
TYZ2Z2Cat2FMatrixFunction[4, 3, 4, 2] = {{-1}}
 
TYZ2Z2Cat2FMatrixFunction[4, 3, 4, 3] = {{-1}}
 
TYZ2Z2Cat2FMatrixFunction[4, 4, 4, 4] = {{1/2, 1/2, 1/2, 1/2}, 
    {1/2, -1/2, -1/2, 1/2}, {1/2, -1/2, 1/2, -1/2}, {1/2, 1/2, -1/2, -1/2}}
 
TYZ2Z2Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TYZ2Z2Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TYZ2Z2Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TYZ2Z2Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TYZ2Z2Cat2Piv1] ^= {TYZ2Z2Cat2Bal1, TYZ2Z2Cat2Bal3, 
    TYZ2Z2Cat2Bal5, TYZ2Z2Cat2Bal7, TYZ2Z2Cat2Bal9, TYZ2Z2Cat2Bal11, 
    TYZ2Z2Cat2Bal13, TYZ2Z2Cat2Bal15}
 
TYZ2Z2Cat2Piv1 /: balancedCategory[TYZ2Z2Cat2Piv1, 1] = TYZ2Z2Cat2Bal1
 
TYZ2Z2Cat2Piv1 /: balancedCategory[TYZ2Z2Cat2Piv1, 2] = TYZ2Z2Cat2Bal3
 
TYZ2Z2Cat2Piv1 /: balancedCategory[TYZ2Z2Cat2Piv1, 3] = TYZ2Z2Cat2Bal5
 
TYZ2Z2Cat2Piv1 /: balancedCategory[TYZ2Z2Cat2Piv1, 4] = TYZ2Z2Cat2Bal7
 
TYZ2Z2Cat2Piv1 /: balancedCategory[TYZ2Z2Cat2Piv1, 5] = TYZ2Z2Cat2Bal9
 
TYZ2Z2Cat2Piv1 /: balancedCategory[TYZ2Z2Cat2Piv1, 6] = TYZ2Z2Cat2Bal11
 
TYZ2Z2Cat2Piv1 /: balancedCategory[TYZ2Z2Cat2Piv1, 7] = TYZ2Z2Cat2Bal13
 
TYZ2Z2Cat2Piv1 /: balancedCategory[TYZ2Z2Cat2Piv1, 8] = TYZ2Z2Cat2Bal15
 
fusionCategory[TYZ2Z2Cat2Piv1] ^= TYZ2Z2Cat2
 
TYZ2Z2Cat2Piv1 /: modularCategory[TYZ2Z2Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TYZ2Z2Cat2Piv1] ^= TYZ2Z2Cat2Piv1
 
pivotalIsomorphism[TYZ2Z2Cat2Piv1] ^= TYZ2Z2Cat2Piv1PivotalIsomorphism
 
TYZ2Z2Cat2Piv1 /: ribbonCategory[TYZ2Z2Cat2Piv1, 1] = TYZ2Z2Cat2Bal1
 
TYZ2Z2Cat2Piv1 /: ribbonCategory[TYZ2Z2Cat2Piv1, 2] = TYZ2Z2Cat2Bal3
 
TYZ2Z2Cat2Piv1 /: ribbonCategory[TYZ2Z2Cat2Piv1, 3] = TYZ2Z2Cat2Bal5
 
TYZ2Z2Cat2Piv1 /: ribbonCategory[TYZ2Z2Cat2Piv1, 4] = TYZ2Z2Cat2Bal7
 
TYZ2Z2Cat2Piv1 /: ribbonCategory[TYZ2Z2Cat2Piv1, 5] = TYZ2Z2Cat2Bal9
 
TYZ2Z2Cat2Piv1 /: ribbonCategory[TYZ2Z2Cat2Piv1, 6] = TYZ2Z2Cat2Bal11
 
TYZ2Z2Cat2Piv1 /: ribbonCategory[TYZ2Z2Cat2Piv1, 7] = TYZ2Z2Cat2Bal13
 
TYZ2Z2Cat2Piv1 /: ribbonCategory[TYZ2Z2Cat2Piv1, 8] = TYZ2Z2Cat2Bal15
 
ring[TYZ2Z2Cat2Piv1] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat2Piv1] ^= TYZ2Z2Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[TYZ2Z2Cat2]][pivotalCategory[#1]] & )[
    TYZ2Z2Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TYZ2Z2Cat2]][
      sphericalCategory[#1]] & )[TYZ2Z2Cat2Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[TYZ2Z2Cat2Piv1PivotalIsomorphism] ^= TYZ2Z2Cat2
 
pivotalCategory[TYZ2Z2Cat2Piv1PivotalIsomorphism] ^= TYZ2Z2Cat2Piv1
 
pivotalIsomorphism[TYZ2Z2Cat2Piv1PivotalIsomorphism] ^= 
   TYZ2Z2Cat2Piv1PivotalIsomorphism
 
TYZ2Z2Cat2Piv1PivotalIsomorphism[0] = 1
 
TYZ2Z2Cat2Piv1PivotalIsomorphism[1] = 1
 
TYZ2Z2Cat2Piv1PivotalIsomorphism[2] = 1
 
TYZ2Z2Cat2Piv1PivotalIsomorphism[3] = 1
 
TYZ2Z2Cat2Piv1PivotalIsomorphism[4] = 1
balancedCategories[TYZ2Z2Cat2Piv2] ^= {TYZ2Z2Cat2Bal2, TYZ2Z2Cat2Bal4, 
    TYZ2Z2Cat2Bal6, TYZ2Z2Cat2Bal8, TYZ2Z2Cat2Bal10, TYZ2Z2Cat2Bal12, 
    TYZ2Z2Cat2Bal14, TYZ2Z2Cat2Bal16}
 
TYZ2Z2Cat2Piv2 /: balancedCategory[TYZ2Z2Cat2Piv2, 1] = TYZ2Z2Cat2Bal2
 
TYZ2Z2Cat2Piv2 /: balancedCategory[TYZ2Z2Cat2Piv2, 2] = TYZ2Z2Cat2Bal4
 
TYZ2Z2Cat2Piv2 /: balancedCategory[TYZ2Z2Cat2Piv2, 3] = TYZ2Z2Cat2Bal6
 
TYZ2Z2Cat2Piv2 /: balancedCategory[TYZ2Z2Cat2Piv2, 4] = TYZ2Z2Cat2Bal8
 
TYZ2Z2Cat2Piv2 /: balancedCategory[TYZ2Z2Cat2Piv2, 5] = TYZ2Z2Cat2Bal10
 
TYZ2Z2Cat2Piv2 /: balancedCategory[TYZ2Z2Cat2Piv2, 6] = TYZ2Z2Cat2Bal12
 
TYZ2Z2Cat2Piv2 /: balancedCategory[TYZ2Z2Cat2Piv2, 7] = TYZ2Z2Cat2Bal14
 
TYZ2Z2Cat2Piv2 /: balancedCategory[TYZ2Z2Cat2Piv2, 8] = TYZ2Z2Cat2Bal16
 
fusionCategory[TYZ2Z2Cat2Piv2] ^= TYZ2Z2Cat2
 
TYZ2Z2Cat2Piv2 /: modularCategory[TYZ2Z2Cat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TYZ2Z2Cat2Piv2] ^= TYZ2Z2Cat2Piv2
 
pivotalIsomorphism[TYZ2Z2Cat2Piv2] ^= TYZ2Z2Cat2Piv2PivotalIsomorphism
 
TYZ2Z2Cat2Piv2 /: ribbonCategory[TYZ2Z2Cat2Piv2, 1] = TYZ2Z2Cat2Bal2
 
TYZ2Z2Cat2Piv2 /: ribbonCategory[TYZ2Z2Cat2Piv2, 2] = TYZ2Z2Cat2Bal4
 
TYZ2Z2Cat2Piv2 /: ribbonCategory[TYZ2Z2Cat2Piv2, 3] = TYZ2Z2Cat2Bal6
 
TYZ2Z2Cat2Piv2 /: ribbonCategory[TYZ2Z2Cat2Piv2, 4] = TYZ2Z2Cat2Bal8
 
TYZ2Z2Cat2Piv2 /: ribbonCategory[TYZ2Z2Cat2Piv2, 5] = TYZ2Z2Cat2Bal10
 
TYZ2Z2Cat2Piv2 /: ribbonCategory[TYZ2Z2Cat2Piv2, 6] = TYZ2Z2Cat2Bal12
 
TYZ2Z2Cat2Piv2 /: ribbonCategory[TYZ2Z2Cat2Piv2, 7] = TYZ2Z2Cat2Bal14
 
TYZ2Z2Cat2Piv2 /: ribbonCategory[TYZ2Z2Cat2Piv2, 8] = TYZ2Z2Cat2Bal16
 
ring[TYZ2Z2Cat2Piv2] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat2Piv2] ^= TYZ2Z2Cat2Piv2
 
(pivotalCategoryIndex[fusionCategory[TYZ2Z2Cat2]][pivotalCategory[#1]] & )[
    TYZ2Z2Cat2Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TYZ2Z2Cat2]][
      sphericalCategory[#1]] & )[TYZ2Z2Cat2Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[TYZ2Z2Cat2Piv2PivotalIsomorphism] ^= TYZ2Z2Cat2
 
pivotalCategory[TYZ2Z2Cat2Piv2PivotalIsomorphism] ^= TYZ2Z2Cat2Piv2
 
pivotalIsomorphism[TYZ2Z2Cat2Piv2PivotalIsomorphism] ^= 
   TYZ2Z2Cat2Piv2PivotalIsomorphism
 
TYZ2Z2Cat2Piv2PivotalIsomorphism[0] = 1
 
TYZ2Z2Cat2Piv2PivotalIsomorphism[1] = 1
 
TYZ2Z2Cat2Piv2PivotalIsomorphism[2] = 1
 
TYZ2Z2Cat2Piv2PivotalIsomorphism[3] = 1
 
TYZ2Z2Cat2Piv2PivotalIsomorphism[4] = -1
balancedCategories[TYZ2Z2Cat3] ^= {TYZ2Z2Cat3Bal1, TYZ2Z2Cat3Bal2, 
    TYZ2Z2Cat3Bal3, TYZ2Z2Cat3Bal4, TYZ2Z2Cat3Bal5, TYZ2Z2Cat3Bal6, 
    TYZ2Z2Cat3Bal7, TYZ2Z2Cat3Bal8, TYZ2Z2Cat3Bal9, TYZ2Z2Cat3Bal10, 
    TYZ2Z2Cat3Bal11, TYZ2Z2Cat3Bal12, TYZ2Z2Cat3Bal13, TYZ2Z2Cat3Bal14, 
    TYZ2Z2Cat3Bal15, TYZ2Z2Cat3Bal16}
 
TYZ2Z2Cat3 /: balancedCategory[TYZ2Z2Cat3, 1] = TYZ2Z2Cat3Bal1
 
TYZ2Z2Cat3 /: balancedCategory[TYZ2Z2Cat3, 2] = TYZ2Z2Cat3Bal2
 
TYZ2Z2Cat3 /: balancedCategory[TYZ2Z2Cat3, 3] = TYZ2Z2Cat3Bal3
 
TYZ2Z2Cat3 /: balancedCategory[TYZ2Z2Cat3, 4] = TYZ2Z2Cat3Bal4
 
TYZ2Z2Cat3 /: balancedCategory[TYZ2Z2Cat3, 5] = TYZ2Z2Cat3Bal5
 
TYZ2Z2Cat3 /: balancedCategory[TYZ2Z2Cat3, 6] = TYZ2Z2Cat3Bal6
 
TYZ2Z2Cat3 /: balancedCategory[TYZ2Z2Cat3, 7] = TYZ2Z2Cat3Bal7
 
TYZ2Z2Cat3 /: balancedCategory[TYZ2Z2Cat3, 8] = TYZ2Z2Cat3Bal8
 
TYZ2Z2Cat3 /: balancedCategory[TYZ2Z2Cat3, 9] = TYZ2Z2Cat3Bal9
 
TYZ2Z2Cat3 /: balancedCategory[TYZ2Z2Cat3, 10] = TYZ2Z2Cat3Bal10
 
TYZ2Z2Cat3 /: balancedCategory[TYZ2Z2Cat3, 11] = TYZ2Z2Cat3Bal11
 
TYZ2Z2Cat3 /: balancedCategory[TYZ2Z2Cat3, 12] = TYZ2Z2Cat3Bal12
 
TYZ2Z2Cat3 /: balancedCategory[TYZ2Z2Cat3, 13] = TYZ2Z2Cat3Bal13
 
TYZ2Z2Cat3 /: balancedCategory[TYZ2Z2Cat3, 14] = TYZ2Z2Cat3Bal14
 
TYZ2Z2Cat3 /: balancedCategory[TYZ2Z2Cat3, 15] = TYZ2Z2Cat3Bal15
 
TYZ2Z2Cat3 /: balancedCategory[TYZ2Z2Cat3, 16] = TYZ2Z2Cat3Bal16
 
braidedCategories[TYZ2Z2Cat3] ^= {TYZ2Z2Cat3Brd1, TYZ2Z2Cat3Brd2, 
    TYZ2Z2Cat3Brd3, TYZ2Z2Cat3Brd4, TYZ2Z2Cat3Brd5, TYZ2Z2Cat3Brd6, 
    TYZ2Z2Cat3Brd7, TYZ2Z2Cat3Brd8}
 
TYZ2Z2Cat3 /: braidedCategory[TYZ2Z2Cat3, 1] = TYZ2Z2Cat3Brd1
 
TYZ2Z2Cat3 /: braidedCategory[TYZ2Z2Cat3, 2] = TYZ2Z2Cat3Brd2
 
TYZ2Z2Cat3 /: braidedCategory[TYZ2Z2Cat3, 3] = TYZ2Z2Cat3Brd3
 
TYZ2Z2Cat3 /: braidedCategory[TYZ2Z2Cat3, 4] = TYZ2Z2Cat3Brd4
 
TYZ2Z2Cat3 /: braidedCategory[TYZ2Z2Cat3, 5] = TYZ2Z2Cat3Brd5
 
TYZ2Z2Cat3 /: braidedCategory[TYZ2Z2Cat3, 6] = TYZ2Z2Cat3Brd6
 
TYZ2Z2Cat3 /: braidedCategory[TYZ2Z2Cat3, 7] = TYZ2Z2Cat3Brd7
 
TYZ2Z2Cat3 /: braidedCategory[TYZ2Z2Cat3, 8] = TYZ2Z2Cat3Brd8
 
coeval[TYZ2Z2Cat3] ^= 1/sixJFunction[TYZ2Z2Cat3][#1, 
      dual[ring[TYZ2Z2Cat3]][#1], #1, #1, 0, 0] & 
 
eval[TYZ2Z2Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TYZ2Z2Cat3] ^= TYZ2Z2Cat3FMatrixFunction
 
fusionCategory[TYZ2Z2Cat3] ^= TYZ2Z2Cat3
 
TYZ2Z2Cat3 /: modularCategory[TYZ2Z2Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TYZ2Z2Cat3] ^= {TYZ2Z2Cat3Piv1, TYZ2Z2Cat3Piv2}
 
TYZ2Z2Cat3 /: pivotalCategory[TYZ2Z2Cat3, 1] = TYZ2Z2Cat3Piv1
 
TYZ2Z2Cat3 /: pivotalCategory[TYZ2Z2Cat3, 2] = TYZ2Z2Cat3Piv2
 
TYZ2Z2Cat3 /: pivotalCategory[TYZ2Z2Cat3, {1, 1, 1, 1, -1}] = TYZ2Z2Cat3Piv2
 
TYZ2Z2Cat3 /: pivotalCategory[TYZ2Z2Cat3, {1, 1, 1, 1, 1}] = TYZ2Z2Cat3Piv1
 
TYZ2Z2Cat3 /: ribbonCategory[TYZ2Z2Cat3, 1] = TYZ2Z2Cat3Bal1
 
TYZ2Z2Cat3 /: ribbonCategory[TYZ2Z2Cat3, 2] = TYZ2Z2Cat3Bal2
 
TYZ2Z2Cat3 /: ribbonCategory[TYZ2Z2Cat3, 3] = TYZ2Z2Cat3Bal3
 
TYZ2Z2Cat3 /: ribbonCategory[TYZ2Z2Cat3, 4] = TYZ2Z2Cat3Bal4
 
TYZ2Z2Cat3 /: ribbonCategory[TYZ2Z2Cat3, 5] = TYZ2Z2Cat3Bal5
 
TYZ2Z2Cat3 /: ribbonCategory[TYZ2Z2Cat3, 6] = TYZ2Z2Cat3Bal6
 
TYZ2Z2Cat3 /: ribbonCategory[TYZ2Z2Cat3, 7] = TYZ2Z2Cat3Bal7
 
TYZ2Z2Cat3 /: ribbonCategory[TYZ2Z2Cat3, 8] = TYZ2Z2Cat3Bal8
 
TYZ2Z2Cat3 /: ribbonCategory[TYZ2Z2Cat3, 9] = TYZ2Z2Cat3Bal9
 
TYZ2Z2Cat3 /: ribbonCategory[TYZ2Z2Cat3, 10] = TYZ2Z2Cat3Bal10
 
TYZ2Z2Cat3 /: ribbonCategory[TYZ2Z2Cat3, 11] = TYZ2Z2Cat3Bal11
 
TYZ2Z2Cat3 /: ribbonCategory[TYZ2Z2Cat3, 12] = TYZ2Z2Cat3Bal12
 
TYZ2Z2Cat3 /: ribbonCategory[TYZ2Z2Cat3, 13] = TYZ2Z2Cat3Bal13
 
TYZ2Z2Cat3 /: ribbonCategory[TYZ2Z2Cat3, 14] = TYZ2Z2Cat3Bal14
 
TYZ2Z2Cat3 /: ribbonCategory[TYZ2Z2Cat3, 15] = TYZ2Z2Cat3Bal15
 
TYZ2Z2Cat3 /: ribbonCategory[TYZ2Z2Cat3, 16] = TYZ2Z2Cat3Bal16
 
ring[TYZ2Z2Cat3] ^= TYZ2Z2
 
TYZ2Z2Cat3 /: sphericalCategory[TYZ2Z2Cat3, 1] = TYZ2Z2Cat3Piv1
 
TYZ2Z2Cat3 /: sphericalCategory[TYZ2Z2Cat3, 2] = TYZ2Z2Cat3Piv2
 
TYZ2Z2Cat3 /: symmetricCategory[TYZ2Z2Cat3, 1] = TYZ2Z2Cat3Brd1
 
TYZ2Z2Cat3 /: symmetricCategory[TYZ2Z2Cat3, 2] = TYZ2Z2Cat3Brd4
 
TYZ2Z2Cat3 /: symmetricCategory[TYZ2Z2Cat3, 3] = TYZ2Z2Cat3Brd5
 
TYZ2Z2Cat3 /: symmetricCategory[TYZ2Z2Cat3, 4] = TYZ2Z2Cat3Brd6
 
TYZ2Z2Cat3 /: symmetricCategory[TYZ2Z2Cat3, 5] = TYZ2Z2Cat3Brd7
 
TYZ2Z2Cat3 /: symmetricCategory[TYZ2Z2Cat3, 6] = TYZ2Z2Cat3Brd8
 
fusionCategoryIndex[TYZ2Z2][TYZ2Z2Cat3] ^= 3
balancedCategory[TYZ2Z2Cat3Bal1] ^= TYZ2Z2Cat3Bal1
 
braidedCategory[TYZ2Z2Cat3Bal1] ^= TYZ2Z2Cat3Brd1
 
fusionCategory[TYZ2Z2Cat3Bal1] ^= TYZ2Z2Cat3
 
pivotalCategory[TYZ2Z2Cat3Bal1] ^= TYZ2Z2Cat3Piv1
 
ribbonCategory[TYZ2Z2Cat3Bal1] ^= TYZ2Z2Cat3Bal1
 
ring[TYZ2Z2Cat3Bal1] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat3Bal1] ^= TYZ2Z2Cat3Piv1
 
symmetricCategory[TYZ2Z2Cat3Bal1] ^= TYZ2Z2Cat3Brd1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][balancedCategory[#1]] & )[
    TYZ2Z2Cat3Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat3Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat3Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat3Bal1] ^= 1
balancedCategory[TYZ2Z2Cat3Bal10] ^= TYZ2Z2Cat3Bal10
 
braidedCategory[TYZ2Z2Cat3Bal10] ^= TYZ2Z2Cat3Brd5
 
fusionCategory[TYZ2Z2Cat3Bal10] ^= TYZ2Z2Cat3
 
pivotalCategory[TYZ2Z2Cat3Bal10] ^= TYZ2Z2Cat3Piv2
 
ribbonCategory[TYZ2Z2Cat3Bal10] ^= TYZ2Z2Cat3Bal10
 
ring[TYZ2Z2Cat3Bal10] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat3Bal10] ^= TYZ2Z2Cat3Piv2
 
symmetricCategory[TYZ2Z2Cat3Bal10] ^= TYZ2Z2Cat3Brd5
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd5]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal10] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][balancedCategory[#1]] & )[
    TYZ2Z2Cat3Bal10] ^= 10
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat3Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal10] ^= 5
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd5]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal10] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal10] ^= 10
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat3Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat3Bal10] ^= 5
balancedCategory[TYZ2Z2Cat3Bal11] ^= TYZ2Z2Cat3Bal11
 
braidedCategory[TYZ2Z2Cat3Bal11] ^= TYZ2Z2Cat3Brd6
 
fusionCategory[TYZ2Z2Cat3Bal11] ^= TYZ2Z2Cat3
 
pivotalCategory[TYZ2Z2Cat3Bal11] ^= TYZ2Z2Cat3Piv1
 
ribbonCategory[TYZ2Z2Cat3Bal11] ^= TYZ2Z2Cat3Bal11
 
ring[TYZ2Z2Cat3Bal11] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat3Bal11] ^= TYZ2Z2Cat3Piv1
 
symmetricCategory[TYZ2Z2Cat3Bal11] ^= TYZ2Z2Cat3Brd6
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd6]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal11] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][balancedCategory[#1]] & )[
    TYZ2Z2Cat3Bal11] ^= 11
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat3Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal11] ^= 6
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd6]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal11] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal11] ^= 11
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat3Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat3Bal11] ^= 6
balancedCategory[TYZ2Z2Cat3Bal12] ^= TYZ2Z2Cat3Bal12
 
braidedCategory[TYZ2Z2Cat3Bal12] ^= TYZ2Z2Cat3Brd6
 
fusionCategory[TYZ2Z2Cat3Bal12] ^= TYZ2Z2Cat3
 
pivotalCategory[TYZ2Z2Cat3Bal12] ^= TYZ2Z2Cat3Piv2
 
ribbonCategory[TYZ2Z2Cat3Bal12] ^= TYZ2Z2Cat3Bal12
 
ring[TYZ2Z2Cat3Bal12] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat3Bal12] ^= TYZ2Z2Cat3Piv2
 
symmetricCategory[TYZ2Z2Cat3Bal12] ^= TYZ2Z2Cat3Brd6
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd6]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal12] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][balancedCategory[#1]] & )[
    TYZ2Z2Cat3Bal12] ^= 12
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat3Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal12] ^= 6
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd6]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal12] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal12] ^= 12
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat3Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat3Bal12] ^= 6
balancedCategory[TYZ2Z2Cat3Bal13] ^= TYZ2Z2Cat3Bal13
 
braidedCategory[TYZ2Z2Cat3Bal13] ^= TYZ2Z2Cat3Brd7
 
fusionCategory[TYZ2Z2Cat3Bal13] ^= TYZ2Z2Cat3
 
pivotalCategory[TYZ2Z2Cat3Bal13] ^= TYZ2Z2Cat3Piv1
 
ribbonCategory[TYZ2Z2Cat3Bal13] ^= TYZ2Z2Cat3Bal13
 
ring[TYZ2Z2Cat3Bal13] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat3Bal13] ^= TYZ2Z2Cat3Piv1
 
symmetricCategory[TYZ2Z2Cat3Bal13] ^= TYZ2Z2Cat3Brd7
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd7]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal13] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][balancedCategory[#1]] & )[
    TYZ2Z2Cat3Bal13] ^= 13
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat3Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal13] ^= 7
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd7]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal13] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal13] ^= 13
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat3Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat3Bal13] ^= 7
balancedCategory[TYZ2Z2Cat3Bal14] ^= TYZ2Z2Cat3Bal14
 
braidedCategory[TYZ2Z2Cat3Bal14] ^= TYZ2Z2Cat3Brd7
 
fusionCategory[TYZ2Z2Cat3Bal14] ^= TYZ2Z2Cat3
 
pivotalCategory[TYZ2Z2Cat3Bal14] ^= TYZ2Z2Cat3Piv2
 
ribbonCategory[TYZ2Z2Cat3Bal14] ^= TYZ2Z2Cat3Bal14
 
ring[TYZ2Z2Cat3Bal14] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat3Bal14] ^= TYZ2Z2Cat3Piv2
 
symmetricCategory[TYZ2Z2Cat3Bal14] ^= TYZ2Z2Cat3Brd7
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd7]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal14] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][balancedCategory[#1]] & )[
    TYZ2Z2Cat3Bal14] ^= 14
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat3Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal14] ^= 7
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd7]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal14] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal14] ^= 14
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat3Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat3Bal14] ^= 7
balancedCategory[TYZ2Z2Cat3Bal15] ^= TYZ2Z2Cat3Bal15
 
braidedCategory[TYZ2Z2Cat3Bal15] ^= TYZ2Z2Cat3Brd8
 
fusionCategory[TYZ2Z2Cat3Bal15] ^= TYZ2Z2Cat3
 
pivotalCategory[TYZ2Z2Cat3Bal15] ^= TYZ2Z2Cat3Piv1
 
ribbonCategory[TYZ2Z2Cat3Bal15] ^= TYZ2Z2Cat3Bal15
 
ring[TYZ2Z2Cat3Bal15] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat3Bal15] ^= TYZ2Z2Cat3Piv1
 
symmetricCategory[TYZ2Z2Cat3Bal15] ^= TYZ2Z2Cat3Brd8
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd8]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal15] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][balancedCategory[#1]] & )[
    TYZ2Z2Cat3Bal15] ^= 15
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat3Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal15] ^= 8
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd8]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal15] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal15] ^= 15
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat3Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat3Bal15] ^= 8
balancedCategory[TYZ2Z2Cat3Bal16] ^= TYZ2Z2Cat3Bal16
 
braidedCategory[TYZ2Z2Cat3Bal16] ^= TYZ2Z2Cat3Brd8
 
fusionCategory[TYZ2Z2Cat3Bal16] ^= TYZ2Z2Cat3
 
pivotalCategory[TYZ2Z2Cat3Bal16] ^= TYZ2Z2Cat3Piv2
 
ribbonCategory[TYZ2Z2Cat3Bal16] ^= TYZ2Z2Cat3Bal16
 
ring[TYZ2Z2Cat3Bal16] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat3Bal16] ^= TYZ2Z2Cat3Piv2
 
symmetricCategory[TYZ2Z2Cat3Bal16] ^= TYZ2Z2Cat3Brd8
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd8]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal16] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][balancedCategory[#1]] & )[
    TYZ2Z2Cat3Bal16] ^= 16
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat3Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal16] ^= 8
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd8]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal16] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal16] ^= 16
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat3Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat3Bal16] ^= 8
balancedCategory[TYZ2Z2Cat3Bal2] ^= TYZ2Z2Cat3Bal2
 
braidedCategory[TYZ2Z2Cat3Bal2] ^= TYZ2Z2Cat3Brd1
 
fusionCategory[TYZ2Z2Cat3Bal2] ^= TYZ2Z2Cat3
 
pivotalCategory[TYZ2Z2Cat3Bal2] ^= TYZ2Z2Cat3Piv2
 
ribbonCategory[TYZ2Z2Cat3Bal2] ^= TYZ2Z2Cat3Bal2
 
ring[TYZ2Z2Cat3Bal2] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat3Bal2] ^= TYZ2Z2Cat3Piv2
 
symmetricCategory[TYZ2Z2Cat3Bal2] ^= TYZ2Z2Cat3Brd1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][balancedCategory[#1]] & )[
    TYZ2Z2Cat3Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat3Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat3Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat3Bal2] ^= 1
balancedCategory[TYZ2Z2Cat3Bal3] ^= TYZ2Z2Cat3Bal3
 
braidedCategory[TYZ2Z2Cat3Bal3] ^= TYZ2Z2Cat3Brd2
 
fusionCategory[TYZ2Z2Cat3Bal3] ^= TYZ2Z2Cat3
 
pivotalCategory[TYZ2Z2Cat3Bal3] ^= TYZ2Z2Cat3Piv1
 
ribbonCategory[TYZ2Z2Cat3Bal3] ^= TYZ2Z2Cat3Bal3
 
ring[TYZ2Z2Cat3Bal3] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat3Bal3] ^= TYZ2Z2Cat3Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][balancedCategory[#1]] & )[
    TYZ2Z2Cat3Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat3Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat3Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat3Bal3] ^= 2
balancedCategory[TYZ2Z2Cat3Bal4] ^= TYZ2Z2Cat3Bal4
 
braidedCategory[TYZ2Z2Cat3Bal4] ^= TYZ2Z2Cat3Brd2
 
fusionCategory[TYZ2Z2Cat3Bal4] ^= TYZ2Z2Cat3
 
pivotalCategory[TYZ2Z2Cat3Bal4] ^= TYZ2Z2Cat3Piv2
 
ribbonCategory[TYZ2Z2Cat3Bal4] ^= TYZ2Z2Cat3Bal4
 
ring[TYZ2Z2Cat3Bal4] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat3Bal4] ^= TYZ2Z2Cat3Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][balancedCategory[#1]] & )[
    TYZ2Z2Cat3Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat3Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat3Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat3Bal4] ^= 2
balancedCategory[TYZ2Z2Cat3Bal5] ^= TYZ2Z2Cat3Bal5
 
braidedCategory[TYZ2Z2Cat3Bal5] ^= TYZ2Z2Cat3Brd3
 
fusionCategory[TYZ2Z2Cat3Bal5] ^= TYZ2Z2Cat3
 
pivotalCategory[TYZ2Z2Cat3Bal5] ^= TYZ2Z2Cat3Piv1
 
ribbonCategory[TYZ2Z2Cat3Bal5] ^= TYZ2Z2Cat3Bal5
 
ring[TYZ2Z2Cat3Bal5] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat3Bal5] ^= TYZ2Z2Cat3Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd3]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][balancedCategory[#1]] & )[
    TYZ2Z2Cat3Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat3Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal5] ^= 3
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat3Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat3Bal5] ^= 3
balancedCategory[TYZ2Z2Cat3Bal6] ^= TYZ2Z2Cat3Bal6
 
braidedCategory[TYZ2Z2Cat3Bal6] ^= TYZ2Z2Cat3Brd3
 
fusionCategory[TYZ2Z2Cat3Bal6] ^= TYZ2Z2Cat3
 
pivotalCategory[TYZ2Z2Cat3Bal6] ^= TYZ2Z2Cat3Piv2
 
ribbonCategory[TYZ2Z2Cat3Bal6] ^= TYZ2Z2Cat3Bal6
 
ring[TYZ2Z2Cat3Bal6] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat3Bal6] ^= TYZ2Z2Cat3Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd3]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][balancedCategory[#1]] & )[
    TYZ2Z2Cat3Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat3Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal6] ^= 3
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat3Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat3Bal6] ^= 3
balancedCategory[TYZ2Z2Cat3Bal7] ^= TYZ2Z2Cat3Bal7
 
braidedCategory[TYZ2Z2Cat3Bal7] ^= TYZ2Z2Cat3Brd4
 
fusionCategory[TYZ2Z2Cat3Bal7] ^= TYZ2Z2Cat3
 
pivotalCategory[TYZ2Z2Cat3Bal7] ^= TYZ2Z2Cat3Piv1
 
ribbonCategory[TYZ2Z2Cat3Bal7] ^= TYZ2Z2Cat3Bal7
 
ring[TYZ2Z2Cat3Bal7] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat3Bal7] ^= TYZ2Z2Cat3Piv1
 
symmetricCategory[TYZ2Z2Cat3Bal7] ^= TYZ2Z2Cat3Brd4
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd4]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][balancedCategory[#1]] & )[
    TYZ2Z2Cat3Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat3Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal7] ^= 4
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat3Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat3Bal7] ^= 4
balancedCategory[TYZ2Z2Cat3Bal8] ^= TYZ2Z2Cat3Bal8
 
braidedCategory[TYZ2Z2Cat3Bal8] ^= TYZ2Z2Cat3Brd4
 
fusionCategory[TYZ2Z2Cat3Bal8] ^= TYZ2Z2Cat3
 
pivotalCategory[TYZ2Z2Cat3Bal8] ^= TYZ2Z2Cat3Piv2
 
ribbonCategory[TYZ2Z2Cat3Bal8] ^= TYZ2Z2Cat3Bal8
 
ring[TYZ2Z2Cat3Bal8] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat3Bal8] ^= TYZ2Z2Cat3Piv2
 
symmetricCategory[TYZ2Z2Cat3Bal8] ^= TYZ2Z2Cat3Brd4
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd4]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][balancedCategory[#1]] & )[
    TYZ2Z2Cat3Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat3Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal8] ^= 4
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat3Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat3Bal8] ^= 4
balancedCategory[TYZ2Z2Cat3Bal9] ^= TYZ2Z2Cat3Bal9
 
braidedCategory[TYZ2Z2Cat3Bal9] ^= TYZ2Z2Cat3Brd5
 
fusionCategory[TYZ2Z2Cat3Bal9] ^= TYZ2Z2Cat3
 
pivotalCategory[TYZ2Z2Cat3Bal9] ^= TYZ2Z2Cat3Piv1
 
ribbonCategory[TYZ2Z2Cat3Bal9] ^= TYZ2Z2Cat3Bal9
 
ring[TYZ2Z2Cat3Bal9] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat3Bal9] ^= TYZ2Z2Cat3Piv1
 
symmetricCategory[TYZ2Z2Cat3Bal9] ^= TYZ2Z2Cat3Brd5
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd5]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal9] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][balancedCategory[#1]] & )[
    TYZ2Z2Cat3Bal9] ^= 9
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat3Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat3Bal9] ^= 5
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat3Brd5]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal9] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat3Bal9] ^= 9
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat3Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat3Bal9] ^= 5
balancedCategories[TYZ2Z2Cat3Brd1] ^= {TYZ2Z2Cat3Bal1, TYZ2Z2Cat3Bal2}
 
TYZ2Z2Cat3Brd1 /: balancedCategory[TYZ2Z2Cat3Brd1, 1] = TYZ2Z2Cat3Bal1
 
TYZ2Z2Cat3Brd1 /: balancedCategory[TYZ2Z2Cat3Brd1, 2] = TYZ2Z2Cat3Bal2
 
braidedCategory[TYZ2Z2Cat3Brd1] ^= TYZ2Z2Cat3Brd1
 
fusionCategory[TYZ2Z2Cat3Brd1] ^= TYZ2Z2Cat3
 
TYZ2Z2Cat3Brd1 /: modularCategory[TYZ2Z2Cat3Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat3Brd1 /: ribbonCategory[TYZ2Z2Cat3Brd1, 1] = TYZ2Z2Cat3Bal1
 
TYZ2Z2Cat3Brd1 /: ribbonCategory[TYZ2Z2Cat3Brd1, 2] = TYZ2Z2Cat3Bal2
 
ring[TYZ2Z2Cat3Brd1] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat3Brd1] ^= TYZ2Z2Cat3Brd1RMatrixFunction
 
symmetricCategory[TYZ2Z2Cat3Brd1] ^= TYZ2Z2Cat3Brd1
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][braidedCategory[#1]] & )[
    TYZ2Z2Cat3Brd1] ^= 1
 
(symmetricCategoryIndex[fusionCategory[TYZ2Z2Cat3]][
      symmetricCategory[#1]] & )[TYZ2Z2Cat3Brd1] ^= 1
braidedCategory[TYZ2Z2Cat3Brd1RMatrixFunction] ^= TYZ2Z2Cat3Brd1
 
fusionCategory[TYZ2Z2Cat3Brd1RMatrixFunction] ^= TYZ2Z2Cat3
 
rMatrixFunction[TYZ2Z2Cat3Brd1RMatrixFunction] ^= 
   TYZ2Z2Cat3Brd1RMatrixFunction
 
TYZ2Z2Cat3Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[1, 1, 0] = {{1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[1, 4, 4] = {{-1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[2, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[3, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[4, 1, 4] = {{-1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[4, 2, 4] = {{1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[4, 3, 4] = {{1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[4, 4, 0] = {{-1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[4, 4, 1] = {{1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[4, 4, 2] = {{-1}}
 
TYZ2Z2Cat3Brd1RMatrixFunction[4, 4, 3] = {{-1}}
balancedCategories[TYZ2Z2Cat3Brd2] ^= {TYZ2Z2Cat3Bal3, TYZ2Z2Cat3Bal4}
 
TYZ2Z2Cat3Brd2 /: balancedCategory[TYZ2Z2Cat3Brd2, 1] = TYZ2Z2Cat3Bal3
 
TYZ2Z2Cat3Brd2 /: balancedCategory[TYZ2Z2Cat3Brd2, 2] = TYZ2Z2Cat3Bal4
 
braidedCategory[TYZ2Z2Cat3Brd2] ^= TYZ2Z2Cat3Brd2
 
fusionCategory[TYZ2Z2Cat3Brd2] ^= TYZ2Z2Cat3
 
TYZ2Z2Cat3Brd2 /: modularCategory[TYZ2Z2Cat3Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat3Brd2 /: ribbonCategory[TYZ2Z2Cat3Brd2, 1] = TYZ2Z2Cat3Bal3
 
TYZ2Z2Cat3Brd2 /: ribbonCategory[TYZ2Z2Cat3Brd2, 2] = TYZ2Z2Cat3Bal4
 
ring[TYZ2Z2Cat3Brd2] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat3Brd2] ^= TYZ2Z2Cat3Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][braidedCategory[#1]] & )[
    TYZ2Z2Cat3Brd2] ^= 2
braidedCategory[TYZ2Z2Cat3Brd2RMatrixFunction] ^= TYZ2Z2Cat3Brd2
 
fusionCategory[TYZ2Z2Cat3Brd2RMatrixFunction] ^= TYZ2Z2Cat3
 
rMatrixFunction[TYZ2Z2Cat3Brd2RMatrixFunction] ^= 
   TYZ2Z2Cat3Brd2RMatrixFunction
 
TYZ2Z2Cat3Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[1, 1, 0] = {{1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[1, 4, 4] = {{-1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[2, 4, 4] = {{-1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[3, 4, 4] = {{-1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[4, 1, 4] = {{-1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[4, 2, 4] = {{-1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[4, 3, 4] = {{-1}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[4, 4, 0] = {{-I}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[4, 4, 1] = {{I}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[4, 4, 2] = {{I}}
 
TYZ2Z2Cat3Brd2RMatrixFunction[4, 4, 3] = {{I}}
balancedCategories[TYZ2Z2Cat3Brd3] ^= {TYZ2Z2Cat3Bal5, TYZ2Z2Cat3Bal6}
 
TYZ2Z2Cat3Brd3 /: balancedCategory[TYZ2Z2Cat3Brd3, 1] = TYZ2Z2Cat3Bal5
 
TYZ2Z2Cat3Brd3 /: balancedCategory[TYZ2Z2Cat3Brd3, 2] = TYZ2Z2Cat3Bal6
 
braidedCategory[TYZ2Z2Cat3Brd3] ^= TYZ2Z2Cat3Brd3
 
fusionCategory[TYZ2Z2Cat3Brd3] ^= TYZ2Z2Cat3
 
TYZ2Z2Cat3Brd3 /: modularCategory[TYZ2Z2Cat3Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat3Brd3 /: ribbonCategory[TYZ2Z2Cat3Brd3, 1] = TYZ2Z2Cat3Bal5
 
TYZ2Z2Cat3Brd3 /: ribbonCategory[TYZ2Z2Cat3Brd3, 2] = TYZ2Z2Cat3Bal6
 
ring[TYZ2Z2Cat3Brd3] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat3Brd3] ^= TYZ2Z2Cat3Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][braidedCategory[#1]] & )[
    TYZ2Z2Cat3Brd3] ^= 3
braidedCategory[TYZ2Z2Cat3Brd3RMatrixFunction] ^= TYZ2Z2Cat3Brd3
 
fusionCategory[TYZ2Z2Cat3Brd3RMatrixFunction] ^= TYZ2Z2Cat3
 
rMatrixFunction[TYZ2Z2Cat3Brd3RMatrixFunction] ^= 
   TYZ2Z2Cat3Brd3RMatrixFunction
 
TYZ2Z2Cat3Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[1, 1, 0] = {{1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[1, 4, 4] = {{-1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[2, 4, 4] = {{-1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[3, 4, 4] = {{-1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[4, 1, 4] = {{-1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[4, 2, 4] = {{-1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[4, 3, 4] = {{-1}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[4, 4, 0] = {{I}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[4, 4, 1] = {{-I}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[4, 4, 2] = {{-I}}
 
TYZ2Z2Cat3Brd3RMatrixFunction[4, 4, 3] = {{-I}}
balancedCategories[TYZ2Z2Cat3Brd4] ^= {TYZ2Z2Cat3Bal7, TYZ2Z2Cat3Bal8}
 
TYZ2Z2Cat3Brd4 /: balancedCategory[TYZ2Z2Cat3Brd4, 1] = TYZ2Z2Cat3Bal7
 
TYZ2Z2Cat3Brd4 /: balancedCategory[TYZ2Z2Cat3Brd4, 2] = TYZ2Z2Cat3Bal8
 
braidedCategory[TYZ2Z2Cat3Brd4] ^= TYZ2Z2Cat3Brd4
 
fusionCategory[TYZ2Z2Cat3Brd4] ^= TYZ2Z2Cat3
 
TYZ2Z2Cat3Brd4 /: modularCategory[TYZ2Z2Cat3Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat3Brd4 /: ribbonCategory[TYZ2Z2Cat3Brd4, 1] = TYZ2Z2Cat3Bal7
 
TYZ2Z2Cat3Brd4 /: ribbonCategory[TYZ2Z2Cat3Brd4, 2] = TYZ2Z2Cat3Bal8
 
ring[TYZ2Z2Cat3Brd4] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat3Brd4] ^= TYZ2Z2Cat3Brd4RMatrixFunction
 
symmetricCategory[TYZ2Z2Cat3Brd4] ^= TYZ2Z2Cat3Brd4
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][braidedCategory[#1]] & )[
    TYZ2Z2Cat3Brd4] ^= 4
 
(symmetricCategoryIndex[fusionCategory[TYZ2Z2Cat3]][
      symmetricCategory[#1]] & )[TYZ2Z2Cat3Brd4] ^= 2
braidedCategory[TYZ2Z2Cat3Brd4RMatrixFunction] ^= TYZ2Z2Cat3Brd4
 
fusionCategory[TYZ2Z2Cat3Brd4RMatrixFunction] ^= TYZ2Z2Cat3
 
rMatrixFunction[TYZ2Z2Cat3Brd4RMatrixFunction] ^= 
   TYZ2Z2Cat3Brd4RMatrixFunction
 
TYZ2Z2Cat3Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[1, 1, 0] = {{1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[1, 4, 4] = {{-1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[2, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[3, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[4, 1, 4] = {{-1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[4, 2, 4] = {{1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[4, 3, 4] = {{1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[4, 4, 0] = {{1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[4, 4, 1] = {{-1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[4, 4, 2] = {{1}}
 
TYZ2Z2Cat3Brd4RMatrixFunction[4, 4, 3] = {{1}}
balancedCategories[TYZ2Z2Cat3Brd5] ^= {TYZ2Z2Cat3Bal9, TYZ2Z2Cat3Bal10}
 
TYZ2Z2Cat3Brd5 /: balancedCategory[TYZ2Z2Cat3Brd5, 1] = TYZ2Z2Cat3Bal9
 
TYZ2Z2Cat3Brd5 /: balancedCategory[TYZ2Z2Cat3Brd5, 2] = TYZ2Z2Cat3Bal10
 
braidedCategory[TYZ2Z2Cat3Brd5] ^= TYZ2Z2Cat3Brd5
 
fusionCategory[TYZ2Z2Cat3Brd5] ^= TYZ2Z2Cat3
 
TYZ2Z2Cat3Brd5 /: modularCategory[TYZ2Z2Cat3Brd5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat3Brd5 /: ribbonCategory[TYZ2Z2Cat3Brd5, 1] = TYZ2Z2Cat3Bal9
 
TYZ2Z2Cat3Brd5 /: ribbonCategory[TYZ2Z2Cat3Brd5, 2] = TYZ2Z2Cat3Bal10
 
ring[TYZ2Z2Cat3Brd5] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat3Brd5] ^= TYZ2Z2Cat3Brd5RMatrixFunction
 
symmetricCategory[TYZ2Z2Cat3Brd5] ^= TYZ2Z2Cat3Brd5
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][braidedCategory[#1]] & )[
    TYZ2Z2Cat3Brd5] ^= 5
 
(symmetricCategoryIndex[fusionCategory[TYZ2Z2Cat3]][
      symmetricCategory[#1]] & )[TYZ2Z2Cat3Brd5] ^= 3
braidedCategory[TYZ2Z2Cat3Brd5RMatrixFunction] ^= TYZ2Z2Cat3Brd5
 
fusionCategory[TYZ2Z2Cat3Brd5RMatrixFunction] ^= TYZ2Z2Cat3
 
rMatrixFunction[TYZ2Z2Cat3Brd5RMatrixFunction] ^= 
   TYZ2Z2Cat3Brd5RMatrixFunction
 
TYZ2Z2Cat3Brd5RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[1, 1, 0] = {{1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[1, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[2, 4, 4] = {{-1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[3, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[4, 1, 4] = {{1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[4, 2, 4] = {{-1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[4, 3, 4] = {{1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[4, 4, 0] = {{-1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[4, 4, 1] = {{-1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[4, 4, 2] = {{1}}
 
TYZ2Z2Cat3Brd5RMatrixFunction[4, 4, 3] = {{-1}}
balancedCategories[TYZ2Z2Cat3Brd6] ^= {TYZ2Z2Cat3Bal11, TYZ2Z2Cat3Bal12}
 
TYZ2Z2Cat3Brd6 /: balancedCategory[TYZ2Z2Cat3Brd6, 1] = TYZ2Z2Cat3Bal11
 
TYZ2Z2Cat3Brd6 /: balancedCategory[TYZ2Z2Cat3Brd6, 2] = TYZ2Z2Cat3Bal12
 
braidedCategory[TYZ2Z2Cat3Brd6] ^= TYZ2Z2Cat3Brd6
 
fusionCategory[TYZ2Z2Cat3Brd6] ^= TYZ2Z2Cat3
 
TYZ2Z2Cat3Brd6 /: modularCategory[TYZ2Z2Cat3Brd6, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat3Brd6 /: ribbonCategory[TYZ2Z2Cat3Brd6, 1] = TYZ2Z2Cat3Bal11
 
TYZ2Z2Cat3Brd6 /: ribbonCategory[TYZ2Z2Cat3Brd6, 2] = TYZ2Z2Cat3Bal12
 
ring[TYZ2Z2Cat3Brd6] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat3Brd6] ^= TYZ2Z2Cat3Brd6RMatrixFunction
 
symmetricCategory[TYZ2Z2Cat3Brd6] ^= TYZ2Z2Cat3Brd6
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][braidedCategory[#1]] & )[
    TYZ2Z2Cat3Brd6] ^= 6
 
(symmetricCategoryIndex[fusionCategory[TYZ2Z2Cat3]][
      symmetricCategory[#1]] & )[TYZ2Z2Cat3Brd6] ^= 4
braidedCategory[TYZ2Z2Cat3Brd6RMatrixFunction] ^= TYZ2Z2Cat3Brd6
 
fusionCategory[TYZ2Z2Cat3Brd6RMatrixFunction] ^= TYZ2Z2Cat3
 
rMatrixFunction[TYZ2Z2Cat3Brd6RMatrixFunction] ^= 
   TYZ2Z2Cat3Brd6RMatrixFunction
 
TYZ2Z2Cat3Brd6RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[1, 1, 0] = {{1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[1, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[2, 4, 4] = {{-1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[3, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[4, 1, 4] = {{1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[4, 2, 4] = {{-1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[4, 3, 4] = {{1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[4, 4, 0] = {{1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[4, 4, 1] = {{1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[4, 4, 2] = {{-1}}
 
TYZ2Z2Cat3Brd6RMatrixFunction[4, 4, 3] = {{1}}
balancedCategories[TYZ2Z2Cat3Brd7] ^= {TYZ2Z2Cat3Bal13, TYZ2Z2Cat3Bal14}
 
TYZ2Z2Cat3Brd7 /: balancedCategory[TYZ2Z2Cat3Brd7, 1] = TYZ2Z2Cat3Bal13
 
TYZ2Z2Cat3Brd7 /: balancedCategory[TYZ2Z2Cat3Brd7, 2] = TYZ2Z2Cat3Bal14
 
braidedCategory[TYZ2Z2Cat3Brd7] ^= TYZ2Z2Cat3Brd7
 
fusionCategory[TYZ2Z2Cat3Brd7] ^= TYZ2Z2Cat3
 
TYZ2Z2Cat3Brd7 /: modularCategory[TYZ2Z2Cat3Brd7, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat3Brd7 /: ribbonCategory[TYZ2Z2Cat3Brd7, 1] = TYZ2Z2Cat3Bal13
 
TYZ2Z2Cat3Brd7 /: ribbonCategory[TYZ2Z2Cat3Brd7, 2] = TYZ2Z2Cat3Bal14
 
ring[TYZ2Z2Cat3Brd7] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat3Brd7] ^= TYZ2Z2Cat3Brd7RMatrixFunction
 
symmetricCategory[TYZ2Z2Cat3Brd7] ^= TYZ2Z2Cat3Brd7
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][braidedCategory[#1]] & )[
    TYZ2Z2Cat3Brd7] ^= 7
 
(symmetricCategoryIndex[fusionCategory[TYZ2Z2Cat3]][
      symmetricCategory[#1]] & )[TYZ2Z2Cat3Brd7] ^= 5
braidedCategory[TYZ2Z2Cat3Brd7RMatrixFunction] ^= TYZ2Z2Cat3Brd7
 
fusionCategory[TYZ2Z2Cat3Brd7RMatrixFunction] ^= TYZ2Z2Cat3
 
rMatrixFunction[TYZ2Z2Cat3Brd7RMatrixFunction] ^= 
   TYZ2Z2Cat3Brd7RMatrixFunction
 
TYZ2Z2Cat3Brd7RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[1, 1, 0] = {{1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[1, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[2, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[3, 4, 4] = {{-1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[4, 1, 4] = {{1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[4, 2, 4] = {{1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[4, 3, 4] = {{-1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[4, 4, 0] = {{-1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[4, 4, 1] = {{-1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[4, 4, 2] = {{-1}}
 
TYZ2Z2Cat3Brd7RMatrixFunction[4, 4, 3] = {{1}}
balancedCategories[TYZ2Z2Cat3Brd8] ^= {TYZ2Z2Cat3Bal15, TYZ2Z2Cat3Bal16}
 
TYZ2Z2Cat3Brd8 /: balancedCategory[TYZ2Z2Cat3Brd8, 1] = TYZ2Z2Cat3Bal15
 
TYZ2Z2Cat3Brd8 /: balancedCategory[TYZ2Z2Cat3Brd8, 2] = TYZ2Z2Cat3Bal16
 
braidedCategory[TYZ2Z2Cat3Brd8] ^= TYZ2Z2Cat3Brd8
 
fusionCategory[TYZ2Z2Cat3Brd8] ^= TYZ2Z2Cat3
 
TYZ2Z2Cat3Brd8 /: modularCategory[TYZ2Z2Cat3Brd8, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat3Brd8 /: ribbonCategory[TYZ2Z2Cat3Brd8, 1] = TYZ2Z2Cat3Bal15
 
TYZ2Z2Cat3Brd8 /: ribbonCategory[TYZ2Z2Cat3Brd8, 2] = TYZ2Z2Cat3Bal16
 
ring[TYZ2Z2Cat3Brd8] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat3Brd8] ^= TYZ2Z2Cat3Brd8RMatrixFunction
 
symmetricCategory[TYZ2Z2Cat3Brd8] ^= TYZ2Z2Cat3Brd8
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat3]][braidedCategory[#1]] & )[
    TYZ2Z2Cat3Brd8] ^= 8
 
(symmetricCategoryIndex[fusionCategory[TYZ2Z2Cat3]][
      symmetricCategory[#1]] & )[TYZ2Z2Cat3Brd8] ^= 6
braidedCategory[TYZ2Z2Cat3Brd8RMatrixFunction] ^= TYZ2Z2Cat3Brd8
 
fusionCategory[TYZ2Z2Cat3Brd8RMatrixFunction] ^= TYZ2Z2Cat3
 
rMatrixFunction[TYZ2Z2Cat3Brd8RMatrixFunction] ^= 
   TYZ2Z2Cat3Brd8RMatrixFunction
 
TYZ2Z2Cat3Brd8RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[1, 1, 0] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[1, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[2, 4, 4] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[3, 4, 4] = {{-1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[4, 1, 4] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[4, 2, 4] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[4, 3, 4] = {{-1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[4, 4, 0] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[4, 4, 1] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[4, 4, 2] = {{1}}
 
TYZ2Z2Cat3Brd8RMatrixFunction[4, 4, 3] = {{-1}}
fMatrixFunction[TYZ2Z2Cat3FMatrixFunction] ^= TYZ2Z2Cat3FMatrixFunction
 
fusionCategory[TYZ2Z2Cat3FMatrixFunction] ^= TYZ2Z2Cat3
 
ring[TYZ2Z2Cat3FMatrixFunction] ^= TYZ2Z2
 
TYZ2Z2Cat3FMatrixFunction[1, 4, 2, 4] = {{-1}}
 
TYZ2Z2Cat3FMatrixFunction[1, 4, 3, 4] = {{-1}}
 
TYZ2Z2Cat3FMatrixFunction[2, 4, 1, 4] = {{-1}}
 
TYZ2Z2Cat3FMatrixFunction[2, 4, 3, 4] = {{-1}}
 
TYZ2Z2Cat3FMatrixFunction[3, 4, 1, 4] = {{-1}}
 
TYZ2Z2Cat3FMatrixFunction[3, 4, 2, 4] = {{-1}}
 
TYZ2Z2Cat3FMatrixFunction[4, 1, 4, 2] = {{-1}}
 
TYZ2Z2Cat3FMatrixFunction[4, 1, 4, 3] = {{-1}}
 
TYZ2Z2Cat3FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
TYZ2Z2Cat3FMatrixFunction[4, 2, 4, 3] = {{-1}}
 
TYZ2Z2Cat3FMatrixFunction[4, 3, 4, 1] = {{-1}}
 
TYZ2Z2Cat3FMatrixFunction[4, 3, 4, 2] = {{-1}}
 
TYZ2Z2Cat3FMatrixFunction[4, 4, 4, 4] = {{1/2, 1/2, 1/2, 1/2}, 
    {1/2, 1/2, -1/2, -1/2}, {1/2, -1/2, 1/2, -1/2}, {1/2, -1/2, -1/2, 1/2}}
 
TYZ2Z2Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TYZ2Z2Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TYZ2Z2Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TYZ2Z2Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TYZ2Z2Cat3Piv1] ^= {TYZ2Z2Cat3Bal1, TYZ2Z2Cat3Bal3, 
    TYZ2Z2Cat3Bal5, TYZ2Z2Cat3Bal7, TYZ2Z2Cat3Bal9, TYZ2Z2Cat3Bal11, 
    TYZ2Z2Cat3Bal13, TYZ2Z2Cat3Bal15}
 
TYZ2Z2Cat3Piv1 /: balancedCategory[TYZ2Z2Cat3Piv1, 1] = TYZ2Z2Cat3Bal1
 
TYZ2Z2Cat3Piv1 /: balancedCategory[TYZ2Z2Cat3Piv1, 2] = TYZ2Z2Cat3Bal3
 
TYZ2Z2Cat3Piv1 /: balancedCategory[TYZ2Z2Cat3Piv1, 3] = TYZ2Z2Cat3Bal5
 
TYZ2Z2Cat3Piv1 /: balancedCategory[TYZ2Z2Cat3Piv1, 4] = TYZ2Z2Cat3Bal7
 
TYZ2Z2Cat3Piv1 /: balancedCategory[TYZ2Z2Cat3Piv1, 5] = TYZ2Z2Cat3Bal9
 
TYZ2Z2Cat3Piv1 /: balancedCategory[TYZ2Z2Cat3Piv1, 6] = TYZ2Z2Cat3Bal11
 
TYZ2Z2Cat3Piv1 /: balancedCategory[TYZ2Z2Cat3Piv1, 7] = TYZ2Z2Cat3Bal13
 
TYZ2Z2Cat3Piv1 /: balancedCategory[TYZ2Z2Cat3Piv1, 8] = TYZ2Z2Cat3Bal15
 
fusionCategory[TYZ2Z2Cat3Piv1] ^= TYZ2Z2Cat3
 
TYZ2Z2Cat3Piv1 /: modularCategory[TYZ2Z2Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TYZ2Z2Cat3Piv1] ^= TYZ2Z2Cat3Piv1
 
pivotalIsomorphism[TYZ2Z2Cat3Piv1] ^= TYZ2Z2Cat3Piv1PivotalIsomorphism
 
TYZ2Z2Cat3Piv1 /: ribbonCategory[TYZ2Z2Cat3Piv1, 1] = TYZ2Z2Cat3Bal1
 
TYZ2Z2Cat3Piv1 /: ribbonCategory[TYZ2Z2Cat3Piv1, 2] = TYZ2Z2Cat3Bal3
 
TYZ2Z2Cat3Piv1 /: ribbonCategory[TYZ2Z2Cat3Piv1, 3] = TYZ2Z2Cat3Bal5
 
TYZ2Z2Cat3Piv1 /: ribbonCategory[TYZ2Z2Cat3Piv1, 4] = TYZ2Z2Cat3Bal7
 
TYZ2Z2Cat3Piv1 /: ribbonCategory[TYZ2Z2Cat3Piv1, 5] = TYZ2Z2Cat3Bal9
 
TYZ2Z2Cat3Piv1 /: ribbonCategory[TYZ2Z2Cat3Piv1, 6] = TYZ2Z2Cat3Bal11
 
TYZ2Z2Cat3Piv1 /: ribbonCategory[TYZ2Z2Cat3Piv1, 7] = TYZ2Z2Cat3Bal13
 
TYZ2Z2Cat3Piv1 /: ribbonCategory[TYZ2Z2Cat3Piv1, 8] = TYZ2Z2Cat3Bal15
 
ring[TYZ2Z2Cat3Piv1] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat3Piv1] ^= TYZ2Z2Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[TYZ2Z2Cat3]][pivotalCategory[#1]] & )[
    TYZ2Z2Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TYZ2Z2Cat3]][
      sphericalCategory[#1]] & )[TYZ2Z2Cat3Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[TYZ2Z2Cat3Piv1PivotalIsomorphism] ^= TYZ2Z2Cat3
 
pivotalCategory[TYZ2Z2Cat3Piv1PivotalIsomorphism] ^= TYZ2Z2Cat3Piv1
 
pivotalIsomorphism[TYZ2Z2Cat3Piv1PivotalIsomorphism] ^= 
   TYZ2Z2Cat3Piv1PivotalIsomorphism
 
TYZ2Z2Cat3Piv1PivotalIsomorphism[0] = 1
 
TYZ2Z2Cat3Piv1PivotalIsomorphism[1] = 1
 
TYZ2Z2Cat3Piv1PivotalIsomorphism[2] = 1
 
TYZ2Z2Cat3Piv1PivotalIsomorphism[3] = 1
 
TYZ2Z2Cat3Piv1PivotalIsomorphism[4] = 1
balancedCategories[TYZ2Z2Cat3Piv2] ^= {TYZ2Z2Cat3Bal2, TYZ2Z2Cat3Bal4, 
    TYZ2Z2Cat3Bal6, TYZ2Z2Cat3Bal8, TYZ2Z2Cat3Bal10, TYZ2Z2Cat3Bal12, 
    TYZ2Z2Cat3Bal14, TYZ2Z2Cat3Bal16}
 
TYZ2Z2Cat3Piv2 /: balancedCategory[TYZ2Z2Cat3Piv2, 1] = TYZ2Z2Cat3Bal2
 
TYZ2Z2Cat3Piv2 /: balancedCategory[TYZ2Z2Cat3Piv2, 2] = TYZ2Z2Cat3Bal4
 
TYZ2Z2Cat3Piv2 /: balancedCategory[TYZ2Z2Cat3Piv2, 3] = TYZ2Z2Cat3Bal6
 
TYZ2Z2Cat3Piv2 /: balancedCategory[TYZ2Z2Cat3Piv2, 4] = TYZ2Z2Cat3Bal8
 
TYZ2Z2Cat3Piv2 /: balancedCategory[TYZ2Z2Cat3Piv2, 5] = TYZ2Z2Cat3Bal10
 
TYZ2Z2Cat3Piv2 /: balancedCategory[TYZ2Z2Cat3Piv2, 6] = TYZ2Z2Cat3Bal12
 
TYZ2Z2Cat3Piv2 /: balancedCategory[TYZ2Z2Cat3Piv2, 7] = TYZ2Z2Cat3Bal14
 
TYZ2Z2Cat3Piv2 /: balancedCategory[TYZ2Z2Cat3Piv2, 8] = TYZ2Z2Cat3Bal16
 
fusionCategory[TYZ2Z2Cat3Piv2] ^= TYZ2Z2Cat3
 
TYZ2Z2Cat3Piv2 /: modularCategory[TYZ2Z2Cat3Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TYZ2Z2Cat3Piv2] ^= TYZ2Z2Cat3Piv2
 
pivotalIsomorphism[TYZ2Z2Cat3Piv2] ^= TYZ2Z2Cat3Piv2PivotalIsomorphism
 
TYZ2Z2Cat3Piv2 /: ribbonCategory[TYZ2Z2Cat3Piv2, 1] = TYZ2Z2Cat3Bal2
 
TYZ2Z2Cat3Piv2 /: ribbonCategory[TYZ2Z2Cat3Piv2, 2] = TYZ2Z2Cat3Bal4
 
TYZ2Z2Cat3Piv2 /: ribbonCategory[TYZ2Z2Cat3Piv2, 3] = TYZ2Z2Cat3Bal6
 
TYZ2Z2Cat3Piv2 /: ribbonCategory[TYZ2Z2Cat3Piv2, 4] = TYZ2Z2Cat3Bal8
 
TYZ2Z2Cat3Piv2 /: ribbonCategory[TYZ2Z2Cat3Piv2, 5] = TYZ2Z2Cat3Bal10
 
TYZ2Z2Cat3Piv2 /: ribbonCategory[TYZ2Z2Cat3Piv2, 6] = TYZ2Z2Cat3Bal12
 
TYZ2Z2Cat3Piv2 /: ribbonCategory[TYZ2Z2Cat3Piv2, 7] = TYZ2Z2Cat3Bal14
 
TYZ2Z2Cat3Piv2 /: ribbonCategory[TYZ2Z2Cat3Piv2, 8] = TYZ2Z2Cat3Bal16
 
ring[TYZ2Z2Cat3Piv2] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat3Piv2] ^= TYZ2Z2Cat3Piv2
 
(pivotalCategoryIndex[fusionCategory[TYZ2Z2Cat3]][pivotalCategory[#1]] & )[
    TYZ2Z2Cat3Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TYZ2Z2Cat3]][
      sphericalCategory[#1]] & )[TYZ2Z2Cat3Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[TYZ2Z2Cat3Piv2PivotalIsomorphism] ^= TYZ2Z2Cat3
 
pivotalCategory[TYZ2Z2Cat3Piv2PivotalIsomorphism] ^= TYZ2Z2Cat3Piv2
 
pivotalIsomorphism[TYZ2Z2Cat3Piv2PivotalIsomorphism] ^= 
   TYZ2Z2Cat3Piv2PivotalIsomorphism
 
TYZ2Z2Cat3Piv2PivotalIsomorphism[0] = 1
 
TYZ2Z2Cat3Piv2PivotalIsomorphism[1] = 1
 
TYZ2Z2Cat3Piv2PivotalIsomorphism[2] = 1
 
TYZ2Z2Cat3Piv2PivotalIsomorphism[3] = 1
 
TYZ2Z2Cat3Piv2PivotalIsomorphism[4] = -1
balancedCategories[TYZ2Z2Cat4] ^= {TYZ2Z2Cat4Bal1, TYZ2Z2Cat4Bal2, 
    TYZ2Z2Cat4Bal3, TYZ2Z2Cat4Bal4, TYZ2Z2Cat4Bal5, TYZ2Z2Cat4Bal6, 
    TYZ2Z2Cat4Bal7, TYZ2Z2Cat4Bal8, TYZ2Z2Cat4Bal9, TYZ2Z2Cat4Bal10, 
    TYZ2Z2Cat4Bal11, TYZ2Z2Cat4Bal12, TYZ2Z2Cat4Bal13, TYZ2Z2Cat4Bal14, 
    TYZ2Z2Cat4Bal15, TYZ2Z2Cat4Bal16}
 
TYZ2Z2Cat4 /: balancedCategory[TYZ2Z2Cat4, 1] = TYZ2Z2Cat4Bal1
 
TYZ2Z2Cat4 /: balancedCategory[TYZ2Z2Cat4, 2] = TYZ2Z2Cat4Bal2
 
TYZ2Z2Cat4 /: balancedCategory[TYZ2Z2Cat4, 3] = TYZ2Z2Cat4Bal3
 
TYZ2Z2Cat4 /: balancedCategory[TYZ2Z2Cat4, 4] = TYZ2Z2Cat4Bal4
 
TYZ2Z2Cat4 /: balancedCategory[TYZ2Z2Cat4, 5] = TYZ2Z2Cat4Bal5
 
TYZ2Z2Cat4 /: balancedCategory[TYZ2Z2Cat4, 6] = TYZ2Z2Cat4Bal6
 
TYZ2Z2Cat4 /: balancedCategory[TYZ2Z2Cat4, 7] = TYZ2Z2Cat4Bal7
 
TYZ2Z2Cat4 /: balancedCategory[TYZ2Z2Cat4, 8] = TYZ2Z2Cat4Bal8
 
TYZ2Z2Cat4 /: balancedCategory[TYZ2Z2Cat4, 9] = TYZ2Z2Cat4Bal9
 
TYZ2Z2Cat4 /: balancedCategory[TYZ2Z2Cat4, 10] = TYZ2Z2Cat4Bal10
 
TYZ2Z2Cat4 /: balancedCategory[TYZ2Z2Cat4, 11] = TYZ2Z2Cat4Bal11
 
TYZ2Z2Cat4 /: balancedCategory[TYZ2Z2Cat4, 12] = TYZ2Z2Cat4Bal12
 
TYZ2Z2Cat4 /: balancedCategory[TYZ2Z2Cat4, 13] = TYZ2Z2Cat4Bal13
 
TYZ2Z2Cat4 /: balancedCategory[TYZ2Z2Cat4, 14] = TYZ2Z2Cat4Bal14
 
TYZ2Z2Cat4 /: balancedCategory[TYZ2Z2Cat4, 15] = TYZ2Z2Cat4Bal15
 
TYZ2Z2Cat4 /: balancedCategory[TYZ2Z2Cat4, 16] = TYZ2Z2Cat4Bal16
 
braidedCategories[TYZ2Z2Cat4] ^= {TYZ2Z2Cat4Brd1, TYZ2Z2Cat4Brd2, 
    TYZ2Z2Cat4Brd3, TYZ2Z2Cat4Brd4, TYZ2Z2Cat4Brd5, TYZ2Z2Cat4Brd6, 
    TYZ2Z2Cat4Brd7, TYZ2Z2Cat4Brd8}
 
TYZ2Z2Cat4 /: braidedCategory[TYZ2Z2Cat4, 1] = TYZ2Z2Cat4Brd1
 
TYZ2Z2Cat4 /: braidedCategory[TYZ2Z2Cat4, 2] = TYZ2Z2Cat4Brd2
 
TYZ2Z2Cat4 /: braidedCategory[TYZ2Z2Cat4, 3] = TYZ2Z2Cat4Brd3
 
TYZ2Z2Cat4 /: braidedCategory[TYZ2Z2Cat4, 4] = TYZ2Z2Cat4Brd4
 
TYZ2Z2Cat4 /: braidedCategory[TYZ2Z2Cat4, 5] = TYZ2Z2Cat4Brd5
 
TYZ2Z2Cat4 /: braidedCategory[TYZ2Z2Cat4, 6] = TYZ2Z2Cat4Brd6
 
TYZ2Z2Cat4 /: braidedCategory[TYZ2Z2Cat4, 7] = TYZ2Z2Cat4Brd7
 
TYZ2Z2Cat4 /: braidedCategory[TYZ2Z2Cat4, 8] = TYZ2Z2Cat4Brd8
 
coeval[TYZ2Z2Cat4] ^= 1/sixJFunction[TYZ2Z2Cat4][#1, 
      dual[ring[TYZ2Z2Cat4]][#1], #1, #1, 0, 0] & 
 
eval[TYZ2Z2Cat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TYZ2Z2Cat4] ^= TYZ2Z2Cat4FMatrixFunction
 
fusionCategory[TYZ2Z2Cat4] ^= TYZ2Z2Cat4
 
TYZ2Z2Cat4 /: modularCategory[TYZ2Z2Cat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TYZ2Z2Cat4] ^= {TYZ2Z2Cat4Piv1, TYZ2Z2Cat4Piv2}
 
TYZ2Z2Cat4 /: pivotalCategory[TYZ2Z2Cat4, 1] = TYZ2Z2Cat4Piv1
 
TYZ2Z2Cat4 /: pivotalCategory[TYZ2Z2Cat4, 2] = TYZ2Z2Cat4Piv2
 
TYZ2Z2Cat4 /: pivotalCategory[TYZ2Z2Cat4, {1, 1, 1, 1, -1}] = TYZ2Z2Cat4Piv2
 
TYZ2Z2Cat4 /: pivotalCategory[TYZ2Z2Cat4, {1, 1, 1, 1, 1}] = TYZ2Z2Cat4Piv1
 
TYZ2Z2Cat4 /: ribbonCategory[TYZ2Z2Cat4, 1] = TYZ2Z2Cat4Bal1
 
TYZ2Z2Cat4 /: ribbonCategory[TYZ2Z2Cat4, 2] = TYZ2Z2Cat4Bal2
 
TYZ2Z2Cat4 /: ribbonCategory[TYZ2Z2Cat4, 3] = TYZ2Z2Cat4Bal3
 
TYZ2Z2Cat4 /: ribbonCategory[TYZ2Z2Cat4, 4] = TYZ2Z2Cat4Bal4
 
TYZ2Z2Cat4 /: ribbonCategory[TYZ2Z2Cat4, 5] = TYZ2Z2Cat4Bal5
 
TYZ2Z2Cat4 /: ribbonCategory[TYZ2Z2Cat4, 6] = TYZ2Z2Cat4Bal6
 
TYZ2Z2Cat4 /: ribbonCategory[TYZ2Z2Cat4, 7] = TYZ2Z2Cat4Bal7
 
TYZ2Z2Cat4 /: ribbonCategory[TYZ2Z2Cat4, 8] = TYZ2Z2Cat4Bal8
 
TYZ2Z2Cat4 /: ribbonCategory[TYZ2Z2Cat4, 9] = TYZ2Z2Cat4Bal9
 
TYZ2Z2Cat4 /: ribbonCategory[TYZ2Z2Cat4, 10] = TYZ2Z2Cat4Bal10
 
TYZ2Z2Cat4 /: ribbonCategory[TYZ2Z2Cat4, 11] = TYZ2Z2Cat4Bal11
 
TYZ2Z2Cat4 /: ribbonCategory[TYZ2Z2Cat4, 12] = TYZ2Z2Cat4Bal12
 
TYZ2Z2Cat4 /: ribbonCategory[TYZ2Z2Cat4, 13] = TYZ2Z2Cat4Bal13
 
TYZ2Z2Cat4 /: ribbonCategory[TYZ2Z2Cat4, 14] = TYZ2Z2Cat4Bal14
 
TYZ2Z2Cat4 /: ribbonCategory[TYZ2Z2Cat4, 15] = TYZ2Z2Cat4Bal15
 
TYZ2Z2Cat4 /: ribbonCategory[TYZ2Z2Cat4, 16] = TYZ2Z2Cat4Bal16
 
ring[TYZ2Z2Cat4] ^= TYZ2Z2
 
TYZ2Z2Cat4 /: sphericalCategory[TYZ2Z2Cat4, 1] = TYZ2Z2Cat4Piv1
 
TYZ2Z2Cat4 /: sphericalCategory[TYZ2Z2Cat4, 2] = TYZ2Z2Cat4Piv2
 
TYZ2Z2Cat4 /: symmetricCategory[TYZ2Z2Cat4, 1] = TYZ2Z2Cat4Brd1
 
TYZ2Z2Cat4 /: symmetricCategory[TYZ2Z2Cat4, 2] = TYZ2Z2Cat4Brd4
 
fusionCategoryIndex[TYZ2Z2][TYZ2Z2Cat4] ^= 4
balancedCategory[TYZ2Z2Cat4Bal1] ^= TYZ2Z2Cat4Bal1
 
braidedCategory[TYZ2Z2Cat4Bal1] ^= TYZ2Z2Cat4Brd1
 
fusionCategory[TYZ2Z2Cat4Bal1] ^= TYZ2Z2Cat4
 
pivotalCategory[TYZ2Z2Cat4Bal1] ^= TYZ2Z2Cat4Piv1
 
ribbonCategory[TYZ2Z2Cat4Bal1] ^= TYZ2Z2Cat4Bal1
 
ring[TYZ2Z2Cat4Bal1] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat4Bal1] ^= TYZ2Z2Cat4Piv1
 
symmetricCategory[TYZ2Z2Cat4Bal1] ^= TYZ2Z2Cat4Brd1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][balancedCategory[#1]] & )[
    TYZ2Z2Cat4Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat4Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat4Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat4Bal1] ^= 1
balancedCategory[TYZ2Z2Cat4Bal10] ^= TYZ2Z2Cat4Bal10
 
braidedCategory[TYZ2Z2Cat4Bal10] ^= TYZ2Z2Cat4Brd5
 
fusionCategory[TYZ2Z2Cat4Bal10] ^= TYZ2Z2Cat4
 
pivotalCategory[TYZ2Z2Cat4Bal10] ^= TYZ2Z2Cat4Piv2
 
ribbonCategory[TYZ2Z2Cat4Bal10] ^= TYZ2Z2Cat4Bal10
 
ring[TYZ2Z2Cat4Bal10] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat4Bal10] ^= TYZ2Z2Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd5]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal10] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][balancedCategory[#1]] & )[
    TYZ2Z2Cat4Bal10] ^= 10
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat4Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal10] ^= 5
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd5]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal10] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal10] ^= 10
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat4Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat4Bal10] ^= 5
balancedCategory[TYZ2Z2Cat4Bal11] ^= TYZ2Z2Cat4Bal11
 
braidedCategory[TYZ2Z2Cat4Bal11] ^= TYZ2Z2Cat4Brd6
 
fusionCategory[TYZ2Z2Cat4Bal11] ^= TYZ2Z2Cat4
 
pivotalCategory[TYZ2Z2Cat4Bal11] ^= TYZ2Z2Cat4Piv1
 
ribbonCategory[TYZ2Z2Cat4Bal11] ^= TYZ2Z2Cat4Bal11
 
ring[TYZ2Z2Cat4Bal11] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat4Bal11] ^= TYZ2Z2Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd6]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal11] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][balancedCategory[#1]] & )[
    TYZ2Z2Cat4Bal11] ^= 11
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat4Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal11] ^= 6
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd6]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal11] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal11] ^= 11
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat4Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat4Bal11] ^= 6
balancedCategory[TYZ2Z2Cat4Bal12] ^= TYZ2Z2Cat4Bal12
 
braidedCategory[TYZ2Z2Cat4Bal12] ^= TYZ2Z2Cat4Brd6
 
fusionCategory[TYZ2Z2Cat4Bal12] ^= TYZ2Z2Cat4
 
pivotalCategory[TYZ2Z2Cat4Bal12] ^= TYZ2Z2Cat4Piv2
 
ribbonCategory[TYZ2Z2Cat4Bal12] ^= TYZ2Z2Cat4Bal12
 
ring[TYZ2Z2Cat4Bal12] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat4Bal12] ^= TYZ2Z2Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd6]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal12] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][balancedCategory[#1]] & )[
    TYZ2Z2Cat4Bal12] ^= 12
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat4Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal12] ^= 6
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd6]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal12] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal12] ^= 12
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat4Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat4Bal12] ^= 6
balancedCategory[TYZ2Z2Cat4Bal13] ^= TYZ2Z2Cat4Bal13
 
braidedCategory[TYZ2Z2Cat4Bal13] ^= TYZ2Z2Cat4Brd7
 
fusionCategory[TYZ2Z2Cat4Bal13] ^= TYZ2Z2Cat4
 
pivotalCategory[TYZ2Z2Cat4Bal13] ^= TYZ2Z2Cat4Piv1
 
ribbonCategory[TYZ2Z2Cat4Bal13] ^= TYZ2Z2Cat4Bal13
 
ring[TYZ2Z2Cat4Bal13] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat4Bal13] ^= TYZ2Z2Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd7]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal13] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][balancedCategory[#1]] & )[
    TYZ2Z2Cat4Bal13] ^= 13
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat4Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal13] ^= 7
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd7]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal13] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal13] ^= 13
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat4Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat4Bal13] ^= 7
balancedCategory[TYZ2Z2Cat4Bal14] ^= TYZ2Z2Cat4Bal14
 
braidedCategory[TYZ2Z2Cat4Bal14] ^= TYZ2Z2Cat4Brd7
 
fusionCategory[TYZ2Z2Cat4Bal14] ^= TYZ2Z2Cat4
 
pivotalCategory[TYZ2Z2Cat4Bal14] ^= TYZ2Z2Cat4Piv2
 
ribbonCategory[TYZ2Z2Cat4Bal14] ^= TYZ2Z2Cat4Bal14
 
ring[TYZ2Z2Cat4Bal14] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat4Bal14] ^= TYZ2Z2Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd7]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal14] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][balancedCategory[#1]] & )[
    TYZ2Z2Cat4Bal14] ^= 14
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat4Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal14] ^= 7
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd7]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal14] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal14] ^= 14
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat4Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat4Bal14] ^= 7
balancedCategory[TYZ2Z2Cat4Bal15] ^= TYZ2Z2Cat4Bal15
 
braidedCategory[TYZ2Z2Cat4Bal15] ^= TYZ2Z2Cat4Brd8
 
fusionCategory[TYZ2Z2Cat4Bal15] ^= TYZ2Z2Cat4
 
pivotalCategory[TYZ2Z2Cat4Bal15] ^= TYZ2Z2Cat4Piv1
 
ribbonCategory[TYZ2Z2Cat4Bal15] ^= TYZ2Z2Cat4Bal15
 
ring[TYZ2Z2Cat4Bal15] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat4Bal15] ^= TYZ2Z2Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd8]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal15] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][balancedCategory[#1]] & )[
    TYZ2Z2Cat4Bal15] ^= 15
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat4Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal15] ^= 8
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd8]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal15] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal15] ^= 15
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat4Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat4Bal15] ^= 8
balancedCategory[TYZ2Z2Cat4Bal16] ^= TYZ2Z2Cat4Bal16
 
braidedCategory[TYZ2Z2Cat4Bal16] ^= TYZ2Z2Cat4Brd8
 
fusionCategory[TYZ2Z2Cat4Bal16] ^= TYZ2Z2Cat4
 
pivotalCategory[TYZ2Z2Cat4Bal16] ^= TYZ2Z2Cat4Piv2
 
ribbonCategory[TYZ2Z2Cat4Bal16] ^= TYZ2Z2Cat4Bal16
 
ring[TYZ2Z2Cat4Bal16] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat4Bal16] ^= TYZ2Z2Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd8]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal16] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][balancedCategory[#1]] & )[
    TYZ2Z2Cat4Bal16] ^= 16
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat4Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal16] ^= 8
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd8]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal16] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal16] ^= 16
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat4Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat4Bal16] ^= 8
balancedCategory[TYZ2Z2Cat4Bal2] ^= TYZ2Z2Cat4Bal2
 
braidedCategory[TYZ2Z2Cat4Bal2] ^= TYZ2Z2Cat4Brd1
 
fusionCategory[TYZ2Z2Cat4Bal2] ^= TYZ2Z2Cat4
 
pivotalCategory[TYZ2Z2Cat4Bal2] ^= TYZ2Z2Cat4Piv2
 
ribbonCategory[TYZ2Z2Cat4Bal2] ^= TYZ2Z2Cat4Bal2
 
ring[TYZ2Z2Cat4Bal2] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat4Bal2] ^= TYZ2Z2Cat4Piv2
 
symmetricCategory[TYZ2Z2Cat4Bal2] ^= TYZ2Z2Cat4Brd1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][balancedCategory[#1]] & )[
    TYZ2Z2Cat4Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat4Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd1]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat4Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat4Bal2] ^= 1
balancedCategory[TYZ2Z2Cat4Bal3] ^= TYZ2Z2Cat4Bal3
 
braidedCategory[TYZ2Z2Cat4Bal3] ^= TYZ2Z2Cat4Brd2
 
fusionCategory[TYZ2Z2Cat4Bal3] ^= TYZ2Z2Cat4
 
pivotalCategory[TYZ2Z2Cat4Bal3] ^= TYZ2Z2Cat4Piv1
 
ribbonCategory[TYZ2Z2Cat4Bal3] ^= TYZ2Z2Cat4Bal3
 
ring[TYZ2Z2Cat4Bal3] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat4Bal3] ^= TYZ2Z2Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][balancedCategory[#1]] & )[
    TYZ2Z2Cat4Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat4Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat4Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat4Bal3] ^= 2
balancedCategory[TYZ2Z2Cat4Bal4] ^= TYZ2Z2Cat4Bal4
 
braidedCategory[TYZ2Z2Cat4Bal4] ^= TYZ2Z2Cat4Brd2
 
fusionCategory[TYZ2Z2Cat4Bal4] ^= TYZ2Z2Cat4
 
pivotalCategory[TYZ2Z2Cat4Bal4] ^= TYZ2Z2Cat4Piv2
 
ribbonCategory[TYZ2Z2Cat4Bal4] ^= TYZ2Z2Cat4Bal4
 
ring[TYZ2Z2Cat4Bal4] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat4Bal4] ^= TYZ2Z2Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][balancedCategory[#1]] & )[
    TYZ2Z2Cat4Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat4Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd2]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat4Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat4Bal4] ^= 2
balancedCategory[TYZ2Z2Cat4Bal5] ^= TYZ2Z2Cat4Bal5
 
braidedCategory[TYZ2Z2Cat4Bal5] ^= TYZ2Z2Cat4Brd3
 
fusionCategory[TYZ2Z2Cat4Bal5] ^= TYZ2Z2Cat4
 
pivotalCategory[TYZ2Z2Cat4Bal5] ^= TYZ2Z2Cat4Piv1
 
ribbonCategory[TYZ2Z2Cat4Bal5] ^= TYZ2Z2Cat4Bal5
 
ring[TYZ2Z2Cat4Bal5] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat4Bal5] ^= TYZ2Z2Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd3]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][balancedCategory[#1]] & )[
    TYZ2Z2Cat4Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat4Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal5] ^= 3
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat4Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat4Bal5] ^= 3
balancedCategory[TYZ2Z2Cat4Bal6] ^= TYZ2Z2Cat4Bal6
 
braidedCategory[TYZ2Z2Cat4Bal6] ^= TYZ2Z2Cat4Brd3
 
fusionCategory[TYZ2Z2Cat4Bal6] ^= TYZ2Z2Cat4
 
pivotalCategory[TYZ2Z2Cat4Bal6] ^= TYZ2Z2Cat4Piv2
 
ribbonCategory[TYZ2Z2Cat4Bal6] ^= TYZ2Z2Cat4Bal6
 
ring[TYZ2Z2Cat4Bal6] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat4Bal6] ^= TYZ2Z2Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd3]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][balancedCategory[#1]] & )[
    TYZ2Z2Cat4Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat4Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal6] ^= 3
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd3]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat4Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat4Bal6] ^= 3
balancedCategory[TYZ2Z2Cat4Bal7] ^= TYZ2Z2Cat4Bal7
 
braidedCategory[TYZ2Z2Cat4Bal7] ^= TYZ2Z2Cat4Brd4
 
fusionCategory[TYZ2Z2Cat4Bal7] ^= TYZ2Z2Cat4
 
pivotalCategory[TYZ2Z2Cat4Bal7] ^= TYZ2Z2Cat4Piv1
 
ribbonCategory[TYZ2Z2Cat4Bal7] ^= TYZ2Z2Cat4Bal7
 
ring[TYZ2Z2Cat4Bal7] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat4Bal7] ^= TYZ2Z2Cat4Piv1
 
symmetricCategory[TYZ2Z2Cat4Bal7] ^= TYZ2Z2Cat4Brd4
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd4]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][balancedCategory[#1]] & )[
    TYZ2Z2Cat4Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat4Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal7] ^= 4
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat4Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat4Bal7] ^= 4
balancedCategory[TYZ2Z2Cat4Bal8] ^= TYZ2Z2Cat4Bal8
 
braidedCategory[TYZ2Z2Cat4Bal8] ^= TYZ2Z2Cat4Brd4
 
fusionCategory[TYZ2Z2Cat4Bal8] ^= TYZ2Z2Cat4
 
pivotalCategory[TYZ2Z2Cat4Bal8] ^= TYZ2Z2Cat4Piv2
 
ribbonCategory[TYZ2Z2Cat4Bal8] ^= TYZ2Z2Cat4Bal8
 
ring[TYZ2Z2Cat4Bal8] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat4Bal8] ^= TYZ2Z2Cat4Piv2
 
symmetricCategory[TYZ2Z2Cat4Bal8] ^= TYZ2Z2Cat4Brd4
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd4]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][balancedCategory[#1]] & )[
    TYZ2Z2Cat4Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat4Piv2]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal8] ^= 4
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat4Piv2]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat4Bal8] ^= 4
balancedCategory[TYZ2Z2Cat4Bal9] ^= TYZ2Z2Cat4Bal9
 
braidedCategory[TYZ2Z2Cat4Bal9] ^= TYZ2Z2Cat4Brd5
 
fusionCategory[TYZ2Z2Cat4Bal9] ^= TYZ2Z2Cat4
 
pivotalCategory[TYZ2Z2Cat4Bal9] ^= TYZ2Z2Cat4Piv1
 
ribbonCategory[TYZ2Z2Cat4Bal9] ^= TYZ2Z2Cat4Bal9
 
ring[TYZ2Z2Cat4Bal9] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat4Bal9] ^= TYZ2Z2Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd5]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal9] ^= 1
 
(balancedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][balancedCategory[#1]] & )[
    TYZ2Z2Cat4Bal9] ^= 9
 
(balancedCategoryIndex[pivotalCategory[TYZ2Z2Cat4Piv1]][
      balancedCategory[#1]] & )[TYZ2Z2Cat4Bal9] ^= 5
 
(ribbonCategoryIndex[braidedCategory[TYZ2Z2Cat4Brd5]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal9] ^= 1
 
(ribbonCategoryIndex[fusionCategory[TYZ2Z2Cat4]][ribbonCategory[#1]] & )[
    TYZ2Z2Cat4Bal9] ^= 9
 
(ribbonCategoryIndex[sphericalCategory[TYZ2Z2Cat4Piv1]][
      ribbonCategory[#1]] & )[TYZ2Z2Cat4Bal9] ^= 5
balancedCategories[TYZ2Z2Cat4Brd1] ^= {TYZ2Z2Cat4Bal1, TYZ2Z2Cat4Bal2}
 
TYZ2Z2Cat4Brd1 /: balancedCategory[TYZ2Z2Cat4Brd1, 1] = TYZ2Z2Cat4Bal1
 
TYZ2Z2Cat4Brd1 /: balancedCategory[TYZ2Z2Cat4Brd1, 2] = TYZ2Z2Cat4Bal2
 
braidedCategory[TYZ2Z2Cat4Brd1] ^= TYZ2Z2Cat4Brd1
 
fusionCategory[TYZ2Z2Cat4Brd1] ^= TYZ2Z2Cat4
 
TYZ2Z2Cat4Brd1 /: modularCategory[TYZ2Z2Cat4Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat4Brd1 /: ribbonCategory[TYZ2Z2Cat4Brd1, 1] = TYZ2Z2Cat4Bal1
 
TYZ2Z2Cat4Brd1 /: ribbonCategory[TYZ2Z2Cat4Brd1, 2] = TYZ2Z2Cat4Bal2
 
ring[TYZ2Z2Cat4Brd1] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat4Brd1] ^= TYZ2Z2Cat4Brd1RMatrixFunction
 
symmetricCategory[TYZ2Z2Cat4Brd1] ^= TYZ2Z2Cat4Brd1
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][braidedCategory[#1]] & )[
    TYZ2Z2Cat4Brd1] ^= 1
 
(symmetricCategoryIndex[fusionCategory[TYZ2Z2Cat4]][
      symmetricCategory[#1]] & )[TYZ2Z2Cat4Brd1] ^= 1
braidedCategory[TYZ2Z2Cat4Brd1RMatrixFunction] ^= TYZ2Z2Cat4Brd1
 
fusionCategory[TYZ2Z2Cat4Brd1RMatrixFunction] ^= TYZ2Z2Cat4
 
rMatrixFunction[TYZ2Z2Cat4Brd1RMatrixFunction] ^= 
   TYZ2Z2Cat4Brd1RMatrixFunction
 
TYZ2Z2Cat4Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[1, 1, 0] = {{1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[1, 4, 4] = {{-1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[2, 4, 4] = {{-1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[3, 4, 4] = {{-1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[4, 1, 4] = {{-1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[4, 2, 4] = {{-1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[4, 3, 4] = {{-1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[4, 4, 0] = {{-1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[4, 4, 1] = {{1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[4, 4, 2] = {{1}}
 
TYZ2Z2Cat4Brd1RMatrixFunction[4, 4, 3] = {{1}}
balancedCategories[TYZ2Z2Cat4Brd2] ^= {TYZ2Z2Cat4Bal3, TYZ2Z2Cat4Bal4}
 
TYZ2Z2Cat4Brd2 /: balancedCategory[TYZ2Z2Cat4Brd2, 1] = TYZ2Z2Cat4Bal3
 
TYZ2Z2Cat4Brd2 /: balancedCategory[TYZ2Z2Cat4Brd2, 2] = TYZ2Z2Cat4Bal4
 
braidedCategory[TYZ2Z2Cat4Brd2] ^= TYZ2Z2Cat4Brd2
 
fusionCategory[TYZ2Z2Cat4Brd2] ^= TYZ2Z2Cat4
 
TYZ2Z2Cat4Brd2 /: modularCategory[TYZ2Z2Cat4Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat4Brd2 /: ribbonCategory[TYZ2Z2Cat4Brd2, 1] = TYZ2Z2Cat4Bal3
 
TYZ2Z2Cat4Brd2 /: ribbonCategory[TYZ2Z2Cat4Brd2, 2] = TYZ2Z2Cat4Bal4
 
ring[TYZ2Z2Cat4Brd2] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat4Brd2] ^= TYZ2Z2Cat4Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][braidedCategory[#1]] & )[
    TYZ2Z2Cat4Brd2] ^= 2
braidedCategory[TYZ2Z2Cat4Brd2RMatrixFunction] ^= TYZ2Z2Cat4Brd2
 
fusionCategory[TYZ2Z2Cat4Brd2RMatrixFunction] ^= TYZ2Z2Cat4
 
rMatrixFunction[TYZ2Z2Cat4Brd2RMatrixFunction] ^= 
   TYZ2Z2Cat4Brd2RMatrixFunction
 
TYZ2Z2Cat4Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[1, 1, 0] = {{1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[1, 4, 4] = {{-1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[2, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[3, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[4, 1, 4] = {{-1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[4, 2, 4] = {{1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[4, 3, 4] = {{1}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[4, 4, 0] = {{-I}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[4, 4, 1] = {{I}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[4, 4, 2] = {{-I}}
 
TYZ2Z2Cat4Brd2RMatrixFunction[4, 4, 3] = {{-I}}
balancedCategories[TYZ2Z2Cat4Brd3] ^= {TYZ2Z2Cat4Bal5, TYZ2Z2Cat4Bal6}
 
TYZ2Z2Cat4Brd3 /: balancedCategory[TYZ2Z2Cat4Brd3, 1] = TYZ2Z2Cat4Bal5
 
TYZ2Z2Cat4Brd3 /: balancedCategory[TYZ2Z2Cat4Brd3, 2] = TYZ2Z2Cat4Bal6
 
braidedCategory[TYZ2Z2Cat4Brd3] ^= TYZ2Z2Cat4Brd3
 
fusionCategory[TYZ2Z2Cat4Brd3] ^= TYZ2Z2Cat4
 
TYZ2Z2Cat4Brd3 /: modularCategory[TYZ2Z2Cat4Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat4Brd3 /: ribbonCategory[TYZ2Z2Cat4Brd3, 1] = TYZ2Z2Cat4Bal5
 
TYZ2Z2Cat4Brd3 /: ribbonCategory[TYZ2Z2Cat4Brd3, 2] = TYZ2Z2Cat4Bal6
 
ring[TYZ2Z2Cat4Brd3] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat4Brd3] ^= TYZ2Z2Cat4Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][braidedCategory[#1]] & )[
    TYZ2Z2Cat4Brd3] ^= 3
braidedCategory[TYZ2Z2Cat4Brd3RMatrixFunction] ^= TYZ2Z2Cat4Brd3
 
fusionCategory[TYZ2Z2Cat4Brd3RMatrixFunction] ^= TYZ2Z2Cat4
 
rMatrixFunction[TYZ2Z2Cat4Brd3RMatrixFunction] ^= 
   TYZ2Z2Cat4Brd3RMatrixFunction
 
TYZ2Z2Cat4Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[1, 1, 0] = {{1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[1, 4, 4] = {{-1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[2, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[3, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[4, 1, 4] = {{-1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[4, 2, 4] = {{1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[4, 3, 4] = {{1}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[4, 4, 0] = {{I}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[4, 4, 1] = {{-I}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[4, 4, 2] = {{I}}
 
TYZ2Z2Cat4Brd3RMatrixFunction[4, 4, 3] = {{I}}
balancedCategories[TYZ2Z2Cat4Brd4] ^= {TYZ2Z2Cat4Bal7, TYZ2Z2Cat4Bal8}
 
TYZ2Z2Cat4Brd4 /: balancedCategory[TYZ2Z2Cat4Brd4, 1] = TYZ2Z2Cat4Bal7
 
TYZ2Z2Cat4Brd4 /: balancedCategory[TYZ2Z2Cat4Brd4, 2] = TYZ2Z2Cat4Bal8
 
braidedCategory[TYZ2Z2Cat4Brd4] ^= TYZ2Z2Cat4Brd4
 
fusionCategory[TYZ2Z2Cat4Brd4] ^= TYZ2Z2Cat4
 
TYZ2Z2Cat4Brd4 /: modularCategory[TYZ2Z2Cat4Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat4Brd4 /: ribbonCategory[TYZ2Z2Cat4Brd4, 1] = TYZ2Z2Cat4Bal7
 
TYZ2Z2Cat4Brd4 /: ribbonCategory[TYZ2Z2Cat4Brd4, 2] = TYZ2Z2Cat4Bal8
 
ring[TYZ2Z2Cat4Brd4] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat4Brd4] ^= TYZ2Z2Cat4Brd4RMatrixFunction
 
symmetricCategory[TYZ2Z2Cat4Brd4] ^= TYZ2Z2Cat4Brd4
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][braidedCategory[#1]] & )[
    TYZ2Z2Cat4Brd4] ^= 4
 
(symmetricCategoryIndex[fusionCategory[TYZ2Z2Cat4]][
      symmetricCategory[#1]] & )[TYZ2Z2Cat4Brd4] ^= 2
braidedCategory[TYZ2Z2Cat4Brd4RMatrixFunction] ^= TYZ2Z2Cat4Brd4
 
fusionCategory[TYZ2Z2Cat4Brd4RMatrixFunction] ^= TYZ2Z2Cat4
 
rMatrixFunction[TYZ2Z2Cat4Brd4RMatrixFunction] ^= 
   TYZ2Z2Cat4Brd4RMatrixFunction
 
TYZ2Z2Cat4Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[1, 1, 0] = {{1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[1, 4, 4] = {{-1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[2, 4, 4] = {{-1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[3, 4, 4] = {{-1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[4, 1, 4] = {{-1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[4, 2, 4] = {{-1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[4, 3, 4] = {{-1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[4, 4, 0] = {{1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[4, 4, 1] = {{-1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[4, 4, 2] = {{-1}}
 
TYZ2Z2Cat4Brd4RMatrixFunction[4, 4, 3] = {{-1}}
balancedCategories[TYZ2Z2Cat4Brd5] ^= {TYZ2Z2Cat4Bal9, TYZ2Z2Cat4Bal10}
 
TYZ2Z2Cat4Brd5 /: balancedCategory[TYZ2Z2Cat4Brd5, 1] = TYZ2Z2Cat4Bal9
 
TYZ2Z2Cat4Brd5 /: balancedCategory[TYZ2Z2Cat4Brd5, 2] = TYZ2Z2Cat4Bal10
 
braidedCategory[TYZ2Z2Cat4Brd5] ^= TYZ2Z2Cat4Brd5
 
fusionCategory[TYZ2Z2Cat4Brd5] ^= TYZ2Z2Cat4
 
TYZ2Z2Cat4Brd5 /: modularCategory[TYZ2Z2Cat4Brd5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat4Brd5 /: ribbonCategory[TYZ2Z2Cat4Brd5, 1] = TYZ2Z2Cat4Bal9
 
TYZ2Z2Cat4Brd5 /: ribbonCategory[TYZ2Z2Cat4Brd5, 2] = TYZ2Z2Cat4Bal10
 
ring[TYZ2Z2Cat4Brd5] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat4Brd5] ^= TYZ2Z2Cat4Brd5RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][braidedCategory[#1]] & )[
    TYZ2Z2Cat4Brd5] ^= 5
braidedCategory[TYZ2Z2Cat4Brd5RMatrixFunction] ^= TYZ2Z2Cat4Brd5
 
fusionCategory[TYZ2Z2Cat4Brd5RMatrixFunction] ^= TYZ2Z2Cat4
 
rMatrixFunction[TYZ2Z2Cat4Brd5RMatrixFunction] ^= 
   TYZ2Z2Cat4Brd5RMatrixFunction
 
TYZ2Z2Cat4Brd5RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[1, 1, 0] = {{1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[1, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[2, 4, 4] = {{-1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[3, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[4, 1, 4] = {{1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[4, 2, 4] = {{-1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[4, 3, 4] = {{1}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[4, 4, 0] = {{-I}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[4, 4, 1] = {{-I}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[4, 4, 2] = {{I}}
 
TYZ2Z2Cat4Brd5RMatrixFunction[4, 4, 3] = {{-I}}
balancedCategories[TYZ2Z2Cat4Brd6] ^= {TYZ2Z2Cat4Bal11, TYZ2Z2Cat4Bal12}
 
TYZ2Z2Cat4Brd6 /: balancedCategory[TYZ2Z2Cat4Brd6, 1] = TYZ2Z2Cat4Bal11
 
TYZ2Z2Cat4Brd6 /: balancedCategory[TYZ2Z2Cat4Brd6, 2] = TYZ2Z2Cat4Bal12
 
braidedCategory[TYZ2Z2Cat4Brd6] ^= TYZ2Z2Cat4Brd6
 
fusionCategory[TYZ2Z2Cat4Brd6] ^= TYZ2Z2Cat4
 
TYZ2Z2Cat4Brd6 /: modularCategory[TYZ2Z2Cat4Brd6, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat4Brd6 /: ribbonCategory[TYZ2Z2Cat4Brd6, 1] = TYZ2Z2Cat4Bal11
 
TYZ2Z2Cat4Brd6 /: ribbonCategory[TYZ2Z2Cat4Brd6, 2] = TYZ2Z2Cat4Bal12
 
ring[TYZ2Z2Cat4Brd6] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat4Brd6] ^= TYZ2Z2Cat4Brd6RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][braidedCategory[#1]] & )[
    TYZ2Z2Cat4Brd6] ^= 6
braidedCategory[TYZ2Z2Cat4Brd6RMatrixFunction] ^= TYZ2Z2Cat4Brd6
 
fusionCategory[TYZ2Z2Cat4Brd6RMatrixFunction] ^= TYZ2Z2Cat4
 
rMatrixFunction[TYZ2Z2Cat4Brd6RMatrixFunction] ^= 
   TYZ2Z2Cat4Brd6RMatrixFunction
 
TYZ2Z2Cat4Brd6RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[1, 1, 0] = {{1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[1, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[2, 4, 4] = {{-1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[3, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[4, 1, 4] = {{1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[4, 2, 4] = {{-1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[4, 3, 4] = {{1}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[4, 4, 0] = {{I}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[4, 4, 1] = {{I}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[4, 4, 2] = {{-I}}
 
TYZ2Z2Cat4Brd6RMatrixFunction[4, 4, 3] = {{I}}
balancedCategories[TYZ2Z2Cat4Brd7] ^= {TYZ2Z2Cat4Bal13, TYZ2Z2Cat4Bal14}
 
TYZ2Z2Cat4Brd7 /: balancedCategory[TYZ2Z2Cat4Brd7, 1] = TYZ2Z2Cat4Bal13
 
TYZ2Z2Cat4Brd7 /: balancedCategory[TYZ2Z2Cat4Brd7, 2] = TYZ2Z2Cat4Bal14
 
braidedCategory[TYZ2Z2Cat4Brd7] ^= TYZ2Z2Cat4Brd7
 
fusionCategory[TYZ2Z2Cat4Brd7] ^= TYZ2Z2Cat4
 
TYZ2Z2Cat4Brd7 /: modularCategory[TYZ2Z2Cat4Brd7, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat4Brd7 /: ribbonCategory[TYZ2Z2Cat4Brd7, 1] = TYZ2Z2Cat4Bal13
 
TYZ2Z2Cat4Brd7 /: ribbonCategory[TYZ2Z2Cat4Brd7, 2] = TYZ2Z2Cat4Bal14
 
ring[TYZ2Z2Cat4Brd7] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat4Brd7] ^= TYZ2Z2Cat4Brd7RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][braidedCategory[#1]] & )[
    TYZ2Z2Cat4Brd7] ^= 7
braidedCategory[TYZ2Z2Cat4Brd7RMatrixFunction] ^= TYZ2Z2Cat4Brd7
 
fusionCategory[TYZ2Z2Cat4Brd7RMatrixFunction] ^= TYZ2Z2Cat4
 
rMatrixFunction[TYZ2Z2Cat4Brd7RMatrixFunction] ^= 
   TYZ2Z2Cat4Brd7RMatrixFunction
 
TYZ2Z2Cat4Brd7RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[1, 1, 0] = {{1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[1, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[2, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[3, 4, 4] = {{-1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[4, 1, 4] = {{1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[4, 2, 4] = {{1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[4, 3, 4] = {{-1}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[4, 4, 0] = {{-I}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[4, 4, 1] = {{-I}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[4, 4, 2] = {{-I}}
 
TYZ2Z2Cat4Brd7RMatrixFunction[4, 4, 3] = {{I}}
balancedCategories[TYZ2Z2Cat4Brd8] ^= {TYZ2Z2Cat4Bal15, TYZ2Z2Cat4Bal16}
 
TYZ2Z2Cat4Brd8 /: balancedCategory[TYZ2Z2Cat4Brd8, 1] = TYZ2Z2Cat4Bal15
 
TYZ2Z2Cat4Brd8 /: balancedCategory[TYZ2Z2Cat4Brd8, 2] = TYZ2Z2Cat4Bal16
 
braidedCategory[TYZ2Z2Cat4Brd8] ^= TYZ2Z2Cat4Brd8
 
fusionCategory[TYZ2Z2Cat4Brd8] ^= TYZ2Z2Cat4
 
TYZ2Z2Cat4Brd8 /: modularCategory[TYZ2Z2Cat4Brd8, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
TYZ2Z2Cat4Brd8 /: ribbonCategory[TYZ2Z2Cat4Brd8, 1] = TYZ2Z2Cat4Bal15
 
TYZ2Z2Cat4Brd8 /: ribbonCategory[TYZ2Z2Cat4Brd8, 2] = TYZ2Z2Cat4Bal16
 
ring[TYZ2Z2Cat4Brd8] ^= TYZ2Z2
 
rMatrixFunction[TYZ2Z2Cat4Brd8] ^= TYZ2Z2Cat4Brd8RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[TYZ2Z2Cat4]][braidedCategory[#1]] & )[
    TYZ2Z2Cat4Brd8] ^= 8
braidedCategory[TYZ2Z2Cat4Brd8RMatrixFunction] ^= TYZ2Z2Cat4Brd8
 
fusionCategory[TYZ2Z2Cat4Brd8RMatrixFunction] ^= TYZ2Z2Cat4
 
rMatrixFunction[TYZ2Z2Cat4Brd8RMatrixFunction] ^= 
   TYZ2Z2Cat4Brd8RMatrixFunction
 
TYZ2Z2Cat4Brd8RMatrixFunction[0, 0, 0] = {{1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[0, 1, 1] = {{1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[0, 2, 2] = {{1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[0, 3, 3] = {{1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[0, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[1, 0, 1] = {{1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[1, 1, 0] = {{1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[1, 2, 3] = {{-1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[1, 3, 2] = {{-1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[1, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[2, 0, 2] = {{1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[2, 1, 3] = {{-1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[2, 2, 0] = {{1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[2, 3, 1] = {{-1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[2, 4, 4] = {{1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[3, 0, 3] = {{1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[3, 1, 2] = {{-1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[3, 2, 1] = {{-1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[3, 3, 0] = {{1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[3, 4, 4] = {{-1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[4, 0, 4] = {{1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[4, 1, 4] = {{1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[4, 2, 4] = {{1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[4, 3, 4] = {{-1}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[4, 4, 0] = {{I}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[4, 4, 1] = {{I}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[4, 4, 2] = {{I}}
 
TYZ2Z2Cat4Brd8RMatrixFunction[4, 4, 3] = {{-I}}
fMatrixFunction[TYZ2Z2Cat4FMatrixFunction] ^= TYZ2Z2Cat4FMatrixFunction
 
fusionCategory[TYZ2Z2Cat4FMatrixFunction] ^= TYZ2Z2Cat4
 
ring[TYZ2Z2Cat4FMatrixFunction] ^= TYZ2Z2
 
TYZ2Z2Cat4FMatrixFunction[1, 4, 2, 4] = {{-1}}
 
TYZ2Z2Cat4FMatrixFunction[1, 4, 3, 4] = {{-1}}
 
TYZ2Z2Cat4FMatrixFunction[2, 4, 1, 4] = {{-1}}
 
TYZ2Z2Cat4FMatrixFunction[2, 4, 3, 4] = {{-1}}
 
TYZ2Z2Cat4FMatrixFunction[3, 4, 1, 4] = {{-1}}
 
TYZ2Z2Cat4FMatrixFunction[3, 4, 2, 4] = {{-1}}
 
TYZ2Z2Cat4FMatrixFunction[4, 1, 4, 2] = {{-1}}
 
TYZ2Z2Cat4FMatrixFunction[4, 1, 4, 3] = {{-1}}
 
TYZ2Z2Cat4FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
TYZ2Z2Cat4FMatrixFunction[4, 2, 4, 3] = {{-1}}
 
TYZ2Z2Cat4FMatrixFunction[4, 3, 4, 1] = {{-1}}
 
TYZ2Z2Cat4FMatrixFunction[4, 3, 4, 2] = {{-1}}
 
TYZ2Z2Cat4FMatrixFunction[4, 4, 4, 4] = {{-1/2, -1/2, -1/2, -1/2}, 
    {-1/2, -1/2, 1/2, 1/2}, {-1/2, 1/2, -1/2, 1/2}, {-1/2, 1/2, 1/2, -1/2}}
 
TYZ2Z2Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TYZ2Z2Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TYZ2Z2Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TYZ2Z2Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TYZ2Z2Cat4Piv1] ^= {TYZ2Z2Cat4Bal1, TYZ2Z2Cat4Bal3, 
    TYZ2Z2Cat4Bal5, TYZ2Z2Cat4Bal7, TYZ2Z2Cat4Bal9, TYZ2Z2Cat4Bal11, 
    TYZ2Z2Cat4Bal13, TYZ2Z2Cat4Bal15}
 
TYZ2Z2Cat4Piv1 /: balancedCategory[TYZ2Z2Cat4Piv1, 1] = TYZ2Z2Cat4Bal1
 
TYZ2Z2Cat4Piv1 /: balancedCategory[TYZ2Z2Cat4Piv1, 2] = TYZ2Z2Cat4Bal3
 
TYZ2Z2Cat4Piv1 /: balancedCategory[TYZ2Z2Cat4Piv1, 3] = TYZ2Z2Cat4Bal5
 
TYZ2Z2Cat4Piv1 /: balancedCategory[TYZ2Z2Cat4Piv1, 4] = TYZ2Z2Cat4Bal7
 
TYZ2Z2Cat4Piv1 /: balancedCategory[TYZ2Z2Cat4Piv1, 5] = TYZ2Z2Cat4Bal9
 
TYZ2Z2Cat4Piv1 /: balancedCategory[TYZ2Z2Cat4Piv1, 6] = TYZ2Z2Cat4Bal11
 
TYZ2Z2Cat4Piv1 /: balancedCategory[TYZ2Z2Cat4Piv1, 7] = TYZ2Z2Cat4Bal13
 
TYZ2Z2Cat4Piv1 /: balancedCategory[TYZ2Z2Cat4Piv1, 8] = TYZ2Z2Cat4Bal15
 
fusionCategory[TYZ2Z2Cat4Piv1] ^= TYZ2Z2Cat4
 
TYZ2Z2Cat4Piv1 /: modularCategory[TYZ2Z2Cat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TYZ2Z2Cat4Piv1] ^= TYZ2Z2Cat4Piv1
 
pivotalIsomorphism[TYZ2Z2Cat4Piv1] ^= TYZ2Z2Cat4Piv1PivotalIsomorphism
 
TYZ2Z2Cat4Piv1 /: ribbonCategory[TYZ2Z2Cat4Piv1, 1] = TYZ2Z2Cat4Bal1
 
TYZ2Z2Cat4Piv1 /: ribbonCategory[TYZ2Z2Cat4Piv1, 2] = TYZ2Z2Cat4Bal3
 
TYZ2Z2Cat4Piv1 /: ribbonCategory[TYZ2Z2Cat4Piv1, 3] = TYZ2Z2Cat4Bal5
 
TYZ2Z2Cat4Piv1 /: ribbonCategory[TYZ2Z2Cat4Piv1, 4] = TYZ2Z2Cat4Bal7
 
TYZ2Z2Cat4Piv1 /: ribbonCategory[TYZ2Z2Cat4Piv1, 5] = TYZ2Z2Cat4Bal9
 
TYZ2Z2Cat4Piv1 /: ribbonCategory[TYZ2Z2Cat4Piv1, 6] = TYZ2Z2Cat4Bal11
 
TYZ2Z2Cat4Piv1 /: ribbonCategory[TYZ2Z2Cat4Piv1, 7] = TYZ2Z2Cat4Bal13
 
TYZ2Z2Cat4Piv1 /: ribbonCategory[TYZ2Z2Cat4Piv1, 8] = TYZ2Z2Cat4Bal15
 
ring[TYZ2Z2Cat4Piv1] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat4Piv1] ^= TYZ2Z2Cat4Piv1
 
(pivotalCategoryIndex[fusionCategory[TYZ2Z2Cat4]][pivotalCategory[#1]] & )[
    TYZ2Z2Cat4Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TYZ2Z2Cat4]][
      sphericalCategory[#1]] & )[TYZ2Z2Cat4Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[TYZ2Z2Cat4Piv1PivotalIsomorphism] ^= TYZ2Z2Cat4
 
pivotalCategory[TYZ2Z2Cat4Piv1PivotalIsomorphism] ^= TYZ2Z2Cat4Piv1
 
pivotalIsomorphism[TYZ2Z2Cat4Piv1PivotalIsomorphism] ^= 
   TYZ2Z2Cat4Piv1PivotalIsomorphism
 
TYZ2Z2Cat4Piv1PivotalIsomorphism[0] = 1
 
TYZ2Z2Cat4Piv1PivotalIsomorphism[1] = 1
 
TYZ2Z2Cat4Piv1PivotalIsomorphism[2] = 1
 
TYZ2Z2Cat4Piv1PivotalIsomorphism[3] = 1
 
TYZ2Z2Cat4Piv1PivotalIsomorphism[4] = 1
balancedCategories[TYZ2Z2Cat4Piv2] ^= {TYZ2Z2Cat4Bal2, TYZ2Z2Cat4Bal4, 
    TYZ2Z2Cat4Bal6, TYZ2Z2Cat4Bal8, TYZ2Z2Cat4Bal10, TYZ2Z2Cat4Bal12, 
    TYZ2Z2Cat4Bal14, TYZ2Z2Cat4Bal16}
 
TYZ2Z2Cat4Piv2 /: balancedCategory[TYZ2Z2Cat4Piv2, 1] = TYZ2Z2Cat4Bal2
 
TYZ2Z2Cat4Piv2 /: balancedCategory[TYZ2Z2Cat4Piv2, 2] = TYZ2Z2Cat4Bal4
 
TYZ2Z2Cat4Piv2 /: balancedCategory[TYZ2Z2Cat4Piv2, 3] = TYZ2Z2Cat4Bal6
 
TYZ2Z2Cat4Piv2 /: balancedCategory[TYZ2Z2Cat4Piv2, 4] = TYZ2Z2Cat4Bal8
 
TYZ2Z2Cat4Piv2 /: balancedCategory[TYZ2Z2Cat4Piv2, 5] = TYZ2Z2Cat4Bal10
 
TYZ2Z2Cat4Piv2 /: balancedCategory[TYZ2Z2Cat4Piv2, 6] = TYZ2Z2Cat4Bal12
 
TYZ2Z2Cat4Piv2 /: balancedCategory[TYZ2Z2Cat4Piv2, 7] = TYZ2Z2Cat4Bal14
 
TYZ2Z2Cat4Piv2 /: balancedCategory[TYZ2Z2Cat4Piv2, 8] = TYZ2Z2Cat4Bal16
 
fusionCategory[TYZ2Z2Cat4Piv2] ^= TYZ2Z2Cat4
 
TYZ2Z2Cat4Piv2 /: modularCategory[TYZ2Z2Cat4Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TYZ2Z2Cat4Piv2] ^= TYZ2Z2Cat4Piv2
 
pivotalIsomorphism[TYZ2Z2Cat4Piv2] ^= TYZ2Z2Cat4Piv2PivotalIsomorphism
 
TYZ2Z2Cat4Piv2 /: ribbonCategory[TYZ2Z2Cat4Piv2, 1] = TYZ2Z2Cat4Bal2
 
TYZ2Z2Cat4Piv2 /: ribbonCategory[TYZ2Z2Cat4Piv2, 2] = TYZ2Z2Cat4Bal4
 
TYZ2Z2Cat4Piv2 /: ribbonCategory[TYZ2Z2Cat4Piv2, 3] = TYZ2Z2Cat4Bal6
 
TYZ2Z2Cat4Piv2 /: ribbonCategory[TYZ2Z2Cat4Piv2, 4] = TYZ2Z2Cat4Bal8
 
TYZ2Z2Cat4Piv2 /: ribbonCategory[TYZ2Z2Cat4Piv2, 5] = TYZ2Z2Cat4Bal10
 
TYZ2Z2Cat4Piv2 /: ribbonCategory[TYZ2Z2Cat4Piv2, 6] = TYZ2Z2Cat4Bal12
 
TYZ2Z2Cat4Piv2 /: ribbonCategory[TYZ2Z2Cat4Piv2, 7] = TYZ2Z2Cat4Bal14
 
TYZ2Z2Cat4Piv2 /: ribbonCategory[TYZ2Z2Cat4Piv2, 8] = TYZ2Z2Cat4Bal16
 
ring[TYZ2Z2Cat4Piv2] ^= TYZ2Z2
 
sphericalCategory[TYZ2Z2Cat4Piv2] ^= TYZ2Z2Cat4Piv2
 
(pivotalCategoryIndex[fusionCategory[TYZ2Z2Cat4]][pivotalCategory[#1]] & )[
    TYZ2Z2Cat4Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TYZ2Z2Cat4]][
      sphericalCategory[#1]] & )[TYZ2Z2Cat4Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[TYZ2Z2Cat4Piv2PivotalIsomorphism] ^= TYZ2Z2Cat4
 
pivotalCategory[TYZ2Z2Cat4Piv2PivotalIsomorphism] ^= TYZ2Z2Cat4Piv2
 
pivotalIsomorphism[TYZ2Z2Cat4Piv2PivotalIsomorphism] ^= 
   TYZ2Z2Cat4Piv2PivotalIsomorphism
 
TYZ2Z2Cat4Piv2PivotalIsomorphism[0] = 1
 
TYZ2Z2Cat4Piv2PivotalIsomorphism[1] = 1
 
TYZ2Z2Cat4Piv2PivotalIsomorphism[2] = 1
 
TYZ2Z2Cat4Piv2PivotalIsomorphism[3] = 1
 
TYZ2Z2Cat4Piv2PivotalIsomorphism[4] = -1
ring[TYZ2Z2NFunction] ^= TYZ2Z2
 
TYZ2Z2NFunction[0, 0, 0] = 1
 
TYZ2Z2NFunction[0, 0, 1] = 0
 
TYZ2Z2NFunction[0, 0, 2] = 0
 
TYZ2Z2NFunction[0, 0, 3] = 0
 
TYZ2Z2NFunction[0, 0, 4] = 0
 
TYZ2Z2NFunction[0, 1, 0] = 0
 
TYZ2Z2NFunction[0, 1, 1] = 1
 
TYZ2Z2NFunction[0, 1, 2] = 0
 
TYZ2Z2NFunction[0, 1, 3] = 0
 
TYZ2Z2NFunction[0, 1, 4] = 0
 
TYZ2Z2NFunction[0, 2, 0] = 0
 
TYZ2Z2NFunction[0, 2, 1] = 0
 
TYZ2Z2NFunction[0, 2, 2] = 1
 
TYZ2Z2NFunction[0, 2, 3] = 0
 
TYZ2Z2NFunction[0, 2, 4] = 0
 
TYZ2Z2NFunction[0, 3, 0] = 0
 
TYZ2Z2NFunction[0, 3, 1] = 0
 
TYZ2Z2NFunction[0, 3, 2] = 0
 
TYZ2Z2NFunction[0, 3, 3] = 1
 
TYZ2Z2NFunction[0, 3, 4] = 0
 
TYZ2Z2NFunction[0, 4, 0] = 0
 
TYZ2Z2NFunction[0, 4, 1] = 0
 
TYZ2Z2NFunction[0, 4, 2] = 0
 
TYZ2Z2NFunction[0, 4, 3] = 0
 
TYZ2Z2NFunction[0, 4, 4] = 1
 
TYZ2Z2NFunction[1, 0, 0] = 0
 
TYZ2Z2NFunction[1, 0, 1] = 1
 
TYZ2Z2NFunction[1, 0, 2] = 0
 
TYZ2Z2NFunction[1, 0, 3] = 0
 
TYZ2Z2NFunction[1, 0, 4] = 0
 
TYZ2Z2NFunction[1, 1, 0] = 1
 
TYZ2Z2NFunction[1, 1, 1] = 0
 
TYZ2Z2NFunction[1, 1, 2] = 0
 
TYZ2Z2NFunction[1, 1, 3] = 0
 
TYZ2Z2NFunction[1, 1, 4] = 0
 
TYZ2Z2NFunction[1, 2, 0] = 0
 
TYZ2Z2NFunction[1, 2, 1] = 0
 
TYZ2Z2NFunction[1, 2, 2] = 0
 
TYZ2Z2NFunction[1, 2, 3] = 1
 
TYZ2Z2NFunction[1, 2, 4] = 0
 
TYZ2Z2NFunction[1, 3, 0] = 0
 
TYZ2Z2NFunction[1, 3, 1] = 0
 
TYZ2Z2NFunction[1, 3, 2] = 1
 
TYZ2Z2NFunction[1, 3, 3] = 0
 
TYZ2Z2NFunction[1, 3, 4] = 0
 
TYZ2Z2NFunction[1, 4, 0] = 0
 
TYZ2Z2NFunction[1, 4, 1] = 0
 
TYZ2Z2NFunction[1, 4, 2] = 0
 
TYZ2Z2NFunction[1, 4, 3] = 0
 
TYZ2Z2NFunction[1, 4, 4] = 1
 
TYZ2Z2NFunction[2, 0, 0] = 0
 
TYZ2Z2NFunction[2, 0, 1] = 0
 
TYZ2Z2NFunction[2, 0, 2] = 1
 
TYZ2Z2NFunction[2, 0, 3] = 0
 
TYZ2Z2NFunction[2, 0, 4] = 0
 
TYZ2Z2NFunction[2, 1, 0] = 0
 
TYZ2Z2NFunction[2, 1, 1] = 0
 
TYZ2Z2NFunction[2, 1, 2] = 0
 
TYZ2Z2NFunction[2, 1, 3] = 1
 
TYZ2Z2NFunction[2, 1, 4] = 0
 
TYZ2Z2NFunction[2, 2, 0] = 1
 
TYZ2Z2NFunction[2, 2, 1] = 0
 
TYZ2Z2NFunction[2, 2, 2] = 0
 
TYZ2Z2NFunction[2, 2, 3] = 0
 
TYZ2Z2NFunction[2, 2, 4] = 0
 
TYZ2Z2NFunction[2, 3, 0] = 0
 
TYZ2Z2NFunction[2, 3, 1] = 1
 
TYZ2Z2NFunction[2, 3, 2] = 0
 
TYZ2Z2NFunction[2, 3, 3] = 0
 
TYZ2Z2NFunction[2, 3, 4] = 0
 
TYZ2Z2NFunction[2, 4, 0] = 0
 
TYZ2Z2NFunction[2, 4, 1] = 0
 
TYZ2Z2NFunction[2, 4, 2] = 0
 
TYZ2Z2NFunction[2, 4, 3] = 0
 
TYZ2Z2NFunction[2, 4, 4] = 1
 
TYZ2Z2NFunction[3, 0, 0] = 0
 
TYZ2Z2NFunction[3, 0, 1] = 0
 
TYZ2Z2NFunction[3, 0, 2] = 0
 
TYZ2Z2NFunction[3, 0, 3] = 1
 
TYZ2Z2NFunction[3, 0, 4] = 0
 
TYZ2Z2NFunction[3, 1, 0] = 0
 
TYZ2Z2NFunction[3, 1, 1] = 0
 
TYZ2Z2NFunction[3, 1, 2] = 1
 
TYZ2Z2NFunction[3, 1, 3] = 0
 
TYZ2Z2NFunction[3, 1, 4] = 0
 
TYZ2Z2NFunction[3, 2, 0] = 0
 
TYZ2Z2NFunction[3, 2, 1] = 1
 
TYZ2Z2NFunction[3, 2, 2] = 0
 
TYZ2Z2NFunction[3, 2, 3] = 0
 
TYZ2Z2NFunction[3, 2, 4] = 0
 
TYZ2Z2NFunction[3, 3, 0] = 1
 
TYZ2Z2NFunction[3, 3, 1] = 0
 
TYZ2Z2NFunction[3, 3, 2] = 0
 
TYZ2Z2NFunction[3, 3, 3] = 0
 
TYZ2Z2NFunction[3, 3, 4] = 0
 
TYZ2Z2NFunction[3, 4, 0] = 0
 
TYZ2Z2NFunction[3, 4, 1] = 0
 
TYZ2Z2NFunction[3, 4, 2] = 0
 
TYZ2Z2NFunction[3, 4, 3] = 0
 
TYZ2Z2NFunction[3, 4, 4] = 1
 
TYZ2Z2NFunction[4, 0, 0] = 0
 
TYZ2Z2NFunction[4, 0, 1] = 0
 
TYZ2Z2NFunction[4, 0, 2] = 0
 
TYZ2Z2NFunction[4, 0, 3] = 0
 
TYZ2Z2NFunction[4, 0, 4] = 1
 
TYZ2Z2NFunction[4, 1, 0] = 0
 
TYZ2Z2NFunction[4, 1, 1] = 0
 
TYZ2Z2NFunction[4, 1, 2] = 0
 
TYZ2Z2NFunction[4, 1, 3] = 0
 
TYZ2Z2NFunction[4, 1, 4] = 1
 
TYZ2Z2NFunction[4, 2, 0] = 0
 
TYZ2Z2NFunction[4, 2, 1] = 0
 
TYZ2Z2NFunction[4, 2, 2] = 0
 
TYZ2Z2NFunction[4, 2, 3] = 0
 
TYZ2Z2NFunction[4, 2, 4] = 1
 
TYZ2Z2NFunction[4, 3, 0] = 0
 
TYZ2Z2NFunction[4, 3, 1] = 0
 
TYZ2Z2NFunction[4, 3, 2] = 0
 
TYZ2Z2NFunction[4, 3, 3] = 0
 
TYZ2Z2NFunction[4, 3, 4] = 1
 
TYZ2Z2NFunction[4, 4, 0] = 1
 
TYZ2Z2NFunction[4, 4, 1] = 1
 
TYZ2Z2NFunction[4, 4, 2] = 1
 
TYZ2Z2NFunction[4, 4, 3] = 1
 
TYZ2Z2NFunction[4, 4, 4] = 0
 
TYZ2Z2NFunction[FusionCategories`Data`TYZ2Z2`Private`a_, FusionCategories`Data`TYZ2Z2`Private`b_, FusionCategories`Data`TYZ2Z2`Private`c_] := 0


 EndPackage[]
