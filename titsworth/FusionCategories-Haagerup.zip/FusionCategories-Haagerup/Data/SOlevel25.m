BeginPackage["FusionCategories`Data`SOlevel25`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[SOlevel25] ^= {SOlevel25Cat1, SOlevel25Cat2, SOlevel25Cat3, 
    SOlevel25Cat4}
 
SOlevel25 /: fusionCategory[SOlevel25, 1] = SOlevel25Cat1
 
SOlevel25 /: fusionCategory[SOlevel25, 2] = SOlevel25Cat2
 
SOlevel25 /: fusionCategory[SOlevel25, 3] = SOlevel25Cat3
 
SOlevel25 /: fusionCategory[SOlevel25, 4] = SOlevel25Cat4
 
nFunction[SOlevel25] ^= SOlevel25NFunction
 
noMultiplicities[SOlevel25] ^= True
 
rank[SOlevel25] ^= 6
 
ring[SOlevel25] ^= SOlevel25
balancedCategories[SOlevel25Cat1] ^= {SOlevel25Cat1Bal1, SOlevel25Cat1Bal2, 
    SOlevel25Cat1Bal3, SOlevel25Cat1Bal4, SOlevel25Cat1Bal5, 
    SOlevel25Cat1Bal6, SOlevel25Cat1Bal7, SOlevel25Cat1Bal8}
 
SOlevel25Cat1 /: balancedCategory[SOlevel25Cat1, 1] = SOlevel25Cat1Bal1
 
SOlevel25Cat1 /: balancedCategory[SOlevel25Cat1, 2] = SOlevel25Cat1Bal2
 
SOlevel25Cat1 /: balancedCategory[SOlevel25Cat1, 3] = SOlevel25Cat1Bal3
 
SOlevel25Cat1 /: balancedCategory[SOlevel25Cat1, 4] = SOlevel25Cat1Bal4
 
SOlevel25Cat1 /: balancedCategory[SOlevel25Cat1, 5] = SOlevel25Cat1Bal5
 
SOlevel25Cat1 /: balancedCategory[SOlevel25Cat1, 6] = SOlevel25Cat1Bal6
 
SOlevel25Cat1 /: balancedCategory[SOlevel25Cat1, 7] = SOlevel25Cat1Bal7
 
SOlevel25Cat1 /: balancedCategory[SOlevel25Cat1, 8] = SOlevel25Cat1Bal8
 
braidedCategories[SOlevel25Cat1] ^= {SOlevel25Cat1Brd1, SOlevel25Cat1Brd2, 
    SOlevel25Cat1Brd3, SOlevel25Cat1Brd4}
 
SOlevel25Cat1 /: braidedCategory[SOlevel25Cat1, 1] = SOlevel25Cat1Brd1
 
SOlevel25Cat1 /: braidedCategory[SOlevel25Cat1, 2] = SOlevel25Cat1Brd2
 
SOlevel25Cat1 /: braidedCategory[SOlevel25Cat1, 3] = SOlevel25Cat1Brd3
 
SOlevel25Cat1 /: braidedCategory[SOlevel25Cat1, 4] = SOlevel25Cat1Brd4
 
coeval[SOlevel25Cat1] ^= 1/sixJFunction[SOlevel25Cat1][#1, 
      dual[ring[SOlevel25Cat1]][#1], #1, #1, 0, 0] & 
 
eval[SOlevel25Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[SOlevel25Cat1] ^= SOlevel25Cat1FMatrixFunction
 
fusionCategory[SOlevel25Cat1] ^= SOlevel25Cat1
 
SOlevel25Cat1 /: modularCategory[SOlevel25Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[SOlevel25Cat1] ^= {SOlevel25Cat1Piv1, SOlevel25Cat1Piv2}
 
SOlevel25Cat1 /: pivotalCategory[SOlevel25Cat1, 1] = SOlevel25Cat1Piv1
 
SOlevel25Cat1 /: pivotalCategory[SOlevel25Cat1, 2] = SOlevel25Cat1Piv2
 
SOlevel25Cat1 /: pivotalCategory[SOlevel25Cat1, {1, 1, -1, -1, 1, 1}] = 
    SOlevel25Cat1Piv2
 
SOlevel25Cat1 /: pivotalCategory[SOlevel25Cat1, {1, 1, 1, 1, 1, 1}] = 
    SOlevel25Cat1Piv1
 
SOlevel25Cat1 /: ribbonCategory[SOlevel25Cat1, 1] = SOlevel25Cat1Bal1
 
SOlevel25Cat1 /: ribbonCategory[SOlevel25Cat1, 2] = SOlevel25Cat1Bal2
 
SOlevel25Cat1 /: ribbonCategory[SOlevel25Cat1, 3] = SOlevel25Cat1Bal3
 
SOlevel25Cat1 /: ribbonCategory[SOlevel25Cat1, 4] = SOlevel25Cat1Bal4
 
SOlevel25Cat1 /: ribbonCategory[SOlevel25Cat1, 5] = SOlevel25Cat1Bal5
 
SOlevel25Cat1 /: ribbonCategory[SOlevel25Cat1, 6] = SOlevel25Cat1Bal6
 
SOlevel25Cat1 /: ribbonCategory[SOlevel25Cat1, 7] = SOlevel25Cat1Bal7
 
SOlevel25Cat1 /: ribbonCategory[SOlevel25Cat1, 8] = SOlevel25Cat1Bal8
 
ring[SOlevel25Cat1] ^= SOlevel25
 
SOlevel25Cat1 /: sphericalCategory[SOlevel25Cat1, 1] = SOlevel25Cat1Piv1
 
SOlevel25Cat1 /: sphericalCategory[SOlevel25Cat1, 2] = SOlevel25Cat1Piv2
 
fusionCategoryIndex[SOlevel25][SOlevel25Cat1] ^= 1
balancedCategory[SOlevel25Cat1Bal1] ^= SOlevel25Cat1Bal1
 
braidedCategory[SOlevel25Cat1Bal1] ^= SOlevel25Cat1Brd1
 
fusionCategory[SOlevel25Cat1Bal1] ^= SOlevel25Cat1
 
pivotalCategory[SOlevel25Cat1Bal1] ^= SOlevel25Cat1Piv1
 
ribbonCategory[SOlevel25Cat1Bal1] ^= SOlevel25Cat1Bal1
 
ring[SOlevel25Cat1Bal1] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat1Bal1] ^= SOlevel25Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat1Brd1]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat1]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat1Piv1]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat1Brd1]][
      ribbonCategory[#1]] & )[SOlevel25Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat1]][ribbonCategory[#1]] & )[
    SOlevel25Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat1Piv1]][
      ribbonCategory[#1]] & )[SOlevel25Cat1Bal1] ^= 1
balancedCategory[SOlevel25Cat1Bal2] ^= SOlevel25Cat1Bal2
 
braidedCategory[SOlevel25Cat1Bal2] ^= SOlevel25Cat1Brd1
 
fusionCategory[SOlevel25Cat1Bal2] ^= SOlevel25Cat1
 
pivotalCategory[SOlevel25Cat1Bal2] ^= SOlevel25Cat1Piv2
 
ribbonCategory[SOlevel25Cat1Bal2] ^= SOlevel25Cat1Bal2
 
ring[SOlevel25Cat1Bal2] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat1Bal2] ^= SOlevel25Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat1Brd1]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat1]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat1Piv2]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat1Brd1]][
      ribbonCategory[#1]] & )[SOlevel25Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat1]][ribbonCategory[#1]] & )[
    SOlevel25Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat1Piv2]][
      ribbonCategory[#1]] & )[SOlevel25Cat1Bal2] ^= 1
balancedCategory[SOlevel25Cat1Bal3] ^= SOlevel25Cat1Bal3
 
braidedCategory[SOlevel25Cat1Bal3] ^= SOlevel25Cat1Brd2
 
fusionCategory[SOlevel25Cat1Bal3] ^= SOlevel25Cat1
 
pivotalCategory[SOlevel25Cat1Bal3] ^= SOlevel25Cat1Piv1
 
ribbonCategory[SOlevel25Cat1Bal3] ^= SOlevel25Cat1Bal3
 
ring[SOlevel25Cat1Bal3] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat1Bal3] ^= SOlevel25Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat1Brd2]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat1]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat1Piv1]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat1Brd2]][
      ribbonCategory[#1]] & )[SOlevel25Cat1Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat1]][ribbonCategory[#1]] & )[
    SOlevel25Cat1Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat1Piv1]][
      ribbonCategory[#1]] & )[SOlevel25Cat1Bal3] ^= 2
balancedCategory[SOlevel25Cat1Bal4] ^= SOlevel25Cat1Bal4
 
braidedCategory[SOlevel25Cat1Bal4] ^= SOlevel25Cat1Brd2
 
fusionCategory[SOlevel25Cat1Bal4] ^= SOlevel25Cat1
 
pivotalCategory[SOlevel25Cat1Bal4] ^= SOlevel25Cat1Piv2
 
ribbonCategory[SOlevel25Cat1Bal4] ^= SOlevel25Cat1Bal4
 
ring[SOlevel25Cat1Bal4] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat1Bal4] ^= SOlevel25Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat1Brd2]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat1]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat1Piv2]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat1Brd2]][
      ribbonCategory[#1]] & )[SOlevel25Cat1Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat1]][ribbonCategory[#1]] & )[
    SOlevel25Cat1Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat1Piv2]][
      ribbonCategory[#1]] & )[SOlevel25Cat1Bal4] ^= 2
balancedCategory[SOlevel25Cat1Bal5] ^= SOlevel25Cat1Bal5
 
braidedCategory[SOlevel25Cat1Bal5] ^= SOlevel25Cat1Brd3
 
fusionCategory[SOlevel25Cat1Bal5] ^= SOlevel25Cat1
 
pivotalCategory[SOlevel25Cat1Bal5] ^= SOlevel25Cat1Piv1
 
ribbonCategory[SOlevel25Cat1Bal5] ^= SOlevel25Cat1Bal5
 
ring[SOlevel25Cat1Bal5] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat1Bal5] ^= SOlevel25Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat1Brd3]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat1]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat1Piv1]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal5] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat1Brd3]][
      ribbonCategory[#1]] & )[SOlevel25Cat1Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat1]][ribbonCategory[#1]] & )[
    SOlevel25Cat1Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat1Piv1]][
      ribbonCategory[#1]] & )[SOlevel25Cat1Bal5] ^= 3
balancedCategory[SOlevel25Cat1Bal6] ^= SOlevel25Cat1Bal6
 
braidedCategory[SOlevel25Cat1Bal6] ^= SOlevel25Cat1Brd3
 
fusionCategory[SOlevel25Cat1Bal6] ^= SOlevel25Cat1
 
pivotalCategory[SOlevel25Cat1Bal6] ^= SOlevel25Cat1Piv2
 
ribbonCategory[SOlevel25Cat1Bal6] ^= SOlevel25Cat1Bal6
 
ring[SOlevel25Cat1Bal6] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat1Bal6] ^= SOlevel25Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat1Brd3]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat1]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat1Piv2]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal6] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat1Brd3]][
      ribbonCategory[#1]] & )[SOlevel25Cat1Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat1]][ribbonCategory[#1]] & )[
    SOlevel25Cat1Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat1Piv2]][
      ribbonCategory[#1]] & )[SOlevel25Cat1Bal6] ^= 3
balancedCategory[SOlevel25Cat1Bal7] ^= SOlevel25Cat1Bal7
 
braidedCategory[SOlevel25Cat1Bal7] ^= SOlevel25Cat1Brd4
 
fusionCategory[SOlevel25Cat1Bal7] ^= SOlevel25Cat1
 
pivotalCategory[SOlevel25Cat1Bal7] ^= SOlevel25Cat1Piv1
 
ribbonCategory[SOlevel25Cat1Bal7] ^= SOlevel25Cat1Bal7
 
ring[SOlevel25Cat1Bal7] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat1Bal7] ^= SOlevel25Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat1Brd4]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat1]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat1Piv1]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal7] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat1Brd4]][
      ribbonCategory[#1]] & )[SOlevel25Cat1Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat1]][ribbonCategory[#1]] & )[
    SOlevel25Cat1Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat1Piv1]][
      ribbonCategory[#1]] & )[SOlevel25Cat1Bal7] ^= 4
balancedCategory[SOlevel25Cat1Bal8] ^= SOlevel25Cat1Bal8
 
braidedCategory[SOlevel25Cat1Bal8] ^= SOlevel25Cat1Brd4
 
fusionCategory[SOlevel25Cat1Bal8] ^= SOlevel25Cat1
 
pivotalCategory[SOlevel25Cat1Bal8] ^= SOlevel25Cat1Piv2
 
ribbonCategory[SOlevel25Cat1Bal8] ^= SOlevel25Cat1Bal8
 
ring[SOlevel25Cat1Bal8] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat1Bal8] ^= SOlevel25Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat1Brd4]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat1]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat1Piv2]][
      balancedCategory[#1]] & )[SOlevel25Cat1Bal8] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat1Brd4]][
      ribbonCategory[#1]] & )[SOlevel25Cat1Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat1]][ribbonCategory[#1]] & )[
    SOlevel25Cat1Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat1Piv2]][
      ribbonCategory[#1]] & )[SOlevel25Cat1Bal8] ^= 4
balancedCategories[SOlevel25Cat1Brd1] ^= {SOlevel25Cat1Bal1, 
    SOlevel25Cat1Bal2}
 
SOlevel25Cat1Brd1 /: balancedCategory[SOlevel25Cat1Brd1, 1] = 
    SOlevel25Cat1Bal1
 
SOlevel25Cat1Brd1 /: balancedCategory[SOlevel25Cat1Brd1, 2] = 
    SOlevel25Cat1Bal2
 
braidedCategory[SOlevel25Cat1Brd1] ^= SOlevel25Cat1Brd1
 
fusionCategory[SOlevel25Cat1Brd1] ^= SOlevel25Cat1
 
SOlevel25Cat1Brd1 /: modularCategory[SOlevel25Cat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel25Cat1Brd1 /: ribbonCategory[SOlevel25Cat1Brd1, 1] = SOlevel25Cat1Bal1
 
SOlevel25Cat1Brd1 /: ribbonCategory[SOlevel25Cat1Brd1, 2] = SOlevel25Cat1Bal2
 
ring[SOlevel25Cat1Brd1] ^= SOlevel25
 
rMatrixFunction[SOlevel25Cat1Brd1] ^= SOlevel25Cat1Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel25Cat1]][braidedCategory[#1]] & )[
    SOlevel25Cat1Brd1] ^= 1
braidedCategory[SOlevel25Cat1Brd1RMatrixFunction] ^= SOlevel25Cat1Brd1
 
fusionCategory[SOlevel25Cat1Brd1RMatrixFunction] ^= SOlevel25Cat1
 
rMatrixFunction[SOlevel25Cat1Brd1RMatrixFunction] ^= 
   SOlevel25Cat1Brd1RMatrixFunction
 
SOlevel25Cat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[0, 5, 5] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[1, 2, 3] = {{-1}}
 
SOlevel25Cat1Brd1RMatrixFunction[1, 3, 2] = {{-1}}
 
SOlevel25Cat1Brd1RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[1, 5, 5] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[2, 1, 3] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[2, 2, 0] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[2, 2, 4] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[2, 2, 5] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[2, 3, 1] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[2, 3, 4] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[2, 3, 5] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[2, 4, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[2, 4, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[2, 5, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[2, 5, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[3, 1, 2] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[3, 2, 1] = {{-1}}
 
SOlevel25Cat1Brd1RMatrixFunction[3, 2, 4] = {{-(-1)^(4/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[3, 2, 5] = {{(-1)^(1/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[3, 3, 0] = {{-1}}
 
SOlevel25Cat1Brd1RMatrixFunction[3, 3, 4] = {{-(-1)^(4/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[3, 3, 5] = {{(-1)^(1/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[3, 4, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[3, 4, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[3, 5, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[3, 5, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[4, 2, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[4, 2, 3] = {{(-1)^(1/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[4, 3, 2] = {{(-1)^(1/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[4, 3, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[4, 4, 0] = {{(-1)^(2/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[4, 4, 1] = {{-(-1)^(2/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[4, 4, 5] = {{-(-1)^(3/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[4, 5, 4] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[4, 5, 5] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[5, 0, 5] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[5, 1, 5] = {{1}}
 
SOlevel25Cat1Brd1RMatrixFunction[5, 2, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[5, 2, 3] = {{-(-1)^(4/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[5, 3, 2] = {{-(-1)^(4/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[5, 3, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[5, 4, 4] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[5, 4, 5] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[5, 5, 0] = {{-(-1)^(3/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[5, 5, 1] = {{(-1)^(3/5)}}
 
SOlevel25Cat1Brd1RMatrixFunction[5, 5, 4] = {{(-1)^(2/5)}}
balancedCategories[SOlevel25Cat1Brd2] ^= {SOlevel25Cat1Bal3, 
    SOlevel25Cat1Bal4}
 
SOlevel25Cat1Brd2 /: balancedCategory[SOlevel25Cat1Brd2, 1] = 
    SOlevel25Cat1Bal3
 
SOlevel25Cat1Brd2 /: balancedCategory[SOlevel25Cat1Brd2, 2] = 
    SOlevel25Cat1Bal4
 
braidedCategory[SOlevel25Cat1Brd2] ^= SOlevel25Cat1Brd2
 
fusionCategory[SOlevel25Cat1Brd2] ^= SOlevel25Cat1
 
SOlevel25Cat1Brd2 /: modularCategory[SOlevel25Cat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel25Cat1Brd2 /: ribbonCategory[SOlevel25Cat1Brd2, 1] = SOlevel25Cat1Bal3
 
SOlevel25Cat1Brd2 /: ribbonCategory[SOlevel25Cat1Brd2, 2] = SOlevel25Cat1Bal4
 
ring[SOlevel25Cat1Brd2] ^= SOlevel25
 
rMatrixFunction[SOlevel25Cat1Brd2] ^= SOlevel25Cat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel25Cat1]][braidedCategory[#1]] & )[
    SOlevel25Cat1Brd2] ^= 2
braidedCategory[SOlevel25Cat1Brd2RMatrixFunction] ^= SOlevel25Cat1Brd2
 
fusionCategory[SOlevel25Cat1Brd2RMatrixFunction] ^= SOlevel25Cat1
 
rMatrixFunction[SOlevel25Cat1Brd2RMatrixFunction] ^= 
   SOlevel25Cat1Brd2RMatrixFunction
 
SOlevel25Cat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[0, 5, 5] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[1, 2, 3] = {{-1}}
 
SOlevel25Cat1Brd2RMatrixFunction[1, 3, 2] = {{-1}}
 
SOlevel25Cat1Brd2RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[1, 5, 5] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[2, 1, 3] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[2, 2, 0] = {{-1}}
 
SOlevel25Cat1Brd2RMatrixFunction[2, 2, 4] = {{-(-1)^(4/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[2, 2, 5] = {{(-1)^(1/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[2, 3, 1] = {{-1}}
 
SOlevel25Cat1Brd2RMatrixFunction[2, 3, 4] = {{-(-1)^(4/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[2, 3, 5] = {{(-1)^(1/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[2, 4, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[2, 4, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[2, 5, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[2, 5, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[3, 1, 2] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[3, 2, 1] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[3, 2, 4] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[3, 2, 5] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[3, 3, 0] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[3, 3, 4] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[3, 3, 5] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[3, 4, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[3, 4, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[3, 5, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[3, 5, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[4, 2, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[4, 2, 3] = {{(-1)^(1/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[4, 3, 2] = {{(-1)^(1/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[4, 3, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[4, 4, 0] = {{(-1)^(2/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[4, 4, 1] = {{-(-1)^(2/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[4, 4, 5] = {{-(-1)^(3/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[4, 5, 4] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[4, 5, 5] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[5, 0, 5] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[5, 1, 5] = {{1}}
 
SOlevel25Cat1Brd2RMatrixFunction[5, 2, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[5, 2, 3] = {{-(-1)^(4/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[5, 3, 2] = {{-(-1)^(4/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[5, 3, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[5, 4, 4] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[5, 4, 5] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[5, 5, 0] = {{-(-1)^(3/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[5, 5, 1] = {{(-1)^(3/5)}}
 
SOlevel25Cat1Brd2RMatrixFunction[5, 5, 4] = {{(-1)^(2/5)}}
balancedCategories[SOlevel25Cat1Brd3] ^= {SOlevel25Cat1Bal5, 
    SOlevel25Cat1Bal6}
 
SOlevel25Cat1Brd3 /: balancedCategory[SOlevel25Cat1Brd3, 1] = 
    SOlevel25Cat1Bal5
 
SOlevel25Cat1Brd3 /: balancedCategory[SOlevel25Cat1Brd3, 2] = 
    SOlevel25Cat1Bal6
 
braidedCategory[SOlevel25Cat1Brd3] ^= SOlevel25Cat1Brd3
 
fusionCategory[SOlevel25Cat1Brd3] ^= SOlevel25Cat1
 
SOlevel25Cat1Brd3 /: modularCategory[SOlevel25Cat1Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel25Cat1Brd3 /: ribbonCategory[SOlevel25Cat1Brd3, 1] = SOlevel25Cat1Bal5
 
SOlevel25Cat1Brd3 /: ribbonCategory[SOlevel25Cat1Brd3, 2] = SOlevel25Cat1Bal6
 
ring[SOlevel25Cat1Brd3] ^= SOlevel25
 
rMatrixFunction[SOlevel25Cat1Brd3] ^= SOlevel25Cat1Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel25Cat1]][braidedCategory[#1]] & )[
    SOlevel25Cat1Brd3] ^= 3
braidedCategory[SOlevel25Cat1Brd3RMatrixFunction] ^= SOlevel25Cat1Brd3
 
fusionCategory[SOlevel25Cat1Brd3RMatrixFunction] ^= SOlevel25Cat1
 
rMatrixFunction[SOlevel25Cat1Brd3RMatrixFunction] ^= 
   SOlevel25Cat1Brd3RMatrixFunction
 
SOlevel25Cat1Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[0, 5, 5] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[1, 2, 3] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[1, 3, 2] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[1, 5, 5] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[2, 1, 3] = {{-1}}
 
SOlevel25Cat1Brd3RMatrixFunction[2, 2, 0] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[2, 2, 4] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[2, 2, 5] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[2, 3, 1] = {{-1}}
 
SOlevel25Cat1Brd3RMatrixFunction[2, 3, 4] = {{(-1)^(1/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[2, 3, 5] = {{-(-1)^(4/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[2, 4, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[2, 4, 3] = {{-(-1)^(4/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[2, 5, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[2, 5, 3] = {{(-1)^(1/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[3, 1, 2] = {{-1}}
 
SOlevel25Cat1Brd3RMatrixFunction[3, 2, 1] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[3, 2, 4] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[3, 2, 5] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[3, 3, 0] = {{-1}}
 
SOlevel25Cat1Brd3RMatrixFunction[3, 3, 4] = {{(-1)^(1/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[3, 3, 5] = {{-(-1)^(4/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[3, 4, 2] = {{-(-1)^(4/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[3, 4, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[3, 5, 2] = {{(-1)^(1/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[3, 5, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[4, 2, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[4, 2, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[4, 3, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[4, 3, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[4, 4, 0] = {{-(-1)^(3/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[4, 4, 1] = {{(-1)^(3/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[4, 4, 5] = {{(-1)^(2/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[4, 5, 4] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[4, 5, 5] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[5, 0, 5] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[5, 1, 5] = {{1}}
 
SOlevel25Cat1Brd3RMatrixFunction[5, 2, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[5, 2, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[5, 3, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[5, 3, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[5, 4, 4] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[5, 4, 5] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[5, 5, 0] = {{(-1)^(2/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[5, 5, 1] = {{-(-1)^(2/5)}}
 
SOlevel25Cat1Brd3RMatrixFunction[5, 5, 4] = {{-(-1)^(3/5)}}
balancedCategories[SOlevel25Cat1Brd4] ^= {SOlevel25Cat1Bal7, 
    SOlevel25Cat1Bal8}
 
SOlevel25Cat1Brd4 /: balancedCategory[SOlevel25Cat1Brd4, 1] = 
    SOlevel25Cat1Bal7
 
SOlevel25Cat1Brd4 /: balancedCategory[SOlevel25Cat1Brd4, 2] = 
    SOlevel25Cat1Bal8
 
braidedCategory[SOlevel25Cat1Brd4] ^= SOlevel25Cat1Brd4
 
fusionCategory[SOlevel25Cat1Brd4] ^= SOlevel25Cat1
 
SOlevel25Cat1Brd4 /: modularCategory[SOlevel25Cat1Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel25Cat1Brd4 /: ribbonCategory[SOlevel25Cat1Brd4, 1] = SOlevel25Cat1Bal7
 
SOlevel25Cat1Brd4 /: ribbonCategory[SOlevel25Cat1Brd4, 2] = SOlevel25Cat1Bal8
 
ring[SOlevel25Cat1Brd4] ^= SOlevel25
 
rMatrixFunction[SOlevel25Cat1Brd4] ^= SOlevel25Cat1Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel25Cat1]][braidedCategory[#1]] & )[
    SOlevel25Cat1Brd4] ^= 4
braidedCategory[SOlevel25Cat1Brd4RMatrixFunction] ^= SOlevel25Cat1Brd4
 
fusionCategory[SOlevel25Cat1Brd4RMatrixFunction] ^= SOlevel25Cat1
 
rMatrixFunction[SOlevel25Cat1Brd4RMatrixFunction] ^= 
   SOlevel25Cat1Brd4RMatrixFunction
 
SOlevel25Cat1Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[0, 5, 5] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[1, 2, 3] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[1, 3, 2] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[1, 5, 5] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[2, 1, 3] = {{-1}}
 
SOlevel25Cat1Brd4RMatrixFunction[2, 2, 0] = {{-1}}
 
SOlevel25Cat1Brd4RMatrixFunction[2, 2, 4] = {{(-1)^(1/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[2, 2, 5] = {{-(-1)^(4/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[2, 3, 1] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[2, 3, 4] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[2, 3, 5] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[2, 4, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[2, 4, 3] = {{-(-1)^(4/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[2, 5, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[2, 5, 3] = {{(-1)^(1/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[3, 1, 2] = {{-1}}
 
SOlevel25Cat1Brd4RMatrixFunction[3, 2, 1] = {{-1}}
 
SOlevel25Cat1Brd4RMatrixFunction[3, 2, 4] = {{(-1)^(1/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[3, 2, 5] = {{-(-1)^(4/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[3, 3, 0] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[3, 3, 4] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[3, 3, 5] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[3, 4, 2] = {{-(-1)^(4/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[3, 4, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[3, 5, 2] = {{(-1)^(1/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[3, 5, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[4, 2, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[4, 2, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[4, 3, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[4, 3, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[4, 4, 0] = {{-(-1)^(3/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[4, 4, 1] = {{(-1)^(3/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[4, 4, 5] = {{(-1)^(2/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[4, 5, 4] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[4, 5, 5] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[5, 0, 5] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[5, 1, 5] = {{1}}
 
SOlevel25Cat1Brd4RMatrixFunction[5, 2, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[5, 2, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[5, 3, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[5, 3, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[5, 4, 4] = {{-(-1)^(1/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[5, 4, 5] = {{(-1)^(4/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[5, 5, 0] = {{(-1)^(2/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[5, 5, 1] = {{-(-1)^(2/5)}}
 
SOlevel25Cat1Brd4RMatrixFunction[5, 5, 4] = {{-(-1)^(3/5)}}
fMatrixFunction[SOlevel25Cat1FMatrixFunction] ^= SOlevel25Cat1FMatrixFunction
 
fusionCategory[SOlevel25Cat1FMatrixFunction] ^= SOlevel25Cat1
 
ring[SOlevel25Cat1FMatrixFunction] ^= SOlevel25
 
SOlevel25Cat1FMatrixFunction[1, 2, 2, 4] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[1, 2, 2, 5] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[1, 2, 3, 4] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[1, 2, 3, 5] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[1, 3, 2, 4] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[1, 3, 2, 5] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[1, 3, 3, 4] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[1, 3, 3, 5] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[1, 4, 4, 0] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[1, 4, 4, 1] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[1, 4, 5, 5] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[1, 5, 4, 5] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[1, 5, 5, 0] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[1, 5, 5, 1] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[1, 5, 5, 4] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[2, 2, 1, 4] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[2, 2, 1, 5] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[2, 2, 2, 2] = 
   {{-(1/Sqrt[5]), 1/Sqrt[5], 1/Sqrt[5]}, {2/Sqrt[5], (-5 + Sqrt[5])/10, 
     (5 + Sqrt[5])/10}, {2/Sqrt[5], (5 + Sqrt[5])/10, (-5 + Sqrt[5])/10}}
 
SOlevel25Cat1FMatrixFunction[2, 2, 2, 3] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0]}}
 
SOlevel25Cat1FMatrixFunction[2, 2, 3, 2] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0]}}
 
SOlevel25Cat1FMatrixFunction[2, 2, 3, 3] = 
   {{-(1/Sqrt[5]), 1/Sqrt[5], 1/Sqrt[5]}, {-2/Sqrt[5], (5 - Sqrt[5])/10, 
     (-5 - Sqrt[5])/10}, {-2/Sqrt[5], (-5 - Sqrt[5])/10, (5 - Sqrt[5])/10}}
 
SOlevel25Cat1FMatrixFunction[2, 2, 4, 4] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat1FMatrixFunction[2, 2, 4, 5] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat1FMatrixFunction[2, 2, 5, 4] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat1FMatrixFunction[2, 2, 5, 5] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat1FMatrixFunction[2, 3, 1, 4] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[2, 3, 1, 5] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[2, 3, 2, 2] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0]}}
 
SOlevel25Cat1FMatrixFunction[2, 3, 2, 3] = 
   {{-(1/Sqrt[5]), -(1/Sqrt[5]), -(1/Sqrt[5])}, 
    {-2/Sqrt[5], (-5 + Sqrt[5])/10, (5 + Sqrt[5])/10}, 
    {-2/Sqrt[5], (5 + Sqrt[5])/10, (-5 + Sqrt[5])/10}}
 
SOlevel25Cat1FMatrixFunction[2, 3, 3, 2] = 
   {{-(1/Sqrt[5]), -(1/Sqrt[5]), -(1/Sqrt[5])}, {2/Sqrt[5], (5 - Sqrt[5])/10, 
     (-5 - Sqrt[5])/10}, {2/Sqrt[5], (-5 - Sqrt[5])/10, (5 - Sqrt[5])/10}}
 
SOlevel25Cat1FMatrixFunction[2, 3, 3, 3] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0]}}
 
SOlevel25Cat1FMatrixFunction[2, 3, 4, 4] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat1FMatrixFunction[2, 3, 4, 5] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat1FMatrixFunction[2, 3, 5, 4] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat1FMatrixFunction[2, 3, 5, 5] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat1FMatrixFunction[2, 4, 2, 4] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat1FMatrixFunction[2, 4, 2, 5] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat1FMatrixFunction[2, 4, 3, 4] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}}
 
SOlevel25Cat1FMatrixFunction[2, 4, 3, 5] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}}
 
SOlevel25Cat1FMatrixFunction[2, 4, 4, 2] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[2, 4, 4, 3] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[2, 4, 5, 2] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[2, 4, 5, 3] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat1FMatrixFunction[2, 5, 2, 4] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat1FMatrixFunction[2, 5, 2, 5] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat1FMatrixFunction[2, 5, 3, 4] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}}
 
SOlevel25Cat1FMatrixFunction[2, 5, 3, 5] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}}
 
SOlevel25Cat1FMatrixFunction[2, 5, 4, 2] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[2, 5, 4, 3] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat1FMatrixFunction[2, 5, 5, 2] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[2, 5, 5, 3] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat1FMatrixFunction[3, 2, 1, 4] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[3, 2, 1, 5] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[3, 2, 2, 2] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0]}}
 
SOlevel25Cat1FMatrixFunction[3, 2, 2, 3] = 
   {{-(1/Sqrt[5]), -(1/Sqrt[5]), -(1/Sqrt[5])}, {2/Sqrt[5], (5 - Sqrt[5])/10, 
     (-5 - Sqrt[5])/10}, {2/Sqrt[5], (-5 - Sqrt[5])/10, (5 - Sqrt[5])/10}}
 
SOlevel25Cat1FMatrixFunction[3, 2, 3, 2] = 
   {{-(1/Sqrt[5]), -(1/Sqrt[5]), -(1/Sqrt[5])}, 
    {-2/Sqrt[5], (-5 + Sqrt[5])/10, (5 + Sqrt[5])/10}, 
    {-2/Sqrt[5], (5 + Sqrt[5])/10, (-5 + Sqrt[5])/10}}
 
SOlevel25Cat1FMatrixFunction[3, 2, 3, 3] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0]}}
 
SOlevel25Cat1FMatrixFunction[3, 2, 4, 4] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat1FMatrixFunction[3, 2, 4, 5] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat1FMatrixFunction[3, 2, 5, 4] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat1FMatrixFunction[3, 2, 5, 5] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat1FMatrixFunction[3, 3, 1, 4] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[3, 3, 1, 5] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[3, 3, 2, 2] = 
   {{-(1/Sqrt[5]), 1/Sqrt[5], 1/Sqrt[5]}, {-2/Sqrt[5], (5 - Sqrt[5])/10, 
     (-5 - Sqrt[5])/10}, {-2/Sqrt[5], (-5 - Sqrt[5])/10, (5 - Sqrt[5])/10}}
 
SOlevel25Cat1FMatrixFunction[3, 3, 2, 3] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0]}}
 
SOlevel25Cat1FMatrixFunction[3, 3, 3, 2] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0]}}
 
SOlevel25Cat1FMatrixFunction[3, 3, 3, 3] = 
   {{-(1/Sqrt[5]), 1/Sqrt[5], 1/Sqrt[5]}, {2/Sqrt[5], (-5 + Sqrt[5])/10, 
     (5 + Sqrt[5])/10}, {2/Sqrt[5], (5 + Sqrt[5])/10, (-5 + Sqrt[5])/10}}
 
SOlevel25Cat1FMatrixFunction[3, 3, 4, 4] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat1FMatrixFunction[3, 3, 4, 5] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat1FMatrixFunction[3, 3, 5, 4] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat1FMatrixFunction[3, 3, 5, 5] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat1FMatrixFunction[3, 4, 2, 4] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}}
 
SOlevel25Cat1FMatrixFunction[3, 4, 2, 5] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}}
 
SOlevel25Cat1FMatrixFunction[3, 4, 3, 4] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat1FMatrixFunction[3, 4, 3, 5] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat1FMatrixFunction[3, 4, 4, 2] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[3, 4, 4, 3] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[3, 4, 5, 2] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat1FMatrixFunction[3, 4, 5, 3] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[3, 5, 2, 4] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}}
 
SOlevel25Cat1FMatrixFunction[3, 5, 2, 5] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}}
 
SOlevel25Cat1FMatrixFunction[3, 5, 3, 4] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat1FMatrixFunction[3, 5, 3, 5] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat1FMatrixFunction[3, 5, 4, 2] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat1FMatrixFunction[3, 5, 4, 3] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[3, 5, 5, 2] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat1FMatrixFunction[3, 5, 5, 3] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[4, 1, 4, 0] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[4, 1, 4, 1] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[4, 1, 5, 4] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[4, 2, 2, 1] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[4, 2, 2, 4] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[4, 2, 2, 5] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[4, 2, 3, 1] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[4, 2, 3, 4] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[4, 2, 3, 5] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat1FMatrixFunction[4, 2, 4, 2] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat1FMatrixFunction[4, 2, 4, 3] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}}
 
SOlevel25Cat1FMatrixFunction[4, 2, 5, 2] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat1FMatrixFunction[4, 2, 5, 3] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}}
 
SOlevel25Cat1FMatrixFunction[4, 3, 2, 1] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[4, 3, 2, 4] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[4, 3, 2, 5] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat1FMatrixFunction[4, 3, 3, 1] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[4, 3, 3, 4] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[4, 3, 3, 5] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[4, 3, 4, 2] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}}
 
SOlevel25Cat1FMatrixFunction[4, 3, 4, 3] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat1FMatrixFunction[4, 3, 5, 2] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}}
 
SOlevel25Cat1FMatrixFunction[4, 3, 5, 3] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat1FMatrixFunction[4, 4, 2, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat1FMatrixFunction[4, 4, 2, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat1FMatrixFunction[4, 4, 3, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat1FMatrixFunction[4, 4, 3, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat1FMatrixFunction[4, 4, 4, 4] = {{1/2, -1/2, -1}, {1/2, -1/2, 1}, 
    {-1/2, -1/2, 0}}
 
SOlevel25Cat1FMatrixFunction[4, 4, 5, 5] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[4, 5, 1, 5] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[4, 5, 2, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat1FMatrixFunction[4, 5, 2, 3] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat1FMatrixFunction[4, 5, 3, 2] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat1FMatrixFunction[4, 5, 3, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat1FMatrixFunction[4, 5, 4, 1] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[4, 5, 4, 5] = {{0, 1}, {1, 0}}
 
SOlevel25Cat1FMatrixFunction[4, 5, 5, 1] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[4, 5, 5, 4] = {{-1, -1}, {-1, 1}}
 
SOlevel25Cat1FMatrixFunction[5, 1, 4, 4] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[5, 1, 5, 0] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[5, 1, 5, 1] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[5, 2, 2, 1] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[5, 2, 2, 4] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[5, 2, 2, 5] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[5, 2, 3, 1] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[5, 2, 3, 4] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat1FMatrixFunction[5, 2, 3, 5] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat1FMatrixFunction[5, 2, 4, 2] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat1FMatrixFunction[5, 2, 4, 3] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}}
 
SOlevel25Cat1FMatrixFunction[5, 2, 5, 2] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat1FMatrixFunction[5, 2, 5, 3] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}}
 
SOlevel25Cat1FMatrixFunction[5, 3, 2, 1] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[5, 3, 2, 4] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat1FMatrixFunction[5, 3, 2, 5] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat1FMatrixFunction[5, 3, 3, 1] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[5, 3, 3, 4] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[5, 3, 3, 5] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[5, 3, 4, 2] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}}
 
SOlevel25Cat1FMatrixFunction[5, 3, 4, 3] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat1FMatrixFunction[5, 3, 5, 2] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}}
 
SOlevel25Cat1FMatrixFunction[5, 3, 5, 3] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat1FMatrixFunction[5, 4, 1, 4] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[5, 4, 1, 5] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[5, 4, 2, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat1FMatrixFunction[5, 4, 2, 3] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat1FMatrixFunction[5, 4, 3, 2] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat1FMatrixFunction[5, 4, 3, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat1FMatrixFunction[5, 4, 4, 5] = {{-1, -1}, {-1, 1}}
 
SOlevel25Cat1FMatrixFunction[5, 4, 5, 1] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[5, 4, 5, 4] = {{0, 1}, {1, 0}}
 
SOlevel25Cat1FMatrixFunction[5, 5, 1, 4] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[5, 5, 2, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat1FMatrixFunction[5, 5, 2, 3] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat1FMatrixFunction[5, 5, 3, 2] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat1FMatrixFunction[5, 5, 3, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat1FMatrixFunction[5, 5, 4, 1] = {{-1}}
 
SOlevel25Cat1FMatrixFunction[5, 5, 4, 4] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat1FMatrixFunction[5, 5, 5, 5] = {{1/2, -1/2, -1}, {1/2, -1/2, 1}, 
    {-1/2, -1/2, 0}}
 
SOlevel25Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SOlevel25Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
SOlevel25Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SOlevel25Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[SOlevel25Cat1Piv1] ^= {SOlevel25Cat1Bal1, 
    SOlevel25Cat1Bal3, SOlevel25Cat1Bal5, SOlevel25Cat1Bal7}
 
SOlevel25Cat1Piv1 /: balancedCategory[SOlevel25Cat1Piv1, 1] = 
    SOlevel25Cat1Bal1
 
SOlevel25Cat1Piv1 /: balancedCategory[SOlevel25Cat1Piv1, 2] = 
    SOlevel25Cat1Bal3
 
SOlevel25Cat1Piv1 /: balancedCategory[SOlevel25Cat1Piv1, 3] = 
    SOlevel25Cat1Bal5
 
SOlevel25Cat1Piv1 /: balancedCategory[SOlevel25Cat1Piv1, 4] = 
    SOlevel25Cat1Bal7
 
fusionCategory[SOlevel25Cat1Piv1] ^= SOlevel25Cat1
 
SOlevel25Cat1Piv1 /: modularCategory[SOlevel25Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SOlevel25Cat1Piv1] ^= SOlevel25Cat1Piv1
 
pivotalIsomorphism[SOlevel25Cat1Piv1] ^= SOlevel25Cat1Piv1PivotalIsomorphism
 
SOlevel25Cat1Piv1 /: ribbonCategory[SOlevel25Cat1Piv1, 1] = SOlevel25Cat1Bal1
 
SOlevel25Cat1Piv1 /: ribbonCategory[SOlevel25Cat1Piv1, 2] = SOlevel25Cat1Bal3
 
SOlevel25Cat1Piv1 /: ribbonCategory[SOlevel25Cat1Piv1, 3] = SOlevel25Cat1Bal5
 
SOlevel25Cat1Piv1 /: ribbonCategory[SOlevel25Cat1Piv1, 4] = SOlevel25Cat1Bal7
 
ring[SOlevel25Cat1Piv1] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat1Piv1] ^= SOlevel25Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[SOlevel25Cat1]][pivotalCategory[#1]] & )[
    SOlevel25Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[SOlevel25Cat1]][
      sphericalCategory[#1]] & )[SOlevel25Cat1Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[SOlevel25Cat1Piv1PivotalIsomorphism] ^= SOlevel25Cat1
 
pivotalCategory[SOlevel25Cat1Piv1PivotalIsomorphism] ^= SOlevel25Cat1Piv1
 
pivotalIsomorphism[SOlevel25Cat1Piv1PivotalIsomorphism] ^= 
   SOlevel25Cat1Piv1PivotalIsomorphism
 
SOlevel25Cat1Piv1PivotalIsomorphism[0] = 1
 
SOlevel25Cat1Piv1PivotalIsomorphism[1] = 1
 
SOlevel25Cat1Piv1PivotalIsomorphism[2] = 1
 
SOlevel25Cat1Piv1PivotalIsomorphism[3] = 1
 
SOlevel25Cat1Piv1PivotalIsomorphism[4] = 1
 
SOlevel25Cat1Piv1PivotalIsomorphism[5] = 1
balancedCategories[SOlevel25Cat1Piv2] ^= {SOlevel25Cat1Bal2, 
    SOlevel25Cat1Bal4, SOlevel25Cat1Bal6, SOlevel25Cat1Bal8}
 
SOlevel25Cat1Piv2 /: balancedCategory[SOlevel25Cat1Piv2, 1] = 
    SOlevel25Cat1Bal2
 
SOlevel25Cat1Piv2 /: balancedCategory[SOlevel25Cat1Piv2, 2] = 
    SOlevel25Cat1Bal4
 
SOlevel25Cat1Piv2 /: balancedCategory[SOlevel25Cat1Piv2, 3] = 
    SOlevel25Cat1Bal6
 
SOlevel25Cat1Piv2 /: balancedCategory[SOlevel25Cat1Piv2, 4] = 
    SOlevel25Cat1Bal8
 
fusionCategory[SOlevel25Cat1Piv2] ^= SOlevel25Cat1
 
SOlevel25Cat1Piv2 /: modularCategory[SOlevel25Cat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SOlevel25Cat1Piv2] ^= SOlevel25Cat1Piv2
 
pivotalIsomorphism[SOlevel25Cat1Piv2] ^= SOlevel25Cat1Piv2PivotalIsomorphism
 
SOlevel25Cat1Piv2 /: ribbonCategory[SOlevel25Cat1Piv2, 1] = SOlevel25Cat1Bal2
 
SOlevel25Cat1Piv2 /: ribbonCategory[SOlevel25Cat1Piv2, 2] = SOlevel25Cat1Bal4
 
SOlevel25Cat1Piv2 /: ribbonCategory[SOlevel25Cat1Piv2, 3] = SOlevel25Cat1Bal6
 
SOlevel25Cat1Piv2 /: ribbonCategory[SOlevel25Cat1Piv2, 4] = SOlevel25Cat1Bal8
 
ring[SOlevel25Cat1Piv2] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat1Piv2] ^= SOlevel25Cat1Piv2
 
(pivotalCategoryIndex[fusionCategory[SOlevel25Cat1]][pivotalCategory[#1]] & )[
    SOlevel25Cat1Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[SOlevel25Cat1]][
      sphericalCategory[#1]] & )[SOlevel25Cat1Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[SOlevel25Cat1Piv2PivotalIsomorphism] ^= SOlevel25Cat1
 
pivotalCategory[SOlevel25Cat1Piv2PivotalIsomorphism] ^= SOlevel25Cat1Piv2
 
pivotalIsomorphism[SOlevel25Cat1Piv2PivotalIsomorphism] ^= 
   SOlevel25Cat1Piv2PivotalIsomorphism
 
SOlevel25Cat1Piv2PivotalIsomorphism[0] = 1
 
SOlevel25Cat1Piv2PivotalIsomorphism[1] = 1
 
SOlevel25Cat1Piv2PivotalIsomorphism[2] = -1
 
SOlevel25Cat1Piv2PivotalIsomorphism[3] = -1
 
SOlevel25Cat1Piv2PivotalIsomorphism[4] = 1
 
SOlevel25Cat1Piv2PivotalIsomorphism[5] = 1
balancedCategories[SOlevel25Cat2] ^= {SOlevel25Cat2Bal1, SOlevel25Cat2Bal2, 
    SOlevel25Cat2Bal3, SOlevel25Cat2Bal4, SOlevel25Cat2Bal5, 
    SOlevel25Cat2Bal6, SOlevel25Cat2Bal7, SOlevel25Cat2Bal8}
 
SOlevel25Cat2 /: balancedCategory[SOlevel25Cat2, 1] = SOlevel25Cat2Bal1
 
SOlevel25Cat2 /: balancedCategory[SOlevel25Cat2, 2] = SOlevel25Cat2Bal2
 
SOlevel25Cat2 /: balancedCategory[SOlevel25Cat2, 3] = SOlevel25Cat2Bal3
 
SOlevel25Cat2 /: balancedCategory[SOlevel25Cat2, 4] = SOlevel25Cat2Bal4
 
SOlevel25Cat2 /: balancedCategory[SOlevel25Cat2, 5] = SOlevel25Cat2Bal5
 
SOlevel25Cat2 /: balancedCategory[SOlevel25Cat2, 6] = SOlevel25Cat2Bal6
 
SOlevel25Cat2 /: balancedCategory[SOlevel25Cat2, 7] = SOlevel25Cat2Bal7
 
SOlevel25Cat2 /: balancedCategory[SOlevel25Cat2, 8] = SOlevel25Cat2Bal8
 
braidedCategories[SOlevel25Cat2] ^= {SOlevel25Cat2Brd1, SOlevel25Cat2Brd2, 
    SOlevel25Cat2Brd3, SOlevel25Cat2Brd4}
 
SOlevel25Cat2 /: braidedCategory[SOlevel25Cat2, 1] = SOlevel25Cat2Brd1
 
SOlevel25Cat2 /: braidedCategory[SOlevel25Cat2, 2] = SOlevel25Cat2Brd2
 
SOlevel25Cat2 /: braidedCategory[SOlevel25Cat2, 3] = SOlevel25Cat2Brd3
 
SOlevel25Cat2 /: braidedCategory[SOlevel25Cat2, 4] = SOlevel25Cat2Brd4
 
coeval[SOlevel25Cat2] ^= 1/sixJFunction[SOlevel25Cat2][#1, 
      dual[ring[SOlevel25Cat2]][#1], #1, #1, 0, 0] & 
 
eval[SOlevel25Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[SOlevel25Cat2] ^= SOlevel25Cat2FMatrixFunction
 
fusionCategory[SOlevel25Cat2] ^= SOlevel25Cat2
 
SOlevel25Cat2 /: modularCategory[SOlevel25Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[SOlevel25Cat2] ^= {SOlevel25Cat2Piv1, SOlevel25Cat2Piv2}
 
SOlevel25Cat2 /: pivotalCategory[SOlevel25Cat2, 1] = SOlevel25Cat2Piv1
 
SOlevel25Cat2 /: pivotalCategory[SOlevel25Cat2, 2] = SOlevel25Cat2Piv2
 
SOlevel25Cat2 /: pivotalCategory[SOlevel25Cat2, {1, 1, -1, -1, 1, 1}] = 
    SOlevel25Cat2Piv2
 
SOlevel25Cat2 /: pivotalCategory[SOlevel25Cat2, {1, 1, 1, 1, 1, 1}] = 
    SOlevel25Cat2Piv1
 
SOlevel25Cat2 /: ribbonCategory[SOlevel25Cat2, 1] = SOlevel25Cat2Bal1
 
SOlevel25Cat2 /: ribbonCategory[SOlevel25Cat2, 2] = SOlevel25Cat2Bal2
 
SOlevel25Cat2 /: ribbonCategory[SOlevel25Cat2, 3] = SOlevel25Cat2Bal3
 
SOlevel25Cat2 /: ribbonCategory[SOlevel25Cat2, 4] = SOlevel25Cat2Bal4
 
SOlevel25Cat2 /: ribbonCategory[SOlevel25Cat2, 5] = SOlevel25Cat2Bal5
 
SOlevel25Cat2 /: ribbonCategory[SOlevel25Cat2, 6] = SOlevel25Cat2Bal6
 
SOlevel25Cat2 /: ribbonCategory[SOlevel25Cat2, 7] = SOlevel25Cat2Bal7
 
SOlevel25Cat2 /: ribbonCategory[SOlevel25Cat2, 8] = SOlevel25Cat2Bal8
 
ring[SOlevel25Cat2] ^= SOlevel25
 
SOlevel25Cat2 /: sphericalCategory[SOlevel25Cat2, 1] = SOlevel25Cat2Piv1
 
SOlevel25Cat2 /: sphericalCategory[SOlevel25Cat2, 2] = SOlevel25Cat2Piv2
 
fusionCategoryIndex[SOlevel25][SOlevel25Cat2] ^= 2
balancedCategory[SOlevel25Cat2Bal1] ^= SOlevel25Cat2Bal1
 
braidedCategory[SOlevel25Cat2Bal1] ^= SOlevel25Cat2Brd1
 
fusionCategory[SOlevel25Cat2Bal1] ^= SOlevel25Cat2
 
pivotalCategory[SOlevel25Cat2Bal1] ^= SOlevel25Cat2Piv1
 
ribbonCategory[SOlevel25Cat2Bal1] ^= SOlevel25Cat2Bal1
 
ring[SOlevel25Cat2Bal1] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat2Bal1] ^= SOlevel25Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat2Brd1]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat2]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat2Piv1]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat2Brd1]][
      ribbonCategory[#1]] & )[SOlevel25Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat2]][ribbonCategory[#1]] & )[
    SOlevel25Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat2Piv1]][
      ribbonCategory[#1]] & )[SOlevel25Cat2Bal1] ^= 1
balancedCategory[SOlevel25Cat2Bal2] ^= SOlevel25Cat2Bal2
 
braidedCategory[SOlevel25Cat2Bal2] ^= SOlevel25Cat2Brd1
 
fusionCategory[SOlevel25Cat2Bal2] ^= SOlevel25Cat2
 
pivotalCategory[SOlevel25Cat2Bal2] ^= SOlevel25Cat2Piv2
 
ribbonCategory[SOlevel25Cat2Bal2] ^= SOlevel25Cat2Bal2
 
ring[SOlevel25Cat2Bal2] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat2Bal2] ^= SOlevel25Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat2Brd1]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat2]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat2Piv2]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat2Brd1]][
      ribbonCategory[#1]] & )[SOlevel25Cat2Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat2]][ribbonCategory[#1]] & )[
    SOlevel25Cat2Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat2Piv2]][
      ribbonCategory[#1]] & )[SOlevel25Cat2Bal2] ^= 1
balancedCategory[SOlevel25Cat2Bal3] ^= SOlevel25Cat2Bal3
 
braidedCategory[SOlevel25Cat2Bal3] ^= SOlevel25Cat2Brd2
 
fusionCategory[SOlevel25Cat2Bal3] ^= SOlevel25Cat2
 
pivotalCategory[SOlevel25Cat2Bal3] ^= SOlevel25Cat2Piv1
 
ribbonCategory[SOlevel25Cat2Bal3] ^= SOlevel25Cat2Bal3
 
ring[SOlevel25Cat2Bal3] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat2Bal3] ^= SOlevel25Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat2Brd2]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat2]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat2Piv1]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat2Brd2]][
      ribbonCategory[#1]] & )[SOlevel25Cat2Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat2]][ribbonCategory[#1]] & )[
    SOlevel25Cat2Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat2Piv1]][
      ribbonCategory[#1]] & )[SOlevel25Cat2Bal3] ^= 2
balancedCategory[SOlevel25Cat2Bal4] ^= SOlevel25Cat2Bal4
 
braidedCategory[SOlevel25Cat2Bal4] ^= SOlevel25Cat2Brd2
 
fusionCategory[SOlevel25Cat2Bal4] ^= SOlevel25Cat2
 
pivotalCategory[SOlevel25Cat2Bal4] ^= SOlevel25Cat2Piv2
 
ribbonCategory[SOlevel25Cat2Bal4] ^= SOlevel25Cat2Bal4
 
ring[SOlevel25Cat2Bal4] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat2Bal4] ^= SOlevel25Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat2Brd2]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat2]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat2Piv2]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat2Brd2]][
      ribbonCategory[#1]] & )[SOlevel25Cat2Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat2]][ribbonCategory[#1]] & )[
    SOlevel25Cat2Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat2Piv2]][
      ribbonCategory[#1]] & )[SOlevel25Cat2Bal4] ^= 2
balancedCategory[SOlevel25Cat2Bal5] ^= SOlevel25Cat2Bal5
 
braidedCategory[SOlevel25Cat2Bal5] ^= SOlevel25Cat2Brd3
 
fusionCategory[SOlevel25Cat2Bal5] ^= SOlevel25Cat2
 
pivotalCategory[SOlevel25Cat2Bal5] ^= SOlevel25Cat2Piv1
 
ribbonCategory[SOlevel25Cat2Bal5] ^= SOlevel25Cat2Bal5
 
ring[SOlevel25Cat2Bal5] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat2Bal5] ^= SOlevel25Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat2Brd3]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat2]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat2Piv1]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal5] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat2Brd3]][
      ribbonCategory[#1]] & )[SOlevel25Cat2Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat2]][ribbonCategory[#1]] & )[
    SOlevel25Cat2Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat2Piv1]][
      ribbonCategory[#1]] & )[SOlevel25Cat2Bal5] ^= 3
balancedCategory[SOlevel25Cat2Bal6] ^= SOlevel25Cat2Bal6
 
braidedCategory[SOlevel25Cat2Bal6] ^= SOlevel25Cat2Brd3
 
fusionCategory[SOlevel25Cat2Bal6] ^= SOlevel25Cat2
 
pivotalCategory[SOlevel25Cat2Bal6] ^= SOlevel25Cat2Piv2
 
ribbonCategory[SOlevel25Cat2Bal6] ^= SOlevel25Cat2Bal6
 
ring[SOlevel25Cat2Bal6] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat2Bal6] ^= SOlevel25Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat2Brd3]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat2]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat2Piv2]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal6] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat2Brd3]][
      ribbonCategory[#1]] & )[SOlevel25Cat2Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat2]][ribbonCategory[#1]] & )[
    SOlevel25Cat2Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat2Piv2]][
      ribbonCategory[#1]] & )[SOlevel25Cat2Bal6] ^= 3
balancedCategory[SOlevel25Cat2Bal7] ^= SOlevel25Cat2Bal7
 
braidedCategory[SOlevel25Cat2Bal7] ^= SOlevel25Cat2Brd4
 
fusionCategory[SOlevel25Cat2Bal7] ^= SOlevel25Cat2
 
pivotalCategory[SOlevel25Cat2Bal7] ^= SOlevel25Cat2Piv1
 
ribbonCategory[SOlevel25Cat2Bal7] ^= SOlevel25Cat2Bal7
 
ring[SOlevel25Cat2Bal7] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat2Bal7] ^= SOlevel25Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat2Brd4]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat2]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat2Piv1]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal7] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat2Brd4]][
      ribbonCategory[#1]] & )[SOlevel25Cat2Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat2]][ribbonCategory[#1]] & )[
    SOlevel25Cat2Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat2Piv1]][
      ribbonCategory[#1]] & )[SOlevel25Cat2Bal7] ^= 4
balancedCategory[SOlevel25Cat2Bal8] ^= SOlevel25Cat2Bal8
 
braidedCategory[SOlevel25Cat2Bal8] ^= SOlevel25Cat2Brd4
 
fusionCategory[SOlevel25Cat2Bal8] ^= SOlevel25Cat2
 
pivotalCategory[SOlevel25Cat2Bal8] ^= SOlevel25Cat2Piv2
 
ribbonCategory[SOlevel25Cat2Bal8] ^= SOlevel25Cat2Bal8
 
ring[SOlevel25Cat2Bal8] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat2Bal8] ^= SOlevel25Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat2Brd4]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat2]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat2Piv2]][
      balancedCategory[#1]] & )[SOlevel25Cat2Bal8] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat2Brd4]][
      ribbonCategory[#1]] & )[SOlevel25Cat2Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat2]][ribbonCategory[#1]] & )[
    SOlevel25Cat2Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat2Piv2]][
      ribbonCategory[#1]] & )[SOlevel25Cat2Bal8] ^= 4
balancedCategories[SOlevel25Cat2Brd1] ^= {SOlevel25Cat2Bal1, 
    SOlevel25Cat2Bal2}
 
SOlevel25Cat2Brd1 /: balancedCategory[SOlevel25Cat2Brd1, 1] = 
    SOlevel25Cat2Bal1
 
SOlevel25Cat2Brd1 /: balancedCategory[SOlevel25Cat2Brd1, 2] = 
    SOlevel25Cat2Bal2
 
braidedCategory[SOlevel25Cat2Brd1] ^= SOlevel25Cat2Brd1
 
fusionCategory[SOlevel25Cat2Brd1] ^= SOlevel25Cat2
 
SOlevel25Cat2Brd1 /: modularCategory[SOlevel25Cat2Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel25Cat2Brd1 /: ribbonCategory[SOlevel25Cat2Brd1, 1] = SOlevel25Cat2Bal1
 
SOlevel25Cat2Brd1 /: ribbonCategory[SOlevel25Cat2Brd1, 2] = SOlevel25Cat2Bal2
 
ring[SOlevel25Cat2Brd1] ^= SOlevel25
 
rMatrixFunction[SOlevel25Cat2Brd1] ^= SOlevel25Cat2Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel25Cat2]][braidedCategory[#1]] & )[
    SOlevel25Cat2Brd1] ^= 1
braidedCategory[SOlevel25Cat2Brd1RMatrixFunction] ^= SOlevel25Cat2Brd1
 
fusionCategory[SOlevel25Cat2Brd1RMatrixFunction] ^= SOlevel25Cat2
 
rMatrixFunction[SOlevel25Cat2Brd1RMatrixFunction] ^= 
   SOlevel25Cat2Brd1RMatrixFunction
 
SOlevel25Cat2Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel25Cat2Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel25Cat2Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel25Cat2Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel25Cat2Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel25Cat2Brd1RMatrixFunction[0, 5, 5] = {{1}}
 
SOlevel25Cat2Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel25Cat2Brd1RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel25Cat2Brd1RMatrixFunction[1, 2, 3] = {{-1}}
 
SOlevel25Cat2Brd1RMatrixFunction[1, 3, 2] = {{-1}}
 
SOlevel25Cat2Brd1RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel25Cat2Brd1RMatrixFunction[1, 5, 5] = {{1}}
 
SOlevel25Cat2Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel25Cat2Brd1RMatrixFunction[2, 1, 3] = {{1}}
 
SOlevel25Cat2Brd1RMatrixFunction[2, 2, 0] = {{I}}
 
SOlevel25Cat2Brd1RMatrixFunction[2, 2, 4] = {{(-1)^(1/10)}}
 
SOlevel25Cat2Brd1RMatrixFunction[2, 2, 5] = {{(-1)^(9/10)}}
 
SOlevel25Cat2Brd1RMatrixFunction[2, 3, 1] = {{I}}
 
SOlevel25Cat2Brd1RMatrixFunction[2, 3, 4] = {{(-1)^(1/10)}}
 
SOlevel25Cat2Brd1RMatrixFunction[2, 3, 5] = {{(-1)^(9/10)}}
 
SOlevel25Cat2Brd1RMatrixFunction[2, 4, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[2, 4, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[2, 5, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[2, 5, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel25Cat2Brd1RMatrixFunction[3, 1, 2] = {{1}}
 
SOlevel25Cat2Brd1RMatrixFunction[3, 2, 1] = {{-I}}
 
SOlevel25Cat2Brd1RMatrixFunction[3, 2, 4] = {{-(-1)^(1/10)}}
 
SOlevel25Cat2Brd1RMatrixFunction[3, 2, 5] = {{-(-1)^(9/10)}}
 
SOlevel25Cat2Brd1RMatrixFunction[3, 3, 0] = {{-I}}
 
SOlevel25Cat2Brd1RMatrixFunction[3, 3, 4] = {{-(-1)^(1/10)}}
 
SOlevel25Cat2Brd1RMatrixFunction[3, 3, 5] = {{-(-1)^(9/10)}}
 
SOlevel25Cat2Brd1RMatrixFunction[3, 4, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[3, 4, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[3, 5, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[3, 5, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel25Cat2Brd1RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel25Cat2Brd1RMatrixFunction[4, 2, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[4, 2, 3] = {{-(-1)^(2/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[4, 3, 2] = {{-(-1)^(2/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[4, 3, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[4, 4, 0] = {{(-1)^(4/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[4, 4, 1] = {{-(-1)^(4/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[4, 4, 5] = {{-(-1)^(1/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[4, 5, 4] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[4, 5, 5] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[5, 0, 5] = {{1}}
 
SOlevel25Cat2Brd1RMatrixFunction[5, 1, 5] = {{1}}
 
SOlevel25Cat2Brd1RMatrixFunction[5, 2, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[5, 2, 3] = {{(-1)^(3/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[5, 3, 2] = {{(-1)^(3/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[5, 3, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[5, 4, 4] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[5, 4, 5] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[5, 5, 0] = {{-(-1)^(1/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[5, 5, 1] = {{(-1)^(1/5)}}
 
SOlevel25Cat2Brd1RMatrixFunction[5, 5, 4] = {{(-1)^(4/5)}}
balancedCategories[SOlevel25Cat2Brd2] ^= {SOlevel25Cat2Bal3, 
    SOlevel25Cat2Bal4}
 
SOlevel25Cat2Brd2 /: balancedCategory[SOlevel25Cat2Brd2, 1] = 
    SOlevel25Cat2Bal3
 
SOlevel25Cat2Brd2 /: balancedCategory[SOlevel25Cat2Brd2, 2] = 
    SOlevel25Cat2Bal4
 
braidedCategory[SOlevel25Cat2Brd2] ^= SOlevel25Cat2Brd2
 
fusionCategory[SOlevel25Cat2Brd2] ^= SOlevel25Cat2
 
SOlevel25Cat2Brd2 /: modularCategory[SOlevel25Cat2Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel25Cat2Brd2 /: ribbonCategory[SOlevel25Cat2Brd2, 1] = SOlevel25Cat2Bal3
 
SOlevel25Cat2Brd2 /: ribbonCategory[SOlevel25Cat2Brd2, 2] = SOlevel25Cat2Bal4
 
ring[SOlevel25Cat2Brd2] ^= SOlevel25
 
rMatrixFunction[SOlevel25Cat2Brd2] ^= SOlevel25Cat2Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel25Cat2]][braidedCategory[#1]] & )[
    SOlevel25Cat2Brd2] ^= 2
braidedCategory[SOlevel25Cat2Brd2RMatrixFunction] ^= SOlevel25Cat2Brd2
 
fusionCategory[SOlevel25Cat2Brd2RMatrixFunction] ^= SOlevel25Cat2
 
rMatrixFunction[SOlevel25Cat2Brd2RMatrixFunction] ^= 
   SOlevel25Cat2Brd2RMatrixFunction
 
SOlevel25Cat2Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel25Cat2Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel25Cat2Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel25Cat2Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel25Cat2Brd2RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel25Cat2Brd2RMatrixFunction[0, 5, 5] = {{1}}
 
SOlevel25Cat2Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel25Cat2Brd2RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel25Cat2Brd2RMatrixFunction[1, 2, 3] = {{-1}}
 
SOlevel25Cat2Brd2RMatrixFunction[1, 3, 2] = {{-1}}
 
SOlevel25Cat2Brd2RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel25Cat2Brd2RMatrixFunction[1, 5, 5] = {{1}}
 
SOlevel25Cat2Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel25Cat2Brd2RMatrixFunction[2, 1, 3] = {{1}}
 
SOlevel25Cat2Brd2RMatrixFunction[2, 2, 0] = {{-I}}
 
SOlevel25Cat2Brd2RMatrixFunction[2, 2, 4] = {{-(-1)^(1/10)}}
 
SOlevel25Cat2Brd2RMatrixFunction[2, 2, 5] = {{-(-1)^(9/10)}}
 
SOlevel25Cat2Brd2RMatrixFunction[2, 3, 1] = {{-I}}
 
SOlevel25Cat2Brd2RMatrixFunction[2, 3, 4] = {{-(-1)^(1/10)}}
 
SOlevel25Cat2Brd2RMatrixFunction[2, 3, 5] = {{-(-1)^(9/10)}}
 
SOlevel25Cat2Brd2RMatrixFunction[2, 4, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[2, 4, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[2, 5, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[2, 5, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel25Cat2Brd2RMatrixFunction[3, 1, 2] = {{1}}
 
SOlevel25Cat2Brd2RMatrixFunction[3, 2, 1] = {{I}}
 
SOlevel25Cat2Brd2RMatrixFunction[3, 2, 4] = {{(-1)^(1/10)}}
 
SOlevel25Cat2Brd2RMatrixFunction[3, 2, 5] = {{(-1)^(9/10)}}
 
SOlevel25Cat2Brd2RMatrixFunction[3, 3, 0] = {{I}}
 
SOlevel25Cat2Brd2RMatrixFunction[3, 3, 4] = {{(-1)^(1/10)}}
 
SOlevel25Cat2Brd2RMatrixFunction[3, 3, 5] = {{(-1)^(9/10)}}
 
SOlevel25Cat2Brd2RMatrixFunction[3, 4, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[3, 4, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[3, 5, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[3, 5, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel25Cat2Brd2RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel25Cat2Brd2RMatrixFunction[4, 2, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[4, 2, 3] = {{-(-1)^(2/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[4, 3, 2] = {{-(-1)^(2/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[4, 3, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[4, 4, 0] = {{(-1)^(4/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[4, 4, 1] = {{-(-1)^(4/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[4, 4, 5] = {{-(-1)^(1/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[4, 5, 4] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[4, 5, 5] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[5, 0, 5] = {{1}}
 
SOlevel25Cat2Brd2RMatrixFunction[5, 1, 5] = {{1}}
 
SOlevel25Cat2Brd2RMatrixFunction[5, 2, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[5, 2, 3] = {{(-1)^(3/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[5, 3, 2] = {{(-1)^(3/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[5, 3, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[5, 4, 4] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[5, 4, 5] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[5, 5, 0] = {{-(-1)^(1/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[5, 5, 1] = {{(-1)^(1/5)}}
 
SOlevel25Cat2Brd2RMatrixFunction[5, 5, 4] = {{(-1)^(4/5)}}
balancedCategories[SOlevel25Cat2Brd3] ^= {SOlevel25Cat2Bal5, 
    SOlevel25Cat2Bal6}
 
SOlevel25Cat2Brd3 /: balancedCategory[SOlevel25Cat2Brd3, 1] = 
    SOlevel25Cat2Bal5
 
SOlevel25Cat2Brd3 /: balancedCategory[SOlevel25Cat2Brd3, 2] = 
    SOlevel25Cat2Bal6
 
braidedCategory[SOlevel25Cat2Brd3] ^= SOlevel25Cat2Brd3
 
fusionCategory[SOlevel25Cat2Brd3] ^= SOlevel25Cat2
 
SOlevel25Cat2Brd3 /: modularCategory[SOlevel25Cat2Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel25Cat2Brd3 /: ribbonCategory[SOlevel25Cat2Brd3, 1] = SOlevel25Cat2Bal5
 
SOlevel25Cat2Brd3 /: ribbonCategory[SOlevel25Cat2Brd3, 2] = SOlevel25Cat2Bal6
 
ring[SOlevel25Cat2Brd3] ^= SOlevel25
 
rMatrixFunction[SOlevel25Cat2Brd3] ^= SOlevel25Cat2Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel25Cat2]][braidedCategory[#1]] & )[
    SOlevel25Cat2Brd3] ^= 3
braidedCategory[SOlevel25Cat2Brd3RMatrixFunction] ^= SOlevel25Cat2Brd3
 
fusionCategory[SOlevel25Cat2Brd3RMatrixFunction] ^= SOlevel25Cat2
 
rMatrixFunction[SOlevel25Cat2Brd3RMatrixFunction] ^= 
   SOlevel25Cat2Brd3RMatrixFunction
 
SOlevel25Cat2Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel25Cat2Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel25Cat2Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel25Cat2Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel25Cat2Brd3RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel25Cat2Brd3RMatrixFunction[0, 5, 5] = {{1}}
 
SOlevel25Cat2Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel25Cat2Brd3RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel25Cat2Brd3RMatrixFunction[1, 2, 3] = {{1}}
 
SOlevel25Cat2Brd3RMatrixFunction[1, 3, 2] = {{1}}
 
SOlevel25Cat2Brd3RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel25Cat2Brd3RMatrixFunction[1, 5, 5] = {{1}}
 
SOlevel25Cat2Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel25Cat2Brd3RMatrixFunction[2, 1, 3] = {{-1}}
 
SOlevel25Cat2Brd3RMatrixFunction[2, 2, 0] = {{-I}}
 
SOlevel25Cat2Brd3RMatrixFunction[2, 2, 4] = {{-(-1)^(9/10)}}
 
SOlevel25Cat2Brd3RMatrixFunction[2, 2, 5] = {{-(-1)^(1/10)}}
 
SOlevel25Cat2Brd3RMatrixFunction[2, 3, 1] = {{I}}
 
SOlevel25Cat2Brd3RMatrixFunction[2, 3, 4] = {{(-1)^(9/10)}}
 
SOlevel25Cat2Brd3RMatrixFunction[2, 3, 5] = {{(-1)^(1/10)}}
 
SOlevel25Cat2Brd3RMatrixFunction[2, 4, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[2, 4, 3] = {{(-1)^(3/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[2, 5, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[2, 5, 3] = {{-(-1)^(2/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel25Cat2Brd3RMatrixFunction[3, 1, 2] = {{-1}}
 
SOlevel25Cat2Brd3RMatrixFunction[3, 2, 1] = {{-I}}
 
SOlevel25Cat2Brd3RMatrixFunction[3, 2, 4] = {{-(-1)^(9/10)}}
 
SOlevel25Cat2Brd3RMatrixFunction[3, 2, 5] = {{-(-1)^(1/10)}}
 
SOlevel25Cat2Brd3RMatrixFunction[3, 3, 0] = {{I}}
 
SOlevel25Cat2Brd3RMatrixFunction[3, 3, 4] = {{(-1)^(9/10)}}
 
SOlevel25Cat2Brd3RMatrixFunction[3, 3, 5] = {{(-1)^(1/10)}}
 
SOlevel25Cat2Brd3RMatrixFunction[3, 4, 2] = {{(-1)^(3/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[3, 4, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[3, 5, 2] = {{-(-1)^(2/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[3, 5, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel25Cat2Brd3RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel25Cat2Brd3RMatrixFunction[4, 2, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[4, 2, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[4, 3, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[4, 3, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[4, 4, 0] = {{-(-1)^(1/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[4, 4, 1] = {{(-1)^(1/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[4, 4, 5] = {{(-1)^(4/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[4, 5, 4] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[4, 5, 5] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[5, 0, 5] = {{1}}
 
SOlevel25Cat2Brd3RMatrixFunction[5, 1, 5] = {{1}}
 
SOlevel25Cat2Brd3RMatrixFunction[5, 2, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[5, 2, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[5, 3, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[5, 3, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[5, 4, 4] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[5, 4, 5] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[5, 5, 0] = {{(-1)^(4/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[5, 5, 1] = {{-(-1)^(4/5)}}
 
SOlevel25Cat2Brd3RMatrixFunction[5, 5, 4] = {{-(-1)^(1/5)}}
balancedCategories[SOlevel25Cat2Brd4] ^= {SOlevel25Cat2Bal7, 
    SOlevel25Cat2Bal8}
 
SOlevel25Cat2Brd4 /: balancedCategory[SOlevel25Cat2Brd4, 1] = 
    SOlevel25Cat2Bal7
 
SOlevel25Cat2Brd4 /: balancedCategory[SOlevel25Cat2Brd4, 2] = 
    SOlevel25Cat2Bal8
 
braidedCategory[SOlevel25Cat2Brd4] ^= SOlevel25Cat2Brd4
 
fusionCategory[SOlevel25Cat2Brd4] ^= SOlevel25Cat2
 
SOlevel25Cat2Brd4 /: modularCategory[SOlevel25Cat2Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel25Cat2Brd4 /: ribbonCategory[SOlevel25Cat2Brd4, 1] = SOlevel25Cat2Bal7
 
SOlevel25Cat2Brd4 /: ribbonCategory[SOlevel25Cat2Brd4, 2] = SOlevel25Cat2Bal8
 
ring[SOlevel25Cat2Brd4] ^= SOlevel25
 
rMatrixFunction[SOlevel25Cat2Brd4] ^= SOlevel25Cat2Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel25Cat2]][braidedCategory[#1]] & )[
    SOlevel25Cat2Brd4] ^= 4
braidedCategory[SOlevel25Cat2Brd4RMatrixFunction] ^= SOlevel25Cat2Brd4
 
fusionCategory[SOlevel25Cat2Brd4RMatrixFunction] ^= SOlevel25Cat2
 
rMatrixFunction[SOlevel25Cat2Brd4RMatrixFunction] ^= 
   SOlevel25Cat2Brd4RMatrixFunction
 
SOlevel25Cat2Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel25Cat2Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel25Cat2Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel25Cat2Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel25Cat2Brd4RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel25Cat2Brd4RMatrixFunction[0, 5, 5] = {{1}}
 
SOlevel25Cat2Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel25Cat2Brd4RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel25Cat2Brd4RMatrixFunction[1, 2, 3] = {{1}}
 
SOlevel25Cat2Brd4RMatrixFunction[1, 3, 2] = {{1}}
 
SOlevel25Cat2Brd4RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel25Cat2Brd4RMatrixFunction[1, 5, 5] = {{1}}
 
SOlevel25Cat2Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel25Cat2Brd4RMatrixFunction[2, 1, 3] = {{-1}}
 
SOlevel25Cat2Brd4RMatrixFunction[2, 2, 0] = {{I}}
 
SOlevel25Cat2Brd4RMatrixFunction[2, 2, 4] = {{(-1)^(9/10)}}
 
SOlevel25Cat2Brd4RMatrixFunction[2, 2, 5] = {{(-1)^(1/10)}}
 
SOlevel25Cat2Brd4RMatrixFunction[2, 3, 1] = {{-I}}
 
SOlevel25Cat2Brd4RMatrixFunction[2, 3, 4] = {{-(-1)^(9/10)}}
 
SOlevel25Cat2Brd4RMatrixFunction[2, 3, 5] = {{-(-1)^(1/10)}}
 
SOlevel25Cat2Brd4RMatrixFunction[2, 4, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[2, 4, 3] = {{(-1)^(3/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[2, 5, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[2, 5, 3] = {{-(-1)^(2/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel25Cat2Brd4RMatrixFunction[3, 1, 2] = {{-1}}
 
SOlevel25Cat2Brd4RMatrixFunction[3, 2, 1] = {{I}}
 
SOlevel25Cat2Brd4RMatrixFunction[3, 2, 4] = {{(-1)^(9/10)}}
 
SOlevel25Cat2Brd4RMatrixFunction[3, 2, 5] = {{(-1)^(1/10)}}
 
SOlevel25Cat2Brd4RMatrixFunction[3, 3, 0] = {{-I}}
 
SOlevel25Cat2Brd4RMatrixFunction[3, 3, 4] = {{-(-1)^(9/10)}}
 
SOlevel25Cat2Brd4RMatrixFunction[3, 3, 5] = {{-(-1)^(1/10)}}
 
SOlevel25Cat2Brd4RMatrixFunction[3, 4, 2] = {{(-1)^(3/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[3, 4, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[3, 5, 2] = {{-(-1)^(2/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[3, 5, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel25Cat2Brd4RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel25Cat2Brd4RMatrixFunction[4, 2, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[4, 2, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[4, 3, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[4, 3, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[4, 4, 0] = {{-(-1)^(1/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[4, 4, 1] = {{(-1)^(1/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[4, 4, 5] = {{(-1)^(4/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[4, 5, 4] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[4, 5, 5] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[5, 0, 5] = {{1}}
 
SOlevel25Cat2Brd4RMatrixFunction[5, 1, 5] = {{1}}
 
SOlevel25Cat2Brd4RMatrixFunction[5, 2, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[5, 2, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[5, 3, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[5, 3, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[5, 4, 4] = {{(-1)^(2/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[5, 4, 5] = {{-(-1)^(3/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[5, 5, 0] = {{(-1)^(4/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[5, 5, 1] = {{-(-1)^(4/5)}}
 
SOlevel25Cat2Brd4RMatrixFunction[5, 5, 4] = {{-(-1)^(1/5)}}
fMatrixFunction[SOlevel25Cat2FMatrixFunction] ^= SOlevel25Cat2FMatrixFunction
 
fusionCategory[SOlevel25Cat2FMatrixFunction] ^= SOlevel25Cat2
 
ring[SOlevel25Cat2FMatrixFunction] ^= SOlevel25
 
SOlevel25Cat2FMatrixFunction[1, 2, 2, 4] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[1, 2, 2, 5] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[1, 2, 3, 4] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[1, 2, 3, 5] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[1, 3, 2, 4] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[1, 3, 2, 5] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[1, 3, 3, 4] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[1, 3, 3, 5] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[1, 4, 4, 0] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[1, 4, 4, 1] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[1, 4, 5, 5] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[1, 5, 4, 5] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[1, 5, 5, 0] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[1, 5, 5, 1] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[1, 5, 5, 4] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[2, 2, 1, 4] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[2, 2, 1, 5] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[2, 2, 2, 2] = 
   {{-(1/Sqrt[5]), 1/Sqrt[5], 1/Sqrt[5]}, {2/Sqrt[5], (5 + Sqrt[5])/10, 
     (-5 + Sqrt[5])/10}, {2/Sqrt[5], (-5 + Sqrt[5])/10, (5 + Sqrt[5])/10}}
 
SOlevel25Cat2FMatrixFunction[2, 2, 2, 3] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0]}}
 
SOlevel25Cat2FMatrixFunction[2, 2, 3, 2] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0]}}
 
SOlevel25Cat2FMatrixFunction[2, 2, 3, 3] = 
   {{-(1/Sqrt[5]), 1/Sqrt[5], 1/Sqrt[5]}, {-2/Sqrt[5], (-5 - Sqrt[5])/10, 
     (5 - Sqrt[5])/10}, {-2/Sqrt[5], (5 - Sqrt[5])/10, (-5 - Sqrt[5])/10}}
 
SOlevel25Cat2FMatrixFunction[2, 2, 4, 4] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat2FMatrixFunction[2, 2, 4, 5] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat2FMatrixFunction[2, 2, 5, 4] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat2FMatrixFunction[2, 2, 5, 5] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat2FMatrixFunction[2, 3, 1, 4] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[2, 3, 1, 5] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[2, 3, 2, 2] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0]}}
 
SOlevel25Cat2FMatrixFunction[2, 3, 2, 3] = 
   {{-(1/Sqrt[5]), -(1/Sqrt[5]), -(1/Sqrt[5])}, 
    {-2/Sqrt[5], (5 + Sqrt[5])/10, (-5 + Sqrt[5])/10}, 
    {-2/Sqrt[5], (-5 + Sqrt[5])/10, (5 + Sqrt[5])/10}}
 
SOlevel25Cat2FMatrixFunction[2, 3, 3, 2] = 
   {{-(1/Sqrt[5]), -(1/Sqrt[5]), -(1/Sqrt[5])}, 
    {2/Sqrt[5], (-5 - Sqrt[5])/10, (5 - Sqrt[5])/10}, 
    {2/Sqrt[5], (5 - Sqrt[5])/10, (-5 - Sqrt[5])/10}}
 
SOlevel25Cat2FMatrixFunction[2, 3, 3, 3] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0]}}
 
SOlevel25Cat2FMatrixFunction[2, 3, 4, 4] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat2FMatrixFunction[2, 3, 4, 5] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat2FMatrixFunction[2, 3, 5, 4] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat2FMatrixFunction[2, 3, 5, 5] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat2FMatrixFunction[2, 4, 2, 4] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat2FMatrixFunction[2, 4, 2, 5] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat2FMatrixFunction[2, 4, 3, 4] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}}
 
SOlevel25Cat2FMatrixFunction[2, 4, 3, 5] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}}
 
SOlevel25Cat2FMatrixFunction[2, 4, 4, 2] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[2, 4, 4, 3] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[2, 4, 5, 2] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[2, 4, 5, 3] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat2FMatrixFunction[2, 5, 2, 4] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat2FMatrixFunction[2, 5, 2, 5] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat2FMatrixFunction[2, 5, 3, 4] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}}
 
SOlevel25Cat2FMatrixFunction[2, 5, 3, 5] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}}
 
SOlevel25Cat2FMatrixFunction[2, 5, 4, 2] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[2, 5, 4, 3] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat2FMatrixFunction[2, 5, 5, 2] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[2, 5, 5, 3] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat2FMatrixFunction[3, 2, 1, 4] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[3, 2, 1, 5] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[3, 2, 2, 2] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0]}}
 
SOlevel25Cat2FMatrixFunction[3, 2, 2, 3] = 
   {{-(1/Sqrt[5]), -(1/Sqrt[5]), -(1/Sqrt[5])}, 
    {2/Sqrt[5], (-5 - Sqrt[5])/10, (5 - Sqrt[5])/10}, 
    {2/Sqrt[5], (5 - Sqrt[5])/10, (-5 - Sqrt[5])/10}}
 
SOlevel25Cat2FMatrixFunction[3, 2, 3, 2] = 
   {{-(1/Sqrt[5]), -(1/Sqrt[5]), -(1/Sqrt[5])}, 
    {-2/Sqrt[5], (5 + Sqrt[5])/10, (-5 + Sqrt[5])/10}, 
    {-2/Sqrt[5], (-5 + Sqrt[5])/10, (5 + Sqrt[5])/10}}
 
SOlevel25Cat2FMatrixFunction[3, 2, 3, 3] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0]}}
 
SOlevel25Cat2FMatrixFunction[3, 2, 4, 4] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat2FMatrixFunction[3, 2, 4, 5] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat2FMatrixFunction[3, 2, 5, 4] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat2FMatrixFunction[3, 2, 5, 5] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat2FMatrixFunction[3, 3, 1, 4] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[3, 3, 1, 5] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[3, 3, 2, 2] = 
   {{-(1/Sqrt[5]), 1/Sqrt[5], 1/Sqrt[5]}, {-2/Sqrt[5], (-5 - Sqrt[5])/10, 
     (5 - Sqrt[5])/10}, {-2/Sqrt[5], (5 - Sqrt[5])/10, (-5 - Sqrt[5])/10}}
 
SOlevel25Cat2FMatrixFunction[3, 3, 2, 3] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0]}}
 
SOlevel25Cat2FMatrixFunction[3, 3, 3, 2] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0]}}
 
SOlevel25Cat2FMatrixFunction[3, 3, 3, 3] = 
   {{-(1/Sqrt[5]), 1/Sqrt[5], 1/Sqrt[5]}, {2/Sqrt[5], (5 + Sqrt[5])/10, 
     (-5 + Sqrt[5])/10}, {2/Sqrt[5], (-5 + Sqrt[5])/10, (5 + Sqrt[5])/10}}
 
SOlevel25Cat2FMatrixFunction[3, 3, 4, 4] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat2FMatrixFunction[3, 3, 4, 5] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat2FMatrixFunction[3, 3, 5, 4] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat2FMatrixFunction[3, 3, 5, 5] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat2FMatrixFunction[3, 4, 2, 4] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}}
 
SOlevel25Cat2FMatrixFunction[3, 4, 2, 5] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}}
 
SOlevel25Cat2FMatrixFunction[3, 4, 3, 4] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat2FMatrixFunction[3, 4, 3, 5] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat2FMatrixFunction[3, 4, 4, 2] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[3, 4, 4, 3] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[3, 4, 5, 2] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat2FMatrixFunction[3, 4, 5, 3] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[3, 5, 2, 4] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}}
 
SOlevel25Cat2FMatrixFunction[3, 5, 2, 5] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}}
 
SOlevel25Cat2FMatrixFunction[3, 5, 3, 4] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat2FMatrixFunction[3, 5, 3, 5] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat2FMatrixFunction[3, 5, 4, 2] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat2FMatrixFunction[3, 5, 4, 3] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[3, 5, 5, 2] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat2FMatrixFunction[3, 5, 5, 3] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[4, 1, 4, 0] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[4, 1, 4, 1] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[4, 1, 5, 4] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[4, 2, 2, 1] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[4, 2, 2, 4] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[4, 2, 2, 5] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[4, 2, 3, 1] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[4, 2, 3, 4] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[4, 2, 3, 5] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat2FMatrixFunction[4, 2, 4, 2] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat2FMatrixFunction[4, 2, 4, 3] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}}
 
SOlevel25Cat2FMatrixFunction[4, 2, 5, 2] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat2FMatrixFunction[4, 2, 5, 3] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}}
 
SOlevel25Cat2FMatrixFunction[4, 3, 2, 1] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[4, 3, 2, 4] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[4, 3, 2, 5] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat2FMatrixFunction[4, 3, 3, 1] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[4, 3, 3, 4] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[4, 3, 3, 5] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[4, 3, 4, 2] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}}
 
SOlevel25Cat2FMatrixFunction[4, 3, 4, 3] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat2FMatrixFunction[4, 3, 5, 2] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}}
 
SOlevel25Cat2FMatrixFunction[4, 3, 5, 3] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat2FMatrixFunction[4, 4, 2, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat2FMatrixFunction[4, 4, 2, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat2FMatrixFunction[4, 4, 3, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat2FMatrixFunction[4, 4, 3, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat2FMatrixFunction[4, 4, 4, 4] = {{1/2, -1/2, -1}, {1/2, -1/2, 1}, 
    {-1/2, -1/2, 0}}
 
SOlevel25Cat2FMatrixFunction[4, 4, 5, 5] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[4, 5, 1, 5] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[4, 5, 2, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat2FMatrixFunction[4, 5, 2, 3] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat2FMatrixFunction[4, 5, 3, 2] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat2FMatrixFunction[4, 5, 3, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat2FMatrixFunction[4, 5, 4, 1] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[4, 5, 4, 5] = {{0, 1}, {1, 0}}
 
SOlevel25Cat2FMatrixFunction[4, 5, 5, 1] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[4, 5, 5, 4] = {{-1, -1}, {-1, 1}}
 
SOlevel25Cat2FMatrixFunction[5, 1, 4, 4] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[5, 1, 5, 0] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[5, 1, 5, 1] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[5, 2, 2, 1] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[5, 2, 2, 4] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[5, 2, 2, 5] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[5, 2, 3, 1] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[5, 2, 3, 4] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat2FMatrixFunction[5, 2, 3, 5] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat2FMatrixFunction[5, 2, 4, 2] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat2FMatrixFunction[5, 2, 4, 3] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}}
 
SOlevel25Cat2FMatrixFunction[5, 2, 5, 2] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat2FMatrixFunction[5, 2, 5, 3] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}}
 
SOlevel25Cat2FMatrixFunction[5, 3, 2, 1] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[5, 3, 2, 4] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat2FMatrixFunction[5, 3, 2, 5] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat2FMatrixFunction[5, 3, 3, 1] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[5, 3, 3, 4] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[5, 3, 3, 5] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[5, 3, 4, 2] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}}
 
SOlevel25Cat2FMatrixFunction[5, 3, 4, 3] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat2FMatrixFunction[5, 3, 5, 2] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}}
 
SOlevel25Cat2FMatrixFunction[5, 3, 5, 3] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat2FMatrixFunction[5, 4, 1, 4] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[5, 4, 1, 5] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[5, 4, 2, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat2FMatrixFunction[5, 4, 2, 3] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat2FMatrixFunction[5, 4, 3, 2] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat2FMatrixFunction[5, 4, 3, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat2FMatrixFunction[5, 4, 4, 5] = {{-1, -1}, {-1, 1}}
 
SOlevel25Cat2FMatrixFunction[5, 4, 5, 1] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[5, 4, 5, 4] = {{0, 1}, {1, 0}}
 
SOlevel25Cat2FMatrixFunction[5, 5, 1, 4] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[5, 5, 2, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat2FMatrixFunction[5, 5, 2, 3] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat2FMatrixFunction[5, 5, 3, 2] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat2FMatrixFunction[5, 5, 3, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat2FMatrixFunction[5, 5, 4, 1] = {{-1}}
 
SOlevel25Cat2FMatrixFunction[5, 5, 4, 4] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat2FMatrixFunction[5, 5, 5, 5] = {{1/2, -1/2, -1}, {1/2, -1/2, 1}, 
    {-1/2, -1/2, 0}}
 
SOlevel25Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SOlevel25Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
SOlevel25Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SOlevel25Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[SOlevel25Cat2Piv1] ^= {SOlevel25Cat2Bal1, 
    SOlevel25Cat2Bal3, SOlevel25Cat2Bal5, SOlevel25Cat2Bal7}
 
SOlevel25Cat2Piv1 /: balancedCategory[SOlevel25Cat2Piv1, 1] = 
    SOlevel25Cat2Bal1
 
SOlevel25Cat2Piv1 /: balancedCategory[SOlevel25Cat2Piv1, 2] = 
    SOlevel25Cat2Bal3
 
SOlevel25Cat2Piv1 /: balancedCategory[SOlevel25Cat2Piv1, 3] = 
    SOlevel25Cat2Bal5
 
SOlevel25Cat2Piv1 /: balancedCategory[SOlevel25Cat2Piv1, 4] = 
    SOlevel25Cat2Bal7
 
fusionCategory[SOlevel25Cat2Piv1] ^= SOlevel25Cat2
 
SOlevel25Cat2Piv1 /: modularCategory[SOlevel25Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SOlevel25Cat2Piv1] ^= SOlevel25Cat2Piv1
 
pivotalIsomorphism[SOlevel25Cat2Piv1] ^= SOlevel25Cat2Piv1PivotalIsomorphism
 
SOlevel25Cat2Piv1 /: ribbonCategory[SOlevel25Cat2Piv1, 1] = SOlevel25Cat2Bal1
 
SOlevel25Cat2Piv1 /: ribbonCategory[SOlevel25Cat2Piv1, 2] = SOlevel25Cat2Bal3
 
SOlevel25Cat2Piv1 /: ribbonCategory[SOlevel25Cat2Piv1, 3] = SOlevel25Cat2Bal5
 
SOlevel25Cat2Piv1 /: ribbonCategory[SOlevel25Cat2Piv1, 4] = SOlevel25Cat2Bal7
 
ring[SOlevel25Cat2Piv1] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat2Piv1] ^= SOlevel25Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[SOlevel25Cat2]][pivotalCategory[#1]] & )[
    SOlevel25Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[SOlevel25Cat2]][
      sphericalCategory[#1]] & )[SOlevel25Cat2Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[SOlevel25Cat2Piv1PivotalIsomorphism] ^= SOlevel25Cat2
 
pivotalCategory[SOlevel25Cat2Piv1PivotalIsomorphism] ^= SOlevel25Cat2Piv1
 
pivotalIsomorphism[SOlevel25Cat2Piv1PivotalIsomorphism] ^= 
   SOlevel25Cat2Piv1PivotalIsomorphism
 
SOlevel25Cat2Piv1PivotalIsomorphism[0] = 1
 
SOlevel25Cat2Piv1PivotalIsomorphism[1] = 1
 
SOlevel25Cat2Piv1PivotalIsomorphism[2] = 1
 
SOlevel25Cat2Piv1PivotalIsomorphism[3] = 1
 
SOlevel25Cat2Piv1PivotalIsomorphism[4] = 1
 
SOlevel25Cat2Piv1PivotalIsomorphism[5] = 1
balancedCategories[SOlevel25Cat2Piv2] ^= {SOlevel25Cat2Bal2, 
    SOlevel25Cat2Bal4, SOlevel25Cat2Bal6, SOlevel25Cat2Bal8}
 
SOlevel25Cat2Piv2 /: balancedCategory[SOlevel25Cat2Piv2, 1] = 
    SOlevel25Cat2Bal2
 
SOlevel25Cat2Piv2 /: balancedCategory[SOlevel25Cat2Piv2, 2] = 
    SOlevel25Cat2Bal4
 
SOlevel25Cat2Piv2 /: balancedCategory[SOlevel25Cat2Piv2, 3] = 
    SOlevel25Cat2Bal6
 
SOlevel25Cat2Piv2 /: balancedCategory[SOlevel25Cat2Piv2, 4] = 
    SOlevel25Cat2Bal8
 
fusionCategory[SOlevel25Cat2Piv2] ^= SOlevel25Cat2
 
SOlevel25Cat2Piv2 /: modularCategory[SOlevel25Cat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SOlevel25Cat2Piv2] ^= SOlevel25Cat2Piv2
 
pivotalIsomorphism[SOlevel25Cat2Piv2] ^= SOlevel25Cat2Piv2PivotalIsomorphism
 
SOlevel25Cat2Piv2 /: ribbonCategory[SOlevel25Cat2Piv2, 1] = SOlevel25Cat2Bal2
 
SOlevel25Cat2Piv2 /: ribbonCategory[SOlevel25Cat2Piv2, 2] = SOlevel25Cat2Bal4
 
SOlevel25Cat2Piv2 /: ribbonCategory[SOlevel25Cat2Piv2, 3] = SOlevel25Cat2Bal6
 
SOlevel25Cat2Piv2 /: ribbonCategory[SOlevel25Cat2Piv2, 4] = SOlevel25Cat2Bal8
 
ring[SOlevel25Cat2Piv2] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat2Piv2] ^= SOlevel25Cat2Piv2
 
(pivotalCategoryIndex[fusionCategory[SOlevel25Cat2]][pivotalCategory[#1]] & )[
    SOlevel25Cat2Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[SOlevel25Cat2]][
      sphericalCategory[#1]] & )[SOlevel25Cat2Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[SOlevel25Cat2Piv2PivotalIsomorphism] ^= SOlevel25Cat2
 
pivotalCategory[SOlevel25Cat2Piv2PivotalIsomorphism] ^= SOlevel25Cat2Piv2
 
pivotalIsomorphism[SOlevel25Cat2Piv2PivotalIsomorphism] ^= 
   SOlevel25Cat2Piv2PivotalIsomorphism
 
SOlevel25Cat2Piv2PivotalIsomorphism[0] = 1
 
SOlevel25Cat2Piv2PivotalIsomorphism[1] = 1
 
SOlevel25Cat2Piv2PivotalIsomorphism[2] = -1
 
SOlevel25Cat2Piv2PivotalIsomorphism[3] = -1
 
SOlevel25Cat2Piv2PivotalIsomorphism[4] = 1
 
SOlevel25Cat2Piv2PivotalIsomorphism[5] = 1
balancedCategories[SOlevel25Cat3] ^= {SOlevel25Cat3Bal1, SOlevel25Cat3Bal2, 
    SOlevel25Cat3Bal3, SOlevel25Cat3Bal4, SOlevel25Cat3Bal5, 
    SOlevel25Cat3Bal6, SOlevel25Cat3Bal7, SOlevel25Cat3Bal8}
 
SOlevel25Cat3 /: balancedCategory[SOlevel25Cat3, 1] = SOlevel25Cat3Bal1
 
SOlevel25Cat3 /: balancedCategory[SOlevel25Cat3, 2] = SOlevel25Cat3Bal2
 
SOlevel25Cat3 /: balancedCategory[SOlevel25Cat3, 3] = SOlevel25Cat3Bal3
 
SOlevel25Cat3 /: balancedCategory[SOlevel25Cat3, 4] = SOlevel25Cat3Bal4
 
SOlevel25Cat3 /: balancedCategory[SOlevel25Cat3, 5] = SOlevel25Cat3Bal5
 
SOlevel25Cat3 /: balancedCategory[SOlevel25Cat3, 6] = SOlevel25Cat3Bal6
 
SOlevel25Cat3 /: balancedCategory[SOlevel25Cat3, 7] = SOlevel25Cat3Bal7
 
SOlevel25Cat3 /: balancedCategory[SOlevel25Cat3, 8] = SOlevel25Cat3Bal8
 
braidedCategories[SOlevel25Cat3] ^= {SOlevel25Cat3Brd1, SOlevel25Cat3Brd2, 
    SOlevel25Cat3Brd3, SOlevel25Cat3Brd4}
 
SOlevel25Cat3 /: braidedCategory[SOlevel25Cat3, 1] = SOlevel25Cat3Brd1
 
SOlevel25Cat3 /: braidedCategory[SOlevel25Cat3, 2] = SOlevel25Cat3Brd2
 
SOlevel25Cat3 /: braidedCategory[SOlevel25Cat3, 3] = SOlevel25Cat3Brd3
 
SOlevel25Cat3 /: braidedCategory[SOlevel25Cat3, 4] = SOlevel25Cat3Brd4
 
coeval[SOlevel25Cat3] ^= 1/sixJFunction[SOlevel25Cat3][#1, 
      dual[ring[SOlevel25Cat3]][#1], #1, #1, 0, 0] & 
 
eval[SOlevel25Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[SOlevel25Cat3] ^= SOlevel25Cat3FMatrixFunction
 
fusionCategory[SOlevel25Cat3] ^= SOlevel25Cat3
 
SOlevel25Cat3 /: modularCategory[SOlevel25Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[SOlevel25Cat3] ^= {SOlevel25Cat3Piv1, SOlevel25Cat3Piv2}
 
SOlevel25Cat3 /: pivotalCategory[SOlevel25Cat3, 1] = SOlevel25Cat3Piv1
 
SOlevel25Cat3 /: pivotalCategory[SOlevel25Cat3, 2] = SOlevel25Cat3Piv2
 
SOlevel25Cat3 /: pivotalCategory[SOlevel25Cat3, {1, 1, -1, -1, 1, 1}] = 
    SOlevel25Cat3Piv2
 
SOlevel25Cat3 /: pivotalCategory[SOlevel25Cat3, {1, 1, 1, 1, 1, 1}] = 
    SOlevel25Cat3Piv1
 
SOlevel25Cat3 /: ribbonCategory[SOlevel25Cat3, 1] = SOlevel25Cat3Bal1
 
SOlevel25Cat3 /: ribbonCategory[SOlevel25Cat3, 2] = SOlevel25Cat3Bal2
 
SOlevel25Cat3 /: ribbonCategory[SOlevel25Cat3, 3] = SOlevel25Cat3Bal3
 
SOlevel25Cat3 /: ribbonCategory[SOlevel25Cat3, 4] = SOlevel25Cat3Bal4
 
SOlevel25Cat3 /: ribbonCategory[SOlevel25Cat3, 5] = SOlevel25Cat3Bal5
 
SOlevel25Cat3 /: ribbonCategory[SOlevel25Cat3, 6] = SOlevel25Cat3Bal6
 
SOlevel25Cat3 /: ribbonCategory[SOlevel25Cat3, 7] = SOlevel25Cat3Bal7
 
SOlevel25Cat3 /: ribbonCategory[SOlevel25Cat3, 8] = SOlevel25Cat3Bal8
 
ring[SOlevel25Cat3] ^= SOlevel25
 
SOlevel25Cat3 /: sphericalCategory[SOlevel25Cat3, 1] = SOlevel25Cat3Piv1
 
SOlevel25Cat3 /: sphericalCategory[SOlevel25Cat3, 2] = SOlevel25Cat3Piv2
 
fusionCategoryIndex[SOlevel25][SOlevel25Cat3] ^= 3
balancedCategory[SOlevel25Cat3Bal1] ^= SOlevel25Cat3Bal1
 
braidedCategory[SOlevel25Cat3Bal1] ^= SOlevel25Cat3Brd1
 
fusionCategory[SOlevel25Cat3Bal1] ^= SOlevel25Cat3
 
pivotalCategory[SOlevel25Cat3Bal1] ^= SOlevel25Cat3Piv1
 
ribbonCategory[SOlevel25Cat3Bal1] ^= SOlevel25Cat3Bal1
 
ring[SOlevel25Cat3Bal1] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat3Bal1] ^= SOlevel25Cat3Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat3Brd1]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat3]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat3Piv1]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat3Brd1]][
      ribbonCategory[#1]] & )[SOlevel25Cat3Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat3]][ribbonCategory[#1]] & )[
    SOlevel25Cat3Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat3Piv1]][
      ribbonCategory[#1]] & )[SOlevel25Cat3Bal1] ^= 1
balancedCategory[SOlevel25Cat3Bal2] ^= SOlevel25Cat3Bal2
 
braidedCategory[SOlevel25Cat3Bal2] ^= SOlevel25Cat3Brd1
 
fusionCategory[SOlevel25Cat3Bal2] ^= SOlevel25Cat3
 
pivotalCategory[SOlevel25Cat3Bal2] ^= SOlevel25Cat3Piv2
 
ribbonCategory[SOlevel25Cat3Bal2] ^= SOlevel25Cat3Bal2
 
ring[SOlevel25Cat3Bal2] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat3Bal2] ^= SOlevel25Cat3Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat3Brd1]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat3]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat3Piv2]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat3Brd1]][
      ribbonCategory[#1]] & )[SOlevel25Cat3Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat3]][ribbonCategory[#1]] & )[
    SOlevel25Cat3Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat3Piv2]][
      ribbonCategory[#1]] & )[SOlevel25Cat3Bal2] ^= 1
balancedCategory[SOlevel25Cat3Bal3] ^= SOlevel25Cat3Bal3
 
braidedCategory[SOlevel25Cat3Bal3] ^= SOlevel25Cat3Brd2
 
fusionCategory[SOlevel25Cat3Bal3] ^= SOlevel25Cat3
 
pivotalCategory[SOlevel25Cat3Bal3] ^= SOlevel25Cat3Piv1
 
ribbonCategory[SOlevel25Cat3Bal3] ^= SOlevel25Cat3Bal3
 
ring[SOlevel25Cat3Bal3] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat3Bal3] ^= SOlevel25Cat3Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat3Brd2]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat3]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat3Piv1]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat3Brd2]][
      ribbonCategory[#1]] & )[SOlevel25Cat3Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat3]][ribbonCategory[#1]] & )[
    SOlevel25Cat3Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat3Piv1]][
      ribbonCategory[#1]] & )[SOlevel25Cat3Bal3] ^= 2
balancedCategory[SOlevel25Cat3Bal4] ^= SOlevel25Cat3Bal4
 
braidedCategory[SOlevel25Cat3Bal4] ^= SOlevel25Cat3Brd2
 
fusionCategory[SOlevel25Cat3Bal4] ^= SOlevel25Cat3
 
pivotalCategory[SOlevel25Cat3Bal4] ^= SOlevel25Cat3Piv2
 
ribbonCategory[SOlevel25Cat3Bal4] ^= SOlevel25Cat3Bal4
 
ring[SOlevel25Cat3Bal4] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat3Bal4] ^= SOlevel25Cat3Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat3Brd2]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat3]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat3Piv2]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat3Brd2]][
      ribbonCategory[#1]] & )[SOlevel25Cat3Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat3]][ribbonCategory[#1]] & )[
    SOlevel25Cat3Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat3Piv2]][
      ribbonCategory[#1]] & )[SOlevel25Cat3Bal4] ^= 2
balancedCategory[SOlevel25Cat3Bal5] ^= SOlevel25Cat3Bal5
 
braidedCategory[SOlevel25Cat3Bal5] ^= SOlevel25Cat3Brd3
 
fusionCategory[SOlevel25Cat3Bal5] ^= SOlevel25Cat3
 
pivotalCategory[SOlevel25Cat3Bal5] ^= SOlevel25Cat3Piv1
 
ribbonCategory[SOlevel25Cat3Bal5] ^= SOlevel25Cat3Bal5
 
ring[SOlevel25Cat3Bal5] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat3Bal5] ^= SOlevel25Cat3Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat3Brd3]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat3]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat3Piv1]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal5] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat3Brd3]][
      ribbonCategory[#1]] & )[SOlevel25Cat3Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat3]][ribbonCategory[#1]] & )[
    SOlevel25Cat3Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat3Piv1]][
      ribbonCategory[#1]] & )[SOlevel25Cat3Bal5] ^= 3
balancedCategory[SOlevel25Cat3Bal6] ^= SOlevel25Cat3Bal6
 
braidedCategory[SOlevel25Cat3Bal6] ^= SOlevel25Cat3Brd3
 
fusionCategory[SOlevel25Cat3Bal6] ^= SOlevel25Cat3
 
pivotalCategory[SOlevel25Cat3Bal6] ^= SOlevel25Cat3Piv2
 
ribbonCategory[SOlevel25Cat3Bal6] ^= SOlevel25Cat3Bal6
 
ring[SOlevel25Cat3Bal6] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat3Bal6] ^= SOlevel25Cat3Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat3Brd3]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat3]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat3Piv2]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal6] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat3Brd3]][
      ribbonCategory[#1]] & )[SOlevel25Cat3Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat3]][ribbonCategory[#1]] & )[
    SOlevel25Cat3Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat3Piv2]][
      ribbonCategory[#1]] & )[SOlevel25Cat3Bal6] ^= 3
balancedCategory[SOlevel25Cat3Bal7] ^= SOlevel25Cat3Bal7
 
braidedCategory[SOlevel25Cat3Bal7] ^= SOlevel25Cat3Brd4
 
fusionCategory[SOlevel25Cat3Bal7] ^= SOlevel25Cat3
 
pivotalCategory[SOlevel25Cat3Bal7] ^= SOlevel25Cat3Piv1
 
ribbonCategory[SOlevel25Cat3Bal7] ^= SOlevel25Cat3Bal7
 
ring[SOlevel25Cat3Bal7] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat3Bal7] ^= SOlevel25Cat3Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat3Brd4]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat3]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat3Piv1]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal7] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat3Brd4]][
      ribbonCategory[#1]] & )[SOlevel25Cat3Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat3]][ribbonCategory[#1]] & )[
    SOlevel25Cat3Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat3Piv1]][
      ribbonCategory[#1]] & )[SOlevel25Cat3Bal7] ^= 4
balancedCategory[SOlevel25Cat3Bal8] ^= SOlevel25Cat3Bal8
 
braidedCategory[SOlevel25Cat3Bal8] ^= SOlevel25Cat3Brd4
 
fusionCategory[SOlevel25Cat3Bal8] ^= SOlevel25Cat3
 
pivotalCategory[SOlevel25Cat3Bal8] ^= SOlevel25Cat3Piv2
 
ribbonCategory[SOlevel25Cat3Bal8] ^= SOlevel25Cat3Bal8
 
ring[SOlevel25Cat3Bal8] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat3Bal8] ^= SOlevel25Cat3Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat3Brd4]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat3]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat3Piv2]][
      balancedCategory[#1]] & )[SOlevel25Cat3Bal8] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat3Brd4]][
      ribbonCategory[#1]] & )[SOlevel25Cat3Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat3]][ribbonCategory[#1]] & )[
    SOlevel25Cat3Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat3Piv2]][
      ribbonCategory[#1]] & )[SOlevel25Cat3Bal8] ^= 4
balancedCategories[SOlevel25Cat3Brd1] ^= {SOlevel25Cat3Bal1, 
    SOlevel25Cat3Bal2}
 
SOlevel25Cat3Brd1 /: balancedCategory[SOlevel25Cat3Brd1, 1] = 
    SOlevel25Cat3Bal1
 
SOlevel25Cat3Brd1 /: balancedCategory[SOlevel25Cat3Brd1, 2] = 
    SOlevel25Cat3Bal2
 
braidedCategory[SOlevel25Cat3Brd1] ^= SOlevel25Cat3Brd1
 
fusionCategory[SOlevel25Cat3Brd1] ^= SOlevel25Cat3
 
SOlevel25Cat3Brd1 /: modularCategory[SOlevel25Cat3Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel25Cat3Brd1 /: ribbonCategory[SOlevel25Cat3Brd1, 1] = SOlevel25Cat3Bal1
 
SOlevel25Cat3Brd1 /: ribbonCategory[SOlevel25Cat3Brd1, 2] = SOlevel25Cat3Bal2
 
ring[SOlevel25Cat3Brd1] ^= SOlevel25
 
rMatrixFunction[SOlevel25Cat3Brd1] ^= SOlevel25Cat3Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel25Cat3]][braidedCategory[#1]] & )[
    SOlevel25Cat3Brd1] ^= 1
braidedCategory[SOlevel25Cat3Brd1RMatrixFunction] ^= SOlevel25Cat3Brd1
 
fusionCategory[SOlevel25Cat3Brd1RMatrixFunction] ^= SOlevel25Cat3
 
rMatrixFunction[SOlevel25Cat3Brd1RMatrixFunction] ^= 
   SOlevel25Cat3Brd1RMatrixFunction
 
SOlevel25Cat3Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel25Cat3Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel25Cat3Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel25Cat3Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel25Cat3Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel25Cat3Brd1RMatrixFunction[0, 5, 5] = {{1}}
 
SOlevel25Cat3Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel25Cat3Brd1RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel25Cat3Brd1RMatrixFunction[1, 2, 3] = {{-1}}
 
SOlevel25Cat3Brd1RMatrixFunction[1, 3, 2] = {{-1}}
 
SOlevel25Cat3Brd1RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel25Cat3Brd1RMatrixFunction[1, 5, 5] = {{1}}
 
SOlevel25Cat3Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel25Cat3Brd1RMatrixFunction[2, 1, 3] = {{1}}
 
SOlevel25Cat3Brd1RMatrixFunction[2, 2, 0] = {{-I}}
 
SOlevel25Cat3Brd1RMatrixFunction[2, 2, 4] = {{(-1)^(3/10)}}
 
SOlevel25Cat3Brd1RMatrixFunction[2, 2, 5] = {{(-1)^(7/10)}}
 
SOlevel25Cat3Brd1RMatrixFunction[2, 3, 1] = {{-I}}
 
SOlevel25Cat3Brd1RMatrixFunction[2, 3, 4] = {{(-1)^(3/10)}}
 
SOlevel25Cat3Brd1RMatrixFunction[2, 3, 5] = {{(-1)^(7/10)}}
 
SOlevel25Cat3Brd1RMatrixFunction[2, 4, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[2, 4, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[2, 5, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[2, 5, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel25Cat3Brd1RMatrixFunction[3, 1, 2] = {{1}}
 
SOlevel25Cat3Brd1RMatrixFunction[3, 2, 1] = {{I}}
 
SOlevel25Cat3Brd1RMatrixFunction[3, 2, 4] = {{-(-1)^(3/10)}}
 
SOlevel25Cat3Brd1RMatrixFunction[3, 2, 5] = {{-(-1)^(7/10)}}
 
SOlevel25Cat3Brd1RMatrixFunction[3, 3, 0] = {{I}}
 
SOlevel25Cat3Brd1RMatrixFunction[3, 3, 4] = {{-(-1)^(3/10)}}
 
SOlevel25Cat3Brd1RMatrixFunction[3, 3, 5] = {{-(-1)^(7/10)}}
 
SOlevel25Cat3Brd1RMatrixFunction[3, 4, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[3, 4, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[3, 5, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[3, 5, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel25Cat3Brd1RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel25Cat3Brd1RMatrixFunction[4, 2, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[4, 2, 3] = {{(-1)^(1/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[4, 3, 2] = {{(-1)^(1/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[4, 3, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[4, 4, 0] = {{(-1)^(2/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[4, 4, 1] = {{-(-1)^(2/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[4, 4, 5] = {{-(-1)^(3/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[4, 5, 4] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[4, 5, 5] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[5, 0, 5] = {{1}}
 
SOlevel25Cat3Brd1RMatrixFunction[5, 1, 5] = {{1}}
 
SOlevel25Cat3Brd1RMatrixFunction[5, 2, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[5, 2, 3] = {{-(-1)^(4/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[5, 3, 2] = {{-(-1)^(4/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[5, 3, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[5, 4, 4] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[5, 4, 5] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[5, 5, 0] = {{-(-1)^(3/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[5, 5, 1] = {{(-1)^(3/5)}}
 
SOlevel25Cat3Brd1RMatrixFunction[5, 5, 4] = {{(-1)^(2/5)}}
balancedCategories[SOlevel25Cat3Brd2] ^= {SOlevel25Cat3Bal3, 
    SOlevel25Cat3Bal4}
 
SOlevel25Cat3Brd2 /: balancedCategory[SOlevel25Cat3Brd2, 1] = 
    SOlevel25Cat3Bal3
 
SOlevel25Cat3Brd2 /: balancedCategory[SOlevel25Cat3Brd2, 2] = 
    SOlevel25Cat3Bal4
 
braidedCategory[SOlevel25Cat3Brd2] ^= SOlevel25Cat3Brd2
 
fusionCategory[SOlevel25Cat3Brd2] ^= SOlevel25Cat3
 
SOlevel25Cat3Brd2 /: modularCategory[SOlevel25Cat3Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel25Cat3Brd2 /: ribbonCategory[SOlevel25Cat3Brd2, 1] = SOlevel25Cat3Bal3
 
SOlevel25Cat3Brd2 /: ribbonCategory[SOlevel25Cat3Brd2, 2] = SOlevel25Cat3Bal4
 
ring[SOlevel25Cat3Brd2] ^= SOlevel25
 
rMatrixFunction[SOlevel25Cat3Brd2] ^= SOlevel25Cat3Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel25Cat3]][braidedCategory[#1]] & )[
    SOlevel25Cat3Brd2] ^= 2
braidedCategory[SOlevel25Cat3Brd2RMatrixFunction] ^= SOlevel25Cat3Brd2
 
fusionCategory[SOlevel25Cat3Brd2RMatrixFunction] ^= SOlevel25Cat3
 
rMatrixFunction[SOlevel25Cat3Brd2RMatrixFunction] ^= 
   SOlevel25Cat3Brd2RMatrixFunction
 
SOlevel25Cat3Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel25Cat3Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel25Cat3Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel25Cat3Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel25Cat3Brd2RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel25Cat3Brd2RMatrixFunction[0, 5, 5] = {{1}}
 
SOlevel25Cat3Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel25Cat3Brd2RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel25Cat3Brd2RMatrixFunction[1, 2, 3] = {{-1}}
 
SOlevel25Cat3Brd2RMatrixFunction[1, 3, 2] = {{-1}}
 
SOlevel25Cat3Brd2RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel25Cat3Brd2RMatrixFunction[1, 5, 5] = {{1}}
 
SOlevel25Cat3Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel25Cat3Brd2RMatrixFunction[2, 1, 3] = {{1}}
 
SOlevel25Cat3Brd2RMatrixFunction[2, 2, 0] = {{I}}
 
SOlevel25Cat3Brd2RMatrixFunction[2, 2, 4] = {{-(-1)^(3/10)}}
 
SOlevel25Cat3Brd2RMatrixFunction[2, 2, 5] = {{-(-1)^(7/10)}}
 
SOlevel25Cat3Brd2RMatrixFunction[2, 3, 1] = {{I}}
 
SOlevel25Cat3Brd2RMatrixFunction[2, 3, 4] = {{-(-1)^(3/10)}}
 
SOlevel25Cat3Brd2RMatrixFunction[2, 3, 5] = {{-(-1)^(7/10)}}
 
SOlevel25Cat3Brd2RMatrixFunction[2, 4, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[2, 4, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[2, 5, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[2, 5, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel25Cat3Brd2RMatrixFunction[3, 1, 2] = {{1}}
 
SOlevel25Cat3Brd2RMatrixFunction[3, 2, 1] = {{-I}}
 
SOlevel25Cat3Brd2RMatrixFunction[3, 2, 4] = {{(-1)^(3/10)}}
 
SOlevel25Cat3Brd2RMatrixFunction[3, 2, 5] = {{(-1)^(7/10)}}
 
SOlevel25Cat3Brd2RMatrixFunction[3, 3, 0] = {{-I}}
 
SOlevel25Cat3Brd2RMatrixFunction[3, 3, 4] = {{(-1)^(3/10)}}
 
SOlevel25Cat3Brd2RMatrixFunction[3, 3, 5] = {{(-1)^(7/10)}}
 
SOlevel25Cat3Brd2RMatrixFunction[3, 4, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[3, 4, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[3, 5, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[3, 5, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel25Cat3Brd2RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel25Cat3Brd2RMatrixFunction[4, 2, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[4, 2, 3] = {{(-1)^(1/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[4, 3, 2] = {{(-1)^(1/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[4, 3, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[4, 4, 0] = {{(-1)^(2/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[4, 4, 1] = {{-(-1)^(2/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[4, 4, 5] = {{-(-1)^(3/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[4, 5, 4] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[4, 5, 5] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[5, 0, 5] = {{1}}
 
SOlevel25Cat3Brd2RMatrixFunction[5, 1, 5] = {{1}}
 
SOlevel25Cat3Brd2RMatrixFunction[5, 2, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[5, 2, 3] = {{-(-1)^(4/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[5, 3, 2] = {{-(-1)^(4/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[5, 3, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[5, 4, 4] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[5, 4, 5] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[5, 5, 0] = {{-(-1)^(3/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[5, 5, 1] = {{(-1)^(3/5)}}
 
SOlevel25Cat3Brd2RMatrixFunction[5, 5, 4] = {{(-1)^(2/5)}}
balancedCategories[SOlevel25Cat3Brd3] ^= {SOlevel25Cat3Bal5, 
    SOlevel25Cat3Bal6}
 
SOlevel25Cat3Brd3 /: balancedCategory[SOlevel25Cat3Brd3, 1] = 
    SOlevel25Cat3Bal5
 
SOlevel25Cat3Brd3 /: balancedCategory[SOlevel25Cat3Brd3, 2] = 
    SOlevel25Cat3Bal6
 
braidedCategory[SOlevel25Cat3Brd3] ^= SOlevel25Cat3Brd3
 
fusionCategory[SOlevel25Cat3Brd3] ^= SOlevel25Cat3
 
SOlevel25Cat3Brd3 /: modularCategory[SOlevel25Cat3Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel25Cat3Brd3 /: ribbonCategory[SOlevel25Cat3Brd3, 1] = SOlevel25Cat3Bal5
 
SOlevel25Cat3Brd3 /: ribbonCategory[SOlevel25Cat3Brd3, 2] = SOlevel25Cat3Bal6
 
ring[SOlevel25Cat3Brd3] ^= SOlevel25
 
rMatrixFunction[SOlevel25Cat3Brd3] ^= SOlevel25Cat3Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel25Cat3]][braidedCategory[#1]] & )[
    SOlevel25Cat3Brd3] ^= 3
braidedCategory[SOlevel25Cat3Brd3RMatrixFunction] ^= SOlevel25Cat3Brd3
 
fusionCategory[SOlevel25Cat3Brd3RMatrixFunction] ^= SOlevel25Cat3
 
rMatrixFunction[SOlevel25Cat3Brd3RMatrixFunction] ^= 
   SOlevel25Cat3Brd3RMatrixFunction
 
SOlevel25Cat3Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel25Cat3Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel25Cat3Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel25Cat3Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel25Cat3Brd3RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel25Cat3Brd3RMatrixFunction[0, 5, 5] = {{1}}
 
SOlevel25Cat3Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel25Cat3Brd3RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel25Cat3Brd3RMatrixFunction[1, 2, 3] = {{1}}
 
SOlevel25Cat3Brd3RMatrixFunction[1, 3, 2] = {{1}}
 
SOlevel25Cat3Brd3RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel25Cat3Brd3RMatrixFunction[1, 5, 5] = {{1}}
 
SOlevel25Cat3Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel25Cat3Brd3RMatrixFunction[2, 1, 3] = {{-1}}
 
SOlevel25Cat3Brd3RMatrixFunction[2, 2, 0] = {{I}}
 
SOlevel25Cat3Brd3RMatrixFunction[2, 2, 4] = {{-(-1)^(7/10)}}
 
SOlevel25Cat3Brd3RMatrixFunction[2, 2, 5] = {{-(-1)^(3/10)}}
 
SOlevel25Cat3Brd3RMatrixFunction[2, 3, 1] = {{-I}}
 
SOlevel25Cat3Brd3RMatrixFunction[2, 3, 4] = {{(-1)^(7/10)}}
 
SOlevel25Cat3Brd3RMatrixFunction[2, 3, 5] = {{(-1)^(3/10)}}
 
SOlevel25Cat3Brd3RMatrixFunction[2, 4, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[2, 4, 3] = {{-(-1)^(4/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[2, 5, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[2, 5, 3] = {{(-1)^(1/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel25Cat3Brd3RMatrixFunction[3, 1, 2] = {{-1}}
 
SOlevel25Cat3Brd3RMatrixFunction[3, 2, 1] = {{I}}
 
SOlevel25Cat3Brd3RMatrixFunction[3, 2, 4] = {{-(-1)^(7/10)}}
 
SOlevel25Cat3Brd3RMatrixFunction[3, 2, 5] = {{-(-1)^(3/10)}}
 
SOlevel25Cat3Brd3RMatrixFunction[3, 3, 0] = {{-I}}
 
SOlevel25Cat3Brd3RMatrixFunction[3, 3, 4] = {{(-1)^(7/10)}}
 
SOlevel25Cat3Brd3RMatrixFunction[3, 3, 5] = {{(-1)^(3/10)}}
 
SOlevel25Cat3Brd3RMatrixFunction[3, 4, 2] = {{-(-1)^(4/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[3, 4, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[3, 5, 2] = {{(-1)^(1/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[3, 5, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel25Cat3Brd3RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel25Cat3Brd3RMatrixFunction[4, 2, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[4, 2, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[4, 3, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[4, 3, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[4, 4, 0] = {{-(-1)^(3/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[4, 4, 1] = {{(-1)^(3/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[4, 4, 5] = {{(-1)^(2/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[4, 5, 4] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[4, 5, 5] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[5, 0, 5] = {{1}}
 
SOlevel25Cat3Brd3RMatrixFunction[5, 1, 5] = {{1}}
 
SOlevel25Cat3Brd3RMatrixFunction[5, 2, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[5, 2, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[5, 3, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[5, 3, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[5, 4, 4] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[5, 4, 5] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[5, 5, 0] = {{(-1)^(2/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[5, 5, 1] = {{-(-1)^(2/5)}}
 
SOlevel25Cat3Brd3RMatrixFunction[5, 5, 4] = {{-(-1)^(3/5)}}
balancedCategories[SOlevel25Cat3Brd4] ^= {SOlevel25Cat3Bal7, 
    SOlevel25Cat3Bal8}
 
SOlevel25Cat3Brd4 /: balancedCategory[SOlevel25Cat3Brd4, 1] = 
    SOlevel25Cat3Bal7
 
SOlevel25Cat3Brd4 /: balancedCategory[SOlevel25Cat3Brd4, 2] = 
    SOlevel25Cat3Bal8
 
braidedCategory[SOlevel25Cat3Brd4] ^= SOlevel25Cat3Brd4
 
fusionCategory[SOlevel25Cat3Brd4] ^= SOlevel25Cat3
 
SOlevel25Cat3Brd4 /: modularCategory[SOlevel25Cat3Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel25Cat3Brd4 /: ribbonCategory[SOlevel25Cat3Brd4, 1] = SOlevel25Cat3Bal7
 
SOlevel25Cat3Brd4 /: ribbonCategory[SOlevel25Cat3Brd4, 2] = SOlevel25Cat3Bal8
 
ring[SOlevel25Cat3Brd4] ^= SOlevel25
 
rMatrixFunction[SOlevel25Cat3Brd4] ^= SOlevel25Cat3Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel25Cat3]][braidedCategory[#1]] & )[
    SOlevel25Cat3Brd4] ^= 4
braidedCategory[SOlevel25Cat3Brd4RMatrixFunction] ^= SOlevel25Cat3Brd4
 
fusionCategory[SOlevel25Cat3Brd4RMatrixFunction] ^= SOlevel25Cat3
 
rMatrixFunction[SOlevel25Cat3Brd4RMatrixFunction] ^= 
   SOlevel25Cat3Brd4RMatrixFunction
 
SOlevel25Cat3Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel25Cat3Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel25Cat3Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel25Cat3Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel25Cat3Brd4RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel25Cat3Brd4RMatrixFunction[0, 5, 5] = {{1}}
 
SOlevel25Cat3Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel25Cat3Brd4RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel25Cat3Brd4RMatrixFunction[1, 2, 3] = {{1}}
 
SOlevel25Cat3Brd4RMatrixFunction[1, 3, 2] = {{1}}
 
SOlevel25Cat3Brd4RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel25Cat3Brd4RMatrixFunction[1, 5, 5] = {{1}}
 
SOlevel25Cat3Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel25Cat3Brd4RMatrixFunction[2, 1, 3] = {{-1}}
 
SOlevel25Cat3Brd4RMatrixFunction[2, 2, 0] = {{-I}}
 
SOlevel25Cat3Brd4RMatrixFunction[2, 2, 4] = {{(-1)^(7/10)}}
 
SOlevel25Cat3Brd4RMatrixFunction[2, 2, 5] = {{(-1)^(3/10)}}
 
SOlevel25Cat3Brd4RMatrixFunction[2, 3, 1] = {{I}}
 
SOlevel25Cat3Brd4RMatrixFunction[2, 3, 4] = {{-(-1)^(7/10)}}
 
SOlevel25Cat3Brd4RMatrixFunction[2, 3, 5] = {{-(-1)^(3/10)}}
 
SOlevel25Cat3Brd4RMatrixFunction[2, 4, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[2, 4, 3] = {{-(-1)^(4/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[2, 5, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[2, 5, 3] = {{(-1)^(1/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel25Cat3Brd4RMatrixFunction[3, 1, 2] = {{-1}}
 
SOlevel25Cat3Brd4RMatrixFunction[3, 2, 1] = {{-I}}
 
SOlevel25Cat3Brd4RMatrixFunction[3, 2, 4] = {{(-1)^(7/10)}}
 
SOlevel25Cat3Brd4RMatrixFunction[3, 2, 5] = {{(-1)^(3/10)}}
 
SOlevel25Cat3Brd4RMatrixFunction[3, 3, 0] = {{I}}
 
SOlevel25Cat3Brd4RMatrixFunction[3, 3, 4] = {{-(-1)^(7/10)}}
 
SOlevel25Cat3Brd4RMatrixFunction[3, 3, 5] = {{-(-1)^(3/10)}}
 
SOlevel25Cat3Brd4RMatrixFunction[3, 4, 2] = {{-(-1)^(4/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[3, 4, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[3, 5, 2] = {{(-1)^(1/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[3, 5, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel25Cat3Brd4RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel25Cat3Brd4RMatrixFunction[4, 2, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[4, 2, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[4, 3, 2] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[4, 3, 3] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[4, 4, 0] = {{-(-1)^(3/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[4, 4, 1] = {{(-1)^(3/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[4, 4, 5] = {{(-1)^(2/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[4, 5, 4] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[4, 5, 5] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[5, 0, 5] = {{1}}
 
SOlevel25Cat3Brd4RMatrixFunction[5, 1, 5] = {{1}}
 
SOlevel25Cat3Brd4RMatrixFunction[5, 2, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[5, 2, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[5, 3, 2] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[5, 3, 3] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[5, 4, 4] = {{-(-1)^(1/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[5, 4, 5] = {{(-1)^(4/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[5, 5, 0] = {{(-1)^(2/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[5, 5, 1] = {{-(-1)^(2/5)}}
 
SOlevel25Cat3Brd4RMatrixFunction[5, 5, 4] = {{-(-1)^(3/5)}}
fMatrixFunction[SOlevel25Cat3FMatrixFunction] ^= SOlevel25Cat3FMatrixFunction
 
fusionCategory[SOlevel25Cat3FMatrixFunction] ^= SOlevel25Cat3
 
ring[SOlevel25Cat3FMatrixFunction] ^= SOlevel25
 
SOlevel25Cat3FMatrixFunction[1, 2, 2, 4] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[1, 2, 2, 5] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[1, 2, 3, 4] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[1, 2, 3, 5] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[1, 3, 2, 4] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[1, 3, 2, 5] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[1, 3, 3, 4] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[1, 3, 3, 5] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[1, 4, 4, 0] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[1, 4, 4, 1] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[1, 4, 5, 5] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[1, 5, 4, 5] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[1, 5, 5, 0] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[1, 5, 5, 1] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[1, 5, 5, 4] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[2, 2, 1, 4] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[2, 2, 1, 5] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[2, 2, 2, 2] = 
   {{1/Sqrt[5], -(1/Sqrt[5]), -(1/Sqrt[5])}, {-2/Sqrt[5], (5 - Sqrt[5])/10, 
     (-5 - Sqrt[5])/10}, {-2/Sqrt[5], (-5 - Sqrt[5])/10, (5 - Sqrt[5])/10}}
 
SOlevel25Cat3FMatrixFunction[2, 2, 2, 3] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0]}}
 
SOlevel25Cat3FMatrixFunction[2, 2, 3, 2] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0]}}
 
SOlevel25Cat3FMatrixFunction[2, 2, 3, 3] = 
   {{1/Sqrt[5], -(1/Sqrt[5]), -(1/Sqrt[5])}, {2/Sqrt[5], (-5 + Sqrt[5])/10, 
     (5 + Sqrt[5])/10}, {2/Sqrt[5], (5 + Sqrt[5])/10, (-5 + Sqrt[5])/10}}
 
SOlevel25Cat3FMatrixFunction[2, 2, 4, 4] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat3FMatrixFunction[2, 2, 4, 5] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat3FMatrixFunction[2, 2, 5, 4] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat3FMatrixFunction[2, 2, 5, 5] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat3FMatrixFunction[2, 3, 1, 4] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[2, 3, 1, 5] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[2, 3, 2, 2] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0]}}
 
SOlevel25Cat3FMatrixFunction[2, 3, 2, 3] = 
   {{1/Sqrt[5], 1/Sqrt[5], 1/Sqrt[5]}, {2/Sqrt[5], (5 - Sqrt[5])/10, 
     (-5 - Sqrt[5])/10}, {2/Sqrt[5], (-5 - Sqrt[5])/10, (5 - Sqrt[5])/10}}
 
SOlevel25Cat3FMatrixFunction[2, 3, 3, 2] = 
   {{1/Sqrt[5], 1/Sqrt[5], 1/Sqrt[5]}, {-2/Sqrt[5], (-5 + Sqrt[5])/10, 
     (5 + Sqrt[5])/10}, {-2/Sqrt[5], (5 + Sqrt[5])/10, (-5 + Sqrt[5])/10}}
 
SOlevel25Cat3FMatrixFunction[2, 3, 3, 3] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0]}}
 
SOlevel25Cat3FMatrixFunction[2, 3, 4, 4] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat3FMatrixFunction[2, 3, 4, 5] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat3FMatrixFunction[2, 3, 5, 4] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat3FMatrixFunction[2, 3, 5, 5] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat3FMatrixFunction[2, 4, 2, 4] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat3FMatrixFunction[2, 4, 2, 5] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat3FMatrixFunction[2, 4, 3, 4] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}}
 
SOlevel25Cat3FMatrixFunction[2, 4, 3, 5] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}}
 
SOlevel25Cat3FMatrixFunction[2, 4, 4, 2] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[2, 4, 4, 3] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[2, 4, 5, 2] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[2, 4, 5, 3] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat3FMatrixFunction[2, 5, 2, 4] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat3FMatrixFunction[2, 5, 2, 5] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat3FMatrixFunction[2, 5, 3, 4] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}}
 
SOlevel25Cat3FMatrixFunction[2, 5, 3, 5] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}}
 
SOlevel25Cat3FMatrixFunction[2, 5, 4, 2] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[2, 5, 4, 3] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat3FMatrixFunction[2, 5, 5, 2] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[2, 5, 5, 3] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat3FMatrixFunction[3, 2, 1, 4] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[3, 2, 1, 5] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[3, 2, 2, 2] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0]}}
 
SOlevel25Cat3FMatrixFunction[3, 2, 2, 3] = 
   {{1/Sqrt[5], 1/Sqrt[5], 1/Sqrt[5]}, {-2/Sqrt[5], (-5 + Sqrt[5])/10, 
     (5 + Sqrt[5])/10}, {-2/Sqrt[5], (5 + Sqrt[5])/10, (-5 + Sqrt[5])/10}}
 
SOlevel25Cat3FMatrixFunction[3, 2, 3, 2] = 
   {{1/Sqrt[5], 1/Sqrt[5], 1/Sqrt[5]}, {2/Sqrt[5], (5 - Sqrt[5])/10, 
     (-5 - Sqrt[5])/10}, {2/Sqrt[5], (-5 - Sqrt[5])/10, (5 - Sqrt[5])/10}}
 
SOlevel25Cat3FMatrixFunction[3, 2, 3, 3] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0]}}
 
SOlevel25Cat3FMatrixFunction[3, 2, 4, 4] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat3FMatrixFunction[3, 2, 4, 5] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat3FMatrixFunction[3, 2, 5, 4] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat3FMatrixFunction[3, 2, 5, 5] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat3FMatrixFunction[3, 3, 1, 4] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[3, 3, 1, 5] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[3, 3, 2, 2] = 
   {{1/Sqrt[5], -(1/Sqrt[5]), -(1/Sqrt[5])}, {2/Sqrt[5], (-5 + Sqrt[5])/10, 
     (5 + Sqrt[5])/10}, {2/Sqrt[5], (5 + Sqrt[5])/10, (-5 + Sqrt[5])/10}}
 
SOlevel25Cat3FMatrixFunction[3, 3, 2, 3] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0]}}
 
SOlevel25Cat3FMatrixFunction[3, 3, 3, 2] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0]}}
 
SOlevel25Cat3FMatrixFunction[3, 3, 3, 3] = 
   {{1/Sqrt[5], -(1/Sqrt[5]), -(1/Sqrt[5])}, {-2/Sqrt[5], (5 - Sqrt[5])/10, 
     (-5 - Sqrt[5])/10}, {-2/Sqrt[5], (-5 - Sqrt[5])/10, (5 - Sqrt[5])/10}}
 
SOlevel25Cat3FMatrixFunction[3, 3, 4, 4] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat3FMatrixFunction[3, 3, 4, 5] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat3FMatrixFunction[3, 3, 5, 4] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat3FMatrixFunction[3, 3, 5, 5] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat3FMatrixFunction[3, 4, 2, 4] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}}
 
SOlevel25Cat3FMatrixFunction[3, 4, 2, 5] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}}
 
SOlevel25Cat3FMatrixFunction[3, 4, 3, 4] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat3FMatrixFunction[3, 4, 3, 5] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat3FMatrixFunction[3, 4, 4, 2] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[3, 4, 4, 3] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[3, 4, 5, 2] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat3FMatrixFunction[3, 4, 5, 3] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[3, 5, 2, 4] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}}
 
SOlevel25Cat3FMatrixFunction[3, 5, 2, 5] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}}
 
SOlevel25Cat3FMatrixFunction[3, 5, 3, 4] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat3FMatrixFunction[3, 5, 3, 5] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat3FMatrixFunction[3, 5, 4, 2] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat3FMatrixFunction[3, 5, 4, 3] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[3, 5, 5, 2] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat3FMatrixFunction[3, 5, 5, 3] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[4, 1, 4, 0] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[4, 1, 4, 1] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[4, 1, 5, 4] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[4, 2, 2, 1] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[4, 2, 2, 4] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[4, 2, 2, 5] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[4, 2, 3, 1] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[4, 2, 3, 4] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[4, 2, 3, 5] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat3FMatrixFunction[4, 2, 4, 2] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat3FMatrixFunction[4, 2, 4, 3] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}}
 
SOlevel25Cat3FMatrixFunction[4, 2, 5, 2] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat3FMatrixFunction[4, 2, 5, 3] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}}
 
SOlevel25Cat3FMatrixFunction[4, 3, 2, 1] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[4, 3, 2, 4] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[4, 3, 2, 5] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat3FMatrixFunction[4, 3, 3, 1] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[4, 3, 3, 4] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[4, 3, 3, 5] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[4, 3, 4, 2] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}}
 
SOlevel25Cat3FMatrixFunction[4, 3, 4, 3] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat3FMatrixFunction[4, 3, 5, 2] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}}
 
SOlevel25Cat3FMatrixFunction[4, 3, 5, 3] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat3FMatrixFunction[4, 4, 2, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat3FMatrixFunction[4, 4, 2, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat3FMatrixFunction[4, 4, 3, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat3FMatrixFunction[4, 4, 3, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat3FMatrixFunction[4, 4, 4, 4] = {{1/2, -1/2, -1}, {1/2, -1/2, 1}, 
    {-1/2, -1/2, 0}}
 
SOlevel25Cat3FMatrixFunction[4, 4, 5, 5] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[4, 5, 1, 5] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[4, 5, 2, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat3FMatrixFunction[4, 5, 2, 3] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat3FMatrixFunction[4, 5, 3, 2] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat3FMatrixFunction[4, 5, 3, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat3FMatrixFunction[4, 5, 4, 1] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[4, 5, 4, 5] = {{0, 1}, {1, 0}}
 
SOlevel25Cat3FMatrixFunction[4, 5, 5, 1] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[4, 5, 5, 4] = {{-1, -1}, {-1, 1}}
 
SOlevel25Cat3FMatrixFunction[5, 1, 4, 4] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[5, 1, 5, 0] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[5, 1, 5, 1] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[5, 2, 2, 1] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[5, 2, 2, 4] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[5, 2, 2, 5] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[5, 2, 3, 1] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[5, 2, 3, 4] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat3FMatrixFunction[5, 2, 3, 5] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat3FMatrixFunction[5, 2, 4, 2] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat3FMatrixFunction[5, 2, 4, 3] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}}
 
SOlevel25Cat3FMatrixFunction[5, 2, 5, 2] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat3FMatrixFunction[5, 2, 5, 3] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}}
 
SOlevel25Cat3FMatrixFunction[5, 3, 2, 1] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[5, 3, 2, 4] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat3FMatrixFunction[5, 3, 2, 5] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat3FMatrixFunction[5, 3, 3, 1] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[5, 3, 3, 4] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[5, 3, 3, 5] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[5, 3, 4, 2] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}}
 
SOlevel25Cat3FMatrixFunction[5, 3, 4, 3] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat3FMatrixFunction[5, 3, 5, 2] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}}
 
SOlevel25Cat3FMatrixFunction[5, 3, 5, 3] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat3FMatrixFunction[5, 4, 1, 4] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[5, 4, 1, 5] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[5, 4, 2, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat3FMatrixFunction[5, 4, 2, 3] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat3FMatrixFunction[5, 4, 3, 2] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat3FMatrixFunction[5, 4, 3, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat3FMatrixFunction[5, 4, 4, 5] = {{-1, -1}, {-1, 1}}
 
SOlevel25Cat3FMatrixFunction[5, 4, 5, 1] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[5, 4, 5, 4] = {{0, 1}, {1, 0}}
 
SOlevel25Cat3FMatrixFunction[5, 5, 1, 4] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[5, 5, 2, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat3FMatrixFunction[5, 5, 2, 3] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat3FMatrixFunction[5, 5, 3, 2] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat3FMatrixFunction[5, 5, 3, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat3FMatrixFunction[5, 5, 4, 1] = {{-1}}
 
SOlevel25Cat3FMatrixFunction[5, 5, 4, 4] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat3FMatrixFunction[5, 5, 5, 5] = {{1/2, -1/2, -1}, {1/2, -1/2, 1}, 
    {-1/2, -1/2, 0}}
 
SOlevel25Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SOlevel25Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
SOlevel25Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SOlevel25Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[SOlevel25Cat3Piv1] ^= {SOlevel25Cat3Bal1, 
    SOlevel25Cat3Bal3, SOlevel25Cat3Bal5, SOlevel25Cat3Bal7}
 
SOlevel25Cat3Piv1 /: balancedCategory[SOlevel25Cat3Piv1, 1] = 
    SOlevel25Cat3Bal1
 
SOlevel25Cat3Piv1 /: balancedCategory[SOlevel25Cat3Piv1, 2] = 
    SOlevel25Cat3Bal3
 
SOlevel25Cat3Piv1 /: balancedCategory[SOlevel25Cat3Piv1, 3] = 
    SOlevel25Cat3Bal5
 
SOlevel25Cat3Piv1 /: balancedCategory[SOlevel25Cat3Piv1, 4] = 
    SOlevel25Cat3Bal7
 
fusionCategory[SOlevel25Cat3Piv1] ^= SOlevel25Cat3
 
SOlevel25Cat3Piv1 /: modularCategory[SOlevel25Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SOlevel25Cat3Piv1] ^= SOlevel25Cat3Piv1
 
pivotalIsomorphism[SOlevel25Cat3Piv1] ^= SOlevel25Cat3Piv1PivotalIsomorphism
 
SOlevel25Cat3Piv1 /: ribbonCategory[SOlevel25Cat3Piv1, 1] = SOlevel25Cat3Bal1
 
SOlevel25Cat3Piv1 /: ribbonCategory[SOlevel25Cat3Piv1, 2] = SOlevel25Cat3Bal3
 
SOlevel25Cat3Piv1 /: ribbonCategory[SOlevel25Cat3Piv1, 3] = SOlevel25Cat3Bal5
 
SOlevel25Cat3Piv1 /: ribbonCategory[SOlevel25Cat3Piv1, 4] = SOlevel25Cat3Bal7
 
ring[SOlevel25Cat3Piv1] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat3Piv1] ^= SOlevel25Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[SOlevel25Cat3]][pivotalCategory[#1]] & )[
    SOlevel25Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[SOlevel25Cat3]][
      sphericalCategory[#1]] & )[SOlevel25Cat3Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[SOlevel25Cat3Piv1PivotalIsomorphism] ^= SOlevel25Cat3
 
pivotalCategory[SOlevel25Cat3Piv1PivotalIsomorphism] ^= SOlevel25Cat3Piv1
 
pivotalIsomorphism[SOlevel25Cat3Piv1PivotalIsomorphism] ^= 
   SOlevel25Cat3Piv1PivotalIsomorphism
 
SOlevel25Cat3Piv1PivotalIsomorphism[0] = 1
 
SOlevel25Cat3Piv1PivotalIsomorphism[1] = 1
 
SOlevel25Cat3Piv1PivotalIsomorphism[2] = 1
 
SOlevel25Cat3Piv1PivotalIsomorphism[3] = 1
 
SOlevel25Cat3Piv1PivotalIsomorphism[4] = 1
 
SOlevel25Cat3Piv1PivotalIsomorphism[5] = 1
balancedCategories[SOlevel25Cat3Piv2] ^= {SOlevel25Cat3Bal2, 
    SOlevel25Cat3Bal4, SOlevel25Cat3Bal6, SOlevel25Cat3Bal8}
 
SOlevel25Cat3Piv2 /: balancedCategory[SOlevel25Cat3Piv2, 1] = 
    SOlevel25Cat3Bal2
 
SOlevel25Cat3Piv2 /: balancedCategory[SOlevel25Cat3Piv2, 2] = 
    SOlevel25Cat3Bal4
 
SOlevel25Cat3Piv2 /: balancedCategory[SOlevel25Cat3Piv2, 3] = 
    SOlevel25Cat3Bal6
 
SOlevel25Cat3Piv2 /: balancedCategory[SOlevel25Cat3Piv2, 4] = 
    SOlevel25Cat3Bal8
 
fusionCategory[SOlevel25Cat3Piv2] ^= SOlevel25Cat3
 
SOlevel25Cat3Piv2 /: modularCategory[SOlevel25Cat3Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SOlevel25Cat3Piv2] ^= SOlevel25Cat3Piv2
 
pivotalIsomorphism[SOlevel25Cat3Piv2] ^= SOlevel25Cat3Piv2PivotalIsomorphism
 
SOlevel25Cat3Piv2 /: ribbonCategory[SOlevel25Cat3Piv2, 1] = SOlevel25Cat3Bal2
 
SOlevel25Cat3Piv2 /: ribbonCategory[SOlevel25Cat3Piv2, 2] = SOlevel25Cat3Bal4
 
SOlevel25Cat3Piv2 /: ribbonCategory[SOlevel25Cat3Piv2, 3] = SOlevel25Cat3Bal6
 
SOlevel25Cat3Piv2 /: ribbonCategory[SOlevel25Cat3Piv2, 4] = SOlevel25Cat3Bal8
 
ring[SOlevel25Cat3Piv2] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat3Piv2] ^= SOlevel25Cat3Piv2
 
(pivotalCategoryIndex[fusionCategory[SOlevel25Cat3]][pivotalCategory[#1]] & )[
    SOlevel25Cat3Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[SOlevel25Cat3]][
      sphericalCategory[#1]] & )[SOlevel25Cat3Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[SOlevel25Cat3Piv2PivotalIsomorphism] ^= SOlevel25Cat3
 
pivotalCategory[SOlevel25Cat3Piv2PivotalIsomorphism] ^= SOlevel25Cat3Piv2
 
pivotalIsomorphism[SOlevel25Cat3Piv2PivotalIsomorphism] ^= 
   SOlevel25Cat3Piv2PivotalIsomorphism
 
SOlevel25Cat3Piv2PivotalIsomorphism[0] = 1
 
SOlevel25Cat3Piv2PivotalIsomorphism[1] = 1
 
SOlevel25Cat3Piv2PivotalIsomorphism[2] = -1
 
SOlevel25Cat3Piv2PivotalIsomorphism[3] = -1
 
SOlevel25Cat3Piv2PivotalIsomorphism[4] = 1
 
SOlevel25Cat3Piv2PivotalIsomorphism[5] = 1
balancedCategories[SOlevel25Cat4] ^= {SOlevel25Cat4Bal1, SOlevel25Cat4Bal2, 
    SOlevel25Cat4Bal3, SOlevel25Cat4Bal4, SOlevel25Cat4Bal5, 
    SOlevel25Cat4Bal6, SOlevel25Cat4Bal7, SOlevel25Cat4Bal8}
 
SOlevel25Cat4 /: balancedCategory[SOlevel25Cat4, 1] = SOlevel25Cat4Bal1
 
SOlevel25Cat4 /: balancedCategory[SOlevel25Cat4, 2] = SOlevel25Cat4Bal2
 
SOlevel25Cat4 /: balancedCategory[SOlevel25Cat4, 3] = SOlevel25Cat4Bal3
 
SOlevel25Cat4 /: balancedCategory[SOlevel25Cat4, 4] = SOlevel25Cat4Bal4
 
SOlevel25Cat4 /: balancedCategory[SOlevel25Cat4, 5] = SOlevel25Cat4Bal5
 
SOlevel25Cat4 /: balancedCategory[SOlevel25Cat4, 6] = SOlevel25Cat4Bal6
 
SOlevel25Cat4 /: balancedCategory[SOlevel25Cat4, 7] = SOlevel25Cat4Bal7
 
SOlevel25Cat4 /: balancedCategory[SOlevel25Cat4, 8] = SOlevel25Cat4Bal8
 
braidedCategories[SOlevel25Cat4] ^= {SOlevel25Cat4Brd1, SOlevel25Cat4Brd2, 
    SOlevel25Cat4Brd3, SOlevel25Cat4Brd4}
 
SOlevel25Cat4 /: braidedCategory[SOlevel25Cat4, 1] = SOlevel25Cat4Brd1
 
SOlevel25Cat4 /: braidedCategory[SOlevel25Cat4, 2] = SOlevel25Cat4Brd2
 
SOlevel25Cat4 /: braidedCategory[SOlevel25Cat4, 3] = SOlevel25Cat4Brd3
 
SOlevel25Cat4 /: braidedCategory[SOlevel25Cat4, 4] = SOlevel25Cat4Brd4
 
coeval[SOlevel25Cat4] ^= 1/sixJFunction[SOlevel25Cat4][#1, 
      dual[ring[SOlevel25Cat4]][#1], #1, #1, 0, 0] & 
 
eval[SOlevel25Cat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[SOlevel25Cat4] ^= SOlevel25Cat4FMatrixFunction
 
fusionCategory[SOlevel25Cat4] ^= SOlevel25Cat4
 
SOlevel25Cat4 /: modularCategory[SOlevel25Cat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[SOlevel25Cat4] ^= {SOlevel25Cat4Piv1, SOlevel25Cat4Piv2}
 
SOlevel25Cat4 /: pivotalCategory[SOlevel25Cat4, 1] = SOlevel25Cat4Piv1
 
SOlevel25Cat4 /: pivotalCategory[SOlevel25Cat4, 2] = SOlevel25Cat4Piv2
 
SOlevel25Cat4 /: pivotalCategory[SOlevel25Cat4, {1, 1, -1, -1, 1, 1}] = 
    SOlevel25Cat4Piv2
 
SOlevel25Cat4 /: pivotalCategory[SOlevel25Cat4, {1, 1, 1, 1, 1, 1}] = 
    SOlevel25Cat4Piv1
 
SOlevel25Cat4 /: ribbonCategory[SOlevel25Cat4, 1] = SOlevel25Cat4Bal1
 
SOlevel25Cat4 /: ribbonCategory[SOlevel25Cat4, 2] = SOlevel25Cat4Bal2
 
SOlevel25Cat4 /: ribbonCategory[SOlevel25Cat4, 3] = SOlevel25Cat4Bal3
 
SOlevel25Cat4 /: ribbonCategory[SOlevel25Cat4, 4] = SOlevel25Cat4Bal4
 
SOlevel25Cat4 /: ribbonCategory[SOlevel25Cat4, 5] = SOlevel25Cat4Bal5
 
SOlevel25Cat4 /: ribbonCategory[SOlevel25Cat4, 6] = SOlevel25Cat4Bal6
 
SOlevel25Cat4 /: ribbonCategory[SOlevel25Cat4, 7] = SOlevel25Cat4Bal7
 
SOlevel25Cat4 /: ribbonCategory[SOlevel25Cat4, 8] = SOlevel25Cat4Bal8
 
ring[SOlevel25Cat4] ^= SOlevel25
 
SOlevel25Cat4 /: sphericalCategory[SOlevel25Cat4, 1] = SOlevel25Cat4Piv1
 
SOlevel25Cat4 /: sphericalCategory[SOlevel25Cat4, 2] = SOlevel25Cat4Piv2
 
fusionCategoryIndex[SOlevel25][SOlevel25Cat4] ^= 4
balancedCategory[SOlevel25Cat4Bal1] ^= SOlevel25Cat4Bal1
 
braidedCategory[SOlevel25Cat4Bal1] ^= SOlevel25Cat4Brd1
 
fusionCategory[SOlevel25Cat4Bal1] ^= SOlevel25Cat4
 
pivotalCategory[SOlevel25Cat4Bal1] ^= SOlevel25Cat4Piv1
 
ribbonCategory[SOlevel25Cat4Bal1] ^= SOlevel25Cat4Bal1
 
ring[SOlevel25Cat4Bal1] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat4Bal1] ^= SOlevel25Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat4Brd1]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat4]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat4Piv1]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat4Brd1]][
      ribbonCategory[#1]] & )[SOlevel25Cat4Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat4]][ribbonCategory[#1]] & )[
    SOlevel25Cat4Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat4Piv1]][
      ribbonCategory[#1]] & )[SOlevel25Cat4Bal1] ^= 1
balancedCategory[SOlevel25Cat4Bal2] ^= SOlevel25Cat4Bal2
 
braidedCategory[SOlevel25Cat4Bal2] ^= SOlevel25Cat4Brd1
 
fusionCategory[SOlevel25Cat4Bal2] ^= SOlevel25Cat4
 
pivotalCategory[SOlevel25Cat4Bal2] ^= SOlevel25Cat4Piv2
 
ribbonCategory[SOlevel25Cat4Bal2] ^= SOlevel25Cat4Bal2
 
ring[SOlevel25Cat4Bal2] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat4Bal2] ^= SOlevel25Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat4Brd1]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat4]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat4Piv2]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat4Brd1]][
      ribbonCategory[#1]] & )[SOlevel25Cat4Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat4]][ribbonCategory[#1]] & )[
    SOlevel25Cat4Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat4Piv2]][
      ribbonCategory[#1]] & )[SOlevel25Cat4Bal2] ^= 1
balancedCategory[SOlevel25Cat4Bal3] ^= SOlevel25Cat4Bal3
 
braidedCategory[SOlevel25Cat4Bal3] ^= SOlevel25Cat4Brd2
 
fusionCategory[SOlevel25Cat4Bal3] ^= SOlevel25Cat4
 
pivotalCategory[SOlevel25Cat4Bal3] ^= SOlevel25Cat4Piv1
 
ribbonCategory[SOlevel25Cat4Bal3] ^= SOlevel25Cat4Bal3
 
ring[SOlevel25Cat4Bal3] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat4Bal3] ^= SOlevel25Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat4Brd2]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat4]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat4Piv1]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat4Brd2]][
      ribbonCategory[#1]] & )[SOlevel25Cat4Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat4]][ribbonCategory[#1]] & )[
    SOlevel25Cat4Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat4Piv1]][
      ribbonCategory[#1]] & )[SOlevel25Cat4Bal3] ^= 2
balancedCategory[SOlevel25Cat4Bal4] ^= SOlevel25Cat4Bal4
 
braidedCategory[SOlevel25Cat4Bal4] ^= SOlevel25Cat4Brd2
 
fusionCategory[SOlevel25Cat4Bal4] ^= SOlevel25Cat4
 
pivotalCategory[SOlevel25Cat4Bal4] ^= SOlevel25Cat4Piv2
 
ribbonCategory[SOlevel25Cat4Bal4] ^= SOlevel25Cat4Bal4
 
ring[SOlevel25Cat4Bal4] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat4Bal4] ^= SOlevel25Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat4Brd2]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat4]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat4Piv2]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat4Brd2]][
      ribbonCategory[#1]] & )[SOlevel25Cat4Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat4]][ribbonCategory[#1]] & )[
    SOlevel25Cat4Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat4Piv2]][
      ribbonCategory[#1]] & )[SOlevel25Cat4Bal4] ^= 2
balancedCategory[SOlevel25Cat4Bal5] ^= SOlevel25Cat4Bal5
 
braidedCategory[SOlevel25Cat4Bal5] ^= SOlevel25Cat4Brd3
 
fusionCategory[SOlevel25Cat4Bal5] ^= SOlevel25Cat4
 
pivotalCategory[SOlevel25Cat4Bal5] ^= SOlevel25Cat4Piv1
 
ribbonCategory[SOlevel25Cat4Bal5] ^= SOlevel25Cat4Bal5
 
ring[SOlevel25Cat4Bal5] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat4Bal5] ^= SOlevel25Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat4Brd3]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat4]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat4Piv1]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal5] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat4Brd3]][
      ribbonCategory[#1]] & )[SOlevel25Cat4Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat4]][ribbonCategory[#1]] & )[
    SOlevel25Cat4Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat4Piv1]][
      ribbonCategory[#1]] & )[SOlevel25Cat4Bal5] ^= 3
balancedCategory[SOlevel25Cat4Bal6] ^= SOlevel25Cat4Bal6
 
braidedCategory[SOlevel25Cat4Bal6] ^= SOlevel25Cat4Brd3
 
fusionCategory[SOlevel25Cat4Bal6] ^= SOlevel25Cat4
 
pivotalCategory[SOlevel25Cat4Bal6] ^= SOlevel25Cat4Piv2
 
ribbonCategory[SOlevel25Cat4Bal6] ^= SOlevel25Cat4Bal6
 
ring[SOlevel25Cat4Bal6] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat4Bal6] ^= SOlevel25Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat4Brd3]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat4]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat4Piv2]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal6] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat4Brd3]][
      ribbonCategory[#1]] & )[SOlevel25Cat4Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat4]][ribbonCategory[#1]] & )[
    SOlevel25Cat4Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat4Piv2]][
      ribbonCategory[#1]] & )[SOlevel25Cat4Bal6] ^= 3
balancedCategory[SOlevel25Cat4Bal7] ^= SOlevel25Cat4Bal7
 
braidedCategory[SOlevel25Cat4Bal7] ^= SOlevel25Cat4Brd4
 
fusionCategory[SOlevel25Cat4Bal7] ^= SOlevel25Cat4
 
pivotalCategory[SOlevel25Cat4Bal7] ^= SOlevel25Cat4Piv1
 
ribbonCategory[SOlevel25Cat4Bal7] ^= SOlevel25Cat4Bal7
 
ring[SOlevel25Cat4Bal7] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat4Bal7] ^= SOlevel25Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat4Brd4]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat4]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat4Piv1]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal7] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat4Brd4]][
      ribbonCategory[#1]] & )[SOlevel25Cat4Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat4]][ribbonCategory[#1]] & )[
    SOlevel25Cat4Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat4Piv1]][
      ribbonCategory[#1]] & )[SOlevel25Cat4Bal7] ^= 4
balancedCategory[SOlevel25Cat4Bal8] ^= SOlevel25Cat4Bal8
 
braidedCategory[SOlevel25Cat4Bal8] ^= SOlevel25Cat4Brd4
 
fusionCategory[SOlevel25Cat4Bal8] ^= SOlevel25Cat4
 
pivotalCategory[SOlevel25Cat4Bal8] ^= SOlevel25Cat4Piv2
 
ribbonCategory[SOlevel25Cat4Bal8] ^= SOlevel25Cat4Bal8
 
ring[SOlevel25Cat4Bal8] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat4Bal8] ^= SOlevel25Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel25Cat4Brd4]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel25Cat4]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[SOlevel25Cat4Piv2]][
      balancedCategory[#1]] & )[SOlevel25Cat4Bal8] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SOlevel25Cat4Brd4]][
      ribbonCategory[#1]] & )[SOlevel25Cat4Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel25Cat4]][ribbonCategory[#1]] & )[
    SOlevel25Cat4Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[SOlevel25Cat4Piv2]][
      ribbonCategory[#1]] & )[SOlevel25Cat4Bal8] ^= 4
balancedCategories[SOlevel25Cat4Brd1] ^= {SOlevel25Cat4Bal1, 
    SOlevel25Cat4Bal2}
 
SOlevel25Cat4Brd1 /: balancedCategory[SOlevel25Cat4Brd1, 1] = 
    SOlevel25Cat4Bal1
 
SOlevel25Cat4Brd1 /: balancedCategory[SOlevel25Cat4Brd1, 2] = 
    SOlevel25Cat4Bal2
 
braidedCategory[SOlevel25Cat4Brd1] ^= SOlevel25Cat4Brd1
 
fusionCategory[SOlevel25Cat4Brd1] ^= SOlevel25Cat4
 
SOlevel25Cat4Brd1 /: modularCategory[SOlevel25Cat4Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel25Cat4Brd1 /: ribbonCategory[SOlevel25Cat4Brd1, 1] = SOlevel25Cat4Bal1
 
SOlevel25Cat4Brd1 /: ribbonCategory[SOlevel25Cat4Brd1, 2] = SOlevel25Cat4Bal2
 
ring[SOlevel25Cat4Brd1] ^= SOlevel25
 
rMatrixFunction[SOlevel25Cat4Brd1] ^= SOlevel25Cat4Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel25Cat4]][braidedCategory[#1]] & )[
    SOlevel25Cat4Brd1] ^= 1
braidedCategory[SOlevel25Cat4Brd1RMatrixFunction] ^= SOlevel25Cat4Brd1
 
fusionCategory[SOlevel25Cat4Brd1RMatrixFunction] ^= SOlevel25Cat4
 
rMatrixFunction[SOlevel25Cat4Brd1RMatrixFunction] ^= 
   SOlevel25Cat4Brd1RMatrixFunction
 
SOlevel25Cat4Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[0, 5, 5] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[1, 2, 3] = {{-1}}
 
SOlevel25Cat4Brd1RMatrixFunction[1, 3, 2] = {{-1}}
 
SOlevel25Cat4Brd1RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[1, 5, 5] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[2, 1, 3] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[2, 2, 0] = {{-1}}
 
SOlevel25Cat4Brd1RMatrixFunction[2, 2, 4] = {{(-1)^(3/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[2, 2, 5] = {{-(-1)^(2/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[2, 3, 1] = {{-1}}
 
SOlevel25Cat4Brd1RMatrixFunction[2, 3, 4] = {{(-1)^(3/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[2, 3, 5] = {{-(-1)^(2/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[2, 4, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[2, 4, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[2, 5, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[2, 5, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[3, 1, 2] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[3, 2, 1] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[3, 2, 4] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[3, 2, 5] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[3, 3, 0] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[3, 3, 4] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[3, 3, 5] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[3, 4, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[3, 4, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[3, 5, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[3, 5, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[4, 2, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[4, 2, 3] = {{-(-1)^(2/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[4, 3, 2] = {{-(-1)^(2/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[4, 3, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[4, 4, 0] = {{(-1)^(4/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[4, 4, 1] = {{-(-1)^(4/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[4, 4, 5] = {{-(-1)^(1/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[4, 5, 4] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[4, 5, 5] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[5, 0, 5] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[5, 1, 5] = {{1}}
 
SOlevel25Cat4Brd1RMatrixFunction[5, 2, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[5, 2, 3] = {{(-1)^(3/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[5, 3, 2] = {{(-1)^(3/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[5, 3, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[5, 4, 4] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[5, 4, 5] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[5, 5, 0] = {{-(-1)^(1/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[5, 5, 1] = {{(-1)^(1/5)}}
 
SOlevel25Cat4Brd1RMatrixFunction[5, 5, 4] = {{(-1)^(4/5)}}
balancedCategories[SOlevel25Cat4Brd2] ^= {SOlevel25Cat4Bal3, 
    SOlevel25Cat4Bal4}
 
SOlevel25Cat4Brd2 /: balancedCategory[SOlevel25Cat4Brd2, 1] = 
    SOlevel25Cat4Bal3
 
SOlevel25Cat4Brd2 /: balancedCategory[SOlevel25Cat4Brd2, 2] = 
    SOlevel25Cat4Bal4
 
braidedCategory[SOlevel25Cat4Brd2] ^= SOlevel25Cat4Brd2
 
fusionCategory[SOlevel25Cat4Brd2] ^= SOlevel25Cat4
 
SOlevel25Cat4Brd2 /: modularCategory[SOlevel25Cat4Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel25Cat4Brd2 /: ribbonCategory[SOlevel25Cat4Brd2, 1] = SOlevel25Cat4Bal3
 
SOlevel25Cat4Brd2 /: ribbonCategory[SOlevel25Cat4Brd2, 2] = SOlevel25Cat4Bal4
 
ring[SOlevel25Cat4Brd2] ^= SOlevel25
 
rMatrixFunction[SOlevel25Cat4Brd2] ^= SOlevel25Cat4Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel25Cat4]][braidedCategory[#1]] & )[
    SOlevel25Cat4Brd2] ^= 2
braidedCategory[SOlevel25Cat4Brd2RMatrixFunction] ^= SOlevel25Cat4Brd2
 
fusionCategory[SOlevel25Cat4Brd2RMatrixFunction] ^= SOlevel25Cat4
 
rMatrixFunction[SOlevel25Cat4Brd2RMatrixFunction] ^= 
   SOlevel25Cat4Brd2RMatrixFunction
 
SOlevel25Cat4Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[0, 5, 5] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[1, 2, 3] = {{-1}}
 
SOlevel25Cat4Brd2RMatrixFunction[1, 3, 2] = {{-1}}
 
SOlevel25Cat4Brd2RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[1, 5, 5] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[2, 1, 3] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[2, 2, 0] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[2, 2, 4] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[2, 2, 5] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[2, 3, 1] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[2, 3, 4] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[2, 3, 5] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[2, 4, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[2, 4, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[2, 5, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[2, 5, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[3, 1, 2] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[3, 2, 1] = {{-1}}
 
SOlevel25Cat4Brd2RMatrixFunction[3, 2, 4] = {{(-1)^(3/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[3, 2, 5] = {{-(-1)^(2/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[3, 3, 0] = {{-1}}
 
SOlevel25Cat4Brd2RMatrixFunction[3, 3, 4] = {{(-1)^(3/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[3, 3, 5] = {{-(-1)^(2/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[3, 4, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[3, 4, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[3, 5, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[3, 5, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[4, 2, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[4, 2, 3] = {{-(-1)^(2/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[4, 3, 2] = {{-(-1)^(2/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[4, 3, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[4, 4, 0] = {{(-1)^(4/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[4, 4, 1] = {{-(-1)^(4/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[4, 4, 5] = {{-(-1)^(1/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[4, 5, 4] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[4, 5, 5] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[5, 0, 5] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[5, 1, 5] = {{1}}
 
SOlevel25Cat4Brd2RMatrixFunction[5, 2, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[5, 2, 3] = {{(-1)^(3/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[5, 3, 2] = {{(-1)^(3/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[5, 3, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[5, 4, 4] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[5, 4, 5] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[5, 5, 0] = {{-(-1)^(1/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[5, 5, 1] = {{(-1)^(1/5)}}
 
SOlevel25Cat4Brd2RMatrixFunction[5, 5, 4] = {{(-1)^(4/5)}}
balancedCategories[SOlevel25Cat4Brd3] ^= {SOlevel25Cat4Bal5, 
    SOlevel25Cat4Bal6}
 
SOlevel25Cat4Brd3 /: balancedCategory[SOlevel25Cat4Brd3, 1] = 
    SOlevel25Cat4Bal5
 
SOlevel25Cat4Brd3 /: balancedCategory[SOlevel25Cat4Brd3, 2] = 
    SOlevel25Cat4Bal6
 
braidedCategory[SOlevel25Cat4Brd3] ^= SOlevel25Cat4Brd3
 
fusionCategory[SOlevel25Cat4Brd3] ^= SOlevel25Cat4
 
SOlevel25Cat4Brd3 /: modularCategory[SOlevel25Cat4Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel25Cat4Brd3 /: ribbonCategory[SOlevel25Cat4Brd3, 1] = SOlevel25Cat4Bal5
 
SOlevel25Cat4Brd3 /: ribbonCategory[SOlevel25Cat4Brd3, 2] = SOlevel25Cat4Bal6
 
ring[SOlevel25Cat4Brd3] ^= SOlevel25
 
rMatrixFunction[SOlevel25Cat4Brd3] ^= SOlevel25Cat4Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel25Cat4]][braidedCategory[#1]] & )[
    SOlevel25Cat4Brd3] ^= 3
braidedCategory[SOlevel25Cat4Brd3RMatrixFunction] ^= SOlevel25Cat4Brd3
 
fusionCategory[SOlevel25Cat4Brd3RMatrixFunction] ^= SOlevel25Cat4
 
rMatrixFunction[SOlevel25Cat4Brd3RMatrixFunction] ^= 
   SOlevel25Cat4Brd3RMatrixFunction
 
SOlevel25Cat4Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[0, 5, 5] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[1, 2, 3] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[1, 3, 2] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[1, 5, 5] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[2, 1, 3] = {{-1}}
 
SOlevel25Cat4Brd3RMatrixFunction[2, 2, 0] = {{-1}}
 
SOlevel25Cat4Brd3RMatrixFunction[2, 2, 4] = {{-(-1)^(2/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[2, 2, 5] = {{(-1)^(3/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[2, 3, 1] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[2, 3, 4] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[2, 3, 5] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[2, 4, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[2, 4, 3] = {{(-1)^(3/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[2, 5, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[2, 5, 3] = {{-(-1)^(2/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[3, 1, 2] = {{-1}}
 
SOlevel25Cat4Brd3RMatrixFunction[3, 2, 1] = {{-1}}
 
SOlevel25Cat4Brd3RMatrixFunction[3, 2, 4] = {{-(-1)^(2/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[3, 2, 5] = {{(-1)^(3/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[3, 3, 0] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[3, 3, 4] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[3, 3, 5] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[3, 4, 2] = {{(-1)^(3/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[3, 4, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[3, 5, 2] = {{-(-1)^(2/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[3, 5, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[4, 2, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[4, 2, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[4, 3, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[4, 3, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[4, 4, 0] = {{-(-1)^(1/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[4, 4, 1] = {{(-1)^(1/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[4, 4, 5] = {{(-1)^(4/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[4, 5, 4] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[4, 5, 5] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[5, 0, 5] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[5, 1, 5] = {{1}}
 
SOlevel25Cat4Brd3RMatrixFunction[5, 2, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[5, 2, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[5, 3, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[5, 3, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[5, 4, 4] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[5, 4, 5] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[5, 5, 0] = {{(-1)^(4/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[5, 5, 1] = {{-(-1)^(4/5)}}
 
SOlevel25Cat4Brd3RMatrixFunction[5, 5, 4] = {{-(-1)^(1/5)}}
balancedCategories[SOlevel25Cat4Brd4] ^= {SOlevel25Cat4Bal7, 
    SOlevel25Cat4Bal8}
 
SOlevel25Cat4Brd4 /: balancedCategory[SOlevel25Cat4Brd4, 1] = 
    SOlevel25Cat4Bal7
 
SOlevel25Cat4Brd4 /: balancedCategory[SOlevel25Cat4Brd4, 2] = 
    SOlevel25Cat4Bal8
 
braidedCategory[SOlevel25Cat4Brd4] ^= SOlevel25Cat4Brd4
 
fusionCategory[SOlevel25Cat4Brd4] ^= SOlevel25Cat4
 
SOlevel25Cat4Brd4 /: modularCategory[SOlevel25Cat4Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel25Cat4Brd4 /: ribbonCategory[SOlevel25Cat4Brd4, 1] = SOlevel25Cat4Bal7
 
SOlevel25Cat4Brd4 /: ribbonCategory[SOlevel25Cat4Brd4, 2] = SOlevel25Cat4Bal8
 
ring[SOlevel25Cat4Brd4] ^= SOlevel25
 
rMatrixFunction[SOlevel25Cat4Brd4] ^= SOlevel25Cat4Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel25Cat4]][braidedCategory[#1]] & )[
    SOlevel25Cat4Brd4] ^= 4
braidedCategory[SOlevel25Cat4Brd4RMatrixFunction] ^= SOlevel25Cat4Brd4
 
fusionCategory[SOlevel25Cat4Brd4RMatrixFunction] ^= SOlevel25Cat4
 
rMatrixFunction[SOlevel25Cat4Brd4RMatrixFunction] ^= 
   SOlevel25Cat4Brd4RMatrixFunction
 
SOlevel25Cat4Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[0, 5, 5] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[1, 2, 3] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[1, 3, 2] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[1, 5, 5] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[2, 1, 3] = {{-1}}
 
SOlevel25Cat4Brd4RMatrixFunction[2, 2, 0] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[2, 2, 4] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[2, 2, 5] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[2, 3, 1] = {{-1}}
 
SOlevel25Cat4Brd4RMatrixFunction[2, 3, 4] = {{-(-1)^(2/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[2, 3, 5] = {{(-1)^(3/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[2, 4, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[2, 4, 3] = {{(-1)^(3/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[2, 5, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[2, 5, 3] = {{-(-1)^(2/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[3, 1, 2] = {{-1}}
 
SOlevel25Cat4Brd4RMatrixFunction[3, 2, 1] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[3, 2, 4] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[3, 2, 5] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[3, 3, 0] = {{-1}}
 
SOlevel25Cat4Brd4RMatrixFunction[3, 3, 4] = {{-(-1)^(2/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[3, 3, 5] = {{(-1)^(3/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[3, 4, 2] = {{(-1)^(3/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[3, 4, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[3, 5, 2] = {{-(-1)^(2/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[3, 5, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[4, 2, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[4, 2, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[4, 3, 2] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[4, 3, 3] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[4, 4, 0] = {{-(-1)^(1/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[4, 4, 1] = {{(-1)^(1/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[4, 4, 5] = {{(-1)^(4/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[4, 5, 4] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[4, 5, 5] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[5, 0, 5] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[5, 1, 5] = {{1}}
 
SOlevel25Cat4Brd4RMatrixFunction[5, 2, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[5, 2, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[5, 3, 2] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[5, 3, 3] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[5, 4, 4] = {{(-1)^(2/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[5, 4, 5] = {{-(-1)^(3/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[5, 5, 0] = {{(-1)^(4/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[5, 5, 1] = {{-(-1)^(4/5)}}
 
SOlevel25Cat4Brd4RMatrixFunction[5, 5, 4] = {{-(-1)^(1/5)}}
fMatrixFunction[SOlevel25Cat4FMatrixFunction] ^= SOlevel25Cat4FMatrixFunction
 
fusionCategory[SOlevel25Cat4FMatrixFunction] ^= SOlevel25Cat4
 
ring[SOlevel25Cat4FMatrixFunction] ^= SOlevel25
 
SOlevel25Cat4FMatrixFunction[1, 2, 2, 4] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[1, 2, 2, 5] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[1, 2, 3, 4] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[1, 2, 3, 5] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[1, 3, 2, 4] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[1, 3, 2, 5] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[1, 3, 3, 4] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[1, 3, 3, 5] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[1, 4, 4, 0] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[1, 4, 4, 1] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[1, 4, 5, 5] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[1, 5, 4, 5] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[1, 5, 5, 0] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[1, 5, 5, 1] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[1, 5, 5, 4] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[2, 2, 1, 4] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[2, 2, 1, 5] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[2, 2, 2, 2] = 
   {{1/Sqrt[5], -(1/Sqrt[5]), -(1/Sqrt[5])}, {-2/Sqrt[5], (-5 - Sqrt[5])/10, 
     (5 - Sqrt[5])/10}, {-2/Sqrt[5], (5 - Sqrt[5])/10, (-5 - Sqrt[5])/10}}
 
SOlevel25Cat4FMatrixFunction[2, 2, 2, 3] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0]}}
 
SOlevel25Cat4FMatrixFunction[2, 2, 3, 2] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0]}}
 
SOlevel25Cat4FMatrixFunction[2, 2, 3, 3] = 
   {{1/Sqrt[5], -(1/Sqrt[5]), -(1/Sqrt[5])}, {2/Sqrt[5], (5 + Sqrt[5])/10, 
     (-5 + Sqrt[5])/10}, {2/Sqrt[5], (-5 + Sqrt[5])/10, (5 + Sqrt[5])/10}}
 
SOlevel25Cat4FMatrixFunction[2, 2, 4, 4] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat4FMatrixFunction[2, 2, 4, 5] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat4FMatrixFunction[2, 2, 5, 4] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat4FMatrixFunction[2, 2, 5, 5] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat4FMatrixFunction[2, 3, 1, 4] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[2, 3, 1, 5] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[2, 3, 2, 2] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0]}}
 
SOlevel25Cat4FMatrixFunction[2, 3, 2, 3] = 
   {{1/Sqrt[5], 1/Sqrt[5], 1/Sqrt[5]}, {2/Sqrt[5], (-5 - Sqrt[5])/10, 
     (5 - Sqrt[5])/10}, {2/Sqrt[5], (5 - Sqrt[5])/10, (-5 - Sqrt[5])/10}}
 
SOlevel25Cat4FMatrixFunction[2, 3, 3, 2] = 
   {{1/Sqrt[5], 1/Sqrt[5], 1/Sqrt[5]}, {-2/Sqrt[5], (5 + Sqrt[5])/10, 
     (-5 + Sqrt[5])/10}, {-2/Sqrt[5], (-5 + Sqrt[5])/10, (5 + Sqrt[5])/10}}
 
SOlevel25Cat4FMatrixFunction[2, 3, 3, 3] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0]}}
 
SOlevel25Cat4FMatrixFunction[2, 3, 4, 4] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat4FMatrixFunction[2, 3, 4, 5] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat4FMatrixFunction[2, 3, 5, 4] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat4FMatrixFunction[2, 3, 5, 5] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat4FMatrixFunction[2, 4, 2, 4] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat4FMatrixFunction[2, 4, 2, 5] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat4FMatrixFunction[2, 4, 3, 4] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}}
 
SOlevel25Cat4FMatrixFunction[2, 4, 3, 5] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}}
 
SOlevel25Cat4FMatrixFunction[2, 4, 4, 2] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[2, 4, 4, 3] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[2, 4, 5, 2] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[2, 4, 5, 3] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat4FMatrixFunction[2, 5, 2, 4] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat4FMatrixFunction[2, 5, 2, 5] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat4FMatrixFunction[2, 5, 3, 4] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}}
 
SOlevel25Cat4FMatrixFunction[2, 5, 3, 5] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}}
 
SOlevel25Cat4FMatrixFunction[2, 5, 4, 2] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[2, 5, 4, 3] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat4FMatrixFunction[2, 5, 5, 2] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[2, 5, 5, 3] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat4FMatrixFunction[3, 2, 1, 4] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[3, 2, 1, 5] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[3, 2, 2, 2] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0]}}
 
SOlevel25Cat4FMatrixFunction[3, 2, 2, 3] = 
   {{1/Sqrt[5], 1/Sqrt[5], 1/Sqrt[5]}, {-2/Sqrt[5], (5 + Sqrt[5])/10, 
     (-5 + Sqrt[5])/10}, {-2/Sqrt[5], (-5 + Sqrt[5])/10, (5 + Sqrt[5])/10}}
 
SOlevel25Cat4FMatrixFunction[3, 2, 3, 2] = 
   {{1/Sqrt[5], 1/Sqrt[5], 1/Sqrt[5]}, {2/Sqrt[5], (-5 - Sqrt[5])/10, 
     (5 - Sqrt[5])/10}, {2/Sqrt[5], (5 - Sqrt[5])/10, (-5 - Sqrt[5])/10}}
 
SOlevel25Cat4FMatrixFunction[3, 2, 3, 3] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0]}}
 
SOlevel25Cat4FMatrixFunction[3, 2, 4, 4] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat4FMatrixFunction[3, 2, 4, 5] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat4FMatrixFunction[3, 2, 5, 4] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat4FMatrixFunction[3, 2, 5, 5] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat4FMatrixFunction[3, 3, 1, 4] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[3, 3, 1, 5] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[3, 3, 2, 2] = 
   {{1/Sqrt[5], -(1/Sqrt[5]), -(1/Sqrt[5])}, {2/Sqrt[5], (5 + Sqrt[5])/10, 
     (-5 + Sqrt[5])/10}, {2/Sqrt[5], (-5 + Sqrt[5])/10, (5 + Sqrt[5])/10}}
 
SOlevel25Cat4FMatrixFunction[3, 3, 2, 3] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 4, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0]}}
 
SOlevel25Cat4FMatrixFunction[3, 3, 3, 2] = 
   {{Root[1 + 5*#1^2 + 5*#1^4 & , 2, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0]}, 
    {Root[1 + 5*#1^2 + 5*#1^4 & , 3, 0], Root[1 + 5*#1^2 + 5*#1^4 & , 1, 0]}}
 
SOlevel25Cat4FMatrixFunction[3, 3, 3, 3] = 
   {{1/Sqrt[5], -(1/Sqrt[5]), -(1/Sqrt[5])}, {-2/Sqrt[5], (-5 - Sqrt[5])/10, 
     (5 - Sqrt[5])/10}, {-2/Sqrt[5], (5 - Sqrt[5])/10, (-5 - Sqrt[5])/10}}
 
SOlevel25Cat4FMatrixFunction[3, 3, 4, 4] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat4FMatrixFunction[3, 3, 4, 5] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat4FMatrixFunction[3, 3, 5, 4] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat4FMatrixFunction[3, 3, 5, 5] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat4FMatrixFunction[3, 4, 2, 4] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}}
 
SOlevel25Cat4FMatrixFunction[3, 4, 2, 5] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}}
 
SOlevel25Cat4FMatrixFunction[3, 4, 3, 4] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat4FMatrixFunction[3, 4, 3, 5] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat4FMatrixFunction[3, 4, 4, 2] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[3, 4, 4, 3] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[3, 4, 5, 2] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat4FMatrixFunction[3, 4, 5, 3] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[3, 5, 2, 4] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}}
 
SOlevel25Cat4FMatrixFunction[3, 5, 2, 5] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}}
 
SOlevel25Cat4FMatrixFunction[3, 5, 3, 4] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 3, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat4FMatrixFunction[3, 5, 3, 5] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat4FMatrixFunction[3, 5, 4, 2] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat4FMatrixFunction[3, 5, 4, 3] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[3, 5, 5, 2] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat4FMatrixFunction[3, 5, 5, 3] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[4, 1, 4, 0] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[4, 1, 4, 1] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[4, 1, 5, 4] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[4, 2, 2, 1] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[4, 2, 2, 4] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[4, 2, 2, 5] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[4, 2, 3, 1] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[4, 2, 3, 4] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[4, 2, 3, 5] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat4FMatrixFunction[4, 2, 4, 2] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat4FMatrixFunction[4, 2, 4, 3] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}}
 
SOlevel25Cat4FMatrixFunction[4, 2, 5, 2] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat4FMatrixFunction[4, 2, 5, 3] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}}
 
SOlevel25Cat4FMatrixFunction[4, 3, 2, 1] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[4, 3, 2, 4] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[4, 3, 2, 5] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat4FMatrixFunction[4, 3, 3, 1] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[4, 3, 3, 4] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[4, 3, 3, 5] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[4, 3, 4, 2] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}}
 
SOlevel25Cat4FMatrixFunction[4, 3, 4, 3] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 1, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat4FMatrixFunction[4, 3, 5, 2] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}}
 
SOlevel25Cat4FMatrixFunction[4, 3, 5, 3] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat4FMatrixFunction[4, 4, 2, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat4FMatrixFunction[4, 4, 2, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat4FMatrixFunction[4, 4, 3, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat4FMatrixFunction[4, 4, 3, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat4FMatrixFunction[4, 4, 4, 4] = {{1/2, -1/2, -1}, {1/2, -1/2, 1}, 
    {-1/2, -1/2, 0}}
 
SOlevel25Cat4FMatrixFunction[4, 4, 5, 5] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[4, 5, 1, 5] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[4, 5, 2, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat4FMatrixFunction[4, 5, 2, 3] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat4FMatrixFunction[4, 5, 3, 2] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat4FMatrixFunction[4, 5, 3, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat4FMatrixFunction[4, 5, 4, 1] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[4, 5, 4, 5] = {{0, 1}, {1, 0}}
 
SOlevel25Cat4FMatrixFunction[4, 5, 5, 1] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[4, 5, 5, 4] = {{-1, -1}, {-1, 1}}
 
SOlevel25Cat4FMatrixFunction[5, 1, 4, 4] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[5, 1, 5, 0] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[5, 1, 5, 1] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[5, 2, 2, 1] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[5, 2, 2, 4] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[5, 2, 2, 5] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[5, 2, 3, 1] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[5, 2, 3, 4] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat4FMatrixFunction[5, 2, 3, 5] = {{1/2, -1/2}, {1/2, 1/2}}
 
SOlevel25Cat4FMatrixFunction[5, 2, 4, 2] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat4FMatrixFunction[5, 2, 4, 3] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}}
 
SOlevel25Cat4FMatrixFunction[5, 2, 5, 2] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat4FMatrixFunction[5, 2, 5, 3] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}}
 
SOlevel25Cat4FMatrixFunction[5, 3, 2, 1] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[5, 3, 2, 4] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat4FMatrixFunction[5, 3, 2, 5] = {{-1/2, 1/2}, {1/2, 1/2}}
 
SOlevel25Cat4FMatrixFunction[5, 3, 3, 1] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[5, 3, 3, 4] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[5, 3, 3, 5] = {{1/2, -1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[5, 3, 4, 2] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}, 
    {(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}}
 
SOlevel25Cat4FMatrixFunction[5, 3, 4, 3] = 
   {{(-1 + Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 4, 0], (-1 + Sqrt[5])/4}}
 
SOlevel25Cat4FMatrixFunction[5, 3, 5, 2] = 
   {{Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}, 
    {(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}}
 
SOlevel25Cat4FMatrixFunction[5, 3, 5, 3] = 
   {{(-1 - Sqrt[5])/4, Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0]}, 
    {Root[5 + 20*#1^2 + 16*#1^4 & , 2, 0], (-1 - Sqrt[5])/4}}
 
SOlevel25Cat4FMatrixFunction[5, 4, 1, 4] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[5, 4, 1, 5] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[5, 4, 2, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat4FMatrixFunction[5, 4, 2, 3] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat4FMatrixFunction[5, 4, 3, 2] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat4FMatrixFunction[5, 4, 3, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat4FMatrixFunction[5, 4, 4, 5] = {{-1, -1}, {-1, 1}}
 
SOlevel25Cat4FMatrixFunction[5, 4, 5, 1] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[5, 4, 5, 4] = {{0, 1}, {1, 0}}
 
SOlevel25Cat4FMatrixFunction[5, 5, 1, 4] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[5, 5, 2, 2] = {{-1, -1}, {1, -1}}
 
SOlevel25Cat4FMatrixFunction[5, 5, 2, 3] = {{1, 1}, {-1, 1}}
 
SOlevel25Cat4FMatrixFunction[5, 5, 3, 2] = {{-1, 1}, {1, 1}}
 
SOlevel25Cat4FMatrixFunction[5, 5, 3, 3] = {{1, -1}, {-1, -1}}
 
SOlevel25Cat4FMatrixFunction[5, 5, 4, 1] = {{-1}}
 
SOlevel25Cat4FMatrixFunction[5, 5, 4, 4] = {{-1/2, 1/2}, {-1/2, -1/2}}
 
SOlevel25Cat4FMatrixFunction[5, 5, 5, 5] = {{1/2, -1/2, -1}, {1/2, -1/2, 1}, 
    {-1/2, -1/2, 0}}
 
SOlevel25Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SOlevel25Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
SOlevel25Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SOlevel25Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[SOlevel25Cat4Piv1] ^= {SOlevel25Cat4Bal1, 
    SOlevel25Cat4Bal3, SOlevel25Cat4Bal5, SOlevel25Cat4Bal7}
 
SOlevel25Cat4Piv1 /: balancedCategory[SOlevel25Cat4Piv1, 1] = 
    SOlevel25Cat4Bal1
 
SOlevel25Cat4Piv1 /: balancedCategory[SOlevel25Cat4Piv1, 2] = 
    SOlevel25Cat4Bal3
 
SOlevel25Cat4Piv1 /: balancedCategory[SOlevel25Cat4Piv1, 3] = 
    SOlevel25Cat4Bal5
 
SOlevel25Cat4Piv1 /: balancedCategory[SOlevel25Cat4Piv1, 4] = 
    SOlevel25Cat4Bal7
 
fusionCategory[SOlevel25Cat4Piv1] ^= SOlevel25Cat4
 
SOlevel25Cat4Piv1 /: modularCategory[SOlevel25Cat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SOlevel25Cat4Piv1] ^= SOlevel25Cat4Piv1
 
pivotalIsomorphism[SOlevel25Cat4Piv1] ^= SOlevel25Cat4Piv1PivotalIsomorphism
 
SOlevel25Cat4Piv1 /: ribbonCategory[SOlevel25Cat4Piv1, 1] = SOlevel25Cat4Bal1
 
SOlevel25Cat4Piv1 /: ribbonCategory[SOlevel25Cat4Piv1, 2] = SOlevel25Cat4Bal3
 
SOlevel25Cat4Piv1 /: ribbonCategory[SOlevel25Cat4Piv1, 3] = SOlevel25Cat4Bal5
 
SOlevel25Cat4Piv1 /: ribbonCategory[SOlevel25Cat4Piv1, 4] = SOlevel25Cat4Bal7
 
ring[SOlevel25Cat4Piv1] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat4Piv1] ^= SOlevel25Cat4Piv1
 
(pivotalCategoryIndex[fusionCategory[SOlevel25Cat4]][pivotalCategory[#1]] & )[
    SOlevel25Cat4Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[SOlevel25Cat4]][
      sphericalCategory[#1]] & )[SOlevel25Cat4Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[SOlevel25Cat4Piv1PivotalIsomorphism] ^= SOlevel25Cat4
 
pivotalCategory[SOlevel25Cat4Piv1PivotalIsomorphism] ^= SOlevel25Cat4Piv1
 
pivotalIsomorphism[SOlevel25Cat4Piv1PivotalIsomorphism] ^= 
   SOlevel25Cat4Piv1PivotalIsomorphism
 
SOlevel25Cat4Piv1PivotalIsomorphism[0] = 1
 
SOlevel25Cat4Piv1PivotalIsomorphism[1] = 1
 
SOlevel25Cat4Piv1PivotalIsomorphism[2] = 1
 
SOlevel25Cat4Piv1PivotalIsomorphism[3] = 1
 
SOlevel25Cat4Piv1PivotalIsomorphism[4] = 1
 
SOlevel25Cat4Piv1PivotalIsomorphism[5] = 1
balancedCategories[SOlevel25Cat4Piv2] ^= {SOlevel25Cat4Bal2, 
    SOlevel25Cat4Bal4, SOlevel25Cat4Bal6, SOlevel25Cat4Bal8}
 
SOlevel25Cat4Piv2 /: balancedCategory[SOlevel25Cat4Piv2, 1] = 
    SOlevel25Cat4Bal2
 
SOlevel25Cat4Piv2 /: balancedCategory[SOlevel25Cat4Piv2, 2] = 
    SOlevel25Cat4Bal4
 
SOlevel25Cat4Piv2 /: balancedCategory[SOlevel25Cat4Piv2, 3] = 
    SOlevel25Cat4Bal6
 
SOlevel25Cat4Piv2 /: balancedCategory[SOlevel25Cat4Piv2, 4] = 
    SOlevel25Cat4Bal8
 
fusionCategory[SOlevel25Cat4Piv2] ^= SOlevel25Cat4
 
SOlevel25Cat4Piv2 /: modularCategory[SOlevel25Cat4Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SOlevel25Cat4Piv2] ^= SOlevel25Cat4Piv2
 
pivotalIsomorphism[SOlevel25Cat4Piv2] ^= SOlevel25Cat4Piv2PivotalIsomorphism
 
SOlevel25Cat4Piv2 /: ribbonCategory[SOlevel25Cat4Piv2, 1] = SOlevel25Cat4Bal2
 
SOlevel25Cat4Piv2 /: ribbonCategory[SOlevel25Cat4Piv2, 2] = SOlevel25Cat4Bal4
 
SOlevel25Cat4Piv2 /: ribbonCategory[SOlevel25Cat4Piv2, 3] = SOlevel25Cat4Bal6
 
SOlevel25Cat4Piv2 /: ribbonCategory[SOlevel25Cat4Piv2, 4] = SOlevel25Cat4Bal8
 
ring[SOlevel25Cat4Piv2] ^= SOlevel25
 
sphericalCategory[SOlevel25Cat4Piv2] ^= SOlevel25Cat4Piv2
 
(pivotalCategoryIndex[fusionCategory[SOlevel25Cat4]][pivotalCategory[#1]] & )[
    SOlevel25Cat4Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[SOlevel25Cat4]][
      sphericalCategory[#1]] & )[SOlevel25Cat4Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[SOlevel25Cat4Piv2PivotalIsomorphism] ^= SOlevel25Cat4
 
pivotalCategory[SOlevel25Cat4Piv2PivotalIsomorphism] ^= SOlevel25Cat4Piv2
 
pivotalIsomorphism[SOlevel25Cat4Piv2PivotalIsomorphism] ^= 
   SOlevel25Cat4Piv2PivotalIsomorphism
 
SOlevel25Cat4Piv2PivotalIsomorphism[0] = 1
 
SOlevel25Cat4Piv2PivotalIsomorphism[1] = 1
 
SOlevel25Cat4Piv2PivotalIsomorphism[2] = -1
 
SOlevel25Cat4Piv2PivotalIsomorphism[3] = -1
 
SOlevel25Cat4Piv2PivotalIsomorphism[4] = 1
 
SOlevel25Cat4Piv2PivotalIsomorphism[5] = 1
ring[SOlevel25NFunction] ^= SOlevel25
 
SOlevel25NFunction[0, 0, 0] = 1
 
SOlevel25NFunction[0, 0, 1] = 0
 
SOlevel25NFunction[0, 0, 2] = 0
 
SOlevel25NFunction[0, 0, 3] = 0
 
SOlevel25NFunction[0, 0, 4] = 0
 
SOlevel25NFunction[0, 0, 5] = 0
 
SOlevel25NFunction[0, 1, 0] = 0
 
SOlevel25NFunction[0, 1, 1] = 1
 
SOlevel25NFunction[0, 1, 2] = 0
 
SOlevel25NFunction[0, 1, 3] = 0
 
SOlevel25NFunction[0, 1, 4] = 0
 
SOlevel25NFunction[0, 1, 5] = 0
 
SOlevel25NFunction[0, 2, 0] = 0
 
SOlevel25NFunction[0, 2, 1] = 0
 
SOlevel25NFunction[0, 2, 2] = 1
 
SOlevel25NFunction[0, 2, 3] = 0
 
SOlevel25NFunction[0, 2, 4] = 0
 
SOlevel25NFunction[0, 2, 5] = 0
 
SOlevel25NFunction[0, 3, 0] = 0
 
SOlevel25NFunction[0, 3, 1] = 0
 
SOlevel25NFunction[0, 3, 2] = 0
 
SOlevel25NFunction[0, 3, 3] = 1
 
SOlevel25NFunction[0, 3, 4] = 0
 
SOlevel25NFunction[0, 3, 5] = 0
 
SOlevel25NFunction[0, 4, 0] = 0
 
SOlevel25NFunction[0, 4, 1] = 0
 
SOlevel25NFunction[0, 4, 2] = 0
 
SOlevel25NFunction[0, 4, 3] = 0
 
SOlevel25NFunction[0, 4, 4] = 1
 
SOlevel25NFunction[0, 4, 5] = 0
 
SOlevel25NFunction[0, 5, 0] = 0
 
SOlevel25NFunction[0, 5, 1] = 0
 
SOlevel25NFunction[0, 5, 2] = 0
 
SOlevel25NFunction[0, 5, 3] = 0
 
SOlevel25NFunction[0, 5, 4] = 0
 
SOlevel25NFunction[0, 5, 5] = 1
 
SOlevel25NFunction[1, 0, 0] = 0
 
SOlevel25NFunction[1, 0, 1] = 1
 
SOlevel25NFunction[1, 0, 2] = 0
 
SOlevel25NFunction[1, 0, 3] = 0
 
SOlevel25NFunction[1, 0, 4] = 0
 
SOlevel25NFunction[1, 0, 5] = 0
 
SOlevel25NFunction[1, 1, 0] = 1
 
SOlevel25NFunction[1, 1, 1] = 0
 
SOlevel25NFunction[1, 1, 2] = 0
 
SOlevel25NFunction[1, 1, 3] = 0
 
SOlevel25NFunction[1, 1, 4] = 0
 
SOlevel25NFunction[1, 1, 5] = 0
 
SOlevel25NFunction[1, 2, 0] = 0
 
SOlevel25NFunction[1, 2, 1] = 0
 
SOlevel25NFunction[1, 2, 2] = 0
 
SOlevel25NFunction[1, 2, 3] = 1
 
SOlevel25NFunction[1, 2, 4] = 0
 
SOlevel25NFunction[1, 2, 5] = 0
 
SOlevel25NFunction[1, 3, 0] = 0
 
SOlevel25NFunction[1, 3, 1] = 0
 
SOlevel25NFunction[1, 3, 2] = 1
 
SOlevel25NFunction[1, 3, 3] = 0
 
SOlevel25NFunction[1, 3, 4] = 0
 
SOlevel25NFunction[1, 3, 5] = 0
 
SOlevel25NFunction[1, 4, 0] = 0
 
SOlevel25NFunction[1, 4, 1] = 0
 
SOlevel25NFunction[1, 4, 2] = 0
 
SOlevel25NFunction[1, 4, 3] = 0
 
SOlevel25NFunction[1, 4, 4] = 1
 
SOlevel25NFunction[1, 4, 5] = 0
 
SOlevel25NFunction[1, 5, 0] = 0
 
SOlevel25NFunction[1, 5, 1] = 0
 
SOlevel25NFunction[1, 5, 2] = 0
 
SOlevel25NFunction[1, 5, 3] = 0
 
SOlevel25NFunction[1, 5, 4] = 0
 
SOlevel25NFunction[1, 5, 5] = 1
 
SOlevel25NFunction[2, 0, 0] = 0
 
SOlevel25NFunction[2, 0, 1] = 0
 
SOlevel25NFunction[2, 0, 2] = 1
 
SOlevel25NFunction[2, 0, 3] = 0
 
SOlevel25NFunction[2, 0, 4] = 0
 
SOlevel25NFunction[2, 0, 5] = 0
 
SOlevel25NFunction[2, 1, 0] = 0
 
SOlevel25NFunction[2, 1, 1] = 0
 
SOlevel25NFunction[2, 1, 2] = 0
 
SOlevel25NFunction[2, 1, 3] = 1
 
SOlevel25NFunction[2, 1, 4] = 0
 
SOlevel25NFunction[2, 1, 5] = 0
 
SOlevel25NFunction[2, 2, 0] = 1
 
SOlevel25NFunction[2, 2, 1] = 0
 
SOlevel25NFunction[2, 2, 2] = 0
 
SOlevel25NFunction[2, 2, 3] = 0
 
SOlevel25NFunction[2, 2, 4] = 1
 
SOlevel25NFunction[2, 2, 5] = 1
 
SOlevel25NFunction[2, 3, 0] = 0
 
SOlevel25NFunction[2, 3, 1] = 1
 
SOlevel25NFunction[2, 3, 2] = 0
 
SOlevel25NFunction[2, 3, 3] = 0
 
SOlevel25NFunction[2, 3, 4] = 1
 
SOlevel25NFunction[2, 3, 5] = 1
 
SOlevel25NFunction[2, 4, 0] = 0
 
SOlevel25NFunction[2, 4, 1] = 0
 
SOlevel25NFunction[2, 4, 2] = 1
 
SOlevel25NFunction[2, 4, 3] = 1
 
SOlevel25NFunction[2, 4, 4] = 0
 
SOlevel25NFunction[2, 4, 5] = 0
 
SOlevel25NFunction[2, 5, 0] = 0
 
SOlevel25NFunction[2, 5, 1] = 0
 
SOlevel25NFunction[2, 5, 2] = 1
 
SOlevel25NFunction[2, 5, 3] = 1
 
SOlevel25NFunction[2, 5, 4] = 0
 
SOlevel25NFunction[2, 5, 5] = 0
 
SOlevel25NFunction[3, 0, 0] = 0
 
SOlevel25NFunction[3, 0, 1] = 0
 
SOlevel25NFunction[3, 0, 2] = 0
 
SOlevel25NFunction[3, 0, 3] = 1
 
SOlevel25NFunction[3, 0, 4] = 0
 
SOlevel25NFunction[3, 0, 5] = 0
 
SOlevel25NFunction[3, 1, 0] = 0
 
SOlevel25NFunction[3, 1, 1] = 0
 
SOlevel25NFunction[3, 1, 2] = 1
 
SOlevel25NFunction[3, 1, 3] = 0
 
SOlevel25NFunction[3, 1, 4] = 0
 
SOlevel25NFunction[3, 1, 5] = 0
 
SOlevel25NFunction[3, 2, 0] = 0
 
SOlevel25NFunction[3, 2, 1] = 1
 
SOlevel25NFunction[3, 2, 2] = 0
 
SOlevel25NFunction[3, 2, 3] = 0
 
SOlevel25NFunction[3, 2, 4] = 1
 
SOlevel25NFunction[3, 2, 5] = 1
 
SOlevel25NFunction[3, 3, 0] = 1
 
SOlevel25NFunction[3, 3, 1] = 0
 
SOlevel25NFunction[3, 3, 2] = 0
 
SOlevel25NFunction[3, 3, 3] = 0
 
SOlevel25NFunction[3, 3, 4] = 1
 
SOlevel25NFunction[3, 3, 5] = 1
 
SOlevel25NFunction[3, 4, 0] = 0
 
SOlevel25NFunction[3, 4, 1] = 0
 
SOlevel25NFunction[3, 4, 2] = 1
 
SOlevel25NFunction[3, 4, 3] = 1
 
SOlevel25NFunction[3, 4, 4] = 0
 
SOlevel25NFunction[3, 4, 5] = 0
 
SOlevel25NFunction[3, 5, 0] = 0
 
SOlevel25NFunction[3, 5, 1] = 0
 
SOlevel25NFunction[3, 5, 2] = 1
 
SOlevel25NFunction[3, 5, 3] = 1
 
SOlevel25NFunction[3, 5, 4] = 0
 
SOlevel25NFunction[3, 5, 5] = 0
 
SOlevel25NFunction[4, 0, 0] = 0
 
SOlevel25NFunction[4, 0, 1] = 0
 
SOlevel25NFunction[4, 0, 2] = 0
 
SOlevel25NFunction[4, 0, 3] = 0
 
SOlevel25NFunction[4, 0, 4] = 1
 
SOlevel25NFunction[4, 0, 5] = 0
 
SOlevel25NFunction[4, 1, 0] = 0
 
SOlevel25NFunction[4, 1, 1] = 0
 
SOlevel25NFunction[4, 1, 2] = 0
 
SOlevel25NFunction[4, 1, 3] = 0
 
SOlevel25NFunction[4, 1, 4] = 1
 
SOlevel25NFunction[4, 1, 5] = 0
 
SOlevel25NFunction[4, 2, 0] = 0
 
SOlevel25NFunction[4, 2, 1] = 0
 
SOlevel25NFunction[4, 2, 2] = 1
 
SOlevel25NFunction[4, 2, 3] = 1
 
SOlevel25NFunction[4, 2, 4] = 0
 
SOlevel25NFunction[4, 2, 5] = 0
 
SOlevel25NFunction[4, 3, 0] = 0
 
SOlevel25NFunction[4, 3, 1] = 0
 
SOlevel25NFunction[4, 3, 2] = 1
 
SOlevel25NFunction[4, 3, 3] = 1
 
SOlevel25NFunction[4, 3, 4] = 0
 
SOlevel25NFunction[4, 3, 5] = 0
 
SOlevel25NFunction[4, 4, 0] = 1
 
SOlevel25NFunction[4, 4, 1] = 1
 
SOlevel25NFunction[4, 4, 2] = 0
 
SOlevel25NFunction[4, 4, 3] = 0
 
SOlevel25NFunction[4, 4, 4] = 0
 
SOlevel25NFunction[4, 4, 5] = 1
 
SOlevel25NFunction[4, 5, 0] = 0
 
SOlevel25NFunction[4, 5, 1] = 0
 
SOlevel25NFunction[4, 5, 2] = 0
 
SOlevel25NFunction[4, 5, 3] = 0
 
SOlevel25NFunction[4, 5, 4] = 1
 
SOlevel25NFunction[4, 5, 5] = 1
 
SOlevel25NFunction[5, 0, 0] = 0
 
SOlevel25NFunction[5, 0, 1] = 0
 
SOlevel25NFunction[5, 0, 2] = 0
 
SOlevel25NFunction[5, 0, 3] = 0
 
SOlevel25NFunction[5, 0, 4] = 0
 
SOlevel25NFunction[5, 0, 5] = 1
 
SOlevel25NFunction[5, 1, 0] = 0
 
SOlevel25NFunction[5, 1, 1] = 0
 
SOlevel25NFunction[5, 1, 2] = 0
 
SOlevel25NFunction[5, 1, 3] = 0
 
SOlevel25NFunction[5, 1, 4] = 0
 
SOlevel25NFunction[5, 1, 5] = 1
 
SOlevel25NFunction[5, 2, 0] = 0
 
SOlevel25NFunction[5, 2, 1] = 0
 
SOlevel25NFunction[5, 2, 2] = 1
 
SOlevel25NFunction[5, 2, 3] = 1
 
SOlevel25NFunction[5, 2, 4] = 0
 
SOlevel25NFunction[5, 2, 5] = 0
 
SOlevel25NFunction[5, 3, 0] = 0
 
SOlevel25NFunction[5, 3, 1] = 0
 
SOlevel25NFunction[5, 3, 2] = 1
 
SOlevel25NFunction[5, 3, 3] = 1
 
SOlevel25NFunction[5, 3, 4] = 0
 
SOlevel25NFunction[5, 3, 5] = 0
 
SOlevel25NFunction[5, 4, 0] = 0
 
SOlevel25NFunction[5, 4, 1] = 0
 
SOlevel25NFunction[5, 4, 2] = 0
 
SOlevel25NFunction[5, 4, 3] = 0
 
SOlevel25NFunction[5, 4, 4] = 1
 
SOlevel25NFunction[5, 4, 5] = 1
 
SOlevel25NFunction[5, 5, 0] = 1
 
SOlevel25NFunction[5, 5, 1] = 1
 
SOlevel25NFunction[5, 5, 2] = 0
 
SOlevel25NFunction[5, 5, 3] = 0
 
SOlevel25NFunction[5, 5, 4] = 1
 
SOlevel25NFunction[5, 5, 5] = 0
 
SOlevel25NFunction[FusionCategories`Data`SOlevel25`Private`a_, FusionCategories`Data`SOlevel25`Private`b_, FusionCategories`Data`SOlevel25`Private`c_] := 0


 EndPackage[]
