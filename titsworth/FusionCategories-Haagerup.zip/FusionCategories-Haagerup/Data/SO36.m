BeginPackage["FusionCategories`Data`SO36`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[SO36] ^= {SO36Cat1, SO36Cat2}
 
SO36 /: fusionCategory[SO36, 1] = SO36Cat1
 
SO36 /: fusionCategory[SO36, 2] = SO36Cat2
 
nFunction[SO36] ^= SO36NFunction
 
noMultiplicities[SO36] ^= True
 
rank[SO36] ^= 4
 
ring[SO36] ^= SO36
balancedCategories[SO36Cat1] ^= {SO36Cat1Bal1, SO36Cat1Bal2, SO36Cat1Bal3, 
    SO36Cat1Bal4}
 
SO36Cat1 /: balancedCategory[SO36Cat1, 1] = SO36Cat1Bal1
 
SO36Cat1 /: balancedCategory[SO36Cat1, 2] = SO36Cat1Bal2
 
SO36Cat1 /: balancedCategory[SO36Cat1, 3] = SO36Cat1Bal3
 
SO36Cat1 /: balancedCategory[SO36Cat1, 4] = SO36Cat1Bal4
 
braidedCategories[SO36Cat1] ^= {SO36Cat1Brd1, SO36Cat1Brd2, SO36Cat1Brd3, 
    SO36Cat1Brd4}
 
SO36Cat1 /: braidedCategory[SO36Cat1, 1] = SO36Cat1Brd1
 
SO36Cat1 /: braidedCategory[SO36Cat1, 2] = SO36Cat1Brd2
 
SO36Cat1 /: braidedCategory[SO36Cat1, 3] = SO36Cat1Brd3
 
SO36Cat1 /: braidedCategory[SO36Cat1, 4] = SO36Cat1Brd4
 
coeval[SO36Cat1] ^= 1/sixJFunction[SO36Cat1][#1, dual[ring[SO36Cat1]][#1], 
      #1, #1, 0, 0] & 
 
eval[SO36Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[SO36Cat1] ^= SO36Cat1FMatrixFunction
 
fusionCategory[SO36Cat1] ^= SO36Cat1
 
SO36Cat1 /: modularCategory[SO36Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[SO36Cat1] ^= {SO36Cat1Piv1}
 
SO36Cat1 /: pivotalCategory[SO36Cat1, 1] = SO36Cat1Piv1
 
SO36Cat1 /: pivotalCategory[SO36Cat1, {1, 1, 1, 1}] = SO36Cat1Piv1
 
SO36Cat1 /: ribbonCategory[SO36Cat1, 1] = SO36Cat1Bal1
 
SO36Cat1 /: ribbonCategory[SO36Cat1, 2] = SO36Cat1Bal2
 
SO36Cat1 /: ribbonCategory[SO36Cat1, 3] = SO36Cat1Bal3
 
SO36Cat1 /: ribbonCategory[SO36Cat1, 4] = SO36Cat1Bal4
 
ring[SO36Cat1] ^= SO36
 
SO36Cat1 /: sphericalCategory[SO36Cat1, 1] = SO36Cat1Piv1
 
fusionCategoryIndex[SO36][SO36Cat1] ^= 1
balancedCategory[SO36Cat1Bal1] ^= SO36Cat1Bal1
 
braidedCategory[SO36Cat1Bal1] ^= SO36Cat1Brd1
 
fusionCategory[SO36Cat1Bal1] ^= SO36Cat1
 
pivotalCategory[SO36Cat1Bal1] ^= SO36Cat1Piv1
 
ribbonCategory[SO36Cat1Bal1] ^= SO36Cat1Bal1
 
ring[SO36Cat1Bal1] ^= SO36
 
sphericalCategory[SO36Cat1Bal1] ^= SO36Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SO36Cat1Brd1]][
      balancedCategory[#1]] & )[SO36Cat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[SO36Cat1]][balancedCategory[#1]] & )[
    SO36Cat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[SO36Cat1Piv1]][
      balancedCategory[#1]] & )[SO36Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SO36Cat1Brd1]][ribbonCategory[#1]] & )[
    SO36Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SO36Cat1]][ribbonCategory[#1]] & )[
    SO36Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[SO36Cat1Piv1]][ribbonCategory[#1]] & )[
    SO36Cat1Bal1] ^= 1
balancedCategory[SO36Cat1Bal2] ^= SO36Cat1Bal2
 
braidedCategory[SO36Cat1Bal2] ^= SO36Cat1Brd2
 
fusionCategory[SO36Cat1Bal2] ^= SO36Cat1
 
pivotalCategory[SO36Cat1Bal2] ^= SO36Cat1Piv1
 
ribbonCategory[SO36Cat1Bal2] ^= SO36Cat1Bal2
 
ring[SO36Cat1Bal2] ^= SO36
 
sphericalCategory[SO36Cat1Bal2] ^= SO36Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SO36Cat1Brd2]][
      balancedCategory[#1]] & )[SO36Cat1Bal2] ^= 1
 
(balancedCategoryIndex[fusionCategory[SO36Cat1]][balancedCategory[#1]] & )[
    SO36Cat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[SO36Cat1Piv1]][
      balancedCategory[#1]] & )[SO36Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SO36Cat1Brd2]][ribbonCategory[#1]] & )[
    SO36Cat1Bal2] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SO36Cat1]][ribbonCategory[#1]] & )[
    SO36Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[SO36Cat1Piv1]][ribbonCategory[#1]] & )[
    SO36Cat1Bal2] ^= 2
balancedCategory[SO36Cat1Bal3] ^= SO36Cat1Bal3
 
braidedCategory[SO36Cat1Bal3] ^= SO36Cat1Brd3
 
fusionCategory[SO36Cat1Bal3] ^= SO36Cat1
 
pivotalCategory[SO36Cat1Bal3] ^= SO36Cat1Piv1
 
ribbonCategory[SO36Cat1Bal3] ^= SO36Cat1Bal3
 
ring[SO36Cat1Bal3] ^= SO36
 
sphericalCategory[SO36Cat1Bal3] ^= SO36Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SO36Cat1Brd3]][
      balancedCategory[#1]] & )[SO36Cat1Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[SO36Cat1]][balancedCategory[#1]] & )[
    SO36Cat1Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[SO36Cat1Piv1]][
      balancedCategory[#1]] & )[SO36Cat1Bal3] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SO36Cat1Brd3]][ribbonCategory[#1]] & )[
    SO36Cat1Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SO36Cat1]][ribbonCategory[#1]] & )[
    SO36Cat1Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[SO36Cat1Piv1]][ribbonCategory[#1]] & )[
    SO36Cat1Bal3] ^= 3
balancedCategory[SO36Cat1Bal4] ^= SO36Cat1Bal4
 
braidedCategory[SO36Cat1Bal4] ^= SO36Cat1Brd4
 
fusionCategory[SO36Cat1Bal4] ^= SO36Cat1
 
pivotalCategory[SO36Cat1Bal4] ^= SO36Cat1Piv1
 
ribbonCategory[SO36Cat1Bal4] ^= SO36Cat1Bal4
 
ring[SO36Cat1Bal4] ^= SO36
 
sphericalCategory[SO36Cat1Bal4] ^= SO36Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SO36Cat1Brd4]][
      balancedCategory[#1]] & )[SO36Cat1Bal4] ^= 1
 
(balancedCategoryIndex[fusionCategory[SO36Cat1]][balancedCategory[#1]] & )[
    SO36Cat1Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[SO36Cat1Piv1]][
      balancedCategory[#1]] & )[SO36Cat1Bal4] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SO36Cat1Brd4]][ribbonCategory[#1]] & )[
    SO36Cat1Bal4] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SO36Cat1]][ribbonCategory[#1]] & )[
    SO36Cat1Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[SO36Cat1Piv1]][ribbonCategory[#1]] & )[
    SO36Cat1Bal4] ^= 4
balancedCategories[SO36Cat1Brd1] ^= {SO36Cat1Bal1}
 
SO36Cat1Brd1 /: balancedCategory[SO36Cat1Brd1, 1] = SO36Cat1Bal1
 
braidedCategory[SO36Cat1Brd1] ^= SO36Cat1Brd1
 
fusionCategory[SO36Cat1Brd1] ^= SO36Cat1
 
SO36Cat1Brd1 /: modularCategory[SO36Cat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SO36Cat1Brd1 /: ribbonCategory[SO36Cat1Brd1, 1] = SO36Cat1Bal1
 
ring[SO36Cat1Brd1] ^= SO36
 
rMatrixFunction[SO36Cat1Brd1] ^= SO36Cat1Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SO36Cat1]][braidedCategory[#1]] & )[
    SO36Cat1Brd1] ^= 1
braidedCategory[SO36Cat1Brd1RMatrixFunction] ^= SO36Cat1Brd1
 
fusionCategory[SO36Cat1Brd1RMatrixFunction] ^= SO36Cat1
 
rMatrixFunction[SO36Cat1Brd1RMatrixFunction] ^= SO36Cat1Brd1RMatrixFunction
 
SO36Cat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
SO36Cat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
SO36Cat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
SO36Cat1Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
SO36Cat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
SO36Cat1Brd1RMatrixFunction[1, 1, 0] = {{I}}
 
SO36Cat1Brd1RMatrixFunction[1, 1, 1] = {{-(-1)^(1/4)}}
 
SO36Cat1Brd1RMatrixFunction[1, 1, 2] = {{-(-1)^(3/4)}}
 
SO36Cat1Brd1RMatrixFunction[1, 2, 1] = {{(-1)^(3/4)}}
 
SO36Cat1Brd1RMatrixFunction[1, 2, 2] = {{-(-1)^(1/4)}}
 
SO36Cat1Brd1RMatrixFunction[1, 2, 3] = {{I}}
 
SO36Cat1Brd1RMatrixFunction[1, 3, 2] = {{-1}}
 
SO36Cat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
SO36Cat1Brd1RMatrixFunction[2, 1, 1] = {{(-1)^(3/4)}}
 
SO36Cat1Brd1RMatrixFunction[2, 1, 2] = {{-(-1)^(1/4)}}
 
SO36Cat1Brd1RMatrixFunction[2, 1, 3] = {{I}}
 
SO36Cat1Brd1RMatrixFunction[2, 2, 0] = {{-I}}
 
SO36Cat1Brd1RMatrixFunction[2, 2, 1] = {{(-1)^(1/4)}}
 
SO36Cat1Brd1RMatrixFunction[2, 2, 2] = {{(-1)^(3/4)}}
 
SO36Cat1Brd1RMatrixFunction[2, 3, 1] = {{1}}
 
SO36Cat1Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
SO36Cat1Brd1RMatrixFunction[3, 1, 2] = {{-1}}
 
SO36Cat1Brd1RMatrixFunction[3, 2, 1] = {{1}}
 
SO36Cat1Brd1RMatrixFunction[3, 3, 0] = {{-1}}
balancedCategories[SO36Cat1Brd2] ^= {SO36Cat1Bal2}
 
SO36Cat1Brd2 /: balancedCategory[SO36Cat1Brd2, 1] = SO36Cat1Bal2
 
braidedCategory[SO36Cat1Brd2] ^= SO36Cat1Brd2
 
fusionCategory[SO36Cat1Brd2] ^= SO36Cat1
 
SO36Cat1Brd2 /: modularCategory[SO36Cat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SO36Cat1Brd2 /: ribbonCategory[SO36Cat1Brd2, 1] = SO36Cat1Bal2
 
ring[SO36Cat1Brd2] ^= SO36
 
rMatrixFunction[SO36Cat1Brd2] ^= SO36Cat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SO36Cat1]][braidedCategory[#1]] & )[
    SO36Cat1Brd2] ^= 2
braidedCategory[SO36Cat1Brd2RMatrixFunction] ^= SO36Cat1Brd2
 
fusionCategory[SO36Cat1Brd2RMatrixFunction] ^= SO36Cat1
 
rMatrixFunction[SO36Cat1Brd2RMatrixFunction] ^= SO36Cat1Brd2RMatrixFunction
 
SO36Cat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
SO36Cat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
SO36Cat1Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
SO36Cat1Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
SO36Cat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
SO36Cat1Brd2RMatrixFunction[1, 1, 0] = {{-I}}
 
SO36Cat1Brd2RMatrixFunction[1, 1, 1] = {{(-1)^(3/4)}}
 
SO36Cat1Brd2RMatrixFunction[1, 1, 2] = {{(-1)^(1/4)}}
 
SO36Cat1Brd2RMatrixFunction[1, 2, 1] = {{-(-1)^(1/4)}}
 
SO36Cat1Brd2RMatrixFunction[1, 2, 2] = {{(-1)^(3/4)}}
 
SO36Cat1Brd2RMatrixFunction[1, 2, 3] = {{-I}}
 
SO36Cat1Brd2RMatrixFunction[1, 3, 2] = {{-1}}
 
SO36Cat1Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
SO36Cat1Brd2RMatrixFunction[2, 1, 1] = {{-(-1)^(1/4)}}
 
SO36Cat1Brd2RMatrixFunction[2, 1, 2] = {{(-1)^(3/4)}}
 
SO36Cat1Brd2RMatrixFunction[2, 1, 3] = {{-I}}
 
SO36Cat1Brd2RMatrixFunction[2, 2, 0] = {{I}}
 
SO36Cat1Brd2RMatrixFunction[2, 2, 1] = {{-(-1)^(3/4)}}
 
SO36Cat1Brd2RMatrixFunction[2, 2, 2] = {{-(-1)^(1/4)}}
 
SO36Cat1Brd2RMatrixFunction[2, 3, 1] = {{1}}
 
SO36Cat1Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
SO36Cat1Brd2RMatrixFunction[3, 1, 2] = {{-1}}
 
SO36Cat1Brd2RMatrixFunction[3, 2, 1] = {{1}}
 
SO36Cat1Brd2RMatrixFunction[3, 3, 0] = {{-1}}
balancedCategories[SO36Cat1Brd3] ^= {SO36Cat1Bal3}
 
SO36Cat1Brd3 /: balancedCategory[SO36Cat1Brd3, 1] = SO36Cat1Bal3
 
braidedCategory[SO36Cat1Brd3] ^= SO36Cat1Brd3
 
fusionCategory[SO36Cat1Brd3] ^= SO36Cat1
 
SO36Cat1Brd3 /: modularCategory[SO36Cat1Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SO36Cat1Brd3 /: ribbonCategory[SO36Cat1Brd3, 1] = SO36Cat1Bal3
 
ring[SO36Cat1Brd3] ^= SO36
 
rMatrixFunction[SO36Cat1Brd3] ^= SO36Cat1Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SO36Cat1]][braidedCategory[#1]] & )[
    SO36Cat1Brd3] ^= 3
braidedCategory[SO36Cat1Brd3RMatrixFunction] ^= SO36Cat1Brd3
 
fusionCategory[SO36Cat1Brd3RMatrixFunction] ^= SO36Cat1
 
rMatrixFunction[SO36Cat1Brd3RMatrixFunction] ^= SO36Cat1Brd3RMatrixFunction
 
SO36Cat1Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
SO36Cat1Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
SO36Cat1Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
SO36Cat1Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
SO36Cat1Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
SO36Cat1Brd3RMatrixFunction[1, 1, 0] = {{I}}
 
SO36Cat1Brd3RMatrixFunction[1, 1, 1] = {{-(-1)^(1/4)}}
 
SO36Cat1Brd3RMatrixFunction[1, 1, 2] = {{-(-1)^(3/4)}}
 
SO36Cat1Brd3RMatrixFunction[1, 2, 1] = {{(-1)^(3/4)}}
 
SO36Cat1Brd3RMatrixFunction[1, 2, 2] = {{-(-1)^(1/4)}}
 
SO36Cat1Brd3RMatrixFunction[1, 2, 3] = {{I}}
 
SO36Cat1Brd3RMatrixFunction[1, 3, 2] = {{-1}}
 
SO36Cat1Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
SO36Cat1Brd3RMatrixFunction[2, 1, 1] = {{(-1)^(3/4)}}
 
SO36Cat1Brd3RMatrixFunction[2, 1, 2] = {{-(-1)^(1/4)}}
 
SO36Cat1Brd3RMatrixFunction[2, 1, 3] = {{I}}
 
SO36Cat1Brd3RMatrixFunction[2, 2, 0] = {{-I}}
 
SO36Cat1Brd3RMatrixFunction[2, 2, 1] = {{(-1)^(1/4)}}
 
SO36Cat1Brd3RMatrixFunction[2, 2, 2] = {{(-1)^(3/4)}}
 
SO36Cat1Brd3RMatrixFunction[2, 3, 1] = {{1}}
 
SO36Cat1Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
SO36Cat1Brd3RMatrixFunction[3, 1, 2] = {{-1}}
 
SO36Cat1Brd3RMatrixFunction[3, 2, 1] = {{1}}
 
SO36Cat1Brd3RMatrixFunction[3, 3, 0] = {{-1}}
balancedCategories[SO36Cat1Brd4] ^= {SO36Cat1Bal4}
 
SO36Cat1Brd4 /: balancedCategory[SO36Cat1Brd4, 1] = SO36Cat1Bal4
 
braidedCategory[SO36Cat1Brd4] ^= SO36Cat1Brd4
 
fusionCategory[SO36Cat1Brd4] ^= SO36Cat1
 
SO36Cat1Brd4 /: modularCategory[SO36Cat1Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SO36Cat1Brd4 /: ribbonCategory[SO36Cat1Brd4, 1] = SO36Cat1Bal4
 
ring[SO36Cat1Brd4] ^= SO36
 
rMatrixFunction[SO36Cat1Brd4] ^= SO36Cat1Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SO36Cat1]][braidedCategory[#1]] & )[
    SO36Cat1Brd4] ^= 4
braidedCategory[SO36Cat1Brd4RMatrixFunction] ^= SO36Cat1Brd4
 
fusionCategory[SO36Cat1Brd4RMatrixFunction] ^= SO36Cat1
 
rMatrixFunction[SO36Cat1Brd4RMatrixFunction] ^= SO36Cat1Brd4RMatrixFunction
 
SO36Cat1Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
SO36Cat1Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
SO36Cat1Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
SO36Cat1Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
SO36Cat1Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
SO36Cat1Brd4RMatrixFunction[1, 1, 0] = {{-I}}
 
SO36Cat1Brd4RMatrixFunction[1, 1, 1] = {{(-1)^(3/4)}}
 
SO36Cat1Brd4RMatrixFunction[1, 1, 2] = {{(-1)^(1/4)}}
 
SO36Cat1Brd4RMatrixFunction[1, 2, 1] = {{-(-1)^(1/4)}}
 
SO36Cat1Brd4RMatrixFunction[1, 2, 2] = {{(-1)^(3/4)}}
 
SO36Cat1Brd4RMatrixFunction[1, 2, 3] = {{-I}}
 
SO36Cat1Brd4RMatrixFunction[1, 3, 2] = {{-1}}
 
SO36Cat1Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
SO36Cat1Brd4RMatrixFunction[2, 1, 1] = {{-(-1)^(1/4)}}
 
SO36Cat1Brd4RMatrixFunction[2, 1, 2] = {{(-1)^(3/4)}}
 
SO36Cat1Brd4RMatrixFunction[2, 1, 3] = {{-I}}
 
SO36Cat1Brd4RMatrixFunction[2, 2, 0] = {{I}}
 
SO36Cat1Brd4RMatrixFunction[2, 2, 1] = {{-(-1)^(3/4)}}
 
SO36Cat1Brd4RMatrixFunction[2, 2, 2] = {{-(-1)^(1/4)}}
 
SO36Cat1Brd4RMatrixFunction[2, 3, 1] = {{1}}
 
SO36Cat1Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
SO36Cat1Brd4RMatrixFunction[3, 1, 2] = {{-1}}
 
SO36Cat1Brd4RMatrixFunction[3, 2, 1] = {{1}}
 
SO36Cat1Brd4RMatrixFunction[3, 3, 0] = {{-1}}
fMatrixFunction[SO36Cat1FMatrixFunction] ^= SO36Cat1FMatrixFunction
 
fusionCategory[SO36Cat1FMatrixFunction] ^= SO36Cat1
 
ring[SO36Cat1FMatrixFunction] ^= SO36
 
SO36Cat1FMatrixFunction[1, 1, 1, 1] = {{-1 + Sqrt[2], 1/Sqrt[2], 1}, 
    {2 - Sqrt[2], 1 - 1/Sqrt[2], -1}, {-1 + Sqrt[2], -1/2, 1 - 1/Sqrt[2]}}
 
SO36Cat1FMatrixFunction[1, 1, 1, 2] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
SO36Cat1FMatrixFunction[1, 1, 1, 3] = {{-1}}
 
SO36Cat1FMatrixFunction[1, 1, 2, 1] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
SO36Cat1FMatrixFunction[1, 1, 2, 2] = {{-1 + Sqrt[2], -1/2, 1 - 1/Sqrt[2]}, 
    {2 - Sqrt[2], 1 - 1/Sqrt[2], -1}, {-1 + Sqrt[2], 1/Sqrt[2], 1}}
 
SO36Cat1FMatrixFunction[1, 2, 1, 1] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
SO36Cat1FMatrixFunction[1, 2, 1, 2] = {{1 - 1/Sqrt[2], 1/2, -1 + Sqrt[2]}, 
    {1, 1 - 1/Sqrt[2], -2 + Sqrt[2]}, {-1, 1/Sqrt[2], 1 - Sqrt[2]}}
 
SO36Cat1FMatrixFunction[1, 2, 2, 1] = {{1, 1/Sqrt[2], -1 + Sqrt[2]}, 
    {-1, 1 - 1/Sqrt[2], 2 - Sqrt[2]}, {1 - 1/Sqrt[2], -1/2, -1 + Sqrt[2]}}
 
SO36Cat1FMatrixFunction[1, 2, 2, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
SO36Cat1FMatrixFunction[1, 3, 1, 2] = {{-1}}
 
SO36Cat1FMatrixFunction[1, 3, 1, 3] = {{-1}}
 
SO36Cat1FMatrixFunction[2, 1, 1, 1] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
SO36Cat1FMatrixFunction[2, 1, 1, 2] = {{1, 1/Sqrt[2], 1 - Sqrt[2]}, 
    {-1, 1 - 1/Sqrt[2], -2 + Sqrt[2]}, {1 - 1/Sqrt[2], -1/2, 1 - Sqrt[2]}}
 
SO36Cat1FMatrixFunction[2, 1, 2, 1] = {{1 - 1/Sqrt[2], 1/2, 1 - Sqrt[2]}, 
    {1, 1 - 1/Sqrt[2], 2 - Sqrt[2]}, {1, -(1/Sqrt[2]), 1 - Sqrt[2]}}
 
SO36Cat1FMatrixFunction[2, 1, 2, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
SO36Cat1FMatrixFunction[2, 1, 2, 3] = {{-1}}
 
SO36Cat1FMatrixFunction[2, 1, 3, 0] = {{-1}}
 
SO36Cat1FMatrixFunction[2, 1, 3, 1] = {{-1}}
 
SO36Cat1FMatrixFunction[2, 2, 1, 1] = {{-1 + Sqrt[2], -1/2, 1 - 1/Sqrt[2]}, 
    {2 - Sqrt[2], 1 - 1/Sqrt[2], -1}, {1 - Sqrt[2], -(1/Sqrt[2]), -1}}
 
SO36Cat1FMatrixFunction[2, 2, 1, 2] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
SO36Cat1FMatrixFunction[2, 2, 2, 1] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
SO36Cat1FMatrixFunction[2, 2, 2, 2] = {{-1 + Sqrt[2], 1/Sqrt[2], 1}, 
    {2 - Sqrt[2], 1 - 1/Sqrt[2], -1}, {-1 + Sqrt[2], -1/2, 1 - 1/Sqrt[2]}}
 
SO36Cat1FMatrixFunction[2, 2, 3, 2] = {{-1}}
 
SO36Cat1FMatrixFunction[2, 2, 3, 3] = {{-1}}
 
SO36Cat1FMatrixFunction[2, 3, 2, 2] = {{-1}}
 
SO36Cat1FMatrixFunction[2, 3, 2, 3] = {{-1}}
 
SO36Cat1FMatrixFunction[3, 1, 1, 3] = {{-1}}
 
SO36Cat1FMatrixFunction[3, 1, 2, 1] = {{-1}}
 
SO36Cat1FMatrixFunction[3, 2, 1, 0] = {{-1}}
 
SO36Cat1FMatrixFunction[3, 2, 2, 2] = {{-1}}
 
SO36Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SO36Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
SO36Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SO36Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[SO36Cat1Piv1] ^= {SO36Cat1Bal1, SO36Cat1Bal2, 
    SO36Cat1Bal3, SO36Cat1Bal4}
 
SO36Cat1Piv1 /: balancedCategory[SO36Cat1Piv1, 1] = SO36Cat1Bal1
 
SO36Cat1Piv1 /: balancedCategory[SO36Cat1Piv1, 2] = SO36Cat1Bal2
 
SO36Cat1Piv1 /: balancedCategory[SO36Cat1Piv1, 3] = SO36Cat1Bal3
 
SO36Cat1Piv1 /: balancedCategory[SO36Cat1Piv1, 4] = SO36Cat1Bal4
 
fusionCategory[SO36Cat1Piv1] ^= SO36Cat1
 
SO36Cat1Piv1 /: modularCategory[SO36Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SO36Cat1Piv1] ^= SO36Cat1Piv1
 
pivotalIsomorphism[SO36Cat1Piv1] ^= SO36Cat1Piv1PivotalIsomorphism
 
SO36Cat1Piv1 /: ribbonCategory[SO36Cat1Piv1, 1] = SO36Cat1Bal1
 
SO36Cat1Piv1 /: ribbonCategory[SO36Cat1Piv1, 2] = SO36Cat1Bal2
 
SO36Cat1Piv1 /: ribbonCategory[SO36Cat1Piv1, 3] = SO36Cat1Bal3
 
SO36Cat1Piv1 /: ribbonCategory[SO36Cat1Piv1, 4] = SO36Cat1Bal4
 
ring[SO36Cat1Piv1] ^= SO36
 
sphericalCategory[SO36Cat1Piv1] ^= SO36Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[SO36Cat1]][pivotalCategory[#1]] & )[
    SO36Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[SO36Cat1]][sphericalCategory[#1]] & )[
    SO36Cat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[SO36Cat1Piv1PivotalIsomorphism] ^= SO36Cat1
 
pivotalCategory[SO36Cat1Piv1PivotalIsomorphism] ^= SO36Cat1Piv1
 
pivotalIsomorphism[SO36Cat1Piv1PivotalIsomorphism] ^= 
   SO36Cat1Piv1PivotalIsomorphism
 
SO36Cat1Piv1PivotalIsomorphism[0] = 1
 
SO36Cat1Piv1PivotalIsomorphism[1] = 1
 
SO36Cat1Piv1PivotalIsomorphism[2] = 1
 
SO36Cat1Piv1PivotalIsomorphism[3] = 1
balancedCategories[SO36Cat2] ^= {}
 
braidedCategories[SO36Cat2] ^= {}
 
coeval[SO36Cat2] ^= 1/sixJFunction[SO36Cat2][#1, dual[ring[SO36Cat2]][#1], 
      #1, #1, 0, 0] & 
 
eval[SO36Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[SO36Cat2] ^= SO36Cat2FMatrixFunction
 
fusionCategory[SO36Cat2] ^= SO36Cat2
 
SO36Cat2 /: modularCategory[SO36Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[SO36Cat2] ^= {SO36Cat2Piv1}
 
SO36Cat2 /: pivotalCategory[SO36Cat2, 1] = SO36Cat2Piv1
 
SO36Cat2 /: pivotalCategory[SO36Cat2, {1, 1, 1, 1}] = SO36Cat2Piv1
 
ring[SO36Cat2] ^= SO36
 
SO36Cat2 /: sphericalCategory[SO36Cat2, 1] = SO36Cat2Piv1
 
fusionCategoryIndex[SO36][SO36Cat2] ^= 2
fMatrixFunction[SO36Cat2FMatrixFunction] ^= SO36Cat2FMatrixFunction
 
fusionCategory[SO36Cat2FMatrixFunction] ^= SO36Cat2
 
ring[SO36Cat2FMatrixFunction] ^= SO36
 
SO36Cat2FMatrixFunction[1, 1, 1, 1] = {{-1 - Sqrt[2], -(1/Sqrt[2]), 1}, 
    {2 + Sqrt[2], 1 + 1/Sqrt[2], -1}, {-1 - Sqrt[2], -1/2, 1 + 1/Sqrt[2]}}
 
SO36Cat2FMatrixFunction[1, 1, 1, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
SO36Cat2FMatrixFunction[1, 1, 1, 3] = {{-1}}
 
SO36Cat2FMatrixFunction[1, 1, 2, 1] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
SO36Cat2FMatrixFunction[1, 1, 2, 2] = {{-1 - Sqrt[2], -1/2, 1 + 1/Sqrt[2]}, 
    {2 + Sqrt[2], 1 + 1/Sqrt[2], -1}, {-1 - Sqrt[2], -(1/Sqrt[2]), 1}}
 
SO36Cat2FMatrixFunction[1, 2, 1, 1] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
SO36Cat2FMatrixFunction[1, 2, 1, 2] = {{1 + 1/Sqrt[2], 1/2, -1 - Sqrt[2]}, 
    {1, 1 + 1/Sqrt[2], -2 - Sqrt[2]}, {-1, -(1/Sqrt[2]), 1 + Sqrt[2]}}
 
SO36Cat2FMatrixFunction[1, 2, 2, 1] = {{1, -(1/Sqrt[2]), -1 - Sqrt[2]}, 
    {-1, 1 + 1/Sqrt[2], 2 + Sqrt[2]}, {1 + 1/Sqrt[2], -1/2, -1 - Sqrt[2]}}
 
SO36Cat2FMatrixFunction[1, 2, 2, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
SO36Cat2FMatrixFunction[1, 3, 1, 2] = {{-1}}
 
SO36Cat2FMatrixFunction[1, 3, 1, 3] = {{-1}}
 
SO36Cat2FMatrixFunction[2, 1, 1, 1] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
SO36Cat2FMatrixFunction[2, 1, 1, 2] = {{1, -(1/Sqrt[2]), 1 + Sqrt[2]}, 
    {-1, 1 + 1/Sqrt[2], -2 - Sqrt[2]}, {1 + 1/Sqrt[2], -1/2, 1 + Sqrt[2]}}
 
SO36Cat2FMatrixFunction[2, 1, 2, 1] = {{1 + 1/Sqrt[2], 1/2, 1 + Sqrt[2]}, 
    {1, 1 + 1/Sqrt[2], 2 + Sqrt[2]}, {1, 1/Sqrt[2], 1 + Sqrt[2]}}
 
SO36Cat2FMatrixFunction[2, 1, 2, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
SO36Cat2FMatrixFunction[2, 1, 2, 3] = {{-1}}
 
SO36Cat2FMatrixFunction[2, 1, 3, 0] = {{-1}}
 
SO36Cat2FMatrixFunction[2, 1, 3, 1] = {{-1}}
 
SO36Cat2FMatrixFunction[2, 2, 1, 1] = {{-1 - Sqrt[2], -1/2, 1 + 1/Sqrt[2]}, 
    {2 + Sqrt[2], 1 + 1/Sqrt[2], -1}, {1 + Sqrt[2], 1/Sqrt[2], -1}}
 
SO36Cat2FMatrixFunction[2, 2, 1, 2] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
SO36Cat2FMatrixFunction[2, 2, 2, 1] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
SO36Cat2FMatrixFunction[2, 2, 2, 2] = {{-1 - Sqrt[2], -(1/Sqrt[2]), 1}, 
    {2 + Sqrt[2], 1 + 1/Sqrt[2], -1}, {-1 - Sqrt[2], -1/2, 1 + 1/Sqrt[2]}}
 
SO36Cat2FMatrixFunction[2, 2, 3, 2] = {{-1}}
 
SO36Cat2FMatrixFunction[2, 2, 3, 3] = {{-1}}
 
SO36Cat2FMatrixFunction[2, 3, 2, 2] = {{-1}}
 
SO36Cat2FMatrixFunction[2, 3, 2, 3] = {{-1}}
 
SO36Cat2FMatrixFunction[3, 1, 1, 3] = {{-1}}
 
SO36Cat2FMatrixFunction[3, 1, 2, 1] = {{-1}}
 
SO36Cat2FMatrixFunction[3, 2, 1, 0] = {{-1}}
 
SO36Cat2FMatrixFunction[3, 2, 2, 2] = {{-1}}
 
SO36Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SO36Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
SO36Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SO36Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[SO36Cat2Piv1] ^= {}
 
fusionCategory[SO36Cat2Piv1] ^= SO36Cat2
 
SO36Cat2Piv1 /: modularCategory[SO36Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SO36Cat2Piv1] ^= SO36Cat2Piv1
 
pivotalIsomorphism[SO36Cat2Piv1] ^= SO36Cat2Piv1PivotalIsomorphism
 
ring[SO36Cat2Piv1] ^= SO36
 
sphericalCategory[SO36Cat2Piv1] ^= SO36Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[SO36Cat2]][pivotalCategory[#1]] & )[
    SO36Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[SO36Cat2]][sphericalCategory[#1]] & )[
    SO36Cat2Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[SO36Cat2Piv1PivotalIsomorphism] ^= SO36Cat2
 
pivotalCategory[SO36Cat2Piv1PivotalIsomorphism] ^= SO36Cat2Piv1
 
pivotalIsomorphism[SO36Cat2Piv1PivotalIsomorphism] ^= 
   SO36Cat2Piv1PivotalIsomorphism
 
SO36Cat2Piv1PivotalIsomorphism[0] = 1
 
SO36Cat2Piv1PivotalIsomorphism[1] = 1
 
SO36Cat2Piv1PivotalIsomorphism[2] = 1
 
SO36Cat2Piv1PivotalIsomorphism[3] = 1
ring[SO36NFunction] ^= SO36
 
SO36NFunction[0, 0, 0] = 1
 
SO36NFunction[0, 0, 1] = 0
 
SO36NFunction[0, 0, 2] = 0
 
SO36NFunction[0, 0, 3] = 0
 
SO36NFunction[0, 1, 0] = 0
 
SO36NFunction[0, 1, 1] = 1
 
SO36NFunction[0, 1, 2] = 0
 
SO36NFunction[0, 1, 3] = 0
 
SO36NFunction[0, 2, 0] = 0
 
SO36NFunction[0, 2, 1] = 0
 
SO36NFunction[0, 2, 2] = 1
 
SO36NFunction[0, 2, 3] = 0
 
SO36NFunction[0, 3, 0] = 0
 
SO36NFunction[0, 3, 1] = 0
 
SO36NFunction[0, 3, 2] = 0
 
SO36NFunction[0, 3, 3] = 1
 
SO36NFunction[1, 0, 0] = 0
 
SO36NFunction[1, 0, 1] = 1
 
SO36NFunction[1, 0, 2] = 0
 
SO36NFunction[1, 0, 3] = 0
 
SO36NFunction[1, 1, 0] = 1
 
SO36NFunction[1, 1, 1] = 1
 
SO36NFunction[1, 1, 2] = 1
 
SO36NFunction[1, 1, 3] = 0
 
SO36NFunction[1, 2, 0] = 0
 
SO36NFunction[1, 2, 1] = 1
 
SO36NFunction[1, 2, 2] = 1
 
SO36NFunction[1, 2, 3] = 1
 
SO36NFunction[1, 3, 0] = 0
 
SO36NFunction[1, 3, 1] = 0
 
SO36NFunction[1, 3, 2] = 1
 
SO36NFunction[1, 3, 3] = 0
 
SO36NFunction[2, 0, 0] = 0
 
SO36NFunction[2, 0, 1] = 0
 
SO36NFunction[2, 0, 2] = 1
 
SO36NFunction[2, 0, 3] = 0
 
SO36NFunction[2, 1, 0] = 0
 
SO36NFunction[2, 1, 1] = 1
 
SO36NFunction[2, 1, 2] = 1
 
SO36NFunction[2, 1, 3] = 1
 
SO36NFunction[2, 2, 0] = 1
 
SO36NFunction[2, 2, 1] = 1
 
SO36NFunction[2, 2, 2] = 1
 
SO36NFunction[2, 2, 3] = 0
 
SO36NFunction[2, 3, 0] = 0
 
SO36NFunction[2, 3, 1] = 1
 
SO36NFunction[2, 3, 2] = 0
 
SO36NFunction[2, 3, 3] = 0
 
SO36NFunction[3, 0, 0] = 0
 
SO36NFunction[3, 0, 1] = 0
 
SO36NFunction[3, 0, 2] = 0
 
SO36NFunction[3, 0, 3] = 1
 
SO36NFunction[3, 1, 0] = 0
 
SO36NFunction[3, 1, 1] = 0
 
SO36NFunction[3, 1, 2] = 1
 
SO36NFunction[3, 1, 3] = 0
 
SO36NFunction[3, 2, 0] = 0
 
SO36NFunction[3, 2, 1] = 1
 
SO36NFunction[3, 2, 2] = 0
 
SO36NFunction[3, 2, 3] = 0
 
SO36NFunction[3, 3, 0] = 1
 
SO36NFunction[3, 3, 1] = 0
 
SO36NFunction[3, 3, 2] = 0
 
SO36NFunction[3, 3, 3] = 0
 
SO36NFunction[FusionCategories`Data`SO36`Private`a_, FusionCategories`Data`SO36`Private`b_, FusionCategories`Data`SO36`Private`c_] := 0


 EndPackage[]
