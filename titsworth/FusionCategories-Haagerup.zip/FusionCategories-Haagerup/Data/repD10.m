BeginPackage["FusionCategories`Data`repD10`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[repD10] ^= {repD10Cat1, repD10Cat2, repD10Cat3, repD10Cat4, 
    repD10Cat5, repD10Cat6}
 
repD10 /: fusionCategory[repD10, 1] = repD10Cat1
 
repD10 /: fusionCategory[repD10, 2] = repD10Cat2
 
repD10 /: fusionCategory[repD10, 3] = repD10Cat3
 
repD10 /: fusionCategory[repD10, 4] = repD10Cat4
 
repD10 /: fusionCategory[repD10, 5] = repD10Cat5
 
repD10 /: fusionCategory[repD10, 6] = repD10Cat6
 
nFunction[repD10] ^= repD10NFunction
 
noMultiplicities[repD10] ^= True
 
rank[repD10] ^= 8
 
ring[repD10] ^= repD10
balancedCategories[repD10Cat1] ^= {repD10Cat1Bal1, repD10Cat1Bal2, 
    repD10Cat1Bal3, repD10Cat1Bal4, repD10Cat1Bal5, repD10Cat1Bal6, 
    repD10Cat1Bal7, repD10Cat1Bal8, repD10Cat1Bal9, repD10Cat1Bal10, 
    repD10Cat1Bal11, repD10Cat1Bal12, repD10Cat1Bal13, repD10Cat1Bal14, 
    repD10Cat1Bal15, repD10Cat1Bal16, repD10Cat1Bal17, repD10Cat1Bal18, 
    repD10Cat1Bal19, repD10Cat1Bal20}
 
repD10Cat1 /: balancedCategory[repD10Cat1, 1] = repD10Cat1Bal1
 
repD10Cat1 /: balancedCategory[repD10Cat1, 2] = repD10Cat1Bal2
 
repD10Cat1 /: balancedCategory[repD10Cat1, 3] = repD10Cat1Bal3
 
repD10Cat1 /: balancedCategory[repD10Cat1, 4] = repD10Cat1Bal4
 
repD10Cat1 /: balancedCategory[repD10Cat1, 5] = repD10Cat1Bal5
 
repD10Cat1 /: balancedCategory[repD10Cat1, 6] = repD10Cat1Bal6
 
repD10Cat1 /: balancedCategory[repD10Cat1, 7] = repD10Cat1Bal7
 
repD10Cat1 /: balancedCategory[repD10Cat1, 8] = repD10Cat1Bal8
 
repD10Cat1 /: balancedCategory[repD10Cat1, 9] = repD10Cat1Bal9
 
repD10Cat1 /: balancedCategory[repD10Cat1, 10] = repD10Cat1Bal10
 
repD10Cat1 /: balancedCategory[repD10Cat1, 11] = repD10Cat1Bal11
 
repD10Cat1 /: balancedCategory[repD10Cat1, 12] = repD10Cat1Bal12
 
repD10Cat1 /: balancedCategory[repD10Cat1, 13] = repD10Cat1Bal13
 
repD10Cat1 /: balancedCategory[repD10Cat1, 14] = repD10Cat1Bal14
 
repD10Cat1 /: balancedCategory[repD10Cat1, 15] = repD10Cat1Bal15
 
repD10Cat1 /: balancedCategory[repD10Cat1, 16] = repD10Cat1Bal16
 
repD10Cat1 /: balancedCategory[repD10Cat1, 17] = repD10Cat1Bal17
 
repD10Cat1 /: balancedCategory[repD10Cat1, 18] = repD10Cat1Bal18
 
repD10Cat1 /: balancedCategory[repD10Cat1, 19] = repD10Cat1Bal19
 
repD10Cat1 /: balancedCategory[repD10Cat1, 20] = repD10Cat1Bal20
 
braidedCategories[repD10Cat1] ^= {repD10Cat1Brd1, repD10Cat1Brd2, 
    repD10Cat1Brd3, repD10Cat1Brd4, repD10Cat1Brd5, repD10Cat1Brd6, 
    repD10Cat1Brd7, repD10Cat1Brd8, repD10Cat1Brd9, repD10Cat1Brd10}
 
repD10Cat1 /: braidedCategory[repD10Cat1, 1] = repD10Cat1Brd1
 
repD10Cat1 /: braidedCategory[repD10Cat1, 2] = repD10Cat1Brd2
 
repD10Cat1 /: braidedCategory[repD10Cat1, 3] = repD10Cat1Brd3
 
repD10Cat1 /: braidedCategory[repD10Cat1, 4] = repD10Cat1Brd4
 
repD10Cat1 /: braidedCategory[repD10Cat1, 5] = repD10Cat1Brd5
 
repD10Cat1 /: braidedCategory[repD10Cat1, 6] = repD10Cat1Brd6
 
repD10Cat1 /: braidedCategory[repD10Cat1, 7] = repD10Cat1Brd7
 
repD10Cat1 /: braidedCategory[repD10Cat1, 8] = repD10Cat1Brd8
 
repD10Cat1 /: braidedCategory[repD10Cat1, 9] = repD10Cat1Brd9
 
repD10Cat1 /: braidedCategory[repD10Cat1, 10] = repD10Cat1Brd10
 
coeval[repD10Cat1] ^= 1/sixJFunction[repD10Cat1][#1, 
      dual[ring[repD10Cat1]][#1], #1, #1, 0, 0] & 
 
eval[repD10Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[repD10Cat1] ^= repD10Cat1FMatrixFunction
 
fusionCategory[repD10Cat1] ^= repD10Cat1
 
repD10Cat1 /: modularCategory[repD10Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[repD10Cat1] ^= {repD10Cat1Piv1, repD10Cat1Piv2}
 
repD10Cat1 /: pivotalCategory[repD10Cat1, 1] = repD10Cat1Piv1
 
repD10Cat1 /: pivotalCategory[repD10Cat1, 2] = repD10Cat1Piv2
 
repD10Cat1 /: pivotalCategory[repD10Cat1, {1, -1, 1, -1, 1, 1, 1, 1}] = 
    repD10Cat1Piv2
 
repD10Cat1 /: pivotalCategory[repD10Cat1, {1, 1, 1, 1, 1, -1, 1, -1}] = 
    repD10Cat1Piv1
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 1] = repD10Cat1Bal1
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 2] = repD10Cat1Bal2
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 3] = repD10Cat1Bal3
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 4] = repD10Cat1Bal4
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 5] = repD10Cat1Bal5
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 6] = repD10Cat1Bal6
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 7] = repD10Cat1Bal7
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 8] = repD10Cat1Bal8
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 9] = repD10Cat1Bal9
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 10] = repD10Cat1Bal10
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 11] = repD10Cat1Bal11
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 12] = repD10Cat1Bal12
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 13] = repD10Cat1Bal13
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 14] = repD10Cat1Bal14
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 15] = repD10Cat1Bal15
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 16] = repD10Cat1Bal16
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 17] = repD10Cat1Bal17
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 18] = repD10Cat1Bal18
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 19] = repD10Cat1Bal19
 
repD10Cat1 /: ribbonCategory[repD10Cat1, 20] = repD10Cat1Bal20
 
ring[repD10Cat1] ^= repD10
 
repD10Cat1 /: sphericalCategory[repD10Cat1, 1] = repD10Cat1Piv1
 
repD10Cat1 /: sphericalCategory[repD10Cat1, 2] = repD10Cat1Piv2
 
repD10Cat1 /: symmetricCategory[repD10Cat1, 1] = repD10Cat1Brd1
 
repD10Cat1 /: symmetricCategory[repD10Cat1, 2] = repD10Cat1Brd6
 
fusionCategoryIndex[repD10][repD10Cat1] ^= 1
balancedCategory[repD10Cat1Bal1] ^= repD10Cat1Bal1
 
braidedCategory[repD10Cat1Bal1] ^= repD10Cat1Brd1
 
fusionCategory[repD10Cat1Bal1] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal1] ^= repD10Cat1Piv1
 
ribbonCategory[repD10Cat1Bal1] ^= repD10Cat1Bal1
 
ring[repD10Cat1Bal1] ^= repD10
 
sphericalCategory[repD10Cat1Bal1] ^= repD10Cat1Piv1
 
symmetricCategory[repD10Cat1Bal1] ^= repD10Cat1Brd1
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd1]][
      balancedCategory[#1]] & )[repD10Cat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv1]][
      balancedCategory[#1]] & )[repD10Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv1]][
      ribbonCategory[#1]] & )[repD10Cat1Bal1] ^= 1
balancedCategory[repD10Cat1Bal10] ^= repD10Cat1Bal10
 
braidedCategory[repD10Cat1Bal10] ^= repD10Cat1Brd5
 
fusionCategory[repD10Cat1Bal10] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal10] ^= repD10Cat1Piv2
 
ribbonCategory[repD10Cat1Bal10] ^= repD10Cat1Bal10
 
ring[repD10Cat1Bal10] ^= repD10
 
sphericalCategory[repD10Cat1Bal10] ^= repD10Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd5]][
      balancedCategory[#1]] & )[repD10Cat1Bal10] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal10] ^= 10
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv2]][
      balancedCategory[#1]] & )[repD10Cat1Bal10] ^= 5
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd5]][ribbonCategory[#1]] & )[
    repD10Cat1Bal10] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal10] ^= 10
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv2]][
      ribbonCategory[#1]] & )[repD10Cat1Bal10] ^= 5
balancedCategory[repD10Cat1Bal11] ^= repD10Cat1Bal11
 
braidedCategory[repD10Cat1Bal11] ^= repD10Cat1Brd6
 
fusionCategory[repD10Cat1Bal11] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal11] ^= repD10Cat1Piv1
 
ribbonCategory[repD10Cat1Bal11] ^= repD10Cat1Bal11
 
ring[repD10Cat1Bal11] ^= repD10
 
sphericalCategory[repD10Cat1Bal11] ^= repD10Cat1Piv1
 
symmetricCategory[repD10Cat1Bal11] ^= repD10Cat1Brd6
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd6]][
      balancedCategory[#1]] & )[repD10Cat1Bal11] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal11] ^= 11
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv1]][
      balancedCategory[#1]] & )[repD10Cat1Bal11] ^= 6
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd6]][ribbonCategory[#1]] & )[
    repD10Cat1Bal11] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal11] ^= 11
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv1]][
      ribbonCategory[#1]] & )[repD10Cat1Bal11] ^= 6
balancedCategory[repD10Cat1Bal12] ^= repD10Cat1Bal12
 
braidedCategory[repD10Cat1Bal12] ^= repD10Cat1Brd6
 
fusionCategory[repD10Cat1Bal12] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal12] ^= repD10Cat1Piv2
 
ribbonCategory[repD10Cat1Bal12] ^= repD10Cat1Bal12
 
ring[repD10Cat1Bal12] ^= repD10
 
sphericalCategory[repD10Cat1Bal12] ^= repD10Cat1Piv2
 
symmetricCategory[repD10Cat1Bal12] ^= repD10Cat1Brd6
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd6]][
      balancedCategory[#1]] & )[repD10Cat1Bal12] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal12] ^= 12
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv2]][
      balancedCategory[#1]] & )[repD10Cat1Bal12] ^= 6
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd6]][ribbonCategory[#1]] & )[
    repD10Cat1Bal12] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal12] ^= 12
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv2]][
      ribbonCategory[#1]] & )[repD10Cat1Bal12] ^= 6
balancedCategory[repD10Cat1Bal13] ^= repD10Cat1Bal13
 
braidedCategory[repD10Cat1Bal13] ^= repD10Cat1Brd7
 
fusionCategory[repD10Cat1Bal13] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal13] ^= repD10Cat1Piv1
 
ribbonCategory[repD10Cat1Bal13] ^= repD10Cat1Bal13
 
ring[repD10Cat1Bal13] ^= repD10
 
sphericalCategory[repD10Cat1Bal13] ^= repD10Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd7]][
      balancedCategory[#1]] & )[repD10Cat1Bal13] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal13] ^= 13
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv1]][
      balancedCategory[#1]] & )[repD10Cat1Bal13] ^= 7
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd7]][ribbonCategory[#1]] & )[
    repD10Cat1Bal13] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal13] ^= 13
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv1]][
      ribbonCategory[#1]] & )[repD10Cat1Bal13] ^= 7
balancedCategory[repD10Cat1Bal14] ^= repD10Cat1Bal14
 
braidedCategory[repD10Cat1Bal14] ^= repD10Cat1Brd7
 
fusionCategory[repD10Cat1Bal14] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal14] ^= repD10Cat1Piv2
 
ribbonCategory[repD10Cat1Bal14] ^= repD10Cat1Bal14
 
ring[repD10Cat1Bal14] ^= repD10
 
sphericalCategory[repD10Cat1Bal14] ^= repD10Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd7]][
      balancedCategory[#1]] & )[repD10Cat1Bal14] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal14] ^= 14
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv2]][
      balancedCategory[#1]] & )[repD10Cat1Bal14] ^= 7
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd7]][ribbonCategory[#1]] & )[
    repD10Cat1Bal14] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal14] ^= 14
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv2]][
      ribbonCategory[#1]] & )[repD10Cat1Bal14] ^= 7
balancedCategory[repD10Cat1Bal15] ^= repD10Cat1Bal15
 
braidedCategory[repD10Cat1Bal15] ^= repD10Cat1Brd8
 
fusionCategory[repD10Cat1Bal15] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal15] ^= repD10Cat1Piv1
 
ribbonCategory[repD10Cat1Bal15] ^= repD10Cat1Bal15
 
ring[repD10Cat1Bal15] ^= repD10
 
sphericalCategory[repD10Cat1Bal15] ^= repD10Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd8]][
      balancedCategory[#1]] & )[repD10Cat1Bal15] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal15] ^= 15
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv1]][
      balancedCategory[#1]] & )[repD10Cat1Bal15] ^= 8
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd8]][ribbonCategory[#1]] & )[
    repD10Cat1Bal15] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal15] ^= 15
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv1]][
      ribbonCategory[#1]] & )[repD10Cat1Bal15] ^= 8
balancedCategory[repD10Cat1Bal16] ^= repD10Cat1Bal16
 
braidedCategory[repD10Cat1Bal16] ^= repD10Cat1Brd8
 
fusionCategory[repD10Cat1Bal16] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal16] ^= repD10Cat1Piv2
 
ribbonCategory[repD10Cat1Bal16] ^= repD10Cat1Bal16
 
ring[repD10Cat1Bal16] ^= repD10
 
sphericalCategory[repD10Cat1Bal16] ^= repD10Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd8]][
      balancedCategory[#1]] & )[repD10Cat1Bal16] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal16] ^= 16
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv2]][
      balancedCategory[#1]] & )[repD10Cat1Bal16] ^= 8
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd8]][ribbonCategory[#1]] & )[
    repD10Cat1Bal16] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal16] ^= 16
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv2]][
      ribbonCategory[#1]] & )[repD10Cat1Bal16] ^= 8
balancedCategory[repD10Cat1Bal17] ^= repD10Cat1Bal17
 
braidedCategory[repD10Cat1Bal17] ^= repD10Cat1Brd9
 
fusionCategory[repD10Cat1Bal17] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal17] ^= repD10Cat1Piv1
 
ribbonCategory[repD10Cat1Bal17] ^= repD10Cat1Bal17
 
ring[repD10Cat1Bal17] ^= repD10
 
sphericalCategory[repD10Cat1Bal17] ^= repD10Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd9]][
      balancedCategory[#1]] & )[repD10Cat1Bal17] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal17] ^= 17
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv1]][
      balancedCategory[#1]] & )[repD10Cat1Bal17] ^= 9
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd9]][ribbonCategory[#1]] & )[
    repD10Cat1Bal17] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal17] ^= 17
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv1]][
      ribbonCategory[#1]] & )[repD10Cat1Bal17] ^= 9
balancedCategory[repD10Cat1Bal18] ^= repD10Cat1Bal18
 
braidedCategory[repD10Cat1Bal18] ^= repD10Cat1Brd9
 
fusionCategory[repD10Cat1Bal18] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal18] ^= repD10Cat1Piv2
 
ribbonCategory[repD10Cat1Bal18] ^= repD10Cat1Bal18
 
ring[repD10Cat1Bal18] ^= repD10
 
sphericalCategory[repD10Cat1Bal18] ^= repD10Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd9]][
      balancedCategory[#1]] & )[repD10Cat1Bal18] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal18] ^= 18
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv2]][
      balancedCategory[#1]] & )[repD10Cat1Bal18] ^= 9
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd9]][ribbonCategory[#1]] & )[
    repD10Cat1Bal18] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal18] ^= 18
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv2]][
      ribbonCategory[#1]] & )[repD10Cat1Bal18] ^= 9
balancedCategory[repD10Cat1Bal19] ^= repD10Cat1Bal19
 
braidedCategory[repD10Cat1Bal19] ^= repD10Cat1Brd10
 
fusionCategory[repD10Cat1Bal19] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal19] ^= repD10Cat1Piv1
 
ribbonCategory[repD10Cat1Bal19] ^= repD10Cat1Bal19
 
ring[repD10Cat1Bal19] ^= repD10
 
sphericalCategory[repD10Cat1Bal19] ^= repD10Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd10]][
      balancedCategory[#1]] & )[repD10Cat1Bal19] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal19] ^= 19
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv1]][
      balancedCategory[#1]] & )[repD10Cat1Bal19] ^= 10
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd10]][
      ribbonCategory[#1]] & )[repD10Cat1Bal19] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal19] ^= 19
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv1]][
      ribbonCategory[#1]] & )[repD10Cat1Bal19] ^= 10
balancedCategory[repD10Cat1Bal2] ^= repD10Cat1Bal2
 
braidedCategory[repD10Cat1Bal2] ^= repD10Cat1Brd1
 
fusionCategory[repD10Cat1Bal2] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal2] ^= repD10Cat1Piv2
 
ribbonCategory[repD10Cat1Bal2] ^= repD10Cat1Bal2
 
ring[repD10Cat1Bal2] ^= repD10
 
sphericalCategory[repD10Cat1Bal2] ^= repD10Cat1Piv2
 
symmetricCategory[repD10Cat1Bal2] ^= repD10Cat1Brd1
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd1]][
      balancedCategory[#1]] & )[repD10Cat1Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv2]][
      balancedCategory[#1]] & )[repD10Cat1Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv2]][
      ribbonCategory[#1]] & )[repD10Cat1Bal2] ^= 1
balancedCategory[repD10Cat1Bal20] ^= repD10Cat1Bal20
 
braidedCategory[repD10Cat1Bal20] ^= repD10Cat1Brd10
 
fusionCategory[repD10Cat1Bal20] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal20] ^= repD10Cat1Piv2
 
ribbonCategory[repD10Cat1Bal20] ^= repD10Cat1Bal20
 
ring[repD10Cat1Bal20] ^= repD10
 
sphericalCategory[repD10Cat1Bal20] ^= repD10Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd10]][
      balancedCategory[#1]] & )[repD10Cat1Bal20] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal20] ^= 20
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv2]][
      balancedCategory[#1]] & )[repD10Cat1Bal20] ^= 10
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd10]][
      ribbonCategory[#1]] & )[repD10Cat1Bal20] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal20] ^= 20
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv2]][
      ribbonCategory[#1]] & )[repD10Cat1Bal20] ^= 10
balancedCategory[repD10Cat1Bal3] ^= repD10Cat1Bal3
 
braidedCategory[repD10Cat1Bal3] ^= repD10Cat1Brd2
 
fusionCategory[repD10Cat1Bal3] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal3] ^= repD10Cat1Piv1
 
ribbonCategory[repD10Cat1Bal3] ^= repD10Cat1Bal3
 
ring[repD10Cat1Bal3] ^= repD10
 
sphericalCategory[repD10Cat1Bal3] ^= repD10Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd2]][
      balancedCategory[#1]] & )[repD10Cat1Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv1]][
      balancedCategory[#1]] & )[repD10Cat1Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd2]][ribbonCategory[#1]] & )[
    repD10Cat1Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv1]][
      ribbonCategory[#1]] & )[repD10Cat1Bal3] ^= 2
balancedCategory[repD10Cat1Bal4] ^= repD10Cat1Bal4
 
braidedCategory[repD10Cat1Bal4] ^= repD10Cat1Brd2
 
fusionCategory[repD10Cat1Bal4] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal4] ^= repD10Cat1Piv2
 
ribbonCategory[repD10Cat1Bal4] ^= repD10Cat1Bal4
 
ring[repD10Cat1Bal4] ^= repD10
 
sphericalCategory[repD10Cat1Bal4] ^= repD10Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd2]][
      balancedCategory[#1]] & )[repD10Cat1Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv2]][
      balancedCategory[#1]] & )[repD10Cat1Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd2]][ribbonCategory[#1]] & )[
    repD10Cat1Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv2]][
      ribbonCategory[#1]] & )[repD10Cat1Bal4] ^= 2
balancedCategory[repD10Cat1Bal5] ^= repD10Cat1Bal5
 
braidedCategory[repD10Cat1Bal5] ^= repD10Cat1Brd3
 
fusionCategory[repD10Cat1Bal5] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal5] ^= repD10Cat1Piv1
 
ribbonCategory[repD10Cat1Bal5] ^= repD10Cat1Bal5
 
ring[repD10Cat1Bal5] ^= repD10
 
sphericalCategory[repD10Cat1Bal5] ^= repD10Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd3]][
      balancedCategory[#1]] & )[repD10Cat1Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv1]][
      balancedCategory[#1]] & )[repD10Cat1Bal5] ^= 3
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd3]][ribbonCategory[#1]] & )[
    repD10Cat1Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv1]][
      ribbonCategory[#1]] & )[repD10Cat1Bal5] ^= 3
balancedCategory[repD10Cat1Bal6] ^= repD10Cat1Bal6
 
braidedCategory[repD10Cat1Bal6] ^= repD10Cat1Brd3
 
fusionCategory[repD10Cat1Bal6] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal6] ^= repD10Cat1Piv2
 
ribbonCategory[repD10Cat1Bal6] ^= repD10Cat1Bal6
 
ring[repD10Cat1Bal6] ^= repD10
 
sphericalCategory[repD10Cat1Bal6] ^= repD10Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd3]][
      balancedCategory[#1]] & )[repD10Cat1Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv2]][
      balancedCategory[#1]] & )[repD10Cat1Bal6] ^= 3
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd3]][ribbonCategory[#1]] & )[
    repD10Cat1Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv2]][
      ribbonCategory[#1]] & )[repD10Cat1Bal6] ^= 3
balancedCategory[repD10Cat1Bal7] ^= repD10Cat1Bal7
 
braidedCategory[repD10Cat1Bal7] ^= repD10Cat1Brd4
 
fusionCategory[repD10Cat1Bal7] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal7] ^= repD10Cat1Piv1
 
ribbonCategory[repD10Cat1Bal7] ^= repD10Cat1Bal7
 
ring[repD10Cat1Bal7] ^= repD10
 
sphericalCategory[repD10Cat1Bal7] ^= repD10Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd4]][
      balancedCategory[#1]] & )[repD10Cat1Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv1]][
      balancedCategory[#1]] & )[repD10Cat1Bal7] ^= 4
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd4]][ribbonCategory[#1]] & )[
    repD10Cat1Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv1]][
      ribbonCategory[#1]] & )[repD10Cat1Bal7] ^= 4
balancedCategory[repD10Cat1Bal8] ^= repD10Cat1Bal8
 
braidedCategory[repD10Cat1Bal8] ^= repD10Cat1Brd4
 
fusionCategory[repD10Cat1Bal8] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal8] ^= repD10Cat1Piv2
 
ribbonCategory[repD10Cat1Bal8] ^= repD10Cat1Bal8
 
ring[repD10Cat1Bal8] ^= repD10
 
sphericalCategory[repD10Cat1Bal8] ^= repD10Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd4]][
      balancedCategory[#1]] & )[repD10Cat1Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv2]][
      balancedCategory[#1]] & )[repD10Cat1Bal8] ^= 4
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd4]][ribbonCategory[#1]] & )[
    repD10Cat1Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv2]][
      ribbonCategory[#1]] & )[repD10Cat1Bal8] ^= 4
balancedCategory[repD10Cat1Bal9] ^= repD10Cat1Bal9
 
braidedCategory[repD10Cat1Bal9] ^= repD10Cat1Brd5
 
fusionCategory[repD10Cat1Bal9] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Bal9] ^= repD10Cat1Piv1
 
ribbonCategory[repD10Cat1Bal9] ^= repD10Cat1Bal9
 
ring[repD10Cat1Bal9] ^= repD10
 
sphericalCategory[repD10Cat1Bal9] ^= repD10Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[repD10Cat1Brd5]][
      balancedCategory[#1]] & )[repD10Cat1Bal9] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat1]][balancedCategory[#1]] & )[
    repD10Cat1Bal9] ^= 9
 
(balancedCategoryIndex[pivotalCategory[repD10Cat1Piv1]][
      balancedCategory[#1]] & )[repD10Cat1Bal9] ^= 5
 
(ribbonCategoryIndex[braidedCategory[repD10Cat1Brd5]][ribbonCategory[#1]] & )[
    repD10Cat1Bal9] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat1]][ribbonCategory[#1]] & )[
    repD10Cat1Bal9] ^= 9
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat1Piv1]][
      ribbonCategory[#1]] & )[repD10Cat1Bal9] ^= 5
balancedCategories[repD10Cat1Brd1] ^= {repD10Cat1Bal1, repD10Cat1Bal2}
 
repD10Cat1Brd1 /: balancedCategory[repD10Cat1Brd1, 1] = repD10Cat1Bal1
 
repD10Cat1Brd1 /: balancedCategory[repD10Cat1Brd1, 2] = repD10Cat1Bal2
 
braidedCategory[repD10Cat1Brd1] ^= repD10Cat1Brd1
 
fusionCategory[repD10Cat1Brd1] ^= repD10Cat1
 
repD10Cat1Brd1 /: modularCategory[repD10Cat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat1Brd1 /: ribbonCategory[repD10Cat1Brd1, 1] = repD10Cat1Bal1
 
repD10Cat1Brd1 /: ribbonCategory[repD10Cat1Brd1, 2] = repD10Cat1Bal2
 
ring[repD10Cat1Brd1] ^= repD10
 
rMatrixFunction[repD10Cat1Brd1] ^= repD10Cat1Brd1RMatrixFunction
 
symmetricCategory[repD10Cat1Brd1] ^= repD10Cat1Brd1
 
(braidedCategoryIndex[fusionCategory[repD10Cat1]][braidedCategory[#1]] & )[
    repD10Cat1Brd1] ^= 1
 
(symmetricCategoryIndex[fusionCategory[repD10Cat1]][
      symmetricCategory[#1]] & )[repD10Cat1Brd1] ^= 1
balancedCategories[repD10Cat1Brd10] ^= {repD10Cat1Bal19, repD10Cat1Bal20}
 
repD10Cat1Brd10 /: balancedCategory[repD10Cat1Brd10, 1] = repD10Cat1Bal19
 
repD10Cat1Brd10 /: balancedCategory[repD10Cat1Brd10, 2] = repD10Cat1Bal20
 
braidedCategory[repD10Cat1Brd10] ^= repD10Cat1Brd10
 
fusionCategory[repD10Cat1Brd10] ^= repD10Cat1
 
repD10Cat1Brd10 /: modularCategory[repD10Cat1Brd10, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat1Brd10 /: ribbonCategory[repD10Cat1Brd10, 1] = repD10Cat1Bal19
 
repD10Cat1Brd10 /: ribbonCategory[repD10Cat1Brd10, 2] = repD10Cat1Bal20
 
ring[repD10Cat1Brd10] ^= repD10
 
rMatrixFunction[repD10Cat1Brd10] ^= repD10Cat1Brd10RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD10Cat1]][braidedCategory[#1]] & )[
    repD10Cat1Brd10] ^= 10
braidedCategory[repD10Cat1Brd10RMatrixFunction] ^= repD10Cat1Brd10
 
fusionCategory[repD10Cat1Brd10RMatrixFunction] ^= repD10Cat1
 
rMatrixFunction[repD10Cat1Brd10RMatrixFunction] ^= 
   repD10Cat1Brd10RMatrixFunction
 
repD10Cat1Brd10RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[1, 1, 2] = {{-1}}
 
repD10Cat1Brd10RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[1, 3, 0] = {{-1}}
 
repD10Cat1Brd10RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[1, 5, 4] = {{-1}}
 
repD10Cat1Brd10RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat1Brd10RMatrixFunction[1, 7, 6] = {{-I}}
 
repD10Cat1Brd10RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[3, 1, 0] = {{-1}}
 
repD10Cat1Brd10RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[3, 3, 2] = {{-1}}
 
repD10Cat1Brd10RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[3, 5, 4] = {{-1}}
 
repD10Cat1Brd10RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat1Brd10RMatrixFunction[3, 7, 6] = {{-I}}
 
repD10Cat1Brd10RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[4, 4, 0] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd10RMatrixFunction[4, 4, 2] = {{(-1)^(1/5)}}
 
repD10Cat1Brd10RMatrixFunction[4, 4, 6] = {{(-1)^(4/5)}}
 
repD10Cat1Brd10RMatrixFunction[4, 5, 1] = {{-(-1)^(7/10)}}
 
repD10Cat1Brd10RMatrixFunction[4, 5, 3] = {{-(-1)^(7/10)}}
 
repD10Cat1Brd10RMatrixFunction[4, 5, 7] = {{(-1)^(4/5)}}
 
repD10Cat1Brd10RMatrixFunction[4, 6, 4] = {{(-1)^(2/5)}}
 
repD10Cat1Brd10RMatrixFunction[4, 6, 6] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd10RMatrixFunction[4, 7, 5] = {{(-1)^(9/10)}}
 
repD10Cat1Brd10RMatrixFunction[4, 7, 7] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd10RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[5, 1, 4] = {{-1}}
 
repD10Cat1Brd10RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[5, 3, 4] = {{-1}}
 
repD10Cat1Brd10RMatrixFunction[5, 4, 1] = {{(-1)^(7/10)}}
 
repD10Cat1Brd10RMatrixFunction[5, 4, 3] = {{(-1)^(7/10)}}
 
repD10Cat1Brd10RMatrixFunction[5, 4, 7] = {{(-1)^(4/5)}}
 
repD10Cat1Brd10RMatrixFunction[5, 5, 0] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd10RMatrixFunction[5, 5, 2] = {{(-1)^(1/5)}}
 
repD10Cat1Brd10RMatrixFunction[5, 5, 6] = {{-(-1)^(4/5)}}
 
repD10Cat1Brd10RMatrixFunction[5, 6, 5] = {{(-1)^(2/5)}}
 
repD10Cat1Brd10RMatrixFunction[5, 6, 7] = {{-(-1)^(1/10)}}
 
repD10Cat1Brd10RMatrixFunction[5, 7, 4] = {{-(-1)^(9/10)}}
 
repD10Cat1Brd10RMatrixFunction[5, 7, 6] = {{(-1)^(1/10)}}
 
repD10Cat1Brd10RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat1Brd10RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat1Brd10RMatrixFunction[6, 4, 4] = {{(-1)^(2/5)}}
 
repD10Cat1Brd10RMatrixFunction[6, 4, 6] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd10RMatrixFunction[6, 5, 5] = {{(-1)^(2/5)}}
 
repD10Cat1Brd10RMatrixFunction[6, 5, 7] = {{(-1)^(1/10)}}
 
repD10Cat1Brd10RMatrixFunction[6, 6, 0] = {{(-1)^(4/5)}}
 
repD10Cat1Brd10RMatrixFunction[6, 6, 2] = {{-(-1)^(4/5)}}
 
repD10Cat1Brd10RMatrixFunction[6, 6, 4] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd10RMatrixFunction[6, 7, 1] = {{-(-1)^(3/10)}}
 
repD10Cat1Brd10RMatrixFunction[6, 7, 3] = {{-(-1)^(3/10)}}
 
repD10Cat1Brd10RMatrixFunction[6, 7, 5] = {{-(-1)^(7/10)}}
 
repD10Cat1Brd10RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[7, 1, 6] = {{I}}
 
repD10Cat1Brd10RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat1Brd10RMatrixFunction[7, 3, 6] = {{I}}
 
repD10Cat1Brd10RMatrixFunction[7, 4, 5] = {{-(-1)^(9/10)}}
 
repD10Cat1Brd10RMatrixFunction[7, 4, 7] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd10RMatrixFunction[7, 5, 4] = {{(-1)^(9/10)}}
 
repD10Cat1Brd10RMatrixFunction[7, 5, 6] = {{-(-1)^(1/10)}}
 
repD10Cat1Brd10RMatrixFunction[7, 6, 1] = {{(-1)^(3/10)}}
 
repD10Cat1Brd10RMatrixFunction[7, 6, 3] = {{(-1)^(3/10)}}
 
repD10Cat1Brd10RMatrixFunction[7, 6, 5] = 
   {{I*(1 + (-1)^(2/5) - (-1)^(3/5) + (-1)^(4/5))}}
 
repD10Cat1Brd10RMatrixFunction[7, 7, 0] = {{(-1)^(4/5)}}
 
repD10Cat1Brd10RMatrixFunction[7, 7, 2] = {{-(-1)^(4/5)}}
 
repD10Cat1Brd10RMatrixFunction[7, 7, 4] = 
   {{1 + (-1)^(2/5) - (-1)^(3/5) + (-1)^(4/5)}}
braidedCategory[repD10Cat1Brd1RMatrixFunction] ^= repD10Cat1Brd1
 
fusionCategory[repD10Cat1Brd1RMatrixFunction] ^= repD10Cat1
 
rMatrixFunction[repD10Cat1Brd1RMatrixFunction] ^= 
   repD10Cat1Brd1RMatrixFunction
 
repD10Cat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[1, 1, 2] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[1, 3, 0] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[1, 5, 4] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat1Brd1RMatrixFunction[1, 7, 6] = {{I}}
 
repD10Cat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[3, 1, 0] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[3, 3, 2] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[3, 5, 4] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat1Brd1RMatrixFunction[3, 7, 6] = {{I}}
 
repD10Cat1Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[4, 4, 0] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[4, 4, 2] = {{-1}}
 
repD10Cat1Brd1RMatrixFunction[4, 4, 6] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[4, 5, 1] = {{I}}
 
repD10Cat1Brd1RMatrixFunction[4, 5, 3] = {{I}}
 
repD10Cat1Brd1RMatrixFunction[4, 5, 7] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[4, 6, 4] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[4, 6, 6] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[4, 7, 5] = {{I}}
 
repD10Cat1Brd1RMatrixFunction[4, 7, 7] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[5, 1, 4] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[5, 3, 4] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[5, 4, 1] = {{-I}}
 
repD10Cat1Brd1RMatrixFunction[5, 4, 3] = {{-I}}
 
repD10Cat1Brd1RMatrixFunction[5, 4, 7] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[5, 5, 0] = {{-1}}
 
repD10Cat1Brd1RMatrixFunction[5, 5, 2] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[5, 5, 6] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[5, 6, 5] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[5, 6, 7] = {{-I}}
 
repD10Cat1Brd1RMatrixFunction[5, 7, 4] = {{I}}
 
repD10Cat1Brd1RMatrixFunction[5, 7, 6] = {{-I}}
 
repD10Cat1Brd1RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat1Brd1RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat1Brd1RMatrixFunction[6, 4, 4] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[6, 4, 6] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[6, 5, 5] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[6, 5, 7] = {{I}}
 
repD10Cat1Brd1RMatrixFunction[6, 6, 0] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[6, 6, 2] = {{-1}}
 
repD10Cat1Brd1RMatrixFunction[6, 6, 4] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[6, 7, 1] = {{I}}
 
repD10Cat1Brd1RMatrixFunction[6, 7, 3] = {{I}}
 
repD10Cat1Brd1RMatrixFunction[6, 7, 5] = {{I}}
 
repD10Cat1Brd1RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[7, 1, 6] = {{-I}}
 
repD10Cat1Brd1RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[7, 3, 6] = {{-I}}
 
repD10Cat1Brd1RMatrixFunction[7, 4, 5] = {{-I}}
 
repD10Cat1Brd1RMatrixFunction[7, 4, 7] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[7, 5, 4] = {{-I}}
 
repD10Cat1Brd1RMatrixFunction[7, 5, 6] = {{I}}
 
repD10Cat1Brd1RMatrixFunction[7, 6, 1] = {{-I}}
 
repD10Cat1Brd1RMatrixFunction[7, 6, 3] = {{-I}}
 
repD10Cat1Brd1RMatrixFunction[7, 6, 5] = {{-I}}
 
repD10Cat1Brd1RMatrixFunction[7, 7, 0] = {{-1}}
 
repD10Cat1Brd1RMatrixFunction[7, 7, 2] = {{1}}
 
repD10Cat1Brd1RMatrixFunction[7, 7, 4] = {{1}}
balancedCategories[repD10Cat1Brd2] ^= {repD10Cat1Bal3, repD10Cat1Bal4}
 
repD10Cat1Brd2 /: balancedCategory[repD10Cat1Brd2, 1] = repD10Cat1Bal3
 
repD10Cat1Brd2 /: balancedCategory[repD10Cat1Brd2, 2] = repD10Cat1Bal4
 
braidedCategory[repD10Cat1Brd2] ^= repD10Cat1Brd2
 
fusionCategory[repD10Cat1Brd2] ^= repD10Cat1
 
repD10Cat1Brd2 /: modularCategory[repD10Cat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat1Brd2 /: ribbonCategory[repD10Cat1Brd2, 1] = repD10Cat1Bal3
 
repD10Cat1Brd2 /: ribbonCategory[repD10Cat1Brd2, 2] = repD10Cat1Bal4
 
ring[repD10Cat1Brd2] ^= repD10
 
rMatrixFunction[repD10Cat1Brd2] ^= repD10Cat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD10Cat1]][braidedCategory[#1]] & )[
    repD10Cat1Brd2] ^= 2
braidedCategory[repD10Cat1Brd2RMatrixFunction] ^= repD10Cat1Brd2
 
fusionCategory[repD10Cat1Brd2RMatrixFunction] ^= repD10Cat1
 
rMatrixFunction[repD10Cat1Brd2RMatrixFunction] ^= 
   repD10Cat1Brd2RMatrixFunction
 
repD10Cat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[1, 1, 2] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[1, 3, 0] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[1, 5, 4] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat1Brd2RMatrixFunction[1, 7, 6] = {{I}}
 
repD10Cat1Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[3, 1, 0] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[3, 3, 2] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[3, 5, 4] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat1Brd2RMatrixFunction[3, 7, 6] = {{I}}
 
repD10Cat1Brd2RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[4, 4, 0] = {{(-1)^(4/5)}}
 
repD10Cat1Brd2RMatrixFunction[4, 4, 2] = {{-(-1)^(4/5)}}
 
repD10Cat1Brd2RMatrixFunction[4, 4, 6] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd2RMatrixFunction[4, 5, 1] = {{-(-1)^(3/10)}}
 
repD10Cat1Brd2RMatrixFunction[4, 5, 3] = {{-(-1)^(3/10)}}
 
repD10Cat1Brd2RMatrixFunction[4, 5, 7] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd2RMatrixFunction[4, 6, 4] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd2RMatrixFunction[4, 6, 6] = {{(-1)^(2/5)}}
 
repD10Cat1Brd2RMatrixFunction[4, 7, 5] = {{(-1)^(1/10)}}
 
repD10Cat1Brd2RMatrixFunction[4, 7, 7] = {{(-1)^(2/5)}}
 
repD10Cat1Brd2RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[5, 1, 4] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[5, 3, 4] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[5, 4, 1] = {{(-1)^(3/10)}}
 
repD10Cat1Brd2RMatrixFunction[5, 4, 3] = {{(-1)^(3/10)}}
 
repD10Cat1Brd2RMatrixFunction[5, 4, 7] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd2RMatrixFunction[5, 5, 0] = {{-(-1)^(4/5)}}
 
repD10Cat1Brd2RMatrixFunction[5, 5, 2] = {{(-1)^(4/5)}}
 
repD10Cat1Brd2RMatrixFunction[5, 5, 6] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd2RMatrixFunction[5, 6, 5] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd2RMatrixFunction[5, 6, 7] = {{-(-1)^(9/10)}}
 
repD10Cat1Brd2RMatrixFunction[5, 7, 4] = {{(-1)^(1/10)}}
 
repD10Cat1Brd2RMatrixFunction[5, 7, 6] = {{-(-1)^(9/10)}}
 
repD10Cat1Brd2RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat1Brd2RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat1Brd2RMatrixFunction[6, 4, 4] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd2RMatrixFunction[6, 4, 6] = {{(-1)^(2/5)}}
 
repD10Cat1Brd2RMatrixFunction[6, 5, 5] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd2RMatrixFunction[6, 5, 7] = {{(-1)^(9/10)}}
 
repD10Cat1Brd2RMatrixFunction[6, 6, 0] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd2RMatrixFunction[6, 6, 2] = {{(-1)^(1/5)}}
 
repD10Cat1Brd2RMatrixFunction[6, 6, 4] = {{(-1)^(4/5)}}
 
repD10Cat1Brd2RMatrixFunction[6, 7, 1] = {{-(-1)^(7/10)}}
 
repD10Cat1Brd2RMatrixFunction[6, 7, 3] = {{-(-1)^(7/10)}}
 
repD10Cat1Brd2RMatrixFunction[6, 7, 5] = {{-(-1)^(3/10)}}
 
repD10Cat1Brd2RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[7, 1, 6] = {{-I}}
 
repD10Cat1Brd2RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat1Brd2RMatrixFunction[7, 3, 6] = {{-I}}
 
repD10Cat1Brd2RMatrixFunction[7, 4, 5] = {{-(-1)^(1/10)}}
 
repD10Cat1Brd2RMatrixFunction[7, 4, 7] = {{(-1)^(2/5)}}
 
repD10Cat1Brd2RMatrixFunction[7, 5, 4] = {{-(-1)^(1/10)}}
 
repD10Cat1Brd2RMatrixFunction[7, 5, 6] = {{(-1)^(9/10)}}
 
repD10Cat1Brd2RMatrixFunction[7, 6, 1] = {{(-1)^(7/10)}}
 
repD10Cat1Brd2RMatrixFunction[7, 6, 3] = {{(-1)^(7/10)}}
 
repD10Cat1Brd2RMatrixFunction[7, 6, 5] = {{(-1)^(3/10)}}
 
repD10Cat1Brd2RMatrixFunction[7, 7, 0] = {{(-1)^(1/5)}}
 
repD10Cat1Brd2RMatrixFunction[7, 7, 2] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd2RMatrixFunction[7, 7, 4] = {{(-1)^(4/5)}}
balancedCategories[repD10Cat1Brd3] ^= {repD10Cat1Bal5, repD10Cat1Bal6}
 
repD10Cat1Brd3 /: balancedCategory[repD10Cat1Brd3, 1] = repD10Cat1Bal5
 
repD10Cat1Brd3 /: balancedCategory[repD10Cat1Brd3, 2] = repD10Cat1Bal6
 
braidedCategory[repD10Cat1Brd3] ^= repD10Cat1Brd3
 
fusionCategory[repD10Cat1Brd3] ^= repD10Cat1
 
repD10Cat1Brd3 /: modularCategory[repD10Cat1Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat1Brd3 /: ribbonCategory[repD10Cat1Brd3, 1] = repD10Cat1Bal5
 
repD10Cat1Brd3 /: ribbonCategory[repD10Cat1Brd3, 2] = repD10Cat1Bal6
 
ring[repD10Cat1Brd3] ^= repD10
 
rMatrixFunction[repD10Cat1Brd3] ^= repD10Cat1Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD10Cat1]][braidedCategory[#1]] & )[
    repD10Cat1Brd3] ^= 3
braidedCategory[repD10Cat1Brd3RMatrixFunction] ^= repD10Cat1Brd3
 
fusionCategory[repD10Cat1Brd3RMatrixFunction] ^= repD10Cat1
 
rMatrixFunction[repD10Cat1Brd3RMatrixFunction] ^= 
   repD10Cat1Brd3RMatrixFunction
 
repD10Cat1Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[1, 1, 2] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[1, 3, 0] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[1, 5, 4] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat1Brd3RMatrixFunction[1, 7, 6] = {{I}}
 
repD10Cat1Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[3, 1, 0] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[3, 3, 2] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[3, 5, 4] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat1Brd3RMatrixFunction[3, 7, 6] = {{I}}
 
repD10Cat1Brd3RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[4, 4, 0] = {{(-1)^(2/5)}}
 
repD10Cat1Brd3RMatrixFunction[4, 4, 2] = {{-(-1)^(2/5)}}
 
repD10Cat1Brd3RMatrixFunction[4, 4, 6] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd3RMatrixFunction[4, 5, 1] = {{(-1)^(9/10)}}
 
repD10Cat1Brd3RMatrixFunction[4, 5, 3] = {{(-1)^(9/10)}}
 
repD10Cat1Brd3RMatrixFunction[4, 5, 7] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd3RMatrixFunction[4, 6, 4] = {{(-1)^(4/5)}}
 
repD10Cat1Brd3RMatrixFunction[4, 6, 6] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd3RMatrixFunction[4, 7, 5] = {{-(-1)^(3/10)}}
 
repD10Cat1Brd3RMatrixFunction[4, 7, 7] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd3RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[5, 1, 4] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[5, 3, 4] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[5, 4, 1] = {{-(-1)^(9/10)}}
 
repD10Cat1Brd3RMatrixFunction[5, 4, 3] = {{-(-1)^(9/10)}}
 
repD10Cat1Brd3RMatrixFunction[5, 4, 7] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd3RMatrixFunction[5, 5, 0] = {{-(-1)^(2/5)}}
 
repD10Cat1Brd3RMatrixFunction[5, 5, 2] = {{(-1)^(2/5)}}
 
repD10Cat1Brd3RMatrixFunction[5, 5, 6] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd3RMatrixFunction[5, 6, 5] = {{(-1)^(4/5)}}
 
repD10Cat1Brd3RMatrixFunction[5, 6, 7] = {{(-1)^(7/10)}}
 
repD10Cat1Brd3RMatrixFunction[5, 7, 4] = {{-(-1)^(3/10)}}
 
repD10Cat1Brd3RMatrixFunction[5, 7, 6] = {{(-1)^(7/10)}}
 
repD10Cat1Brd3RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat1Brd3RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat1Brd3RMatrixFunction[6, 4, 4] = {{(-1)^(4/5)}}
 
repD10Cat1Brd3RMatrixFunction[6, 4, 6] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd3RMatrixFunction[6, 5, 5] = {{(-1)^(4/5)}}
 
repD10Cat1Brd3RMatrixFunction[6, 5, 7] = {{-(-1)^(7/10)}}
 
repD10Cat1Brd3RMatrixFunction[6, 6, 0] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd3RMatrixFunction[6, 6, 2] = {{(-1)^(3/5)}}
 
repD10Cat1Brd3RMatrixFunction[6, 6, 4] = {{(-1)^(2/5)}}
 
repD10Cat1Brd3RMatrixFunction[6, 7, 1] = {{(-1)^(1/10)}}
 
repD10Cat1Brd3RMatrixFunction[6, 7, 3] = {{(-1)^(1/10)}}
 
repD10Cat1Brd3RMatrixFunction[6, 7, 5] = {{(-1)^(9/10)}}
 
repD10Cat1Brd3RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[7, 1, 6] = {{-I}}
 
repD10Cat1Brd3RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat1Brd3RMatrixFunction[7, 3, 6] = {{-I}}
 
repD10Cat1Brd3RMatrixFunction[7, 4, 5] = {{(-1)^(3/10)}}
 
repD10Cat1Brd3RMatrixFunction[7, 4, 7] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd3RMatrixFunction[7, 5, 4] = {{(-1)^(3/10)}}
 
repD10Cat1Brd3RMatrixFunction[7, 5, 6] = {{-(-1)^(7/10)}}
 
repD10Cat1Brd3RMatrixFunction[7, 6, 1] = {{-(-1)^(1/10)}}
 
repD10Cat1Brd3RMatrixFunction[7, 6, 3] = {{-(-1)^(1/10)}}
 
repD10Cat1Brd3RMatrixFunction[7, 6, 5] = {{-(-1)^(9/10)}}
 
repD10Cat1Brd3RMatrixFunction[7, 7, 0] = {{(-1)^(3/5)}}
 
repD10Cat1Brd3RMatrixFunction[7, 7, 2] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd3RMatrixFunction[7, 7, 4] = {{(-1)^(2/5)}}
balancedCategories[repD10Cat1Brd4] ^= {repD10Cat1Bal7, repD10Cat1Bal8}
 
repD10Cat1Brd4 /: balancedCategory[repD10Cat1Brd4, 1] = repD10Cat1Bal7
 
repD10Cat1Brd4 /: balancedCategory[repD10Cat1Brd4, 2] = repD10Cat1Bal8
 
braidedCategory[repD10Cat1Brd4] ^= repD10Cat1Brd4
 
fusionCategory[repD10Cat1Brd4] ^= repD10Cat1
 
repD10Cat1Brd4 /: modularCategory[repD10Cat1Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat1Brd4 /: ribbonCategory[repD10Cat1Brd4, 1] = repD10Cat1Bal7
 
repD10Cat1Brd4 /: ribbonCategory[repD10Cat1Brd4, 2] = repD10Cat1Bal8
 
ring[repD10Cat1Brd4] ^= repD10
 
rMatrixFunction[repD10Cat1Brd4] ^= repD10Cat1Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD10Cat1]][braidedCategory[#1]] & )[
    repD10Cat1Brd4] ^= 4
braidedCategory[repD10Cat1Brd4RMatrixFunction] ^= repD10Cat1Brd4
 
fusionCategory[repD10Cat1Brd4RMatrixFunction] ^= repD10Cat1
 
rMatrixFunction[repD10Cat1Brd4RMatrixFunction] ^= 
   repD10Cat1Brd4RMatrixFunction
 
repD10Cat1Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[1, 1, 2] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[1, 3, 0] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[1, 5, 4] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat1Brd4RMatrixFunction[1, 7, 6] = {{I}}
 
repD10Cat1Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[3, 1, 0] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[3, 3, 2] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[3, 5, 4] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat1Brd4RMatrixFunction[3, 7, 6] = {{I}}
 
repD10Cat1Brd4RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[4, 4, 0] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd4RMatrixFunction[4, 4, 2] = {{(-1)^(3/5)}}
 
repD10Cat1Brd4RMatrixFunction[4, 4, 6] = {{(-1)^(2/5)}}
 
repD10Cat1Brd4RMatrixFunction[4, 5, 1] = {{(-1)^(1/10)}}
 
repD10Cat1Brd4RMatrixFunction[4, 5, 3] = {{(-1)^(1/10)}}
 
repD10Cat1Brd4RMatrixFunction[4, 5, 7] = {{(-1)^(2/5)}}
 
repD10Cat1Brd4RMatrixFunction[4, 6, 4] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd4RMatrixFunction[4, 6, 6] = {{(-1)^(4/5)}}
 
repD10Cat1Brd4RMatrixFunction[4, 7, 5] = {{-(-1)^(7/10)}}
 
repD10Cat1Brd4RMatrixFunction[4, 7, 7] = {{(-1)^(4/5)}}
 
repD10Cat1Brd4RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[5, 1, 4] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[5, 3, 4] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[5, 4, 1] = {{-(-1)^(1/10)}}
 
repD10Cat1Brd4RMatrixFunction[5, 4, 3] = {{-(-1)^(1/10)}}
 
repD10Cat1Brd4RMatrixFunction[5, 4, 7] = {{(-1)^(2/5)}}
 
repD10Cat1Brd4RMatrixFunction[5, 5, 0] = {{(-1)^(3/5)}}
 
repD10Cat1Brd4RMatrixFunction[5, 5, 2] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd4RMatrixFunction[5, 5, 6] = {{(-1)^(2/5)}}
 
repD10Cat1Brd4RMatrixFunction[5, 6, 5] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd4RMatrixFunction[5, 6, 7] = {{(-1)^(3/10)}}
 
repD10Cat1Brd4RMatrixFunction[5, 7, 4] = {{-(-1)^(7/10)}}
 
repD10Cat1Brd4RMatrixFunction[5, 7, 6] = {{(-1)^(3/10)}}
 
repD10Cat1Brd4RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat1Brd4RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat1Brd4RMatrixFunction[6, 4, 4] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd4RMatrixFunction[6, 4, 6] = {{(-1)^(4/5)}}
 
repD10Cat1Brd4RMatrixFunction[6, 5, 5] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd4RMatrixFunction[6, 5, 7] = {{-(-1)^(3/10)}}
 
repD10Cat1Brd4RMatrixFunction[6, 6, 0] = {{(-1)^(2/5)}}
 
repD10Cat1Brd4RMatrixFunction[6, 6, 2] = {{-(-1)^(2/5)}}
 
repD10Cat1Brd4RMatrixFunction[6, 6, 4] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd4RMatrixFunction[6, 7, 1] = {{(-1)^(9/10)}}
 
repD10Cat1Brd4RMatrixFunction[6, 7, 3] = {{(-1)^(9/10)}}
 
repD10Cat1Brd4RMatrixFunction[6, 7, 5] = {{(-1)^(1/10)}}
 
repD10Cat1Brd4RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[7, 1, 6] = {{-I}}
 
repD10Cat1Brd4RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat1Brd4RMatrixFunction[7, 3, 6] = {{-I}}
 
repD10Cat1Brd4RMatrixFunction[7, 4, 5] = {{(-1)^(7/10)}}
 
repD10Cat1Brd4RMatrixFunction[7, 4, 7] = {{(-1)^(4/5)}}
 
repD10Cat1Brd4RMatrixFunction[7, 5, 4] = {{(-1)^(7/10)}}
 
repD10Cat1Brd4RMatrixFunction[7, 5, 6] = {{-(-1)^(3/10)}}
 
repD10Cat1Brd4RMatrixFunction[7, 6, 1] = {{-(-1)^(9/10)}}
 
repD10Cat1Brd4RMatrixFunction[7, 6, 3] = {{-(-1)^(9/10)}}
 
repD10Cat1Brd4RMatrixFunction[7, 6, 5] = 
   {{I*(1 - (-1)^(1/5) + (-1)^(2/5) + (-1)^(4/5))}}
 
repD10Cat1Brd4RMatrixFunction[7, 7, 0] = {{-(-1)^(2/5)}}
 
repD10Cat1Brd4RMatrixFunction[7, 7, 2] = {{(-1)^(2/5)}}
 
repD10Cat1Brd4RMatrixFunction[7, 7, 4] = {{-(-1)^(3/5)}}
balancedCategories[repD10Cat1Brd5] ^= {repD10Cat1Bal9, repD10Cat1Bal10}
 
repD10Cat1Brd5 /: balancedCategory[repD10Cat1Brd5, 1] = repD10Cat1Bal9
 
repD10Cat1Brd5 /: balancedCategory[repD10Cat1Brd5, 2] = repD10Cat1Bal10
 
braidedCategory[repD10Cat1Brd5] ^= repD10Cat1Brd5
 
fusionCategory[repD10Cat1Brd5] ^= repD10Cat1
 
repD10Cat1Brd5 /: modularCategory[repD10Cat1Brd5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat1Brd5 /: ribbonCategory[repD10Cat1Brd5, 1] = repD10Cat1Bal9
 
repD10Cat1Brd5 /: ribbonCategory[repD10Cat1Brd5, 2] = repD10Cat1Bal10
 
ring[repD10Cat1Brd5] ^= repD10
 
rMatrixFunction[repD10Cat1Brd5] ^= repD10Cat1Brd5RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD10Cat1]][braidedCategory[#1]] & )[
    repD10Cat1Brd5] ^= 5
braidedCategory[repD10Cat1Brd5RMatrixFunction] ^= repD10Cat1Brd5
 
fusionCategory[repD10Cat1Brd5RMatrixFunction] ^= repD10Cat1
 
rMatrixFunction[repD10Cat1Brd5RMatrixFunction] ^= 
   repD10Cat1Brd5RMatrixFunction
 
repD10Cat1Brd5RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[1, 1, 2] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[1, 3, 0] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[1, 5, 4] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat1Brd5RMatrixFunction[1, 7, 6] = {{I}}
 
repD10Cat1Brd5RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[3, 1, 0] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[3, 3, 2] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[3, 5, 4] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat1Brd5RMatrixFunction[3, 7, 6] = {{I}}
 
repD10Cat1Brd5RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[4, 4, 0] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd5RMatrixFunction[4, 4, 2] = {{(-1)^(1/5)}}
 
repD10Cat1Brd5RMatrixFunction[4, 4, 6] = {{(-1)^(4/5)}}
 
repD10Cat1Brd5RMatrixFunction[4, 5, 1] = {{-(-1)^(7/10)}}
 
repD10Cat1Brd5RMatrixFunction[4, 5, 3] = {{-(-1)^(7/10)}}
 
repD10Cat1Brd5RMatrixFunction[4, 5, 7] = {{(-1)^(4/5)}}
 
repD10Cat1Brd5RMatrixFunction[4, 6, 4] = {{(-1)^(2/5)}}
 
repD10Cat1Brd5RMatrixFunction[4, 6, 6] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd5RMatrixFunction[4, 7, 5] = {{(-1)^(9/10)}}
 
repD10Cat1Brd5RMatrixFunction[4, 7, 7] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd5RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[5, 1, 4] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[5, 3, 4] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[5, 4, 1] = {{(-1)^(7/10)}}
 
repD10Cat1Brd5RMatrixFunction[5, 4, 3] = {{(-1)^(7/10)}}
 
repD10Cat1Brd5RMatrixFunction[5, 4, 7] = {{(-1)^(4/5)}}
 
repD10Cat1Brd5RMatrixFunction[5, 5, 0] = {{(-1)^(1/5)}}
 
repD10Cat1Brd5RMatrixFunction[5, 5, 2] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd5RMatrixFunction[5, 5, 6] = {{(-1)^(4/5)}}
 
repD10Cat1Brd5RMatrixFunction[5, 6, 5] = {{(-1)^(2/5)}}
 
repD10Cat1Brd5RMatrixFunction[5, 6, 7] = {{-(-1)^(1/10)}}
 
repD10Cat1Brd5RMatrixFunction[5, 7, 4] = {{(-1)^(9/10)}}
 
repD10Cat1Brd5RMatrixFunction[5, 7, 6] = {{-(-1)^(1/10)}}
 
repD10Cat1Brd5RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat1Brd5RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat1Brd5RMatrixFunction[6, 4, 4] = {{(-1)^(2/5)}}
 
repD10Cat1Brd5RMatrixFunction[6, 4, 6] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd5RMatrixFunction[6, 5, 5] = {{(-1)^(2/5)}}
 
repD10Cat1Brd5RMatrixFunction[6, 5, 7] = {{(-1)^(1/10)}}
 
repD10Cat1Brd5RMatrixFunction[6, 6, 0] = {{(-1)^(4/5)}}
 
repD10Cat1Brd5RMatrixFunction[6, 6, 2] = {{-(-1)^(4/5)}}
 
repD10Cat1Brd5RMatrixFunction[6, 6, 4] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd5RMatrixFunction[6, 7, 1] = {{-(-1)^(3/10)}}
 
repD10Cat1Brd5RMatrixFunction[6, 7, 3] = {{-(-1)^(3/10)}}
 
repD10Cat1Brd5RMatrixFunction[6, 7, 5] = {{-(-1)^(7/10)}}
 
repD10Cat1Brd5RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[7, 1, 6] = {{-I}}
 
repD10Cat1Brd5RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat1Brd5RMatrixFunction[7, 3, 6] = {{-I}}
 
repD10Cat1Brd5RMatrixFunction[7, 4, 5] = {{-(-1)^(9/10)}}
 
repD10Cat1Brd5RMatrixFunction[7, 4, 7] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd5RMatrixFunction[7, 5, 4] = {{-(-1)^(9/10)}}
 
repD10Cat1Brd5RMatrixFunction[7, 5, 6] = {{(-1)^(1/10)}}
 
repD10Cat1Brd5RMatrixFunction[7, 6, 1] = {{(-1)^(3/10)}}
 
repD10Cat1Brd5RMatrixFunction[7, 6, 3] = {{(-1)^(3/10)}}
 
repD10Cat1Brd5RMatrixFunction[7, 6, 5] = 
   {{I*(1 + (-1)^(2/5) - (-1)^(3/5) + (-1)^(4/5))}}
 
repD10Cat1Brd5RMatrixFunction[7, 7, 0] = {{-(-1)^(4/5)}}
 
repD10Cat1Brd5RMatrixFunction[7, 7, 2] = {{(-1)^(4/5)}}
 
repD10Cat1Brd5RMatrixFunction[7, 7, 4] = {{-(-1)^(1/5)}}
balancedCategories[repD10Cat1Brd6] ^= {repD10Cat1Bal11, repD10Cat1Bal12}
 
repD10Cat1Brd6 /: balancedCategory[repD10Cat1Brd6, 1] = repD10Cat1Bal11
 
repD10Cat1Brd6 /: balancedCategory[repD10Cat1Brd6, 2] = repD10Cat1Bal12
 
braidedCategory[repD10Cat1Brd6] ^= repD10Cat1Brd6
 
fusionCategory[repD10Cat1Brd6] ^= repD10Cat1
 
repD10Cat1Brd6 /: modularCategory[repD10Cat1Brd6, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat1Brd6 /: ribbonCategory[repD10Cat1Brd6, 1] = repD10Cat1Bal11
 
repD10Cat1Brd6 /: ribbonCategory[repD10Cat1Brd6, 2] = repD10Cat1Bal12
 
ring[repD10Cat1Brd6] ^= repD10
 
rMatrixFunction[repD10Cat1Brd6] ^= repD10Cat1Brd6RMatrixFunction
 
symmetricCategory[repD10Cat1Brd6] ^= repD10Cat1Brd6
 
(braidedCategoryIndex[fusionCategory[repD10Cat1]][braidedCategory[#1]] & )[
    repD10Cat1Brd6] ^= 6
 
(symmetricCategoryIndex[fusionCategory[repD10Cat1]][
      symmetricCategory[#1]] & )[repD10Cat1Brd6] ^= 2
braidedCategory[repD10Cat1Brd6RMatrixFunction] ^= repD10Cat1Brd6
 
fusionCategory[repD10Cat1Brd6RMatrixFunction] ^= repD10Cat1
 
rMatrixFunction[repD10Cat1Brd6RMatrixFunction] ^= 
   repD10Cat1Brd6RMatrixFunction
 
repD10Cat1Brd6RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[1, 1, 2] = {{-1}}
 
repD10Cat1Brd6RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[1, 3, 0] = {{-1}}
 
repD10Cat1Brd6RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[1, 5, 4] = {{-1}}
 
repD10Cat1Brd6RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat1Brd6RMatrixFunction[1, 7, 6] = {{-I}}
 
repD10Cat1Brd6RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[3, 1, 0] = {{-1}}
 
repD10Cat1Brd6RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[3, 3, 2] = {{-1}}
 
repD10Cat1Brd6RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[3, 5, 4] = {{-1}}
 
repD10Cat1Brd6RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat1Brd6RMatrixFunction[3, 7, 6] = {{-I}}
 
repD10Cat1Brd6RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[4, 4, 0] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[4, 4, 2] = {{-1}}
 
repD10Cat1Brd6RMatrixFunction[4, 4, 6] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[4, 5, 1] = {{I}}
 
repD10Cat1Brd6RMatrixFunction[4, 5, 3] = {{I}}
 
repD10Cat1Brd6RMatrixFunction[4, 5, 7] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[4, 6, 4] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[4, 6, 6] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[4, 7, 5] = {{I}}
 
repD10Cat1Brd6RMatrixFunction[4, 7, 7] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[5, 1, 4] = {{-1}}
 
repD10Cat1Brd6RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[5, 3, 4] = {{-1}}
 
repD10Cat1Brd6RMatrixFunction[5, 4, 1] = {{-I}}
 
repD10Cat1Brd6RMatrixFunction[5, 4, 3] = {{-I}}
 
repD10Cat1Brd6RMatrixFunction[5, 4, 7] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[5, 5, 0] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[5, 5, 2] = {{-1}}
 
repD10Cat1Brd6RMatrixFunction[5, 5, 6] = {{-1}}
 
repD10Cat1Brd6RMatrixFunction[5, 6, 5] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[5, 6, 7] = {{-I}}
 
repD10Cat1Brd6RMatrixFunction[5, 7, 4] = {{-I}}
 
repD10Cat1Brd6RMatrixFunction[5, 7, 6] = {{I}}
 
repD10Cat1Brd6RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat1Brd6RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat1Brd6RMatrixFunction[6, 4, 4] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[6, 4, 6] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[6, 5, 5] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[6, 5, 7] = {{I}}
 
repD10Cat1Brd6RMatrixFunction[6, 6, 0] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[6, 6, 2] = {{-1}}
 
repD10Cat1Brd6RMatrixFunction[6, 6, 4] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[6, 7, 1] = {{I}}
 
repD10Cat1Brd6RMatrixFunction[6, 7, 3] = {{I}}
 
repD10Cat1Brd6RMatrixFunction[6, 7, 5] = {{I}}
 
repD10Cat1Brd6RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[7, 1, 6] = {{I}}
 
repD10Cat1Brd6RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[7, 3, 6] = {{I}}
 
repD10Cat1Brd6RMatrixFunction[7, 4, 5] = {{-I}}
 
repD10Cat1Brd6RMatrixFunction[7, 4, 7] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[7, 5, 4] = {{I}}
 
repD10Cat1Brd6RMatrixFunction[7, 5, 6] = {{-I}}
 
repD10Cat1Brd6RMatrixFunction[7, 6, 1] = {{-I}}
 
repD10Cat1Brd6RMatrixFunction[7, 6, 3] = {{-I}}
 
repD10Cat1Brd6RMatrixFunction[7, 6, 5] = {{-I}}
 
repD10Cat1Brd6RMatrixFunction[7, 7, 0] = {{1}}
 
repD10Cat1Brd6RMatrixFunction[7, 7, 2] = {{-1}}
 
repD10Cat1Brd6RMatrixFunction[7, 7, 4] = {{-1}}
balancedCategories[repD10Cat1Brd7] ^= {repD10Cat1Bal13, repD10Cat1Bal14}
 
repD10Cat1Brd7 /: balancedCategory[repD10Cat1Brd7, 1] = repD10Cat1Bal13
 
repD10Cat1Brd7 /: balancedCategory[repD10Cat1Brd7, 2] = repD10Cat1Bal14
 
braidedCategory[repD10Cat1Brd7] ^= repD10Cat1Brd7
 
fusionCategory[repD10Cat1Brd7] ^= repD10Cat1
 
repD10Cat1Brd7 /: modularCategory[repD10Cat1Brd7, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat1Brd7 /: ribbonCategory[repD10Cat1Brd7, 1] = repD10Cat1Bal13
 
repD10Cat1Brd7 /: ribbonCategory[repD10Cat1Brd7, 2] = repD10Cat1Bal14
 
ring[repD10Cat1Brd7] ^= repD10
 
rMatrixFunction[repD10Cat1Brd7] ^= repD10Cat1Brd7RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD10Cat1]][braidedCategory[#1]] & )[
    repD10Cat1Brd7] ^= 7
braidedCategory[repD10Cat1Brd7RMatrixFunction] ^= repD10Cat1Brd7
 
fusionCategory[repD10Cat1Brd7RMatrixFunction] ^= repD10Cat1
 
rMatrixFunction[repD10Cat1Brd7RMatrixFunction] ^= 
   repD10Cat1Brd7RMatrixFunction
 
repD10Cat1Brd7RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[1, 1, 2] = {{-1}}
 
repD10Cat1Brd7RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[1, 3, 0] = {{-1}}
 
repD10Cat1Brd7RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[1, 5, 4] = {{-1}}
 
repD10Cat1Brd7RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat1Brd7RMatrixFunction[1, 7, 6] = {{-I}}
 
repD10Cat1Brd7RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[3, 1, 0] = {{-1}}
 
repD10Cat1Brd7RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[3, 3, 2] = {{-1}}
 
repD10Cat1Brd7RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[3, 5, 4] = {{-1}}
 
repD10Cat1Brd7RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat1Brd7RMatrixFunction[3, 7, 6] = {{-I}}
 
repD10Cat1Brd7RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[4, 4, 0] = {{(-1)^(4/5)}}
 
repD10Cat1Brd7RMatrixFunction[4, 4, 2] = {{-(-1)^(4/5)}}
 
repD10Cat1Brd7RMatrixFunction[4, 4, 6] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd7RMatrixFunction[4, 5, 1] = {{-(-1)^(3/10)}}
 
repD10Cat1Brd7RMatrixFunction[4, 5, 3] = {{-(-1)^(3/10)}}
 
repD10Cat1Brd7RMatrixFunction[4, 5, 7] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd7RMatrixFunction[4, 6, 4] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd7RMatrixFunction[4, 6, 6] = {{(-1)^(2/5)}}
 
repD10Cat1Brd7RMatrixFunction[4, 7, 5] = {{(-1)^(1/10)}}
 
repD10Cat1Brd7RMatrixFunction[4, 7, 7] = {{(-1)^(2/5)}}
 
repD10Cat1Brd7RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[5, 1, 4] = {{-1}}
 
repD10Cat1Brd7RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[5, 3, 4] = {{-1}}
 
repD10Cat1Brd7RMatrixFunction[5, 4, 1] = {{(-1)^(3/10)}}
 
repD10Cat1Brd7RMatrixFunction[5, 4, 3] = {{(-1)^(3/10)}}
 
repD10Cat1Brd7RMatrixFunction[5, 4, 7] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd7RMatrixFunction[5, 5, 0] = {{(-1)^(4/5)}}
 
repD10Cat1Brd7RMatrixFunction[5, 5, 2] = {{-(-1)^(4/5)}}
 
repD10Cat1Brd7RMatrixFunction[5, 5, 6] = {{(-1)^(1/5)}}
 
repD10Cat1Brd7RMatrixFunction[5, 6, 5] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd7RMatrixFunction[5, 6, 7] = {{-(-1)^(9/10)}}
 
repD10Cat1Brd7RMatrixFunction[5, 7, 4] = {{-(-1)^(1/10)}}
 
repD10Cat1Brd7RMatrixFunction[5, 7, 6] = {{(-1)^(9/10)}}
 
repD10Cat1Brd7RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat1Brd7RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat1Brd7RMatrixFunction[6, 4, 4] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd7RMatrixFunction[6, 4, 6] = {{(-1)^(2/5)}}
 
repD10Cat1Brd7RMatrixFunction[6, 5, 5] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd7RMatrixFunction[6, 5, 7] = {{(-1)^(9/10)}}
 
repD10Cat1Brd7RMatrixFunction[6, 6, 0] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd7RMatrixFunction[6, 6, 2] = {{(-1)^(1/5)}}
 
repD10Cat1Brd7RMatrixFunction[6, 6, 4] = {{(-1)^(4/5)}}
 
repD10Cat1Brd7RMatrixFunction[6, 7, 1] = {{-(-1)^(7/10)}}
 
repD10Cat1Brd7RMatrixFunction[6, 7, 3] = {{-(-1)^(7/10)}}
 
repD10Cat1Brd7RMatrixFunction[6, 7, 5] = {{-(-1)^(3/10)}}
 
repD10Cat1Brd7RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[7, 1, 6] = {{I}}
 
repD10Cat1Brd7RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat1Brd7RMatrixFunction[7, 3, 6] = {{I}}
 
repD10Cat1Brd7RMatrixFunction[7, 4, 5] = {{-(-1)^(1/10)}}
 
repD10Cat1Brd7RMatrixFunction[7, 4, 7] = {{(-1)^(2/5)}}
 
repD10Cat1Brd7RMatrixFunction[7, 5, 4] = {{(-1)^(1/10)}}
 
repD10Cat1Brd7RMatrixFunction[7, 5, 6] = {{-(-1)^(9/10)}}
 
repD10Cat1Brd7RMatrixFunction[7, 6, 1] = {{(-1)^(7/10)}}
 
repD10Cat1Brd7RMatrixFunction[7, 6, 3] = {{(-1)^(7/10)}}
 
repD10Cat1Brd7RMatrixFunction[7, 6, 5] = {{(-1)^(3/10)}}
 
repD10Cat1Brd7RMatrixFunction[7, 7, 0] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd7RMatrixFunction[7, 7, 2] = {{(-1)^(1/5)}}
 
repD10Cat1Brd7RMatrixFunction[7, 7, 4] = {{-(-1)^(4/5)}}
balancedCategories[repD10Cat1Brd8] ^= {repD10Cat1Bal15, repD10Cat1Bal16}
 
repD10Cat1Brd8 /: balancedCategory[repD10Cat1Brd8, 1] = repD10Cat1Bal15
 
repD10Cat1Brd8 /: balancedCategory[repD10Cat1Brd8, 2] = repD10Cat1Bal16
 
braidedCategory[repD10Cat1Brd8] ^= repD10Cat1Brd8
 
fusionCategory[repD10Cat1Brd8] ^= repD10Cat1
 
repD10Cat1Brd8 /: modularCategory[repD10Cat1Brd8, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat1Brd8 /: ribbonCategory[repD10Cat1Brd8, 1] = repD10Cat1Bal15
 
repD10Cat1Brd8 /: ribbonCategory[repD10Cat1Brd8, 2] = repD10Cat1Bal16
 
ring[repD10Cat1Brd8] ^= repD10
 
rMatrixFunction[repD10Cat1Brd8] ^= repD10Cat1Brd8RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD10Cat1]][braidedCategory[#1]] & )[
    repD10Cat1Brd8] ^= 8
braidedCategory[repD10Cat1Brd8RMatrixFunction] ^= repD10Cat1Brd8
 
fusionCategory[repD10Cat1Brd8RMatrixFunction] ^= repD10Cat1
 
rMatrixFunction[repD10Cat1Brd8RMatrixFunction] ^= 
   repD10Cat1Brd8RMatrixFunction
 
repD10Cat1Brd8RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[1, 1, 2] = {{-1}}
 
repD10Cat1Brd8RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[1, 3, 0] = {{-1}}
 
repD10Cat1Brd8RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[1, 5, 4] = {{-1}}
 
repD10Cat1Brd8RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat1Brd8RMatrixFunction[1, 7, 6] = {{-I}}
 
repD10Cat1Brd8RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[3, 1, 0] = {{-1}}
 
repD10Cat1Brd8RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[3, 3, 2] = {{-1}}
 
repD10Cat1Brd8RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[3, 5, 4] = {{-1}}
 
repD10Cat1Brd8RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat1Brd8RMatrixFunction[3, 7, 6] = {{-I}}
 
repD10Cat1Brd8RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[4, 4, 0] = {{(-1)^(2/5)}}
 
repD10Cat1Brd8RMatrixFunction[4, 4, 2] = {{-(-1)^(2/5)}}
 
repD10Cat1Brd8RMatrixFunction[4, 4, 6] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd8RMatrixFunction[4, 5, 1] = {{(-1)^(9/10)}}
 
repD10Cat1Brd8RMatrixFunction[4, 5, 3] = {{(-1)^(9/10)}}
 
repD10Cat1Brd8RMatrixFunction[4, 5, 7] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd8RMatrixFunction[4, 6, 4] = {{(-1)^(4/5)}}
 
repD10Cat1Brd8RMatrixFunction[4, 6, 6] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd8RMatrixFunction[4, 7, 5] = {{-(-1)^(3/10)}}
 
repD10Cat1Brd8RMatrixFunction[4, 7, 7] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd8RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[5, 1, 4] = {{-1}}
 
repD10Cat1Brd8RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[5, 3, 4] = {{-1}}
 
repD10Cat1Brd8RMatrixFunction[5, 4, 1] = {{-(-1)^(9/10)}}
 
repD10Cat1Brd8RMatrixFunction[5, 4, 3] = {{-(-1)^(9/10)}}
 
repD10Cat1Brd8RMatrixFunction[5, 4, 7] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd8RMatrixFunction[5, 5, 0] = {{(-1)^(2/5)}}
 
repD10Cat1Brd8RMatrixFunction[5, 5, 2] = {{-(-1)^(2/5)}}
 
repD10Cat1Brd8RMatrixFunction[5, 5, 6] = {{(-1)^(3/5)}}
 
repD10Cat1Brd8RMatrixFunction[5, 6, 5] = {{(-1)^(4/5)}}
 
repD10Cat1Brd8RMatrixFunction[5, 6, 7] = {{(-1)^(7/10)}}
 
repD10Cat1Brd8RMatrixFunction[5, 7, 4] = {{(-1)^(3/10)}}
 
repD10Cat1Brd8RMatrixFunction[5, 7, 6] = {{-(-1)^(7/10)}}
 
repD10Cat1Brd8RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat1Brd8RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat1Brd8RMatrixFunction[6, 4, 4] = {{(-1)^(4/5)}}
 
repD10Cat1Brd8RMatrixFunction[6, 4, 6] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd8RMatrixFunction[6, 5, 5] = {{(-1)^(4/5)}}
 
repD10Cat1Brd8RMatrixFunction[6, 5, 7] = {{-(-1)^(7/10)}}
 
repD10Cat1Brd8RMatrixFunction[6, 6, 0] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd8RMatrixFunction[6, 6, 2] = {{(-1)^(3/5)}}
 
repD10Cat1Brd8RMatrixFunction[6, 6, 4] = {{(-1)^(2/5)}}
 
repD10Cat1Brd8RMatrixFunction[6, 7, 1] = {{(-1)^(1/10)}}
 
repD10Cat1Brd8RMatrixFunction[6, 7, 3] = {{(-1)^(1/10)}}
 
repD10Cat1Brd8RMatrixFunction[6, 7, 5] = {{(-1)^(9/10)}}
 
repD10Cat1Brd8RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[7, 1, 6] = {{I}}
 
repD10Cat1Brd8RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat1Brd8RMatrixFunction[7, 3, 6] = {{I}}
 
repD10Cat1Brd8RMatrixFunction[7, 4, 5] = {{(-1)^(3/10)}}
 
repD10Cat1Brd8RMatrixFunction[7, 4, 7] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd8RMatrixFunction[7, 5, 4] = {{-(-1)^(3/10)}}
 
repD10Cat1Brd8RMatrixFunction[7, 5, 6] = {{(-1)^(7/10)}}
 
repD10Cat1Brd8RMatrixFunction[7, 6, 1] = {{-(-1)^(1/10)}}
 
repD10Cat1Brd8RMatrixFunction[7, 6, 3] = {{-(-1)^(1/10)}}
 
repD10Cat1Brd8RMatrixFunction[7, 6, 5] = {{-(-1)^(9/10)}}
 
repD10Cat1Brd8RMatrixFunction[7, 7, 0] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd8RMatrixFunction[7, 7, 2] = {{(-1)^(3/5)}}
 
repD10Cat1Brd8RMatrixFunction[7, 7, 4] = {{-(-1)^(2/5)}}
balancedCategories[repD10Cat1Brd9] ^= {repD10Cat1Bal17, repD10Cat1Bal18}
 
repD10Cat1Brd9 /: balancedCategory[repD10Cat1Brd9, 1] = repD10Cat1Bal17
 
repD10Cat1Brd9 /: balancedCategory[repD10Cat1Brd9, 2] = repD10Cat1Bal18
 
braidedCategory[repD10Cat1Brd9] ^= repD10Cat1Brd9
 
fusionCategory[repD10Cat1Brd9] ^= repD10Cat1
 
repD10Cat1Brd9 /: modularCategory[repD10Cat1Brd9, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat1Brd9 /: ribbonCategory[repD10Cat1Brd9, 1] = repD10Cat1Bal17
 
repD10Cat1Brd9 /: ribbonCategory[repD10Cat1Brd9, 2] = repD10Cat1Bal18
 
ring[repD10Cat1Brd9] ^= repD10
 
rMatrixFunction[repD10Cat1Brd9] ^= repD10Cat1Brd9RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD10Cat1]][braidedCategory[#1]] & )[
    repD10Cat1Brd9] ^= 9
braidedCategory[repD10Cat1Brd9RMatrixFunction] ^= repD10Cat1Brd9
 
fusionCategory[repD10Cat1Brd9RMatrixFunction] ^= repD10Cat1
 
rMatrixFunction[repD10Cat1Brd9RMatrixFunction] ^= 
   repD10Cat1Brd9RMatrixFunction
 
repD10Cat1Brd9RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[1, 1, 2] = {{-1}}
 
repD10Cat1Brd9RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[1, 3, 0] = {{-1}}
 
repD10Cat1Brd9RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[1, 5, 4] = {{-1}}
 
repD10Cat1Brd9RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat1Brd9RMatrixFunction[1, 7, 6] = {{-I}}
 
repD10Cat1Brd9RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[3, 1, 0] = {{-1}}
 
repD10Cat1Brd9RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[3, 3, 2] = {{-1}}
 
repD10Cat1Brd9RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[3, 5, 4] = {{-1}}
 
repD10Cat1Brd9RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat1Brd9RMatrixFunction[3, 7, 6] = {{-I}}
 
repD10Cat1Brd9RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[4, 4, 0] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd9RMatrixFunction[4, 4, 2] = {{(-1)^(3/5)}}
 
repD10Cat1Brd9RMatrixFunction[4, 4, 6] = {{(-1)^(2/5)}}
 
repD10Cat1Brd9RMatrixFunction[4, 5, 1] = {{(-1)^(1/10)}}
 
repD10Cat1Brd9RMatrixFunction[4, 5, 3] = {{(-1)^(1/10)}}
 
repD10Cat1Brd9RMatrixFunction[4, 5, 7] = {{(-1)^(2/5)}}
 
repD10Cat1Brd9RMatrixFunction[4, 6, 4] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd9RMatrixFunction[4, 6, 6] = {{(-1)^(4/5)}}
 
repD10Cat1Brd9RMatrixFunction[4, 7, 5] = {{-(-1)^(7/10)}}
 
repD10Cat1Brd9RMatrixFunction[4, 7, 7] = {{(-1)^(4/5)}}
 
repD10Cat1Brd9RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[5, 1, 4] = {{-1}}
 
repD10Cat1Brd9RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[5, 3, 4] = {{-1}}
 
repD10Cat1Brd9RMatrixFunction[5, 4, 1] = {{-(-1)^(1/10)}}
 
repD10Cat1Brd9RMatrixFunction[5, 4, 3] = {{-(-1)^(1/10)}}
 
repD10Cat1Brd9RMatrixFunction[5, 4, 7] = {{(-1)^(2/5)}}
 
repD10Cat1Brd9RMatrixFunction[5, 5, 0] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd9RMatrixFunction[5, 5, 2] = {{(-1)^(3/5)}}
 
repD10Cat1Brd9RMatrixFunction[5, 5, 6] = {{-(-1)^(2/5)}}
 
repD10Cat1Brd9RMatrixFunction[5, 6, 5] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd9RMatrixFunction[5, 6, 7] = {{(-1)^(3/10)}}
 
repD10Cat1Brd9RMatrixFunction[5, 7, 4] = {{(-1)^(7/10)}}
 
repD10Cat1Brd9RMatrixFunction[5, 7, 6] = {{-(-1)^(3/10)}}
 
repD10Cat1Brd9RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat1Brd9RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat1Brd9RMatrixFunction[6, 4, 4] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd9RMatrixFunction[6, 4, 6] = {{(-1)^(4/5)}}
 
repD10Cat1Brd9RMatrixFunction[6, 5, 5] = {{-(-1)^(1/5)}}
 
repD10Cat1Brd9RMatrixFunction[6, 5, 7] = {{-(-1)^(3/10)}}
 
repD10Cat1Brd9RMatrixFunction[6, 6, 0] = {{(-1)^(2/5)}}
 
repD10Cat1Brd9RMatrixFunction[6, 6, 2] = {{-(-1)^(2/5)}}
 
repD10Cat1Brd9RMatrixFunction[6, 6, 4] = {{-(-1)^(3/5)}}
 
repD10Cat1Brd9RMatrixFunction[6, 7, 1] = {{(-1)^(9/10)}}
 
repD10Cat1Brd9RMatrixFunction[6, 7, 3] = {{(-1)^(9/10)}}
 
repD10Cat1Brd9RMatrixFunction[6, 7, 5] = {{(-1)^(1/10)}}
 
repD10Cat1Brd9RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[7, 1, 6] = {{I}}
 
repD10Cat1Brd9RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat1Brd9RMatrixFunction[7, 3, 6] = {{I}}
 
repD10Cat1Brd9RMatrixFunction[7, 4, 5] = {{(-1)^(7/10)}}
 
repD10Cat1Brd9RMatrixFunction[7, 4, 7] = {{(-1)^(4/5)}}
 
repD10Cat1Brd9RMatrixFunction[7, 5, 4] = {{-(-1)^(7/10)}}
 
repD10Cat1Brd9RMatrixFunction[7, 5, 6] = {{(-1)^(3/10)}}
 
repD10Cat1Brd9RMatrixFunction[7, 6, 1] = {{-(-1)^(9/10)}}
 
repD10Cat1Brd9RMatrixFunction[7, 6, 3] = {{-(-1)^(9/10)}}
 
repD10Cat1Brd9RMatrixFunction[7, 6, 5] = 
   {{I*(1 - (-1)^(1/5) + (-1)^(2/5) + (-1)^(4/5))}}
 
repD10Cat1Brd9RMatrixFunction[7, 7, 0] = {{(-1)^(2/5)}}
 
repD10Cat1Brd9RMatrixFunction[7, 7, 2] = {{-(-1)^(2/5)}}
 
repD10Cat1Brd9RMatrixFunction[7, 7, 4] = 
   {{1 - (-1)^(1/5) + (-1)^(2/5) + (-1)^(4/5)}}
fMatrixFunction[repD10Cat1FMatrixFunction] ^= repD10Cat1FMatrixFunction
 
fusionCategory[repD10Cat1FMatrixFunction] ^= repD10Cat1
 
ring[repD10Cat1FMatrixFunction] ^= repD10
 
repD10Cat1FMatrixFunction[1, 4, 4, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 4, 4, 7] = {{-I}}
 
repD10Cat1FMatrixFunction[1, 4, 5, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 4, 5, 6] = {{-I}}
 
repD10Cat1FMatrixFunction[1, 4, 7, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 4, 7, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 5, 4, 0] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 5, 4, 6] = {{-I}}
 
repD10Cat1FMatrixFunction[1, 5, 5, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 5, 5, 7] = {{-I}}
 
repD10Cat1FMatrixFunction[1, 5, 6, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 5, 7, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 6, 1, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 6, 3, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 6, 4, 5] = {{I}}
 
repD10Cat1FMatrixFunction[1, 6, 5, 4] = {{-I}}
 
repD10Cat1FMatrixFunction[1, 6, 5, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 6, 6, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 6, 6, 5] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 6, 7, 0] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 7, 1, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 7, 3, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 7, 4, 4] = {{I}}
 
repD10Cat1FMatrixFunction[1, 7, 4, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 7, 5, 5] = {{-I}}
 
repD10Cat1FMatrixFunction[1, 7, 6, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 7, 6, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[1, 7, 7, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 4, 4, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 4, 5, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 4, 6, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 4, 7, 5] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 5, 4, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 5, 4, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 5, 5, 0] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 5, 5, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 5, 5, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 5, 6, 5] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 5, 7, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 6, 4, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 6, 4, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 6, 5, 5] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 6, 5, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 6, 6, 0] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 6, 6, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 6, 7, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 6, 7, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 7, 4, 5] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 7, 4, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 7, 5, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[2, 7, 5, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 4, 4, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 4, 4, 7] = {{I}}
 
repD10Cat1FMatrixFunction[3, 4, 5, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 4, 5, 6] = {{I}}
 
repD10Cat1FMatrixFunction[3, 4, 6, 5] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 4, 7, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 5, 4, 6] = {{I}}
 
repD10Cat1FMatrixFunction[3, 5, 5, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 5, 5, 7] = {{I}}
 
repD10Cat1FMatrixFunction[3, 5, 7, 5] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 5, 7, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 6, 1, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 6, 3, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 6, 4, 5] = {{-I}}
 
repD10Cat1FMatrixFunction[3, 6, 4, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 6, 5, 4] = {{I}}
 
repD10Cat1FMatrixFunction[3, 6, 6, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 6, 6, 5] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 6, 7, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 7, 1, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 7, 3, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 7, 4, 4] = {{-I}}
 
repD10Cat1FMatrixFunction[3, 7, 5, 5] = {{I}}
 
repD10Cat1FMatrixFunction[3, 7, 5, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 7, 6, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 7, 6, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[3, 7, 7, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 1, 4, 1] = {{I}}
 
repD10Cat1FMatrixFunction[4, 1, 4, 3] = {{-I}}
 
repD10Cat1FMatrixFunction[4, 1, 5, 0] = {{I}}
 
repD10Cat1FMatrixFunction[4, 1, 5, 2] = {{-I}}
 
repD10Cat1FMatrixFunction[4, 2, 4, 0] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 2, 4, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 2, 5, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 2, 5, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 2, 6, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 2, 7, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 3, 4, 1] = {{-I}}
 
repD10Cat1FMatrixFunction[4, 3, 4, 3] = {{I}}
 
repD10Cat1FMatrixFunction[4, 3, 5, 0] = {{-I}}
 
repD10Cat1FMatrixFunction[4, 3, 5, 2] = {{I}}
 
repD10Cat1FMatrixFunction[4, 3, 6, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 3, 7, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 4, 1, 1] = {{I}}
 
repD10Cat1FMatrixFunction[4, 4, 1, 3] = {{I}}
 
repD10Cat1FMatrixFunction[4, 4, 2, 0] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 4, 2, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 4, 2, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 4, 3, 1] = {{-I}}
 
repD10Cat1FMatrixFunction[4, 4, 3, 3] = {{-I}}
 
repD10Cat1FMatrixFunction[4, 4, 3, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 4, 4, 4] = {{1/2, 1/2, -(1/Sqrt[2])}, 
    {-1/2, -1/2, -(1/Sqrt[2])}, {-(1/Sqrt[2]), 1/Sqrt[2], 0}}
 
repD10Cat1FMatrixFunction[4, 4, 5, 5] = {{I/2, I/2, (-I)/Sqrt[2]}, 
    {-I/2, -I/2, (-I)/Sqrt[2]}, {(-I)/Sqrt[2], I/Sqrt[2], 0}}
 
repD10Cat1FMatrixFunction[4, 4, 6, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
repD10Cat1FMatrixFunction[4, 4, 7, 5] = {{I}}
 
repD10Cat1FMatrixFunction[4, 4, 7, 7] = {{(-I)/Sqrt[2], I/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
repD10Cat1FMatrixFunction[4, 5, 1, 0] = {{I}}
 
repD10Cat1FMatrixFunction[4, 5, 1, 2] = {{I}}
 
repD10Cat1FMatrixFunction[4, 5, 1, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 5, 2, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 5, 2, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 5, 2, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 5, 3, 0] = {{-I}}
 
repD10Cat1FMatrixFunction[4, 5, 3, 2] = {{-I}}
 
repD10Cat1FMatrixFunction[4, 5, 4, 5] = {{-I/2, -I/2, -(1/Sqrt[2])}, 
    {-I/2, -I/2, 1/Sqrt[2]}, {-(1/Sqrt[2]), 1/Sqrt[2], 0}}
 
repD10Cat1FMatrixFunction[4, 5, 5, 4] = {{-1/2, -1/2, I/Sqrt[2]}, 
    {-1/2, -1/2, (-I)/Sqrt[2]}, {I/Sqrt[2], (-I)/Sqrt[2], 0}}
 
repD10Cat1FMatrixFunction[4, 5, 6, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 5, 6, 5] = {{I}}
 
repD10Cat1FMatrixFunction[4, 5, 6, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {I/Sqrt[2], I/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[4, 5, 7, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 5, 7, 6] = {{I/Sqrt[2], (-I)/Sqrt[2]}, 
    {I/Sqrt[2], I/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[4, 6, 1, 5] = {{I}}
 
repD10Cat1FMatrixFunction[4, 6, 2, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 6, 2, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 6, 3, 5] = {{-I}}
 
repD10Cat1FMatrixFunction[4, 6, 3, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 6, 4, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 6, 4, 6] = {{0, 1}, {1, 0}}
 
repD10Cat1FMatrixFunction[4, 6, 5, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 6, 5, 5] = {{I}}
 
repD10Cat1FMatrixFunction[4, 6, 5, 7] = {{0, 1}, {1, 0}}
 
repD10Cat1FMatrixFunction[4, 6, 6, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 6, 6, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repD10Cat1FMatrixFunction[4, 6, 7, 1] = {{-I}}
 
repD10Cat1FMatrixFunction[4, 6, 7, 3] = {{I}}
 
repD10Cat1FMatrixFunction[4, 6, 7, 5] = {{(-I)/Sqrt[2], 1/Sqrt[2]}, 
    {I/Sqrt[2], 1/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[4, 7, 1, 4] = {{I}}
 
repD10Cat1FMatrixFunction[4, 7, 1, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 7, 2, 5] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 7, 2, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[4, 7, 3, 4] = {{-I}}
 
repD10Cat1FMatrixFunction[4, 7, 4, 5] = {{I}}
 
repD10Cat1FMatrixFunction[4, 7, 4, 7] = {{0, 1}, {-I, 0}}
 
repD10Cat1FMatrixFunction[4, 7, 5, 6] = {{0, 1}, {-I, 0}}
 
repD10Cat1FMatrixFunction[4, 7, 6, 1] = {{-I}}
 
repD10Cat1FMatrixFunction[4, 7, 6, 3] = {{-I}}
 
repD10Cat1FMatrixFunction[4, 7, 6, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
repD10Cat1FMatrixFunction[4, 7, 6, 7] = {{-I}}
 
repD10Cat1FMatrixFunction[4, 7, 7, 4] = {{I/Sqrt[2], -(1/Sqrt[2])}, 
    {I/Sqrt[2], 1/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[4, 7, 7, 6] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 1, 4, 0] = {{I}}
 
repD10Cat1FMatrixFunction[5, 1, 4, 2] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 1, 5, 1] = {{I}}
 
repD10Cat1FMatrixFunction[5, 1, 5, 3] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 1, 6, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 1, 7, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 2, 4, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 2, 4, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 2, 5, 0] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 2, 5, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 2, 6, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 2, 7, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 3, 4, 0] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 3, 4, 2] = {{I}}
 
repD10Cat1FMatrixFunction[5, 3, 5, 1] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 3, 5, 3] = {{I}}
 
repD10Cat1FMatrixFunction[5, 4, 1, 0] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 4, 1, 2] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 4, 1, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 4, 2, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 4, 3, 0] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 4, 3, 2] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 4, 4, 5] = {{1/2, -1/2, -(1/Sqrt[2])}, 
    {-1/2, 1/2, -(1/Sqrt[2])}, {-(1/Sqrt[2]), -(1/Sqrt[2]), 0}}
 
repD10Cat1FMatrixFunction[5, 4, 4, 7] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 4, 5, 4] = {{I/2, -I/2, I/Sqrt[2]}, 
    {-I/2, I/2, I/Sqrt[2]}, {I/Sqrt[2], I/Sqrt[2], 0}}
 
repD10Cat1FMatrixFunction[5, 4, 5, 6] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 4, 6, 1] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 4, 6, 3] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 4, 6, 5] = {{I}}
 
repD10Cat1FMatrixFunction[5, 4, 6, 7] = {{(-I)/Sqrt[2], (-I)/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[5, 4, 7, 0] = {{I}}
 
repD10Cat1FMatrixFunction[5, 4, 7, 2] = {{I}}
 
repD10Cat1FMatrixFunction[5, 4, 7, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 4, 7, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repD10Cat1FMatrixFunction[5, 5, 1, 1] = {{I}}
 
repD10Cat1FMatrixFunction[5, 5, 1, 3] = {{I}}
 
repD10Cat1FMatrixFunction[5, 5, 2, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 5, 3, 1] = {{I}}
 
repD10Cat1FMatrixFunction[5, 5, 3, 3] = {{I}}
 
repD10Cat1FMatrixFunction[5, 5, 3, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 5, 4, 4] = {{-I/2, I/2, -(1/Sqrt[2])}, 
    {-I/2, I/2, 1/Sqrt[2]}, {-(1/Sqrt[2]), -(1/Sqrt[2]), 0}}
 
repD10Cat1FMatrixFunction[5, 5, 4, 6] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 5, 5, 5] = {{-1/2, 1/2, (-I)/Sqrt[2]}, 
    {-1/2, 1/2, I/Sqrt[2]}, {(-I)/Sqrt[2], (-I)/Sqrt[2], 0}}
 
repD10Cat1FMatrixFunction[5, 5, 5, 7] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 5, 6, 0] = {{I}}
 
repD10Cat1FMatrixFunction[5, 5, 6, 2] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 5, 6, 6] = {{I/Sqrt[2], I/Sqrt[2]}, 
    {(-I)/Sqrt[2], I/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[5, 5, 7, 1] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 5, 7, 3] = {{I}}
 
repD10Cat1FMatrixFunction[5, 5, 7, 5] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 5, 7, 7] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {I/Sqrt[2], (-I)/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[5, 6, 1, 4] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 6, 2, 5] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 6, 2, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 6, 3, 4] = {{I}}
 
repD10Cat1FMatrixFunction[5, 6, 3, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 6, 4, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 6, 4, 5] = {{I}}
 
repD10Cat1FMatrixFunction[5, 6, 4, 7] = {{0, I}, {-I, 0}}
 
repD10Cat1FMatrixFunction[5, 6, 5, 0] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 6, 5, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 6, 5, 6] = {{0, -I}, {I, 0}}
 
repD10Cat1FMatrixFunction[5, 6, 6, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 6, 6, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[5, 6, 6, 7] = {{I}}
 
repD10Cat1FMatrixFunction[5, 6, 7, 0] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 6, 7, 2] = {{I}}
 
repD10Cat1FMatrixFunction[5, 6, 7, 4] = {{I/Sqrt[2], 1/Sqrt[2]}, 
    {(-I)/Sqrt[2], 1/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[5, 6, 7, 6] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 7, 1, 5] = {{-I}}
 
repD10Cat1FMatrixFunction[5, 7, 1, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 7, 2, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 7, 2, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 7, 3, 5] = {{I}}
 
repD10Cat1FMatrixFunction[5, 7, 4, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 7, 4, 6] = {{0, I}, {-1, 0}}
 
repD10Cat1FMatrixFunction[5, 7, 5, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 7, 5, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 7, 5, 5] = {{I}}
 
repD10Cat1FMatrixFunction[5, 7, 5, 7] = {{0, -I}, {1, 0}}
 
repD10Cat1FMatrixFunction[5, 7, 6, 0] = {{I}}
 
repD10Cat1FMatrixFunction[5, 7, 6, 2] = {{I}}
 
repD10Cat1FMatrixFunction[5, 7, 6, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
repD10Cat1FMatrixFunction[5, 7, 6, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 7, 7, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 7, 7, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[5, 7, 7, 5] = {{(-I)/Sqrt[2], 1/Sqrt[2]}, 
    {(-I)/Sqrt[2], -(1/Sqrt[2])}}
 
repD10Cat1FMatrixFunction[6, 1, 6, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 1, 7, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 2, 4, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 2, 5, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 2, 6, 0] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 2, 6, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 2, 7, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 2, 7, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 3, 4, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 3, 5, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 3, 6, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 3, 7, 0] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 4, 2, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 4, 3, 5] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 4, 4, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[6, 4, 5, 1] = {{I}}
 
repD10Cat1FMatrixFunction[6, 4, 5, 3] = {{I}}
 
repD10Cat1FMatrixFunction[6, 4, 5, 7] = {{(-I)/Sqrt[2], (-I)/Sqrt[2]}, 
    {(-I)/Sqrt[2], I/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[6, 4, 6, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 4, 6, 4] = {{0, 1}, {1, 0}}
 
repD10Cat1FMatrixFunction[6, 4, 7, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 4, 7, 5] = {{0, I}, {-I, 0}}
 
repD10Cat1FMatrixFunction[6, 4, 7, 7] = {{I}}
 
repD10Cat1FMatrixFunction[6, 5, 1, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 5, 2, 5] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 5, 4, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 5, 4, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repD10Cat1FMatrixFunction[6, 5, 5, 0] = {{I}}
 
repD10Cat1FMatrixFunction[6, 5, 5, 2] = {{-I}}
 
repD10Cat1FMatrixFunction[6, 5, 5, 6] = {{I/Sqrt[2], I/Sqrt[2]}, 
    {(-I)/Sqrt[2], I/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[6, 5, 6, 5] = {{0, I}, {-I, 0}}
 
repD10Cat1FMatrixFunction[6, 5, 6, 7] = {{I}}
 
repD10Cat1FMatrixFunction[6, 5, 7, 4] = {{0, 1}, {1, 0}}
 
repD10Cat1FMatrixFunction[6, 6, 1, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 6, 1, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 6, 3, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 6, 3, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 6, 4, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 6, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[6, 6, 5, 1] = {{I}}
 
repD10Cat1FMatrixFunction[6, 6, 5, 3] = {{-I}}
 
repD10Cat1FMatrixFunction[6, 6, 5, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[6, 6, 6, 6] = {{1/2, -1/2, -(1/Sqrt[2])}, 
    {1/2, -1/2, 1/Sqrt[2]}, {-(1/Sqrt[2]), -(1/Sqrt[2]), 0}}
 
repD10Cat1FMatrixFunction[6, 6, 7, 5] = {{-I}}
 
repD10Cat1FMatrixFunction[6, 6, 7, 7] = {{-1/2, 1/2, 1/Sqrt[2]}, 
    {-1/2, 1/2, -(1/Sqrt[2])}, {-(1/Sqrt[2]), -(1/Sqrt[2]), 0}}
 
repD10Cat1FMatrixFunction[6, 7, 1, 0] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 7, 1, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 7, 3, 0] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 7, 3, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 7, 4, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 7, 4, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[6, 7, 4, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repD10Cat1FMatrixFunction[6, 7, 5, 0] = {{I}}
 
repD10Cat1FMatrixFunction[6, 7, 5, 2] = {{I}}
 
repD10Cat1FMatrixFunction[6, 7, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repD10Cat1FMatrixFunction[6, 7, 6, 5] = {{-I}}
 
repD10Cat1FMatrixFunction[6, 7, 6, 7] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {-1/2, 1/2, 1/Sqrt[2]}, {1/Sqrt[2], 1/Sqrt[2], 0}}
 
repD10Cat1FMatrixFunction[6, 7, 7, 6] = {{-1/2, 1/2, -(1/Sqrt[2])}, 
    {1/2, -1/2, -(1/Sqrt[2])}, {1/Sqrt[2], 1/Sqrt[2], 0}}
 
repD10Cat1FMatrixFunction[7, 1, 4, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 1, 5, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 1, 6, 0] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 1, 7, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 2, 4, 7] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 2, 5, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 2, 6, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 2, 6, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 2, 7, 0] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 2, 7, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 3, 6, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 3, 7, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 4, 1, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 4, 2, 5] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 4, 4, 1] = {{I}}
 
repD10Cat1FMatrixFunction[7, 4, 4, 3] = {{I}}
 
repD10Cat1FMatrixFunction[7, 4, 4, 5] = {{-I}}
 
repD10Cat1FMatrixFunction[7, 4, 4, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[7, 4, 5, 4] = {{-I}}
 
repD10Cat1FMatrixFunction[7, 4, 5, 6] = {{I/Sqrt[2], (-I)/Sqrt[2]}, 
    {I/Sqrt[2], I/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[7, 4, 6, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 4, 6, 5] = {{0, I}, {-I, 0}}
 
repD10Cat1FMatrixFunction[7, 4, 6, 7] = {{I}}
 
repD10Cat1FMatrixFunction[7, 4, 7, 0] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 4, 7, 4] = {{0, -1}, {-1, 0}}
 
repD10Cat1FMatrixFunction[7, 4, 7, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 5, 2, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 5, 3, 5] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 5, 4, 0] = {{-I}}
 
repD10Cat1FMatrixFunction[7, 5, 4, 2] = {{I}}
 
repD10Cat1FMatrixFunction[7, 5, 4, 4] = {{-I}}
 
repD10Cat1FMatrixFunction[7, 5, 4, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[7, 5, 5, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 5, 5, 5] = {{-I}}
 
repD10Cat1FMatrixFunction[7, 5, 5, 7] = {{(-I)/Sqrt[2], (-I)/Sqrt[2]}, 
    {I/Sqrt[2], (-I)/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[7, 5, 6, 4] = {{0, -1}, {1, 0}}
 
repD10Cat1FMatrixFunction[7, 5, 6, 6] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 5, 7, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 5, 7, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 5, 7, 5] = {{0, I}, {I, 0}}
 
repD10Cat1FMatrixFunction[7, 5, 7, 7] = {{I}}
 
repD10Cat1FMatrixFunction[7, 6, 1, 0] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 6, 1, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 6, 1, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 6, 2, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 6, 2, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 6, 3, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 6, 4, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 6, 4, 5] = {{I/Sqrt[2], (-I)/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[7, 6, 4, 7] = {{I}}
 
repD10Cat1FMatrixFunction[7, 6, 5, 0] = {{-I}}
 
repD10Cat1FMatrixFunction[7, 6, 5, 2] = {{I}}
 
repD10Cat1FMatrixFunction[7, 6, 5, 4] = {{(-I)/Sqrt[2], I/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
repD10Cat1FMatrixFunction[7, 6, 5, 6] = {{-I}}
 
repD10Cat1FMatrixFunction[7, 6, 6, 5] = {{I}}
 
repD10Cat1FMatrixFunction[7, 6, 6, 7] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {-(1/Sqrt[2]), 1/Sqrt[2], 0}}
 
repD10Cat1FMatrixFunction[7, 6, 7, 6] = {{1/2, 1/2, -(1/Sqrt[2])}, 
    {1/2, 1/2, 1/Sqrt[2]}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
repD10Cat1FMatrixFunction[7, 7, 1, 5] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 7, 2, 0] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 7, 2, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 7, 3, 1] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 7, 3, 3] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 7, 3, 5] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 7, 4, 0] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 7, 4, 2] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 7, 4, 4] = {{(-I)/Sqrt[2], I/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
repD10Cat1FMatrixFunction[7, 7, 4, 6] = {{I}}
 
repD10Cat1FMatrixFunction[7, 7, 5, 1] = {{I}}
 
repD10Cat1FMatrixFunction[7, 7, 5, 3] = {{I}}
 
repD10Cat1FMatrixFunction[7, 7, 5, 5] = {{I/Sqrt[2], (-I)/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
repD10Cat1FMatrixFunction[7, 7, 5, 7] = {{-I}}
 
repD10Cat1FMatrixFunction[7, 7, 6, 4] = {{-1}}
 
repD10Cat1FMatrixFunction[7, 7, 6, 6] = {{-1/2, -1/2, -(1/Sqrt[2])}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
repD10Cat1FMatrixFunction[7, 7, 7, 5] = {{-I}}
 
repD10Cat1FMatrixFunction[7, 7, 7, 7] = {{-1/2, -1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, 1/Sqrt[2]}, {-(1/Sqrt[2]), 1/Sqrt[2], 0}}
 
repD10Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repD10Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
repD10Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repD10Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[repD10Cat1Piv1] ^= {repD10Cat1Bal1, repD10Cat1Bal3, 
    repD10Cat1Bal5, repD10Cat1Bal7, repD10Cat1Bal9, repD10Cat1Bal11, 
    repD10Cat1Bal13, repD10Cat1Bal15, repD10Cat1Bal17, repD10Cat1Bal19}
 
repD10Cat1Piv1 /: balancedCategory[repD10Cat1Piv1, 1] = repD10Cat1Bal1
 
repD10Cat1Piv1 /: balancedCategory[repD10Cat1Piv1, 2] = repD10Cat1Bal3
 
repD10Cat1Piv1 /: balancedCategory[repD10Cat1Piv1, 3] = repD10Cat1Bal5
 
repD10Cat1Piv1 /: balancedCategory[repD10Cat1Piv1, 4] = repD10Cat1Bal7
 
repD10Cat1Piv1 /: balancedCategory[repD10Cat1Piv1, 5] = repD10Cat1Bal9
 
repD10Cat1Piv1 /: balancedCategory[repD10Cat1Piv1, 6] = repD10Cat1Bal11
 
repD10Cat1Piv1 /: balancedCategory[repD10Cat1Piv1, 7] = repD10Cat1Bal13
 
repD10Cat1Piv1 /: balancedCategory[repD10Cat1Piv1, 8] = repD10Cat1Bal15
 
repD10Cat1Piv1 /: balancedCategory[repD10Cat1Piv1, 9] = repD10Cat1Bal17
 
repD10Cat1Piv1 /: balancedCategory[repD10Cat1Piv1, 10] = repD10Cat1Bal19
 
fusionCategory[repD10Cat1Piv1] ^= repD10Cat1
 
repD10Cat1Piv1 /: modularCategory[repD10Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repD10Cat1Piv1] ^= repD10Cat1Piv1
 
pivotalIsomorphism[repD10Cat1Piv1] ^= repD10Cat1Piv1PivotalIsomorphism
 
repD10Cat1Piv1 /: ribbonCategory[repD10Cat1Piv1, 1] = repD10Cat1Bal1
 
repD10Cat1Piv1 /: ribbonCategory[repD10Cat1Piv1, 2] = repD10Cat1Bal3
 
repD10Cat1Piv1 /: ribbonCategory[repD10Cat1Piv1, 3] = repD10Cat1Bal5
 
repD10Cat1Piv1 /: ribbonCategory[repD10Cat1Piv1, 4] = repD10Cat1Bal7
 
repD10Cat1Piv1 /: ribbonCategory[repD10Cat1Piv1, 5] = repD10Cat1Bal9
 
repD10Cat1Piv1 /: ribbonCategory[repD10Cat1Piv1, 6] = repD10Cat1Bal11
 
repD10Cat1Piv1 /: ribbonCategory[repD10Cat1Piv1, 7] = repD10Cat1Bal13
 
repD10Cat1Piv1 /: ribbonCategory[repD10Cat1Piv1, 8] = repD10Cat1Bal15
 
repD10Cat1Piv1 /: ribbonCategory[repD10Cat1Piv1, 9] = repD10Cat1Bal17
 
repD10Cat1Piv1 /: ribbonCategory[repD10Cat1Piv1, 10] = repD10Cat1Bal19
 
ring[repD10Cat1Piv1] ^= repD10
 
sphericalCategory[repD10Cat1Piv1] ^= repD10Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[repD10Cat1]][pivotalCategory[#1]] & )[
    repD10Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[repD10Cat1]][
      sphericalCategory[#1]] & )[repD10Cat1Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[repD10Cat1Piv1PivotalIsomorphism] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Piv1PivotalIsomorphism] ^= repD10Cat1Piv1
 
pivotalIsomorphism[repD10Cat1Piv1PivotalIsomorphism] ^= 
   repD10Cat1Piv1PivotalIsomorphism
 
repD10Cat1Piv1PivotalIsomorphism[0] = 1
 
repD10Cat1Piv1PivotalIsomorphism[1] = 1
 
repD10Cat1Piv1PivotalIsomorphism[2] = 1
 
repD10Cat1Piv1PivotalIsomorphism[3] = 1
 
repD10Cat1Piv1PivotalIsomorphism[4] = 1
 
repD10Cat1Piv1PivotalIsomorphism[5] = -1
 
repD10Cat1Piv1PivotalIsomorphism[6] = 1
 
repD10Cat1Piv1PivotalIsomorphism[7] = -1
balancedCategories[repD10Cat1Piv2] ^= {repD10Cat1Bal2, repD10Cat1Bal4, 
    repD10Cat1Bal6, repD10Cat1Bal8, repD10Cat1Bal10, repD10Cat1Bal12, 
    repD10Cat1Bal14, repD10Cat1Bal16, repD10Cat1Bal18, repD10Cat1Bal20}
 
repD10Cat1Piv2 /: balancedCategory[repD10Cat1Piv2, 1] = repD10Cat1Bal2
 
repD10Cat1Piv2 /: balancedCategory[repD10Cat1Piv2, 2] = repD10Cat1Bal4
 
repD10Cat1Piv2 /: balancedCategory[repD10Cat1Piv2, 3] = repD10Cat1Bal6
 
repD10Cat1Piv2 /: balancedCategory[repD10Cat1Piv2, 4] = repD10Cat1Bal8
 
repD10Cat1Piv2 /: balancedCategory[repD10Cat1Piv2, 5] = repD10Cat1Bal10
 
repD10Cat1Piv2 /: balancedCategory[repD10Cat1Piv2, 6] = repD10Cat1Bal12
 
repD10Cat1Piv2 /: balancedCategory[repD10Cat1Piv2, 7] = repD10Cat1Bal14
 
repD10Cat1Piv2 /: balancedCategory[repD10Cat1Piv2, 8] = repD10Cat1Bal16
 
repD10Cat1Piv2 /: balancedCategory[repD10Cat1Piv2, 9] = repD10Cat1Bal18
 
repD10Cat1Piv2 /: balancedCategory[repD10Cat1Piv2, 10] = repD10Cat1Bal20
 
fusionCategory[repD10Cat1Piv2] ^= repD10Cat1
 
repD10Cat1Piv2 /: modularCategory[repD10Cat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repD10Cat1Piv2] ^= repD10Cat1Piv2
 
pivotalIsomorphism[repD10Cat1Piv2] ^= repD10Cat1Piv2PivotalIsomorphism
 
repD10Cat1Piv2 /: ribbonCategory[repD10Cat1Piv2, 1] = repD10Cat1Bal2
 
repD10Cat1Piv2 /: ribbonCategory[repD10Cat1Piv2, 2] = repD10Cat1Bal4
 
repD10Cat1Piv2 /: ribbonCategory[repD10Cat1Piv2, 3] = repD10Cat1Bal6
 
repD10Cat1Piv2 /: ribbonCategory[repD10Cat1Piv2, 4] = repD10Cat1Bal8
 
repD10Cat1Piv2 /: ribbonCategory[repD10Cat1Piv2, 5] = repD10Cat1Bal10
 
repD10Cat1Piv2 /: ribbonCategory[repD10Cat1Piv2, 6] = repD10Cat1Bal12
 
repD10Cat1Piv2 /: ribbonCategory[repD10Cat1Piv2, 7] = repD10Cat1Bal14
 
repD10Cat1Piv2 /: ribbonCategory[repD10Cat1Piv2, 8] = repD10Cat1Bal16
 
repD10Cat1Piv2 /: ribbonCategory[repD10Cat1Piv2, 9] = repD10Cat1Bal18
 
repD10Cat1Piv2 /: ribbonCategory[repD10Cat1Piv2, 10] = repD10Cat1Bal20
 
ring[repD10Cat1Piv2] ^= repD10
 
sphericalCategory[repD10Cat1Piv2] ^= repD10Cat1Piv2
 
(pivotalCategoryIndex[fusionCategory[repD10Cat1]][pivotalCategory[#1]] & )[
    repD10Cat1Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[repD10Cat1]][
      sphericalCategory[#1]] & )[repD10Cat1Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[repD10Cat1Piv2PivotalIsomorphism] ^= repD10Cat1
 
pivotalCategory[repD10Cat1Piv2PivotalIsomorphism] ^= repD10Cat1Piv2
 
pivotalIsomorphism[repD10Cat1Piv2PivotalIsomorphism] ^= 
   repD10Cat1Piv2PivotalIsomorphism
 
repD10Cat1Piv2PivotalIsomorphism[0] = 1
 
repD10Cat1Piv2PivotalIsomorphism[1] = -1
 
repD10Cat1Piv2PivotalIsomorphism[2] = 1
 
repD10Cat1Piv2PivotalIsomorphism[3] = -1
 
repD10Cat1Piv2PivotalIsomorphism[4] = 1
 
repD10Cat1Piv2PivotalIsomorphism[5] = 1
 
repD10Cat1Piv2PivotalIsomorphism[6] = 1
 
repD10Cat1Piv2PivotalIsomorphism[7] = 1
balancedCategories[repD10Cat2] ^= {}
 
braidedCategories[repD10Cat2] ^= {}
 
coeval[repD10Cat2] ^= 1/sixJFunction[repD10Cat2][#1, 
      dual[ring[repD10Cat2]][#1], #1, #1, 0, 0] & 
 
eval[repD10Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[repD10Cat2] ^= repD10Cat2FMatrixFunction
 
fusionCategory[repD10Cat2] ^= repD10Cat2
 
repD10Cat2 /: modularCategory[repD10Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[repD10Cat2] ^= {repD10Cat2Piv1, repD10Cat2Piv2}
 
repD10Cat2 /: pivotalCategory[repD10Cat2, 1] = repD10Cat2Piv1
 
repD10Cat2 /: pivotalCategory[repD10Cat2, 2] = repD10Cat2Piv2
 
repD10Cat2 /: pivotalCategory[repD10Cat2, {1, -1, 1, -1, 1, 1, 1, 1}] = 
    repD10Cat2Piv2
 
repD10Cat2 /: pivotalCategory[repD10Cat2, {1, 1, 1, 1, 1, -1, 1, -1}] = 
    repD10Cat2Piv1
 
ring[repD10Cat2] ^= repD10
 
repD10Cat2 /: sphericalCategory[repD10Cat2, 1] = repD10Cat2Piv1
 
repD10Cat2 /: sphericalCategory[repD10Cat2, 2] = repD10Cat2Piv2
 
fusionCategoryIndex[repD10][repD10Cat2] ^= 2
fMatrixFunction[repD10Cat2FMatrixFunction] ^= repD10Cat2FMatrixFunction
 
fusionCategory[repD10Cat2FMatrixFunction] ^= repD10Cat2
 
ring[repD10Cat2FMatrixFunction] ^= repD10
 
repD10Cat2FMatrixFunction[1, 4, 4, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[1, 4, 4, 7] = {{-(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[1, 4, 5, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[1, 4, 5, 6] = {{-(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[1, 4, 6, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[1, 4, 7, 4] = {{-1}}
 
repD10Cat2FMatrixFunction[1, 5, 4, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[1, 5, 4, 6] = {{-(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[1, 5, 5, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[1, 5, 5, 7] = {{-(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[1, 5, 6, 4] = {{-1}}
 
repD10Cat2FMatrixFunction[1, 5, 6, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[1, 6, 1, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[1, 6, 3, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[1, 6, 4, 5] = {{I}}
 
repD10Cat2FMatrixFunction[1, 6, 5, 4] = {{-I}}
 
repD10Cat2FMatrixFunction[1, 6, 5, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[1, 6, 6, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[1, 6, 6, 5] = {{(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[1, 6, 7, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[1, 6, 7, 4] = {{(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[1, 7, 1, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[1, 7, 3, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[1, 7, 4, 4] = {{I}}
 
repD10Cat2FMatrixFunction[1, 7, 4, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[1, 7, 5, 5] = {{-I}}
 
repD10Cat2FMatrixFunction[1, 7, 6, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[1, 7, 6, 4] = {{-(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[1, 7, 7, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[1, 7, 7, 5] = {{-(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[2, 4, 4, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 4, 5, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 4, 6, 4] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 4, 7, 5] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 5, 4, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 5, 4, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 5, 5, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 5, 5, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 5, 5, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 5, 6, 5] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 5, 7, 4] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 6, 4, 4] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 6, 4, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 6, 5, 5] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 6, 5, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 6, 6, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 6, 6, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 6, 7, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 6, 7, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 7, 4, 5] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 7, 4, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 7, 5, 4] = {{-1}}
 
repD10Cat2FMatrixFunction[2, 7, 5, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 4, 4, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 4, 4, 7] = {{(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[3, 4, 5, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 4, 5, 6] = {{(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[3, 4, 6, 5] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 4, 6, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 5, 4, 6] = {{(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[3, 5, 5, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 5, 5, 7] = {{(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[3, 5, 6, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 5, 7, 5] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 6, 1, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 6, 3, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 6, 4, 5] = {{-I}}
 
repD10Cat2FMatrixFunction[3, 6, 4, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 6, 5, 4] = {{I}}
 
repD10Cat2FMatrixFunction[3, 6, 6, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 6, 6, 5] = {{(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[3, 6, 7, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 6, 7, 4] = {{(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[3, 7, 1, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 7, 3, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 7, 4, 4] = {{-I}}
 
repD10Cat2FMatrixFunction[3, 7, 5, 5] = {{I}}
 
repD10Cat2FMatrixFunction[3, 7, 5, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 7, 6, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 7, 6, 4] = {{-(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[3, 7, 7, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[3, 7, 7, 5] = {{-(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[4, 1, 4, 1] = {{I}}
 
repD10Cat2FMatrixFunction[4, 1, 4, 3] = {{-I}}
 
repD10Cat2FMatrixFunction[4, 1, 5, 0] = {{I}}
 
repD10Cat2FMatrixFunction[4, 1, 5, 2] = {{-I}}
 
repD10Cat2FMatrixFunction[4, 2, 4, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 2, 4, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 2, 5, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 2, 5, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 2, 6, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 2, 7, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 3, 4, 1] = {{-I}}
 
repD10Cat2FMatrixFunction[4, 3, 4, 3] = {{I}}
 
repD10Cat2FMatrixFunction[4, 3, 5, 0] = {{-I}}
 
repD10Cat2FMatrixFunction[4, 3, 5, 2] = {{I}}
 
repD10Cat2FMatrixFunction[4, 3, 6, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 3, 7, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 4, 1, 1] = {{I}}
 
repD10Cat2FMatrixFunction[4, 4, 1, 3] = {{I}}
 
repD10Cat2FMatrixFunction[4, 4, 1, 7] = {{(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[4, 4, 2, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 4, 2, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 4, 2, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 4, 3, 1] = {{-I}}
 
repD10Cat2FMatrixFunction[4, 4, 3, 3] = {{-I}}
 
repD10Cat2FMatrixFunction[4, 4, 3, 7] = {{-(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[4, 4, 4, 4] = {{1/2, 1/2, -1/2}, 
    {-1/2, -1/2, -1/2}, {-1, 1, 0}}
 
repD10Cat2FMatrixFunction[4, 4, 4, 6] = {{(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[4, 4, 5, 5] = {{I/2, I/2, -I/2}, 
    {-I/2, -I/2, -I/2}, {-(-1)^(9/10), (-1)^(9/10), 0}}
 
repD10Cat2FMatrixFunction[4, 4, 5, 7] = {{-(-1)^(4/5)}}
 
repD10Cat2FMatrixFunction[4, 4, 6, 4] = {{-(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[4, 4, 6, 6] = {{-1, 1}, {-1/2, -1/2}}
 
repD10Cat2FMatrixFunction[4, 4, 7, 5] = {{I}}
 
repD10Cat2FMatrixFunction[4, 4, 7, 7] = {{-(-1)^(9/10), (-1)^(9/10)}, 
    {-1/2, -1/2}}
 
repD10Cat2FMatrixFunction[4, 5, 1, 0] = {{I}}
 
repD10Cat2FMatrixFunction[4, 5, 1, 2] = {{I}}
 
repD10Cat2FMatrixFunction[4, 5, 1, 6] = {{(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[4, 5, 2, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 5, 2, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 5, 2, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 5, 3, 0] = {{-I}}
 
repD10Cat2FMatrixFunction[4, 5, 3, 2] = {{-I}}
 
repD10Cat2FMatrixFunction[4, 5, 3, 6] = {{-(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[4, 5, 4, 5] = {{-I/2, -I/2, (-1)^(3/5)/2}, 
    {-I/2, -I/2, -(-1)^(3/5)/2}, {-(-1)^(2/5), (-1)^(2/5), 0}}
 
repD10Cat2FMatrixFunction[4, 5, 4, 7] = {{-(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[4, 5, 5, 4] = {{-1/2, -1/2, (-1)^(1/10)/2}, 
    {-1/2, -1/2, -(-1)^(1/10)/2}, {I, -I, 0}}
 
repD10Cat2FMatrixFunction[4, 5, 6, 1] = {{(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[4, 5, 6, 3] = {{-(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[4, 5, 6, 5] = {{(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[4, 5, 6, 7] = {{-(-1)^(2/5), (-1)^(2/5)}, 
    {I/2, I/2}}
 
repD10Cat2FMatrixFunction[4, 5, 7, 0] = {{(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[4, 5, 7, 2] = {{-(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[4, 5, 7, 4] = {{-(-1)^(1/5)}}
 
repD10Cat2FMatrixFunction[4, 5, 7, 6] = {{I, -I}, {I/2, I/2}}
 
repD10Cat2FMatrixFunction[4, 6, 1, 5] = {{I}}
 
repD10Cat2FMatrixFunction[4, 6, 2, 4] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 6, 2, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 6, 3, 5] = {{-I}}
 
repD10Cat2FMatrixFunction[4, 6, 3, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 6, 4, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 6, 4, 4] = {{(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[4, 6, 4, 6] = {{0, -2*(-1)^(3/5)}, 
    {-(-1)^(3/5)/2, 0}}
 
repD10Cat2FMatrixFunction[4, 6, 5, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 6, 5, 5] = {{-(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[4, 6, 5, 7] = {{0, -2}, {(-1)^(1/5)/2, 0}}
 
repD10Cat2FMatrixFunction[4, 6, 6, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 6, 6, 4] = {{-1/2, -1}, {1/2, -1}}
 
repD10Cat2FMatrixFunction[4, 6, 6, 6] = {{(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[4, 6, 7, 1] = {{-(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[4, 6, 7, 3] = {{(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[4, 6, 7, 5] = {{-I/2, (-1)^(2/5)}, 
    {I/2, (-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[4, 6, 7, 7] = {{(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[4, 7, 1, 4] = {{I}}
 
repD10Cat2FMatrixFunction[4, 7, 1, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 7, 2, 5] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 7, 2, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 7, 3, 4] = {{-I}}
 
repD10Cat2FMatrixFunction[4, 7, 4, 5] = {{-(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[4, 7, 4, 7] = {{0, -2}, {-(-1)^(7/10)/2, 0}}
 
repD10Cat2FMatrixFunction[4, 7, 5, 4] = {{(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[4, 7, 5, 6] = {{0, -2*(-1)^(3/5)}, 
    {-(-1)^(1/10)/2, 0}}
 
repD10Cat2FMatrixFunction[4, 7, 6, 1] = {{(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[4, 7, 6, 3] = {{(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[4, 7, 6, 5] = {{1/2, -(-1)^(2/5)}, 
    {1/2, (-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[4, 7, 6, 7] = {{-(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[4, 7, 7, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 7, 7, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[4, 7, 7, 4] = {{-I/2, 1}, {-I/2, -1}}
 
repD10Cat2FMatrixFunction[4, 7, 7, 6] = {{-(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[5, 1, 4, 0] = {{I}}
 
repD10Cat2FMatrixFunction[5, 1, 4, 2] = {{-I}}
 
repD10Cat2FMatrixFunction[5, 1, 5, 1] = {{I}}
 
repD10Cat2FMatrixFunction[5, 1, 5, 3] = {{-I}}
 
repD10Cat2FMatrixFunction[5, 1, 6, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 1, 7, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 2, 4, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 2, 4, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 2, 5, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 2, 5, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 2, 6, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 2, 7, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 3, 4, 0] = {{-I}}
 
repD10Cat2FMatrixFunction[5, 3, 4, 2] = {{I}}
 
repD10Cat2FMatrixFunction[5, 3, 5, 1] = {{-I}}
 
repD10Cat2FMatrixFunction[5, 3, 5, 3] = {{I}}
 
repD10Cat2FMatrixFunction[5, 4, 1, 0] = {{-I}}
 
repD10Cat2FMatrixFunction[5, 4, 1, 2] = {{-I}}
 
repD10Cat2FMatrixFunction[5, 4, 1, 6] = {{(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[5, 4, 2, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 4, 3, 0] = {{-I}}
 
repD10Cat2FMatrixFunction[5, 4, 3, 2] = {{-I}}
 
repD10Cat2FMatrixFunction[5, 4, 3, 6] = {{-(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[5, 4, 4, 5] = {{1/2, -1/2, (-1)^(3/5)/2}, 
    {-1/2, 1/2, (-1)^(3/5)/2}, {-1, -1, 0}}
 
repD10Cat2FMatrixFunction[5, 4, 4, 7] = {{I}}
 
repD10Cat2FMatrixFunction[5, 4, 5, 4] = {{I/2, -I/2, (-1)^(1/10)/2}, 
    {-I/2, I/2, (-1)^(1/10)/2}, {(-1)^(9/10), (-1)^(9/10), 0}}
 
repD10Cat2FMatrixFunction[5, 4, 5, 6] = {{-(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[5, 4, 6, 1] = {{(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[5, 4, 6, 3] = {{(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[5, 4, 6, 5] = {{-(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[5, 4, 6, 7] = {{-(-1)^(9/10), -(-1)^(9/10)}, 
    {1/2, -1/2}}
 
repD10Cat2FMatrixFunction[5, 4, 7, 0] = {{-(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[5, 4, 7, 2] = {{-(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[5, 4, 7, 4] = {{-(-1)^(1/5)}}
 
repD10Cat2FMatrixFunction[5, 4, 7, 6] = {{1, 1}, {-1/2, 1/2}}
 
repD10Cat2FMatrixFunction[5, 5, 1, 1] = {{I}}
 
repD10Cat2FMatrixFunction[5, 5, 1, 3] = {{I}}
 
repD10Cat2FMatrixFunction[5, 5, 1, 7] = {{(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[5, 5, 2, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 5, 3, 1] = {{I}}
 
repD10Cat2FMatrixFunction[5, 5, 3, 3] = {{I}}
 
repD10Cat2FMatrixFunction[5, 5, 3, 7] = {{-(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[5, 5, 4, 4] = {{-I/2, I/2, -1/2}, {-I/2, I/2, 1/2}, 
    {-(-1)^(2/5), -(-1)^(2/5), 0}}
 
repD10Cat2FMatrixFunction[5, 5, 4, 6] = {{(-1)^(3/10)}}
 
repD10Cat2FMatrixFunction[5, 5, 5, 5] = {{-1/2, 1/2, -I/2}, {-1/2, 1/2, I/2}, 
    {-I, -I, 0}}
 
repD10Cat2FMatrixFunction[5, 5, 5, 7] = {{(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[5, 5, 6, 0] = {{I}}
 
repD10Cat2FMatrixFunction[5, 5, 6, 2] = {{-I}}
 
repD10Cat2FMatrixFunction[5, 5, 6, 4] = {{(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[5, 5, 6, 6] = {{I, I}, {I/2, -I/2}}
 
repD10Cat2FMatrixFunction[5, 5, 7, 1] = {{-I}}
 
repD10Cat2FMatrixFunction[5, 5, 7, 3] = {{I}}
 
repD10Cat2FMatrixFunction[5, 5, 7, 5] = {{I}}
 
repD10Cat2FMatrixFunction[5, 5, 7, 7] = {{(-1)^(2/5), (-1)^(2/5)}, 
    {-I/2, I/2}}
 
repD10Cat2FMatrixFunction[5, 6, 1, 4] = {{-I}}
 
repD10Cat2FMatrixFunction[5, 6, 2, 5] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 6, 2, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 6, 3, 4] = {{I}}
 
repD10Cat2FMatrixFunction[5, 6, 3, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 6, 4, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 6, 4, 5] = {{-(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[5, 6, 4, 7] = {{0, -2*I}, {-(-1)^(7/10)/2, 0}}
 
repD10Cat2FMatrixFunction[5, 6, 5, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 6, 5, 4] = {{-(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[5, 6, 5, 6] = {{0, -2*(-1)^(1/10)}, 
    {(-1)^(1/10)/2, 0}}
 
repD10Cat2FMatrixFunction[5, 6, 6, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 6, 6, 5] = {{-1/2, (-1)^(2/5)}, 
    {1/2, (-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[5, 6, 6, 7] = {{(-1)^(3/10)}}
 
repD10Cat2FMatrixFunction[5, 6, 7, 0] = {{-(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[5, 6, 7, 2] = {{(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[5, 6, 7, 4] = {{I/2, 1}, {-I/2, 1}}
 
repD10Cat2FMatrixFunction[5, 6, 7, 6] = {{I}}
 
repD10Cat2FMatrixFunction[5, 7, 1, 5] = {{-I}}
 
repD10Cat2FMatrixFunction[5, 7, 1, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 7, 2, 4] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 7, 2, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 7, 3, 5] = {{I}}
 
repD10Cat2FMatrixFunction[5, 7, 4, 4] = {{-(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[5, 7, 4, 6] = {{0, 2*(-1)^(1/10)}, 
    {(-1)^(3/5)/2, 0}}
 
repD10Cat2FMatrixFunction[5, 7, 5, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 7, 5, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[5, 7, 5, 5] = {{-(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[5, 7, 5, 7] = {{0, 2*I}, {(-1)^(1/5)/2, 0}}
 
repD10Cat2FMatrixFunction[5, 7, 6, 0] = {{-(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[5, 7, 6, 2] = {{-(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[5, 7, 6, 4] = {{1/2, -1}, {1/2, 1}}
 
repD10Cat2FMatrixFunction[5, 7, 7, 5] = {{I/2, -(-1)^(2/5)}, 
    {I/2, (-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[5, 7, 7, 7] = {{-(-1)^(4/5)}}
 
repD10Cat2FMatrixFunction[6, 1, 6, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 1, 7, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 2, 4, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 2, 5, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 2, 6, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 2, 6, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 2, 7, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 2, 7, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 3, 4, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 3, 5, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 3, 6, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 3, 7, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 4, 1, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 4, 2, 4] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 4, 3, 5] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 4, 3, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 4, 4, 4] = {{-(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[6, 4, 4, 6] = {{-1/2, -1}, {-1/2, 1}}
 
repD10Cat2FMatrixFunction[6, 4, 5, 1] = {{(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[6, 4, 5, 3] = {{(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[6, 4, 5, 5] = {{-(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[6, 4, 5, 7] = {{-(-1)^(1/10)/2, I}, 
    {-(-1)^(1/10)/2, -I}}
 
repD10Cat2FMatrixFunction[6, 4, 6, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 4, 6, 4] = {{0, 2*(-1)^(2/5)}, {(-1)^(2/5)/2, 0}}
 
repD10Cat2FMatrixFunction[6, 4, 6, 6] = {{-(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[6, 4, 7, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 4, 7, 5] = {{0, -2*(-1)^(3/10)}, {-I/2, 0}}
 
repD10Cat2FMatrixFunction[6, 4, 7, 7] = {{-(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[6, 5, 1, 4] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 5, 1, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 5, 2, 5] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 5, 3, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 5, 4, 1] = {{-(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[6, 5, 4, 3] = {{(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[6, 5, 4, 5] = {{(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[6, 5, 4, 7] = {{(-1)^(3/5)/2, -1}, 
    {-(-1)^(3/5)/2, -1}}
 
repD10Cat2FMatrixFunction[6, 5, 5, 0] = {{I}}
 
repD10Cat2FMatrixFunction[6, 5, 5, 2] = {{-I}}
 
repD10Cat2FMatrixFunction[6, 5, 5, 4] = {{(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[6, 5, 5, 6] = {{I/2, -I}, {-I/2, -I}}
 
repD10Cat2FMatrixFunction[6, 5, 6, 5] = {{0, 2*(-1)^(3/10)}, {-I/2, 0}}
 
repD10Cat2FMatrixFunction[6, 5, 6, 7] = {{-(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[6, 5, 7, 4] = {{0, -2*(-1)^(2/5)}, 
    {(-1)^(2/5)/2, 0}}
 
repD10Cat2FMatrixFunction[6, 5, 7, 6] = {{-(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[6, 6, 1, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 6, 1, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 6, 1, 5] = {{-(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[6, 6, 3, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 6, 3, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 6, 3, 5] = {{-(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[6, 6, 4, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 6, 4, 4] = {{-1, -1}, {-1/2, 1/2}}
 
repD10Cat2FMatrixFunction[6, 6, 4, 6] = {{(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[6, 6, 5, 1] = {{-I}}
 
repD10Cat2FMatrixFunction[6, 6, 5, 3] = {{I}}
 
repD10Cat2FMatrixFunction[6, 6, 5, 5] = 
   {{-1, -1}, {-(-1)^(3/5)/2, (-1)^(3/5)/2}}
 
repD10Cat2FMatrixFunction[6, 6, 5, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 6, 6, 4] = {{-(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[6, 6, 6, 6] = {{1/2, -1/2, -1}, {1/2, -1/2, 1}, 
    {-1/2, -1/2, 0}}
 
repD10Cat2FMatrixFunction[6, 6, 7, 5] = {{(-1)^(7/10)}}
 
repD10Cat2FMatrixFunction[6, 6, 7, 7] = {{-1/2, 1/2, 1}, {-1/2, 1/2, -1}, 
    {-(-1)^(3/5)/2, -(-1)^(3/5)/2, 0}}
 
repD10Cat2FMatrixFunction[6, 7, 1, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 7, 1, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 7, 1, 4] = {{(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[6, 7, 3, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 7, 3, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[6, 7, 3, 4] = {{(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[6, 7, 4, 1] = {{(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[6, 7, 4, 3] = {{(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[6, 7, 4, 5] = 
   {{1, 1}, {(-1)^(3/5)/2, -(-1)^(3/5)/2}}
 
repD10Cat2FMatrixFunction[6, 7, 4, 7] = {{-(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[6, 7, 5, 0] = {{(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[6, 7, 5, 2] = {{(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[6, 7, 5, 4] = {{1, 1}, {1/2, -1/2}}
 
repD10Cat2FMatrixFunction[6, 7, 5, 6] = {{(-1)^(4/5)}}
 
repD10Cat2FMatrixFunction[6, 7, 6, 5] = {{-(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[6, 7, 6, 7] = {{-1/2, 1/2, -(-1)^(2/5)}, 
    {1/2, -1/2, -(-1)^(2/5)}, {(-1)^(3/5)/2, (-1)^(3/5)/2, 0}}
 
repD10Cat2FMatrixFunction[6, 7, 7, 6] = {{1/2, -1/2, (-1)^(2/5)}, 
    {-1/2, 1/2, (-1)^(2/5)}, {1/2, 1/2, 0}}
 
repD10Cat2FMatrixFunction[7, 1, 4, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 1, 5, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 1, 6, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 1, 7, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 2, 4, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 2, 5, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 2, 6, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 2, 6, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 2, 7, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 2, 7, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 3, 6, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 3, 7, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 4, 1, 4] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 4, 1, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 4, 2, 5] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 4, 3, 6] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 4, 4, 1] = {{-I}}
 
repD10Cat2FMatrixFunction[7, 4, 4, 3] = {{-I}}
 
repD10Cat2FMatrixFunction[7, 4, 4, 5] = {{-(-1)^(7/10)}}
 
repD10Cat2FMatrixFunction[7, 4, 4, 7] = {{(-1)^(3/5)/2, -1}, 
    {(-1)^(3/5)/2, 1}}
 
repD10Cat2FMatrixFunction[7, 4, 5, 0] = {{-(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[7, 4, 5, 2] = {{-(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[7, 4, 5, 4] = {{I}}
 
repD10Cat2FMatrixFunction[7, 4, 5, 6] = {{I/2, I}, {I/2, -I}}
 
repD10Cat2FMatrixFunction[7, 4, 6, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 4, 6, 5] = {{0, 2*(-1)^(3/10)}, {I/2, 0}}
 
repD10Cat2FMatrixFunction[7, 4, 6, 7] = {{-(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[7, 4, 7, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 4, 7, 4] = {{0, 2*(-1)^(2/5)}, {(-1)^(2/5)/2, 0}}
 
repD10Cat2FMatrixFunction[7, 4, 7, 6] = {{(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[7, 5, 1, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 5, 2, 4] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 5, 3, 5] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 5, 3, 7] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 5, 4, 0] = {{(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[7, 5, 4, 2] = {{-(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[7, 5, 4, 4] = {{-I}}
 
repD10Cat2FMatrixFunction[7, 5, 4, 6] = {{-1/2, 1}, {1/2, 1}}
 
repD10Cat2FMatrixFunction[7, 5, 5, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 5, 5, 5] = {{(-1)^(7/10)}}
 
repD10Cat2FMatrixFunction[7, 5, 5, 7] = {{-(-1)^(1/10)/2, I}, 
    {(-1)^(1/10)/2, I}}
 
repD10Cat2FMatrixFunction[7, 5, 6, 4] = {{0, -2*(-1)^(2/5)}, 
    {-(-1)^(2/5)/2, 0}}
 
repD10Cat2FMatrixFunction[7, 5, 6, 6] = {{(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[7, 5, 7, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 5, 7, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 5, 7, 5] = {{0, -2*(-1)^(3/10)}, {-I/2, 0}}
 
repD10Cat2FMatrixFunction[7, 5, 7, 7] = {{-(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[7, 6, 1, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 6, 1, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 6, 1, 4] = {{-(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[7, 6, 2, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 6, 2, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 6, 3, 4] = {{-(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[7, 6, 4, 1] = {{-(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[7, 6, 4, 3] = {{(-1)^(2/5)}}
 
repD10Cat2FMatrixFunction[7, 6, 4, 5] = 
   {{-I, I}, {-(-1)^(3/5)/2, -(-1)^(3/5)/2}}
 
repD10Cat2FMatrixFunction[7, 6, 4, 7] = {{-(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[7, 6, 5, 0] = {{(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[7, 6, 5, 2] = {{-(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[7, 6, 5, 4] = {{I, -I}, {1/2, 1/2}}
 
repD10Cat2FMatrixFunction[7, 6, 5, 6] = {{(-1)^(3/10)}}
 
repD10Cat2FMatrixFunction[7, 6, 6, 5] = {{-I}}
 
repD10Cat2FMatrixFunction[7, 6, 6, 7] = {{-1/2, -1/2, (-1)^(2/5)}, 
    {-1/2, -1/2, -(-1)^(2/5)}, {1/2, -1/2, 0}}
 
repD10Cat2FMatrixFunction[7, 6, 7, 4] = {{(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[7, 6, 7, 6] = {{-1/2, -1/2, -(-1)^(2/5)}, 
    {-1/2, -1/2, (-1)^(2/5)}, {-(-1)^(3/5)/2, (-1)^(3/5)/2, 0}}
 
repD10Cat2FMatrixFunction[7, 7, 1, 5] = {{(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[7, 7, 2, 0] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 7, 2, 2] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 7, 3, 1] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 7, 3, 3] = {{-1}}
 
repD10Cat2FMatrixFunction[7, 7, 3, 5] = {{(-1)^(3/5)}}
 
repD10Cat2FMatrixFunction[7, 7, 4, 4] = {{I, -I}, {-1/2, -1/2}}
 
repD10Cat2FMatrixFunction[7, 7, 4, 6] = {{(-1)^(9/10)}}
 
repD10Cat2FMatrixFunction[7, 7, 5, 1] = {{I}}
 
repD10Cat2FMatrixFunction[7, 7, 5, 3] = {{I}}
 
repD10Cat2FMatrixFunction[7, 7, 5, 5] = 
   {{-I, I}, {(-1)^(3/5)/2, (-1)^(3/5)/2}}
 
repD10Cat2FMatrixFunction[7, 7, 5, 7] = {{I}}
 
repD10Cat2FMatrixFunction[7, 7, 6, 4] = {{-(-1)^(1/5)}}
 
repD10Cat2FMatrixFunction[7, 7, 6, 6] = {{-1/2, -1/2, 1}, {1/2, 1/2, 1}, 
    {-(-1)^(3/5)/2, (-1)^(3/5)/2, 0}}
 
repD10Cat2FMatrixFunction[7, 7, 7, 5] = {{(-1)^(1/10)}}
 
repD10Cat2FMatrixFunction[7, 7, 7, 7] = {{-1/2, -1/2, -1}, {1/2, 1/2, -1}, 
    {1/2, -1/2, 0}}
 
repD10Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repD10Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
repD10Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repD10Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[repD10Cat2Piv1] ^= {}
 
fusionCategory[repD10Cat2Piv1] ^= repD10Cat2
 
repD10Cat2Piv1 /: modularCategory[repD10Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repD10Cat2Piv1] ^= repD10Cat2Piv1
 
pivotalIsomorphism[repD10Cat2Piv1] ^= repD10Cat2Piv1PivotalIsomorphism
 
ring[repD10Cat2Piv1] ^= repD10
 
sphericalCategory[repD10Cat2Piv1] ^= repD10Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[repD10Cat2]][pivotalCategory[#1]] & )[
    repD10Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[repD10Cat2]][
      sphericalCategory[#1]] & )[repD10Cat2Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[repD10Cat2Piv1PivotalIsomorphism] ^= repD10Cat2
 
pivotalCategory[repD10Cat2Piv1PivotalIsomorphism] ^= repD10Cat2Piv1
 
pivotalIsomorphism[repD10Cat2Piv1PivotalIsomorphism] ^= 
   repD10Cat2Piv1PivotalIsomorphism
 
repD10Cat2Piv1PivotalIsomorphism[0] = 1
 
repD10Cat2Piv1PivotalIsomorphism[1] = 1
 
repD10Cat2Piv1PivotalIsomorphism[2] = 1
 
repD10Cat2Piv1PivotalIsomorphism[3] = 1
 
repD10Cat2Piv1PivotalIsomorphism[4] = 1
 
repD10Cat2Piv1PivotalIsomorphism[5] = -1
 
repD10Cat2Piv1PivotalIsomorphism[6] = 1
 
repD10Cat2Piv1PivotalIsomorphism[7] = -1
balancedCategories[repD10Cat2Piv2] ^= {}
 
fusionCategory[repD10Cat2Piv2] ^= repD10Cat2
 
repD10Cat2Piv2 /: modularCategory[repD10Cat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repD10Cat2Piv2] ^= repD10Cat2Piv2
 
pivotalIsomorphism[repD10Cat2Piv2] ^= repD10Cat2Piv2PivotalIsomorphism
 
ring[repD10Cat2Piv2] ^= repD10
 
sphericalCategory[repD10Cat2Piv2] ^= repD10Cat2Piv2
 
(pivotalCategoryIndex[fusionCategory[repD10Cat2]][pivotalCategory[#1]] & )[
    repD10Cat2Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[repD10Cat2]][
      sphericalCategory[#1]] & )[repD10Cat2Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[repD10Cat2Piv2PivotalIsomorphism] ^= repD10Cat2
 
pivotalCategory[repD10Cat2Piv2PivotalIsomorphism] ^= repD10Cat2Piv2
 
pivotalIsomorphism[repD10Cat2Piv2PivotalIsomorphism] ^= 
   repD10Cat2Piv2PivotalIsomorphism
 
repD10Cat2Piv2PivotalIsomorphism[0] = 1
 
repD10Cat2Piv2PivotalIsomorphism[1] = -1
 
repD10Cat2Piv2PivotalIsomorphism[2] = 1
 
repD10Cat2Piv2PivotalIsomorphism[3] = -1
 
repD10Cat2Piv2PivotalIsomorphism[4] = 1
 
repD10Cat2Piv2PivotalIsomorphism[5] = 1
 
repD10Cat2Piv2PivotalIsomorphism[6] = 1
 
repD10Cat2Piv2PivotalIsomorphism[7] = 1
balancedCategories[repD10Cat3] ^= {}
 
braidedCategories[repD10Cat3] ^= {}
 
coeval[repD10Cat3] ^= 1/sixJFunction[repD10Cat3][#1, 
      dual[ring[repD10Cat3]][#1], #1, #1, 0, 0] & 
 
eval[repD10Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[repD10Cat3] ^= repD10Cat3FMatrixFunction
 
fusionCategory[repD10Cat3] ^= repD10Cat3
 
repD10Cat3 /: modularCategory[repD10Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[repD10Cat3] ^= {repD10Cat3Piv1, repD10Cat3Piv2}
 
repD10Cat3 /: pivotalCategory[repD10Cat3, 1] = repD10Cat3Piv1
 
repD10Cat3 /: pivotalCategory[repD10Cat3, 2] = repD10Cat3Piv2
 
repD10Cat3 /: pivotalCategory[repD10Cat3, {1, -1, 1, -1, 1, 1, 1, 1}] = 
    repD10Cat3Piv2
 
repD10Cat3 /: pivotalCategory[repD10Cat3, {1, 1, 1, 1, 1, -1, 1, -1}] = 
    repD10Cat3Piv1
 
ring[repD10Cat3] ^= repD10
 
repD10Cat3 /: sphericalCategory[repD10Cat3, 1] = repD10Cat3Piv1
 
repD10Cat3 /: sphericalCategory[repD10Cat3, 2] = repD10Cat3Piv2
 
fusionCategoryIndex[repD10][repD10Cat3] ^= 3
fMatrixFunction[repD10Cat3FMatrixFunction] ^= repD10Cat3FMatrixFunction
 
fusionCategory[repD10Cat3FMatrixFunction] ^= repD10Cat3
 
ring[repD10Cat3FMatrixFunction] ^= repD10
 
repD10Cat3FMatrixFunction[1, 4, 4, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[1, 4, 4, 7] = {{(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[1, 4, 5, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[1, 4, 5, 6] = {{(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[1, 4, 7, 4] = {{-1}}
 
repD10Cat3FMatrixFunction[1, 4, 7, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[1, 5, 4, 0] = {{-1}}
 
repD10Cat3FMatrixFunction[1, 5, 4, 6] = {{(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[1, 5, 5, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[1, 5, 5, 7] = {{(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[1, 5, 6, 4] = {{-1}}
 
repD10Cat3FMatrixFunction[1, 5, 7, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[1, 6, 1, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[1, 6, 3, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[1, 6, 4, 5] = {{I}}
 
repD10Cat3FMatrixFunction[1, 6, 5, 4] = {{-I}}
 
repD10Cat3FMatrixFunction[1, 6, 5, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[1, 6, 6, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[1, 6, 6, 5] = {{-(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[1, 6, 7, 0] = {{-1}}
 
repD10Cat3FMatrixFunction[1, 6, 7, 4] = {{-(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[1, 7, 1, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[1, 7, 3, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[1, 7, 4, 4] = {{I}}
 
repD10Cat3FMatrixFunction[1, 7, 4, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[1, 7, 5, 5] = {{-I}}
 
repD10Cat3FMatrixFunction[1, 7, 6, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[1, 7, 6, 4] = {{(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[1, 7, 7, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[1, 7, 7, 5] = {{(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[2, 4, 4, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 4, 5, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 4, 6, 4] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 4, 7, 5] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 5, 4, 1] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 5, 4, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 5, 5, 0] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 5, 5, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 5, 5, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 5, 6, 5] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 5, 7, 4] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 6, 4, 4] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 6, 4, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 6, 5, 5] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 6, 5, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 6, 6, 0] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 6, 6, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 6, 7, 1] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 6, 7, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 7, 4, 5] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 7, 4, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 7, 5, 4] = {{-1}}
 
repD10Cat3FMatrixFunction[2, 7, 5, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 4, 4, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 4, 4, 7] = {{-(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[3, 4, 5, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 4, 5, 6] = {{-(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[3, 4, 6, 5] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 4, 7, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 5, 4, 6] = {{-(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[3, 5, 5, 1] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 5, 5, 7] = {{-(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[3, 5, 7, 5] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 5, 7, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 6, 1, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 6, 3, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 6, 4, 5] = {{-I}}
 
repD10Cat3FMatrixFunction[3, 6, 4, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 6, 5, 4] = {{I}}
 
repD10Cat3FMatrixFunction[3, 6, 6, 1] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 6, 6, 5] = {{-(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[3, 6, 7, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 6, 7, 4] = {{-(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[3, 7, 1, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 7, 3, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 7, 4, 4] = {{-I}}
 
repD10Cat3FMatrixFunction[3, 7, 5, 5] = {{I}}
 
repD10Cat3FMatrixFunction[3, 7, 5, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 7, 6, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 7, 6, 4] = {{(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[3, 7, 7, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[3, 7, 7, 5] = {{(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[4, 1, 4, 1] = {{I}}
 
repD10Cat3FMatrixFunction[4, 1, 4, 3] = {{-I}}
 
repD10Cat3FMatrixFunction[4, 1, 5, 0] = {{I}}
 
repD10Cat3FMatrixFunction[4, 1, 5, 2] = {{-I}}
 
repD10Cat3FMatrixFunction[4, 2, 4, 0] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 2, 4, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 2, 5, 1] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 2, 5, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 2, 6, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 2, 7, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 3, 4, 1] = {{-I}}
 
repD10Cat3FMatrixFunction[4, 3, 4, 3] = {{I}}
 
repD10Cat3FMatrixFunction[4, 3, 5, 0] = {{-I}}
 
repD10Cat3FMatrixFunction[4, 3, 5, 2] = {{I}}
 
repD10Cat3FMatrixFunction[4, 3, 6, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 3, 7, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 4, 1, 1] = {{I}}
 
repD10Cat3FMatrixFunction[4, 4, 1, 3] = {{I}}
 
repD10Cat3FMatrixFunction[4, 4, 1, 7] = {{(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[4, 4, 2, 0] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 4, 2, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 4, 2, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 4, 3, 1] = {{-I}}
 
repD10Cat3FMatrixFunction[4, 4, 3, 3] = {{-I}}
 
repD10Cat3FMatrixFunction[4, 4, 3, 7] = {{-(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[4, 4, 4, 4] = {{1/2, 1/2, -1/2}, 
    {-1/2, -1/2, -1/2}, {-1, 1, 0}}
 
repD10Cat3FMatrixFunction[4, 4, 4, 6] = {{(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[4, 4, 5, 5] = {{I/2, I/2, -I/2}, 
    {-I/2, -I/2, -I/2}, {(-1)^(3/10), -(-1)^(3/10), 0}}
 
repD10Cat3FMatrixFunction[4, 4, 5, 7] = {{-(-1)^(3/5)}}
 
repD10Cat3FMatrixFunction[4, 4, 6, 4] = {{-(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[4, 4, 6, 6] = {{-1, 1}, {-1/2, -1/2}}
 
repD10Cat3FMatrixFunction[4, 4, 7, 5] = {{I}}
 
repD10Cat3FMatrixFunction[4, 4, 7, 7] = {{(-1)^(3/10), -(-1)^(3/10)}, 
    {-1/2, -1/2}}
 
repD10Cat3FMatrixFunction[4, 5, 1, 0] = {{I}}
 
repD10Cat3FMatrixFunction[4, 5, 1, 2] = {{I}}
 
repD10Cat3FMatrixFunction[4, 5, 1, 6] = {{(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[4, 5, 2, 1] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 5, 2, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 5, 2, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 5, 3, 0] = {{-I}}
 
repD10Cat3FMatrixFunction[4, 5, 3, 2] = {{-I}}
 
repD10Cat3FMatrixFunction[4, 5, 3, 6] = {{-(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[4, 5, 4, 5] = {{-I/2, -I/2, (-1)^(1/5)/2}, 
    {-I/2, -I/2, -(-1)^(1/5)/2}, {-(-1)^(4/5), (-1)^(4/5), 0}}
 
repD10Cat3FMatrixFunction[4, 5, 4, 7] = {{(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[4, 5, 5, 4] = {{-1/2, -1/2, -(-1)^(7/10)/2}, 
    {-1/2, -1/2, (-1)^(7/10)/2}, {I, -I, 0}}
 
repD10Cat3FMatrixFunction[4, 5, 6, 1] = {{-(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[4, 5, 6, 3] = {{(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[4, 5, 6, 5] = {{-(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[4, 5, 6, 7] = {{-(-1)^(4/5), (-1)^(4/5)}, 
    {I/2, I/2}}
 
repD10Cat3FMatrixFunction[4, 5, 7, 0] = {{-(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[4, 5, 7, 2] = {{(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[4, 5, 7, 4] = {{(-1)^(2/5)}}
 
repD10Cat3FMatrixFunction[4, 5, 7, 6] = {{I, -I}, {I/2, I/2}}
 
repD10Cat3FMatrixFunction[4, 6, 1, 5] = {{I}}
 
repD10Cat3FMatrixFunction[4, 6, 2, 4] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 6, 2, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 6, 3, 5] = {{-I}}
 
repD10Cat3FMatrixFunction[4, 6, 3, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 6, 4, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 6, 4, 4] = {{(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[4, 6, 4, 6] = {{0, -2*(-1)^(1/5)}, 
    {-(-1)^(1/5)/2, 0}}
 
repD10Cat3FMatrixFunction[4, 6, 5, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 6, 5, 5] = {{-(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[4, 6, 5, 7] = {{0, 2}, {(-1)^(2/5)/2, 0}}
 
repD10Cat3FMatrixFunction[4, 6, 6, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 6, 6, 4] = {{-1/2, -1}, {1/2, -1}}
 
repD10Cat3FMatrixFunction[4, 6, 6, 6] = {{(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[4, 6, 7, 1] = {{(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[4, 6, 7, 3] = {{-(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[4, 6, 7, 5] = {{-I/2, (-1)^(4/5)}, 
    {I/2, (-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[4, 6, 7, 7] = {{(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[4, 7, 1, 4] = {{I}}
 
repD10Cat3FMatrixFunction[4, 7, 1, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 7, 2, 5] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 7, 2, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[4, 7, 3, 4] = {{-I}}
 
repD10Cat3FMatrixFunction[4, 7, 4, 5] = {{-(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[4, 7, 4, 7] = {{0, 2}, {-(-1)^(9/10)/2, 0}}
 
repD10Cat3FMatrixFunction[4, 7, 5, 4] = {{(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[4, 7, 5, 6] = {{0, -2*(-1)^(1/5)}, 
    {(-1)^(7/10)/2, 0}}
 
repD10Cat3FMatrixFunction[4, 7, 6, 1] = {{(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[4, 7, 6, 3] = {{(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[4, 7, 6, 5] = {{-1/2, (-1)^(4/5)}, 
    {-1/2, -(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[4, 7, 6, 7] = {{(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[4, 7, 7, 4] = {{I/2, -1}, {I/2, 1}}
 
repD10Cat3FMatrixFunction[4, 7, 7, 6] = {{(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[5, 1, 4, 0] = {{I}}
 
repD10Cat3FMatrixFunction[5, 1, 4, 2] = {{-I}}
 
repD10Cat3FMatrixFunction[5, 1, 5, 1] = {{I}}
 
repD10Cat3FMatrixFunction[5, 1, 5, 3] = {{-I}}
 
repD10Cat3FMatrixFunction[5, 1, 6, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 1, 7, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 2, 4, 1] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 2, 4, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 2, 5, 0] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 2, 5, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 2, 6, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 2, 7, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 3, 4, 0] = {{-I}}
 
repD10Cat3FMatrixFunction[5, 3, 4, 2] = {{I}}
 
repD10Cat3FMatrixFunction[5, 3, 5, 1] = {{-I}}
 
repD10Cat3FMatrixFunction[5, 3, 5, 3] = {{I}}
 
repD10Cat3FMatrixFunction[5, 4, 1, 0] = {{-I}}
 
repD10Cat3FMatrixFunction[5, 4, 1, 2] = {{-I}}
 
repD10Cat3FMatrixFunction[5, 4, 1, 6] = {{(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[5, 4, 2, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 4, 3, 0] = {{-I}}
 
repD10Cat3FMatrixFunction[5, 4, 3, 2] = {{-I}}
 
repD10Cat3FMatrixFunction[5, 4, 3, 6] = {{-(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[5, 4, 4, 5] = {{1/2, -1/2, (-1)^(1/5)/2}, 
    {-1/2, 1/2, (-1)^(1/5)/2}, {-1, -1, 0}}
 
repD10Cat3FMatrixFunction[5, 4, 4, 7] = {{-I}}
 
repD10Cat3FMatrixFunction[5, 4, 5, 4] = {{I/2, -I/2, -(-1)^(7/10)/2}, 
    {-I/2, I/2, -(-1)^(7/10)/2}, {-(-1)^(3/10), -(-1)^(3/10), 0}}
 
repD10Cat3FMatrixFunction[5, 4, 5, 6] = {{(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[5, 4, 6, 1] = {{(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[5, 4, 6, 3] = {{(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[5, 4, 6, 5] = {{-(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[5, 4, 6, 7] = {{(-1)^(3/10), (-1)^(3/10)}, 
    {-1/2, 1/2}}
 
repD10Cat3FMatrixFunction[5, 4, 7, 0] = {{-(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[5, 4, 7, 2] = {{-(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[5, 4, 7, 4] = {{-(-1)^(2/5)}}
 
repD10Cat3FMatrixFunction[5, 4, 7, 6] = {{1, 1}, {1/2, -1/2}}
 
repD10Cat3FMatrixFunction[5, 5, 1, 1] = {{I}}
 
repD10Cat3FMatrixFunction[5, 5, 1, 3] = {{I}}
 
repD10Cat3FMatrixFunction[5, 5, 1, 7] = {{(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[5, 5, 2, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 5, 3, 1] = {{I}}
 
repD10Cat3FMatrixFunction[5, 5, 3, 3] = {{I}}
 
repD10Cat3FMatrixFunction[5, 5, 3, 7] = {{-(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[5, 5, 4, 4] = {{-I/2, I/2, -1/2}, {-I/2, I/2, 1/2}, 
    {-(-1)^(4/5), -(-1)^(4/5), 0}}
 
repD10Cat3FMatrixFunction[5, 5, 4, 6] = {{-(-1)^(1/10)}}
 
repD10Cat3FMatrixFunction[5, 5, 5, 5] = {{-1/2, 1/2, -I/2}, {-1/2, 1/2, I/2}, 
    {-I, -I, 0}}
 
repD10Cat3FMatrixFunction[5, 5, 5, 7] = {{(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[5, 5, 6, 0] = {{I}}
 
repD10Cat3FMatrixFunction[5, 5, 6, 2] = {{-I}}
 
repD10Cat3FMatrixFunction[5, 5, 6, 4] = {{-(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[5, 5, 6, 6] = {{I, I}, {-I/2, I/2}}
 
repD10Cat3FMatrixFunction[5, 5, 7, 1] = {{-I}}
 
repD10Cat3FMatrixFunction[5, 5, 7, 3] = {{I}}
 
repD10Cat3FMatrixFunction[5, 5, 7, 5] = {{-I}}
 
repD10Cat3FMatrixFunction[5, 5, 7, 7] = {{(-1)^(4/5), (-1)^(4/5)}, 
    {I/2, -I/2}}
 
repD10Cat3FMatrixFunction[5, 6, 1, 4] = {{-I}}
 
repD10Cat3FMatrixFunction[5, 6, 2, 5] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 6, 2, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 6, 3, 4] = {{I}}
 
repD10Cat3FMatrixFunction[5, 6, 3, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 6, 4, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 6, 4, 5] = {{-(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[5, 6, 4, 7] = {{0, 2*I}, {-(-1)^(9/10)/2, 0}}
 
repD10Cat3FMatrixFunction[5, 6, 5, 0] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 6, 5, 4] = {{-(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[5, 6, 5, 6] = {{0, 2*(-1)^(7/10)}, 
    {-(-1)^(7/10)/2, 0}}
 
repD10Cat3FMatrixFunction[5, 6, 6, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 6, 6, 5] = {{-1/2, (-1)^(4/5)}, 
    {1/2, (-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[5, 6, 6, 7] = {{(-1)^(1/10)}}
 
repD10Cat3FMatrixFunction[5, 6, 7, 0] = {{(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[5, 6, 7, 2] = {{-(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[5, 6, 7, 4] = {{I/2, 1}, {-I/2, 1}}
 
repD10Cat3FMatrixFunction[5, 6, 7, 6] = {{-I}}
 
repD10Cat3FMatrixFunction[5, 7, 1, 5] = {{-I}}
 
repD10Cat3FMatrixFunction[5, 7, 1, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 7, 2, 4] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 7, 2, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 7, 3, 5] = {{I}}
 
repD10Cat3FMatrixFunction[5, 7, 4, 4] = {{-(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[5, 7, 4, 6] = {{0, -2*(-1)^(7/10)}, 
    {(-1)^(1/5)/2, 0}}
 
repD10Cat3FMatrixFunction[5, 7, 5, 1] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 7, 5, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 7, 5, 5] = {{-(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[5, 7, 5, 7] = {{0, -2*I}, {(-1)^(2/5)/2, 0}}
 
repD10Cat3FMatrixFunction[5, 7, 6, 0] = {{-(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[5, 7, 6, 2] = {{-(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[5, 7, 6, 4] = {{-1/2, 1}, {-1/2, -1}}
 
repD10Cat3FMatrixFunction[5, 7, 6, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 7, 7, 1] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 7, 7, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[5, 7, 7, 5] = {{-I/2, (-1)^(4/5)}, 
    {-I/2, -(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[5, 7, 7, 7] = {{-(-1)^(3/5)}}
 
repD10Cat3FMatrixFunction[6, 1, 6, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 1, 7, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 2, 4, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 2, 5, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 2, 6, 0] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 2, 6, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 2, 7, 1] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 2, 7, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 3, 4, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 3, 5, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 3, 6, 1] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 3, 7, 0] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 4, 2, 4] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 4, 3, 5] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 4, 4, 4] = {{-(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[6, 4, 4, 6] = {{-1/2, -1}, {-1/2, 1}}
 
repD10Cat3FMatrixFunction[6, 4, 5, 1] = {{-(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[6, 4, 5, 3] = {{-(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[6, 4, 5, 5] = {{-(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[6, 4, 5, 7] = {{(-1)^(7/10)/2, -I}, 
    {(-1)^(7/10)/2, I}}
 
repD10Cat3FMatrixFunction[6, 4, 6, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 4, 6, 4] = {{0, 2*(-1)^(4/5)}, {(-1)^(4/5)/2, 0}}
 
repD10Cat3FMatrixFunction[6, 4, 6, 6] = {{-(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[6, 4, 7, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 4, 7, 5] = {{0, 2*(-1)^(1/10)}, {-I/2, 0}}
 
repD10Cat3FMatrixFunction[6, 4, 7, 7] = {{-(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[6, 5, 1, 4] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 5, 2, 5] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 5, 4, 1] = {{-(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[6, 5, 4, 3] = {{(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[6, 5, 4, 5] = {{-(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[6, 5, 4, 7] = {{(-1)^(1/5)/2, -1}, 
    {-(-1)^(1/5)/2, -1}}
 
repD10Cat3FMatrixFunction[6, 5, 5, 0] = {{I}}
 
repD10Cat3FMatrixFunction[6, 5, 5, 2] = {{-I}}
 
repD10Cat3FMatrixFunction[6, 5, 5, 4] = {{-(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[6, 5, 5, 6] = {{I/2, I}, {-I/2, I}}
 
repD10Cat3FMatrixFunction[6, 5, 6, 5] = {{0, 2*(-1)^(1/10)}, {-I/2, 0}}
 
repD10Cat3FMatrixFunction[6, 5, 6, 7] = {{-(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[6, 5, 7, 4] = {{0, 2*(-1)^(4/5)}, {(-1)^(4/5)/2, 0}}
 
repD10Cat3FMatrixFunction[6, 5, 7, 6] = {{-(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[6, 6, 1, 1] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 6, 1, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 6, 1, 5] = {{-(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[6, 6, 3, 1] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 6, 3, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 6, 3, 5] = {{-(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[6, 6, 4, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 6, 4, 4] = {{-1, -1}, {-1/2, 1/2}}
 
repD10Cat3FMatrixFunction[6, 6, 4, 6] = {{(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[6, 6, 5, 1] = {{I}}
 
repD10Cat3FMatrixFunction[6, 6, 5, 3] = {{-I}}
 
repD10Cat3FMatrixFunction[6, 6, 5, 5] = 
   {{-1, -1}, {(-1)^(1/5)/2, -(-1)^(1/5)/2}}
 
repD10Cat3FMatrixFunction[6, 6, 6, 4] = {{-(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[6, 6, 6, 6] = {{1/2, -1/2, -1}, {1/2, -1/2, 1}, 
    {-1/2, -1/2, 0}}
 
repD10Cat3FMatrixFunction[6, 6, 7, 5] = {{-(-1)^(9/10)}}
 
repD10Cat3FMatrixFunction[6, 6, 7, 7] = {{-1/2, 1/2, 1}, {-1/2, 1/2, -1}, 
    {(-1)^(1/5)/2, (-1)^(1/5)/2, 0}}
 
repD10Cat3FMatrixFunction[6, 7, 1, 0] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 7, 1, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 7, 1, 4] = {{(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[6, 7, 3, 0] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 7, 3, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[6, 7, 3, 4] = {{(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[6, 7, 4, 1] = {{-(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[6, 7, 4, 3] = {{-(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[6, 7, 4, 5] = 
   {{1, 1}, {-(-1)^(1/5)/2, (-1)^(1/5)/2}}
 
repD10Cat3FMatrixFunction[6, 7, 4, 7] = {{(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[6, 7, 5, 0] = {{-(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[6, 7, 5, 2] = {{-(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[6, 7, 5, 4] = {{1, 1}, {1/2, -1/2}}
 
repD10Cat3FMatrixFunction[6, 7, 5, 6] = {{-(-1)^(3/5)}}
 
repD10Cat3FMatrixFunction[6, 7, 6, 5] = {{(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[6, 7, 6, 7] = {{1/2, -1/2, (-1)^(4/5)}, 
    {-1/2, 1/2, (-1)^(4/5)}, {-(-1)^(1/5)/2, -(-1)^(1/5)/2, 0}}
 
repD10Cat3FMatrixFunction[6, 7, 7, 6] = {{-1/2, 1/2, -(-1)^(4/5)}, 
    {1/2, -1/2, -(-1)^(4/5)}, {1/2, 1/2, 0}}
 
repD10Cat3FMatrixFunction[7, 1, 4, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 1, 5, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 1, 6, 0] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 1, 7, 1] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 2, 4, 7] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 2, 5, 6] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 2, 6, 1] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 2, 6, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 2, 7, 0] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 2, 7, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 3, 6, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 3, 7, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 4, 1, 4] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 4, 2, 5] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 4, 4, 1] = {{I}}
 
repD10Cat3FMatrixFunction[7, 4, 4, 3] = {{I}}
 
repD10Cat3FMatrixFunction[7, 4, 4, 5] = {{-(-1)^(9/10)}}
 
repD10Cat3FMatrixFunction[7, 4, 4, 7] = {{(-1)^(1/5)/2, -1}, 
    {(-1)^(1/5)/2, 1}}
 
repD10Cat3FMatrixFunction[7, 4, 5, 0] = {{(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[7, 4, 5, 2] = {{(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[7, 4, 5, 4] = {{-I}}
 
repD10Cat3FMatrixFunction[7, 4, 5, 6] = {{I/2, -I}, {I/2, I}}
 
repD10Cat3FMatrixFunction[7, 4, 6, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 4, 6, 5] = {{0, 2*(-1)^(1/10)}, {-I/2, 0}}
 
repD10Cat3FMatrixFunction[7, 4, 6, 7] = {{-(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[7, 4, 7, 0] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 4, 7, 4] = {{0, -2*(-1)^(4/5)}, 
    {-(-1)^(4/5)/2, 0}}
 
repD10Cat3FMatrixFunction[7, 4, 7, 6] = {{(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[7, 5, 2, 4] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 5, 3, 5] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 5, 4, 0] = {{(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[7, 5, 4, 2] = {{-(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[7, 5, 4, 4] = {{-I}}
 
repD10Cat3FMatrixFunction[7, 5, 4, 6] = {{-1/2, 1}, {1/2, 1}}
 
repD10Cat3FMatrixFunction[7, 5, 5, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 5, 5, 5] = {{-(-1)^(9/10)}}
 
repD10Cat3FMatrixFunction[7, 5, 5, 7] = {{(-1)^(7/10)/2, -I}, 
    {-(-1)^(7/10)/2, -I}}
 
repD10Cat3FMatrixFunction[7, 5, 6, 4] = {{0, -2*(-1)^(4/5)}, 
    {(-1)^(4/5)/2, 0}}
 
repD10Cat3FMatrixFunction[7, 5, 6, 6] = {{(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[7, 5, 7, 1] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 5, 7, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 5, 7, 5] = {{0, 2*(-1)^(1/10)}, {I/2, 0}}
 
repD10Cat3FMatrixFunction[7, 5, 7, 7] = {{-(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[7, 6, 1, 0] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 6, 1, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 6, 1, 4] = {{-(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[7, 6, 2, 1] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 6, 2, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 6, 3, 4] = {{-(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[7, 6, 4, 1] = {{-(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[7, 6, 4, 3] = {{(-1)^(4/5)}}
 
repD10Cat3FMatrixFunction[7, 6, 4, 5] = 
   {{I, -I}, {-(-1)^(1/5)/2, -(-1)^(1/5)/2}}
 
repD10Cat3FMatrixFunction[7, 6, 4, 7] = {{-(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[7, 6, 5, 0] = {{(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[7, 6, 5, 2] = {{-(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[7, 6, 5, 4] = {{-I, I}, {-1/2, -1/2}}
 
repD10Cat3FMatrixFunction[7, 6, 5, 6] = {{-(-1)^(1/10)}}
 
repD10Cat3FMatrixFunction[7, 6, 6, 5] = {{I}}
 
repD10Cat3FMatrixFunction[7, 6, 6, 7] = {{1/2, 1/2, (-1)^(4/5)}, 
    {1/2, 1/2, -(-1)^(4/5)}, {-1/2, 1/2, 0}}
 
repD10Cat3FMatrixFunction[7, 6, 7, 4] = {{-(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[7, 6, 7, 6] = {{1/2, 1/2, -(-1)^(4/5)}, 
    {1/2, 1/2, (-1)^(4/5)}, {-(-1)^(1/5)/2, (-1)^(1/5)/2, 0}}
 
repD10Cat3FMatrixFunction[7, 7, 1, 5] = {{(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[7, 7, 2, 0] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 7, 2, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 7, 3, 1] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 7, 3, 3] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 7, 3, 5] = {{(-1)^(1/5)}}
 
repD10Cat3FMatrixFunction[7, 7, 4, 0] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 7, 4, 2] = {{-1}}
 
repD10Cat3FMatrixFunction[7, 7, 4, 4] = {{-I, I}, {1/2, 1/2}}
 
repD10Cat3FMatrixFunction[7, 7, 4, 6] = {{-(-1)^(3/10)}}
 
repD10Cat3FMatrixFunction[7, 7, 5, 1] = {{I}}
 
repD10Cat3FMatrixFunction[7, 7, 5, 3] = {{I}}
 
repD10Cat3FMatrixFunction[7, 7, 5, 5] = 
   {{I, -I}, {(-1)^(1/5)/2, (-1)^(1/5)/2}}
 
repD10Cat3FMatrixFunction[7, 7, 5, 7] = {{-I}}
 
repD10Cat3FMatrixFunction[7, 7, 6, 4] = {{-(-1)^(2/5)}}
 
repD10Cat3FMatrixFunction[7, 7, 6, 6] = {{-1/2, -1/2, -1}, {1/2, 1/2, -1}, 
    {-(-1)^(1/5)/2, (-1)^(1/5)/2, 0}}
 
repD10Cat3FMatrixFunction[7, 7, 7, 5] = {{(-1)^(7/10)}}
 
repD10Cat3FMatrixFunction[7, 7, 7, 7] = {{-1/2, -1/2, 1}, {1/2, 1/2, 1}, 
    {-1/2, 1/2, 0}}
 
repD10Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repD10Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
repD10Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repD10Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[repD10Cat3Piv1] ^= {}
 
fusionCategory[repD10Cat3Piv1] ^= repD10Cat3
 
repD10Cat3Piv1 /: modularCategory[repD10Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repD10Cat3Piv1] ^= repD10Cat3Piv1
 
pivotalIsomorphism[repD10Cat3Piv1] ^= repD10Cat3Piv1PivotalIsomorphism
 
ring[repD10Cat3Piv1] ^= repD10
 
sphericalCategory[repD10Cat3Piv1] ^= repD10Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[repD10Cat3]][pivotalCategory[#1]] & )[
    repD10Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[repD10Cat3]][
      sphericalCategory[#1]] & )[repD10Cat3Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[repD10Cat3Piv1PivotalIsomorphism] ^= repD10Cat3
 
pivotalCategory[repD10Cat3Piv1PivotalIsomorphism] ^= repD10Cat3Piv1
 
pivotalIsomorphism[repD10Cat3Piv1PivotalIsomorphism] ^= 
   repD10Cat3Piv1PivotalIsomorphism
 
repD10Cat3Piv1PivotalIsomorphism[0] = 1
 
repD10Cat3Piv1PivotalIsomorphism[1] = 1
 
repD10Cat3Piv1PivotalIsomorphism[2] = 1
 
repD10Cat3Piv1PivotalIsomorphism[3] = 1
 
repD10Cat3Piv1PivotalIsomorphism[4] = 1
 
repD10Cat3Piv1PivotalIsomorphism[5] = -1
 
repD10Cat3Piv1PivotalIsomorphism[6] = 1
 
repD10Cat3Piv1PivotalIsomorphism[7] = -1
balancedCategories[repD10Cat3Piv2] ^= {}
 
fusionCategory[repD10Cat3Piv2] ^= repD10Cat3
 
repD10Cat3Piv2 /: modularCategory[repD10Cat3Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repD10Cat3Piv2] ^= repD10Cat3Piv2
 
pivotalIsomorphism[repD10Cat3Piv2] ^= repD10Cat3Piv2PivotalIsomorphism
 
ring[repD10Cat3Piv2] ^= repD10
 
sphericalCategory[repD10Cat3Piv2] ^= repD10Cat3Piv2
 
(pivotalCategoryIndex[fusionCategory[repD10Cat3]][pivotalCategory[#1]] & )[
    repD10Cat3Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[repD10Cat3]][
      sphericalCategory[#1]] & )[repD10Cat3Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[repD10Cat3Piv2PivotalIsomorphism] ^= repD10Cat3
 
pivotalCategory[repD10Cat3Piv2PivotalIsomorphism] ^= repD10Cat3Piv2
 
pivotalIsomorphism[repD10Cat3Piv2PivotalIsomorphism] ^= 
   repD10Cat3Piv2PivotalIsomorphism
 
repD10Cat3Piv2PivotalIsomorphism[0] = 1
 
repD10Cat3Piv2PivotalIsomorphism[1] = -1
 
repD10Cat3Piv2PivotalIsomorphism[2] = 1
 
repD10Cat3Piv2PivotalIsomorphism[3] = -1
 
repD10Cat3Piv2PivotalIsomorphism[4] = 1
 
repD10Cat3Piv2PivotalIsomorphism[5] = 1
 
repD10Cat3Piv2PivotalIsomorphism[6] = 1
 
repD10Cat3Piv2PivotalIsomorphism[7] = 1
balancedCategories[repD10Cat4] ^= {repD10Cat4Bal1, repD10Cat4Bal2, 
    repD10Cat4Bal3, repD10Cat4Bal4, repD10Cat4Bal5, repD10Cat4Bal6, 
    repD10Cat4Bal7, repD10Cat4Bal8, repD10Cat4Bal9, repD10Cat4Bal10, 
    repD10Cat4Bal11, repD10Cat4Bal12, repD10Cat4Bal13, repD10Cat4Bal14, 
    repD10Cat4Bal15, repD10Cat4Bal16, repD10Cat4Bal17, repD10Cat4Bal18, 
    repD10Cat4Bal19, repD10Cat4Bal20}
 
repD10Cat4 /: balancedCategory[repD10Cat4, 1] = repD10Cat4Bal1
 
repD10Cat4 /: balancedCategory[repD10Cat4, 2] = repD10Cat4Bal2
 
repD10Cat4 /: balancedCategory[repD10Cat4, 3] = repD10Cat4Bal3
 
repD10Cat4 /: balancedCategory[repD10Cat4, 4] = repD10Cat4Bal4
 
repD10Cat4 /: balancedCategory[repD10Cat4, 5] = repD10Cat4Bal5
 
repD10Cat4 /: balancedCategory[repD10Cat4, 6] = repD10Cat4Bal6
 
repD10Cat4 /: balancedCategory[repD10Cat4, 7] = repD10Cat4Bal7
 
repD10Cat4 /: balancedCategory[repD10Cat4, 8] = repD10Cat4Bal8
 
repD10Cat4 /: balancedCategory[repD10Cat4, 9] = repD10Cat4Bal9
 
repD10Cat4 /: balancedCategory[repD10Cat4, 10] = repD10Cat4Bal10
 
repD10Cat4 /: balancedCategory[repD10Cat4, 11] = repD10Cat4Bal11
 
repD10Cat4 /: balancedCategory[repD10Cat4, 12] = repD10Cat4Bal12
 
repD10Cat4 /: balancedCategory[repD10Cat4, 13] = repD10Cat4Bal13
 
repD10Cat4 /: balancedCategory[repD10Cat4, 14] = repD10Cat4Bal14
 
repD10Cat4 /: balancedCategory[repD10Cat4, 15] = repD10Cat4Bal15
 
repD10Cat4 /: balancedCategory[repD10Cat4, 16] = repD10Cat4Bal16
 
repD10Cat4 /: balancedCategory[repD10Cat4, 17] = repD10Cat4Bal17
 
repD10Cat4 /: balancedCategory[repD10Cat4, 18] = repD10Cat4Bal18
 
repD10Cat4 /: balancedCategory[repD10Cat4, 19] = repD10Cat4Bal19
 
repD10Cat4 /: balancedCategory[repD10Cat4, 20] = repD10Cat4Bal20
 
braidedCategories[repD10Cat4] ^= {repD10Cat4Brd1, repD10Cat4Brd2, 
    repD10Cat4Brd3, repD10Cat4Brd4, repD10Cat4Brd5, repD10Cat4Brd6, 
    repD10Cat4Brd7, repD10Cat4Brd8, repD10Cat4Brd9, repD10Cat4Brd10}
 
repD10Cat4 /: braidedCategory[repD10Cat4, 1] = repD10Cat4Brd1
 
repD10Cat4 /: braidedCategory[repD10Cat4, 2] = repD10Cat4Brd2
 
repD10Cat4 /: braidedCategory[repD10Cat4, 3] = repD10Cat4Brd3
 
repD10Cat4 /: braidedCategory[repD10Cat4, 4] = repD10Cat4Brd4
 
repD10Cat4 /: braidedCategory[repD10Cat4, 5] = repD10Cat4Brd5
 
repD10Cat4 /: braidedCategory[repD10Cat4, 6] = repD10Cat4Brd6
 
repD10Cat4 /: braidedCategory[repD10Cat4, 7] = repD10Cat4Brd7
 
repD10Cat4 /: braidedCategory[repD10Cat4, 8] = repD10Cat4Brd8
 
repD10Cat4 /: braidedCategory[repD10Cat4, 9] = repD10Cat4Brd9
 
repD10Cat4 /: braidedCategory[repD10Cat4, 10] = repD10Cat4Brd10
 
coeval[repD10Cat4] ^= 1/sixJFunction[repD10Cat4][#1, 
      dual[ring[repD10Cat4]][#1], #1, #1, 0, 0] & 
 
eval[repD10Cat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[repD10Cat4] ^= repD10Cat4FMatrixFunction
 
fusionCategory[repD10Cat4] ^= repD10Cat4
 
repD10Cat4 /: modularCategory[repD10Cat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[repD10Cat4] ^= {repD10Cat4Piv1, repD10Cat4Piv2}
 
repD10Cat4 /: pivotalCategory[repD10Cat4, 1] = repD10Cat4Piv1
 
repD10Cat4 /: pivotalCategory[repD10Cat4, 2] = repD10Cat4Piv2
 
repD10Cat4 /: pivotalCategory[repD10Cat4, {1, -1, 1, -1, 1, 1, 1, 1}] = 
    repD10Cat4Piv2
 
repD10Cat4 /: pivotalCategory[repD10Cat4, {1, 1, 1, 1, 1, -1, 1, -1}] = 
    repD10Cat4Piv1
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 1] = repD10Cat4Bal1
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 2] = repD10Cat4Bal2
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 3] = repD10Cat4Bal3
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 4] = repD10Cat4Bal4
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 5] = repD10Cat4Bal5
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 6] = repD10Cat4Bal6
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 7] = repD10Cat4Bal7
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 8] = repD10Cat4Bal8
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 9] = repD10Cat4Bal9
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 10] = repD10Cat4Bal10
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 11] = repD10Cat4Bal11
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 12] = repD10Cat4Bal12
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 13] = repD10Cat4Bal13
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 14] = repD10Cat4Bal14
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 15] = repD10Cat4Bal15
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 16] = repD10Cat4Bal16
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 17] = repD10Cat4Bal17
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 18] = repD10Cat4Bal18
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 19] = repD10Cat4Bal19
 
repD10Cat4 /: ribbonCategory[repD10Cat4, 20] = repD10Cat4Bal20
 
ring[repD10Cat4] ^= repD10
 
repD10Cat4 /: sphericalCategory[repD10Cat4, 1] = repD10Cat4Piv1
 
repD10Cat4 /: sphericalCategory[repD10Cat4, 2] = repD10Cat4Piv2
 
fusionCategoryIndex[repD10][repD10Cat4] ^= 4
balancedCategory[repD10Cat4Bal1] ^= repD10Cat4Bal1
 
braidedCategory[repD10Cat4Bal1] ^= repD10Cat4Brd1
 
fusionCategory[repD10Cat4Bal1] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal1] ^= repD10Cat4Piv1
 
ribbonCategory[repD10Cat4Bal1] ^= repD10Cat4Bal1
 
ring[repD10Cat4Bal1] ^= repD10
 
sphericalCategory[repD10Cat4Bal1] ^= repD10Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd1]][
      balancedCategory[#1]] & )[repD10Cat4Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv1]][
      balancedCategory[#1]] & )[repD10Cat4Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd1]][ribbonCategory[#1]] & )[
    repD10Cat4Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv1]][
      ribbonCategory[#1]] & )[repD10Cat4Bal1] ^= 1
balancedCategory[repD10Cat4Bal10] ^= repD10Cat4Bal10
 
braidedCategory[repD10Cat4Bal10] ^= repD10Cat4Brd5
 
fusionCategory[repD10Cat4Bal10] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal10] ^= repD10Cat4Piv2
 
ribbonCategory[repD10Cat4Bal10] ^= repD10Cat4Bal10
 
ring[repD10Cat4Bal10] ^= repD10
 
sphericalCategory[repD10Cat4Bal10] ^= repD10Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd5]][
      balancedCategory[#1]] & )[repD10Cat4Bal10] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal10] ^= 10
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv2]][
      balancedCategory[#1]] & )[repD10Cat4Bal10] ^= 5
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd5]][ribbonCategory[#1]] & )[
    repD10Cat4Bal10] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal10] ^= 10
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv2]][
      ribbonCategory[#1]] & )[repD10Cat4Bal10] ^= 5
balancedCategory[repD10Cat4Bal11] ^= repD10Cat4Bal11
 
braidedCategory[repD10Cat4Bal11] ^= repD10Cat4Brd6
 
fusionCategory[repD10Cat4Bal11] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal11] ^= repD10Cat4Piv1
 
ribbonCategory[repD10Cat4Bal11] ^= repD10Cat4Bal11
 
ring[repD10Cat4Bal11] ^= repD10
 
sphericalCategory[repD10Cat4Bal11] ^= repD10Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd6]][
      balancedCategory[#1]] & )[repD10Cat4Bal11] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal11] ^= 11
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv1]][
      balancedCategory[#1]] & )[repD10Cat4Bal11] ^= 6
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd6]][ribbonCategory[#1]] & )[
    repD10Cat4Bal11] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal11] ^= 11
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv1]][
      ribbonCategory[#1]] & )[repD10Cat4Bal11] ^= 6
balancedCategory[repD10Cat4Bal12] ^= repD10Cat4Bal12
 
braidedCategory[repD10Cat4Bal12] ^= repD10Cat4Brd6
 
fusionCategory[repD10Cat4Bal12] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal12] ^= repD10Cat4Piv2
 
ribbonCategory[repD10Cat4Bal12] ^= repD10Cat4Bal12
 
ring[repD10Cat4Bal12] ^= repD10
 
sphericalCategory[repD10Cat4Bal12] ^= repD10Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd6]][
      balancedCategory[#1]] & )[repD10Cat4Bal12] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal12] ^= 12
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv2]][
      balancedCategory[#1]] & )[repD10Cat4Bal12] ^= 6
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd6]][ribbonCategory[#1]] & )[
    repD10Cat4Bal12] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal12] ^= 12
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv2]][
      ribbonCategory[#1]] & )[repD10Cat4Bal12] ^= 6
balancedCategory[repD10Cat4Bal13] ^= repD10Cat4Bal13
 
braidedCategory[repD10Cat4Bal13] ^= repD10Cat4Brd7
 
fusionCategory[repD10Cat4Bal13] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal13] ^= repD10Cat4Piv1
 
ribbonCategory[repD10Cat4Bal13] ^= repD10Cat4Bal13
 
ring[repD10Cat4Bal13] ^= repD10
 
sphericalCategory[repD10Cat4Bal13] ^= repD10Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd7]][
      balancedCategory[#1]] & )[repD10Cat4Bal13] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal13] ^= 13
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv1]][
      balancedCategory[#1]] & )[repD10Cat4Bal13] ^= 7
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd7]][ribbonCategory[#1]] & )[
    repD10Cat4Bal13] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal13] ^= 13
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv1]][
      ribbonCategory[#1]] & )[repD10Cat4Bal13] ^= 7
balancedCategory[repD10Cat4Bal14] ^= repD10Cat4Bal14
 
braidedCategory[repD10Cat4Bal14] ^= repD10Cat4Brd7
 
fusionCategory[repD10Cat4Bal14] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal14] ^= repD10Cat4Piv2
 
ribbonCategory[repD10Cat4Bal14] ^= repD10Cat4Bal14
 
ring[repD10Cat4Bal14] ^= repD10
 
sphericalCategory[repD10Cat4Bal14] ^= repD10Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd7]][
      balancedCategory[#1]] & )[repD10Cat4Bal14] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal14] ^= 14
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv2]][
      balancedCategory[#1]] & )[repD10Cat4Bal14] ^= 7
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd7]][ribbonCategory[#1]] & )[
    repD10Cat4Bal14] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal14] ^= 14
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv2]][
      ribbonCategory[#1]] & )[repD10Cat4Bal14] ^= 7
balancedCategory[repD10Cat4Bal15] ^= repD10Cat4Bal15
 
braidedCategory[repD10Cat4Bal15] ^= repD10Cat4Brd8
 
fusionCategory[repD10Cat4Bal15] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal15] ^= repD10Cat4Piv1
 
ribbonCategory[repD10Cat4Bal15] ^= repD10Cat4Bal15
 
ring[repD10Cat4Bal15] ^= repD10
 
sphericalCategory[repD10Cat4Bal15] ^= repD10Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd8]][
      balancedCategory[#1]] & )[repD10Cat4Bal15] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal15] ^= 15
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv1]][
      balancedCategory[#1]] & )[repD10Cat4Bal15] ^= 8
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd8]][ribbonCategory[#1]] & )[
    repD10Cat4Bal15] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal15] ^= 15
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv1]][
      ribbonCategory[#1]] & )[repD10Cat4Bal15] ^= 8
balancedCategory[repD10Cat4Bal16] ^= repD10Cat4Bal16
 
braidedCategory[repD10Cat4Bal16] ^= repD10Cat4Brd8
 
fusionCategory[repD10Cat4Bal16] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal16] ^= repD10Cat4Piv2
 
ribbonCategory[repD10Cat4Bal16] ^= repD10Cat4Bal16
 
ring[repD10Cat4Bal16] ^= repD10
 
sphericalCategory[repD10Cat4Bal16] ^= repD10Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd8]][
      balancedCategory[#1]] & )[repD10Cat4Bal16] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal16] ^= 16
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv2]][
      balancedCategory[#1]] & )[repD10Cat4Bal16] ^= 8
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd8]][ribbonCategory[#1]] & )[
    repD10Cat4Bal16] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal16] ^= 16
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv2]][
      ribbonCategory[#1]] & )[repD10Cat4Bal16] ^= 8
balancedCategory[repD10Cat4Bal17] ^= repD10Cat4Bal17
 
braidedCategory[repD10Cat4Bal17] ^= repD10Cat4Brd9
 
fusionCategory[repD10Cat4Bal17] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal17] ^= repD10Cat4Piv1
 
ribbonCategory[repD10Cat4Bal17] ^= repD10Cat4Bal17
 
ring[repD10Cat4Bal17] ^= repD10
 
sphericalCategory[repD10Cat4Bal17] ^= repD10Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd9]][
      balancedCategory[#1]] & )[repD10Cat4Bal17] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal17] ^= 17
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv1]][
      balancedCategory[#1]] & )[repD10Cat4Bal17] ^= 9
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd9]][ribbonCategory[#1]] & )[
    repD10Cat4Bal17] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal17] ^= 17
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv1]][
      ribbonCategory[#1]] & )[repD10Cat4Bal17] ^= 9
balancedCategory[repD10Cat4Bal18] ^= repD10Cat4Bal18
 
braidedCategory[repD10Cat4Bal18] ^= repD10Cat4Brd9
 
fusionCategory[repD10Cat4Bal18] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal18] ^= repD10Cat4Piv2
 
ribbonCategory[repD10Cat4Bal18] ^= repD10Cat4Bal18
 
ring[repD10Cat4Bal18] ^= repD10
 
sphericalCategory[repD10Cat4Bal18] ^= repD10Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd9]][
      balancedCategory[#1]] & )[repD10Cat4Bal18] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal18] ^= 18
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv2]][
      balancedCategory[#1]] & )[repD10Cat4Bal18] ^= 9
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd9]][ribbonCategory[#1]] & )[
    repD10Cat4Bal18] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal18] ^= 18
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv2]][
      ribbonCategory[#1]] & )[repD10Cat4Bal18] ^= 9
balancedCategory[repD10Cat4Bal19] ^= repD10Cat4Bal19
 
braidedCategory[repD10Cat4Bal19] ^= repD10Cat4Brd10
 
fusionCategory[repD10Cat4Bal19] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal19] ^= repD10Cat4Piv1
 
ribbonCategory[repD10Cat4Bal19] ^= repD10Cat4Bal19
 
ring[repD10Cat4Bal19] ^= repD10
 
sphericalCategory[repD10Cat4Bal19] ^= repD10Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd10]][
      balancedCategory[#1]] & )[repD10Cat4Bal19] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal19] ^= 19
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv1]][
      balancedCategory[#1]] & )[repD10Cat4Bal19] ^= 10
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd10]][
      ribbonCategory[#1]] & )[repD10Cat4Bal19] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal19] ^= 19
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv1]][
      ribbonCategory[#1]] & )[repD10Cat4Bal19] ^= 10
balancedCategory[repD10Cat4Bal2] ^= repD10Cat4Bal2
 
braidedCategory[repD10Cat4Bal2] ^= repD10Cat4Brd1
 
fusionCategory[repD10Cat4Bal2] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal2] ^= repD10Cat4Piv2
 
ribbonCategory[repD10Cat4Bal2] ^= repD10Cat4Bal2
 
ring[repD10Cat4Bal2] ^= repD10
 
sphericalCategory[repD10Cat4Bal2] ^= repD10Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd1]][
      balancedCategory[#1]] & )[repD10Cat4Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv2]][
      balancedCategory[#1]] & )[repD10Cat4Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd1]][ribbonCategory[#1]] & )[
    repD10Cat4Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv2]][
      ribbonCategory[#1]] & )[repD10Cat4Bal2] ^= 1
balancedCategory[repD10Cat4Bal20] ^= repD10Cat4Bal20
 
braidedCategory[repD10Cat4Bal20] ^= repD10Cat4Brd10
 
fusionCategory[repD10Cat4Bal20] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal20] ^= repD10Cat4Piv2
 
ribbonCategory[repD10Cat4Bal20] ^= repD10Cat4Bal20
 
ring[repD10Cat4Bal20] ^= repD10
 
sphericalCategory[repD10Cat4Bal20] ^= repD10Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd10]][
      balancedCategory[#1]] & )[repD10Cat4Bal20] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal20] ^= 20
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv2]][
      balancedCategory[#1]] & )[repD10Cat4Bal20] ^= 10
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd10]][
      ribbonCategory[#1]] & )[repD10Cat4Bal20] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal20] ^= 20
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv2]][
      ribbonCategory[#1]] & )[repD10Cat4Bal20] ^= 10
balancedCategory[repD10Cat4Bal3] ^= repD10Cat4Bal3
 
braidedCategory[repD10Cat4Bal3] ^= repD10Cat4Brd2
 
fusionCategory[repD10Cat4Bal3] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal3] ^= repD10Cat4Piv1
 
ribbonCategory[repD10Cat4Bal3] ^= repD10Cat4Bal3
 
ring[repD10Cat4Bal3] ^= repD10
 
sphericalCategory[repD10Cat4Bal3] ^= repD10Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd2]][
      balancedCategory[#1]] & )[repD10Cat4Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv1]][
      balancedCategory[#1]] & )[repD10Cat4Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd2]][ribbonCategory[#1]] & )[
    repD10Cat4Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv1]][
      ribbonCategory[#1]] & )[repD10Cat4Bal3] ^= 2
balancedCategory[repD10Cat4Bal4] ^= repD10Cat4Bal4
 
braidedCategory[repD10Cat4Bal4] ^= repD10Cat4Brd2
 
fusionCategory[repD10Cat4Bal4] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal4] ^= repD10Cat4Piv2
 
ribbonCategory[repD10Cat4Bal4] ^= repD10Cat4Bal4
 
ring[repD10Cat4Bal4] ^= repD10
 
sphericalCategory[repD10Cat4Bal4] ^= repD10Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd2]][
      balancedCategory[#1]] & )[repD10Cat4Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv2]][
      balancedCategory[#1]] & )[repD10Cat4Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd2]][ribbonCategory[#1]] & )[
    repD10Cat4Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv2]][
      ribbonCategory[#1]] & )[repD10Cat4Bal4] ^= 2
balancedCategory[repD10Cat4Bal5] ^= repD10Cat4Bal5
 
braidedCategory[repD10Cat4Bal5] ^= repD10Cat4Brd3
 
fusionCategory[repD10Cat4Bal5] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal5] ^= repD10Cat4Piv1
 
ribbonCategory[repD10Cat4Bal5] ^= repD10Cat4Bal5
 
ring[repD10Cat4Bal5] ^= repD10
 
sphericalCategory[repD10Cat4Bal5] ^= repD10Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd3]][
      balancedCategory[#1]] & )[repD10Cat4Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv1]][
      balancedCategory[#1]] & )[repD10Cat4Bal5] ^= 3
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd3]][ribbonCategory[#1]] & )[
    repD10Cat4Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv1]][
      ribbonCategory[#1]] & )[repD10Cat4Bal5] ^= 3
balancedCategory[repD10Cat4Bal6] ^= repD10Cat4Bal6
 
braidedCategory[repD10Cat4Bal6] ^= repD10Cat4Brd3
 
fusionCategory[repD10Cat4Bal6] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal6] ^= repD10Cat4Piv2
 
ribbonCategory[repD10Cat4Bal6] ^= repD10Cat4Bal6
 
ring[repD10Cat4Bal6] ^= repD10
 
sphericalCategory[repD10Cat4Bal6] ^= repD10Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd3]][
      balancedCategory[#1]] & )[repD10Cat4Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv2]][
      balancedCategory[#1]] & )[repD10Cat4Bal6] ^= 3
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd3]][ribbonCategory[#1]] & )[
    repD10Cat4Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv2]][
      ribbonCategory[#1]] & )[repD10Cat4Bal6] ^= 3
balancedCategory[repD10Cat4Bal7] ^= repD10Cat4Bal7
 
braidedCategory[repD10Cat4Bal7] ^= repD10Cat4Brd4
 
fusionCategory[repD10Cat4Bal7] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal7] ^= repD10Cat4Piv1
 
ribbonCategory[repD10Cat4Bal7] ^= repD10Cat4Bal7
 
ring[repD10Cat4Bal7] ^= repD10
 
sphericalCategory[repD10Cat4Bal7] ^= repD10Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd4]][
      balancedCategory[#1]] & )[repD10Cat4Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv1]][
      balancedCategory[#1]] & )[repD10Cat4Bal7] ^= 4
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv1]][
      ribbonCategory[#1]] & )[repD10Cat4Bal7] ^= 4
balancedCategory[repD10Cat4Bal8] ^= repD10Cat4Bal8
 
braidedCategory[repD10Cat4Bal8] ^= repD10Cat4Brd4
 
fusionCategory[repD10Cat4Bal8] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal8] ^= repD10Cat4Piv2
 
ribbonCategory[repD10Cat4Bal8] ^= repD10Cat4Bal8
 
ring[repD10Cat4Bal8] ^= repD10
 
sphericalCategory[repD10Cat4Bal8] ^= repD10Cat4Piv2
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd4]][
      balancedCategory[#1]] & )[repD10Cat4Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv2]][
      balancedCategory[#1]] & )[repD10Cat4Bal8] ^= 4
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv2]][
      ribbonCategory[#1]] & )[repD10Cat4Bal8] ^= 4
balancedCategory[repD10Cat4Bal9] ^= repD10Cat4Bal9
 
braidedCategory[repD10Cat4Bal9] ^= repD10Cat4Brd5
 
fusionCategory[repD10Cat4Bal9] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Bal9] ^= repD10Cat4Piv1
 
ribbonCategory[repD10Cat4Bal9] ^= repD10Cat4Bal9
 
ring[repD10Cat4Bal9] ^= repD10
 
sphericalCategory[repD10Cat4Bal9] ^= repD10Cat4Piv1
 
(balancedCategoryIndex[braidedCategory[repD10Cat4Brd5]][
      balancedCategory[#1]] & )[repD10Cat4Bal9] ^= 1
 
(balancedCategoryIndex[fusionCategory[repD10Cat4]][balancedCategory[#1]] & )[
    repD10Cat4Bal9] ^= 9
 
(balancedCategoryIndex[pivotalCategory[repD10Cat4Piv1]][
      balancedCategory[#1]] & )[repD10Cat4Bal9] ^= 5
 
(ribbonCategoryIndex[braidedCategory[repD10Cat4Brd5]][ribbonCategory[#1]] & )[
    repD10Cat4Bal9] ^= 1
 
(ribbonCategoryIndex[fusionCategory[repD10Cat4]][ribbonCategory[#1]] & )[
    repD10Cat4Bal9] ^= 9
 
(ribbonCategoryIndex[sphericalCategory[repD10Cat4Piv1]][
      ribbonCategory[#1]] & )[repD10Cat4Bal9] ^= 5
balancedCategories[repD10Cat4Brd1] ^= {repD10Cat4Bal1, repD10Cat4Bal2}
 
repD10Cat4Brd1 /: balancedCategory[repD10Cat4Brd1, 1] = repD10Cat4Bal1
 
repD10Cat4Brd1 /: balancedCategory[repD10Cat4Brd1, 2] = repD10Cat4Bal2
 
braidedCategory[repD10Cat4Brd1] ^= repD10Cat4Brd1
 
fusionCategory[repD10Cat4Brd1] ^= repD10Cat4
 
repD10Cat4Brd1 /: modularCategory[repD10Cat4Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat4Brd1 /: ribbonCategory[repD10Cat4Brd1, 1] = repD10Cat4Bal1
 
repD10Cat4Brd1 /: ribbonCategory[repD10Cat4Brd1, 2] = repD10Cat4Bal2
 
ring[repD10Cat4Brd1] ^= repD10
 
rMatrixFunction[repD10Cat4Brd1] ^= repD10Cat4Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD10Cat4]][braidedCategory[#1]] & )[
    repD10Cat4Brd1] ^= 1
balancedCategories[repD10Cat4Brd10] ^= {repD10Cat4Bal19, repD10Cat4Bal20}
 
repD10Cat4Brd10 /: balancedCategory[repD10Cat4Brd10, 1] = repD10Cat4Bal19
 
repD10Cat4Brd10 /: balancedCategory[repD10Cat4Brd10, 2] = repD10Cat4Bal20
 
braidedCategory[repD10Cat4Brd10] ^= repD10Cat4Brd10
 
fusionCategory[repD10Cat4Brd10] ^= repD10Cat4
 
repD10Cat4Brd10 /: modularCategory[repD10Cat4Brd10, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat4Brd10 /: ribbonCategory[repD10Cat4Brd10, 1] = repD10Cat4Bal19
 
repD10Cat4Brd10 /: ribbonCategory[repD10Cat4Brd10, 2] = repD10Cat4Bal20
 
ring[repD10Cat4Brd10] ^= repD10
 
rMatrixFunction[repD10Cat4Brd10] ^= repD10Cat4Brd10RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD10Cat4]][braidedCategory[#1]] & )[
    repD10Cat4Brd10] ^= 10
braidedCategory[repD10Cat4Brd10RMatrixFunction] ^= repD10Cat4Brd10
 
fusionCategory[repD10Cat4Brd10RMatrixFunction] ^= repD10Cat4
 
rMatrixFunction[repD10Cat4Brd10RMatrixFunction] ^= 
   repD10Cat4Brd10RMatrixFunction
 
repD10Cat4Brd10RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[1, 1, 2] = {{-I}}
 
repD10Cat4Brd10RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[1, 3, 0] = {{-I}}
 
repD10Cat4Brd10RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[1, 5, 4] = {{-I}}
 
repD10Cat4Brd10RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat4Brd10RMatrixFunction[1, 7, 6] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[3, 1, 0] = {{-I}}
 
repD10Cat4Brd10RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[3, 3, 2] = {{-I}}
 
repD10Cat4Brd10RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[3, 5, 4] = {{-I}}
 
repD10Cat4Brd10RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat4Brd10RMatrixFunction[3, 7, 6] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[4, 4, 0] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd10RMatrixFunction[4, 4, 2] = {{(-1)^(3/5)}}
 
repD10Cat4Brd10RMatrixFunction[4, 4, 6] = {{(-1)^(2/5)}}
 
repD10Cat4Brd10RMatrixFunction[4, 5, 1] = {{(-1)^(1/10)}}
 
repD10Cat4Brd10RMatrixFunction[4, 5, 3] = {{(-1)^(1/10)}}
 
repD10Cat4Brd10RMatrixFunction[4, 5, 7] = {{(-1)^(2/5)}}
 
repD10Cat4Brd10RMatrixFunction[4, 6, 4] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd10RMatrixFunction[4, 6, 6] = {{(-1)^(4/5)}}
 
repD10Cat4Brd10RMatrixFunction[4, 7, 5] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd10RMatrixFunction[4, 7, 7] = {{(-1)^(4/5)}}
 
repD10Cat4Brd10RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[5, 1, 4] = {{-I}}
 
repD10Cat4Brd10RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[5, 3, 4] = {{-I}}
 
repD10Cat4Brd10RMatrixFunction[5, 4, 1] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd10RMatrixFunction[5, 4, 3] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd10RMatrixFunction[5, 4, 7] = {{(-1)^(2/5)}}
 
repD10Cat4Brd10RMatrixFunction[5, 5, 0] = {{(-1)^(1/10)}}
 
repD10Cat4Brd10RMatrixFunction[5, 5, 2] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd10RMatrixFunction[5, 5, 6] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd10RMatrixFunction[5, 6, 5] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd10RMatrixFunction[5, 6, 7] = {{(-1)^(3/10)}}
 
repD10Cat4Brd10RMatrixFunction[5, 7, 4] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd10RMatrixFunction[5, 7, 6] = {{-(-1)^(4/5)}}
 
repD10Cat4Brd10RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat4Brd10RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat4Brd10RMatrixFunction[6, 4, 4] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd10RMatrixFunction[6, 4, 6] = {{(-1)^(4/5)}}
 
repD10Cat4Brd10RMatrixFunction[6, 5, 5] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd10RMatrixFunction[6, 5, 7] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd10RMatrixFunction[6, 6, 0] = {{(-1)^(2/5)}}
 
repD10Cat4Brd10RMatrixFunction[6, 6, 2] = {{-(-1)^(2/5)}}
 
repD10Cat4Brd10RMatrixFunction[6, 6, 4] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd10RMatrixFunction[6, 7, 1] = {{(-1)^(9/10)}}
 
repD10Cat4Brd10RMatrixFunction[6, 7, 3] = {{(-1)^(9/10)}}
 
repD10Cat4Brd10RMatrixFunction[6, 7, 5] = {{(-1)^(1/10)}}
 
repD10Cat4Brd10RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[7, 1, 6] = {{-1}}
 
repD10Cat4Brd10RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat4Brd10RMatrixFunction[7, 3, 6] = {{-1}}
 
repD10Cat4Brd10RMatrixFunction[7, 4, 5] = {{(-1)^(7/10)}}
 
repD10Cat4Brd10RMatrixFunction[7, 4, 7] = {{(-1)^(4/5)}}
 
repD10Cat4Brd10RMatrixFunction[7, 5, 4] = {{(-1)^(1/5)}}
 
repD10Cat4Brd10RMatrixFunction[7, 5, 6] = {{(-1)^(4/5)}}
 
repD10Cat4Brd10RMatrixFunction[7, 6, 1] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd10RMatrixFunction[7, 6, 3] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd10RMatrixFunction[7, 6, 5] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd10RMatrixFunction[7, 7, 0] = {{(-1)^(9/10)}}
 
repD10Cat4Brd10RMatrixFunction[7, 7, 2] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd10RMatrixFunction[7, 7, 4] = {{-(-1)^(1/10)}}
braidedCategory[repD10Cat4Brd1RMatrixFunction] ^= repD10Cat4Brd1
 
fusionCategory[repD10Cat4Brd1RMatrixFunction] ^= repD10Cat4
 
rMatrixFunction[repD10Cat4Brd1RMatrixFunction] ^= 
   repD10Cat4Brd1RMatrixFunction
 
repD10Cat4Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[1, 1, 2] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[1, 3, 0] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[1, 5, 4] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat4Brd1RMatrixFunction[1, 7, 6] = {{-1}}
 
repD10Cat4Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[3, 1, 0] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[3, 3, 2] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[3, 5, 4] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat4Brd1RMatrixFunction[3, 7, 6] = {{-1}}
 
repD10Cat4Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[4, 4, 0] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[4, 4, 2] = {{-1}}
 
repD10Cat4Brd1RMatrixFunction[4, 4, 6] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[4, 5, 1] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[4, 5, 3] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[4, 5, 7] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[4, 6, 4] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[4, 6, 6] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[4, 7, 5] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[4, 7, 7] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[5, 1, 4] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[5, 3, 4] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[5, 4, 1] = {{-I}}
 
repD10Cat4Brd1RMatrixFunction[5, 4, 3] = {{-I}}
 
repD10Cat4Brd1RMatrixFunction[5, 4, 7] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[5, 5, 0] = {{-I}}
 
repD10Cat4Brd1RMatrixFunction[5, 5, 2] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[5, 5, 6] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[5, 6, 5] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[5, 6, 7] = {{-I}}
 
repD10Cat4Brd1RMatrixFunction[5, 7, 4] = {{-1}}
 
repD10Cat4Brd1RMatrixFunction[5, 7, 6] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[6, 4, 4] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[6, 4, 6] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[6, 5, 5] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[6, 5, 7] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[6, 6, 0] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[6, 6, 2] = {{-1}}
 
repD10Cat4Brd1RMatrixFunction[6, 6, 4] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[6, 7, 1] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[6, 7, 3] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[6, 7, 5] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[7, 1, 6] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[7, 3, 6] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[7, 4, 5] = {{-I}}
 
repD10Cat4Brd1RMatrixFunction[7, 4, 7] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[7, 5, 4] = {{1}}
 
repD10Cat4Brd1RMatrixFunction[7, 5, 6] = {{-1}}
 
repD10Cat4Brd1RMatrixFunction[7, 6, 1] = {{-I}}
 
repD10Cat4Brd1RMatrixFunction[7, 6, 3] = {{-I}}
 
repD10Cat4Brd1RMatrixFunction[7, 6, 5] = {{-I}}
 
repD10Cat4Brd1RMatrixFunction[7, 7, 0] = {{-I}}
 
repD10Cat4Brd1RMatrixFunction[7, 7, 2] = {{I}}
 
repD10Cat4Brd1RMatrixFunction[7, 7, 4] = {{I}}
balancedCategories[repD10Cat4Brd2] ^= {repD10Cat4Bal3, repD10Cat4Bal4}
 
repD10Cat4Brd2 /: balancedCategory[repD10Cat4Brd2, 1] = repD10Cat4Bal3
 
repD10Cat4Brd2 /: balancedCategory[repD10Cat4Brd2, 2] = repD10Cat4Bal4
 
braidedCategory[repD10Cat4Brd2] ^= repD10Cat4Brd2
 
fusionCategory[repD10Cat4Brd2] ^= repD10Cat4
 
repD10Cat4Brd2 /: modularCategory[repD10Cat4Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat4Brd2 /: ribbonCategory[repD10Cat4Brd2, 1] = repD10Cat4Bal3
 
repD10Cat4Brd2 /: ribbonCategory[repD10Cat4Brd2, 2] = repD10Cat4Bal4
 
ring[repD10Cat4Brd2] ^= repD10
 
rMatrixFunction[repD10Cat4Brd2] ^= repD10Cat4Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD10Cat4]][braidedCategory[#1]] & )[
    repD10Cat4Brd2] ^= 2
braidedCategory[repD10Cat4Brd2RMatrixFunction] ^= repD10Cat4Brd2
 
fusionCategory[repD10Cat4Brd2RMatrixFunction] ^= repD10Cat4
 
rMatrixFunction[repD10Cat4Brd2RMatrixFunction] ^= 
   repD10Cat4Brd2RMatrixFunction
 
repD10Cat4Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[1, 1, 2] = {{I}}
 
repD10Cat4Brd2RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[1, 3, 0] = {{I}}
 
repD10Cat4Brd2RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[1, 5, 4] = {{I}}
 
repD10Cat4Brd2RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat4Brd2RMatrixFunction[1, 7, 6] = {{-1}}
 
repD10Cat4Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[3, 1, 0] = {{I}}
 
repD10Cat4Brd2RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[3, 3, 2] = {{I}}
 
repD10Cat4Brd2RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[3, 5, 4] = {{I}}
 
repD10Cat4Brd2RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat4Brd2RMatrixFunction[3, 7, 6] = {{-1}}
 
repD10Cat4Brd2RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[4, 4, 0] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd2RMatrixFunction[4, 4, 2] = {{(-1)^(3/5)}}
 
repD10Cat4Brd2RMatrixFunction[4, 4, 6] = {{(-1)^(2/5)}}
 
repD10Cat4Brd2RMatrixFunction[4, 5, 1] = {{(-1)^(1/10)}}
 
repD10Cat4Brd2RMatrixFunction[4, 5, 3] = {{(-1)^(1/10)}}
 
repD10Cat4Brd2RMatrixFunction[4, 5, 7] = {{(-1)^(2/5)}}
 
repD10Cat4Brd2RMatrixFunction[4, 6, 4] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd2RMatrixFunction[4, 6, 6] = {{(-1)^(4/5)}}
 
repD10Cat4Brd2RMatrixFunction[4, 7, 5] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd2RMatrixFunction[4, 7, 7] = {{(-1)^(4/5)}}
 
repD10Cat4Brd2RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[5, 1, 4] = {{I}}
 
repD10Cat4Brd2RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[5, 3, 4] = {{I}}
 
repD10Cat4Brd2RMatrixFunction[5, 4, 1] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd2RMatrixFunction[5, 4, 3] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd2RMatrixFunction[5, 4, 7] = {{(-1)^(2/5)}}
 
repD10Cat4Brd2RMatrixFunction[5, 5, 0] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd2RMatrixFunction[5, 5, 2] = {{(-1)^(1/10)}}
 
repD10Cat4Brd2RMatrixFunction[5, 5, 6] = {{(-1)^(9/10)}}
 
repD10Cat4Brd2RMatrixFunction[5, 6, 5] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd2RMatrixFunction[5, 6, 7] = {{(-1)^(3/10)}}
 
repD10Cat4Brd2RMatrixFunction[5, 7, 4] = {{(-1)^(1/5)}}
 
repD10Cat4Brd2RMatrixFunction[5, 7, 6] = {{(-1)^(4/5)}}
 
repD10Cat4Brd2RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat4Brd2RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat4Brd2RMatrixFunction[6, 4, 4] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd2RMatrixFunction[6, 4, 6] = {{(-1)^(4/5)}}
 
repD10Cat4Brd2RMatrixFunction[6, 5, 5] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd2RMatrixFunction[6, 5, 7] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd2RMatrixFunction[6, 6, 0] = {{(-1)^(2/5)}}
 
repD10Cat4Brd2RMatrixFunction[6, 6, 2] = {{-(-1)^(2/5)}}
 
repD10Cat4Brd2RMatrixFunction[6, 6, 4] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd2RMatrixFunction[6, 7, 1] = {{(-1)^(9/10)}}
 
repD10Cat4Brd2RMatrixFunction[6, 7, 3] = {{(-1)^(9/10)}}
 
repD10Cat4Brd2RMatrixFunction[6, 7, 5] = {{(-1)^(1/10)}}
 
repD10Cat4Brd2RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[7, 1, 6] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[7, 3, 6] = {{1}}
 
repD10Cat4Brd2RMatrixFunction[7, 4, 5] = {{(-1)^(7/10)}}
 
repD10Cat4Brd2RMatrixFunction[7, 4, 7] = {{(-1)^(4/5)}}
 
repD10Cat4Brd2RMatrixFunction[7, 5, 4] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd2RMatrixFunction[7, 5, 6] = {{-(-1)^(4/5)}}
 
repD10Cat4Brd2RMatrixFunction[7, 6, 1] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd2RMatrixFunction[7, 6, 3] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd2RMatrixFunction[7, 6, 5] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd2RMatrixFunction[7, 7, 0] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd2RMatrixFunction[7, 7, 2] = {{(-1)^(9/10)}}
 
repD10Cat4Brd2RMatrixFunction[7, 7, 4] = {{(-1)^(1/10)}}
balancedCategories[repD10Cat4Brd3] ^= {repD10Cat4Bal5, repD10Cat4Bal6}
 
repD10Cat4Brd3 /: balancedCategory[repD10Cat4Brd3, 1] = repD10Cat4Bal5
 
repD10Cat4Brd3 /: balancedCategory[repD10Cat4Brd3, 2] = repD10Cat4Bal6
 
braidedCategory[repD10Cat4Brd3] ^= repD10Cat4Brd3
 
fusionCategory[repD10Cat4Brd3] ^= repD10Cat4
 
repD10Cat4Brd3 /: modularCategory[repD10Cat4Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat4Brd3 /: ribbonCategory[repD10Cat4Brd3, 1] = repD10Cat4Bal5
 
repD10Cat4Brd3 /: ribbonCategory[repD10Cat4Brd3, 2] = repD10Cat4Bal6
 
ring[repD10Cat4Brd3] ^= repD10
 
rMatrixFunction[repD10Cat4Brd3] ^= repD10Cat4Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD10Cat4]][braidedCategory[#1]] & )[
    repD10Cat4Brd3] ^= 3
braidedCategory[repD10Cat4Brd3RMatrixFunction] ^= repD10Cat4Brd3
 
fusionCategory[repD10Cat4Brd3RMatrixFunction] ^= repD10Cat4
 
rMatrixFunction[repD10Cat4Brd3RMatrixFunction] ^= 
   repD10Cat4Brd3RMatrixFunction
 
repD10Cat4Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[1, 1, 2] = {{I}}
 
repD10Cat4Brd3RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[1, 3, 0] = {{I}}
 
repD10Cat4Brd3RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[1, 5, 4] = {{I}}
 
repD10Cat4Brd3RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat4Brd3RMatrixFunction[1, 7, 6] = {{-1}}
 
repD10Cat4Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[3, 1, 0] = {{I}}
 
repD10Cat4Brd3RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[3, 3, 2] = {{I}}
 
repD10Cat4Brd3RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[3, 5, 4] = {{I}}
 
repD10Cat4Brd3RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat4Brd3RMatrixFunction[3, 7, 6] = {{-1}}
 
repD10Cat4Brd3RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[4, 4, 0] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd3RMatrixFunction[4, 4, 2] = {{(-1)^(1/5)}}
 
repD10Cat4Brd3RMatrixFunction[4, 4, 6] = {{(-1)^(4/5)}}
 
repD10Cat4Brd3RMatrixFunction[4, 5, 1] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd3RMatrixFunction[4, 5, 3] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd3RMatrixFunction[4, 5, 7] = {{(-1)^(4/5)}}
 
repD10Cat4Brd3RMatrixFunction[4, 6, 4] = {{(-1)^(2/5)}}
 
repD10Cat4Brd3RMatrixFunction[4, 6, 6] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd3RMatrixFunction[4, 7, 5] = {{(-1)^(9/10)}}
 
repD10Cat4Brd3RMatrixFunction[4, 7, 7] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd3RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[5, 1, 4] = {{I}}
 
repD10Cat4Brd3RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[5, 3, 4] = {{I}}
 
repD10Cat4Brd3RMatrixFunction[5, 4, 1] = {{(-1)^(7/10)}}
 
repD10Cat4Brd3RMatrixFunction[5, 4, 3] = {{(-1)^(7/10)}}
 
repD10Cat4Brd3RMatrixFunction[5, 4, 7] = {{(-1)^(4/5)}}
 
repD10Cat4Brd3RMatrixFunction[5, 5, 0] = {{(-1)^(7/10)}}
 
repD10Cat4Brd3RMatrixFunction[5, 5, 2] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd3RMatrixFunction[5, 5, 6] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd3RMatrixFunction[5, 6, 5] = {{(-1)^(2/5)}}
 
repD10Cat4Brd3RMatrixFunction[5, 6, 7] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd3RMatrixFunction[5, 7, 4] = {{-(-1)^(2/5)}}
 
repD10Cat4Brd3RMatrixFunction[5, 7, 6] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd3RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat4Brd3RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat4Brd3RMatrixFunction[6, 4, 4] = {{(-1)^(2/5)}}
 
repD10Cat4Brd3RMatrixFunction[6, 4, 6] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd3RMatrixFunction[6, 5, 5] = {{(-1)^(2/5)}}
 
repD10Cat4Brd3RMatrixFunction[6, 5, 7] = {{(-1)^(1/10)}}
 
repD10Cat4Brd3RMatrixFunction[6, 6, 0] = {{(-1)^(4/5)}}
 
repD10Cat4Brd3RMatrixFunction[6, 6, 2] = {{-(-1)^(4/5)}}
 
repD10Cat4Brd3RMatrixFunction[6, 6, 4] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd3RMatrixFunction[6, 7, 1] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd3RMatrixFunction[6, 7, 3] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd3RMatrixFunction[6, 7, 5] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd3RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[7, 1, 6] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[7, 3, 6] = {{1}}
 
repD10Cat4Brd3RMatrixFunction[7, 4, 5] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd3RMatrixFunction[7, 4, 7] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd3RMatrixFunction[7, 5, 4] = {{(-1)^(2/5)}}
 
repD10Cat4Brd3RMatrixFunction[7, 5, 6] = {{(-1)^(3/5)}}
 
repD10Cat4Brd3RMatrixFunction[7, 6, 1] = {{(-1)^(3/10)}}
 
repD10Cat4Brd3RMatrixFunction[7, 6, 3] = {{(-1)^(3/10)}}
 
repD10Cat4Brd3RMatrixFunction[7, 6, 5] = {{(-1)^(7/10)}}
 
repD10Cat4Brd3RMatrixFunction[7, 7, 0] = {{(-1)^(3/10)}}
 
repD10Cat4Brd3RMatrixFunction[7, 7, 2] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd3RMatrixFunction[7, 7, 4] = {{-(-1)^(7/10)}}
balancedCategories[repD10Cat4Brd4] ^= {repD10Cat4Bal7, repD10Cat4Bal8}
 
repD10Cat4Brd4 /: balancedCategory[repD10Cat4Brd4, 1] = repD10Cat4Bal7
 
repD10Cat4Brd4 /: balancedCategory[repD10Cat4Brd4, 2] = repD10Cat4Bal8
 
braidedCategory[repD10Cat4Brd4] ^= repD10Cat4Brd4
 
fusionCategory[repD10Cat4Brd4] ^= repD10Cat4
 
repD10Cat4Brd4 /: modularCategory[repD10Cat4Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat4Brd4 /: ribbonCategory[repD10Cat4Brd4, 1] = repD10Cat4Bal7
 
repD10Cat4Brd4 /: ribbonCategory[repD10Cat4Brd4, 2] = repD10Cat4Bal8
 
ring[repD10Cat4Brd4] ^= repD10
 
rMatrixFunction[repD10Cat4Brd4] ^= repD10Cat4Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD10Cat4]][braidedCategory[#1]] & )[
    repD10Cat4Brd4] ^= 4
braidedCategory[repD10Cat4Brd4RMatrixFunction] ^= repD10Cat4Brd4
 
fusionCategory[repD10Cat4Brd4RMatrixFunction] ^= repD10Cat4
 
rMatrixFunction[repD10Cat4Brd4RMatrixFunction] ^= 
   repD10Cat4Brd4RMatrixFunction
 
repD10Cat4Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[1, 1, 2] = {{I}}
 
repD10Cat4Brd4RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[1, 3, 0] = {{I}}
 
repD10Cat4Brd4RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[1, 5, 4] = {{I}}
 
repD10Cat4Brd4RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat4Brd4RMatrixFunction[1, 7, 6] = {{-1}}
 
repD10Cat4Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[3, 1, 0] = {{I}}
 
repD10Cat4Brd4RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[3, 3, 2] = {{I}}
 
repD10Cat4Brd4RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[3, 5, 4] = {{I}}
 
repD10Cat4Brd4RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat4Brd4RMatrixFunction[3, 7, 6] = {{-1}}
 
repD10Cat4Brd4RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[4, 4, 0] = {{(-1)^(4/5)}}
 
repD10Cat4Brd4RMatrixFunction[4, 4, 2] = {{-(-1)^(4/5)}}
 
repD10Cat4Brd4RMatrixFunction[4, 4, 6] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd4RMatrixFunction[4, 5, 1] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd4RMatrixFunction[4, 5, 3] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd4RMatrixFunction[4, 5, 7] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd4RMatrixFunction[4, 6, 4] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd4RMatrixFunction[4, 6, 6] = {{(-1)^(2/5)}}
 
repD10Cat4Brd4RMatrixFunction[4, 7, 5] = {{(-1)^(1/10)}}
 
repD10Cat4Brd4RMatrixFunction[4, 7, 7] = {{(-1)^(2/5)}}
 
repD10Cat4Brd4RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[5, 1, 4] = {{I}}
 
repD10Cat4Brd4RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[5, 3, 4] = {{I}}
 
repD10Cat4Brd4RMatrixFunction[5, 4, 1] = {{(-1)^(3/10)}}
 
repD10Cat4Brd4RMatrixFunction[5, 4, 3] = {{(-1)^(3/10)}}
 
repD10Cat4Brd4RMatrixFunction[5, 4, 7] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd4RMatrixFunction[5, 5, 0] = {{(-1)^(3/10)}}
 
repD10Cat4Brd4RMatrixFunction[5, 5, 2] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd4RMatrixFunction[5, 5, 6] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd4RMatrixFunction[5, 6, 5] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd4RMatrixFunction[5, 6, 7] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd4RMatrixFunction[5, 7, 4] = {{(-1)^(3/5)}}
 
repD10Cat4Brd4RMatrixFunction[5, 7, 6] = {{(-1)^(2/5)}}
 
repD10Cat4Brd4RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat4Brd4RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat4Brd4RMatrixFunction[6, 4, 4] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd4RMatrixFunction[6, 4, 6] = {{(-1)^(2/5)}}
 
repD10Cat4Brd4RMatrixFunction[6, 5, 5] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd4RMatrixFunction[6, 5, 7] = {{(-1)^(9/10)}}
 
repD10Cat4Brd4RMatrixFunction[6, 6, 0] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd4RMatrixFunction[6, 6, 2] = {{(-1)^(1/5)}}
 
repD10Cat4Brd4RMatrixFunction[6, 6, 4] = {{(-1)^(4/5)}}
 
repD10Cat4Brd4RMatrixFunction[6, 7, 1] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd4RMatrixFunction[6, 7, 3] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd4RMatrixFunction[6, 7, 5] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd4RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[7, 1, 6] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[7, 3, 6] = {{1}}
 
repD10Cat4Brd4RMatrixFunction[7, 4, 5] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd4RMatrixFunction[7, 4, 7] = {{(-1)^(2/5)}}
 
repD10Cat4Brd4RMatrixFunction[7, 5, 4] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd4RMatrixFunction[7, 5, 6] = {{-(-1)^(2/5)}}
 
repD10Cat4Brd4RMatrixFunction[7, 6, 1] = {{(-1)^(7/10)}}
 
repD10Cat4Brd4RMatrixFunction[7, 6, 3] = {{(-1)^(7/10)}}
 
repD10Cat4Brd4RMatrixFunction[7, 6, 5] = {{(-1)^(3/10)}}
 
repD10Cat4Brd4RMatrixFunction[7, 7, 0] = {{(-1)^(7/10)}}
 
repD10Cat4Brd4RMatrixFunction[7, 7, 2] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd4RMatrixFunction[7, 7, 4] = {{-(-1)^(3/10)}}
balancedCategories[repD10Cat4Brd5] ^= {repD10Cat4Bal9, repD10Cat4Bal10}
 
repD10Cat4Brd5 /: balancedCategory[repD10Cat4Brd5, 1] = repD10Cat4Bal9
 
repD10Cat4Brd5 /: balancedCategory[repD10Cat4Brd5, 2] = repD10Cat4Bal10
 
braidedCategory[repD10Cat4Brd5] ^= repD10Cat4Brd5
 
fusionCategory[repD10Cat4Brd5] ^= repD10Cat4
 
repD10Cat4Brd5 /: modularCategory[repD10Cat4Brd5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat4Brd5 /: ribbonCategory[repD10Cat4Brd5, 1] = repD10Cat4Bal9
 
repD10Cat4Brd5 /: ribbonCategory[repD10Cat4Brd5, 2] = repD10Cat4Bal10
 
ring[repD10Cat4Brd5] ^= repD10
 
rMatrixFunction[repD10Cat4Brd5] ^= repD10Cat4Brd5RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD10Cat4]][braidedCategory[#1]] & )[
    repD10Cat4Brd5] ^= 5
braidedCategory[repD10Cat4Brd5RMatrixFunction] ^= repD10Cat4Brd5
 
fusionCategory[repD10Cat4Brd5RMatrixFunction] ^= repD10Cat4
 
rMatrixFunction[repD10Cat4Brd5RMatrixFunction] ^= 
   repD10Cat4Brd5RMatrixFunction
 
repD10Cat4Brd5RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[1, 1, 2] = {{I}}
 
repD10Cat4Brd5RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[1, 3, 0] = {{I}}
 
repD10Cat4Brd5RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[1, 5, 4] = {{I}}
 
repD10Cat4Brd5RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat4Brd5RMatrixFunction[1, 7, 6] = {{-1}}
 
repD10Cat4Brd5RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[3, 1, 0] = {{I}}
 
repD10Cat4Brd5RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[3, 3, 2] = {{I}}
 
repD10Cat4Brd5RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[3, 5, 4] = {{I}}
 
repD10Cat4Brd5RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat4Brd5RMatrixFunction[3, 7, 6] = {{-1}}
 
repD10Cat4Brd5RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[4, 4, 0] = {{(-1)^(2/5)}}
 
repD10Cat4Brd5RMatrixFunction[4, 4, 2] = {{-(-1)^(2/5)}}
 
repD10Cat4Brd5RMatrixFunction[4, 4, 6] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd5RMatrixFunction[4, 5, 1] = {{(-1)^(9/10)}}
 
repD10Cat4Brd5RMatrixFunction[4, 5, 3] = {{(-1)^(9/10)}}
 
repD10Cat4Brd5RMatrixFunction[4, 5, 7] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd5RMatrixFunction[4, 6, 4] = {{(-1)^(4/5)}}
 
repD10Cat4Brd5RMatrixFunction[4, 6, 6] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd5RMatrixFunction[4, 7, 5] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd5RMatrixFunction[4, 7, 7] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd5RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[5, 1, 4] = {{I}}
 
repD10Cat4Brd5RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[5, 3, 4] = {{I}}
 
repD10Cat4Brd5RMatrixFunction[5, 4, 1] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd5RMatrixFunction[5, 4, 3] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd5RMatrixFunction[5, 4, 7] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd5RMatrixFunction[5, 5, 0] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd5RMatrixFunction[5, 5, 2] = {{(-1)^(9/10)}}
 
repD10Cat4Brd5RMatrixFunction[5, 5, 6] = {{(-1)^(1/10)}}
 
repD10Cat4Brd5RMatrixFunction[5, 6, 5] = {{(-1)^(4/5)}}
 
repD10Cat4Brd5RMatrixFunction[5, 6, 7] = {{(-1)^(7/10)}}
 
repD10Cat4Brd5RMatrixFunction[5, 7, 4] = {{-(-1)^(4/5)}}
 
repD10Cat4Brd5RMatrixFunction[5, 7, 6] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd5RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat4Brd5RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat4Brd5RMatrixFunction[6, 4, 4] = {{(-1)^(4/5)}}
 
repD10Cat4Brd5RMatrixFunction[6, 4, 6] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd5RMatrixFunction[6, 5, 5] = {{(-1)^(4/5)}}
 
repD10Cat4Brd5RMatrixFunction[6, 5, 7] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd5RMatrixFunction[6, 6, 0] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd5RMatrixFunction[6, 6, 2] = {{(-1)^(3/5)}}
 
repD10Cat4Brd5RMatrixFunction[6, 6, 4] = {{(-1)^(2/5)}}
 
repD10Cat4Brd5RMatrixFunction[6, 7, 1] = {{(-1)^(1/10)}}
 
repD10Cat4Brd5RMatrixFunction[6, 7, 3] = {{(-1)^(1/10)}}
 
repD10Cat4Brd5RMatrixFunction[6, 7, 5] = {{(-1)^(9/10)}}
 
repD10Cat4Brd5RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[7, 1, 6] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[7, 3, 6] = {{1}}
 
repD10Cat4Brd5RMatrixFunction[7, 4, 5] = {{(-1)^(3/10)}}
 
repD10Cat4Brd5RMatrixFunction[7, 4, 7] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd5RMatrixFunction[7, 5, 4] = {{(-1)^(4/5)}}
 
repD10Cat4Brd5RMatrixFunction[7, 5, 6] = {{(-1)^(1/5)}}
 
repD10Cat4Brd5RMatrixFunction[7, 6, 1] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd5RMatrixFunction[7, 6, 3] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd5RMatrixFunction[7, 6, 5] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd5RMatrixFunction[7, 7, 0] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd5RMatrixFunction[7, 7, 2] = {{(-1)^(1/10)}}
 
repD10Cat4Brd5RMatrixFunction[7, 7, 4] = {{(-1)^(9/10)}}
balancedCategories[repD10Cat4Brd6] ^= {repD10Cat4Bal11, repD10Cat4Bal12}
 
repD10Cat4Brd6 /: balancedCategory[repD10Cat4Brd6, 1] = repD10Cat4Bal11
 
repD10Cat4Brd6 /: balancedCategory[repD10Cat4Brd6, 2] = repD10Cat4Bal12
 
braidedCategory[repD10Cat4Brd6] ^= repD10Cat4Brd6
 
fusionCategory[repD10Cat4Brd6] ^= repD10Cat4
 
repD10Cat4Brd6 /: modularCategory[repD10Cat4Brd6, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat4Brd6 /: ribbonCategory[repD10Cat4Brd6, 1] = repD10Cat4Bal11
 
repD10Cat4Brd6 /: ribbonCategory[repD10Cat4Brd6, 2] = repD10Cat4Bal12
 
ring[repD10Cat4Brd6] ^= repD10
 
rMatrixFunction[repD10Cat4Brd6] ^= repD10Cat4Brd6RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD10Cat4]][braidedCategory[#1]] & )[
    repD10Cat4Brd6] ^= 6
braidedCategory[repD10Cat4Brd6RMatrixFunction] ^= repD10Cat4Brd6
 
fusionCategory[repD10Cat4Brd6RMatrixFunction] ^= repD10Cat4
 
rMatrixFunction[repD10Cat4Brd6RMatrixFunction] ^= 
   repD10Cat4Brd6RMatrixFunction
 
repD10Cat4Brd6RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[1, 1, 2] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[1, 3, 0] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[1, 5, 4] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[1, 7, 6] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[3, 1, 0] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[3, 3, 2] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[3, 5, 4] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[3, 7, 6] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[4, 4, 0] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[4, 4, 2] = {{-1}}
 
repD10Cat4Brd6RMatrixFunction[4, 4, 6] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[4, 5, 1] = {{I}}
 
repD10Cat4Brd6RMatrixFunction[4, 5, 3] = {{I}}
 
repD10Cat4Brd6RMatrixFunction[4, 5, 7] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[4, 6, 4] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[4, 6, 6] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[4, 7, 5] = {{I}}
 
repD10Cat4Brd6RMatrixFunction[4, 7, 7] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[5, 1, 4] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[5, 3, 4] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[5, 4, 1] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[5, 4, 3] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[5, 4, 7] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[5, 5, 0] = {{I}}
 
repD10Cat4Brd6RMatrixFunction[5, 5, 2] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[5, 5, 6] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[5, 6, 5] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[5, 6, 7] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[5, 7, 4] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[5, 7, 6] = {{-1}}
 
repD10Cat4Brd6RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat4Brd6RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat4Brd6RMatrixFunction[6, 4, 4] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[6, 4, 6] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[6, 5, 5] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[6, 5, 7] = {{I}}
 
repD10Cat4Brd6RMatrixFunction[6, 6, 0] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[6, 6, 2] = {{-1}}
 
repD10Cat4Brd6RMatrixFunction[6, 6, 4] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[6, 7, 1] = {{I}}
 
repD10Cat4Brd6RMatrixFunction[6, 7, 3] = {{I}}
 
repD10Cat4Brd6RMatrixFunction[6, 7, 5] = {{I}}
 
repD10Cat4Brd6RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[7, 1, 6] = {{-1}}
 
repD10Cat4Brd6RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[7, 3, 6] = {{-1}}
 
repD10Cat4Brd6RMatrixFunction[7, 4, 5] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[7, 4, 7] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[7, 5, 4] = {{-1}}
 
repD10Cat4Brd6RMatrixFunction[7, 5, 6] = {{1}}
 
repD10Cat4Brd6RMatrixFunction[7, 6, 1] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[7, 6, 3] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[7, 6, 5] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[7, 7, 0] = {{I}}
 
repD10Cat4Brd6RMatrixFunction[7, 7, 2] = {{-I}}
 
repD10Cat4Brd6RMatrixFunction[7, 7, 4] = {{-I}}
balancedCategories[repD10Cat4Brd7] ^= {repD10Cat4Bal13, repD10Cat4Bal14}
 
repD10Cat4Brd7 /: balancedCategory[repD10Cat4Brd7, 1] = repD10Cat4Bal13
 
repD10Cat4Brd7 /: balancedCategory[repD10Cat4Brd7, 2] = repD10Cat4Bal14
 
braidedCategory[repD10Cat4Brd7] ^= repD10Cat4Brd7
 
fusionCategory[repD10Cat4Brd7] ^= repD10Cat4
 
repD10Cat4Brd7 /: modularCategory[repD10Cat4Brd7, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat4Brd7 /: ribbonCategory[repD10Cat4Brd7, 1] = repD10Cat4Bal13
 
repD10Cat4Brd7 /: ribbonCategory[repD10Cat4Brd7, 2] = repD10Cat4Bal14
 
ring[repD10Cat4Brd7] ^= repD10
 
rMatrixFunction[repD10Cat4Brd7] ^= repD10Cat4Brd7RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD10Cat4]][braidedCategory[#1]] & )[
    repD10Cat4Brd7] ^= 7
braidedCategory[repD10Cat4Brd7RMatrixFunction] ^= repD10Cat4Brd7
 
fusionCategory[repD10Cat4Brd7RMatrixFunction] ^= repD10Cat4
 
rMatrixFunction[repD10Cat4Brd7RMatrixFunction] ^= 
   repD10Cat4Brd7RMatrixFunction
 
repD10Cat4Brd7RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[1, 1, 2] = {{-I}}
 
repD10Cat4Brd7RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[1, 3, 0] = {{-I}}
 
repD10Cat4Brd7RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[1, 5, 4] = {{-I}}
 
repD10Cat4Brd7RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat4Brd7RMatrixFunction[1, 7, 6] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[3, 1, 0] = {{-I}}
 
repD10Cat4Brd7RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[3, 3, 2] = {{-I}}
 
repD10Cat4Brd7RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[3, 5, 4] = {{-I}}
 
repD10Cat4Brd7RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat4Brd7RMatrixFunction[3, 7, 6] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[4, 4, 0] = {{(-1)^(2/5)}}
 
repD10Cat4Brd7RMatrixFunction[4, 4, 2] = {{-(-1)^(2/5)}}
 
repD10Cat4Brd7RMatrixFunction[4, 4, 6] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd7RMatrixFunction[4, 5, 1] = {{(-1)^(9/10)}}
 
repD10Cat4Brd7RMatrixFunction[4, 5, 3] = {{(-1)^(9/10)}}
 
repD10Cat4Brd7RMatrixFunction[4, 5, 7] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd7RMatrixFunction[4, 6, 4] = {{(-1)^(4/5)}}
 
repD10Cat4Brd7RMatrixFunction[4, 6, 6] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd7RMatrixFunction[4, 7, 5] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd7RMatrixFunction[4, 7, 7] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd7RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[5, 1, 4] = {{-I}}
 
repD10Cat4Brd7RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[5, 3, 4] = {{-I}}
 
repD10Cat4Brd7RMatrixFunction[5, 4, 1] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd7RMatrixFunction[5, 4, 3] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd7RMatrixFunction[5, 4, 7] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd7RMatrixFunction[5, 5, 0] = {{(-1)^(9/10)}}
 
repD10Cat4Brd7RMatrixFunction[5, 5, 2] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd7RMatrixFunction[5, 5, 6] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd7RMatrixFunction[5, 6, 5] = {{(-1)^(4/5)}}
 
repD10Cat4Brd7RMatrixFunction[5, 6, 7] = {{(-1)^(7/10)}}
 
repD10Cat4Brd7RMatrixFunction[5, 7, 4] = {{(-1)^(4/5)}}
 
repD10Cat4Brd7RMatrixFunction[5, 7, 6] = {{(-1)^(1/5)}}
 
repD10Cat4Brd7RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat4Brd7RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat4Brd7RMatrixFunction[6, 4, 4] = {{(-1)^(4/5)}}
 
repD10Cat4Brd7RMatrixFunction[6, 4, 6] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd7RMatrixFunction[6, 5, 5] = {{(-1)^(4/5)}}
 
repD10Cat4Brd7RMatrixFunction[6, 5, 7] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd7RMatrixFunction[6, 6, 0] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd7RMatrixFunction[6, 6, 2] = {{(-1)^(3/5)}}
 
repD10Cat4Brd7RMatrixFunction[6, 6, 4] = {{(-1)^(2/5)}}
 
repD10Cat4Brd7RMatrixFunction[6, 7, 1] = {{(-1)^(1/10)}}
 
repD10Cat4Brd7RMatrixFunction[6, 7, 3] = {{(-1)^(1/10)}}
 
repD10Cat4Brd7RMatrixFunction[6, 7, 5] = {{(-1)^(9/10)}}
 
repD10Cat4Brd7RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[7, 1, 6] = {{-1}}
 
repD10Cat4Brd7RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat4Brd7RMatrixFunction[7, 3, 6] = {{-1}}
 
repD10Cat4Brd7RMatrixFunction[7, 4, 5] = {{(-1)^(3/10)}}
 
repD10Cat4Brd7RMatrixFunction[7, 4, 7] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd7RMatrixFunction[7, 5, 4] = {{-(-1)^(4/5)}}
 
repD10Cat4Brd7RMatrixFunction[7, 5, 6] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd7RMatrixFunction[7, 6, 1] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd7RMatrixFunction[7, 6, 3] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd7RMatrixFunction[7, 6, 5] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd7RMatrixFunction[7, 7, 0] = {{(-1)^(1/10)}}
 
repD10Cat4Brd7RMatrixFunction[7, 7, 2] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd7RMatrixFunction[7, 7, 4] = {{-(-1)^(9/10)}}
balancedCategories[repD10Cat4Brd8] ^= {repD10Cat4Bal15, repD10Cat4Bal16}
 
repD10Cat4Brd8 /: balancedCategory[repD10Cat4Brd8, 1] = repD10Cat4Bal15
 
repD10Cat4Brd8 /: balancedCategory[repD10Cat4Brd8, 2] = repD10Cat4Bal16
 
braidedCategory[repD10Cat4Brd8] ^= repD10Cat4Brd8
 
fusionCategory[repD10Cat4Brd8] ^= repD10Cat4
 
repD10Cat4Brd8 /: modularCategory[repD10Cat4Brd8, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat4Brd8 /: ribbonCategory[repD10Cat4Brd8, 1] = repD10Cat4Bal15
 
repD10Cat4Brd8 /: ribbonCategory[repD10Cat4Brd8, 2] = repD10Cat4Bal16
 
ring[repD10Cat4Brd8] ^= repD10
 
rMatrixFunction[repD10Cat4Brd8] ^= repD10Cat4Brd8RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD10Cat4]][braidedCategory[#1]] & )[
    repD10Cat4Brd8] ^= 8
braidedCategory[repD10Cat4Brd8RMatrixFunction] ^= repD10Cat4Brd8
 
fusionCategory[repD10Cat4Brd8RMatrixFunction] ^= repD10Cat4
 
rMatrixFunction[repD10Cat4Brd8RMatrixFunction] ^= 
   repD10Cat4Brd8RMatrixFunction
 
repD10Cat4Brd8RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[1, 1, 2] = {{-I}}
 
repD10Cat4Brd8RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[1, 3, 0] = {{-I}}
 
repD10Cat4Brd8RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[1, 5, 4] = {{-I}}
 
repD10Cat4Brd8RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat4Brd8RMatrixFunction[1, 7, 6] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[3, 1, 0] = {{-I}}
 
repD10Cat4Brd8RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[3, 3, 2] = {{-I}}
 
repD10Cat4Brd8RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[3, 5, 4] = {{-I}}
 
repD10Cat4Brd8RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat4Brd8RMatrixFunction[3, 7, 6] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[4, 4, 0] = {{(-1)^(4/5)}}
 
repD10Cat4Brd8RMatrixFunction[4, 4, 2] = {{-(-1)^(4/5)}}
 
repD10Cat4Brd8RMatrixFunction[4, 4, 6] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd8RMatrixFunction[4, 5, 1] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd8RMatrixFunction[4, 5, 3] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd8RMatrixFunction[4, 5, 7] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd8RMatrixFunction[4, 6, 4] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd8RMatrixFunction[4, 6, 6] = {{(-1)^(2/5)}}
 
repD10Cat4Brd8RMatrixFunction[4, 7, 5] = {{(-1)^(1/10)}}
 
repD10Cat4Brd8RMatrixFunction[4, 7, 7] = {{(-1)^(2/5)}}
 
repD10Cat4Brd8RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[5, 1, 4] = {{-I}}
 
repD10Cat4Brd8RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[5, 3, 4] = {{-I}}
 
repD10Cat4Brd8RMatrixFunction[5, 4, 1] = {{(-1)^(3/10)}}
 
repD10Cat4Brd8RMatrixFunction[5, 4, 3] = {{(-1)^(3/10)}}
 
repD10Cat4Brd8RMatrixFunction[5, 4, 7] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd8RMatrixFunction[5, 5, 0] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd8RMatrixFunction[5, 5, 2] = {{(-1)^(3/10)}}
 
repD10Cat4Brd8RMatrixFunction[5, 5, 6] = {{(-1)^(7/10)}}
 
repD10Cat4Brd8RMatrixFunction[5, 6, 5] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd8RMatrixFunction[5, 6, 7] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd8RMatrixFunction[5, 7, 4] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd8RMatrixFunction[5, 7, 6] = {{-(-1)^(2/5)}}
 
repD10Cat4Brd8RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat4Brd8RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat4Brd8RMatrixFunction[6, 4, 4] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd8RMatrixFunction[6, 4, 6] = {{(-1)^(2/5)}}
 
repD10Cat4Brd8RMatrixFunction[6, 5, 5] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd8RMatrixFunction[6, 5, 7] = {{(-1)^(9/10)}}
 
repD10Cat4Brd8RMatrixFunction[6, 6, 0] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd8RMatrixFunction[6, 6, 2] = {{(-1)^(1/5)}}
 
repD10Cat4Brd8RMatrixFunction[6, 6, 4] = {{(-1)^(4/5)}}
 
repD10Cat4Brd8RMatrixFunction[6, 7, 1] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd8RMatrixFunction[6, 7, 3] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd8RMatrixFunction[6, 7, 5] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd8RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[7, 1, 6] = {{-1}}
 
repD10Cat4Brd8RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat4Brd8RMatrixFunction[7, 3, 6] = {{-1}}
 
repD10Cat4Brd8RMatrixFunction[7, 4, 5] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd8RMatrixFunction[7, 4, 7] = {{(-1)^(2/5)}}
 
repD10Cat4Brd8RMatrixFunction[7, 5, 4] = {{(-1)^(3/5)}}
 
repD10Cat4Brd8RMatrixFunction[7, 5, 6] = {{(-1)^(2/5)}}
 
repD10Cat4Brd8RMatrixFunction[7, 6, 1] = {{(-1)^(7/10)}}
 
repD10Cat4Brd8RMatrixFunction[7, 6, 3] = {{(-1)^(7/10)}}
 
repD10Cat4Brd8RMatrixFunction[7, 6, 5] = {{(-1)^(3/10)}}
 
repD10Cat4Brd8RMatrixFunction[7, 7, 0] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd8RMatrixFunction[7, 7, 2] = {{(-1)^(7/10)}}
 
repD10Cat4Brd8RMatrixFunction[7, 7, 4] = {{(-1)^(3/10)}}
balancedCategories[repD10Cat4Brd9] ^= {repD10Cat4Bal17, repD10Cat4Bal18}
 
repD10Cat4Brd9 /: balancedCategory[repD10Cat4Brd9, 1] = repD10Cat4Bal17
 
repD10Cat4Brd9 /: balancedCategory[repD10Cat4Brd9, 2] = repD10Cat4Bal18
 
braidedCategory[repD10Cat4Brd9] ^= repD10Cat4Brd9
 
fusionCategory[repD10Cat4Brd9] ^= repD10Cat4
 
repD10Cat4Brd9 /: modularCategory[repD10Cat4Brd9, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
repD10Cat4Brd9 /: ribbonCategory[repD10Cat4Brd9, 1] = repD10Cat4Bal17
 
repD10Cat4Brd9 /: ribbonCategory[repD10Cat4Brd9, 2] = repD10Cat4Bal18
 
ring[repD10Cat4Brd9] ^= repD10
 
rMatrixFunction[repD10Cat4Brd9] ^= repD10Cat4Brd9RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[repD10Cat4]][braidedCategory[#1]] & )[
    repD10Cat4Brd9] ^= 9
braidedCategory[repD10Cat4Brd9RMatrixFunction] ^= repD10Cat4Brd9
 
fusionCategory[repD10Cat4Brd9RMatrixFunction] ^= repD10Cat4
 
rMatrixFunction[repD10Cat4Brd9RMatrixFunction] ^= 
   repD10Cat4Brd9RMatrixFunction
 
repD10Cat4Brd9RMatrixFunction[0, 0, 0] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[0, 1, 1] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[0, 2, 2] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[0, 3, 3] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[0, 4, 4] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[0, 5, 5] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[0, 6, 6] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[0, 7, 7] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[1, 0, 1] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[1, 1, 2] = {{-I}}
 
repD10Cat4Brd9RMatrixFunction[1, 2, 3] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[1, 3, 0] = {{-I}}
 
repD10Cat4Brd9RMatrixFunction[1, 4, 5] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[1, 5, 4] = {{-I}}
 
repD10Cat4Brd9RMatrixFunction[1, 6, 7] = {{-I}}
 
repD10Cat4Brd9RMatrixFunction[1, 7, 6] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[2, 0, 2] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[2, 1, 3] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[2, 2, 0] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[2, 3, 1] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[2, 4, 4] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[2, 5, 5] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[2, 6, 6] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[2, 7, 7] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[3, 0, 3] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[3, 1, 0] = {{-I}}
 
repD10Cat4Brd9RMatrixFunction[3, 2, 1] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[3, 3, 2] = {{-I}}
 
repD10Cat4Brd9RMatrixFunction[3, 4, 5] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[3, 5, 4] = {{-I}}
 
repD10Cat4Brd9RMatrixFunction[3, 6, 7] = {{-I}}
 
repD10Cat4Brd9RMatrixFunction[3, 7, 6] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[4, 0, 4] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[4, 1, 5] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[4, 2, 4] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[4, 3, 5] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[4, 4, 0] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd9RMatrixFunction[4, 4, 2] = {{(-1)^(1/5)}}
 
repD10Cat4Brd9RMatrixFunction[4, 4, 6] = {{(-1)^(4/5)}}
 
repD10Cat4Brd9RMatrixFunction[4, 5, 1] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd9RMatrixFunction[4, 5, 3] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd9RMatrixFunction[4, 5, 7] = {{(-1)^(4/5)}}
 
repD10Cat4Brd9RMatrixFunction[4, 6, 4] = {{(-1)^(2/5)}}
 
repD10Cat4Brd9RMatrixFunction[4, 6, 6] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd9RMatrixFunction[4, 7, 5] = {{(-1)^(9/10)}}
 
repD10Cat4Brd9RMatrixFunction[4, 7, 7] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd9RMatrixFunction[5, 0, 5] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[5, 1, 4] = {{-I}}
 
repD10Cat4Brd9RMatrixFunction[5, 2, 5] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[5, 3, 4] = {{-I}}
 
repD10Cat4Brd9RMatrixFunction[5, 4, 1] = {{(-1)^(7/10)}}
 
repD10Cat4Brd9RMatrixFunction[5, 4, 3] = {{(-1)^(7/10)}}
 
repD10Cat4Brd9RMatrixFunction[5, 4, 7] = {{(-1)^(4/5)}}
 
repD10Cat4Brd9RMatrixFunction[5, 5, 0] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd9RMatrixFunction[5, 5, 2] = {{(-1)^(7/10)}}
 
repD10Cat4Brd9RMatrixFunction[5, 5, 6] = {{(-1)^(3/10)}}
 
repD10Cat4Brd9RMatrixFunction[5, 6, 5] = {{(-1)^(2/5)}}
 
repD10Cat4Brd9RMatrixFunction[5, 6, 7] = {{-(-1)^(1/10)}}
 
repD10Cat4Brd9RMatrixFunction[5, 7, 4] = {{(-1)^(2/5)}}
 
repD10Cat4Brd9RMatrixFunction[5, 7, 6] = {{(-1)^(3/5)}}
 
repD10Cat4Brd9RMatrixFunction[6, 0, 6] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[6, 1, 7] = {{I}}
 
repD10Cat4Brd9RMatrixFunction[6, 2, 6] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[6, 3, 7] = {{I}}
 
repD10Cat4Brd9RMatrixFunction[6, 4, 4] = {{(-1)^(2/5)}}
 
repD10Cat4Brd9RMatrixFunction[6, 4, 6] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd9RMatrixFunction[6, 5, 5] = {{(-1)^(2/5)}}
 
repD10Cat4Brd9RMatrixFunction[6, 5, 7] = {{(-1)^(1/10)}}
 
repD10Cat4Brd9RMatrixFunction[6, 6, 0] = {{(-1)^(4/5)}}
 
repD10Cat4Brd9RMatrixFunction[6, 6, 2] = {{-(-1)^(4/5)}}
 
repD10Cat4Brd9RMatrixFunction[6, 6, 4] = {{-(-1)^(1/5)}}
 
repD10Cat4Brd9RMatrixFunction[6, 7, 1] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd9RMatrixFunction[6, 7, 3] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd9RMatrixFunction[6, 7, 5] = {{-(-1)^(7/10)}}
 
repD10Cat4Brd9RMatrixFunction[7, 0, 7] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[7, 1, 6] = {{-1}}
 
repD10Cat4Brd9RMatrixFunction[7, 2, 7] = {{1}}
 
repD10Cat4Brd9RMatrixFunction[7, 3, 6] = {{-1}}
 
repD10Cat4Brd9RMatrixFunction[7, 4, 5] = {{-(-1)^(9/10)}}
 
repD10Cat4Brd9RMatrixFunction[7, 4, 7] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd9RMatrixFunction[7, 5, 4] = {{-(-1)^(2/5)}}
 
repD10Cat4Brd9RMatrixFunction[7, 5, 6] = {{-(-1)^(3/5)}}
 
repD10Cat4Brd9RMatrixFunction[7, 6, 1] = {{(-1)^(3/10)}}
 
repD10Cat4Brd9RMatrixFunction[7, 6, 3] = {{(-1)^(3/10)}}
 
repD10Cat4Brd9RMatrixFunction[7, 6, 5] = {{(-1)^(7/10)}}
 
repD10Cat4Brd9RMatrixFunction[7, 7, 0] = {{-(-1)^(3/10)}}
 
repD10Cat4Brd9RMatrixFunction[7, 7, 2] = {{(-1)^(3/10)}}
 
repD10Cat4Brd9RMatrixFunction[7, 7, 4] = {{(-1)^(7/10)}}
fMatrixFunction[repD10Cat4FMatrixFunction] ^= repD10Cat4FMatrixFunction
 
fusionCategory[repD10Cat4FMatrixFunction] ^= repD10Cat4
 
ring[repD10Cat4FMatrixFunction] ^= repD10
 
repD10Cat4FMatrixFunction[1, 1, 1, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 1, 3, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 1, 5, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 1, 7, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 3, 1, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 3, 3, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 3, 5, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 3, 7, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 4, 4, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 4, 4, 7] = {{-I}}
 
repD10Cat4FMatrixFunction[1, 4, 5, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 4, 5, 6] = {{-I}}
 
repD10Cat4FMatrixFunction[1, 4, 7, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 4, 7, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 5, 1, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 5, 3, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 5, 4, 0] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 5, 4, 6] = {{-I}}
 
repD10Cat4FMatrixFunction[1, 5, 5, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 5, 5, 7] = {{I}}
 
repD10Cat4FMatrixFunction[1, 5, 6, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 5, 7, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 6, 1, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 6, 3, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 6, 4, 5] = {{I}}
 
repD10Cat4FMatrixFunction[1, 6, 5, 4] = {{-I}}
 
repD10Cat4FMatrixFunction[1, 6, 5, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 6, 6, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 6, 6, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 6, 7, 0] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 7, 4, 4] = {{I}}
 
repD10Cat4FMatrixFunction[1, 7, 4, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 7, 5, 5] = {{I}}
 
repD10Cat4FMatrixFunction[1, 7, 5, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 7, 6, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 7, 6, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 7, 7, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[1, 7, 7, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 4, 4, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 4, 5, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 4, 6, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 4, 7, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 5, 4, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 5, 4, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 5, 5, 0] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 5, 5, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 5, 5, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 5, 6, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 5, 7, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 6, 4, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 6, 4, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 6, 5, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 6, 5, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 6, 6, 0] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 6, 6, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 6, 7, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 6, 7, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 7, 4, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 7, 4, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 7, 5, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[2, 7, 5, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 1, 1, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 1, 3, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 1, 5, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 1, 7, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 3, 1, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 3, 3, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 3, 5, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 3, 7, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 4, 4, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 4, 4, 7] = {{I}}
 
repD10Cat4FMatrixFunction[3, 4, 5, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 4, 5, 6] = {{I}}
 
repD10Cat4FMatrixFunction[3, 4, 6, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 4, 7, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 5, 1, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 5, 3, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 5, 4, 6] = {{I}}
 
repD10Cat4FMatrixFunction[3, 5, 5, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 5, 5, 7] = {{-I}}
 
repD10Cat4FMatrixFunction[3, 6, 1, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 6, 3, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 6, 4, 5] = {{-I}}
 
repD10Cat4FMatrixFunction[3, 6, 4, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 6, 5, 4] = {{I}}
 
repD10Cat4FMatrixFunction[3, 6, 6, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 6, 6, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 6, 7, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 7, 4, 4] = {{-I}}
 
repD10Cat4FMatrixFunction[3, 7, 5, 5] = {{-I}}
 
repD10Cat4FMatrixFunction[3, 7, 6, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 7, 6, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 7, 7, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[3, 7, 7, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 1, 4, 1] = {{I}}
 
repD10Cat4FMatrixFunction[4, 1, 4, 3] = {{-I}}
 
repD10Cat4FMatrixFunction[4, 1, 5, 0] = {{I}}
 
repD10Cat4FMatrixFunction[4, 1, 5, 2] = {{-I}}
 
repD10Cat4FMatrixFunction[4, 2, 4, 0] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 2, 4, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 2, 5, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 2, 5, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 2, 6, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 2, 7, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 3, 4, 1] = {{-I}}
 
repD10Cat4FMatrixFunction[4, 3, 4, 3] = {{I}}
 
repD10Cat4FMatrixFunction[4, 3, 5, 0] = {{-I}}
 
repD10Cat4FMatrixFunction[4, 3, 5, 2] = {{I}}
 
repD10Cat4FMatrixFunction[4, 3, 6, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 3, 7, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 4, 1, 1] = {{I}}
 
repD10Cat4FMatrixFunction[4, 4, 1, 3] = {{I}}
 
repD10Cat4FMatrixFunction[4, 4, 2, 0] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 4, 2, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 4, 2, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 4, 3, 1] = {{-I}}
 
repD10Cat4FMatrixFunction[4, 4, 3, 3] = {{-I}}
 
repD10Cat4FMatrixFunction[4, 4, 3, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 4, 4, 4] = {{1/2, 1/2, -(1/Sqrt[2])}, 
    {-1/2, -1/2, -(1/Sqrt[2])}, {-(1/Sqrt[2]), 1/Sqrt[2], 0}}
 
repD10Cat4FMatrixFunction[4, 4, 5, 5] = {{I/2, I/2, (-I)/Sqrt[2]}, 
    {-I/2, -I/2, (-I)/Sqrt[2]}, {(-I)/Sqrt[2], I/Sqrt[2], 0}}
 
repD10Cat4FMatrixFunction[4, 4, 6, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
repD10Cat4FMatrixFunction[4, 4, 7, 5] = {{I}}
 
repD10Cat4FMatrixFunction[4, 4, 7, 7] = {{(-I)/Sqrt[2], I/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
repD10Cat4FMatrixFunction[4, 5, 1, 0] = {{I}}
 
repD10Cat4FMatrixFunction[4, 5, 1, 2] = {{I}}
 
repD10Cat4FMatrixFunction[4, 5, 1, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 5, 2, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 5, 2, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 5, 2, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 5, 3, 0] = {{-I}}
 
repD10Cat4FMatrixFunction[4, 5, 3, 2] = {{-I}}
 
repD10Cat4FMatrixFunction[4, 5, 4, 5] = {{-I/2, -I/2, -(1/Sqrt[2])}, 
    {-I/2, -I/2, 1/Sqrt[2]}, {-(1/Sqrt[2]), 1/Sqrt[2], 0}}
 
repD10Cat4FMatrixFunction[4, 5, 5, 4] = {{-1/2, -1/2, I/Sqrt[2]}, 
    {-1/2, -1/2, (-I)/Sqrt[2]}, {I/Sqrt[2], (-I)/Sqrt[2], 0}}
 
repD10Cat4FMatrixFunction[4, 5, 6, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 5, 6, 5] = {{I}}
 
repD10Cat4FMatrixFunction[4, 5, 6, 7] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {I/Sqrt[2], I/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[4, 5, 7, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 5, 7, 6] = {{I/Sqrt[2], (-I)/Sqrt[2]}, 
    {I/Sqrt[2], I/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[4, 6, 1, 5] = {{I}}
 
repD10Cat4FMatrixFunction[4, 6, 2, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 6, 2, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 6, 3, 5] = {{-I}}
 
repD10Cat4FMatrixFunction[4, 6, 3, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 6, 4, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 6, 4, 6] = {{0, 1}, {1, 0}}
 
repD10Cat4FMatrixFunction[4, 6, 5, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 6, 5, 5] = {{I}}
 
repD10Cat4FMatrixFunction[4, 6, 5, 7] = {{0, 1}, {1, 0}}
 
repD10Cat4FMatrixFunction[4, 6, 6, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 6, 6, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repD10Cat4FMatrixFunction[4, 6, 7, 1] = {{-I}}
 
repD10Cat4FMatrixFunction[4, 6, 7, 3] = {{I}}
 
repD10Cat4FMatrixFunction[4, 6, 7, 5] = {{(-I)/Sqrt[2], 1/Sqrt[2]}, 
    {I/Sqrt[2], 1/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[4, 7, 1, 4] = {{I}}
 
repD10Cat4FMatrixFunction[4, 7, 1, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 7, 2, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 7, 2, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[4, 7, 3, 4] = {{-I}}
 
repD10Cat4FMatrixFunction[4, 7, 4, 5] = {{I}}
 
repD10Cat4FMatrixFunction[4, 7, 4, 7] = {{0, 1}, {-I, 0}}
 
repD10Cat4FMatrixFunction[4, 7, 5, 6] = {{0, 1}, {-I, 0}}
 
repD10Cat4FMatrixFunction[4, 7, 6, 1] = {{-I}}
 
repD10Cat4FMatrixFunction[4, 7, 6, 3] = {{-I}}
 
repD10Cat4FMatrixFunction[4, 7, 6, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
repD10Cat4FMatrixFunction[4, 7, 6, 7] = {{-I}}
 
repD10Cat4FMatrixFunction[4, 7, 7, 4] = {{I/Sqrt[2], -(1/Sqrt[2])}, 
    {I/Sqrt[2], 1/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[4, 7, 7, 6] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 1, 1, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 1, 3, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 1, 4, 0] = {{I}}
 
repD10Cat4FMatrixFunction[5, 1, 4, 2] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 1, 5, 1] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 1, 5, 3] = {{I}}
 
repD10Cat4FMatrixFunction[5, 1, 5, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 1, 6, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 1, 7, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 2, 4, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 2, 4, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 2, 5, 0] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 2, 5, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 2, 6, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 2, 7, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 3, 1, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 3, 3, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 3, 4, 0] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 3, 4, 2] = {{I}}
 
repD10Cat4FMatrixFunction[5, 3, 5, 1] = {{I}}
 
repD10Cat4FMatrixFunction[5, 3, 5, 3] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 3, 5, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 3, 7, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 3, 7, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 4, 1, 0] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 4, 1, 2] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 4, 1, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 4, 2, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 4, 3, 0] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 4, 3, 2] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 4, 4, 5] = {{1/2, -1/2, -(1/Sqrt[2])}, 
    {-1/2, 1/2, -(1/Sqrt[2])}, {-(1/Sqrt[2]), -(1/Sqrt[2]), 0}}
 
repD10Cat4FMatrixFunction[5, 4, 4, 7] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 4, 5, 4] = {{I/2, -I/2, I/Sqrt[2]}, 
    {-I/2, I/2, I/Sqrt[2]}, {I/Sqrt[2], I/Sqrt[2], 0}}
 
repD10Cat4FMatrixFunction[5, 4, 5, 6] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 4, 6, 1] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 4, 6, 3] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 4, 6, 5] = {{I}}
 
repD10Cat4FMatrixFunction[5, 4, 6, 7] = {{(-I)/Sqrt[2], (-I)/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[5, 4, 7, 0] = {{I}}
 
repD10Cat4FMatrixFunction[5, 4, 7, 2] = {{I}}
 
repD10Cat4FMatrixFunction[5, 4, 7, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 4, 7, 6] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repD10Cat4FMatrixFunction[5, 5, 1, 1] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 5, 1, 3] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 5, 1, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 5, 2, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 5, 3, 1] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 5, 3, 3] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 5, 4, 4] = {{-I/2, I/2, -(1/Sqrt[2])}, 
    {-I/2, I/2, 1/Sqrt[2]}, {-(1/Sqrt[2]), -(1/Sqrt[2]), 0}}
 
repD10Cat4FMatrixFunction[5, 5, 4, 6] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 5, 5, 5] = {{1/2, -1/2, I/Sqrt[2]}, 
    {1/2, -1/2, (-I)/Sqrt[2]}, {I/Sqrt[2], I/Sqrt[2], 0}}
 
repD10Cat4FMatrixFunction[5, 5, 5, 7] = {{I}}
 
repD10Cat4FMatrixFunction[5, 5, 6, 0] = {{I}}
 
repD10Cat4FMatrixFunction[5, 5, 6, 2] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 5, 6, 6] = {{I/Sqrt[2], I/Sqrt[2]}, 
    {(-I)/Sqrt[2], I/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[5, 5, 7, 1] = {{I}}
 
repD10Cat4FMatrixFunction[5, 5, 7, 3] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 5, 7, 5] = {{I}}
 
repD10Cat4FMatrixFunction[5, 5, 7, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {(-I)/Sqrt[2], I/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[5, 6, 1, 4] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 6, 2, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 6, 2, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 6, 3, 4] = {{I}}
 
repD10Cat4FMatrixFunction[5, 6, 3, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 6, 4, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 6, 4, 5] = {{I}}
 
repD10Cat4FMatrixFunction[5, 6, 4, 7] = {{0, I}, {-I, 0}}
 
repD10Cat4FMatrixFunction[5, 6, 5, 0] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 6, 5, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 6, 5, 6] = {{0, -I}, {I, 0}}
 
repD10Cat4FMatrixFunction[5, 6, 6, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 6, 6, 5] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[5, 6, 6, 7] = {{I}}
 
repD10Cat4FMatrixFunction[5, 6, 7, 0] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 6, 7, 2] = {{I}}
 
repD10Cat4FMatrixFunction[5, 6, 7, 4] = {{I/Sqrt[2], 1/Sqrt[2]}, 
    {(-I)/Sqrt[2], 1/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[5, 6, 7, 6] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 7, 1, 5] = {{I}}
 
repD10Cat4FMatrixFunction[5, 7, 2, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 7, 2, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 7, 3, 5] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 7, 3, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 7, 4, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 7, 4, 6] = {{0, I}, {-1, 0}}
 
repD10Cat4FMatrixFunction[5, 7, 5, 5] = {{-I}}
 
repD10Cat4FMatrixFunction[5, 7, 5, 7] = {{0, I}, {-1, 0}}
 
repD10Cat4FMatrixFunction[5, 7, 6, 0] = {{I}}
 
repD10Cat4FMatrixFunction[5, 7, 6, 2] = {{I}}
 
repD10Cat4FMatrixFunction[5, 7, 6, 4] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
repD10Cat4FMatrixFunction[5, 7, 6, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[5, 7, 7, 5] = {{I/Sqrt[2], -(1/Sqrt[2])}, 
    {I/Sqrt[2], 1/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[5, 7, 7, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 1, 6, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 1, 7, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 2, 4, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 2, 5, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 2, 6, 0] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 2, 6, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 2, 7, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 2, 7, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 3, 4, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 3, 5, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 3, 6, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 3, 7, 0] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 4, 2, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 4, 3, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 4, 4, 6] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[6, 4, 5, 1] = {{I}}
 
repD10Cat4FMatrixFunction[6, 4, 5, 3] = {{I}}
 
repD10Cat4FMatrixFunction[6, 4, 5, 7] = {{(-I)/Sqrt[2], (-I)/Sqrt[2]}, 
    {(-I)/Sqrt[2], I/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[6, 4, 6, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 4, 6, 4] = {{0, 1}, {1, 0}}
 
repD10Cat4FMatrixFunction[6, 4, 7, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 4, 7, 5] = {{0, I}, {-I, 0}}
 
repD10Cat4FMatrixFunction[6, 4, 7, 7] = {{I}}
 
repD10Cat4FMatrixFunction[6, 5, 1, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 5, 2, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 5, 4, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 5, 4, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repD10Cat4FMatrixFunction[6, 5, 5, 0] = {{I}}
 
repD10Cat4FMatrixFunction[6, 5, 5, 2] = {{-I}}
 
repD10Cat4FMatrixFunction[6, 5, 5, 6] = {{I/Sqrt[2], I/Sqrt[2]}, 
    {(-I)/Sqrt[2], I/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[6, 5, 6, 5] = {{0, I}, {-I, 0}}
 
repD10Cat4FMatrixFunction[6, 5, 6, 7] = {{I}}
 
repD10Cat4FMatrixFunction[6, 5, 7, 4] = {{0, 1}, {1, 0}}
 
repD10Cat4FMatrixFunction[6, 6, 1, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 6, 1, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 6, 3, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 6, 3, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 6, 4, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 6, 4, 4] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[6, 6, 5, 1] = {{I}}
 
repD10Cat4FMatrixFunction[6, 6, 5, 3] = {{-I}}
 
repD10Cat4FMatrixFunction[6, 6, 5, 5] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[6, 6, 6, 6] = {{1/2, -1/2, -(1/Sqrt[2])}, 
    {1/2, -1/2, 1/Sqrt[2]}, {-(1/Sqrt[2]), -(1/Sqrt[2]), 0}}
 
repD10Cat4FMatrixFunction[6, 6, 7, 5] = {{-I}}
 
repD10Cat4FMatrixFunction[6, 6, 7, 7] = {{-1/2, 1/2, 1/Sqrt[2]}, 
    {-1/2, 1/2, -(1/Sqrt[2])}, {-(1/Sqrt[2]), -(1/Sqrt[2]), 0}}
 
repD10Cat4FMatrixFunction[6, 7, 1, 0] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 7, 1, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 7, 3, 0] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 7, 3, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 7, 4, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 7, 4, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[6, 7, 4, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repD10Cat4FMatrixFunction[6, 7, 5, 0] = {{I}}
 
repD10Cat4FMatrixFunction[6, 7, 5, 2] = {{I}}
 
repD10Cat4FMatrixFunction[6, 7, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
repD10Cat4FMatrixFunction[6, 7, 6, 5] = {{-I}}
 
repD10Cat4FMatrixFunction[6, 7, 6, 7] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {-1/2, 1/2, 1/Sqrt[2]}, {1/Sqrt[2], 1/Sqrt[2], 0}}
 
repD10Cat4FMatrixFunction[6, 7, 7, 6] = {{-1/2, 1/2, -(1/Sqrt[2])}, 
    {1/2, -1/2, -(1/Sqrt[2])}, {1/Sqrt[2], 1/Sqrt[2], 0}}
 
repD10Cat4FMatrixFunction[7, 1, 1, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 1, 3, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 1, 4, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 1, 5, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 1, 6, 0] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 1, 7, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 1, 7, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 2, 4, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 2, 5, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 2, 6, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 2, 6, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 2, 7, 0] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 2, 7, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 3, 1, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 3, 3, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 3, 5, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 3, 5, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 3, 6, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 3, 7, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 3, 7, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 4, 1, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 4, 2, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 4, 4, 1] = {{I}}
 
repD10Cat4FMatrixFunction[7, 4, 4, 3] = {{I}}
 
repD10Cat4FMatrixFunction[7, 4, 4, 5] = {{-I}}
 
repD10Cat4FMatrixFunction[7, 4, 4, 7] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[7, 4, 5, 4] = {{-I}}
 
repD10Cat4FMatrixFunction[7, 4, 5, 6] = {{I/Sqrt[2], (-I)/Sqrt[2]}, 
    {I/Sqrt[2], I/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[7, 4, 6, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 4, 6, 5] = {{0, I}, {-I, 0}}
 
repD10Cat4FMatrixFunction[7, 4, 6, 7] = {{I}}
 
repD10Cat4FMatrixFunction[7, 4, 7, 0] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 4, 7, 4] = {{0, -1}, {-1, 0}}
 
repD10Cat4FMatrixFunction[7, 4, 7, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 5, 1, 5] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 5, 1, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 5, 2, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 5, 3, 7] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 5, 4, 0] = {{-I}}
 
repD10Cat4FMatrixFunction[7, 5, 4, 2] = {{I}}
 
repD10Cat4FMatrixFunction[7, 5, 4, 4] = {{-I}}
 
repD10Cat4FMatrixFunction[7, 5, 4, 6] = {{-(1/Sqrt[2]), 1/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[7, 5, 5, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 5, 5, 5] = {{I}}
 
repD10Cat4FMatrixFunction[7, 5, 5, 7] = {{I/Sqrt[2], I/Sqrt[2]}, 
    {(-I)/Sqrt[2], I/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[7, 5, 6, 4] = {{0, -1}, {1, 0}}
 
repD10Cat4FMatrixFunction[7, 5, 6, 6] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 5, 7, 5] = {{0, -I}, {-I, 0}}
 
repD10Cat4FMatrixFunction[7, 5, 7, 7] = {{-I}}
 
repD10Cat4FMatrixFunction[7, 6, 1, 0] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 6, 1, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 6, 1, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 6, 2, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 6, 2, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 6, 3, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 6, 4, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 6, 4, 5] = {{I/Sqrt[2], (-I)/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[7, 6, 4, 7] = {{I}}
 
repD10Cat4FMatrixFunction[7, 6, 5, 0] = {{-I}}
 
repD10Cat4FMatrixFunction[7, 6, 5, 2] = {{I}}
 
repD10Cat4FMatrixFunction[7, 6, 5, 4] = {{(-I)/Sqrt[2], I/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
repD10Cat4FMatrixFunction[7, 6, 5, 6] = {{-I}}
 
repD10Cat4FMatrixFunction[7, 6, 6, 5] = {{I}}
 
repD10Cat4FMatrixFunction[7, 6, 6, 7] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {-(1/Sqrt[2]), 1/Sqrt[2], 0}}
 
repD10Cat4FMatrixFunction[7, 6, 7, 6] = {{1/2, 1/2, -(1/Sqrt[2])}, 
    {1/2, 1/2, 1/Sqrt[2]}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
repD10Cat4FMatrixFunction[7, 7, 1, 1] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 7, 1, 3] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 7, 2, 0] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 7, 2, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 7, 4, 0] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 7, 4, 2] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 7, 4, 4] = {{(-I)/Sqrt[2], I/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[7, 7, 4, 6] = {{I}}
 
repD10Cat4FMatrixFunction[7, 7, 5, 1] = {{-I}}
 
repD10Cat4FMatrixFunction[7, 7, 5, 3] = {{-I}}
 
repD10Cat4FMatrixFunction[7, 7, 5, 5] = {{(-I)/Sqrt[2], I/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
repD10Cat4FMatrixFunction[7, 7, 5, 7] = {{I}}
 
repD10Cat4FMatrixFunction[7, 7, 6, 4] = {{-1}}
 
repD10Cat4FMatrixFunction[7, 7, 6, 6] = {{-1/2, -1/2, -(1/Sqrt[2])}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
repD10Cat4FMatrixFunction[7, 7, 7, 5] = {{I}}
 
repD10Cat4FMatrixFunction[7, 7, 7, 7] = {{1/2, 1/2, -(1/Sqrt[2])}, 
    {-1/2, -1/2, -(1/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
repD10Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repD10Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
repD10Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repD10Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[repD10Cat4Piv1] ^= {repD10Cat4Bal1, repD10Cat4Bal3, 
    repD10Cat4Bal5, repD10Cat4Bal7, repD10Cat4Bal9, repD10Cat4Bal11, 
    repD10Cat4Bal13, repD10Cat4Bal15, repD10Cat4Bal17, repD10Cat4Bal19}
 
repD10Cat4Piv1 /: balancedCategory[repD10Cat4Piv1, 1] = repD10Cat4Bal1
 
repD10Cat4Piv1 /: balancedCategory[repD10Cat4Piv1, 2] = repD10Cat4Bal3
 
repD10Cat4Piv1 /: balancedCategory[repD10Cat4Piv1, 3] = repD10Cat4Bal5
 
repD10Cat4Piv1 /: balancedCategory[repD10Cat4Piv1, 4] = repD10Cat4Bal7
 
repD10Cat4Piv1 /: balancedCategory[repD10Cat4Piv1, 5] = repD10Cat4Bal9
 
repD10Cat4Piv1 /: balancedCategory[repD10Cat4Piv1, 6] = repD10Cat4Bal11
 
repD10Cat4Piv1 /: balancedCategory[repD10Cat4Piv1, 7] = repD10Cat4Bal13
 
repD10Cat4Piv1 /: balancedCategory[repD10Cat4Piv1, 8] = repD10Cat4Bal15
 
repD10Cat4Piv1 /: balancedCategory[repD10Cat4Piv1, 9] = repD10Cat4Bal17
 
repD10Cat4Piv1 /: balancedCategory[repD10Cat4Piv1, 10] = repD10Cat4Bal19
 
fusionCategory[repD10Cat4Piv1] ^= repD10Cat4
 
repD10Cat4Piv1 /: modularCategory[repD10Cat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repD10Cat4Piv1] ^= repD10Cat4Piv1
 
pivotalIsomorphism[repD10Cat4Piv1] ^= repD10Cat4Piv1PivotalIsomorphism
 
repD10Cat4Piv1 /: ribbonCategory[repD10Cat4Piv1, 1] = repD10Cat4Bal1
 
repD10Cat4Piv1 /: ribbonCategory[repD10Cat4Piv1, 2] = repD10Cat4Bal3
 
repD10Cat4Piv1 /: ribbonCategory[repD10Cat4Piv1, 3] = repD10Cat4Bal5
 
repD10Cat4Piv1 /: ribbonCategory[repD10Cat4Piv1, 4] = repD10Cat4Bal7
 
repD10Cat4Piv1 /: ribbonCategory[repD10Cat4Piv1, 5] = repD10Cat4Bal9
 
repD10Cat4Piv1 /: ribbonCategory[repD10Cat4Piv1, 6] = repD10Cat4Bal11
 
repD10Cat4Piv1 /: ribbonCategory[repD10Cat4Piv1, 7] = repD10Cat4Bal13
 
repD10Cat4Piv1 /: ribbonCategory[repD10Cat4Piv1, 8] = repD10Cat4Bal15
 
repD10Cat4Piv1 /: ribbonCategory[repD10Cat4Piv1, 9] = repD10Cat4Bal17
 
repD10Cat4Piv1 /: ribbonCategory[repD10Cat4Piv1, 10] = repD10Cat4Bal19
 
ring[repD10Cat4Piv1] ^= repD10
 
sphericalCategory[repD10Cat4Piv1] ^= repD10Cat4Piv1
 
(pivotalCategoryIndex[fusionCategory[repD10Cat4]][pivotalCategory[#1]] & )[
    repD10Cat4Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[repD10Cat4]][
      sphericalCategory[#1]] & )[repD10Cat4Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[repD10Cat4Piv1PivotalIsomorphism] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Piv1PivotalIsomorphism] ^= repD10Cat4Piv1
 
pivotalIsomorphism[repD10Cat4Piv1PivotalIsomorphism] ^= 
   repD10Cat4Piv1PivotalIsomorphism
 
repD10Cat4Piv1PivotalIsomorphism[0] = 1
 
repD10Cat4Piv1PivotalIsomorphism[1] = 1
 
repD10Cat4Piv1PivotalIsomorphism[2] = 1
 
repD10Cat4Piv1PivotalIsomorphism[3] = 1
 
repD10Cat4Piv1PivotalIsomorphism[4] = 1
 
repD10Cat4Piv1PivotalIsomorphism[5] = -1
 
repD10Cat4Piv1PivotalIsomorphism[6] = 1
 
repD10Cat4Piv1PivotalIsomorphism[7] = -1
balancedCategories[repD10Cat4Piv2] ^= {repD10Cat4Bal2, repD10Cat4Bal4, 
    repD10Cat4Bal6, repD10Cat4Bal8, repD10Cat4Bal10, repD10Cat4Bal12, 
    repD10Cat4Bal14, repD10Cat4Bal16, repD10Cat4Bal18, repD10Cat4Bal20}
 
repD10Cat4Piv2 /: balancedCategory[repD10Cat4Piv2, 1] = repD10Cat4Bal2
 
repD10Cat4Piv2 /: balancedCategory[repD10Cat4Piv2, 2] = repD10Cat4Bal4
 
repD10Cat4Piv2 /: balancedCategory[repD10Cat4Piv2, 3] = repD10Cat4Bal6
 
repD10Cat4Piv2 /: balancedCategory[repD10Cat4Piv2, 4] = repD10Cat4Bal8
 
repD10Cat4Piv2 /: balancedCategory[repD10Cat4Piv2, 5] = repD10Cat4Bal10
 
repD10Cat4Piv2 /: balancedCategory[repD10Cat4Piv2, 6] = repD10Cat4Bal12
 
repD10Cat4Piv2 /: balancedCategory[repD10Cat4Piv2, 7] = repD10Cat4Bal14
 
repD10Cat4Piv2 /: balancedCategory[repD10Cat4Piv2, 8] = repD10Cat4Bal16
 
repD10Cat4Piv2 /: balancedCategory[repD10Cat4Piv2, 9] = repD10Cat4Bal18
 
repD10Cat4Piv2 /: balancedCategory[repD10Cat4Piv2, 10] = repD10Cat4Bal20
 
fusionCategory[repD10Cat4Piv2] ^= repD10Cat4
 
repD10Cat4Piv2 /: modularCategory[repD10Cat4Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repD10Cat4Piv2] ^= repD10Cat4Piv2
 
pivotalIsomorphism[repD10Cat4Piv2] ^= repD10Cat4Piv2PivotalIsomorphism
 
repD10Cat4Piv2 /: ribbonCategory[repD10Cat4Piv2, 1] = repD10Cat4Bal2
 
repD10Cat4Piv2 /: ribbonCategory[repD10Cat4Piv2, 2] = repD10Cat4Bal4
 
repD10Cat4Piv2 /: ribbonCategory[repD10Cat4Piv2, 3] = repD10Cat4Bal6
 
repD10Cat4Piv2 /: ribbonCategory[repD10Cat4Piv2, 4] = repD10Cat4Bal8
 
repD10Cat4Piv2 /: ribbonCategory[repD10Cat4Piv2, 5] = repD10Cat4Bal10
 
repD10Cat4Piv2 /: ribbonCategory[repD10Cat4Piv2, 6] = repD10Cat4Bal12
 
repD10Cat4Piv2 /: ribbonCategory[repD10Cat4Piv2, 7] = repD10Cat4Bal14
 
repD10Cat4Piv2 /: ribbonCategory[repD10Cat4Piv2, 8] = repD10Cat4Bal16
 
repD10Cat4Piv2 /: ribbonCategory[repD10Cat4Piv2, 9] = repD10Cat4Bal18
 
repD10Cat4Piv2 /: ribbonCategory[repD10Cat4Piv2, 10] = repD10Cat4Bal20
 
ring[repD10Cat4Piv2] ^= repD10
 
sphericalCategory[repD10Cat4Piv2] ^= repD10Cat4Piv2
 
(pivotalCategoryIndex[fusionCategory[repD10Cat4]][pivotalCategory[#1]] & )[
    repD10Cat4Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[repD10Cat4]][
      sphericalCategory[#1]] & )[repD10Cat4Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[repD10Cat4Piv2PivotalIsomorphism] ^= repD10Cat4
 
pivotalCategory[repD10Cat4Piv2PivotalIsomorphism] ^= repD10Cat4Piv2
 
pivotalIsomorphism[repD10Cat4Piv2PivotalIsomorphism] ^= 
   repD10Cat4Piv2PivotalIsomorphism
 
repD10Cat4Piv2PivotalIsomorphism[0] = 1
 
repD10Cat4Piv2PivotalIsomorphism[1] = -1
 
repD10Cat4Piv2PivotalIsomorphism[2] = 1
 
repD10Cat4Piv2PivotalIsomorphism[3] = -1
 
repD10Cat4Piv2PivotalIsomorphism[4] = 1
 
repD10Cat4Piv2PivotalIsomorphism[5] = 1
 
repD10Cat4Piv2PivotalIsomorphism[6] = 1
 
repD10Cat4Piv2PivotalIsomorphism[7] = 1
balancedCategories[repD10Cat5] ^= {}
 
braidedCategories[repD10Cat5] ^= {}
 
coeval[repD10Cat5] ^= 1/sixJFunction[repD10Cat5][#1, 
      dual[ring[repD10Cat5]][#1], #1, #1, 0, 0] & 
 
eval[repD10Cat5] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[repD10Cat5] ^= repD10Cat5FMatrixFunction
 
fusionCategory[repD10Cat5] ^= repD10Cat5
 
repD10Cat5 /: modularCategory[repD10Cat5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[repD10Cat5] ^= {repD10Cat5Piv1, repD10Cat5Piv2}
 
repD10Cat5 /: pivotalCategory[repD10Cat5, 1] = repD10Cat5Piv1
 
repD10Cat5 /: pivotalCategory[repD10Cat5, 2] = repD10Cat5Piv2
 
repD10Cat5 /: pivotalCategory[repD10Cat5, {1, -1, 1, -1, 1, 1, 1, 1}] = 
    repD10Cat5Piv2
 
repD10Cat5 /: pivotalCategory[repD10Cat5, {1, 1, 1, 1, 1, -1, 1, -1}] = 
    repD10Cat5Piv1
 
ring[repD10Cat5] ^= repD10
 
repD10Cat5 /: sphericalCategory[repD10Cat5, 1] = repD10Cat5Piv1
 
repD10Cat5 /: sphericalCategory[repD10Cat5, 2] = repD10Cat5Piv2
 
fusionCategoryIndex[repD10][repD10Cat5] ^= 5
fMatrixFunction[repD10Cat5FMatrixFunction] ^= repD10Cat5FMatrixFunction
 
fusionCategory[repD10Cat5FMatrixFunction] ^= repD10Cat5
 
ring[repD10Cat5FMatrixFunction] ^= repD10
 
repD10Cat5FMatrixFunction[1, 1, 1, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 1, 3, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 1, 5, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 1, 7, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 3, 1, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 3, 3, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 3, 5, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 3, 7, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 4, 4, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 4, 4, 7] = {{-(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[1, 4, 5, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 4, 5, 6] = {{-(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[1, 4, 6, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 4, 7, 4] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 5, 1, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 5, 3, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 5, 4, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 5, 4, 6] = {{-(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[1, 5, 5, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 5, 5, 7] = {{(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[1, 5, 6, 4] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 5, 6, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 5, 7, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 5, 7, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 6, 1, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 6, 3, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 6, 4, 5] = {{I}}
 
repD10Cat5FMatrixFunction[1, 6, 5, 4] = {{-I}}
 
repD10Cat5FMatrixFunction[1, 6, 5, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 6, 6, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 6, 6, 5] = {{(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[1, 6, 7, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 6, 7, 4] = {{(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[1, 7, 4, 4] = {{I}}
 
repD10Cat5FMatrixFunction[1, 7, 4, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 7, 5, 5] = {{I}}
 
repD10Cat5FMatrixFunction[1, 7, 5, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 7, 6, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 7, 6, 4] = {{-(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[1, 7, 7, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[1, 7, 7, 5] = {{(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[2, 4, 4, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 4, 5, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 4, 6, 4] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 4, 7, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 5, 4, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 5, 4, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 5, 5, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 5, 5, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 5, 5, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 5, 6, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 5, 7, 4] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 6, 4, 4] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 6, 4, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 6, 5, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 6, 5, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 6, 6, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 6, 6, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 6, 7, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 6, 7, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 7, 4, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 7, 4, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 7, 5, 4] = {{-1}}
 
repD10Cat5FMatrixFunction[2, 7, 5, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 1, 1, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 1, 3, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 1, 5, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 1, 7, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 3, 1, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 3, 3, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 3, 5, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 3, 7, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 4, 4, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 4, 4, 7] = {{(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[3, 4, 5, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 4, 5, 6] = {{(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[3, 4, 6, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 4, 6, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 5, 1, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 5, 3, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 5, 4, 6] = {{(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[3, 5, 5, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 5, 5, 7] = {{-(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[3, 5, 6, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 5, 7, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 6, 1, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 6, 3, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 6, 4, 5] = {{-I}}
 
repD10Cat5FMatrixFunction[3, 6, 4, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 6, 5, 4] = {{I}}
 
repD10Cat5FMatrixFunction[3, 6, 6, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 6, 6, 5] = {{(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[3, 6, 7, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 6, 7, 4] = {{(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[3, 7, 4, 4] = {{-I}}
 
repD10Cat5FMatrixFunction[3, 7, 5, 5] = {{-I}}
 
repD10Cat5FMatrixFunction[3, 7, 6, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 7, 6, 4] = {{-(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[3, 7, 7, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[3, 7, 7, 5] = {{(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[4, 1, 4, 1] = {{I}}
 
repD10Cat5FMatrixFunction[4, 1, 4, 3] = {{-I}}
 
repD10Cat5FMatrixFunction[4, 1, 5, 0] = {{I}}
 
repD10Cat5FMatrixFunction[4, 1, 5, 2] = {{-I}}
 
repD10Cat5FMatrixFunction[4, 2, 4, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 2, 4, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 2, 5, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 2, 5, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 2, 6, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 2, 7, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 3, 4, 1] = {{-I}}
 
repD10Cat5FMatrixFunction[4, 3, 4, 3] = {{I}}
 
repD10Cat5FMatrixFunction[4, 3, 5, 0] = {{-I}}
 
repD10Cat5FMatrixFunction[4, 3, 5, 2] = {{I}}
 
repD10Cat5FMatrixFunction[4, 3, 6, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 3, 7, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 4, 1, 1] = {{I}}
 
repD10Cat5FMatrixFunction[4, 4, 1, 3] = {{I}}
 
repD10Cat5FMatrixFunction[4, 4, 1, 7] = {{(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[4, 4, 2, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 4, 2, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 4, 2, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 4, 3, 1] = {{-I}}
 
repD10Cat5FMatrixFunction[4, 4, 3, 3] = {{-I}}
 
repD10Cat5FMatrixFunction[4, 4, 3, 7] = {{-(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[4, 4, 4, 4] = {{1/2, 1/2, -1/2}, 
    {-1/2, -1/2, -1/2}, {-1, 1, 0}}
 
repD10Cat5FMatrixFunction[4, 4, 4, 6] = {{(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[4, 4, 5, 5] = {{I/2, I/2, -I/2}, 
    {-I/2, -I/2, -I/2}, {-(-1)^(9/10), (-1)^(9/10), 0}}
 
repD10Cat5FMatrixFunction[4, 4, 5, 7] = {{-(-1)^(4/5)}}
 
repD10Cat5FMatrixFunction[4, 4, 6, 4] = {{-(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[4, 4, 6, 6] = {{-1, 1}, {-1/2, -1/2}}
 
repD10Cat5FMatrixFunction[4, 4, 7, 5] = {{I}}
 
repD10Cat5FMatrixFunction[4, 4, 7, 7] = {{-(-1)^(9/10), (-1)^(9/10)}, 
    {-1/2, -1/2}}
 
repD10Cat5FMatrixFunction[4, 5, 1, 0] = {{I}}
 
repD10Cat5FMatrixFunction[4, 5, 1, 2] = {{I}}
 
repD10Cat5FMatrixFunction[4, 5, 1, 6] = {{(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[4, 5, 2, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 5, 2, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 5, 2, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 5, 3, 0] = {{-I}}
 
repD10Cat5FMatrixFunction[4, 5, 3, 2] = {{-I}}
 
repD10Cat5FMatrixFunction[4, 5, 3, 6] = {{-(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[4, 5, 4, 5] = {{-I/2, -I/2, (-1)^(3/5)/2}, 
    {-I/2, -I/2, -(-1)^(3/5)/2}, {-(-1)^(2/5), (-1)^(2/5), 0}}
 
repD10Cat5FMatrixFunction[4, 5, 4, 7] = {{-(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[4, 5, 5, 4] = {{-1/2, -1/2, (-1)^(1/10)/2}, 
    {-1/2, -1/2, -(-1)^(1/10)/2}, {I, -I, 0}}
 
repD10Cat5FMatrixFunction[4, 5, 6, 1] = {{(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[4, 5, 6, 3] = {{-(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[4, 5, 6, 5] = {{(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[4, 5, 6, 7] = {{-(-1)^(2/5), (-1)^(2/5)}, 
    {I/2, I/2}}
 
repD10Cat5FMatrixFunction[4, 5, 7, 0] = {{(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[4, 5, 7, 2] = {{-(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[4, 5, 7, 4] = {{-(-1)^(1/5)}}
 
repD10Cat5FMatrixFunction[4, 5, 7, 6] = {{I, -I}, {I/2, I/2}}
 
repD10Cat5FMatrixFunction[4, 6, 1, 5] = {{I}}
 
repD10Cat5FMatrixFunction[4, 6, 2, 4] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 6, 2, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 6, 3, 5] = {{-I}}
 
repD10Cat5FMatrixFunction[4, 6, 3, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 6, 4, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 6, 4, 4] = {{(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[4, 6, 4, 6] = {{0, -2*(-1)^(3/5)}, 
    {-(-1)^(3/5)/2, 0}}
 
repD10Cat5FMatrixFunction[4, 6, 5, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 6, 5, 5] = {{-(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[4, 6, 5, 7] = {{0, -2}, {(-1)^(1/5)/2, 0}}
 
repD10Cat5FMatrixFunction[4, 6, 6, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 6, 6, 4] = {{-1/2, -1}, {1/2, -1}}
 
repD10Cat5FMatrixFunction[4, 6, 6, 6] = {{(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[4, 6, 7, 1] = {{-(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[4, 6, 7, 3] = {{(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[4, 6, 7, 5] = {{-I/2, (-1)^(2/5)}, 
    {I/2, (-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[4, 6, 7, 7] = {{(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[4, 7, 1, 4] = {{I}}
 
repD10Cat5FMatrixFunction[4, 7, 1, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 7, 2, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 7, 2, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 7, 3, 4] = {{-I}}
 
repD10Cat5FMatrixFunction[4, 7, 4, 5] = {{-(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[4, 7, 4, 7] = {{0, -2}, {-(-1)^(7/10)/2, 0}}
 
repD10Cat5FMatrixFunction[4, 7, 5, 4] = {{(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[4, 7, 5, 6] = {{0, -2*(-1)^(3/5)}, 
    {-(-1)^(1/10)/2, 0}}
 
repD10Cat5FMatrixFunction[4, 7, 6, 1] = {{(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[4, 7, 6, 3] = {{(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[4, 7, 6, 5] = {{1/2, -(-1)^(2/5)}, 
    {1/2, (-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[4, 7, 6, 7] = {{-(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[4, 7, 7, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 7, 7, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[4, 7, 7, 4] = {{-I/2, 1}, {-I/2, -1}}
 
repD10Cat5FMatrixFunction[4, 7, 7, 6] = {{-(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[5, 1, 1, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 1, 3, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 1, 4, 0] = {{I}}
 
repD10Cat5FMatrixFunction[5, 1, 4, 2] = {{-I}}
 
repD10Cat5FMatrixFunction[5, 1, 5, 1] = {{-I}}
 
repD10Cat5FMatrixFunction[5, 1, 5, 3] = {{I}}
 
repD10Cat5FMatrixFunction[5, 1, 5, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 1, 6, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 1, 7, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 2, 4, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 2, 4, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 2, 5, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 2, 5, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 2, 6, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 2, 7, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 3, 1, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 3, 3, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 3, 4, 0] = {{-I}}
 
repD10Cat5FMatrixFunction[5, 3, 4, 2] = {{I}}
 
repD10Cat5FMatrixFunction[5, 3, 5, 1] = {{I}}
 
repD10Cat5FMatrixFunction[5, 3, 5, 3] = {{-I}}
 
repD10Cat5FMatrixFunction[5, 3, 5, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 3, 7, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 3, 7, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 4, 1, 0] = {{-I}}
 
repD10Cat5FMatrixFunction[5, 4, 1, 2] = {{-I}}
 
repD10Cat5FMatrixFunction[5, 4, 1, 6] = {{(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[5, 4, 2, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 4, 3, 0] = {{-I}}
 
repD10Cat5FMatrixFunction[5, 4, 3, 2] = {{-I}}
 
repD10Cat5FMatrixFunction[5, 4, 3, 6] = {{-(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[5, 4, 4, 5] = {{1/2, -1/2, (-1)^(3/5)/2}, 
    {-1/2, 1/2, (-1)^(3/5)/2}, {-1, -1, 0}}
 
repD10Cat5FMatrixFunction[5, 4, 4, 7] = {{I}}
 
repD10Cat5FMatrixFunction[5, 4, 5, 4] = {{I/2, -I/2, (-1)^(1/10)/2}, 
    {-I/2, I/2, (-1)^(1/10)/2}, {(-1)^(9/10), (-1)^(9/10), 0}}
 
repD10Cat5FMatrixFunction[5, 4, 5, 6] = {{-(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[5, 4, 6, 1] = {{(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[5, 4, 6, 3] = {{(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[5, 4, 6, 5] = {{-(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[5, 4, 6, 7] = {{-(-1)^(9/10), -(-1)^(9/10)}, 
    {1/2, -1/2}}
 
repD10Cat5FMatrixFunction[5, 4, 7, 0] = {{-(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[5, 4, 7, 2] = {{-(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[5, 4, 7, 4] = {{-(-1)^(1/5)}}
 
repD10Cat5FMatrixFunction[5, 4, 7, 6] = {{1, 1}, {-1/2, 1/2}}
 
repD10Cat5FMatrixFunction[5, 5, 1, 1] = {{-I}}
 
repD10Cat5FMatrixFunction[5, 5, 1, 3] = {{-I}}
 
repD10Cat5FMatrixFunction[5, 5, 1, 7] = {{-(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[5, 5, 2, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 5, 3, 1] = {{-I}}
 
repD10Cat5FMatrixFunction[5, 5, 3, 3] = {{-I}}
 
repD10Cat5FMatrixFunction[5, 5, 3, 7] = {{(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[5, 5, 4, 4] = {{-I/2, I/2, -1/2}, {-I/2, I/2, 1/2}, 
    {-(-1)^(2/5), -(-1)^(2/5), 0}}
 
repD10Cat5FMatrixFunction[5, 5, 4, 6] = {{(-1)^(3/10)}}
 
repD10Cat5FMatrixFunction[5, 5, 5, 5] = {{1/2, -1/2, I/2}, {1/2, -1/2, -I/2}, 
    {I, I, 0}}
 
repD10Cat5FMatrixFunction[5, 5, 5, 7] = {{-(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[5, 5, 6, 0] = {{I}}
 
repD10Cat5FMatrixFunction[5, 5, 6, 2] = {{-I}}
 
repD10Cat5FMatrixFunction[5, 5, 6, 4] = {{(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[5, 5, 6, 6] = {{I, I}, {I/2, -I/2}}
 
repD10Cat5FMatrixFunction[5, 5, 7, 1] = {{I}}
 
repD10Cat5FMatrixFunction[5, 5, 7, 3] = {{-I}}
 
repD10Cat5FMatrixFunction[5, 5, 7, 5] = {{-I}}
 
repD10Cat5FMatrixFunction[5, 5, 7, 7] = {{-(-1)^(2/5), -(-1)^(2/5)}, 
    {I/2, -I/2}}
 
repD10Cat5FMatrixFunction[5, 6, 1, 4] = {{-I}}
 
repD10Cat5FMatrixFunction[5, 6, 2, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 6, 2, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 6, 3, 4] = {{I}}
 
repD10Cat5FMatrixFunction[5, 6, 3, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 6, 4, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 6, 4, 5] = {{-(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[5, 6, 4, 7] = {{0, -2*I}, {-(-1)^(7/10)/2, 0}}
 
repD10Cat5FMatrixFunction[5, 6, 5, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 6, 5, 4] = {{-(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[5, 6, 5, 6] = {{0, -2*(-1)^(1/10)}, 
    {(-1)^(1/10)/2, 0}}
 
repD10Cat5FMatrixFunction[5, 6, 6, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 6, 6, 5] = {{-1/2, (-1)^(2/5)}, 
    {1/2, (-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[5, 6, 6, 7] = {{(-1)^(3/10)}}
 
repD10Cat5FMatrixFunction[5, 6, 7, 0] = {{-(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[5, 6, 7, 2] = {{(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[5, 6, 7, 4] = {{I/2, 1}, {-I/2, 1}}
 
repD10Cat5FMatrixFunction[5, 6, 7, 6] = {{I}}
 
repD10Cat5FMatrixFunction[5, 7, 1, 5] = {{I}}
 
repD10Cat5FMatrixFunction[5, 7, 2, 4] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 7, 2, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 7, 3, 5] = {{-I}}
 
repD10Cat5FMatrixFunction[5, 7, 3, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 7, 4, 4] = {{-(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[5, 7, 4, 6] = {{0, 2*(-1)^(1/10)}, 
    {(-1)^(3/5)/2, 0}}
 
repD10Cat5FMatrixFunction[5, 7, 5, 5] = {{(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[5, 7, 5, 7] = {{0, -2*I}, {-(-1)^(1/5)/2, 0}}
 
repD10Cat5FMatrixFunction[5, 7, 6, 0] = {{-(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[5, 7, 6, 2] = {{-(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[5, 7, 6, 4] = {{1/2, -1}, {1/2, 1}}
 
repD10Cat5FMatrixFunction[5, 7, 7, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 7, 7, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[5, 7, 7, 5] = {{-I/2, (-1)^(2/5)}, 
    {-I/2, -(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[5, 7, 7, 7] = {{(-1)^(4/5)}}
 
repD10Cat5FMatrixFunction[6, 1, 6, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 1, 7, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 2, 4, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 2, 5, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 2, 6, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 2, 6, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 2, 7, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 2, 7, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 3, 4, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 3, 5, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 3, 6, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 3, 7, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 4, 1, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 4, 2, 4] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 4, 3, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 4, 3, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 4, 4, 4] = {{-(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[6, 4, 4, 6] = {{-1/2, -1}, {-1/2, 1}}
 
repD10Cat5FMatrixFunction[6, 4, 5, 1] = {{(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[6, 4, 5, 3] = {{(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[6, 4, 5, 5] = {{-(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[6, 4, 5, 7] = {{-(-1)^(1/10)/2, I}, 
    {-(-1)^(1/10)/2, -I}}
 
repD10Cat5FMatrixFunction[6, 4, 6, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 4, 6, 4] = {{0, 2*(-1)^(2/5)}, {(-1)^(2/5)/2, 0}}
 
repD10Cat5FMatrixFunction[6, 4, 6, 6] = {{-(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[6, 4, 7, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 4, 7, 5] = {{0, -2*(-1)^(3/10)}, {-I/2, 0}}
 
repD10Cat5FMatrixFunction[6, 4, 7, 7] = {{-(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[6, 5, 1, 4] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 5, 1, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 5, 2, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 5, 3, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 5, 4, 1] = {{-(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[6, 5, 4, 3] = {{(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[6, 5, 4, 5] = {{(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[6, 5, 4, 7] = {{(-1)^(3/5)/2, -1}, 
    {-(-1)^(3/5)/2, -1}}
 
repD10Cat5FMatrixFunction[6, 5, 5, 0] = {{I}}
 
repD10Cat5FMatrixFunction[6, 5, 5, 2] = {{-I}}
 
repD10Cat5FMatrixFunction[6, 5, 5, 4] = {{(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[6, 5, 5, 6] = {{I/2, -I}, {-I/2, -I}}
 
repD10Cat5FMatrixFunction[6, 5, 6, 5] = {{0, 2*(-1)^(3/10)}, {-I/2, 0}}
 
repD10Cat5FMatrixFunction[6, 5, 6, 7] = {{-(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[6, 5, 7, 4] = {{0, -2*(-1)^(2/5)}, 
    {(-1)^(2/5)/2, 0}}
 
repD10Cat5FMatrixFunction[6, 5, 7, 6] = {{-(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[6, 6, 1, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 6, 1, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 6, 1, 5] = {{-(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[6, 6, 3, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 6, 3, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 6, 3, 5] = {{-(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[6, 6, 4, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 6, 4, 4] = {{-1, -1}, {-1/2, 1/2}}
 
repD10Cat5FMatrixFunction[6, 6, 4, 6] = {{(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[6, 6, 5, 1] = {{-I}}
 
repD10Cat5FMatrixFunction[6, 6, 5, 3] = {{I}}
 
repD10Cat5FMatrixFunction[6, 6, 5, 5] = 
   {{-1, -1}, {-(-1)^(3/5)/2, (-1)^(3/5)/2}}
 
repD10Cat5FMatrixFunction[6, 6, 5, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 6, 6, 4] = {{-(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[6, 6, 6, 6] = {{1/2, -1/2, -1}, {1/2, -1/2, 1}, 
    {-1/2, -1/2, 0}}
 
repD10Cat5FMatrixFunction[6, 6, 7, 5] = {{(-1)^(7/10)}}
 
repD10Cat5FMatrixFunction[6, 6, 7, 7] = {{-1/2, 1/2, 1}, {-1/2, 1/2, -1}, 
    {-(-1)^(3/5)/2, -(-1)^(3/5)/2, 0}}
 
repD10Cat5FMatrixFunction[6, 7, 1, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 7, 1, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 7, 1, 4] = {{(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[6, 7, 3, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 7, 3, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[6, 7, 3, 4] = {{(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[6, 7, 4, 1] = {{(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[6, 7, 4, 3] = {{(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[6, 7, 4, 5] = 
   {{1, 1}, {(-1)^(3/5)/2, -(-1)^(3/5)/2}}
 
repD10Cat5FMatrixFunction[6, 7, 4, 7] = {{-(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[6, 7, 5, 0] = {{(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[6, 7, 5, 2] = {{(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[6, 7, 5, 4] = {{1, 1}, {1/2, -1/2}}
 
repD10Cat5FMatrixFunction[6, 7, 5, 6] = {{(-1)^(4/5)}}
 
repD10Cat5FMatrixFunction[6, 7, 6, 5] = {{-(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[6, 7, 6, 7] = {{-1/2, 1/2, -(-1)^(2/5)}, 
    {1/2, -1/2, -(-1)^(2/5)}, {(-1)^(3/5)/2, (-1)^(3/5)/2, 0}}
 
repD10Cat5FMatrixFunction[6, 7, 7, 6] = {{1/2, -1/2, (-1)^(2/5)}, 
    {-1/2, 1/2, (-1)^(2/5)}, {1/2, 1/2, 0}}
 
repD10Cat5FMatrixFunction[7, 1, 1, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 1, 3, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 1, 4, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 1, 5, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 1, 6, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 1, 7, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 1, 7, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 2, 4, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 2, 5, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 2, 6, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 2, 6, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 2, 7, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 2, 7, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 3, 1, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 3, 3, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 3, 5, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 3, 5, 7] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 3, 6, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 3, 7, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 3, 7, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 4, 1, 4] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 4, 1, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 4, 2, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 4, 3, 6] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 4, 4, 1] = {{-I}}
 
repD10Cat5FMatrixFunction[7, 4, 4, 3] = {{-I}}
 
repD10Cat5FMatrixFunction[7, 4, 4, 5] = {{-(-1)^(7/10)}}
 
repD10Cat5FMatrixFunction[7, 4, 4, 7] = {{(-1)^(3/5)/2, -1}, 
    {(-1)^(3/5)/2, 1}}
 
repD10Cat5FMatrixFunction[7, 4, 5, 0] = {{-(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[7, 4, 5, 2] = {{-(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[7, 4, 5, 4] = {{I}}
 
repD10Cat5FMatrixFunction[7, 4, 5, 6] = {{I/2, I}, {I/2, -I}}
 
repD10Cat5FMatrixFunction[7, 4, 6, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 4, 6, 5] = {{0, 2*(-1)^(3/10)}, {I/2, 0}}
 
repD10Cat5FMatrixFunction[7, 4, 6, 7] = {{-(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[7, 4, 7, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 4, 7, 4] = {{0, 2*(-1)^(2/5)}, {(-1)^(2/5)/2, 0}}
 
repD10Cat5FMatrixFunction[7, 4, 7, 6] = {{(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[7, 5, 1, 5] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 5, 2, 4] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 5, 4, 0] = {{(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[7, 5, 4, 2] = {{-(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[7, 5, 4, 4] = {{-I}}
 
repD10Cat5FMatrixFunction[7, 5, 4, 6] = {{-1/2, 1}, {1/2, 1}}
 
repD10Cat5FMatrixFunction[7, 5, 5, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 5, 5, 5] = {{-(-1)^(7/10)}}
 
repD10Cat5FMatrixFunction[7, 5, 5, 7] = {{(-1)^(1/10)/2, -I}, 
    {-(-1)^(1/10)/2, -I}}
 
repD10Cat5FMatrixFunction[7, 5, 6, 4] = {{0, -2*(-1)^(2/5)}, 
    {-(-1)^(2/5)/2, 0}}
 
repD10Cat5FMatrixFunction[7, 5, 6, 6] = {{(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[7, 5, 7, 5] = {{0, 2*(-1)^(3/10)}, {I/2, 0}}
 
repD10Cat5FMatrixFunction[7, 5, 7, 7] = {{(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[7, 6, 1, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 6, 1, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 6, 1, 4] = {{-(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[7, 6, 2, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 6, 2, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 6, 3, 4] = {{-(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[7, 6, 4, 1] = {{-(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[7, 6, 4, 3] = {{(-1)^(2/5)}}
 
repD10Cat5FMatrixFunction[7, 6, 4, 5] = 
   {{-I, I}, {-(-1)^(3/5)/2, -(-1)^(3/5)/2}}
 
repD10Cat5FMatrixFunction[7, 6, 4, 7] = {{-(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[7, 6, 5, 0] = {{(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[7, 6, 5, 2] = {{-(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[7, 6, 5, 4] = {{I, -I}, {1/2, 1/2}}
 
repD10Cat5FMatrixFunction[7, 6, 5, 6] = {{(-1)^(3/10)}}
 
repD10Cat5FMatrixFunction[7, 6, 6, 5] = {{-I}}
 
repD10Cat5FMatrixFunction[7, 6, 6, 7] = {{-1/2, -1/2, (-1)^(2/5)}, 
    {-1/2, -1/2, -(-1)^(2/5)}, {1/2, -1/2, 0}}
 
repD10Cat5FMatrixFunction[7, 6, 7, 4] = {{(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[7, 6, 7, 6] = {{-1/2, -1/2, -(-1)^(2/5)}, 
    {-1/2, -1/2, (-1)^(2/5)}, {-(-1)^(3/5)/2, (-1)^(3/5)/2, 0}}
 
repD10Cat5FMatrixFunction[7, 7, 1, 1] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 7, 1, 3] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 7, 1, 5] = {{-(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[7, 7, 2, 0] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 7, 2, 2] = {{-1}}
 
repD10Cat5FMatrixFunction[7, 7, 3, 5] = {{-(-1)^(3/5)}}
 
repD10Cat5FMatrixFunction[7, 7, 4, 4] = {{I, -I}, {-1/2, -1/2}}
 
repD10Cat5FMatrixFunction[7, 7, 4, 6] = {{(-1)^(9/10)}}
 
repD10Cat5FMatrixFunction[7, 7, 5, 1] = {{-I}}
 
repD10Cat5FMatrixFunction[7, 7, 5, 3] = {{-I}}
 
repD10Cat5FMatrixFunction[7, 7, 5, 5] = 
   {{I, -I}, {-(-1)^(3/5)/2, -(-1)^(3/5)/2}}
 
repD10Cat5FMatrixFunction[7, 7, 5, 7] = {{-I}}
 
repD10Cat5FMatrixFunction[7, 7, 6, 4] = {{-(-1)^(1/5)}}
 
repD10Cat5FMatrixFunction[7, 7, 6, 6] = {{-1/2, -1/2, 1}, {1/2, 1/2, 1}, 
    {-(-1)^(3/5)/2, (-1)^(3/5)/2, 0}}
 
repD10Cat5FMatrixFunction[7, 7, 7, 5] = {{-(-1)^(1/10)}}
 
repD10Cat5FMatrixFunction[7, 7, 7, 7] = {{1/2, 1/2, 1}, {-1/2, -1/2, 1}, 
    {-1/2, 1/2, 0}}
 
repD10Cat5FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repD10Cat5], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
repD10Cat5FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repD10Cat5], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[repD10Cat5Piv1] ^= {}
 
fusionCategory[repD10Cat5Piv1] ^= repD10Cat5
 
repD10Cat5Piv1 /: modularCategory[repD10Cat5Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repD10Cat5Piv1] ^= repD10Cat5Piv1
 
pivotalIsomorphism[repD10Cat5Piv1] ^= repD10Cat5Piv1PivotalIsomorphism
 
ring[repD10Cat5Piv1] ^= repD10
 
sphericalCategory[repD10Cat5Piv1] ^= repD10Cat5Piv1
 
(pivotalCategoryIndex[fusionCategory[repD10Cat5]][pivotalCategory[#1]] & )[
    repD10Cat5Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[repD10Cat5]][
      sphericalCategory[#1]] & )[repD10Cat5Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[repD10Cat5Piv1PivotalIsomorphism] ^= repD10Cat5
 
pivotalCategory[repD10Cat5Piv1PivotalIsomorphism] ^= repD10Cat5Piv1
 
pivotalIsomorphism[repD10Cat5Piv1PivotalIsomorphism] ^= 
   repD10Cat5Piv1PivotalIsomorphism
 
repD10Cat5Piv1PivotalIsomorphism[0] = 1
 
repD10Cat5Piv1PivotalIsomorphism[1] = 1
 
repD10Cat5Piv1PivotalIsomorphism[2] = 1
 
repD10Cat5Piv1PivotalIsomorphism[3] = 1
 
repD10Cat5Piv1PivotalIsomorphism[4] = 1
 
repD10Cat5Piv1PivotalIsomorphism[5] = -1
 
repD10Cat5Piv1PivotalIsomorphism[6] = 1
 
repD10Cat5Piv1PivotalIsomorphism[7] = -1
balancedCategories[repD10Cat5Piv2] ^= {}
 
fusionCategory[repD10Cat5Piv2] ^= repD10Cat5
 
repD10Cat5Piv2 /: modularCategory[repD10Cat5Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repD10Cat5Piv2] ^= repD10Cat5Piv2
 
pivotalIsomorphism[repD10Cat5Piv2] ^= repD10Cat5Piv2PivotalIsomorphism
 
ring[repD10Cat5Piv2] ^= repD10
 
sphericalCategory[repD10Cat5Piv2] ^= repD10Cat5Piv2
 
(pivotalCategoryIndex[fusionCategory[repD10Cat5]][pivotalCategory[#1]] & )[
    repD10Cat5Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[repD10Cat5]][
      sphericalCategory[#1]] & )[repD10Cat5Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[repD10Cat5Piv2PivotalIsomorphism] ^= repD10Cat5
 
pivotalCategory[repD10Cat5Piv2PivotalIsomorphism] ^= repD10Cat5Piv2
 
pivotalIsomorphism[repD10Cat5Piv2PivotalIsomorphism] ^= 
   repD10Cat5Piv2PivotalIsomorphism
 
repD10Cat5Piv2PivotalIsomorphism[0] = 1
 
repD10Cat5Piv2PivotalIsomorphism[1] = -1
 
repD10Cat5Piv2PivotalIsomorphism[2] = 1
 
repD10Cat5Piv2PivotalIsomorphism[3] = -1
 
repD10Cat5Piv2PivotalIsomorphism[4] = 1
 
repD10Cat5Piv2PivotalIsomorphism[5] = 1
 
repD10Cat5Piv2PivotalIsomorphism[6] = 1
 
repD10Cat5Piv2PivotalIsomorphism[7] = 1
balancedCategories[repD10Cat6] ^= {}
 
braidedCategories[repD10Cat6] ^= {}
 
coeval[repD10Cat6] ^= 1/sixJFunction[repD10Cat6][#1, 
      dual[ring[repD10Cat6]][#1], #1, #1, 0, 0] & 
 
eval[repD10Cat6] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[repD10Cat6] ^= repD10Cat6FMatrixFunction
 
fusionCategory[repD10Cat6] ^= repD10Cat6
 
repD10Cat6 /: modularCategory[repD10Cat6, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[repD10Cat6] ^= {repD10Cat6Piv1, repD10Cat6Piv2}
 
repD10Cat6 /: pivotalCategory[repD10Cat6, 1] = repD10Cat6Piv1
 
repD10Cat6 /: pivotalCategory[repD10Cat6, 2] = repD10Cat6Piv2
 
repD10Cat6 /: pivotalCategory[repD10Cat6, {1, -1, 1, -1, 1, 1, 1, 1}] = 
    repD10Cat6Piv2
 
repD10Cat6 /: pivotalCategory[repD10Cat6, {1, 1, 1, 1, 1, -1, 1, -1}] = 
    repD10Cat6Piv1
 
ring[repD10Cat6] ^= repD10
 
repD10Cat6 /: sphericalCategory[repD10Cat6, 1] = repD10Cat6Piv1
 
repD10Cat6 /: sphericalCategory[repD10Cat6, 2] = repD10Cat6Piv2
 
fusionCategoryIndex[repD10][repD10Cat6] ^= 6
fMatrixFunction[repD10Cat6FMatrixFunction] ^= repD10Cat6FMatrixFunction
 
fusionCategory[repD10Cat6FMatrixFunction] ^= repD10Cat6
 
ring[repD10Cat6FMatrixFunction] ^= repD10
 
repD10Cat6FMatrixFunction[1, 1, 1, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 1, 3, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 1, 5, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 1, 7, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 3, 1, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 3, 3, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 3, 5, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 3, 7, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 4, 4, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 4, 4, 7] = {{(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[1, 4, 5, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 4, 5, 6] = {{(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[1, 4, 7, 4] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 4, 7, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 5, 1, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 5, 3, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 5, 4, 0] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 5, 4, 6] = {{(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[1, 5, 5, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 5, 5, 7] = {{-(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[1, 5, 6, 4] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 5, 7, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 6, 1, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 6, 3, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 6, 4, 5] = {{I}}
 
repD10Cat6FMatrixFunction[1, 6, 5, 4] = {{-I}}
 
repD10Cat6FMatrixFunction[1, 6, 5, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 6, 6, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 6, 6, 5] = {{-(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[1, 6, 7, 0] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 6, 7, 4] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[1, 7, 4, 4] = {{I}}
 
repD10Cat6FMatrixFunction[1, 7, 4, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 7, 5, 5] = {{I}}
 
repD10Cat6FMatrixFunction[1, 7, 5, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 7, 6, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 7, 6, 4] = {{(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[1, 7, 7, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[1, 7, 7, 5] = {{-(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[2, 4, 4, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 4, 5, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 4, 6, 4] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 4, 7, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 5, 4, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 5, 4, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 5, 5, 0] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 5, 5, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 5, 5, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 5, 6, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 5, 7, 4] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 6, 4, 4] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 6, 4, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 6, 5, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 6, 5, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 6, 6, 0] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 6, 6, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 6, 7, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 6, 7, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 7, 4, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 7, 4, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 7, 5, 4] = {{-1}}
 
repD10Cat6FMatrixFunction[2, 7, 5, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 1, 1, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 1, 3, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 1, 5, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 1, 7, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 3, 1, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 3, 3, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 3, 5, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 3, 7, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 4, 4, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 4, 4, 7] = {{-(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[3, 4, 5, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 4, 5, 6] = {{-(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[3, 4, 6, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 4, 7, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 5, 1, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 5, 3, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 5, 4, 6] = {{-(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[3, 5, 5, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 5, 5, 7] = {{(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[3, 6, 1, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 6, 3, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 6, 4, 5] = {{-I}}
 
repD10Cat6FMatrixFunction[3, 6, 4, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 6, 5, 4] = {{I}}
 
repD10Cat6FMatrixFunction[3, 6, 6, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 6, 6, 5] = {{-(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[3, 6, 7, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 6, 7, 4] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[3, 7, 4, 4] = {{-I}}
 
repD10Cat6FMatrixFunction[3, 7, 5, 5] = {{-I}}
 
repD10Cat6FMatrixFunction[3, 7, 6, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 7, 6, 4] = {{(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[3, 7, 7, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[3, 7, 7, 5] = {{-(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[4, 1, 4, 1] = {{I}}
 
repD10Cat6FMatrixFunction[4, 1, 4, 3] = {{-I}}
 
repD10Cat6FMatrixFunction[4, 1, 5, 0] = {{I}}
 
repD10Cat6FMatrixFunction[4, 1, 5, 2] = {{-I}}
 
repD10Cat6FMatrixFunction[4, 2, 4, 0] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 2, 4, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 2, 5, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 2, 5, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 2, 6, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 2, 7, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 3, 4, 1] = {{-I}}
 
repD10Cat6FMatrixFunction[4, 3, 4, 3] = {{I}}
 
repD10Cat6FMatrixFunction[4, 3, 5, 0] = {{-I}}
 
repD10Cat6FMatrixFunction[4, 3, 5, 2] = {{I}}
 
repD10Cat6FMatrixFunction[4, 3, 6, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 3, 7, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 4, 1, 1] = {{I}}
 
repD10Cat6FMatrixFunction[4, 4, 1, 3] = {{I}}
 
repD10Cat6FMatrixFunction[4, 4, 1, 7] = {{(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[4, 4, 2, 0] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 4, 2, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 4, 2, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 4, 3, 1] = {{-I}}
 
repD10Cat6FMatrixFunction[4, 4, 3, 3] = {{-I}}
 
repD10Cat6FMatrixFunction[4, 4, 3, 7] = {{-(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[4, 4, 4, 4] = {{1/2, 1/2, -1/2}, 
    {-1/2, -1/2, -1/2}, {-1, 1, 0}}
 
repD10Cat6FMatrixFunction[4, 4, 4, 6] = {{(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[4, 4, 5, 5] = {{I/2, I/2, -I/2}, 
    {-I/2, -I/2, -I/2}, {(-1)^(3/10), -(-1)^(3/10), 0}}
 
repD10Cat6FMatrixFunction[4, 4, 5, 7] = {{-(-1)^(3/5)}}
 
repD10Cat6FMatrixFunction[4, 4, 6, 4] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[4, 4, 6, 6] = {{-1, 1}, {-1/2, -1/2}}
 
repD10Cat6FMatrixFunction[4, 4, 7, 5] = {{I}}
 
repD10Cat6FMatrixFunction[4, 4, 7, 7] = {{(-1)^(3/10), -(-1)^(3/10)}, 
    {-1/2, -1/2}}
 
repD10Cat6FMatrixFunction[4, 5, 1, 0] = {{I}}
 
repD10Cat6FMatrixFunction[4, 5, 1, 2] = {{I}}
 
repD10Cat6FMatrixFunction[4, 5, 1, 6] = {{(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[4, 5, 2, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 5, 2, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 5, 2, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 5, 3, 0] = {{-I}}
 
repD10Cat6FMatrixFunction[4, 5, 3, 2] = {{-I}}
 
repD10Cat6FMatrixFunction[4, 5, 3, 6] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[4, 5, 4, 5] = {{-I/2, -I/2, (-1)^(1/5)/2}, 
    {-I/2, -I/2, -(-1)^(1/5)/2}, {-(-1)^(4/5), (-1)^(4/5), 0}}
 
repD10Cat6FMatrixFunction[4, 5, 4, 7] = {{(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[4, 5, 5, 4] = {{-1/2, -1/2, -(-1)^(7/10)/2}, 
    {-1/2, -1/2, (-1)^(7/10)/2}, {I, -I, 0}}
 
repD10Cat6FMatrixFunction[4, 5, 6, 1] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[4, 5, 6, 3] = {{(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[4, 5, 6, 5] = {{-(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[4, 5, 6, 7] = {{-(-1)^(4/5), (-1)^(4/5)}, 
    {I/2, I/2}}
 
repD10Cat6FMatrixFunction[4, 5, 7, 0] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[4, 5, 7, 2] = {{(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[4, 5, 7, 4] = {{(-1)^(2/5)}}
 
repD10Cat6FMatrixFunction[4, 5, 7, 6] = {{I, -I}, {I/2, I/2}}
 
repD10Cat6FMatrixFunction[4, 6, 1, 5] = {{I}}
 
repD10Cat6FMatrixFunction[4, 6, 2, 4] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 6, 2, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 6, 3, 5] = {{-I}}
 
repD10Cat6FMatrixFunction[4, 6, 3, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 6, 4, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 6, 4, 4] = {{(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[4, 6, 4, 6] = {{0, -2*(-1)^(1/5)}, 
    {-(-1)^(1/5)/2, 0}}
 
repD10Cat6FMatrixFunction[4, 6, 5, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 6, 5, 5] = {{-(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[4, 6, 5, 7] = {{0, 2}, {(-1)^(2/5)/2, 0}}
 
repD10Cat6FMatrixFunction[4, 6, 6, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 6, 6, 4] = {{-1/2, -1}, {1/2, -1}}
 
repD10Cat6FMatrixFunction[4, 6, 6, 6] = {{(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[4, 6, 7, 1] = {{(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[4, 6, 7, 3] = {{-(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[4, 6, 7, 5] = {{-I/2, (-1)^(4/5)}, 
    {I/2, (-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[4, 6, 7, 7] = {{(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[4, 7, 1, 4] = {{I}}
 
repD10Cat6FMatrixFunction[4, 7, 1, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 7, 2, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 7, 2, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[4, 7, 3, 4] = {{-I}}
 
repD10Cat6FMatrixFunction[4, 7, 4, 5] = {{-(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[4, 7, 4, 7] = {{0, 2}, {-(-1)^(9/10)/2, 0}}
 
repD10Cat6FMatrixFunction[4, 7, 5, 4] = {{(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[4, 7, 5, 6] = {{0, -2*(-1)^(1/5)}, 
    {(-1)^(7/10)/2, 0}}
 
repD10Cat6FMatrixFunction[4, 7, 6, 1] = {{(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[4, 7, 6, 3] = {{(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[4, 7, 6, 5] = {{-1/2, (-1)^(4/5)}, 
    {-1/2, -(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[4, 7, 6, 7] = {{(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[4, 7, 7, 4] = {{I/2, -1}, {I/2, 1}}
 
repD10Cat6FMatrixFunction[4, 7, 7, 6] = {{(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[5, 1, 1, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 1, 3, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 1, 4, 0] = {{I}}
 
repD10Cat6FMatrixFunction[5, 1, 4, 2] = {{-I}}
 
repD10Cat6FMatrixFunction[5, 1, 5, 1] = {{-I}}
 
repD10Cat6FMatrixFunction[5, 1, 5, 3] = {{I}}
 
repD10Cat6FMatrixFunction[5, 1, 5, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 1, 6, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 1, 7, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 2, 4, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 2, 4, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 2, 5, 0] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 2, 5, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 2, 6, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 2, 7, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 3, 1, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 3, 3, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 3, 4, 0] = {{-I}}
 
repD10Cat6FMatrixFunction[5, 3, 4, 2] = {{I}}
 
repD10Cat6FMatrixFunction[5, 3, 5, 1] = {{I}}
 
repD10Cat6FMatrixFunction[5, 3, 5, 3] = {{-I}}
 
repD10Cat6FMatrixFunction[5, 3, 5, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 3, 7, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 3, 7, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 4, 1, 0] = {{-I}}
 
repD10Cat6FMatrixFunction[5, 4, 1, 2] = {{-I}}
 
repD10Cat6FMatrixFunction[5, 4, 1, 6] = {{(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[5, 4, 2, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 4, 3, 0] = {{-I}}
 
repD10Cat6FMatrixFunction[5, 4, 3, 2] = {{-I}}
 
repD10Cat6FMatrixFunction[5, 4, 3, 6] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[5, 4, 4, 5] = {{1/2, -1/2, (-1)^(1/5)/2}, 
    {-1/2, 1/2, (-1)^(1/5)/2}, {-1, -1, 0}}
 
repD10Cat6FMatrixFunction[5, 4, 4, 7] = {{-I}}
 
repD10Cat6FMatrixFunction[5, 4, 5, 4] = {{I/2, -I/2, -(-1)^(7/10)/2}, 
    {-I/2, I/2, -(-1)^(7/10)/2}, {-(-1)^(3/10), -(-1)^(3/10), 0}}
 
repD10Cat6FMatrixFunction[5, 4, 5, 6] = {{(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[5, 4, 6, 1] = {{(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[5, 4, 6, 3] = {{(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[5, 4, 6, 5] = {{-(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[5, 4, 6, 7] = {{(-1)^(3/10), (-1)^(3/10)}, 
    {-1/2, 1/2}}
 
repD10Cat6FMatrixFunction[5, 4, 7, 0] = {{-(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[5, 4, 7, 2] = {{-(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[5, 4, 7, 4] = {{-(-1)^(2/5)}}
 
repD10Cat6FMatrixFunction[5, 4, 7, 6] = {{1, 1}, {1/2, -1/2}}
 
repD10Cat6FMatrixFunction[5, 5, 1, 1] = {{-I}}
 
repD10Cat6FMatrixFunction[5, 5, 1, 3] = {{-I}}
 
repD10Cat6FMatrixFunction[5, 5, 1, 7] = {{-(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[5, 5, 2, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 5, 3, 1] = {{-I}}
 
repD10Cat6FMatrixFunction[5, 5, 3, 3] = {{-I}}
 
repD10Cat6FMatrixFunction[5, 5, 3, 7] = {{(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[5, 5, 4, 4] = {{-I/2, I/2, -1/2}, {-I/2, I/2, 1/2}, 
    {-(-1)^(4/5), -(-1)^(4/5), 0}}
 
repD10Cat6FMatrixFunction[5, 5, 4, 6] = {{-(-1)^(1/10)}}
 
repD10Cat6FMatrixFunction[5, 5, 5, 5] = {{1/2, -1/2, I/2}, {1/2, -1/2, -I/2}, 
    {I, I, 0}}
 
repD10Cat6FMatrixFunction[5, 5, 5, 7] = {{-(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[5, 5, 6, 0] = {{I}}
 
repD10Cat6FMatrixFunction[5, 5, 6, 2] = {{-I}}
 
repD10Cat6FMatrixFunction[5, 5, 6, 4] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[5, 5, 6, 6] = {{I, I}, {-I/2, I/2}}
 
repD10Cat6FMatrixFunction[5, 5, 7, 1] = {{I}}
 
repD10Cat6FMatrixFunction[5, 5, 7, 3] = {{-I}}
 
repD10Cat6FMatrixFunction[5, 5, 7, 5] = {{I}}
 
repD10Cat6FMatrixFunction[5, 5, 7, 7] = {{-(-1)^(4/5), -(-1)^(4/5)}, 
    {-I/2, I/2}}
 
repD10Cat6FMatrixFunction[5, 6, 1, 4] = {{-I}}
 
repD10Cat6FMatrixFunction[5, 6, 2, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 6, 2, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 6, 3, 4] = {{I}}
 
repD10Cat6FMatrixFunction[5, 6, 3, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 6, 4, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 6, 4, 5] = {{-(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[5, 6, 4, 7] = {{0, 2*I}, {-(-1)^(9/10)/2, 0}}
 
repD10Cat6FMatrixFunction[5, 6, 5, 0] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 6, 5, 4] = {{-(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[5, 6, 5, 6] = {{0, 2*(-1)^(7/10)}, 
    {-(-1)^(7/10)/2, 0}}
 
repD10Cat6FMatrixFunction[5, 6, 6, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 6, 6, 5] = {{-1/2, (-1)^(4/5)}, 
    {1/2, (-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[5, 6, 6, 7] = {{(-1)^(1/10)}}
 
repD10Cat6FMatrixFunction[5, 6, 7, 0] = {{(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[5, 6, 7, 2] = {{-(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[5, 6, 7, 4] = {{I/2, 1}, {-I/2, 1}}
 
repD10Cat6FMatrixFunction[5, 6, 7, 6] = {{-I}}
 
repD10Cat6FMatrixFunction[5, 7, 1, 5] = {{I}}
 
repD10Cat6FMatrixFunction[5, 7, 2, 4] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 7, 2, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 7, 3, 5] = {{-I}}
 
repD10Cat6FMatrixFunction[5, 7, 3, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 7, 4, 4] = {{-(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[5, 7, 4, 6] = {{0, -2*(-1)^(7/10)}, 
    {(-1)^(1/5)/2, 0}}
 
repD10Cat6FMatrixFunction[5, 7, 5, 5] = {{(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[5, 7, 5, 7] = {{0, 2*I}, {-(-1)^(2/5)/2, 0}}
 
repD10Cat6FMatrixFunction[5, 7, 6, 0] = {{-(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[5, 7, 6, 2] = {{-(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[5, 7, 6, 4] = {{-1/2, 1}, {-1/2, -1}}
 
repD10Cat6FMatrixFunction[5, 7, 6, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[5, 7, 7, 5] = {{I/2, -(-1)^(4/5)}, 
    {I/2, (-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[5, 7, 7, 7] = {{(-1)^(3/5)}}
 
repD10Cat6FMatrixFunction[6, 1, 6, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 1, 7, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 2, 4, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 2, 5, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 2, 6, 0] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 2, 6, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 2, 7, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 2, 7, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 3, 4, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 3, 5, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 3, 6, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 3, 7, 0] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 4, 2, 4] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 4, 3, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 4, 4, 4] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[6, 4, 4, 6] = {{-1/2, -1}, {-1/2, 1}}
 
repD10Cat6FMatrixFunction[6, 4, 5, 1] = {{-(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[6, 4, 5, 3] = {{-(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[6, 4, 5, 5] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[6, 4, 5, 7] = {{(-1)^(7/10)/2, -I}, 
    {(-1)^(7/10)/2, I}}
 
repD10Cat6FMatrixFunction[6, 4, 6, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 4, 6, 4] = {{0, 2*(-1)^(4/5)}, {(-1)^(4/5)/2, 0}}
 
repD10Cat6FMatrixFunction[6, 4, 6, 6] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[6, 4, 7, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 4, 7, 5] = {{0, 2*(-1)^(1/10)}, {-I/2, 0}}
 
repD10Cat6FMatrixFunction[6, 4, 7, 7] = {{-(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[6, 5, 1, 4] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 5, 2, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 5, 4, 1] = {{-(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[6, 5, 4, 3] = {{(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[6, 5, 4, 5] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[6, 5, 4, 7] = {{(-1)^(1/5)/2, -1}, 
    {-(-1)^(1/5)/2, -1}}
 
repD10Cat6FMatrixFunction[6, 5, 5, 0] = {{I}}
 
repD10Cat6FMatrixFunction[6, 5, 5, 2] = {{-I}}
 
repD10Cat6FMatrixFunction[6, 5, 5, 4] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[6, 5, 5, 6] = {{I/2, I}, {-I/2, I}}
 
repD10Cat6FMatrixFunction[6, 5, 6, 5] = {{0, 2*(-1)^(1/10)}, {-I/2, 0}}
 
repD10Cat6FMatrixFunction[6, 5, 6, 7] = {{-(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[6, 5, 7, 4] = {{0, 2*(-1)^(4/5)}, {(-1)^(4/5)/2, 0}}
 
repD10Cat6FMatrixFunction[6, 5, 7, 6] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[6, 6, 1, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 6, 1, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 6, 1, 5] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[6, 6, 3, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 6, 3, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 6, 3, 5] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[6, 6, 4, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 6, 4, 4] = {{-1, -1}, {-1/2, 1/2}}
 
repD10Cat6FMatrixFunction[6, 6, 4, 6] = {{(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[6, 6, 5, 1] = {{I}}
 
repD10Cat6FMatrixFunction[6, 6, 5, 3] = {{-I}}
 
repD10Cat6FMatrixFunction[6, 6, 5, 5] = 
   {{-1, -1}, {(-1)^(1/5)/2, -(-1)^(1/5)/2}}
 
repD10Cat6FMatrixFunction[6, 6, 6, 4] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[6, 6, 6, 6] = {{1/2, -1/2, -1}, {1/2, -1/2, 1}, 
    {-1/2, -1/2, 0}}
 
repD10Cat6FMatrixFunction[6, 6, 7, 5] = {{-(-1)^(9/10)}}
 
repD10Cat6FMatrixFunction[6, 6, 7, 7] = {{-1/2, 1/2, 1}, {-1/2, 1/2, -1}, 
    {(-1)^(1/5)/2, (-1)^(1/5)/2, 0}}
 
repD10Cat6FMatrixFunction[6, 7, 1, 0] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 7, 1, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 7, 1, 4] = {{(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[6, 7, 3, 0] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 7, 3, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[6, 7, 3, 4] = {{(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[6, 7, 4, 1] = {{-(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[6, 7, 4, 3] = {{-(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[6, 7, 4, 5] = 
   {{1, 1}, {-(-1)^(1/5)/2, (-1)^(1/5)/2}}
 
repD10Cat6FMatrixFunction[6, 7, 4, 7] = {{(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[6, 7, 5, 0] = {{-(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[6, 7, 5, 2] = {{-(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[6, 7, 5, 4] = {{1, 1}, {1/2, -1/2}}
 
repD10Cat6FMatrixFunction[6, 7, 5, 6] = {{-(-1)^(3/5)}}
 
repD10Cat6FMatrixFunction[6, 7, 6, 5] = {{(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[6, 7, 6, 7] = {{1/2, -1/2, (-1)^(4/5)}, 
    {-1/2, 1/2, (-1)^(4/5)}, {-(-1)^(1/5)/2, -(-1)^(1/5)/2, 0}}
 
repD10Cat6FMatrixFunction[6, 7, 7, 6] = {{-1/2, 1/2, -(-1)^(4/5)}, 
    {1/2, -1/2, -(-1)^(4/5)}, {1/2, 1/2, 0}}
 
repD10Cat6FMatrixFunction[7, 1, 1, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 1, 3, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 1, 4, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 1, 5, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 1, 6, 0] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 1, 7, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 1, 7, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 2, 4, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 2, 5, 6] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 2, 6, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 2, 6, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 2, 7, 0] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 2, 7, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 3, 1, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 3, 3, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 3, 5, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 3, 5, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 3, 6, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 3, 7, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 3, 7, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 4, 1, 4] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 4, 2, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 4, 4, 1] = {{I}}
 
repD10Cat6FMatrixFunction[7, 4, 4, 3] = {{I}}
 
repD10Cat6FMatrixFunction[7, 4, 4, 5] = {{-(-1)^(9/10)}}
 
repD10Cat6FMatrixFunction[7, 4, 4, 7] = {{(-1)^(1/5)/2, -1}, 
    {(-1)^(1/5)/2, 1}}
 
repD10Cat6FMatrixFunction[7, 4, 5, 0] = {{(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[7, 4, 5, 2] = {{(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[7, 4, 5, 4] = {{-I}}
 
repD10Cat6FMatrixFunction[7, 4, 5, 6] = {{I/2, -I}, {I/2, I}}
 
repD10Cat6FMatrixFunction[7, 4, 6, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 4, 6, 5] = {{0, 2*(-1)^(1/10)}, {-I/2, 0}}
 
repD10Cat6FMatrixFunction[7, 4, 6, 7] = {{-(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[7, 4, 7, 0] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 4, 7, 4] = {{0, -2*(-1)^(4/5)}, 
    {-(-1)^(4/5)/2, 0}}
 
repD10Cat6FMatrixFunction[7, 4, 7, 6] = {{(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[7, 5, 1, 5] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 5, 1, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 5, 2, 4] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 5, 3, 7] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 5, 4, 0] = {{(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[7, 5, 4, 2] = {{-(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[7, 5, 4, 4] = {{-I}}
 
repD10Cat6FMatrixFunction[7, 5, 4, 6] = {{-1/2, 1}, {1/2, 1}}
 
repD10Cat6FMatrixFunction[7, 5, 5, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 5, 5, 5] = {{(-1)^(9/10)}}
 
repD10Cat6FMatrixFunction[7, 5, 5, 7] = {{-(-1)^(7/10)/2, I}, 
    {(-1)^(7/10)/2, I}}
 
repD10Cat6FMatrixFunction[7, 5, 6, 4] = {{0, -2*(-1)^(4/5)}, 
    {(-1)^(4/5)/2, 0}}
 
repD10Cat6FMatrixFunction[7, 5, 6, 6] = {{(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[7, 5, 7, 5] = {{0, -2*(-1)^(1/10)}, {-I/2, 0}}
 
repD10Cat6FMatrixFunction[7, 5, 7, 7] = {{(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[7, 6, 1, 0] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 6, 1, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 6, 1, 4] = {{-(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[7, 6, 2, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 6, 2, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 6, 3, 4] = {{-(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[7, 6, 4, 1] = {{-(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[7, 6, 4, 3] = {{(-1)^(4/5)}}
 
repD10Cat6FMatrixFunction[7, 6, 4, 5] = 
   {{I, -I}, {-(-1)^(1/5)/2, -(-1)^(1/5)/2}}
 
repD10Cat6FMatrixFunction[7, 6, 4, 7] = {{-(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[7, 6, 5, 0] = {{(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[7, 6, 5, 2] = {{-(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[7, 6, 5, 4] = {{-I, I}, {-1/2, -1/2}}
 
repD10Cat6FMatrixFunction[7, 6, 5, 6] = {{-(-1)^(1/10)}}
 
repD10Cat6FMatrixFunction[7, 6, 6, 5] = {{I}}
 
repD10Cat6FMatrixFunction[7, 6, 6, 7] = {{1/2, 1/2, (-1)^(4/5)}, 
    {1/2, 1/2, -(-1)^(4/5)}, {-1/2, 1/2, 0}}
 
repD10Cat6FMatrixFunction[7, 6, 7, 4] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[7, 6, 7, 6] = {{1/2, 1/2, -(-1)^(4/5)}, 
    {1/2, 1/2, (-1)^(4/5)}, {-(-1)^(1/5)/2, (-1)^(1/5)/2, 0}}
 
repD10Cat6FMatrixFunction[7, 7, 1, 1] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 7, 1, 3] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 7, 1, 5] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[7, 7, 2, 0] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 7, 2, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 7, 3, 5] = {{-(-1)^(1/5)}}
 
repD10Cat6FMatrixFunction[7, 7, 4, 0] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 7, 4, 2] = {{-1}}
 
repD10Cat6FMatrixFunction[7, 7, 4, 4] = {{-I, I}, {1/2, 1/2}}
 
repD10Cat6FMatrixFunction[7, 7, 4, 6] = {{-(-1)^(3/10)}}
 
repD10Cat6FMatrixFunction[7, 7, 5, 1] = {{-I}}
 
repD10Cat6FMatrixFunction[7, 7, 5, 3] = {{-I}}
 
repD10Cat6FMatrixFunction[7, 7, 5, 5] = 
   {{-I, I}, {-(-1)^(1/5)/2, -(-1)^(1/5)/2}}
 
repD10Cat6FMatrixFunction[7, 7, 5, 7] = {{I}}
 
repD10Cat6FMatrixFunction[7, 7, 6, 4] = {{-(-1)^(2/5)}}
 
repD10Cat6FMatrixFunction[7, 7, 6, 6] = {{-1/2, -1/2, -1}, {1/2, 1/2, -1}, 
    {-(-1)^(1/5)/2, (-1)^(1/5)/2, 0}}
 
repD10Cat6FMatrixFunction[7, 7, 7, 5] = {{-(-1)^(7/10)}}
 
repD10Cat6FMatrixFunction[7, 7, 7, 7] = {{1/2, 1/2, -1}, {-1/2, -1/2, -1}, 
    {1/2, -1/2, 0}}
 
repD10Cat6FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repD10Cat6], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
repD10Cat6FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[repD10Cat6], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[repD10Cat6Piv1] ^= {}
 
fusionCategory[repD10Cat6Piv1] ^= repD10Cat6
 
repD10Cat6Piv1 /: modularCategory[repD10Cat6Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repD10Cat6Piv1] ^= repD10Cat6Piv1
 
pivotalIsomorphism[repD10Cat6Piv1] ^= repD10Cat6Piv1PivotalIsomorphism
 
ring[repD10Cat6Piv1] ^= repD10
 
sphericalCategory[repD10Cat6Piv1] ^= repD10Cat6Piv1
 
(pivotalCategoryIndex[fusionCategory[repD10Cat6]][pivotalCategory[#1]] & )[
    repD10Cat6Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[repD10Cat6]][
      sphericalCategory[#1]] & )[repD10Cat6Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[repD10Cat6Piv1PivotalIsomorphism] ^= repD10Cat6
 
pivotalCategory[repD10Cat6Piv1PivotalIsomorphism] ^= repD10Cat6Piv1
 
pivotalIsomorphism[repD10Cat6Piv1PivotalIsomorphism] ^= 
   repD10Cat6Piv1PivotalIsomorphism
 
repD10Cat6Piv1PivotalIsomorphism[0] = 1
 
repD10Cat6Piv1PivotalIsomorphism[1] = 1
 
repD10Cat6Piv1PivotalIsomorphism[2] = 1
 
repD10Cat6Piv1PivotalIsomorphism[3] = 1
 
repD10Cat6Piv1PivotalIsomorphism[4] = 1
 
repD10Cat6Piv1PivotalIsomorphism[5] = -1
 
repD10Cat6Piv1PivotalIsomorphism[6] = 1
 
repD10Cat6Piv1PivotalIsomorphism[7] = -1
balancedCategories[repD10Cat6Piv2] ^= {}
 
fusionCategory[repD10Cat6Piv2] ^= repD10Cat6
 
repD10Cat6Piv2 /: modularCategory[repD10Cat6Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[repD10Cat6Piv2] ^= repD10Cat6Piv2
 
pivotalIsomorphism[repD10Cat6Piv2] ^= repD10Cat6Piv2PivotalIsomorphism
 
ring[repD10Cat6Piv2] ^= repD10
 
sphericalCategory[repD10Cat6Piv2] ^= repD10Cat6Piv2
 
(pivotalCategoryIndex[fusionCategory[repD10Cat6]][pivotalCategory[#1]] & )[
    repD10Cat6Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[repD10Cat6]][
      sphericalCategory[#1]] & )[repD10Cat6Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[repD10Cat6Piv2PivotalIsomorphism] ^= repD10Cat6
 
pivotalCategory[repD10Cat6Piv2PivotalIsomorphism] ^= repD10Cat6Piv2
 
pivotalIsomorphism[repD10Cat6Piv2PivotalIsomorphism] ^= 
   repD10Cat6Piv2PivotalIsomorphism
 
repD10Cat6Piv2PivotalIsomorphism[0] = 1
 
repD10Cat6Piv2PivotalIsomorphism[1] = -1
 
repD10Cat6Piv2PivotalIsomorphism[2] = 1
 
repD10Cat6Piv2PivotalIsomorphism[3] = -1
 
repD10Cat6Piv2PivotalIsomorphism[4] = 1
 
repD10Cat6Piv2PivotalIsomorphism[5] = 1
 
repD10Cat6Piv2PivotalIsomorphism[6] = 1
 
repD10Cat6Piv2PivotalIsomorphism[7] = 1
ring[repD10NFunction] ^= repD10
 
repD10NFunction[0, 0, 0] = 1
 
repD10NFunction[0, 0, 1] = 0
 
repD10NFunction[0, 0, 2] = 0
 
repD10NFunction[0, 0, 3] = 0
 
repD10NFunction[0, 0, 4] = 0
 
repD10NFunction[0, 0, 5] = 0
 
repD10NFunction[0, 0, 6] = 0
 
repD10NFunction[0, 0, 7] = 0
 
repD10NFunction[0, 1, 0] = 0
 
repD10NFunction[0, 1, 1] = 1
 
repD10NFunction[0, 1, 2] = 0
 
repD10NFunction[0, 1, 3] = 0
 
repD10NFunction[0, 1, 4] = 0
 
repD10NFunction[0, 1, 5] = 0
 
repD10NFunction[0, 1, 6] = 0
 
repD10NFunction[0, 1, 7] = 0
 
repD10NFunction[0, 2, 0] = 0
 
repD10NFunction[0, 2, 1] = 0
 
repD10NFunction[0, 2, 2] = 1
 
repD10NFunction[0, 2, 3] = 0
 
repD10NFunction[0, 2, 4] = 0
 
repD10NFunction[0, 2, 5] = 0
 
repD10NFunction[0, 2, 6] = 0
 
repD10NFunction[0, 2, 7] = 0
 
repD10NFunction[0, 3, 0] = 0
 
repD10NFunction[0, 3, 1] = 0
 
repD10NFunction[0, 3, 2] = 0
 
repD10NFunction[0, 3, 3] = 1
 
repD10NFunction[0, 3, 4] = 0
 
repD10NFunction[0, 3, 5] = 0
 
repD10NFunction[0, 3, 6] = 0
 
repD10NFunction[0, 3, 7] = 0
 
repD10NFunction[0, 4, 0] = 0
 
repD10NFunction[0, 4, 1] = 0
 
repD10NFunction[0, 4, 2] = 0
 
repD10NFunction[0, 4, 3] = 0
 
repD10NFunction[0, 4, 4] = 1
 
repD10NFunction[0, 4, 5] = 0
 
repD10NFunction[0, 4, 6] = 0
 
repD10NFunction[0, 4, 7] = 0
 
repD10NFunction[0, 5, 0] = 0
 
repD10NFunction[0, 5, 1] = 0
 
repD10NFunction[0, 5, 2] = 0
 
repD10NFunction[0, 5, 3] = 0
 
repD10NFunction[0, 5, 4] = 0
 
repD10NFunction[0, 5, 5] = 1
 
repD10NFunction[0, 5, 6] = 0
 
repD10NFunction[0, 5, 7] = 0
 
repD10NFunction[0, 6, 0] = 0
 
repD10NFunction[0, 6, 1] = 0
 
repD10NFunction[0, 6, 2] = 0
 
repD10NFunction[0, 6, 3] = 0
 
repD10NFunction[0, 6, 4] = 0
 
repD10NFunction[0, 6, 5] = 0
 
repD10NFunction[0, 6, 6] = 1
 
repD10NFunction[0, 6, 7] = 0
 
repD10NFunction[0, 7, 0] = 0
 
repD10NFunction[0, 7, 1] = 0
 
repD10NFunction[0, 7, 2] = 0
 
repD10NFunction[0, 7, 3] = 0
 
repD10NFunction[0, 7, 4] = 0
 
repD10NFunction[0, 7, 5] = 0
 
repD10NFunction[0, 7, 6] = 0
 
repD10NFunction[0, 7, 7] = 1
 
repD10NFunction[1, 0, 0] = 0
 
repD10NFunction[1, 0, 1] = 1
 
repD10NFunction[1, 0, 2] = 0
 
repD10NFunction[1, 0, 3] = 0
 
repD10NFunction[1, 0, 4] = 0
 
repD10NFunction[1, 0, 5] = 0
 
repD10NFunction[1, 0, 6] = 0
 
repD10NFunction[1, 0, 7] = 0
 
repD10NFunction[1, 1, 0] = 0
 
repD10NFunction[1, 1, 1] = 0
 
repD10NFunction[1, 1, 2] = 1
 
repD10NFunction[1, 1, 3] = 0
 
repD10NFunction[1, 1, 4] = 0
 
repD10NFunction[1, 1, 5] = 0
 
repD10NFunction[1, 1, 6] = 0
 
repD10NFunction[1, 1, 7] = 0
 
repD10NFunction[1, 2, 0] = 0
 
repD10NFunction[1, 2, 1] = 0
 
repD10NFunction[1, 2, 2] = 0
 
repD10NFunction[1, 2, 3] = 1
 
repD10NFunction[1, 2, 4] = 0
 
repD10NFunction[1, 2, 5] = 0
 
repD10NFunction[1, 2, 6] = 0
 
repD10NFunction[1, 2, 7] = 0
 
repD10NFunction[1, 3, 0] = 1
 
repD10NFunction[1, 3, 1] = 0
 
repD10NFunction[1, 3, 2] = 0
 
repD10NFunction[1, 3, 3] = 0
 
repD10NFunction[1, 3, 4] = 0
 
repD10NFunction[1, 3, 5] = 0
 
repD10NFunction[1, 3, 6] = 0
 
repD10NFunction[1, 3, 7] = 0
 
repD10NFunction[1, 4, 0] = 0
 
repD10NFunction[1, 4, 1] = 0
 
repD10NFunction[1, 4, 2] = 0
 
repD10NFunction[1, 4, 3] = 0
 
repD10NFunction[1, 4, 4] = 0
 
repD10NFunction[1, 4, 5] = 1
 
repD10NFunction[1, 4, 6] = 0
 
repD10NFunction[1, 4, 7] = 0
 
repD10NFunction[1, 5, 0] = 0
 
repD10NFunction[1, 5, 1] = 0
 
repD10NFunction[1, 5, 2] = 0
 
repD10NFunction[1, 5, 3] = 0
 
repD10NFunction[1, 5, 4] = 1
 
repD10NFunction[1, 5, 5] = 0
 
repD10NFunction[1, 5, 6] = 0
 
repD10NFunction[1, 5, 7] = 0
 
repD10NFunction[1, 6, 0] = 0
 
repD10NFunction[1, 6, 1] = 0
 
repD10NFunction[1, 6, 2] = 0
 
repD10NFunction[1, 6, 3] = 0
 
repD10NFunction[1, 6, 4] = 0
 
repD10NFunction[1, 6, 5] = 0
 
repD10NFunction[1, 6, 6] = 0
 
repD10NFunction[1, 6, 7] = 1
 
repD10NFunction[1, 7, 0] = 0
 
repD10NFunction[1, 7, 1] = 0
 
repD10NFunction[1, 7, 2] = 0
 
repD10NFunction[1, 7, 3] = 0
 
repD10NFunction[1, 7, 4] = 0
 
repD10NFunction[1, 7, 5] = 0
 
repD10NFunction[1, 7, 6] = 1
 
repD10NFunction[1, 7, 7] = 0
 
repD10NFunction[2, 0, 0] = 0
 
repD10NFunction[2, 0, 1] = 0
 
repD10NFunction[2, 0, 2] = 1
 
repD10NFunction[2, 0, 3] = 0
 
repD10NFunction[2, 0, 4] = 0
 
repD10NFunction[2, 0, 5] = 0
 
repD10NFunction[2, 0, 6] = 0
 
repD10NFunction[2, 0, 7] = 0
 
repD10NFunction[2, 1, 0] = 0
 
repD10NFunction[2, 1, 1] = 0
 
repD10NFunction[2, 1, 2] = 0
 
repD10NFunction[2, 1, 3] = 1
 
repD10NFunction[2, 1, 4] = 0
 
repD10NFunction[2, 1, 5] = 0
 
repD10NFunction[2, 1, 6] = 0
 
repD10NFunction[2, 1, 7] = 0
 
repD10NFunction[2, 2, 0] = 1
 
repD10NFunction[2, 2, 1] = 0
 
repD10NFunction[2, 2, 2] = 0
 
repD10NFunction[2, 2, 3] = 0
 
repD10NFunction[2, 2, 4] = 0
 
repD10NFunction[2, 2, 5] = 0
 
repD10NFunction[2, 2, 6] = 0
 
repD10NFunction[2, 2, 7] = 0
 
repD10NFunction[2, 3, 0] = 0
 
repD10NFunction[2, 3, 1] = 1
 
repD10NFunction[2, 3, 2] = 0
 
repD10NFunction[2, 3, 3] = 0
 
repD10NFunction[2, 3, 4] = 0
 
repD10NFunction[2, 3, 5] = 0
 
repD10NFunction[2, 3, 6] = 0
 
repD10NFunction[2, 3, 7] = 0
 
repD10NFunction[2, 4, 0] = 0
 
repD10NFunction[2, 4, 1] = 0
 
repD10NFunction[2, 4, 2] = 0
 
repD10NFunction[2, 4, 3] = 0
 
repD10NFunction[2, 4, 4] = 1
 
repD10NFunction[2, 4, 5] = 0
 
repD10NFunction[2, 4, 6] = 0
 
repD10NFunction[2, 4, 7] = 0
 
repD10NFunction[2, 5, 0] = 0
 
repD10NFunction[2, 5, 1] = 0
 
repD10NFunction[2, 5, 2] = 0
 
repD10NFunction[2, 5, 3] = 0
 
repD10NFunction[2, 5, 4] = 0
 
repD10NFunction[2, 5, 5] = 1
 
repD10NFunction[2, 5, 6] = 0
 
repD10NFunction[2, 5, 7] = 0
 
repD10NFunction[2, 6, 0] = 0
 
repD10NFunction[2, 6, 1] = 0
 
repD10NFunction[2, 6, 2] = 0
 
repD10NFunction[2, 6, 3] = 0
 
repD10NFunction[2, 6, 4] = 0
 
repD10NFunction[2, 6, 5] = 0
 
repD10NFunction[2, 6, 6] = 1
 
repD10NFunction[2, 6, 7] = 0
 
repD10NFunction[2, 7, 0] = 0
 
repD10NFunction[2, 7, 1] = 0
 
repD10NFunction[2, 7, 2] = 0
 
repD10NFunction[2, 7, 3] = 0
 
repD10NFunction[2, 7, 4] = 0
 
repD10NFunction[2, 7, 5] = 0
 
repD10NFunction[2, 7, 6] = 0
 
repD10NFunction[2, 7, 7] = 1
 
repD10NFunction[3, 0, 0] = 0
 
repD10NFunction[3, 0, 1] = 0
 
repD10NFunction[3, 0, 2] = 0
 
repD10NFunction[3, 0, 3] = 1
 
repD10NFunction[3, 0, 4] = 0
 
repD10NFunction[3, 0, 5] = 0
 
repD10NFunction[3, 0, 6] = 0
 
repD10NFunction[3, 0, 7] = 0
 
repD10NFunction[3, 1, 0] = 1
 
repD10NFunction[3, 1, 1] = 0
 
repD10NFunction[3, 1, 2] = 0
 
repD10NFunction[3, 1, 3] = 0
 
repD10NFunction[3, 1, 4] = 0
 
repD10NFunction[3, 1, 5] = 0
 
repD10NFunction[3, 1, 6] = 0
 
repD10NFunction[3, 1, 7] = 0
 
repD10NFunction[3, 2, 0] = 0
 
repD10NFunction[3, 2, 1] = 1
 
repD10NFunction[3, 2, 2] = 0
 
repD10NFunction[3, 2, 3] = 0
 
repD10NFunction[3, 2, 4] = 0
 
repD10NFunction[3, 2, 5] = 0
 
repD10NFunction[3, 2, 6] = 0
 
repD10NFunction[3, 2, 7] = 0
 
repD10NFunction[3, 3, 0] = 0
 
repD10NFunction[3, 3, 1] = 0
 
repD10NFunction[3, 3, 2] = 1
 
repD10NFunction[3, 3, 3] = 0
 
repD10NFunction[3, 3, 4] = 0
 
repD10NFunction[3, 3, 5] = 0
 
repD10NFunction[3, 3, 6] = 0
 
repD10NFunction[3, 3, 7] = 0
 
repD10NFunction[3, 4, 0] = 0
 
repD10NFunction[3, 4, 1] = 0
 
repD10NFunction[3, 4, 2] = 0
 
repD10NFunction[3, 4, 3] = 0
 
repD10NFunction[3, 4, 4] = 0
 
repD10NFunction[3, 4, 5] = 1
 
repD10NFunction[3, 4, 6] = 0
 
repD10NFunction[3, 4, 7] = 0
 
repD10NFunction[3, 5, 0] = 0
 
repD10NFunction[3, 5, 1] = 0
 
repD10NFunction[3, 5, 2] = 0
 
repD10NFunction[3, 5, 3] = 0
 
repD10NFunction[3, 5, 4] = 1
 
repD10NFunction[3, 5, 5] = 0
 
repD10NFunction[3, 5, 6] = 0
 
repD10NFunction[3, 5, 7] = 0
 
repD10NFunction[3, 6, 0] = 0
 
repD10NFunction[3, 6, 1] = 0
 
repD10NFunction[3, 6, 2] = 0
 
repD10NFunction[3, 6, 3] = 0
 
repD10NFunction[3, 6, 4] = 0
 
repD10NFunction[3, 6, 5] = 0
 
repD10NFunction[3, 6, 6] = 0
 
repD10NFunction[3, 6, 7] = 1
 
repD10NFunction[3, 7, 0] = 0
 
repD10NFunction[3, 7, 1] = 0
 
repD10NFunction[3, 7, 2] = 0
 
repD10NFunction[3, 7, 3] = 0
 
repD10NFunction[3, 7, 4] = 0
 
repD10NFunction[3, 7, 5] = 0
 
repD10NFunction[3, 7, 6] = 1
 
repD10NFunction[3, 7, 7] = 0
 
repD10NFunction[4, 0, 0] = 0
 
repD10NFunction[4, 0, 1] = 0
 
repD10NFunction[4, 0, 2] = 0
 
repD10NFunction[4, 0, 3] = 0
 
repD10NFunction[4, 0, 4] = 1
 
repD10NFunction[4, 0, 5] = 0
 
repD10NFunction[4, 0, 6] = 0
 
repD10NFunction[4, 0, 7] = 0
 
repD10NFunction[4, 1, 0] = 0
 
repD10NFunction[4, 1, 1] = 0
 
repD10NFunction[4, 1, 2] = 0
 
repD10NFunction[4, 1, 3] = 0
 
repD10NFunction[4, 1, 4] = 0
 
repD10NFunction[4, 1, 5] = 1
 
repD10NFunction[4, 1, 6] = 0
 
repD10NFunction[4, 1, 7] = 0
 
repD10NFunction[4, 2, 0] = 0
 
repD10NFunction[4, 2, 1] = 0
 
repD10NFunction[4, 2, 2] = 0
 
repD10NFunction[4, 2, 3] = 0
 
repD10NFunction[4, 2, 4] = 1
 
repD10NFunction[4, 2, 5] = 0
 
repD10NFunction[4, 2, 6] = 0
 
repD10NFunction[4, 2, 7] = 0
 
repD10NFunction[4, 3, 0] = 0
 
repD10NFunction[4, 3, 1] = 0
 
repD10NFunction[4, 3, 2] = 0
 
repD10NFunction[4, 3, 3] = 0
 
repD10NFunction[4, 3, 4] = 0
 
repD10NFunction[4, 3, 5] = 1
 
repD10NFunction[4, 3, 6] = 0
 
repD10NFunction[4, 3, 7] = 0
 
repD10NFunction[4, 4, 0] = 1
 
repD10NFunction[4, 4, 1] = 0
 
repD10NFunction[4, 4, 2] = 1
 
repD10NFunction[4, 4, 3] = 0
 
repD10NFunction[4, 4, 4] = 0
 
repD10NFunction[4, 4, 5] = 0
 
repD10NFunction[4, 4, 6] = 1
 
repD10NFunction[4, 4, 7] = 0
 
repD10NFunction[4, 5, 0] = 0
 
repD10NFunction[4, 5, 1] = 1
 
repD10NFunction[4, 5, 2] = 0
 
repD10NFunction[4, 5, 3] = 1
 
repD10NFunction[4, 5, 4] = 0
 
repD10NFunction[4, 5, 5] = 0
 
repD10NFunction[4, 5, 6] = 0
 
repD10NFunction[4, 5, 7] = 1
 
repD10NFunction[4, 6, 0] = 0
 
repD10NFunction[4, 6, 1] = 0
 
repD10NFunction[4, 6, 2] = 0
 
repD10NFunction[4, 6, 3] = 0
 
repD10NFunction[4, 6, 4] = 1
 
repD10NFunction[4, 6, 5] = 0
 
repD10NFunction[4, 6, 6] = 1
 
repD10NFunction[4, 6, 7] = 0
 
repD10NFunction[4, 7, 0] = 0
 
repD10NFunction[4, 7, 1] = 0
 
repD10NFunction[4, 7, 2] = 0
 
repD10NFunction[4, 7, 3] = 0
 
repD10NFunction[4, 7, 4] = 0
 
repD10NFunction[4, 7, 5] = 1
 
repD10NFunction[4, 7, 6] = 0
 
repD10NFunction[4, 7, 7] = 1
 
repD10NFunction[5, 0, 0] = 0
 
repD10NFunction[5, 0, 1] = 0
 
repD10NFunction[5, 0, 2] = 0
 
repD10NFunction[5, 0, 3] = 0
 
repD10NFunction[5, 0, 4] = 0
 
repD10NFunction[5, 0, 5] = 1
 
repD10NFunction[5, 0, 6] = 0
 
repD10NFunction[5, 0, 7] = 0
 
repD10NFunction[5, 1, 0] = 0
 
repD10NFunction[5, 1, 1] = 0
 
repD10NFunction[5, 1, 2] = 0
 
repD10NFunction[5, 1, 3] = 0
 
repD10NFunction[5, 1, 4] = 1
 
repD10NFunction[5, 1, 5] = 0
 
repD10NFunction[5, 1, 6] = 0
 
repD10NFunction[5, 1, 7] = 0
 
repD10NFunction[5, 2, 0] = 0
 
repD10NFunction[5, 2, 1] = 0
 
repD10NFunction[5, 2, 2] = 0
 
repD10NFunction[5, 2, 3] = 0
 
repD10NFunction[5, 2, 4] = 0
 
repD10NFunction[5, 2, 5] = 1
 
repD10NFunction[5, 2, 6] = 0
 
repD10NFunction[5, 2, 7] = 0
 
repD10NFunction[5, 3, 0] = 0
 
repD10NFunction[5, 3, 1] = 0
 
repD10NFunction[5, 3, 2] = 0
 
repD10NFunction[5, 3, 3] = 0
 
repD10NFunction[5, 3, 4] = 1
 
repD10NFunction[5, 3, 5] = 0
 
repD10NFunction[5, 3, 6] = 0
 
repD10NFunction[5, 3, 7] = 0
 
repD10NFunction[5, 4, 0] = 0
 
repD10NFunction[5, 4, 1] = 1
 
repD10NFunction[5, 4, 2] = 0
 
repD10NFunction[5, 4, 3] = 1
 
repD10NFunction[5, 4, 4] = 0
 
repD10NFunction[5, 4, 5] = 0
 
repD10NFunction[5, 4, 6] = 0
 
repD10NFunction[5, 4, 7] = 1
 
repD10NFunction[5, 5, 0] = 1
 
repD10NFunction[5, 5, 1] = 0
 
repD10NFunction[5, 5, 2] = 1
 
repD10NFunction[5, 5, 3] = 0
 
repD10NFunction[5, 5, 4] = 0
 
repD10NFunction[5, 5, 5] = 0
 
repD10NFunction[5, 5, 6] = 1
 
repD10NFunction[5, 5, 7] = 0
 
repD10NFunction[5, 6, 0] = 0
 
repD10NFunction[5, 6, 1] = 0
 
repD10NFunction[5, 6, 2] = 0
 
repD10NFunction[5, 6, 3] = 0
 
repD10NFunction[5, 6, 4] = 0
 
repD10NFunction[5, 6, 5] = 1
 
repD10NFunction[5, 6, 6] = 0
 
repD10NFunction[5, 6, 7] = 1
 
repD10NFunction[5, 7, 0] = 0
 
repD10NFunction[5, 7, 1] = 0
 
repD10NFunction[5, 7, 2] = 0
 
repD10NFunction[5, 7, 3] = 0
 
repD10NFunction[5, 7, 4] = 1
 
repD10NFunction[5, 7, 5] = 0
 
repD10NFunction[5, 7, 6] = 1
 
repD10NFunction[5, 7, 7] = 0
 
repD10NFunction[6, 0, 0] = 0
 
repD10NFunction[6, 0, 1] = 0
 
repD10NFunction[6, 0, 2] = 0
 
repD10NFunction[6, 0, 3] = 0
 
repD10NFunction[6, 0, 4] = 0
 
repD10NFunction[6, 0, 5] = 0
 
repD10NFunction[6, 0, 6] = 1
 
repD10NFunction[6, 0, 7] = 0
 
repD10NFunction[6, 1, 0] = 0
 
repD10NFunction[6, 1, 1] = 0
 
repD10NFunction[6, 1, 2] = 0
 
repD10NFunction[6, 1, 3] = 0
 
repD10NFunction[6, 1, 4] = 0
 
repD10NFunction[6, 1, 5] = 0
 
repD10NFunction[6, 1, 6] = 0
 
repD10NFunction[6, 1, 7] = 1
 
repD10NFunction[6, 2, 0] = 0
 
repD10NFunction[6, 2, 1] = 0
 
repD10NFunction[6, 2, 2] = 0
 
repD10NFunction[6, 2, 3] = 0
 
repD10NFunction[6, 2, 4] = 0
 
repD10NFunction[6, 2, 5] = 0
 
repD10NFunction[6, 2, 6] = 1
 
repD10NFunction[6, 2, 7] = 0
 
repD10NFunction[6, 3, 0] = 0
 
repD10NFunction[6, 3, 1] = 0
 
repD10NFunction[6, 3, 2] = 0
 
repD10NFunction[6, 3, 3] = 0
 
repD10NFunction[6, 3, 4] = 0
 
repD10NFunction[6, 3, 5] = 0
 
repD10NFunction[6, 3, 6] = 0
 
repD10NFunction[6, 3, 7] = 1
 
repD10NFunction[6, 4, 0] = 0
 
repD10NFunction[6, 4, 1] = 0
 
repD10NFunction[6, 4, 2] = 0
 
repD10NFunction[6, 4, 3] = 0
 
repD10NFunction[6, 4, 4] = 1
 
repD10NFunction[6, 4, 5] = 0
 
repD10NFunction[6, 4, 6] = 1
 
repD10NFunction[6, 4, 7] = 0
 
repD10NFunction[6, 5, 0] = 0
 
repD10NFunction[6, 5, 1] = 0
 
repD10NFunction[6, 5, 2] = 0
 
repD10NFunction[6, 5, 3] = 0
 
repD10NFunction[6, 5, 4] = 0
 
repD10NFunction[6, 5, 5] = 1
 
repD10NFunction[6, 5, 6] = 0
 
repD10NFunction[6, 5, 7] = 1
 
repD10NFunction[6, 6, 0] = 1
 
repD10NFunction[6, 6, 1] = 0
 
repD10NFunction[6, 6, 2] = 1
 
repD10NFunction[6, 6, 3] = 0
 
repD10NFunction[6, 6, 4] = 1
 
repD10NFunction[6, 6, 5] = 0
 
repD10NFunction[6, 6, 6] = 0
 
repD10NFunction[6, 6, 7] = 0
 
repD10NFunction[6, 7, 0] = 0
 
repD10NFunction[6, 7, 1] = 1
 
repD10NFunction[6, 7, 2] = 0
 
repD10NFunction[6, 7, 3] = 1
 
repD10NFunction[6, 7, 4] = 0
 
repD10NFunction[6, 7, 5] = 1
 
repD10NFunction[6, 7, 6] = 0
 
repD10NFunction[6, 7, 7] = 0
 
repD10NFunction[7, 0, 0] = 0
 
repD10NFunction[7, 0, 1] = 0
 
repD10NFunction[7, 0, 2] = 0
 
repD10NFunction[7, 0, 3] = 0
 
repD10NFunction[7, 0, 4] = 0
 
repD10NFunction[7, 0, 5] = 0
 
repD10NFunction[7, 0, 6] = 0
 
repD10NFunction[7, 0, 7] = 1
 
repD10NFunction[7, 1, 0] = 0
 
repD10NFunction[7, 1, 1] = 0
 
repD10NFunction[7, 1, 2] = 0
 
repD10NFunction[7, 1, 3] = 0
 
repD10NFunction[7, 1, 4] = 0
 
repD10NFunction[7, 1, 5] = 0
 
repD10NFunction[7, 1, 6] = 1
 
repD10NFunction[7, 1, 7] = 0
 
repD10NFunction[7, 2, 0] = 0
 
repD10NFunction[7, 2, 1] = 0
 
repD10NFunction[7, 2, 2] = 0
 
repD10NFunction[7, 2, 3] = 0
 
repD10NFunction[7, 2, 4] = 0
 
repD10NFunction[7, 2, 5] = 0
 
repD10NFunction[7, 2, 6] = 0
 
repD10NFunction[7, 2, 7] = 1
 
repD10NFunction[7, 3, 0] = 0
 
repD10NFunction[7, 3, 1] = 0
 
repD10NFunction[7, 3, 2] = 0
 
repD10NFunction[7, 3, 3] = 0
 
repD10NFunction[7, 3, 4] = 0
 
repD10NFunction[7, 3, 5] = 0
 
repD10NFunction[7, 3, 6] = 1
 
repD10NFunction[7, 3, 7] = 0
 
repD10NFunction[7, 4, 0] = 0
 
repD10NFunction[7, 4, 1] = 0
 
repD10NFunction[7, 4, 2] = 0
 
repD10NFunction[7, 4, 3] = 0
 
repD10NFunction[7, 4, 4] = 0
 
repD10NFunction[7, 4, 5] = 1
 
repD10NFunction[7, 4, 6] = 0
 
repD10NFunction[7, 4, 7] = 1
 
repD10NFunction[7, 5, 0] = 0
 
repD10NFunction[7, 5, 1] = 0
 
repD10NFunction[7, 5, 2] = 0
 
repD10NFunction[7, 5, 3] = 0
 
repD10NFunction[7, 5, 4] = 1
 
repD10NFunction[7, 5, 5] = 0
 
repD10NFunction[7, 5, 6] = 1
 
repD10NFunction[7, 5, 7] = 0
 
repD10NFunction[7, 6, 0] = 0
 
repD10NFunction[7, 6, 1] = 1
 
repD10NFunction[7, 6, 2] = 0
 
repD10NFunction[7, 6, 3] = 1
 
repD10NFunction[7, 6, 4] = 0
 
repD10NFunction[7, 6, 5] = 1
 
repD10NFunction[7, 6, 6] = 0
 
repD10NFunction[7, 6, 7] = 0
 
repD10NFunction[7, 7, 0] = 1
 
repD10NFunction[7, 7, 1] = 0
 
repD10NFunction[7, 7, 2] = 1
 
repD10NFunction[7, 7, 3] = 0
 
repD10NFunction[7, 7, 4] = 1
 
repD10NFunction[7, 7, 5] = 0
 
repD10NFunction[7, 7, 6] = 0
 
repD10NFunction[7, 7, 7] = 0
 
repD10NFunction[a_, b_, c_] := 0


 EndPackage[]