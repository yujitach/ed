BeginPackage["FusionCategories`Data`haagerup6`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[haagerup6] ^= {haagerup6Cat1, haagerup6Cat2, haagerup6Cat3, 
    haagerup6Cat4, haagerup6Cat5, haagerup6Cat6, haagerup6Cat7, 
    haagerup6Cat8, haagerup6Cat1Unitary, haagerup6Cat3Unitary, 
    haagerup6Cat5Unitary, haagerup6Cat7Unitary}
 
haagerup6 /: fusionCategory[haagerup6, 1] = haagerup6Cat1
 
haagerup6 /: fusionCategory[haagerup6, 2] = haagerup6Cat2
 
haagerup6 /: fusionCategory[haagerup6, 3] = haagerup6Cat3
 
haagerup6 /: fusionCategory[haagerup6, 4] = haagerup6Cat4
 
haagerup6 /: fusionCategory[haagerup6, 5] = haagerup6Cat5
 
haagerup6 /: fusionCategory[haagerup6, 6] = haagerup6Cat6
 
haagerup6 /: fusionCategory[haagerup6, 7] = haagerup6Cat7
 
haagerup6 /: fusionCategory[haagerup6, 8] = haagerup6Cat8
 
haagerup6 /: fusionCategory[haagerup6, 9] = haagerup6Cat1Unitary
 
haagerup6 /: fusionCategory[haagerup6, 10] = haagerup6Cat3Unitary
 
haagerup6 /: fusionCategory[haagerup6, 11] = haagerup6Cat5Unitary
 
haagerup6 /: fusionCategory[haagerup6, 12] = haagerup6Cat7Unitary
 
nFunction[haagerup6] ^= haagerup6NFunction
 
noMultiplicities[haagerup6] ^= True
 
rank[haagerup6] ^= 6
 
ring[haagerup6] ^= haagerup6
balancedCategories[haagerup6Cat1] ^= {}
 
braidedCategories[haagerup6Cat1] ^= {}
 
coeval[haagerup6Cat1] ^= 1/sixJFunction[haagerup6Cat1][#1, 
      dual[ring[haagerup6Cat1]][#1], #1, #1, 0, 0] & 
 
eval[haagerup6Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haagerup6Cat1] ^= haagerup6Cat1FMatrixFunction
 
fusionCategory[haagerup6Cat1] ^= haagerup6Cat1
 
haagerup6Cat1 /: modularCategory[haagerup6Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[haagerup6Cat1] ^= {haagerup6Cat1Piv1}
 
haagerup6Cat1 /: pivotalCategory[haagerup6Cat1, 1] = haagerup6Cat1Piv1
 
haagerup6Cat1 /: pivotalCategory[haagerup6Cat1, {1, 1, 1, 1, 1, 1}] = 
    haagerup6Cat1Piv1
 
ring[haagerup6Cat1] ^= haagerup6
 
haagerup6Cat1 /: sphericalCategory[haagerup6Cat1, 1] = haagerup6Cat1Piv1
 
fusionCategoryIndex[haagerup6][haagerup6Cat1] ^= 1
fMatrixFunction[haagerup6Cat1FMatrixFunction] ^= haagerup6Cat1FMatrixFunction
 
fusionCategory[haagerup6Cat1FMatrixFunction] ^= haagerup6Cat1
 
ring[haagerup6Cat1FMatrixFunction] ^= haagerup6
 
haagerup6Cat1FMatrixFunction[1, 3, 2, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[1, 3, 4, 3] = {{-1}}
 
haagerup6Cat1FMatrixFunction[1, 3, 5, 3] = {{-1}}
 
haagerup6Cat1FMatrixFunction[1, 3, 5, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[1, 3, 5, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[1, 4, 1, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[1, 4, 2, 3] = {{-1}}
 
haagerup6Cat1FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[1, 4, 5, 3] = {{-1}}
 
haagerup6Cat1FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[1, 4, 5, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[1, 5, 1, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[2, 3, 1, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[2, 4, 2, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[2, 4, 4, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[2, 4, 5, 3] = {{-1}}
 
haagerup6Cat1FMatrixFunction[2, 4, 5, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[2, 4, 5, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[2, 5, 1, 3] = {{-1}}
 
haagerup6Cat1FMatrixFunction[2, 5, 2, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haagerup6Cat1FMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haagerup6Cat1FMatrixFunction[2, 5, 5, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[2, 5, 5, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[3, 1, 3, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[3, 1, 3, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[3, 1, 4, 1] = {{-1}}
 
haagerup6Cat1FMatrixFunction[3, 1, 4, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[3, 2, 4, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[3, 2, 5, 2] = {{-1}}
 
haagerup6Cat1FMatrixFunction[3, 2, 5, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[3, 2, 5, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[3, 3, 3, 3] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(3 - Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[3, 3, 3, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[3, 3, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1FMatrixFunction[3, 3, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[3, 3, 4, 4] = {{(-3 + Sqrt[13])/2, -1, 1, -1}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(3 - Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3}}
 
haagerup6Cat1FMatrixFunction[3, 3, 4, 5] = 
   {{(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[3, 3, 5, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1FMatrixFunction[3, 3, 5, 4] = 
   {{(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1FMatrixFunction[3, 3, 5, 5] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(3 - Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[3, 4, 3, 2] = {{-1}}
 
haagerup6Cat1FMatrixFunction[3, 4, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[3, 4, 3, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1FMatrixFunction[3, 4, 3, 5] = {{(-3 + Sqrt[13])/2, 1, -1, 1}, 
    {(-3 + Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}, 
    {(3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1FMatrixFunction[3, 4, 4, 3] = {{(-3 + Sqrt[13])/2, 1, -1, 1}, 
    {(3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-3 + Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(3 - Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3}}
 
haagerup6Cat1FMatrixFunction[3, 4, 4, 4] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1FMatrixFunction[3, 4, 4, 5] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1FMatrixFunction[3, 4, 5, 3] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[3, 4, 5, 4] = {{(3 - Sqrt[13])/2, 1, -1, -1}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(3 - Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[3, 4, 5, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}}
 
haagerup6Cat1FMatrixFunction[3, 5, 3, 2] = {{-1}}
 
haagerup6Cat1FMatrixFunction[3, 5, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1FMatrixFunction[3, 5, 3, 4] = {{(-3 + Sqrt[13])/2, 1, -1, 1}, 
    {(-3 + Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}, 
    {(3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1FMatrixFunction[3, 5, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
haagerup6Cat1FMatrixFunction[3, 5, 4, 3] = 
   {{(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1FMatrixFunction[3, 5, 4, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[3, 5, 4, 5] = {{(3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-2 + Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}}
 
haagerup6Cat1FMatrixFunction[3, 5, 5, 2] = {{-1}}
 
haagerup6Cat1FMatrixFunction[3, 5, 5, 3] = {{(-3 + Sqrt[13])/2, 1, 1, -1}, 
    {(3 - Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-3 + Sqrt[13])/2, (2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[3, 5, 5, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1FMatrixFunction[3, 5, 5, 5] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[4, 1, 3, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 1, 4, 2] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 1, 4, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 1, 4, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 2, 3, 2] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 2, 4, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 2, 5, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 3, 1, 3] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 3, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[4, 3, 3, 4] = {{(-3 + Sqrt[13])/2, 1, -1, 1}, 
    {(3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-3 + Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(3 - Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3}}
 
haagerup6Cat1FMatrixFunction[4, 3, 3, 5] = 
   {{(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1FMatrixFunction[4, 3, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1FMatrixFunction[4, 3, 4, 4] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1FMatrixFunction[4, 3, 4, 5] = {{(3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}, 
    {(3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(3 - Sqrt[13])/2, (2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[4, 3, 5, 3] = {{(-3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(3 - Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1FMatrixFunction[4, 3, 5, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[4, 3, 5, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1FMatrixFunction[4, 4, 1, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 4, 3, 3] = {{(-3 + Sqrt[13])/2, -1, 1, -1}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(3 - Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3}}
 
haagerup6Cat1FMatrixFunction[4, 4, 3, 4] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1FMatrixFunction[4, 4, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 4, 4, 3] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1FMatrixFunction[4, 4, 4, 4] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-2 + Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1FMatrixFunction[4, 4, 4, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1FMatrixFunction[4, 4, 5, 1] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 4, 5, 3] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1FMatrixFunction[4, 4, 5, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1FMatrixFunction[4, 4, 5, 5] = {{(-3 + Sqrt[13])/2, -1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1FMatrixFunction[4, 5, 2, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 5, 3, 1] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 5, 3, 2] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 5, 3, 3] = 
   {{(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[4, 5, 3, 4] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1FMatrixFunction[4, 5, 3, 5] = {{(3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-2 + Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}}
 
haagerup6Cat1FMatrixFunction[4, 5, 4, 1] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 5, 4, 3] = {{(3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}, 
    {(3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(3 - Sqrt[13])/2, (2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[4, 5, 4, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1FMatrixFunction[4, 5, 4, 5] = 
   {{(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[4, 5, 5, 1] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 5, 5, 2] = {{-1}}
 
haagerup6Cat1FMatrixFunction[4, 5, 5, 3] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}}
 
haagerup6Cat1FMatrixFunction[4, 5, 5, 4] = {{(-3 + Sqrt[13])/2, 1, 1, 1}, 
    {(3 - Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {(3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-2 + Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1FMatrixFunction[4, 5, 5, 5] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1FMatrixFunction[5, 1, 3, 1] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 1, 3, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 1, 5, 2] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 2, 5, 1] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 3, 1, 3] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 3, 1, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 3, 2, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 3, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1FMatrixFunction[5, 3, 3, 4] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[5, 3, 3, 5] = {{(-3 + Sqrt[13])/2, 1, 1, -1}, 
    {(3 - Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-3 + Sqrt[13])/2, (2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[5, 3, 4, 3] = {{(-3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(3 - Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1FMatrixFunction[5, 3, 4, 4] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1FMatrixFunction[5, 3, 4, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}}
 
haagerup6Cat1FMatrixFunction[5, 3, 5, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1FMatrixFunction[5, 3, 5, 4] = {{(3 - Sqrt[13])/2, 1, 1, 1}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-2 + Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-3 + Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}}
 
haagerup6Cat1FMatrixFunction[5, 3, 5, 5] = 
   {{(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[5, 4, 1, 3] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 4, 1, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 4, 2, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 4, 2, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 4, 3, 3] = 
   {{(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1FMatrixFunction[5, 4, 3, 4] = {{(3 - Sqrt[13])/2, 1, -1, -1}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(3 - Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[5, 4, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1FMatrixFunction[5, 4, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[5, 4, 4, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1FMatrixFunction[5, 4, 4, 5] = {{(-3 + Sqrt[13])/2, 1, 1, 1}, 
    {(3 - Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {(3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-2 + Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1FMatrixFunction[5, 4, 5, 3] = {{(3 - Sqrt[13])/2, 1, 1, 1}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-2 + Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-3 + Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}}
 
haagerup6Cat1FMatrixFunction[5, 4, 5, 4] = 
   {{(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[5, 4, 5, 5] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 5, 1, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 5, 2, 4] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 5, 2, 5] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 5, 3, 3] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(3 - Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[5, 5, 3, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}}
 
haagerup6Cat1FMatrixFunction[5, 5, 3, 5] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[5, 5, 4, 1] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 5, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1FMatrixFunction[5, 5, 4, 4] = {{(-3 + Sqrt[13])/2, -1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1FMatrixFunction[5, 5, 4, 5] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1FMatrixFunction[5, 5, 5, 1] = {{-1}}
 
haagerup6Cat1FMatrixFunction[5, 5, 5, 3] = 
   {{(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1FMatrixFunction[5, 5, 5, 4] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1FMatrixFunction[5, 5, 5, 5] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], 
     (-2 + Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-3 + Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}}
 
haagerup6Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haagerup6Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[haagerup6Cat1Piv1] ^= {}
 
fusionCategory[haagerup6Cat1Piv1] ^= haagerup6Cat1
 
haagerup6Cat1Piv1 /: modularCategory[haagerup6Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[haagerup6Cat1Piv1] ^= haagerup6Cat1Piv1
 
pivotalIsomorphism[haagerup6Cat1Piv1] ^= haagerup6Cat1Piv1PivotalIsomorphism
 
ring[haagerup6Cat1Piv1] ^= haagerup6
 
sphericalCategory[haagerup6Cat1Piv1] ^= haagerup6Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[haagerup6Cat1]][pivotalCategory[#1]] & )[
    haagerup6Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haagerup6Cat1]][
      sphericalCategory[#1]] & )[haagerup6Cat1Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haagerup6Cat1Piv1PivotalIsomorphism] ^= haagerup6Cat1
 
pivotalCategory[haagerup6Cat1Piv1PivotalIsomorphism] ^= haagerup6Cat1Piv1
 
pivotalIsomorphism[haagerup6Cat1Piv1PivotalIsomorphism] ^= 
   haagerup6Cat1Piv1PivotalIsomorphism
 
haagerup6Cat1Piv1PivotalIsomorphism[0] = 1
 
haagerup6Cat1Piv1PivotalIsomorphism[1] = 1
 
haagerup6Cat1Piv1PivotalIsomorphism[2] = 1
 
haagerup6Cat1Piv1PivotalIsomorphism[3] = 1
 
haagerup6Cat1Piv1PivotalIsomorphism[4] = 1
 
haagerup6Cat1Piv1PivotalIsomorphism[5] = 1
coeval[haagerup6Cat1Unitary] ^= 
   1/sixJFunction[haagerup6Cat1Unitary][#1, dual[ring[haagerup6Cat1Unitary]][
       #1], #1, #1, 0, 0] & 
 
eval[haagerup6Cat1Unitary] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haagerup6Cat1Unitary] ^= haagerup6Cat1UnitaryFMatrixFunction
 
fusionCategory[haagerup6Cat1Unitary] ^= haagerup6Cat1Unitary
 
pivotalCategories[haagerup6Cat1Unitary] ^= {haagerup6Cat1UnitaryPiv1}
 
haagerup6Cat1Unitary /: pivotalCategory[haagerup6Cat1Unitary, 1] = 
    haagerup6Cat1UnitaryPiv1
 
haagerup6Cat1Unitary /: pivotalCategory[haagerup6Cat1Unitary, 
     {1, 1, 1, 1, 1, 1}] = haagerup6Cat1UnitaryPiv1
 
ring[haagerup6Cat1Unitary] ^= haagerup6
 
haagerup6Cat1Unitary /: sphericalCategory[haagerup6Cat1Unitary, 1] = 
    haagerup6Cat1UnitaryPiv1
 
fusionCategoryIndex[haagerup6][haagerup6Cat1Unitary] ^= 9
fMatrixFunction[haagerup6Cat1UnitaryFMatrixFunction] ^= 
   haagerup6Cat1UnitaryFMatrixFunction
 
fusionCategory[haagerup6Cat1UnitaryFMatrixFunction] ^= haagerup6Cat1Unitary
 
ring[haagerup6Cat1UnitaryFMatrixFunction] ^= haagerup6
 
haagerup6Cat1UnitaryFMatrixFunction[1, 3, 2, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[1, 3, 4, 3] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[1, 3, 5, 3] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[1, 3, 5, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[1, 3, 5, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[1, 4, 1, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[1, 4, 2, 3] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[1, 4, 5, 3] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[1, 4, 5, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[1, 5, 1, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[2, 3, 1, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[2, 4, 2, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[2, 4, 4, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[2, 4, 5, 3] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[2, 4, 5, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[2, 4, 5, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[2, 5, 1, 3] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[2, 5, 2, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[2, 5, 5, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[2, 5, 5, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 1, 3, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 1, 3, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 1, 4, 1] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 1, 4, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 2, 4, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 2, 5, 2] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 2, 5, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 2, 5, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 3, 3, 3] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 3, 3, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 3, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 3, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 3, 4, 4] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 3, 4, 5] = 
   {{(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 3, 5, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 3, 5, 4] = 
   {{(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 3, 5, 5] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 4, 3, 2] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 4, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 4, 3, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 4, 3, 5] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 
      1, 0], Sqrt[(-3 + Sqrt[13])/2]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 
      0], (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (2 - Sqrt[13])/3}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 4, 4, 3] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 
      1, 0], Sqrt[(-3 + Sqrt[13])/2]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Sqrt[(-3 + Sqrt[13])/2], (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 4, 4, 4] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 4, 4, 5] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 4, 5, 3] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 4, 5, 4] = 
   {{(3 - Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 
      1, 0], Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 4, 5, 5] = 
   {{(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 5, 3, 2] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 5, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 5, 3, 4] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 
      1, 0], Sqrt[(-3 + Sqrt[13])/2]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 
      0], (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (2 - Sqrt[13])/3}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 5, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-1 - Sqrt[13])/6}, 
    {(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 5, 4, 2] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 5, 4, 3] = 
   {{(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 5, 4, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 5, 4, 5] = 
   {{(3 - Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (2 - Sqrt[13])/3}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 5, 5, 2] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 5, 5, 3] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (2 - Sqrt[13])/3}, 
    {Sqrt[(-3 + Sqrt[13])/2], Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 
      0], (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Sqrt[(-3 + Sqrt[13])/2], (2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 5, 5, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6}}
 
haagerup6Cat1UnitaryFMatrixFunction[3, 5, 5, 5] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 1, 3, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 1, 4, 2] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 1, 4, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 1, 4, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 2, 3, 2] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 2, 4, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 2, 5, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 3, 1, 3] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 3, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 3, 3, 4] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 
      1, 0], Sqrt[(-3 + Sqrt[13])/2]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Sqrt[(-3 + Sqrt[13])/2], (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 3, 3, 5] = 
   {{(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 3, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 3, 4, 4] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 3, 4, 5] = 
   {{(3 - Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (2 - Sqrt[13])/3}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 3, 5, 3] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (2 - Sqrt[13])/3}, 
    {Sqrt[(-3 + Sqrt[13])/2], Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 
      0], (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 3, 5, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 3, 5, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 4, 1, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 4, 3, 3] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 4, 3, 4] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 4, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 4, 4, 3] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 4, 4, 4] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-2 + Sqrt[13])/3}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 4, 4, 5] = 
   {{(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 4, 5, 1] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 4, 5, 3] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 4, 5, 4] = 
   {{(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 4, 5, 5] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 5, 2, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 5, 3, 1] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 5, 3, 2] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 5, 3, 3] = 
   {{(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 5, 3, 4] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 5, 3, 5] = 
   {{(3 - Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (2 - Sqrt[13])/3}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 5, 4, 1] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 5, 4, 3] = 
   {{(3 - Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (2 - Sqrt[13])/3}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 5, 4, 4] = 
   {{(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 5, 4, 5] = 
   {{(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 5, 5, 1] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 5, 5, 2] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 5, 5, 3] = 
   {{(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-1 - Sqrt[13])/6}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 5, 5, 4] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Sqrt[(-3 + Sqrt[13])/2]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-2 + Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Sqrt[(-3 + Sqrt[13])/2], Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 
      0], Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], 
     (2 - Sqrt[13])/3}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[4, 5, 5, 5] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 1, 3, 1] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 1, 3, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 1, 5, 2] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 2, 5, 1] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 3, 1, 3] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 3, 1, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 3, 2, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 3, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 3, 3, 4] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 3, 3, 5] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (2 - Sqrt[13])/3}, 
    {Sqrt[(-3 + Sqrt[13])/2], Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 
      0], (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Sqrt[(-3 + Sqrt[13])/2], (2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 3, 4, 3] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (2 - Sqrt[13])/3}, 
    {Sqrt[(-3 + Sqrt[13])/2], Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 
      0], (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 3, 4, 4] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 3, 4, 5] = 
   {{(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-1 - Sqrt[13])/6}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 3, 5, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-1 - Sqrt[13])/6}, 
    {(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 3, 5, 4] = 
   {{(3 - Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Sqrt[(-3 + Sqrt[13])/2]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 3, 5, 5] = 
   {{(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 4, 1, 3] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 4, 1, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 4, 2, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 4, 2, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 4, 3, 3] = 
   {{(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 4, 3, 4] = 
   {{(3 - Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 
      1, 0], Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 4, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 4, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 4, 4, 4] = 
   {{(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 4, 4, 5] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Sqrt[(-3 + Sqrt[13])/2]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-2 + Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Sqrt[(-3 + Sqrt[13])/2], Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 
      0], Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], 
     (2 - Sqrt[13])/3}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 4, 5, 3] = 
   {{(3 - Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Sqrt[(-3 + Sqrt[13])/2]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 4, 5, 4] = 
   {{(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 4, 5, 5] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 5, 1, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 5, 2, 4] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 5, 2, 5] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 5, 3, 3] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 5, 3, 4] = 
   {{(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 5, 3, 5] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 5, 4, 1] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 5, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 5, 4, 4] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 5, 4, 5] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {(-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 5, 5, 1] = {{-1}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 5, 5, 3] = 
   {{(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 5, 5, 4] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     (-5 + Sqrt[13] - Sqrt[6*(1 + Sqrt[13])])/12, (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat1UnitaryFMatrixFunction[5, 5, 5, 5] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}}
 
haagerup6Cat1UnitaryFMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haagerup6Cat1UnitaryFMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
fusionCategory[haagerup6Cat1UnitaryPiv1] ^= haagerup6Cat1Unitary
 
pivotalCategory[haagerup6Cat1UnitaryPiv1] ^= haagerup6Cat1UnitaryPiv1
 
pivotalIsomorphism[haagerup6Cat1UnitaryPiv1] ^= 
   haagerup6Cat1UnitaryPiv1PivotalIsomorphism
 
ring[haagerup6Cat1UnitaryPiv1] ^= haagerup6
 
sphericalCategory[haagerup6Cat1UnitaryPiv1] ^= haagerup6Cat1UnitaryPiv1
 
(pivotalCategoryIndex[fusionCategory[haagerup6Cat1Unitary]][
      pivotalCategory[#1]] & )[haagerup6Cat1UnitaryPiv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haagerup6Cat1Unitary]][
      sphericalCategory[#1]] & )[haagerup6Cat1UnitaryPiv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haagerup6Cat1UnitaryPiv1PivotalIsomorphism] ^= 
   haagerup6Cat1Unitary
 
pivotalCategory[haagerup6Cat1UnitaryPiv1PivotalIsomorphism] ^= 
   haagerup6Cat1UnitaryPiv1
 
pivotalIsomorphism[haagerup6Cat1UnitaryPiv1PivotalIsomorphism] ^= 
   haagerup6Cat1UnitaryPiv1PivotalIsomorphism
 
haagerup6Cat1UnitaryPiv1PivotalIsomorphism[0] = 1
 
haagerup6Cat1UnitaryPiv1PivotalIsomorphism[1] = 1
 
haagerup6Cat1UnitaryPiv1PivotalIsomorphism[2] = 1
 
haagerup6Cat1UnitaryPiv1PivotalIsomorphism[3] = 1
 
haagerup6Cat1UnitaryPiv1PivotalIsomorphism[4] = 1
 
haagerup6Cat1UnitaryPiv1PivotalIsomorphism[5] = 1
balancedCategories[haagerup6Cat2] ^= {}
 
braidedCategories[haagerup6Cat2] ^= {}
 
coeval[haagerup6Cat2] ^= 1/sixJFunction[haagerup6Cat2][#1, 
      dual[ring[haagerup6Cat2]][#1], #1, #1, 0, 0] & 
 
eval[haagerup6Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haagerup6Cat2] ^= haagerup6Cat2FMatrixFunction
 
fusionCategory[haagerup6Cat2] ^= haagerup6Cat2
 
haagerup6Cat2 /: modularCategory[haagerup6Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[haagerup6Cat2] ^= {haagerup6Cat2Piv1}
 
haagerup6Cat2 /: pivotalCategory[haagerup6Cat2, 1] = haagerup6Cat2Piv1
 
haagerup6Cat2 /: pivotalCategory[haagerup6Cat2, {1, 1, 1, 1, 1, 1}] = 
    haagerup6Cat2Piv1
 
ring[haagerup6Cat2] ^= haagerup6
 
haagerup6Cat2 /: sphericalCategory[haagerup6Cat2, 1] = haagerup6Cat2Piv1
 
fusionCategoryIndex[haagerup6][haagerup6Cat2] ^= 2
fMatrixFunction[haagerup6Cat2FMatrixFunction] ^= haagerup6Cat2FMatrixFunction
 
fusionCategory[haagerup6Cat2FMatrixFunction] ^= haagerup6Cat2
 
ring[haagerup6Cat2FMatrixFunction] ^= haagerup6
 
haagerup6Cat2FMatrixFunction[1, 3, 2, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[1, 3, 4, 3] = {{-1}}
 
haagerup6Cat2FMatrixFunction[1, 3, 5, 3] = {{-1}}
 
haagerup6Cat2FMatrixFunction[1, 3, 5, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[1, 3, 5, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[1, 4, 1, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[1, 4, 2, 3] = {{-1}}
 
haagerup6Cat2FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[1, 4, 5, 3] = {{-1}}
 
haagerup6Cat2FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[1, 4, 5, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[1, 5, 1, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[2, 3, 1, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[2, 4, 2, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[2, 4, 4, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[2, 4, 5, 3] = {{-1}}
 
haagerup6Cat2FMatrixFunction[2, 4, 5, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[2, 4, 5, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[2, 5, 1, 3] = {{-1}}
 
haagerup6Cat2FMatrixFunction[2, 5, 2, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haagerup6Cat2FMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haagerup6Cat2FMatrixFunction[2, 5, 5, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[2, 5, 5, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[3, 1, 3, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[3, 1, 3, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[3, 1, 4, 1] = {{-1}}
 
haagerup6Cat2FMatrixFunction[3, 1, 4, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[3, 2, 4, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[3, 2, 5, 2] = {{-1}}
 
haagerup6Cat2FMatrixFunction[3, 2, 5, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[3, 2, 5, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[3, 3, 3, 3] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(3 + Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[3, 3, 3, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[3, 3, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haagerup6Cat2FMatrixFunction[3, 3, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[3, 3, 4, 4] = {{(-3 - Sqrt[13])/2, -1, 1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(3 + Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-2 - Sqrt[13])/3}}
 
haagerup6Cat2FMatrixFunction[3, 3, 4, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[3, 3, 5, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}}
 
haagerup6Cat2FMatrixFunction[3, 3, 5, 4] = 
   {{(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[3, 3, 5, 5] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(3 + Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[3, 4, 3, 2] = {{-1}}
 
haagerup6Cat2FMatrixFunction[3, 4, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[3, 4, 3, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haagerup6Cat2FMatrixFunction[3, 4, 3, 5] = {{(-3 - Sqrt[13])/2, 1, -1, 1}, 
    {(-3 - Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[3, 4, 4, 3] = {{(-3 - Sqrt[13])/2, 1, -1, 1}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-2 - Sqrt[13])/3}}
 
haagerup6Cat2FMatrixFunction[3, 4, 4, 4] = 
   {{(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[3, 4, 4, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[3, 4, 5, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[3, 4, 5, 4] = {{(3 + Sqrt[13])/2, 1, -1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(3 + Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[3, 4, 5, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}}
 
haagerup6Cat2FMatrixFunction[3, 5, 3, 2] = {{-1}}
 
haagerup6Cat2FMatrixFunction[3, 5, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haagerup6Cat2FMatrixFunction[3, 5, 3, 4] = {{(-3 - Sqrt[13])/2, 1, -1, 1}, 
    {(-3 - Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[3, 5, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
haagerup6Cat2FMatrixFunction[3, 5, 4, 3] = 
   {{(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[3, 5, 4, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[3, 5, 4, 5] = {{(3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (-2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}}
 
haagerup6Cat2FMatrixFunction[3, 5, 5, 2] = {{-1}}
 
haagerup6Cat2FMatrixFunction[3, 5, 5, 3] = {{(-3 - Sqrt[13])/2, 1, 1, -1}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[3, 5, 5, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}}
 
haagerup6Cat2FMatrixFunction[3, 5, 5, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[4, 1, 3, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 1, 4, 2] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 1, 4, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 1, 4, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 2, 3, 2] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 2, 4, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 2, 5, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 3, 1, 3] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 3, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[4, 3, 3, 4] = {{(-3 - Sqrt[13])/2, 1, -1, 1}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-2 - Sqrt[13])/3}}
 
haagerup6Cat2FMatrixFunction[4, 3, 3, 5] = 
   {{(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[4, 3, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haagerup6Cat2FMatrixFunction[4, 3, 4, 4] = 
   {{(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[4, 3, 4, 5] = {{(3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}, 
    {(3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(3 + Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[4, 3, 5, 3] = {{(-3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[4, 3, 5, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[4, 3, 5, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haagerup6Cat2FMatrixFunction[4, 4, 1, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 4, 3, 3] = {{(-3 - Sqrt[13])/2, -1, 1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(3 + Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-2 - Sqrt[13])/3}}
 
haagerup6Cat2FMatrixFunction[4, 4, 3, 4] = 
   {{(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[4, 4, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 4, 4, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[4, 4, 4, 4] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-2 - Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[4, 4, 4, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haagerup6Cat2FMatrixFunction[4, 4, 5, 1] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 4, 5, 3] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[4, 4, 5, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haagerup6Cat2FMatrixFunction[4, 4, 5, 5] = {{(-3 - Sqrt[13])/2, -1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-2 - Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[4, 5, 2, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 5, 3, 1] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 5, 3, 2] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 5, 3, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[4, 5, 3, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[4, 5, 3, 5] = {{(3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (-2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}}
 
haagerup6Cat2FMatrixFunction[4, 5, 4, 1] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 5, 4, 3] = {{(3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}, 
    {(3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(3 + Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[4, 5, 4, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haagerup6Cat2FMatrixFunction[4, 5, 4, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[4, 5, 5, 1] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 5, 5, 2] = {{-1}}
 
haagerup6Cat2FMatrixFunction[4, 5, 5, 3] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}}
 
haagerup6Cat2FMatrixFunction[4, 5, 5, 4] = {{(-3 - Sqrt[13])/2, 1, 1, 1}, 
    {(3 + Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (-2 - Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[4, 5, 5, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 1, 3, 1] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 1, 3, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 1, 5, 2] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 2, 5, 1] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 3, 1, 3] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 3, 1, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 3, 2, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 3, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}}
 
haagerup6Cat2FMatrixFunction[5, 3, 3, 4] = 
   {{(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 3, 3, 5] = {{(-3 - Sqrt[13])/2, 1, 1, -1}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 3, 4, 3] = {{(-3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 3, 4, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 3, 4, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}}
 
haagerup6Cat2FMatrixFunction[5, 3, 5, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 3, 5, 4] = {{(3 + Sqrt[13])/2, 1, 1, 1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (-2 - Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}}
 
haagerup6Cat2FMatrixFunction[5, 3, 5, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 4, 1, 3] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 4, 1, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 4, 2, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 4, 2, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 4, 3, 3] = 
   {{(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 4, 3, 4] = {{(3 + Sqrt[13])/2, 1, -1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(3 + Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 4, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}}
 
haagerup6Cat2FMatrixFunction[5, 4, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 4, 4, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haagerup6Cat2FMatrixFunction[5, 4, 4, 5] = {{(-3 - Sqrt[13])/2, 1, 1, 1}, 
    {(3 + Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (-2 - Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 4, 5, 3] = {{(3 + Sqrt[13])/2, 1, 1, 1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (-2 - Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}}
 
haagerup6Cat2FMatrixFunction[5, 4, 5, 4] = 
   {{(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 4, 5, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 5, 1, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 5, 2, 4] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 5, 2, 5] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 5, 3, 3] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(3 + Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 5, 3, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}}
 
haagerup6Cat2FMatrixFunction[5, 5, 3, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 5, 4, 1] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 5, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haagerup6Cat2FMatrixFunction[5, 5, 4, 4] = {{(-3 - Sqrt[13])/2, -1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-2 - Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 5, 4, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 5, 5, 1] = {{-1}}
 
haagerup6Cat2FMatrixFunction[5, 5, 5, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 5, 5, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat2FMatrixFunction[5, 5, 5, 5] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], 
     (-2 - Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}}
 
haagerup6Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haagerup6Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[haagerup6Cat2Piv1] ^= {}
 
fusionCategory[haagerup6Cat2Piv1] ^= haagerup6Cat2
 
haagerup6Cat2Piv1 /: modularCategory[haagerup6Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[haagerup6Cat2Piv1] ^= haagerup6Cat2Piv1
 
pivotalIsomorphism[haagerup6Cat2Piv1] ^= haagerup6Cat2Piv1PivotalIsomorphism
 
ring[haagerup6Cat2Piv1] ^= haagerup6
 
sphericalCategory[haagerup6Cat2Piv1] ^= haagerup6Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[haagerup6Cat2]][pivotalCategory[#1]] & )[
    haagerup6Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haagerup6Cat2]][
      sphericalCategory[#1]] & )[haagerup6Cat2Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haagerup6Cat2Piv1PivotalIsomorphism] ^= haagerup6Cat2
 
pivotalCategory[haagerup6Cat2Piv1PivotalIsomorphism] ^= haagerup6Cat2Piv1
 
pivotalIsomorphism[haagerup6Cat2Piv1PivotalIsomorphism] ^= 
   haagerup6Cat2Piv1PivotalIsomorphism
 
haagerup6Cat2Piv1PivotalIsomorphism[0] = 1
 
haagerup6Cat2Piv1PivotalIsomorphism[1] = 1
 
haagerup6Cat2Piv1PivotalIsomorphism[2] = 1
 
haagerup6Cat2Piv1PivotalIsomorphism[3] = 1
 
haagerup6Cat2Piv1PivotalIsomorphism[4] = 1
 
haagerup6Cat2Piv1PivotalIsomorphism[5] = 1
balancedCategories[haagerup6Cat3] ^= {}
 
braidedCategories[haagerup6Cat3] ^= {}
 
coeval[haagerup6Cat3] ^= 1/sixJFunction[haagerup6Cat3][#1, 
      dual[ring[haagerup6Cat3]][#1], #1, #1, 0, 0] & 
 
eval[haagerup6Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haagerup6Cat3] ^= haagerup6Cat3FMatrixFunction
 
fusionCategory[haagerup6Cat3] ^= haagerup6Cat3
 
haagerup6Cat3 /: modularCategory[haagerup6Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[haagerup6Cat3] ^= {haagerup6Cat3Piv1}
 
haagerup6Cat3 /: pivotalCategory[haagerup6Cat3, 1] = haagerup6Cat3Piv1
 
haagerup6Cat3 /: pivotalCategory[haagerup6Cat3, {1, 1, 1, 1, 1, 1}] = 
    haagerup6Cat3Piv1
 
ring[haagerup6Cat3] ^= haagerup6
 
haagerup6Cat3 /: sphericalCategory[haagerup6Cat3, 1] = haagerup6Cat3Piv1
 
fusionCategoryIndex[haagerup6][haagerup6Cat3] ^= 3
fMatrixFunction[haagerup6Cat3FMatrixFunction] ^= haagerup6Cat3FMatrixFunction
 
fusionCategory[haagerup6Cat3FMatrixFunction] ^= haagerup6Cat3
 
ring[haagerup6Cat3FMatrixFunction] ^= haagerup6
 
haagerup6Cat3FMatrixFunction[1, 3, 2, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[1, 3, 4, 3] = {{-1}}
 
haagerup6Cat3FMatrixFunction[1, 3, 5, 3] = {{-1}}
 
haagerup6Cat3FMatrixFunction[1, 3, 5, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[1, 3, 5, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[1, 4, 1, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[1, 4, 2, 3] = {{-1}}
 
haagerup6Cat3FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[1, 4, 5, 3] = {{-1}}
 
haagerup6Cat3FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[1, 4, 5, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[1, 5, 1, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[2, 3, 1, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[2, 4, 2, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[2, 4, 4, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[2, 4, 5, 3] = {{-1}}
 
haagerup6Cat3FMatrixFunction[2, 4, 5, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[2, 4, 5, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[2, 5, 1, 3] = {{-1}}
 
haagerup6Cat3FMatrixFunction[2, 5, 2, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haagerup6Cat3FMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haagerup6Cat3FMatrixFunction[2, 5, 5, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[2, 5, 5, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[3, 1, 3, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[3, 1, 3, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[3, 1, 4, 1] = {{-1}}
 
haagerup6Cat3FMatrixFunction[3, 1, 4, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[3, 2, 4, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[3, 2, 5, 2] = {{-1}}
 
haagerup6Cat3FMatrixFunction[3, 2, 5, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[3, 2, 5, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[3, 3, 3, 3] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(3 - Sqrt[13])/2, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, (7 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 3, 3, 4] = 
   {{(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 3, 3, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat3FMatrixFunction[3, 3, 4, 3] = 
   {{(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 3, 4, 4] = {{(-3 + Sqrt[13])/2, -1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(3 - Sqrt[13])/2, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 3, 4, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 3, 5, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat3FMatrixFunction[3, 3, 5, 4] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 3, 5, 5] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 4, 3, 2] = {{-1}}
 
haagerup6Cat3FMatrixFunction[3, 4, 3, 3] = 
   {{(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 4, 3, 4] = 
   {{(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat3FMatrixFunction[3, 4, 3, 5] = {{(-3 + Sqrt[13])/2, 1, -1, 1}, 
    {(-3 + Sqrt[13])/2, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 4, 4, 3] = {{(-3 + Sqrt[13])/2, 1, -1, 1}, 
    {(3 - Sqrt[13])/2, (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 4, 4, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 4, 4, 5] = 
   {{(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 4, 5, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 4, 5, 4] = {{(3 - Sqrt[13])/2, 1, -1, -1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 4, 5, 5] = 
   {{(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat3FMatrixFunction[3, 5, 3, 2] = {{-1}}
 
haagerup6Cat3FMatrixFunction[3, 5, 3, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat3FMatrixFunction[3, 5, 3, 4] = {{(-3 + Sqrt[13])/2, 1, -1, 1}, 
    {(-3 + Sqrt[13])/2, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 5, 3, 5] = 
   {{(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
haagerup6Cat3FMatrixFunction[3, 5, 4, 3] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 5, 4, 4] = 
   {{(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 5, 4, 5] = {{(3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (-7 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-7 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 5, 5, 2] = {{-1}}
 
haagerup6Cat3FMatrixFunction[3, 5, 5, 3] = {{(-3 + Sqrt[13])/2, 1, 1, -1}, 
    {(3 - Sqrt[13])/2, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[3, 5, 5, 4] = 
   {{(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat3FMatrixFunction[3, 5, 5, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 1, 3, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 1, 4, 2] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 1, 4, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 1, 4, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 2, 3, 2] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 2, 4, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 2, 5, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 3, 1, 3] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 3, 3, 3] = 
   {{(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 3, 3, 4] = {{(-3 + Sqrt[13])/2, 1, -1, 1}, 
    {(3 - Sqrt[13])/2, (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 3, 3, 5] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 3, 4, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat3FMatrixFunction[4, 3, 4, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 3, 4, 5] = {{(3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 3, 5, 3] = {{(-3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (7 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(3 - Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (1 - Sqrt[13])/6, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 3, 5, 4] = 
   {{(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 3, 5, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat3FMatrixFunction[4, 4, 1, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 4, 3, 3] = {{(-3 + Sqrt[13])/2, -1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(3 - Sqrt[13])/2, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 4, 3, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 4, 3, 5] = 
   {{(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 4, 4, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 4, 4, 4] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(3 - Sqrt[13])/2, (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (-7 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (-7 + Sqrt[13])/6, (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 4, 4, 5] = 
   {{(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat3FMatrixFunction[4, 4, 5, 1] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 4, 5, 3] = 
   {{(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 4, 5, 4] = 
   {{(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat3FMatrixFunction[4, 4, 5, 5] = {{(-3 + Sqrt[13])/2, -1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-7 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 5, 2, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 5, 3, 1] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 5, 3, 2] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 5, 3, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 5, 3, 4] = 
   {{(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 5, 3, 5] = {{(3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (-7 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-7 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 5, 4, 1] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 5, 4, 3] = {{(3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 5, 4, 4] = 
   {{(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat3FMatrixFunction[4, 5, 4, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 5, 5, 1] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 5, 5, 2] = {{-1}}
 
haagerup6Cat3FMatrixFunction[4, 5, 5, 3] = 
   {{(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat3FMatrixFunction[4, 5, 5, 4] = {{(-3 + Sqrt[13])/2, 1, 1, 1}, 
    {(3 - Sqrt[13])/2, (-7 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, (7 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (-7 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[4, 5, 5, 5] = 
   {{(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 1, 3, 1] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 1, 3, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 1, 5, 2] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 2, 5, 1] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 3, 1, 3] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 3, 1, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 3, 2, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 3, 3, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat3FMatrixFunction[5, 3, 3, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 3, 3, 5] = {{(-3 + Sqrt[13])/2, 1, 1, -1}, 
    {(3 - Sqrt[13])/2, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 3, 4, 3] = {{(-3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (7 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(3 - Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (1 - Sqrt[13])/6, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 3, 4, 4] = 
   {{(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 3, 4, 5] = 
   {{(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat3FMatrixFunction[5, 3, 5, 3] = 
   {{(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 3, 5, 4] = {{(3 - Sqrt[13])/2, 1, 1, 1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (-7 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-7 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6, (7 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 3, 5, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 4, 1, 3] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 4, 1, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 4, 2, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 4, 2, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 4, 3, 3] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 4, 3, 4] = {{(3 - Sqrt[13])/2, 1, -1, -1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 4, 3, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat3FMatrixFunction[5, 4, 4, 3] = 
   {{(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 4, 4, 4] = 
   {{(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat3FMatrixFunction[5, 4, 4, 5] = {{(-3 + Sqrt[13])/2, 1, 1, 1}, 
    {(3 - Sqrt[13])/2, (-7 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, (7 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (-7 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 4, 5, 3] = {{(3 - Sqrt[13])/2, 1, 1, 1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (-7 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-7 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6, (7 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 4, 5, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 4, 5, 5] = 
   {{(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 5, 1, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 5, 2, 4] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 5, 2, 5] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 5, 3, 3] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 5, 3, 4] = 
   {{(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat3FMatrixFunction[5, 5, 3, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 5, 4, 1] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 5, 4, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat3FMatrixFunction[5, 5, 4, 4] = {{(-3 + Sqrt[13])/2, -1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-7 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 5, 4, 5] = 
   {{(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 5, 5, 1] = {{-1}}
 
haagerup6Cat3FMatrixFunction[5, 5, 5, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 5, 5, 4] = 
   {{(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[5, 5, 5, 5] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(3 - Sqrt[13])/2, (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-7 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, (7 - Sqrt[13])/6}}
 
haagerup6Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haagerup6Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[haagerup6Cat3Piv1] ^= {}
 
fusionCategory[haagerup6Cat3Piv1] ^= haagerup6Cat3
 
haagerup6Cat3Piv1 /: modularCategory[haagerup6Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[haagerup6Cat3Piv1] ^= haagerup6Cat3Piv1
 
pivotalIsomorphism[haagerup6Cat3Piv1] ^= haagerup6Cat3Piv1PivotalIsomorphism
 
ring[haagerup6Cat3Piv1] ^= haagerup6
 
sphericalCategory[haagerup6Cat3Piv1] ^= haagerup6Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[haagerup6Cat3]][pivotalCategory[#1]] & )[
    haagerup6Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haagerup6Cat3]][
      sphericalCategory[#1]] & )[haagerup6Cat3Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haagerup6Cat3Piv1PivotalIsomorphism] ^= haagerup6Cat3
 
pivotalCategory[haagerup6Cat3Piv1PivotalIsomorphism] ^= haagerup6Cat3Piv1
 
pivotalIsomorphism[haagerup6Cat3Piv1PivotalIsomorphism] ^= 
   haagerup6Cat3Piv1PivotalIsomorphism
 
haagerup6Cat3Piv1PivotalIsomorphism[0] = 1
 
haagerup6Cat3Piv1PivotalIsomorphism[1] = 1
 
haagerup6Cat3Piv1PivotalIsomorphism[2] = 1
 
haagerup6Cat3Piv1PivotalIsomorphism[3] = 1
 
haagerup6Cat3Piv1PivotalIsomorphism[4] = 1
 
haagerup6Cat3Piv1PivotalIsomorphism[5] = 1
coeval[haagerup6Cat3Unitary] ^= 
   1/sixJFunction[haagerup6Cat3Unitary][#1, dual[ring[haagerup6Cat3Unitary]][
       #1], #1, #1, 0, 0] & 
 
eval[haagerup6Cat3Unitary] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haagerup6Cat3Unitary] ^= haagerup6Cat3UnitaryFMatrixFunction
 
fusionCategory[haagerup6Cat3Unitary] ^= haagerup6Cat3Unitary
 
pivotalCategories[haagerup6Cat3Unitary] ^= {haagerup6Cat3UnitaryPiv1}
 
haagerup6Cat3Unitary /: pivotalCategory[haagerup6Cat3Unitary, 1] = 
    haagerup6Cat3UnitaryPiv1
 
haagerup6Cat3Unitary /: pivotalCategory[haagerup6Cat3Unitary, 
     {1, 1, 1, 1, 1, 1}] = haagerup6Cat3UnitaryPiv1
 
ring[haagerup6Cat3Unitary] ^= haagerup6
 
haagerup6Cat3Unitary /: sphericalCategory[haagerup6Cat3Unitary, 1] = 
    haagerup6Cat3UnitaryPiv1
 
fusionCategoryIndex[haagerup6][haagerup6Cat3Unitary] ^= 10
fMatrixFunction[haagerup6Cat3UnitaryFMatrixFunction] ^= 
   haagerup6Cat3UnitaryFMatrixFunction
 
fusionCategory[haagerup6Cat3UnitaryFMatrixFunction] ^= haagerup6Cat3Unitary
 
ring[haagerup6Cat3UnitaryFMatrixFunction] ^= haagerup6
 
haagerup6Cat3UnitaryFMatrixFunction[1, 3, 2, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[1, 3, 4, 3] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[1, 3, 5, 3] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[1, 3, 5, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[1, 3, 5, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[1, 4, 1, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[1, 4, 2, 3] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[1, 4, 5, 3] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[1, 4, 5, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[1, 5, 1, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[2, 3, 1, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[2, 4, 2, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[2, 4, 4, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[2, 4, 5, 3] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[2, 4, 5, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[2, 4, 5, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[2, 5, 1, 3] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[2, 5, 2, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[2, 5, 5, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[2, 5, 5, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 1, 3, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 1, 3, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 1, 4, 1] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 1, 4, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 2, 4, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 2, 5, 2] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 2, 5, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 2, 5, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 3, 3, 3] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, (7 - Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 3, 3, 4] = 
   {{(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 3, 3, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 3, 4, 3] = 
   {{(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 3, 4, 4] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (-7 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 3, 4, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 3, 5, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 3, 5, 4] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 3, 5, 5] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 4, 3, 2] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 4, 3, 3] = 
   {{(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 4, 3, 4] = 
   {{(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 4, 3, 5] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 
      1, 0], Sqrt[(-3 + Sqrt[13])/2]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, 
    {Sqrt[(-3 + Sqrt[13])/2], (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 4, 4, 3] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 
      1, 0], Sqrt[(-3 + Sqrt[13])/2]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}, 
    {Sqrt[(-3 + Sqrt[13])/2], (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 4, 4, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 4, 4, 5] = 
   {{(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 4, 5, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 4, 5, 4] = 
   {{(3 - Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 
      1, 0], Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, (7 - Sqrt[13])/6}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 4, 5, 5] = 
   {{(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 5, 3, 2] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 5, 3, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 5, 3, 4] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 
      1, 0], Sqrt[(-3 + Sqrt[13])/2]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, 
    {Sqrt[(-3 + Sqrt[13])/2], (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 5, 3, 5] = 
   {{(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 5, 4, 2] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 5, 4, 3] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 5, 4, 4] = 
   {{(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 5, 4, 5] = 
   {{(3 - Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-1 + Sqrt[13])/6, (-7 + Sqrt[13])/6, (1 - Sqrt[13])/6}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-7 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 5, 5, 2] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 5, 5, 3] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6}, 
    {Sqrt[(-3 + Sqrt[13])/2], (1 - Sqrt[13])/6, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], (7 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 5, 5, 4] = 
   {{(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat3UnitaryFMatrixFunction[3, 5, 5, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 1, 3, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 1, 4, 2] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 1, 4, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 1, 4, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 2, 3, 2] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 2, 4, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 2, 5, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 3, 1, 3] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 3, 3, 3] = 
   {{(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 3, 3, 4] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 
      1, 0], Sqrt[(-3 + Sqrt[13])/2]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}, 
    {Sqrt[(-3 + Sqrt[13])/2], (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 3, 3, 5] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 3, 4, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 3, 4, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 3, 4, 5] = 
   {{(3 - Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (1 - Sqrt[13])/6, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 3, 5, 3] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 3, 5, 4] = 
   {{(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 3, 5, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 4, 1, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 4, 3, 3] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (-7 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 4, 3, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 4, 3, 5] = 
   {{(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 4, 4, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 4, 4, 4] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (-7 + Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-7 + Sqrt[13])/6, (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 4, 4, 5] = 
   {{(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 4, 5, 1] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 4, 5, 3] = 
   {{(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 4, 5, 4] = 
   {{(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 4, 5, 5] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-7 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 5, 2, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 5, 3, 1] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 5, 3, 2] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 5, 3, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 5, 3, 4] = 
   {{(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 5, 3, 5] = 
   {{(3 - Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-1 + Sqrt[13])/6, (-7 + Sqrt[13])/6, (1 - Sqrt[13])/6}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-7 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 5, 4, 1] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 5, 4, 3] = 
   {{(3 - Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (1 - Sqrt[13])/6, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 5, 4, 4] = 
   {{(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 5, 4, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 5, 5, 1] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 5, 5, 2] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 5, 5, 3] = 
   {{(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 5, 5, 4] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Sqrt[(-3 + Sqrt[13])/2]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-7 + Sqrt[13])/6, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, 
    {Sqrt[(-3 + Sqrt[13])/2], (1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-1 + Sqrt[13])/6, (-7 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[4, 5, 5, 5] = 
   {{(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 1, 3, 1] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 1, 3, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 1, 5, 2] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 2, 5, 1] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 3, 1, 3] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 3, 1, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 3, 2, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 3, 3, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 3, 3, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 3, 3, 5] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6}, 
    {Sqrt[(-3 + Sqrt[13])/2], (1 - Sqrt[13])/6, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], (7 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 3, 4, 3] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 3, 4, 4] = 
   {{(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 3, 4, 5] = 
   {{(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 3, 5, 3] = 
   {{(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 3, 5, 4] = 
   {{(3 - Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Sqrt[(-3 + Sqrt[13])/2]}, {Sqrt[(-3 + Sqrt[13])/2], (-1 + Sqrt[13])/6, 
     (-7 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-7 + Sqrt[13])/6, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 3, 5, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 4, 1, 3] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 4, 1, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 4, 2, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 4, 2, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 4, 3, 3] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 4, 3, 4] = 
   {{(3 - Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 
      1, 0], Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, (7 - Sqrt[13])/6}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 4, 3, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 4, 4, 3] = 
   {{(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 4, 4, 4] = 
   {{(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 4, 4, 5] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Sqrt[(-3 + Sqrt[13])/2]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-7 + Sqrt[13])/6, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, 
    {Sqrt[(-3 + Sqrt[13])/2], (1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-1 + Sqrt[13])/6, (-7 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 4, 5, 3] = 
   {{(3 - Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2], 
     Sqrt[(-3 + Sqrt[13])/2]}, {Sqrt[(-3 + Sqrt[13])/2], (-1 + Sqrt[13])/6, 
     (-7 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-7 + Sqrt[13])/6, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 4, 5, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 4, 5, 5] = 
   {{(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 5, 1, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 5, 2, 4] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 5, 2, 5] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 5, 3, 3] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 5, 3, 4] = 
   {{(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 5, 3, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 5, 4, 1] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 5, 4, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 5, 4, 4] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], (-7 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 5, 4, 5] = 
   {{(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 5, 5, 1] = {{-1}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 5, 5, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 5, 5, 4] = 
   {{(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[5, 5, 5, 5] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Sqrt[(-3 + Sqrt[13])/2]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], (-7 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {Sqrt[(-3 + Sqrt[13])/2], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, (7 - Sqrt[13])/6}}
 
haagerup6Cat3UnitaryFMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haagerup6Cat3UnitaryFMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
fusionCategory[haagerup6Cat3UnitaryPiv1] ^= haagerup6Cat3Unitary
 
pivotalCategory[haagerup6Cat3UnitaryPiv1] ^= haagerup6Cat3UnitaryPiv1
 
pivotalIsomorphism[haagerup6Cat3UnitaryPiv1] ^= 
   haagerup6Cat3UnitaryPiv1PivotalIsomorphism
 
ring[haagerup6Cat3UnitaryPiv1] ^= haagerup6
 
sphericalCategory[haagerup6Cat3UnitaryPiv1] ^= haagerup6Cat3UnitaryPiv1
 
(pivotalCategoryIndex[fusionCategory[haagerup6Cat3Unitary]][
      pivotalCategory[#1]] & )[haagerup6Cat3UnitaryPiv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haagerup6Cat3Unitary]][
      sphericalCategory[#1]] & )[haagerup6Cat3UnitaryPiv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haagerup6Cat3UnitaryPiv1PivotalIsomorphism] ^= 
   haagerup6Cat3Unitary
 
pivotalCategory[haagerup6Cat3UnitaryPiv1PivotalIsomorphism] ^= 
   haagerup6Cat3UnitaryPiv1
 
pivotalIsomorphism[haagerup6Cat3UnitaryPiv1PivotalIsomorphism] ^= 
   haagerup6Cat3UnitaryPiv1PivotalIsomorphism
 
haagerup6Cat3UnitaryPiv1PivotalIsomorphism[0] = 1
 
haagerup6Cat3UnitaryPiv1PivotalIsomorphism[1] = 1
 
haagerup6Cat3UnitaryPiv1PivotalIsomorphism[2] = 1
 
haagerup6Cat3UnitaryPiv1PivotalIsomorphism[3] = 1
 
haagerup6Cat3UnitaryPiv1PivotalIsomorphism[4] = 1
 
haagerup6Cat3UnitaryPiv1PivotalIsomorphism[5] = 1
balancedCategories[haagerup6Cat4] ^= {}
 
braidedCategories[haagerup6Cat4] ^= {}
 
coeval[haagerup6Cat4] ^= 1/sixJFunction[haagerup6Cat4][#1, 
      dual[ring[haagerup6Cat4]][#1], #1, #1, 0, 0] & 
 
eval[haagerup6Cat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haagerup6Cat4] ^= haagerup6Cat4FMatrixFunction
 
fusionCategory[haagerup6Cat4] ^= haagerup6Cat4
 
haagerup6Cat4 /: modularCategory[haagerup6Cat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[haagerup6Cat4] ^= {haagerup6Cat4Piv1}
 
haagerup6Cat4 /: pivotalCategory[haagerup6Cat4, 1] = haagerup6Cat4Piv1
 
haagerup6Cat4 /: pivotalCategory[haagerup6Cat4, {1, 1, 1, 1, 1, 1}] = 
    haagerup6Cat4Piv1
 
ring[haagerup6Cat4] ^= haagerup6
 
haagerup6Cat4 /: sphericalCategory[haagerup6Cat4, 1] = haagerup6Cat4Piv1
 
fusionCategoryIndex[haagerup6][haagerup6Cat4] ^= 4
fMatrixFunction[haagerup6Cat4FMatrixFunction] ^= haagerup6Cat4FMatrixFunction
 
fusionCategory[haagerup6Cat4FMatrixFunction] ^= haagerup6Cat4
 
ring[haagerup6Cat4FMatrixFunction] ^= haagerup6
 
haagerup6Cat4FMatrixFunction[1, 3, 2, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[1, 3, 4, 3] = {{-1}}
 
haagerup6Cat4FMatrixFunction[1, 3, 5, 3] = {{-1}}
 
haagerup6Cat4FMatrixFunction[1, 3, 5, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[1, 3, 5, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[1, 4, 1, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[1, 4, 2, 3] = {{-1}}
 
haagerup6Cat4FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[1, 4, 5, 3] = {{-1}}
 
haagerup6Cat4FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[1, 4, 5, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[1, 5, 1, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[2, 3, 1, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[2, 4, 2, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[2, 4, 4, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[2, 4, 5, 3] = {{-1}}
 
haagerup6Cat4FMatrixFunction[2, 4, 5, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[2, 4, 5, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[2, 5, 1, 3] = {{-1}}
 
haagerup6Cat4FMatrixFunction[2, 5, 2, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haagerup6Cat4FMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haagerup6Cat4FMatrixFunction[2, 5, 5, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[2, 5, 5, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[3, 1, 3, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[3, 1, 3, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[3, 1, 4, 1] = {{-1}}
 
haagerup6Cat4FMatrixFunction[3, 1, 4, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[3, 2, 4, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[3, 2, 5, 2] = {{-1}}
 
haagerup6Cat4FMatrixFunction[3, 2, 5, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[3, 2, 5, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[3, 3, 3, 3] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(3 + Sqrt[13])/2, (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6, (7 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 3, 3, 4] = 
   {{(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 3, 3, 5] = 
   {{(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat4FMatrixFunction[3, 3, 4, 3] = 
   {{(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 3, 4, 4] = {{(-3 - Sqrt[13])/2, -1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(3 + Sqrt[13])/2, (7 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, (-7 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 3, 4, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 3, 5, 3] = 
   {{(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat4FMatrixFunction[3, 3, 5, 4] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 3, 5, 5] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     (7 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (7 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 4, 3, 2] = {{-1}}
 
haagerup6Cat4FMatrixFunction[3, 4, 3, 3] = 
   {{(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 4, 3, 4] = 
   {{(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat4FMatrixFunction[3, 4, 3, 5] = {{(-3 - Sqrt[13])/2, 1, -1, 1}, 
    {(-3 - Sqrt[13])/2, (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 4, 4, 3] = {{(-3 - Sqrt[13])/2, 1, -1, 1}, 
    {(3 + Sqrt[13])/2, (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (7 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, (-7 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 4, 4, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 4, 4, 5] = 
   {{(-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 4, 5, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 4, 5, 4] = {{(3 + Sqrt[13])/2, 1, -1, -1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     (7 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (7 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 4, 5, 5] = 
   {{(-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat4FMatrixFunction[3, 5, 3, 2] = {{-1}}
 
haagerup6Cat4FMatrixFunction[3, 5, 3, 3] = 
   {{(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat4FMatrixFunction[3, 5, 3, 4] = {{(-3 - Sqrt[13])/2, 1, -1, 1}, 
    {(-3 - Sqrt[13])/2, (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 5, 3, 5] = 
   {{(1 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
haagerup6Cat4FMatrixFunction[3, 5, 4, 3] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 5, 4, 4] = 
   {{(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 5, 4, 5] = {{(3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (-7 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-7 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 5, 5, 2] = {{-1}}
 
haagerup6Cat4FMatrixFunction[3, 5, 5, 3] = {{(-3 - Sqrt[13])/2, 1, 1, -1}, 
    {(3 + Sqrt[13])/2, (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (7 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (1 + Sqrt[13])/6, 
     (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (7 + Sqrt[13])/6, (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[3, 5, 5, 4] = 
   {{(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat4FMatrixFunction[3, 5, 5, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 1, 3, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 1, 4, 2] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 1, 4, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 1, 4, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 2, 3, 2] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 2, 4, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 2, 5, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 3, 1, 3] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 3, 3, 3] = 
   {{(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 3, 3, 4] = {{(-3 - Sqrt[13])/2, 1, -1, 1}, 
    {(3 + Sqrt[13])/2, (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (7 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, (-7 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 3, 3, 5] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 3, 4, 3] = 
   {{(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat4FMatrixFunction[4, 3, 4, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 3, 4, 5] = {{(3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (7 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, (1 + Sqrt[13])/6, 
     (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (7 + Sqrt[13])/6, (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 3, 5, 3] = {{(-3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (7 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(3 + Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (1 + Sqrt[13])/6, (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 3, 5, 4] = 
   {{(1 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 3, 5, 5] = 
   {{(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat4FMatrixFunction[4, 4, 1, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 4, 3, 3] = {{(-3 - Sqrt[13])/2, -1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(3 + Sqrt[13])/2, (7 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, (-7 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 4, 3, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 4, 3, 5] = 
   {{(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 4, 4, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 4, 4, 4] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(3 + Sqrt[13])/2, (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (-7 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (7 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (-7 - Sqrt[13])/6, (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 4, 4, 5] = 
   {{(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat4FMatrixFunction[4, 4, 5, 1] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 4, 5, 3] = 
   {{(-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 4, 5, 4] = 
   {{(-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat4FMatrixFunction[4, 4, 5, 5] = {{(-3 - Sqrt[13])/2, -1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-7 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6, (-7 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 5, 2, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 5, 3, 1] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 5, 3, 2] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 5, 3, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 5, 3, 4] = 
   {{(-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 5, 3, 5] = {{(3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (-7 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-7 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 5, 4, 1] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 5, 4, 3] = {{(3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (7 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, (1 + Sqrt[13])/6, 
     (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (7 + Sqrt[13])/6, (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 5, 4, 4] = 
   {{(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat4FMatrixFunction[4, 5, 4, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 5, 5, 1] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 5, 5, 2] = {{-1}}
 
haagerup6Cat4FMatrixFunction[4, 5, 5, 3] = 
   {{(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat4FMatrixFunction[4, 5, 5, 4] = {{(-3 - Sqrt[13])/2, 1, 1, 1}, 
    {(3 + Sqrt[13])/2, (-7 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, (7 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (-7 - Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[4, 5, 5, 5] = 
   {{(-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 1, 3, 1] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 1, 3, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 1, 5, 2] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 2, 5, 1] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 3, 1, 3] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 3, 1, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 3, 2, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 3, 3, 3] = 
   {{(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat4FMatrixFunction[5, 3, 3, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 3, 3, 5] = {{(-3 - Sqrt[13])/2, 1, 1, -1}, 
    {(3 + Sqrt[13])/2, (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (7 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (1 + Sqrt[13])/6, 
     (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (7 + Sqrt[13])/6, (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 3, 4, 3] = {{(-3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (7 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(3 + Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (1 + Sqrt[13])/6, (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 3, 4, 4] = 
   {{(-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 3, 4, 5] = 
   {{(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat4FMatrixFunction[5, 3, 5, 3] = 
   {{(1 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 3, 5, 4] = {{(3 + Sqrt[13])/2, 1, 1, 1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (-7 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-7 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6, (7 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 3, 5, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 4, 1, 3] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 4, 1, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 4, 2, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 4, 2, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 4, 3, 3] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 4, 3, 4] = {{(3 + Sqrt[13])/2, 1, -1, -1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     (7 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (7 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 4, 3, 5] = 
   {{(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}}
 
haagerup6Cat4FMatrixFunction[5, 4, 4, 3] = 
   {{(1 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 4, 4, 4] = 
   {{(-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat4FMatrixFunction[5, 4, 4, 5] = {{(-3 - Sqrt[13])/2, 1, 1, 1}, 
    {(3 + Sqrt[13])/2, (-7 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, (7 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (-7 - Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 4, 5, 3] = {{(3 + Sqrt[13])/2, 1, 1, 1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (-7 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-7 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6, (7 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 4, 5, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 4, 5, 5] = 
   {{(-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 5, 1, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 5, 2, 4] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 5, 2, 5] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 5, 3, 3] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     (7 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (7 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 5, 3, 4] = 
   {{(-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat4FMatrixFunction[5, 5, 3, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 5, 4, 1] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 5, 4, 3] = 
   {{(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}}
 
haagerup6Cat4FMatrixFunction[5, 5, 4, 4] = {{(-3 - Sqrt[13])/2, -1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-7 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6, (-7 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 5, 4, 5] = 
   {{(-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 5, 5, 1] = {{-1}}
 
haagerup6Cat4FMatrixFunction[5, 5, 5, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 5, 5, 4] = 
   {{(-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[5, 5, 5, 5] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(3 + Sqrt[13])/2, (1 + Sqrt[13])/6, (-7 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-7 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, (7 + Sqrt[13])/6}}
 
haagerup6Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haagerup6Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[haagerup6Cat4Piv1] ^= {}
 
fusionCategory[haagerup6Cat4Piv1] ^= haagerup6Cat4
 
haagerup6Cat4Piv1 /: modularCategory[haagerup6Cat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[haagerup6Cat4Piv1] ^= haagerup6Cat4Piv1
 
pivotalIsomorphism[haagerup6Cat4Piv1] ^= haagerup6Cat4Piv1PivotalIsomorphism
 
ring[haagerup6Cat4Piv1] ^= haagerup6
 
sphericalCategory[haagerup6Cat4Piv1] ^= haagerup6Cat4Piv1
 
(pivotalCategoryIndex[fusionCategory[haagerup6Cat4]][pivotalCategory[#1]] & )[
    haagerup6Cat4Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haagerup6Cat4]][
      sphericalCategory[#1]] & )[haagerup6Cat4Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haagerup6Cat4Piv1PivotalIsomorphism] ^= haagerup6Cat4
 
pivotalCategory[haagerup6Cat4Piv1PivotalIsomorphism] ^= haagerup6Cat4Piv1
 
pivotalIsomorphism[haagerup6Cat4Piv1PivotalIsomorphism] ^= 
   haagerup6Cat4Piv1PivotalIsomorphism
 
haagerup6Cat4Piv1PivotalIsomorphism[0] = 1
 
haagerup6Cat4Piv1PivotalIsomorphism[1] = 1
 
haagerup6Cat4Piv1PivotalIsomorphism[2] = 1
 
haagerup6Cat4Piv1PivotalIsomorphism[3] = 1
 
haagerup6Cat4Piv1PivotalIsomorphism[4] = 1
 
haagerup6Cat4Piv1PivotalIsomorphism[5] = 1
balancedCategories[haagerup6Cat5] ^= {}
 
braidedCategories[haagerup6Cat5] ^= {}
 
coeval[haagerup6Cat5] ^= 1/sixJFunction[haagerup6Cat5][#1, 
      dual[ring[haagerup6Cat5]][#1], #1, #1, 0, 0] & 
 
eval[haagerup6Cat5] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haagerup6Cat5] ^= haagerup6Cat5FMatrixFunction
 
fusionCategory[haagerup6Cat5] ^= haagerup6Cat5
 
haagerup6Cat5 /: modularCategory[haagerup6Cat5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[haagerup6Cat5] ^= {haagerup6Cat5Piv1}
 
haagerup6Cat5 /: pivotalCategory[haagerup6Cat5, 1] = haagerup6Cat5Piv1
 
haagerup6Cat5 /: pivotalCategory[haagerup6Cat5, {1, (-1 + I*Sqrt[3])/2, 
      (-1 - I*Sqrt[3])/2, 1, 1, 1}] = haagerup6Cat5Piv1
 
ring[haagerup6Cat5] ^= haagerup6
 
haagerup6Cat5 /: sphericalCategory[haagerup6Cat5, 1] = haagerup6Cat5Piv1
 
fusionCategoryIndex[haagerup6][haagerup6Cat5] ^= 5
fMatrixFunction[haagerup6Cat5FMatrixFunction] ^= haagerup6Cat5FMatrixFunction
 
fusionCategory[haagerup6Cat5FMatrixFunction] ^= haagerup6Cat5
 
ring[haagerup6Cat5FMatrixFunction] ^= haagerup6
 
haagerup6Cat5FMatrixFunction[1, 1, 1, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 1, 2, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 1, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 1, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 2, 1, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 2, 2, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 2, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 2, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 3, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[1, 3, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 3, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 3, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 3, 4, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[1, 3, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 3, 5, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[1, 3, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[1, 3, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[1, 4, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[1, 4, 2, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[1, 4, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 4, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 4, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 4, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 4, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 4, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haagerup6Cat5FMatrixFunction[1, 4, 5, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haagerup6Cat5FMatrixFunction[1, 4, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[1, 5, 1, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[1, 5, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 5, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 5, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 5, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[1, 5, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 1, 1, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 1, 2, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 1, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 2, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 3, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[2, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 3, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 3, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 3, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 3, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 3, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 3, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 3, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 3, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 3, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 4, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 4, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[2, 4, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 4, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 4, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[2, 4, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 4, 5, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[2, 4, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[2, 4, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[2, 5, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[2, 5, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[2, 5, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 5, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 5, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 5, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haagerup6Cat5FMatrixFunction[2, 5, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haagerup6Cat5FMatrixFunction[2, 5, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[2, 5, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[3, 1, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 1, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 1, 3, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[3, 1, 3, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[3, 1, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[3, 1, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[3, 1, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 1, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 2, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 2, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[3, 2, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[3, 2, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[3, 2, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[3, 3, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 3, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 3, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 3, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 3, 3, 3] = 
   {{(-3 + Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), -1, (1 + I*Sqrt[3])/2}, 
    {(-3 + Sqrt[13])/2, 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 3, 3, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 3, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat5FMatrixFunction[3, 3, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 3, 4, 4] = 
   {{(-3 + Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), (1 + I*Sqrt[3])/2, 
     (I/2)*(I + Sqrt[3])}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {(-3 + Sqrt[13])/2, 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}}
 
haagerup6Cat5FMatrixFunction[3, 3, 4, 5] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat5FMatrixFunction[3, 3, 5, 4] = 
   {{(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 3, 5, 5] = 
   {{(-3 + Sqrt[13])/2, 1, -1, (1 + I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 4, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 4, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[3, 4, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 4, 3, 4] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat5FMatrixFunction[3, 4, 3, 5] = 
   {{(-3 + Sqrt[13])/2, -1, 1, (1 - I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 4, 4, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], -1, 1, 
     (1 - I*Sqrt[3])/2}, {(-3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 
      0]}, {(3 - Sqrt[13])/2, 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0}}
 
haagerup6Cat5FMatrixFunction[3, 4, 4, 4] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 4, 5, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 4, 5, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], -1, 1, 1}, 
    {(3 - Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 
      0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 1, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(-3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 5, 1, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 5, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 5, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 5, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 5, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[3, 5, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[3, 5, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat5FMatrixFunction[3, 5, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], (1 + I*Sqrt[3])/2, 
     (-I/2)*(-I + Sqrt[3]), -1}, {(3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, {(-3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 5, 3, 5] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 5, 4, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[3, 5, 4, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 6, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 5, 4, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 5, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], (1 + I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}}
 
haagerup6Cat5FMatrixFunction[3, 5, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[3, 5, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], (1 + I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, {(-3 + Sqrt[13])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 
      0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 
        3*#1^7 + #1^8 & , 8, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 5, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat5FMatrixFunction[3, 5, 5, 5] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 1, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 1, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 1, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 1, 3, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[4, 1, 4, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[4, 1, 4, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[4, 1, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[4, 1, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 1, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 1, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 1, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 2, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 2, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haagerup6Cat5FMatrixFunction[4, 2, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 2, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 2, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[4, 2, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 2, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 2, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[4, 3, 1, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 3, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[4, 3, 2, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 3, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haagerup6Cat5FMatrixFunction[4, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 3, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], -1, 1, 
     (1 - I*Sqrt[3])/2}, {(-3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}}
 
haagerup6Cat5FMatrixFunction[4, 3, 3, 5] = 
   {{(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 3, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat5FMatrixFunction[4, 3, 4, 4] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 3, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], (1 - I*Sqrt[3])/2, 
     -1, (I/2)*(I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 3, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 3, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 3, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], (1 + I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 3, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 3, 5, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 4, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 4, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[4, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 4, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 4, 3, 3] = 
   {{(-3 + Sqrt[13])/2, 1, (1 - I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, 
    {(3 - Sqrt[13])/2, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {(-3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0}}
 
haagerup6Cat5FMatrixFunction[4, 4, 3, 4] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 4, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haagerup6Cat5FMatrixFunction[4, 4, 4, 3] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 4, 4, 4] = {{(-3 + Sqrt[13])/2, 1, -1, -1}, 
    {(-3 + Sqrt[13])/2, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {(3 - Sqrt[13])/2, 0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat5FMatrixFunction[4, 4, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[4, 4, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 4, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 
        2*#1^5 + 6*#1^6 + 2*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat5FMatrixFunction[4, 4, 5, 5] = 
   {{(-3 + Sqrt[13])/2, (I/2)*(I + Sqrt[3]), (1 - I*Sqrt[3])/2, 
     (I/2)*(I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 
      0], 0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {(3 - Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 5, 1, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 5, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 5, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 5, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[4, 5, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[4, 5, 3, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[4, 5, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[4, 5, 3, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 5, 3, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], (1 - I*Sqrt[3])/2, 
     -1, (I/2)*(I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 2, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}}
 
haagerup6Cat5FMatrixFunction[4, 5, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haagerup6Cat5FMatrixFunction[4, 5, 4, 3] = 
   {{(3 - Sqrt[13])/2, (1 - I*Sqrt[3])/2, -1, (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 5, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat5FMatrixFunction[4, 5, 4, 5] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 5, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[4, 5, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[4, 5, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 5, 5, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], (1 - I*Sqrt[3])/2, 
     -1, -1}, {(-3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     0}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat5FMatrixFunction[4, 5, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 1, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 1, 3, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[5, 1, 3, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[5, 1, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 1, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haagerup6Cat5FMatrixFunction[5, 1, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[5, 2, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 2, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 2, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 2, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 2, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haagerup6Cat5FMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haagerup6Cat5FMatrixFunction[5, 2, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[5, 2, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 2, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haagerup6Cat5FMatrixFunction[5, 3, 1, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 3, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[5, 3, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[5, 3, 2, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 3, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haagerup6Cat5FMatrixFunction[5, 3, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 3, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat5FMatrixFunction[5, 3, 3, 4] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 3, 3, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], (1 + I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 3, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 3, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 3, 4, 3] = 
   {{(-3 + Sqrt[13])/2, -1, (1 + I*Sqrt[3])/2, 1}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 3, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 3, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}}
 
haagerup6Cat5FMatrixFunction[5, 3, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 3, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 3, 5, 4] = 
   {{(3 - Sqrt[13])/2, (1 + I*Sqrt[3])/2, (1 - I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, {(-3 + Sqrt[13])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}}
 
haagerup6Cat5FMatrixFunction[5, 3, 5, 5] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 6, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 4, 1, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 4, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[5, 4, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[5, 4, 2, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 4, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[5, 4, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haagerup6Cat5FMatrixFunction[5, 4, 3, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 4, 3, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], (1 - I*Sqrt[3])/2, 
     (I/2)*(I + Sqrt[3]), (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat5FMatrixFunction[5, 4, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 4, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 4, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 4, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat5FMatrixFunction[5, 4, 4, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], (1 - I*Sqrt[3])/2, 
     -1, -1}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0}, {(-3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 4, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 4, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 4, 5, 3] = 
   {{(3 - Sqrt[13])/2, (1 + I*Sqrt[3])/2, (1 - I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, {(-3 + Sqrt[13])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}}
 
haagerup6Cat5FMatrixFunction[5, 4, 5, 4] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 5, 1, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haagerup6Cat5FMatrixFunction[5, 5, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[5, 5, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 5, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[5, 5, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haagerup6Cat5FMatrixFunction[5, 5, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 5, 3, 3] = 
   {{(-3 + Sqrt[13])/2, (I/2)*(I + Sqrt[3]), -1, (1 - I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 5, 3, 5] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 5, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[5, 5, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 5, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 5, 4, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     (-I/2)*(-I + Sqrt[3]), -1, (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 5, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 5, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 5, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5FMatrixFunction[5, 5, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5FMatrixFunction[5, 5, 5, 3] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 5, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat5FMatrixFunction[5, 5, 5, 5] = 
   {{(-3 + Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), -1, (1 - I*Sqrt[3])/2}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {(3 - Sqrt[13])/2, 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0}}
 
haagerup6Cat5FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat5], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haagerup6Cat5FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat5], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[haagerup6Cat5Piv1] ^= {}
 
fusionCategory[haagerup6Cat5Piv1] ^= haagerup6Cat5
 
haagerup6Cat5Piv1 /: modularCategory[haagerup6Cat5Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[haagerup6Cat5Piv1] ^= haagerup6Cat5Piv1
 
pivotalIsomorphism[haagerup6Cat5Piv1] ^= haagerup6Cat5Piv1PivotalIsomorphism
 
ring[haagerup6Cat5Piv1] ^= haagerup6
 
sphericalCategory[haagerup6Cat5Piv1] ^= haagerup6Cat5Piv1
 
(pivotalCategoryIndex[fusionCategory[haagerup6Cat5]][pivotalCategory[#1]] & )[
    haagerup6Cat5Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haagerup6Cat5]][
      sphericalCategory[#1]] & )[haagerup6Cat5Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haagerup6Cat5Piv1PivotalIsomorphism] ^= haagerup6Cat5
 
pivotalCategory[haagerup6Cat5Piv1PivotalIsomorphism] ^= haagerup6Cat5Piv1
 
pivotalIsomorphism[haagerup6Cat5Piv1PivotalIsomorphism] ^= 
   haagerup6Cat5Piv1PivotalIsomorphism
 
haagerup6Cat5Piv1PivotalIsomorphism[0] = 1
 
haagerup6Cat5Piv1PivotalIsomorphism[1] = (-1 + I*Sqrt[3])/2
 
haagerup6Cat5Piv1PivotalIsomorphism[2] = (-1 - I*Sqrt[3])/2
 
haagerup6Cat5Piv1PivotalIsomorphism[3] = 1
 
haagerup6Cat5Piv1PivotalIsomorphism[4] = 1
 
haagerup6Cat5Piv1PivotalIsomorphism[5] = 1
coeval[haagerup6Cat5Unitary] ^= 
   1/sixJFunction[haagerup6Cat5Unitary][#1, dual[ring[haagerup6Cat5Unitary]][
       #1], #1, #1, 0, 0] & 
 
eval[haagerup6Cat5Unitary] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haagerup6Cat5Unitary] ^= haagerup6Cat5UnitaryFMatrixFunction
 
fusionCategory[haagerup6Cat5Unitary] ^= haagerup6Cat5Unitary
 
pivotalCategories[haagerup6Cat5Unitary] ^= {haagerup6Cat5UnitaryPiv1}
 
haagerup6Cat5Unitary /: pivotalCategory[haagerup6Cat5Unitary, 1] = 
    haagerup6Cat5UnitaryPiv1
 
haagerup6Cat5Unitary /: pivotalCategory[haagerup6Cat5Unitary, 
     {1, (-1 + I*Sqrt[3])/2, (-1 - I*Sqrt[3])/2, 1, 1, 1}] = 
    haagerup6Cat5UnitaryPiv1
 
ring[haagerup6Cat5Unitary] ^= haagerup6
 
haagerup6Cat5Unitary /: sphericalCategory[haagerup6Cat5Unitary, 1] = 
    haagerup6Cat5UnitaryPiv1
 
fusionCategoryIndex[haagerup6][haagerup6Cat5Unitary] ^= 11
fMatrixFunction[haagerup6Cat5UnitaryFMatrixFunction] ^= 
   haagerup6Cat5UnitaryFMatrixFunction
 
fusionCategory[haagerup6Cat5UnitaryFMatrixFunction] ^= haagerup6Cat5Unitary
 
ring[haagerup6Cat5UnitaryFMatrixFunction] ^= haagerup6
 
haagerup6Cat5UnitaryFMatrixFunction[1, 1, 1, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 1, 2, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 1, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 1, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 2, 1, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 2, 2, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 2, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 2, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 3, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 3, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 3, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 3, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 3, 4, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 3, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 3, 5, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 3, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 3, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 4, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 4, 2, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 4, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 4, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 4, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 4, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 4, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 4, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 4, 5, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 4, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 5, 1, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 5, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 5, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 5, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 5, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[1, 5, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 1, 1, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 1, 2, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 1, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 2, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 3, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 3, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 3, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 3, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 3, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 3, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 3, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 3, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 3, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 3, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 4, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 4, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 4, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 4, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 4, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 4, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 4, 5, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 4, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 4, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 5, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 5, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 5, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 5, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 5, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 5, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 5, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 5, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[2, 5, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 1, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 1, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 1, 3, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 1, 3, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 1, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 1, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 1, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 1, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 2, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 2, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 2, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 2, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 2, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 3, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 3, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 3, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 3, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 3, 3, 3] = 
   {{(-3 + Sqrt[13])/2, Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 
      1, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 1, 0]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     0}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 3, 3, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 3, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 3, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 3, 4, 4] = 
   {{(-3 + Sqrt[13])/2, Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 
      0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 3, 4, 5] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 3, 5, 4] = 
   {{(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 3, 5, 5] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 
      1, 0], Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 4, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 4, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 4, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 4, 3, 4] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 4, 3, 5] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 
      5, 0]}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 4, 4, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], Sqrt[(-3 + Sqrt[13])/2], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 4, 4, 4] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 4, 5, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 4, 5, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], Sqrt[(-3 + Sqrt[13])/2], 
     Sqrt[(-3 + Sqrt[13])/2]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 5, 1, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 5, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 5, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 5, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 5, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 5, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 5, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 5, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, {Sqrt[(-3 + Sqrt[13])/2], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 5, 3, 5] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {(-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 5, 4, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 5, 4, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 6, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 5, 4, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 5, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 5, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 5, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 
      0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 5, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[3, 5, 5, 5] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 1, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 1, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 1, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 1, 3, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 1, 4, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 1, 4, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 1, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 1, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 1, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 1, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 1, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 2, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 2, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 2, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 2, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 2, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 2, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 2, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 2, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 3, 1, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 3, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 3, 2, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 3, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 3, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], Sqrt[(-3 + Sqrt[13])/2], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 
      0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 
      0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 3, 3, 5] = 
   {{(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 3, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 3, 4, 4] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 3, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 3, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 3, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 3, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 3, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 3, 5, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 4, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 4, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 4, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 4, 3, 3] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 4, 3, 4] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 4, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 4, 4, 3] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 4, 4, 4] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 
      1, 0], Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 4, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 4, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 4, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 
        2*#1^5 + 6*#1^6 + 2*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 4, 5, 5] = 
   {{(-3 + Sqrt[13])/2, Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 1, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 3, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 3, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 3, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 4, 3] = 
   {{(3 - Sqrt[13])/2, Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 4, 5] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 5, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 
      0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 
        3*#1^7 + #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 
      1, 0], 0}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[4, 5, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {(-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 1, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 1, 3, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 1, 3, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 1, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 1, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 1, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 2, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 2, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 2, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 2, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 2, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 2, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 2, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 2, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 1, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 2, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 3, 4] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 3, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 4, 3] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Sqrt[(-3 + Sqrt[13])/2]}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 
      6, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 
      0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 5, 4] = 
   {{(3 - Sqrt[13])/2, Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 3, 5, 5] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 6, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 1, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 2, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 3, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 3, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 4, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0}, {Sqrt[(-3 + Sqrt[13])/2], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 5, 3] = 
   {{(3 - Sqrt[13])/2, Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 5, 4] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {(-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 1, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 3, 3] = 
   {{(-3 + Sqrt[13])/2, Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 3, 5] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 4, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0]}, {(-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 5, 3] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat5UnitaryFMatrixFunction[5, 5, 5, 5] = 
   {{(-3 + Sqrt[13])/2, Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 
      0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0}}
 
haagerup6Cat5UnitaryFMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat5], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haagerup6Cat5UnitaryFMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat5], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
fusionCategory[haagerup6Cat5UnitaryPiv1] ^= haagerup6Cat5Unitary
 
pivotalCategory[haagerup6Cat5UnitaryPiv1] ^= haagerup6Cat5UnitaryPiv1
 
pivotalIsomorphism[haagerup6Cat5UnitaryPiv1] ^= 
   haagerup6Cat5UnitaryPiv1PivotalIsomorphism
 
ring[haagerup6Cat5UnitaryPiv1] ^= haagerup6
 
sphericalCategory[haagerup6Cat5UnitaryPiv1] ^= haagerup6Cat5UnitaryPiv1
 
(pivotalCategoryIndex[fusionCategory[haagerup6Cat5Unitary]][
      pivotalCategory[#1]] & )[haagerup6Cat5UnitaryPiv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haagerup6Cat5Unitary]][
      sphericalCategory[#1]] & )[haagerup6Cat5UnitaryPiv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haagerup6Cat5UnitaryPiv1PivotalIsomorphism] ^= 
   haagerup6Cat5Unitary
 
pivotalCategory[haagerup6Cat5UnitaryPiv1PivotalIsomorphism] ^= 
   haagerup6Cat5UnitaryPiv1
 
pivotalIsomorphism[haagerup6Cat5UnitaryPiv1PivotalIsomorphism] ^= 
   haagerup6Cat5UnitaryPiv1PivotalIsomorphism
 
haagerup6Cat5UnitaryPiv1PivotalIsomorphism[0] = 1
 
haagerup6Cat5UnitaryPiv1PivotalIsomorphism[1] = (-1 + I*Sqrt[3])/2
 
haagerup6Cat5UnitaryPiv1PivotalIsomorphism[2] = (-1 - I*Sqrt[3])/2
 
haagerup6Cat5UnitaryPiv1PivotalIsomorphism[3] = 1
 
haagerup6Cat5UnitaryPiv1PivotalIsomorphism[4] = 1
 
haagerup6Cat5UnitaryPiv1PivotalIsomorphism[5] = 1
balancedCategories[haagerup6Cat6] ^= {}
 
braidedCategories[haagerup6Cat6] ^= {}
 
coeval[haagerup6Cat6] ^= 1/sixJFunction[haagerup6Cat6][#1, 
      dual[ring[haagerup6Cat6]][#1], #1, #1, 0, 0] & 
 
eval[haagerup6Cat6] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haagerup6Cat6] ^= haagerup6Cat6FMatrixFunction
 
fusionCategory[haagerup6Cat6] ^= haagerup6Cat6
 
haagerup6Cat6 /: modularCategory[haagerup6Cat6, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[haagerup6Cat6] ^= {haagerup6Cat6Piv1}
 
haagerup6Cat6 /: pivotalCategory[haagerup6Cat6, 1] = haagerup6Cat6Piv1
 
haagerup6Cat6 /: pivotalCategory[haagerup6Cat6, {1, (-1 + I*Sqrt[3])/2, 
      (-1 - I*Sqrt[3])/2, 1, 1, 1}] = haagerup6Cat6Piv1
 
ring[haagerup6Cat6] ^= haagerup6
 
haagerup6Cat6 /: sphericalCategory[haagerup6Cat6, 1] = haagerup6Cat6Piv1
 
fusionCategoryIndex[haagerup6][haagerup6Cat6] ^= 6
fMatrixFunction[haagerup6Cat6FMatrixFunction] ^= haagerup6Cat6FMatrixFunction
 
fusionCategory[haagerup6Cat6FMatrixFunction] ^= haagerup6Cat6
 
ring[haagerup6Cat6FMatrixFunction] ^= haagerup6
 
haagerup6Cat6FMatrixFunction[1, 1, 1, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 1, 2, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 1, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 1, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 2, 1, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 2, 2, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 2, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 2, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 3, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[1, 3, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 3, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 3, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 3, 4, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[1, 3, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 3, 5, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[1, 3, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[1, 3, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[1, 4, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[1, 4, 2, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[1, 4, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 4, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 4, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 4, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 4, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 4, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haagerup6Cat6FMatrixFunction[1, 4, 5, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haagerup6Cat6FMatrixFunction[1, 4, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[1, 5, 1, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[1, 5, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 5, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 5, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 5, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[1, 5, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 1, 1, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 1, 2, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 1, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 2, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 3, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[2, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 3, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 3, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 3, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 3, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 3, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 3, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 3, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 3, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 3, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 4, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 4, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[2, 4, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 4, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 4, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[2, 4, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 4, 5, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[2, 4, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[2, 4, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[2, 5, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[2, 5, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[2, 5, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 5, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 5, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 5, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haagerup6Cat6FMatrixFunction[2, 5, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haagerup6Cat6FMatrixFunction[2, 5, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[2, 5, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[3, 1, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 1, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 1, 3, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[3, 1, 3, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[3, 1, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[3, 1, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[3, 1, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 1, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 2, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 2, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[3, 2, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[3, 2, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[3, 2, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[3, 3, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 3, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 3, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 3, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 3, 3, 3] = 
   {{(-3 - Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), -1, (1 + I*Sqrt[3])/2}, 
    {(-3 - Sqrt[13])/2, 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 3, 3, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}, 
    {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 3, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat6FMatrixFunction[3, 3, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 3, 4, 4] = 
   {{(-3 - Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), (1 + I*Sqrt[3])/2, 
     (I/2)*(I + Sqrt[3])}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}, 
    {(-3 - Sqrt[13])/2, 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 0}}
 
haagerup6Cat6FMatrixFunction[3, 3, 4, 5] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}, {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat6FMatrixFunction[3, 3, 5, 4] = 
   {{(-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], (-1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 3, 5, 5] = 
   {{(-3 - Sqrt[13])/2, 1, -1, (1 + I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 4, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 4, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[3, 4, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 4, 3, 4] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}, 
    {(-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat6FMatrixFunction[3, 4, 3, 5] = 
   {{(-3 - Sqrt[13])/2, -1, 1, (1 - I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 4, 4, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], -1, 1, 
     (1 - I*Sqrt[3])/2}, {(-3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 
      0]}, {(3 + Sqrt[13])/2, 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0}}
 
haagerup6Cat6FMatrixFunction[3, 4, 4, 4] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 4, 5, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 4, 5, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], -1, 1, 1}, 
    {(3 + Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 
      0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 8, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {(-3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 5, 1, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 5, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 5, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 5, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 5, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[3, 5, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[3, 5, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}, {(-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat6FMatrixFunction[3, 5, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], (1 + I*Sqrt[3])/2, 
     (-I/2)*(-I + Sqrt[3]), -1}, {(3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 0}, {(-3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 5, 3, 5] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], (-1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {(-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 5, 4, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[3, 5, 4, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 5, 4, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}, {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 5, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], (1 + I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 0}}
 
haagerup6Cat6FMatrixFunction[3, 5, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[3, 5, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], (1 + I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, {(-3 - Sqrt[13])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 
      0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 
        3*#1^7 + #1^8 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 5, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat6FMatrixFunction[3, 5, 5, 5] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 1, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 1, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 1, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 1, 3, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[4, 1, 4, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[4, 1, 4, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[4, 1, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[4, 1, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 1, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 1, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 1, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 2, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 2, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haagerup6Cat6FMatrixFunction[4, 2, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 2, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 2, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[4, 2, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 2, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 2, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[4, 3, 1, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 3, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[4, 3, 2, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 3, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haagerup6Cat6FMatrixFunction[4, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 3, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], -1, 1, 
     (1 - I*Sqrt[3])/2}, {(-3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 0}}
 
haagerup6Cat6FMatrixFunction[4, 3, 3, 5] = 
   {{(-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 3, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}, {(-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat6FMatrixFunction[4, 3, 4, 4] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 3, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], (1 - I*Sqrt[3])/2, 
     -1, (I/2)*(I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      1, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 3, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 3, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 3, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], (1 + I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 3, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 3, 5, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 4, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 4, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[4, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 4, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 4, 3, 3] = 
   {{(-3 - Sqrt[13])/2, 1, (1 - I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, 
    {(3 + Sqrt[13])/2, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}, {(-3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0}}
 
haagerup6Cat6FMatrixFunction[4, 4, 3, 4] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 4, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haagerup6Cat6FMatrixFunction[4, 4, 4, 3] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 4, 4, 4] = {{(-3 - Sqrt[13])/2, 1, -1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}, 
    {(3 + Sqrt[13])/2, 0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat6FMatrixFunction[4, 4, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[4, 4, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 4, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 
        2*#1^5 + 6*#1^6 + 2*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat6FMatrixFunction[4, 4, 5, 5] = 
   {{(-3 - Sqrt[13])/2, (I/2)*(I + Sqrt[3]), (1 - I*Sqrt[3])/2, 
     (I/2)*(I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 
      0], 0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {(3 + Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 5, 1, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 5, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 5, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 5, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[4, 5, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[4, 5, 3, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[4, 5, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[4, 5, 3, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}, {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 5, 3, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], (1 - I*Sqrt[3])/2, 
     -1, (I/2)*(I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      1, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 3, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {(3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 0}}
 
haagerup6Cat6FMatrixFunction[4, 5, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haagerup6Cat6FMatrixFunction[4, 5, 4, 3] = 
   {{(3 + Sqrt[13])/2, (1 - I*Sqrt[3])/2, -1, (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 5, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {(-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat6FMatrixFunction[4, 5, 4, 5] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 5, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[4, 5, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[4, 5, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 5, 5, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], (1 - I*Sqrt[3])/2, 
     -1, -1}, {(-3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     0}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}}
 
haagerup6Cat6FMatrixFunction[4, 5, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 1, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 1, 3, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[5, 1, 3, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[5, 1, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 1, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haagerup6Cat6FMatrixFunction[5, 1, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[5, 2, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 2, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 2, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 2, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 2, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haagerup6Cat6FMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haagerup6Cat6FMatrixFunction[5, 2, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[5, 2, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 2, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haagerup6Cat6FMatrixFunction[5, 3, 1, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 3, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[5, 3, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[5, 3, 2, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 3, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haagerup6Cat6FMatrixFunction[5, 3, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 3, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat6FMatrixFunction[5, 3, 3, 4] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 3, 3, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], (1 + I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 3, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 3, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 3, 4, 3] = 
   {{(-3 - Sqrt[13])/2, -1, (1 + I*Sqrt[3])/2, 1}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 3, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 3, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat6FMatrixFunction[5, 3, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 3, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {(-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 3, 5, 4] = 
   {{(3 + Sqrt[13])/2, (1 + I*Sqrt[3])/2, (1 - I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, {(-3 - Sqrt[13])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 0}}
 
haagerup6Cat6FMatrixFunction[5, 3, 5, 5] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 4, 1, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 4, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[5, 4, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[5, 4, 2, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 4, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[5, 4, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haagerup6Cat6FMatrixFunction[5, 4, 3, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], (-1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 4, 3, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], (1 - I*Sqrt[3])/2, 
     (I/2)*(I + Sqrt[3]), (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat6FMatrixFunction[5, 4, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 4, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 4, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 4, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}, {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat6FMatrixFunction[5, 4, 4, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], (1 - I*Sqrt[3])/2, 
     -1, -1}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0}, {(-3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 4, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 4, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 4, 5, 3] = 
   {{(3 + Sqrt[13])/2, (1 + I*Sqrt[3])/2, (1 - I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, {(-3 - Sqrt[13])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 0}}
 
haagerup6Cat6FMatrixFunction[5, 4, 5, 4] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 5, 1, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haagerup6Cat6FMatrixFunction[5, 5, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[5, 5, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 5, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[5, 5, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haagerup6Cat6FMatrixFunction[5, 5, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 5, 3, 3] = 
   {{(-3 - Sqrt[13])/2, (I/2)*(I + Sqrt[3]), -1, (1 - I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 5, 3, 5] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 5, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[5, 5, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 5, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 5, 4, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-I/2)*(-I + Sqrt[3]), -1, (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 0}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 5, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}, {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 5, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 5, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat6FMatrixFunction[5, 5, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat6FMatrixFunction[5, 5, 5, 3] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 5, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat6FMatrixFunction[5, 5, 5, 5] = 
   {{(-3 - Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), -1, (1 - I*Sqrt[3])/2}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}, {(3 + Sqrt[13])/2, 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0}}
 
haagerup6Cat6FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat6], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haagerup6Cat6FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat6], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[haagerup6Cat6Piv1] ^= {}
 
fusionCategory[haagerup6Cat6Piv1] ^= haagerup6Cat6
 
haagerup6Cat6Piv1 /: modularCategory[haagerup6Cat6Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[haagerup6Cat6Piv1] ^= haagerup6Cat6Piv1
 
pivotalIsomorphism[haagerup6Cat6Piv1] ^= haagerup6Cat6Piv1PivotalIsomorphism
 
ring[haagerup6Cat6Piv1] ^= haagerup6
 
sphericalCategory[haagerup6Cat6Piv1] ^= haagerup6Cat6Piv1
 
(pivotalCategoryIndex[fusionCategory[haagerup6Cat6]][pivotalCategory[#1]] & )[
    haagerup6Cat6Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haagerup6Cat6]][
      sphericalCategory[#1]] & )[haagerup6Cat6Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haagerup6Cat6Piv1PivotalIsomorphism] ^= haagerup6Cat6
 
pivotalCategory[haagerup6Cat6Piv1PivotalIsomorphism] ^= haagerup6Cat6Piv1
 
pivotalIsomorphism[haagerup6Cat6Piv1PivotalIsomorphism] ^= 
   haagerup6Cat6Piv1PivotalIsomorphism
 
haagerup6Cat6Piv1PivotalIsomorphism[0] = 1
 
haagerup6Cat6Piv1PivotalIsomorphism[1] = (-1 + I*Sqrt[3])/2
 
haagerup6Cat6Piv1PivotalIsomorphism[2] = (-1 - I*Sqrt[3])/2
 
haagerup6Cat6Piv1PivotalIsomorphism[3] = 1
 
haagerup6Cat6Piv1PivotalIsomorphism[4] = 1
 
haagerup6Cat6Piv1PivotalIsomorphism[5] = 1
balancedCategories[haagerup6Cat7] ^= {}
 
braidedCategories[haagerup6Cat7] ^= {}
 
coeval[haagerup6Cat7] ^= 1/sixJFunction[haagerup6Cat7][#1, 
      dual[ring[haagerup6Cat7]][#1], #1, #1, 0, 0] & 
 
eval[haagerup6Cat7] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haagerup6Cat7] ^= haagerup6Cat7FMatrixFunction
 
fusionCategory[haagerup6Cat7] ^= haagerup6Cat7
 
haagerup6Cat7 /: modularCategory[haagerup6Cat7, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[haagerup6Cat7] ^= {haagerup6Cat7Piv1}
 
haagerup6Cat7 /: pivotalCategory[haagerup6Cat7, 1] = haagerup6Cat7Piv1
 
haagerup6Cat7 /: pivotalCategory[haagerup6Cat7, {1, (-1 - I*Sqrt[3])/2, 
      (-1 + I*Sqrt[3])/2, 1, 1, 1}] = haagerup6Cat7Piv1
 
ring[haagerup6Cat7] ^= haagerup6
 
haagerup6Cat7 /: sphericalCategory[haagerup6Cat7, 1] = haagerup6Cat7Piv1
 
fusionCategoryIndex[haagerup6][haagerup6Cat7] ^= 7
fMatrixFunction[haagerup6Cat7FMatrixFunction] ^= haagerup6Cat7FMatrixFunction
 
fusionCategory[haagerup6Cat7FMatrixFunction] ^= haagerup6Cat7
 
ring[haagerup6Cat7FMatrixFunction] ^= haagerup6
 
haagerup6Cat7FMatrixFunction[1, 1, 1, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 1, 2, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 1, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 1, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 2, 1, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 2, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 2, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 2, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 3, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[1, 3, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 3, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 3, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 3, 4, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[1, 3, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 3, 5, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[1, 3, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[1, 3, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[1, 4, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[1, 4, 2, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[1, 4, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 4, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 4, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 4, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 4, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 4, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haagerup6Cat7FMatrixFunction[1, 4, 5, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haagerup6Cat7FMatrixFunction[1, 4, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[1, 5, 1, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[1, 5, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 5, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 5, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 5, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[1, 5, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 1, 1, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 1, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 1, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 2, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 3, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[2, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 3, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 3, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 3, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 3, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 3, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 3, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 3, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 3, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 3, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 4, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 4, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[2, 4, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 4, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 4, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 4, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[2, 4, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 4, 5, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[2, 4, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[2, 4, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[2, 5, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[2, 5, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[2, 5, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 5, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 5, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 5, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haagerup6Cat7FMatrixFunction[2, 5, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haagerup6Cat7FMatrixFunction[2, 5, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[2, 5, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[3, 1, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 1, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 1, 3, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[3, 1, 3, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[3, 1, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[3, 1, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[3, 1, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 1, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 2, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 2, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[3, 2, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[3, 2, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[3, 2, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[3, 3, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 3, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 3, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 3, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 3, 3, 3] = 
   {{(-3 + Sqrt[13])/2, (I/2)*(I + Sqrt[3]), -1, (1 - I*Sqrt[3])/2}, 
    {(-3 + Sqrt[13])/2, 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 3, 3, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 3, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat7FMatrixFunction[3, 3, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 3, 4, 4] = 
   {{(-3 + Sqrt[13])/2, (I/2)*(I + Sqrt[3]), (1 - I*Sqrt[3])/2, 
     (-I/2)*(-I + Sqrt[3])}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {(-3 + Sqrt[13])/2, 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}}
 
haagerup6Cat7FMatrixFunction[3, 3, 4, 5] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat7FMatrixFunction[3, 3, 5, 4] = 
   {{(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 3, 5, 5] = 
   {{(-3 + Sqrt[13])/2, 1, -1, (1 - I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 4, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 4, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[3, 4, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 4, 3, 4] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat7FMatrixFunction[3, 4, 3, 5] = 
   {{(-3 + Sqrt[13])/2, -1, 1, (1 + I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 4, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 4, 4, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], -1, 1, 
     (1 + I*Sqrt[3])/2}, {(-3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 
      0]}, {(3 - Sqrt[13])/2, 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0}}
 
haagerup6Cat7FMatrixFunction[3, 4, 4, 4] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 4, 5, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 4, 5, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], -1, 1, 1}, 
    {(3 - Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 
      0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 2, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(-3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 5, 1, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 5, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 5, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 5, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 5, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[3, 5, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[3, 5, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat7FMatrixFunction[3, 5, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], (1 - I*Sqrt[3])/2, 
     (I/2)*(I + Sqrt[3]), -1}, {(3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, {(-3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 5, 3, 5] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 5, 4, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[3, 5, 4, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 5, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 5, 4, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 5, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], (1 - I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}}
 
haagerup6Cat7FMatrixFunction[3, 5, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[3, 5, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], (1 - I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, {(-3 + Sqrt[13])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 
      0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 
        3*#1^7 + #1^8 & , 7, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 5, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat7FMatrixFunction[3, 5, 5, 5] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 1, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 1, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 1, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 1, 3, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[4, 1, 4, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[4, 1, 4, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[4, 1, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[4, 1, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 1, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 1, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 1, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 2, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 2, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haagerup6Cat7FMatrixFunction[4, 2, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 2, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 2, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[4, 2, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 2, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 2, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[4, 3, 1, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 3, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[4, 3, 2, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 3, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haagerup6Cat7FMatrixFunction[4, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 3, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], -1, 1, 
     (1 + I*Sqrt[3])/2}, {(-3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}}
 
haagerup6Cat7FMatrixFunction[4, 3, 3, 5] = 
   {{(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 3, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat7FMatrixFunction[4, 3, 4, 4] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 3, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], (1 + I*Sqrt[3])/2, 
     -1, (-I/2)*(-I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 3, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 3, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 3, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], (1 - I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 3, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 3, 5, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 4, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 4, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[4, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 4, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 4, 3, 3] = 
   {{(-3 + Sqrt[13])/2, 1, (1 + I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, 
    {(3 - Sqrt[13])/2, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {(-3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0}}
 
haagerup6Cat7FMatrixFunction[4, 4, 3, 4] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 4, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haagerup6Cat7FMatrixFunction[4, 4, 4, 3] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 4, 4, 4] = {{(-3 + Sqrt[13])/2, 1, -1, -1}, 
    {(-3 + Sqrt[13])/2, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {(3 - Sqrt[13])/2, 0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat7FMatrixFunction[4, 4, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[4, 4, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 4, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 
        2*#1^5 + 6*#1^6 + 2*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat7FMatrixFunction[4, 4, 5, 5] = 
   {{(-3 + Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), (1 + I*Sqrt[3])/2, 
     (-I/2)*(-I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 
      0], 0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {(3 - Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 5, 1, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 5, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 5, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 5, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[4, 5, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[4, 5, 3, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[4, 5, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[4, 5, 3, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 5, 3, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], (1 + I*Sqrt[3])/2, 
     -1, (-I/2)*(-I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 1, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}}
 
haagerup6Cat7FMatrixFunction[4, 5, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haagerup6Cat7FMatrixFunction[4, 5, 4, 3] = 
   {{(3 - Sqrt[13])/2, (1 + I*Sqrt[3])/2, -1, (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 5, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat7FMatrixFunction[4, 5, 4, 5] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 5, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[4, 5, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[4, 5, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 5, 5, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], (1 + I*Sqrt[3])/2, 
     -1, -1}, {(-3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     0}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat7FMatrixFunction[4, 5, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 1, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 1, 3, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[5, 1, 3, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[5, 1, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 1, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haagerup6Cat7FMatrixFunction[5, 1, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[5, 2, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 2, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 2, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 2, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 2, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haagerup6Cat7FMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haagerup6Cat7FMatrixFunction[5, 2, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[5, 2, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 2, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haagerup6Cat7FMatrixFunction[5, 3, 1, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 3, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[5, 3, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[5, 3, 2, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 3, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haagerup6Cat7FMatrixFunction[5, 3, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 3, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat7FMatrixFunction[5, 3, 3, 4] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 3, 3, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], (1 - I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 3, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 3, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 3, 4, 3] = 
   {{(-3 + Sqrt[13])/2, -1, (1 - I*Sqrt[3])/2, 1}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 3, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 3, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}}
 
haagerup6Cat7FMatrixFunction[5, 3, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 3, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 3, 5, 4] = 
   {{(3 - Sqrt[13])/2, (1 - I*Sqrt[3])/2, (1 + I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, {(-3 + Sqrt[13])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}}
 
haagerup6Cat7FMatrixFunction[5, 3, 5, 5] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 5, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 4, 1, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 4, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[5, 4, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[5, 4, 2, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 4, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[5, 4, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haagerup6Cat7FMatrixFunction[5, 4, 3, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 4, 3, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], (1 + I*Sqrt[3])/2, 
     (-I/2)*(-I + Sqrt[3]), (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat7FMatrixFunction[5, 4, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 4, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 4, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat7FMatrixFunction[5, 4, 4, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], (1 + I*Sqrt[3])/2, 
     -1, -1}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0}, {(-3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 4, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 4, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 4, 5, 3] = 
   {{(3 - Sqrt[13])/2, (1 - I*Sqrt[3])/2, (1 + I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, {(-3 + Sqrt[13])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}}
 
haagerup6Cat7FMatrixFunction[5, 4, 5, 4] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 5, 1, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haagerup6Cat7FMatrixFunction[5, 5, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[5, 5, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 5, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[5, 5, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haagerup6Cat7FMatrixFunction[5, 5, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 5, 3, 3] = 
   {{(-3 + Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), -1, (1 + I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 5, 3, 5] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 5, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[5, 5, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 5, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 5, 4, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], (I/2)*(I + Sqrt[3]), 
     -1, (-I/2)*(-I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      3, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 5, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 5, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 5, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7FMatrixFunction[5, 5, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7FMatrixFunction[5, 5, 5, 3] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 5, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat7FMatrixFunction[5, 5, 5, 5] = 
   {{(-3 + Sqrt[13])/2, (I/2)*(I + Sqrt[3]), -1, (1 + I*Sqrt[3])/2}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {(3 - Sqrt[13])/2, 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0}}
 
haagerup6Cat7FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat7], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haagerup6Cat7FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat7], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[haagerup6Cat7Piv1] ^= {}
 
fusionCategory[haagerup6Cat7Piv1] ^= haagerup6Cat7
 
haagerup6Cat7Piv1 /: modularCategory[haagerup6Cat7Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[haagerup6Cat7Piv1] ^= haagerup6Cat7Piv1
 
pivotalIsomorphism[haagerup6Cat7Piv1] ^= haagerup6Cat7Piv1PivotalIsomorphism
 
ring[haagerup6Cat7Piv1] ^= haagerup6
 
sphericalCategory[haagerup6Cat7Piv1] ^= haagerup6Cat7Piv1
 
(pivotalCategoryIndex[fusionCategory[haagerup6Cat7]][pivotalCategory[#1]] & )[
    haagerup6Cat7Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haagerup6Cat7]][
      sphericalCategory[#1]] & )[haagerup6Cat7Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haagerup6Cat7Piv1PivotalIsomorphism] ^= haagerup6Cat7
 
pivotalCategory[haagerup6Cat7Piv1PivotalIsomorphism] ^= haagerup6Cat7Piv1
 
pivotalIsomorphism[haagerup6Cat7Piv1PivotalIsomorphism] ^= 
   haagerup6Cat7Piv1PivotalIsomorphism
 
haagerup6Cat7Piv1PivotalIsomorphism[0] = 1
 
haagerup6Cat7Piv1PivotalIsomorphism[1] = (-1 - I*Sqrt[3])/2
 
haagerup6Cat7Piv1PivotalIsomorphism[2] = (-1 + I*Sqrt[3])/2
 
haagerup6Cat7Piv1PivotalIsomorphism[3] = 1
 
haagerup6Cat7Piv1PivotalIsomorphism[4] = 1
 
haagerup6Cat7Piv1PivotalIsomorphism[5] = 1
coeval[haagerup6Cat7Unitary] ^= 
   1/sixJFunction[haagerup6Cat7Unitary][#1, dual[ring[haagerup6Cat7Unitary]][
       #1], #1, #1, 0, 0] & 
 
eval[haagerup6Cat7Unitary] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haagerup6Cat7Unitary] ^= haagerup6Cat7UnitaryFMatrixFunction
 
fusionCategory[haagerup6Cat7Unitary] ^= haagerup6Cat7Unitary
 
pivotalCategories[haagerup6Cat7Unitary] ^= {haagerup6Cat7UnitaryPiv1}
 
haagerup6Cat7Unitary /: pivotalCategory[haagerup6Cat7Unitary, 1] = 
    haagerup6Cat7UnitaryPiv1
 
haagerup6Cat7Unitary /: pivotalCategory[haagerup6Cat7Unitary, 
     {1, (-1 - I*Sqrt[3])/2, (-1 + I*Sqrt[3])/2, 1, 1, 1}] = 
    haagerup6Cat7UnitaryPiv1
 
ring[haagerup6Cat7Unitary] ^= haagerup6
 
haagerup6Cat7Unitary /: sphericalCategory[haagerup6Cat7Unitary, 1] = 
    haagerup6Cat7UnitaryPiv1
 
fusionCategoryIndex[haagerup6][haagerup6Cat7Unitary] ^= 12
fMatrixFunction[haagerup6Cat7UnitaryFMatrixFunction] ^= 
   haagerup6Cat7UnitaryFMatrixFunction
 
fusionCategory[haagerup6Cat7UnitaryFMatrixFunction] ^= haagerup6Cat7Unitary
 
ring[haagerup6Cat7UnitaryFMatrixFunction] ^= haagerup6
 
haagerup6Cat7UnitaryFMatrixFunction[1, 1, 1, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 1, 2, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 1, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 1, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 2, 1, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 2, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 2, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 2, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 3, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 3, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 3, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 3, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 3, 4, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 3, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 3, 5, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 3, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 3, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 4, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 4, 2, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 4, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 4, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 4, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 4, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 4, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 4, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 4, 5, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 4, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 5, 1, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 5, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 5, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 5, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 5, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[1, 5, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 1, 1, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 1, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 1, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 2, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 3, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 3, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 3, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 3, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 3, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 3, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 3, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 3, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 3, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 3, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 4, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 4, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 4, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 4, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 4, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 4, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 4, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 4, 5, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 4, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 4, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 5, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 5, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 5, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 5, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 5, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 5, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 5, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 5, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[2, 5, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 1, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 1, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 1, 3, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 1, 3, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 1, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 1, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 1, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 1, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 2, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 2, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 2, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 2, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 2, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 3, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 3, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 3, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 3, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 3, 3, 3] = 
   {{(-3 + Sqrt[13])/2, Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 
      1, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 2, 0]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     0}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 3, 3, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 3, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 3, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 3, 4, 4] = 
   {{(-3 + Sqrt[13])/2, Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 
      0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 3, 4, 5] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 3, 5, 4] = 
   {{(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 3, 5, 5] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 
      1, 0], Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 4, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 4, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 4, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 4, 3, 4] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 4, 3, 5] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Sqrt[(-3 + Sqrt[13])/2], Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 
      6, 0]}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 4, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 4, 4, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], Sqrt[(-3 + Sqrt[13])/2], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 4, 4, 4] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 4, 5, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 4, 5, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], Sqrt[(-3 + Sqrt[13])/2], 
     Sqrt[(-3 + Sqrt[13])/2]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 5, 1, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 5, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 5, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 5, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 5, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 5, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 5, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 5, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, {Sqrt[(-3 + Sqrt[13])/2], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 5, 3, 5] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {(-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 5, 4, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 5, 4, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 5, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 5, 4, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 5, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 5, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 5, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 
      0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 5, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[3, 5, 5, 5] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 1, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 1, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 1, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 1, 3, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 1, 4, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 1, 4, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 1, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 1, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 1, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 1, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 1, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 2, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 2, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 2, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 2, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 2, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 2, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 2, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 2, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 3, 1, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 3, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 3, 2, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 3, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 3, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], Sqrt[(-3 + Sqrt[13])/2], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 
      0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 
      0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 3, 3, 5] = 
   {{(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 3, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 3, 4, 4] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 3, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 3, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 3, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 3, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 3, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 3, 5, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 4, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 4, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 4, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 4, 3, 3] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 4, 3, 4] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 4, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 4, 4, 3] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 4, 4, 4] = 
   {{(-3 + Sqrt[13])/2, Sqrt[(-3 + Sqrt[13])/2], Root[-1 + 3*#1^2 + #1^4 & , 
      1, 0], Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 4, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 4, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 4, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 
        2*#1^5 + 6*#1^6 + 2*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 4, 5, 5] = 
   {{(-3 + Sqrt[13])/2, Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 1, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 3, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 3, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 3, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 4, 3] = 
   {{(3 - Sqrt[13])/2, Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 4, 5] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 5, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, 
    {Sqrt[(-3 + Sqrt[13])/2], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 
      0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 
        3*#1^7 + #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 
      1, 0], 0}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[4, 5, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {(-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 1, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 1, 3, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 1, 3, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 1, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 1, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 1, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 2, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 2, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 2, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 2, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 2, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 2, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 2, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 2, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 1, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 2, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 3, 4] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 3, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 4, 3] = 
   {{(-3 + Sqrt[13])/2, Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Sqrt[(-3 + Sqrt[13])/2]}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 
      5, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 
      0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 5, 4] = 
   {{(3 - Sqrt[13])/2, Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 3, 5, 5] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 5, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 1, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 2, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 3, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 3, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 4, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], Root[-1 + 3*#1^2 + #1^4 & , 1, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0}, {Sqrt[(-3 + Sqrt[13])/2], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 5, 3] = 
   {{(3 - Sqrt[13])/2, Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, {Sqrt[(-3 + Sqrt[13])/2], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 5, 4] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {(-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 1, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 3, 3] = 
   {{(-3 + Sqrt[13])/2, Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 
     (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 3, 5] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 4, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 5, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}, 
    {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0]}, {(-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 5, 3] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], (-3 + Sqrt[13] + Sqrt[2*(-1 + Sqrt[13])])/4, 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat7UnitaryFMatrixFunction[5, 5, 5, 5] = 
   {{(-3 + Sqrt[13])/2, Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 4, 0], 
     Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 
     Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 0]}, 
    {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[-1 + 3*#1^2 + #1^4 & , 1, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 3*#1^2 + 10*#1^4 - 3*#1^6 + #1^8 & , 6, 
      0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0}}
 
haagerup6Cat7UnitaryFMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat7], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haagerup6Cat7UnitaryFMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat7], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
fusionCategory[haagerup6Cat7UnitaryPiv1] ^= haagerup6Cat7Unitary
 
pivotalCategory[haagerup6Cat7UnitaryPiv1] ^= haagerup6Cat7UnitaryPiv1
 
pivotalIsomorphism[haagerup6Cat7UnitaryPiv1] ^= 
   haagerup6Cat7UnitaryPiv1PivotalIsomorphism
 
ring[haagerup6Cat7UnitaryPiv1] ^= haagerup6
 
sphericalCategory[haagerup6Cat7UnitaryPiv1] ^= haagerup6Cat7UnitaryPiv1
 
(pivotalCategoryIndex[fusionCategory[haagerup6Cat7Unitary]][
      pivotalCategory[#1]] & )[haagerup6Cat7UnitaryPiv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haagerup6Cat7Unitary]][
      sphericalCategory[#1]] & )[haagerup6Cat7UnitaryPiv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haagerup6Cat7UnitaryPiv1PivotalIsomorphism] ^= 
   haagerup6Cat7Unitary
 
pivotalCategory[haagerup6Cat7UnitaryPiv1PivotalIsomorphism] ^= 
   haagerup6Cat7UnitaryPiv1
 
pivotalIsomorphism[haagerup6Cat7UnitaryPiv1PivotalIsomorphism] ^= 
   haagerup6Cat7UnitaryPiv1PivotalIsomorphism
 
haagerup6Cat7UnitaryPiv1PivotalIsomorphism[0] = 1
 
haagerup6Cat7UnitaryPiv1PivotalIsomorphism[1] = (-1 - I*Sqrt[3])/2
 
haagerup6Cat7UnitaryPiv1PivotalIsomorphism[2] = (-1 + I*Sqrt[3])/2
 
haagerup6Cat7UnitaryPiv1PivotalIsomorphism[3] = 1
 
haagerup6Cat7UnitaryPiv1PivotalIsomorphism[4] = 1
 
haagerup6Cat7UnitaryPiv1PivotalIsomorphism[5] = 1
balancedCategories[haagerup6Cat8] ^= {}
 
braidedCategories[haagerup6Cat8] ^= {}
 
coeval[haagerup6Cat8] ^= 1/sixJFunction[haagerup6Cat8][#1, 
      dual[ring[haagerup6Cat8]][#1], #1, #1, 0, 0] & 
 
eval[haagerup6Cat8] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haagerup6Cat8] ^= haagerup6Cat8FMatrixFunction
 
fusionCategory[haagerup6Cat8] ^= haagerup6Cat8
 
haagerup6Cat8 /: modularCategory[haagerup6Cat8, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[haagerup6Cat8] ^= {haagerup6Cat8Piv1}
 
haagerup6Cat8 /: pivotalCategory[haagerup6Cat8, 1] = haagerup6Cat8Piv1
 
haagerup6Cat8 /: pivotalCategory[haagerup6Cat8, {1, (-1 - I*Sqrt[3])/2, 
      (-1 + I*Sqrt[3])/2, 1, 1, 1}] = haagerup6Cat8Piv1
 
ring[haagerup6Cat8] ^= haagerup6
 
haagerup6Cat8 /: sphericalCategory[haagerup6Cat8, 1] = haagerup6Cat8Piv1
 
fusionCategoryIndex[haagerup6][haagerup6Cat8] ^= 8
fMatrixFunction[haagerup6Cat8FMatrixFunction] ^= haagerup6Cat8FMatrixFunction
 
fusionCategory[haagerup6Cat8FMatrixFunction] ^= haagerup6Cat8
 
ring[haagerup6Cat8FMatrixFunction] ^= haagerup6
 
haagerup6Cat8FMatrixFunction[1, 1, 1, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 1, 2, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 1, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 1, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 2, 1, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 2, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 2, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 2, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 3, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[1, 3, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 3, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 3, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 3, 4, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[1, 3, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 3, 5, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[1, 3, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[1, 3, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[1, 4, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[1, 4, 2, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[1, 4, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 4, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 4, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 4, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 4, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 4, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haagerup6Cat8FMatrixFunction[1, 4, 5, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haagerup6Cat8FMatrixFunction[1, 4, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[1, 5, 1, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[1, 5, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 5, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 5, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 5, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[1, 5, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 1, 1, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 1, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 1, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 2, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 3, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[2, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 3, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 3, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 3, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 3, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 3, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 3, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 3, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 3, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 3, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 4, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 4, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[2, 4, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 4, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 4, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 4, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[2, 4, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 4, 5, 3] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[2, 4, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[2, 4, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[2, 5, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[2, 5, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[2, 5, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 5, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 5, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 5, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haagerup6Cat8FMatrixFunction[2, 5, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haagerup6Cat8FMatrixFunction[2, 5, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[2, 5, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[3, 1, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 1, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 1, 3, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[3, 1, 3, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[3, 1, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[3, 1, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[3, 1, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 1, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 2, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 2, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[3, 2, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[3, 2, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[3, 2, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[3, 3, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 3, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 3, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 3, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 3, 3, 3] = 
   {{(-3 - Sqrt[13])/2, (I/2)*(I + Sqrt[3]), -1, (1 - I*Sqrt[3])/2}, 
    {(-3 - Sqrt[13])/2, 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 3, 3, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}, 
    {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 3, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat8FMatrixFunction[3, 3, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 3, 4, 4] = 
   {{(-3 - Sqrt[13])/2, (I/2)*(I + Sqrt[3]), (1 - I*Sqrt[3])/2, 
     (-I/2)*(-I + Sqrt[3])}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 0}}
 
haagerup6Cat8FMatrixFunction[3, 3, 4, 5] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}, {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat8FMatrixFunction[3, 3, 5, 4] = 
   {{(-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], (-1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 3, 5, 5] = 
   {{(-3 - Sqrt[13])/2, 1, -1, (1 - I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 4, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 4, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[3, 4, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 4, 3, 4] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}, 
    {(-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat8FMatrixFunction[3, 4, 3, 5] = 
   {{(-3 - Sqrt[13])/2, -1, 1, (1 + I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 4, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 4, 4, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], -1, 1, 
     (1 + I*Sqrt[3])/2}, {(-3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 
      0]}, {(3 + Sqrt[13])/2, 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0}}
 
haagerup6Cat8FMatrixFunction[3, 4, 4, 4] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 4, 5, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 1, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 7, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 4, 5, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], -1, 1, 1}, 
    {(3 + Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 
      0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 3, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {(-3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 5, 1, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 5, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 5, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 5, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 5, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[3, 5, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[3, 5, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}, {(-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat8FMatrixFunction[3, 5, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], (1 - I*Sqrt[3])/2, 
     (I/2)*(I + Sqrt[3]), -1}, {(3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 0}, {(-3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 5, 3, 5] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], (-1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {(-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 5, 4, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[3, 5, 4, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 8, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 5, 4, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}, {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 5, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], (1 - I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 0}}
 
haagerup6Cat8FMatrixFunction[3, 5, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[3, 5, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], (1 - I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, {(-3 - Sqrt[13])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 
      0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 
        3*#1^7 + #1^8 & , 6, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 5, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat8FMatrixFunction[3, 5, 5, 5] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 7, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 1, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 1, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 1, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 1, 3, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[4, 1, 4, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[4, 1, 4, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[4, 1, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[4, 1, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 1, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 1, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 1, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 2, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 2, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haagerup6Cat8FMatrixFunction[4, 2, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 2, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 2, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[4, 2, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 2, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 2, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[4, 3, 1, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 3, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[4, 3, 2, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 3, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haagerup6Cat8FMatrixFunction[4, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 3, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], -1, 1, 
     (1 + I*Sqrt[3])/2}, {(-3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 0}}
 
haagerup6Cat8FMatrixFunction[4, 3, 3, 5] = 
   {{(-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 3, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}, {(-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat8FMatrixFunction[4, 3, 4, 4] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 3, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], (1 + I*Sqrt[3])/2, 
     -1, (-I/2)*(-I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 3, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 3, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 3, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], (1 - I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 3, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 3, 5, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 4, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 4, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[4, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 4, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 4, 3, 3] = 
   {{(-3 - Sqrt[13])/2, 1, (1 + I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, 
    {(3 + Sqrt[13])/2, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}, {(-3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0}}
 
haagerup6Cat8FMatrixFunction[4, 4, 3, 4] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 4, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haagerup6Cat8FMatrixFunction[4, 4, 4, 3] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 4, 4, 4] = {{(-3 - Sqrt[13])/2, 1, -1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}, 
    {(3 + Sqrt[13])/2, 0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat8FMatrixFunction[4, 4, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[4, 4, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 4, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 
        2*#1^5 + 6*#1^6 + 2*#1^7 + #1^8 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat8FMatrixFunction[4, 4, 5, 5] = 
   {{(-3 - Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), (1 + I*Sqrt[3])/2, 
     (-I/2)*(-I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 
      0], 0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {(3 + Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 5, 1, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 5, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 5, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 5, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[4, 5, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[4, 5, 3, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[4, 5, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[4, 5, 3, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}, {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 5, 3, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], (1 + I*Sqrt[3])/2, 
     -1, (-I/2)*(-I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 8, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {(3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 0}}
 
haagerup6Cat8FMatrixFunction[4, 5, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haagerup6Cat8FMatrixFunction[4, 5, 4, 3] = 
   {{(3 + Sqrt[13])/2, (1 + I*Sqrt[3])/2, -1, (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 5, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {(-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat8FMatrixFunction[4, 5, 4, 5] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 5, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[4, 5, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[4, 5, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 7, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 5, 5, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], (1 + I*Sqrt[3])/2, 
     -1, -1}, {(-3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     0}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}}
 
haagerup6Cat8FMatrixFunction[4, 5, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 1, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 1, 3, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[5, 1, 3, 5] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[5, 1, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 1, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haagerup6Cat8FMatrixFunction[5, 1, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[5, 2, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 2, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 2, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 2, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 2, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haagerup6Cat8FMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haagerup6Cat8FMatrixFunction[5, 2, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[5, 2, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 2, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haagerup6Cat8FMatrixFunction[5, 3, 1, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 3, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[5, 3, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[5, 3, 2, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 3, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haagerup6Cat8FMatrixFunction[5, 3, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 3, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat8FMatrixFunction[5, 3, 3, 4] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 3, 3, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], (1 - I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 3, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 3, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 3, 4, 3] = 
   {{(-3 - Sqrt[13])/2, -1, (1 - I*Sqrt[3])/2, 1}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 3, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 3, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat8FMatrixFunction[5, 3, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 3, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {(-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 3, 5, 4] = 
   {{(3 + Sqrt[13])/2, (1 - I*Sqrt[3])/2, (1 + I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}, {(-3 - Sqrt[13])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 0}}
 
haagerup6Cat8FMatrixFunction[5, 3, 5, 5] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 8, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 4, 1, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 4, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[5, 4, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[5, 4, 2, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 4, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[5, 4, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haagerup6Cat8FMatrixFunction[5, 4, 3, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], (-1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 4, 3, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], (1 + I*Sqrt[3])/2, 
     (-I/2)*(-I + Sqrt[3]), (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat8FMatrixFunction[5, 4, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 4, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 4, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}, {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haagerup6Cat8FMatrixFunction[5, 4, 4, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], (1 + I*Sqrt[3])/2, 
     -1, -1}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0}, {(-3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 4, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 4, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 4, 5, 3] = 
   {{(3 + Sqrt[13])/2, (1 - I*Sqrt[3])/2, (1 + I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}, {(-3 - Sqrt[13])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 0}}
 
haagerup6Cat8FMatrixFunction[5, 4, 5, 4] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 5, 1, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haagerup6Cat8FMatrixFunction[5, 5, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[5, 5, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 5, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[5, 5, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haagerup6Cat8FMatrixFunction[5, 5, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 5, 3, 3] = 
   {{(-3 - Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), -1, (1 + I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 5, 3, 5] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 5, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[5, 5, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 5, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 5, 4, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], (I/2)*(I + Sqrt[3]), 
     -1, (-I/2)*(-I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      2, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 0}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 5, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}, {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 5, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 5, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haagerup6Cat8FMatrixFunction[5, 5, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haagerup6Cat8FMatrixFunction[5, 5, 5, 3] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 5, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 1, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}}
 
haagerup6Cat8FMatrixFunction[5, 5, 5, 5] = 
   {{(-3 - Sqrt[13])/2, (I/2)*(I + Sqrt[3]), -1, (1 + I*Sqrt[3])/2}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}, {(3 + Sqrt[13])/2, 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0}}
 
haagerup6Cat8FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat8], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haagerup6Cat8FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haagerup6Cat8], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[haagerup6Cat8Piv1] ^= {}
 
fusionCategory[haagerup6Cat8Piv1] ^= haagerup6Cat8
 
haagerup6Cat8Piv1 /: modularCategory[haagerup6Cat8Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[haagerup6Cat8Piv1] ^= haagerup6Cat8Piv1
 
pivotalIsomorphism[haagerup6Cat8Piv1] ^= haagerup6Cat8Piv1PivotalIsomorphism
 
ring[haagerup6Cat8Piv1] ^= haagerup6
 
sphericalCategory[haagerup6Cat8Piv1] ^= haagerup6Cat8Piv1
 
(pivotalCategoryIndex[fusionCategory[haagerup6Cat8]][pivotalCategory[#1]] & )[
    haagerup6Cat8Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haagerup6Cat8]][
      sphericalCategory[#1]] & )[haagerup6Cat8Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haagerup6Cat8Piv1PivotalIsomorphism] ^= haagerup6Cat8
 
pivotalCategory[haagerup6Cat8Piv1PivotalIsomorphism] ^= haagerup6Cat8Piv1
 
pivotalIsomorphism[haagerup6Cat8Piv1PivotalIsomorphism] ^= 
   haagerup6Cat8Piv1PivotalIsomorphism
 
haagerup6Cat8Piv1PivotalIsomorphism[0] = 1
 
haagerup6Cat8Piv1PivotalIsomorphism[1] = (-1 - I*Sqrt[3])/2
 
haagerup6Cat8Piv1PivotalIsomorphism[2] = (-1 + I*Sqrt[3])/2
 
haagerup6Cat8Piv1PivotalIsomorphism[3] = 1
 
haagerup6Cat8Piv1PivotalIsomorphism[4] = 1
 
haagerup6Cat8Piv1PivotalIsomorphism[5] = 1
ring[haagerup6NFunction] ^= haagerup6
 
haagerup6NFunction[0, 0, 0] = 1
 
haagerup6NFunction[0, 0, 1] = 0
 
haagerup6NFunction[0, 0, 2] = 0
 
haagerup6NFunction[0, 0, 3] = 0
 
haagerup6NFunction[0, 0, 4] = 0
 
haagerup6NFunction[0, 0, 5] = 0
 
haagerup6NFunction[0, 1, 0] = 0
 
haagerup6NFunction[0, 1, 1] = 1
 
haagerup6NFunction[0, 1, 2] = 0
 
haagerup6NFunction[0, 1, 3] = 0
 
haagerup6NFunction[0, 1, 4] = 0
 
haagerup6NFunction[0, 1, 5] = 0
 
haagerup6NFunction[0, 2, 0] = 0
 
haagerup6NFunction[0, 2, 1] = 0
 
haagerup6NFunction[0, 2, 2] = 1
 
haagerup6NFunction[0, 2, 3] = 0
 
haagerup6NFunction[0, 2, 4] = 0
 
haagerup6NFunction[0, 2, 5] = 0
 
haagerup6NFunction[0, 3, 0] = 0
 
haagerup6NFunction[0, 3, 1] = 0
 
haagerup6NFunction[0, 3, 2] = 0
 
haagerup6NFunction[0, 3, 3] = 1
 
haagerup6NFunction[0, 3, 4] = 0
 
haagerup6NFunction[0, 3, 5] = 0
 
haagerup6NFunction[0, 4, 0] = 0
 
haagerup6NFunction[0, 4, 1] = 0
 
haagerup6NFunction[0, 4, 2] = 0
 
haagerup6NFunction[0, 4, 3] = 0
 
haagerup6NFunction[0, 4, 4] = 1
 
haagerup6NFunction[0, 4, 5] = 0
 
haagerup6NFunction[0, 5, 0] = 0
 
haagerup6NFunction[0, 5, 1] = 0
 
haagerup6NFunction[0, 5, 2] = 0
 
haagerup6NFunction[0, 5, 3] = 0
 
haagerup6NFunction[0, 5, 4] = 0
 
haagerup6NFunction[0, 5, 5] = 1
 
haagerup6NFunction[1, 0, 0] = 0
 
haagerup6NFunction[1, 0, 1] = 1
 
haagerup6NFunction[1, 0, 2] = 0
 
haagerup6NFunction[1, 0, 3] = 0
 
haagerup6NFunction[1, 0, 4] = 0
 
haagerup6NFunction[1, 0, 5] = 0
 
haagerup6NFunction[1, 1, 0] = 0
 
haagerup6NFunction[1, 1, 1] = 0
 
haagerup6NFunction[1, 1, 2] = 1
 
haagerup6NFunction[1, 1, 3] = 0
 
haagerup6NFunction[1, 1, 4] = 0
 
haagerup6NFunction[1, 1, 5] = 0
 
haagerup6NFunction[1, 2, 0] = 1
 
haagerup6NFunction[1, 2, 1] = 0
 
haagerup6NFunction[1, 2, 2] = 0
 
haagerup6NFunction[1, 2, 3] = 0
 
haagerup6NFunction[1, 2, 4] = 0
 
haagerup6NFunction[1, 2, 5] = 0
 
haagerup6NFunction[1, 3, 0] = 0
 
haagerup6NFunction[1, 3, 1] = 0
 
haagerup6NFunction[1, 3, 2] = 0
 
haagerup6NFunction[1, 3, 3] = 0
 
haagerup6NFunction[1, 3, 4] = 1
 
haagerup6NFunction[1, 3, 5] = 0
 
haagerup6NFunction[1, 4, 0] = 0
 
haagerup6NFunction[1, 4, 1] = 0
 
haagerup6NFunction[1, 4, 2] = 0
 
haagerup6NFunction[1, 4, 3] = 0
 
haagerup6NFunction[1, 4, 4] = 0
 
haagerup6NFunction[1, 4, 5] = 1
 
haagerup6NFunction[1, 5, 0] = 0
 
haagerup6NFunction[1, 5, 1] = 0
 
haagerup6NFunction[1, 5, 2] = 0
 
haagerup6NFunction[1, 5, 3] = 1
 
haagerup6NFunction[1, 5, 4] = 0
 
haagerup6NFunction[1, 5, 5] = 0
 
haagerup6NFunction[2, 0, 0] = 0
 
haagerup6NFunction[2, 0, 1] = 0
 
haagerup6NFunction[2, 0, 2] = 1
 
haagerup6NFunction[2, 0, 3] = 0
 
haagerup6NFunction[2, 0, 4] = 0
 
haagerup6NFunction[2, 0, 5] = 0
 
haagerup6NFunction[2, 1, 0] = 1
 
haagerup6NFunction[2, 1, 1] = 0
 
haagerup6NFunction[2, 1, 2] = 0
 
haagerup6NFunction[2, 1, 3] = 0
 
haagerup6NFunction[2, 1, 4] = 0
 
haagerup6NFunction[2, 1, 5] = 0
 
haagerup6NFunction[2, 2, 0] = 0
 
haagerup6NFunction[2, 2, 1] = 1
 
haagerup6NFunction[2, 2, 2] = 0
 
haagerup6NFunction[2, 2, 3] = 0
 
haagerup6NFunction[2, 2, 4] = 0
 
haagerup6NFunction[2, 2, 5] = 0
 
haagerup6NFunction[2, 3, 0] = 0
 
haagerup6NFunction[2, 3, 1] = 0
 
haagerup6NFunction[2, 3, 2] = 0
 
haagerup6NFunction[2, 3, 3] = 0
 
haagerup6NFunction[2, 3, 4] = 0
 
haagerup6NFunction[2, 3, 5] = 1
 
haagerup6NFunction[2, 4, 0] = 0
 
haagerup6NFunction[2, 4, 1] = 0
 
haagerup6NFunction[2, 4, 2] = 0
 
haagerup6NFunction[2, 4, 3] = 1
 
haagerup6NFunction[2, 4, 4] = 0
 
haagerup6NFunction[2, 4, 5] = 0
 
haagerup6NFunction[2, 5, 0] = 0
 
haagerup6NFunction[2, 5, 1] = 0
 
haagerup6NFunction[2, 5, 2] = 0
 
haagerup6NFunction[2, 5, 3] = 0
 
haagerup6NFunction[2, 5, 4] = 1
 
haagerup6NFunction[2, 5, 5] = 0
 
haagerup6NFunction[3, 0, 0] = 0
 
haagerup6NFunction[3, 0, 1] = 0
 
haagerup6NFunction[3, 0, 2] = 0
 
haagerup6NFunction[3, 0, 3] = 1
 
haagerup6NFunction[3, 0, 4] = 0
 
haagerup6NFunction[3, 0, 5] = 0
 
haagerup6NFunction[3, 1, 0] = 0
 
haagerup6NFunction[3, 1, 1] = 0
 
haagerup6NFunction[3, 1, 2] = 0
 
haagerup6NFunction[3, 1, 3] = 0
 
haagerup6NFunction[3, 1, 4] = 0
 
haagerup6NFunction[3, 1, 5] = 1
 
haagerup6NFunction[3, 2, 0] = 0
 
haagerup6NFunction[3, 2, 1] = 0
 
haagerup6NFunction[3, 2, 2] = 0
 
haagerup6NFunction[3, 2, 3] = 0
 
haagerup6NFunction[3, 2, 4] = 1
 
haagerup6NFunction[3, 2, 5] = 0
 
haagerup6NFunction[3, 3, 0] = 1
 
haagerup6NFunction[3, 3, 1] = 0
 
haagerup6NFunction[3, 3, 2] = 0
 
haagerup6NFunction[3, 3, 3] = 1
 
haagerup6NFunction[3, 3, 4] = 1
 
haagerup6NFunction[3, 3, 5] = 1
 
haagerup6NFunction[3, 4, 0] = 0
 
haagerup6NFunction[3, 4, 1] = 0
 
haagerup6NFunction[3, 4, 2] = 1
 
haagerup6NFunction[3, 4, 3] = 1
 
haagerup6NFunction[3, 4, 4] = 1
 
haagerup6NFunction[3, 4, 5] = 1
 
haagerup6NFunction[3, 5, 0] = 0
 
haagerup6NFunction[3, 5, 1] = 1
 
haagerup6NFunction[3, 5, 2] = 0
 
haagerup6NFunction[3, 5, 3] = 1
 
haagerup6NFunction[3, 5, 4] = 1
 
haagerup6NFunction[3, 5, 5] = 1
 
haagerup6NFunction[4, 0, 0] = 0
 
haagerup6NFunction[4, 0, 1] = 0
 
haagerup6NFunction[4, 0, 2] = 0
 
haagerup6NFunction[4, 0, 3] = 0
 
haagerup6NFunction[4, 0, 4] = 1
 
haagerup6NFunction[4, 0, 5] = 0
 
haagerup6NFunction[4, 1, 0] = 0
 
haagerup6NFunction[4, 1, 1] = 0
 
haagerup6NFunction[4, 1, 2] = 0
 
haagerup6NFunction[4, 1, 3] = 1
 
haagerup6NFunction[4, 1, 4] = 0
 
haagerup6NFunction[4, 1, 5] = 0
 
haagerup6NFunction[4, 2, 0] = 0
 
haagerup6NFunction[4, 2, 1] = 0
 
haagerup6NFunction[4, 2, 2] = 0
 
haagerup6NFunction[4, 2, 3] = 0
 
haagerup6NFunction[4, 2, 4] = 0
 
haagerup6NFunction[4, 2, 5] = 1
 
haagerup6NFunction[4, 3, 0] = 0
 
haagerup6NFunction[4, 3, 1] = 1
 
haagerup6NFunction[4, 3, 2] = 0
 
haagerup6NFunction[4, 3, 3] = 1
 
haagerup6NFunction[4, 3, 4] = 1
 
haagerup6NFunction[4, 3, 5] = 1
 
haagerup6NFunction[4, 4, 0] = 1
 
haagerup6NFunction[4, 4, 1] = 0
 
haagerup6NFunction[4, 4, 2] = 0
 
haagerup6NFunction[4, 4, 3] = 1
 
haagerup6NFunction[4, 4, 4] = 1
 
haagerup6NFunction[4, 4, 5] = 1
 
haagerup6NFunction[4, 5, 0] = 0
 
haagerup6NFunction[4, 5, 1] = 0
 
haagerup6NFunction[4, 5, 2] = 1
 
haagerup6NFunction[4, 5, 3] = 1
 
haagerup6NFunction[4, 5, 4] = 1
 
haagerup6NFunction[4, 5, 5] = 1
 
haagerup6NFunction[5, 0, 0] = 0
 
haagerup6NFunction[5, 0, 1] = 0
 
haagerup6NFunction[5, 0, 2] = 0
 
haagerup6NFunction[5, 0, 3] = 0
 
haagerup6NFunction[5, 0, 4] = 0
 
haagerup6NFunction[5, 0, 5] = 1
 
haagerup6NFunction[5, 1, 0] = 0
 
haagerup6NFunction[5, 1, 1] = 0
 
haagerup6NFunction[5, 1, 2] = 0
 
haagerup6NFunction[5, 1, 3] = 0
 
haagerup6NFunction[5, 1, 4] = 1
 
haagerup6NFunction[5, 1, 5] = 0
 
haagerup6NFunction[5, 2, 0] = 0
 
haagerup6NFunction[5, 2, 1] = 0
 
haagerup6NFunction[5, 2, 2] = 0
 
haagerup6NFunction[5, 2, 3] = 1
 
haagerup6NFunction[5, 2, 4] = 0
 
haagerup6NFunction[5, 2, 5] = 0
 
haagerup6NFunction[5, 3, 0] = 0
 
haagerup6NFunction[5, 3, 1] = 0
 
haagerup6NFunction[5, 3, 2] = 1
 
haagerup6NFunction[5, 3, 3] = 1
 
haagerup6NFunction[5, 3, 4] = 1
 
haagerup6NFunction[5, 3, 5] = 1
 
haagerup6NFunction[5, 4, 0] = 0
 
haagerup6NFunction[5, 4, 1] = 1
 
haagerup6NFunction[5, 4, 2] = 0
 
haagerup6NFunction[5, 4, 3] = 1
 
haagerup6NFunction[5, 4, 4] = 1
 
haagerup6NFunction[5, 4, 5] = 1
 
haagerup6NFunction[5, 5, 0] = 1
 
haagerup6NFunction[5, 5, 1] = 0
 
haagerup6NFunction[5, 5, 2] = 0
 
haagerup6NFunction[5, 5, 3] = 1
 
haagerup6NFunction[5, 5, 4] = 1
 
haagerup6NFunction[5, 5, 5] = 1
 
haagerup6NFunction[a_, b_, c_] := 0
Attributes[haagerup6$] = {Temporary}


 EndPackage[]