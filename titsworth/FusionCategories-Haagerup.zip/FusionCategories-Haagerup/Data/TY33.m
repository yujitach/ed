BeginPackage["FusionCategories`Data`TY33`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[TY33] ^= {TY33Cat1, TY33Cat2, TY33Cat3, TY33Cat4}
 
TY33 /: fusionCategory[TY33, 1] = TY33Cat1
 
TY33 /: fusionCategory[TY33, 2] = TY33Cat2
 
TY33 /: fusionCategory[TY33, 3] = TY33Cat3
 
TY33 /: fusionCategory[TY33, 4] = TY33Cat4
 
nFunction[TY33] ^= TY33NFunction
 
noMultiplicities[TY33] ^= True
 
rank[TY33] ^= 10
 
ring[TY33] ^= TY33
balancedCategories[TY33Cat1] ^= {}
 
braidedCategories[TY33Cat1] ^= {}
 
coeval[TY33Cat1] ^= 1/sixJFunction[TY33Cat1][#1, dual[ring[TY33Cat1]][#1], 
      #1, #1, 0, 0] & 
 
eval[TY33Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TY33Cat1] ^= TY33Cat1FMatrixFunction
 
fusionCategory[TY33Cat1] ^= TY33Cat1
 
TY33Cat1 /: modularCategory[TY33Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TY33Cat1] ^= {TY33Cat1Piv1, TY33Cat1Piv2}
 
TY33Cat1 /: pivotalCategory[TY33Cat1, 1] = TY33Cat1Piv1
 
TY33Cat1 /: pivotalCategory[TY33Cat1, 2] = TY33Cat1Piv2
 
TY33Cat1 /: pivotalCategory[TY33Cat1, {1, 1, 1, 1, 1, 1, 1, 1, 1, -1}] = 
    TY33Cat1Piv2
 
TY33Cat1 /: pivotalCategory[TY33Cat1, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}] = 
    TY33Cat1Piv1
 
ring[TY33Cat1] ^= TY33
 
TY33Cat1 /: sphericalCategory[TY33Cat1, 1] = TY33Cat1Piv1
 
TY33Cat1 /: sphericalCategory[TY33Cat1, 2] = TY33Cat1Piv2
 
fusionCategoryIndex[TY33][TY33Cat1] ^= 1
fMatrixFunction[TY33Cat1FMatrixFunction] ^= TY33Cat1FMatrixFunction
 
fusionCategory[TY33Cat1FMatrixFunction] ^= TY33Cat1
 
ring[TY33Cat1FMatrixFunction] ^= TY33
 
TY33Cat1FMatrixFunction[1, 9, 3, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[1, 9, 4, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[1, 9, 5, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[1, 9, 6, 9] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[1, 9, 7, 9] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[1, 9, 8, 9] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[2, 9, 3, 9] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[2, 9, 4, 9] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[2, 9, 5, 9] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[2, 9, 6, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[2, 9, 7, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[2, 9, 8, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[3, 9, 1, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[3, 9, 2, 9] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[3, 9, 3, 9] = {{-1 + (-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[3, 9, 4, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[3, 9, 6, 9] = {{-1 - (-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[3, 9, 8, 9] = {{(-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[4, 9, 1, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[4, 9, 2, 9] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[4, 9, 3, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[4, 9, 5, 9] = {{-1 + (-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[4, 9, 6, 9] = {{(-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[4, 9, 7, 9] = {{-1 - (-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[5, 9, 1, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[5, 9, 2, 9] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[5, 9, 4, 9] = {{-1 + (-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[5, 9, 5, 9] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[5, 9, 7, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[5, 9, 8, 9] = {{-1 - (-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[6, 9, 1, 9] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[6, 9, 2, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[6, 9, 3, 9] = {{-1 - (-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[6, 9, 4, 9] = {{(-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[6, 9, 6, 9] = {{-1 + (-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[6, 9, 8, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[7, 9, 1, 9] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[7, 9, 2, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[7, 9, 4, 9] = {{-1 - (-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[7, 9, 5, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[7, 9, 7, 9] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[7, 9, 8, 9] = {{-1 + (-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[8, 9, 1, 9] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[8, 9, 2, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[8, 9, 3, 9] = {{(-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[8, 9, 5, 9] = {{-1 - (-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[8, 9, 6, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[8, 9, 7, 9] = {{-1 + (-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 1, 9, 3] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[9, 1, 9, 4] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[9, 1, 9, 5] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[9, 1, 9, 6] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 1, 9, 7] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 1, 9, 8] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 2, 9, 3] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 2, 9, 4] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 2, 9, 5] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 2, 9, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[9, 2, 9, 7] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[9, 2, 9, 8] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[9, 3, 9, 1] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[9, 3, 9, 2] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 3, 9, 3] = {{-1 + (-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 3, 9, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[9, 3, 9, 6] = {{-1 - (-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[9, 3, 9, 8] = {{(-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[9, 4, 9, 1] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[9, 4, 9, 2] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 4, 9, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[9, 4, 9, 5] = {{-1 + (-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 4, 9, 6] = {{(-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[9, 4, 9, 7] = {{-1 - (-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[9, 5, 9, 1] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[9, 5, 9, 2] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 5, 9, 4] = {{-1 + (-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 5, 9, 5] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 5, 9, 7] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[9, 5, 9, 8] = {{-1 - (-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[9, 6, 9, 1] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 6, 9, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[9, 6, 9, 3] = {{-1 - (-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[9, 6, 9, 4] = {{(-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[9, 6, 9, 6] = {{-1 + (-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 6, 9, 8] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[9, 7, 9, 1] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 7, 9, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[9, 7, 9, 4] = {{-1 - (-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[9, 7, 9, 5] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[9, 7, 9, 7] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 7, 9, 8] = {{-1 + (-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 8, 9, 1] = {{-(-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 8, 9, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[9, 8, 9, 3] = {{(-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[9, 8, 9, 5] = {{-1 - (-1)^(2/3)}}
 
TY33Cat1FMatrixFunction[9, 8, 9, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat1FMatrixFunction[9, 8, 9, 7] = {{-1 + (-1)^(1/3)}}
 
TY33Cat1FMatrixFunction[9, 9, 9, 9] = {{1/3, 1/3, 1/3, 1/3, 1/3, 1/3, 1/3, 
     1/3, 1/3}, {1/3, 1/3, 1/3, -(-1)^(1/3)/3, -(-1)^(1/3)/3, -(-1)^(1/3)/3, 
     (I/6)*(I + Sqrt[3]), (I/6)*(I + Sqrt[3]), (I/6)*(I + Sqrt[3])}, 
    {1/3, 1/3, 1/3, (I/6)*(I + Sqrt[3]), (I/6)*(I + Sqrt[3]), 
     (I/6)*(I + Sqrt[3]), -(-1)^(1/3)/3, -(-1)^(1/3)/3, -(-1)^(1/3)/3}, 
    {1/3, -(-1)^(1/3)/3, (I/6)*(I + Sqrt[3]), (-1 - (-1)^(2/3))/3, 
     (-1)^(2/3)/3, 1/3, (-1 + (-1)^(1/3))/3, 1/3, (-I/6)*(-I + Sqrt[3])}, 
    {1/3, -(-1)^(1/3)/3, (I/6)*(I + Sqrt[3]), (-1)^(2/3)/3, 1/3, 
     (-1 - (-1)^(2/3))/3, (-I/6)*(-I + Sqrt[3]), (-1 + (-1)^(1/3))/3, 1/3}, 
    {1/3, -(-1)^(1/3)/3, (I/6)*(I + Sqrt[3]), 1/3, (-1 - (-1)^(2/3))/3, 
     (I/6)*(I + Sqrt[3]), 1/3, -(-1)^(1/3)/3, (-1 + (-1)^(1/3))/3}, 
    {1/3, (I/6)*(I + Sqrt[3]), -(-1)^(1/3)/3, (-1 + (-1)^(1/3))/3, 
     (-I/6)*(-I + Sqrt[3]), 1/3, (-1 - (-1)^(2/3))/3, 1/3, (-1)^(2/3)/3}, 
    {1/3, (I/6)*(I + Sqrt[3]), -(-1)^(1/3)/3, 1/3, (-1 + (-1)^(1/3))/3, 
     -(-1)^(1/3)/3, 1/3, (I/6)*(I + Sqrt[3]), (-1 - (-1)^(2/3))/3}, 
    {1/3, (I/6)*(I + Sqrt[3]), -(-1)^(1/3)/3, (-I/6)*(-I + Sqrt[3]), 1/3, 
     (-1 + (-1)^(1/3))/3, (-1)^(2/3)/3, (-1 - (-1)^(2/3))/3, 1/3}}
 
TY33Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY33Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TY33Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY33Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TY33Cat1Piv1] ^= {}
 
fusionCategory[TY33Cat1Piv1] ^= TY33Cat1
 
TY33Cat1Piv1 /: modularCategory[TY33Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY33Cat1Piv1] ^= TY33Cat1Piv1
 
pivotalIsomorphism[TY33Cat1Piv1] ^= TY33Cat1Piv1PivotalIsomorphism
 
ring[TY33Cat1Piv1] ^= TY33
 
sphericalCategory[TY33Cat1Piv1] ^= TY33Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[TY33Cat1]][pivotalCategory[#1]] & )[
    TY33Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TY33Cat1]][sphericalCategory[#1]] & )[
    TY33Cat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY33Cat1Piv1PivotalIsomorphism] ^= TY33Cat1
 
pivotalCategory[TY33Cat1Piv1PivotalIsomorphism] ^= TY33Cat1Piv1
 
pivotalIsomorphism[TY33Cat1Piv1PivotalIsomorphism] ^= 
   TY33Cat1Piv1PivotalIsomorphism
 
TY33Cat1Piv1PivotalIsomorphism[0] = 1
 
TY33Cat1Piv1PivotalIsomorphism[1] = 1
 
TY33Cat1Piv1PivotalIsomorphism[2] = 1
 
TY33Cat1Piv1PivotalIsomorphism[3] = 1
 
TY33Cat1Piv1PivotalIsomorphism[4] = 1
 
TY33Cat1Piv1PivotalIsomorphism[5] = 1
 
TY33Cat1Piv1PivotalIsomorphism[6] = 1
 
TY33Cat1Piv1PivotalIsomorphism[7] = 1
 
TY33Cat1Piv1PivotalIsomorphism[8] = 1
 
TY33Cat1Piv1PivotalIsomorphism[9] = 1
balancedCategories[TY33Cat1Piv2] ^= {}
 
fusionCategory[TY33Cat1Piv2] ^= TY33Cat1
 
TY33Cat1Piv2 /: modularCategory[TY33Cat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY33Cat1Piv2] ^= TY33Cat1Piv2
 
pivotalIsomorphism[TY33Cat1Piv2] ^= TY33Cat1Piv2PivotalIsomorphism
 
ring[TY33Cat1Piv2] ^= TY33
 
sphericalCategory[TY33Cat1Piv2] ^= TY33Cat1Piv2
 
(pivotalCategoryIndex[fusionCategory[TY33Cat1]][pivotalCategory[#1]] & )[
    TY33Cat1Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TY33Cat1]][sphericalCategory[#1]] & )[
    TY33Cat1Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY33Cat1Piv2PivotalIsomorphism] ^= TY33Cat1
 
pivotalCategory[TY33Cat1Piv2PivotalIsomorphism] ^= TY33Cat1Piv2
 
pivotalIsomorphism[TY33Cat1Piv2PivotalIsomorphism] ^= 
   TY33Cat1Piv2PivotalIsomorphism
 
TY33Cat1Piv2PivotalIsomorphism[0] = 1
 
TY33Cat1Piv2PivotalIsomorphism[1] = 1
 
TY33Cat1Piv2PivotalIsomorphism[2] = 1
 
TY33Cat1Piv2PivotalIsomorphism[3] = 1
 
TY33Cat1Piv2PivotalIsomorphism[4] = 1
 
TY33Cat1Piv2PivotalIsomorphism[5] = 1
 
TY33Cat1Piv2PivotalIsomorphism[6] = 1
 
TY33Cat1Piv2PivotalIsomorphism[7] = 1
 
TY33Cat1Piv2PivotalIsomorphism[8] = 1
 
TY33Cat1Piv2PivotalIsomorphism[9] = -1
balancedCategories[TY33Cat2] ^= {}
 
braidedCategories[TY33Cat2] ^= {}
 
coeval[TY33Cat2] ^= 1/sixJFunction[TY33Cat2][#1, dual[ring[TY33Cat2]][#1], 
      #1, #1, 0, 0] & 
 
eval[TY33Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TY33Cat2] ^= TY33Cat2FMatrixFunction
 
fusionCategory[TY33Cat2] ^= TY33Cat2
 
TY33Cat2 /: modularCategory[TY33Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TY33Cat2] ^= {TY33Cat2Piv1, TY33Cat2Piv2}
 
TY33Cat2 /: pivotalCategory[TY33Cat2, 1] = TY33Cat2Piv1
 
TY33Cat2 /: pivotalCategory[TY33Cat2, 2] = TY33Cat2Piv2
 
TY33Cat2 /: pivotalCategory[TY33Cat2, {1, 1, 1, 1, 1, 1, 1, 1, 1, -1}] = 
    TY33Cat2Piv2
 
TY33Cat2 /: pivotalCategory[TY33Cat2, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}] = 
    TY33Cat2Piv1
 
ring[TY33Cat2] ^= TY33
 
TY33Cat2 /: sphericalCategory[TY33Cat2, 1] = TY33Cat2Piv1
 
TY33Cat2 /: sphericalCategory[TY33Cat2, 2] = TY33Cat2Piv2
 
fusionCategoryIndex[TY33][TY33Cat2] ^= 2
fMatrixFunction[TY33Cat2FMatrixFunction] ^= TY33Cat2FMatrixFunction
 
fusionCategory[TY33Cat2FMatrixFunction] ^= TY33Cat2
 
ring[TY33Cat2FMatrixFunction] ^= TY33
 
TY33Cat2FMatrixFunction[1, 9, 3, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[1, 9, 4, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[1, 9, 5, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[1, 9, 6, 9] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[1, 9, 7, 9] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[1, 9, 8, 9] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[2, 9, 3, 9] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[2, 9, 4, 9] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[2, 9, 5, 9] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[2, 9, 6, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[2, 9, 7, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[2, 9, 8, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[3, 9, 1, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[3, 9, 2, 9] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[3, 9, 3, 9] = {{-1 + (-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[3, 9, 4, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[3, 9, 6, 9] = {{-1 - (-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[3, 9, 8, 9] = {{(-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[4, 9, 1, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[4, 9, 2, 9] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[4, 9, 3, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[4, 9, 5, 9] = {{-1 + (-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[4, 9, 6, 9] = {{(-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[4, 9, 7, 9] = {{-1 - (-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[5, 9, 1, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[5, 9, 2, 9] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[5, 9, 4, 9] = {{-1 + (-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[5, 9, 5, 9] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[5, 9, 7, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[5, 9, 8, 9] = {{-1 - (-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[6, 9, 1, 9] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[6, 9, 2, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[6, 9, 3, 9] = {{-1 - (-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[6, 9, 4, 9] = {{(-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[6, 9, 6, 9] = {{-1 + (-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[6, 9, 8, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[7, 9, 1, 9] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[7, 9, 2, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[7, 9, 4, 9] = {{-1 - (-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[7, 9, 5, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[7, 9, 7, 9] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[7, 9, 8, 9] = {{-1 + (-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[8, 9, 1, 9] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[8, 9, 2, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[8, 9, 3, 9] = {{(-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[8, 9, 5, 9] = {{-1 - (-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[8, 9, 6, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[8, 9, 7, 9] = {{-1 + (-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 1, 9, 3] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[9, 1, 9, 4] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[9, 1, 9, 5] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[9, 1, 9, 6] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 1, 9, 7] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 1, 9, 8] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 2, 9, 3] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 2, 9, 4] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 2, 9, 5] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 2, 9, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[9, 2, 9, 7] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[9, 2, 9, 8] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[9, 3, 9, 1] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[9, 3, 9, 2] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 3, 9, 3] = {{-1 + (-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 3, 9, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[9, 3, 9, 6] = {{-1 - (-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[9, 3, 9, 8] = {{(-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[9, 4, 9, 1] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[9, 4, 9, 2] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 4, 9, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[9, 4, 9, 5] = {{-1 + (-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 4, 9, 6] = {{(-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[9, 4, 9, 7] = {{-1 - (-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[9, 5, 9, 1] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[9, 5, 9, 2] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 5, 9, 4] = {{-1 + (-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 5, 9, 5] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 5, 9, 7] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[9, 5, 9, 8] = {{-1 - (-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[9, 6, 9, 1] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 6, 9, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[9, 6, 9, 3] = {{-1 - (-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[9, 6, 9, 4] = {{(-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[9, 6, 9, 6] = {{-1 + (-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 6, 9, 8] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[9, 7, 9, 1] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 7, 9, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[9, 7, 9, 4] = {{-1 - (-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[9, 7, 9, 5] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[9, 7, 9, 7] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 7, 9, 8] = {{-1 + (-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 8, 9, 1] = {{-(-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 8, 9, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[9, 8, 9, 3] = {{(-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[9, 8, 9, 5] = {{-1 - (-1)^(2/3)}}
 
TY33Cat2FMatrixFunction[9, 8, 9, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat2FMatrixFunction[9, 8, 9, 7] = {{-1 + (-1)^(1/3)}}
 
TY33Cat2FMatrixFunction[9, 9, 9, 9] = {{-1/3, -1/3, -1/3, -1/3, -1/3, -1/3, 
     -1/3, -1/3, -1/3}, {-1/3, -1/3, -1/3, (-1)^(1/3)/3, (-1)^(1/3)/3, 
     (-1)^(1/3)/3, (1 - I*Sqrt[3])/6, (1 - I*Sqrt[3])/6, (1 - I*Sqrt[3])/6}, 
    {-1/3, -1/3, -1/3, (1 - I*Sqrt[3])/6, (1 - I*Sqrt[3])/6, 
     (1 - I*Sqrt[3])/6, (-1)^(1/3)/3, (-1)^(1/3)/3, (-1)^(1/3)/3}, 
    {-1/3, (-1)^(1/3)/3, (1 - I*Sqrt[3])/6, (1 + (-1)^(2/3))/3, 
     -(-1)^(2/3)/3, -1/3, (1 - (-1)^(1/3))/3, -1/3, (1 + I*Sqrt[3])/6}, 
    {-1/3, (-1)^(1/3)/3, (1 - I*Sqrt[3])/6, -(-1)^(2/3)/3, -1/3, 
     (1 + (-1)^(2/3))/3, (1 + I*Sqrt[3])/6, (1 - (-1)^(1/3))/3, -1/3}, 
    {-1/3, (-1)^(1/3)/3, (1 - I*Sqrt[3])/6, -1/3, (1 + (-1)^(2/3))/3, 
     (1 - I*Sqrt[3])/6, -1/3, (-1)^(1/3)/3, (1 - (-1)^(1/3))/3}, 
    {-1/3, (1 - I*Sqrt[3])/6, (-1)^(1/3)/3, (1 - (-1)^(1/3))/3, 
     (1 + I*Sqrt[3])/6, -1/3, (1 + (-1)^(2/3))/3, -1/3, -(-1)^(2/3)/3}, 
    {-1/3, (1 - I*Sqrt[3])/6, (-1)^(1/3)/3, -1/3, (1 - (-1)^(1/3))/3, 
     (-1)^(1/3)/3, -1/3, (1 - I*Sqrt[3])/6, (1 + (-1)^(2/3))/3}, 
    {-1/3, (1 - I*Sqrt[3])/6, (-1)^(1/3)/3, (1 + I*Sqrt[3])/6, -1/3, 
     (1 - (-1)^(1/3))/3, -(-1)^(2/3)/3, (1 + (-1)^(2/3))/3, -1/3}}
 
TY33Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY33Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TY33Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY33Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TY33Cat2Piv1] ^= {}
 
fusionCategory[TY33Cat2Piv1] ^= TY33Cat2
 
TY33Cat2Piv1 /: modularCategory[TY33Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY33Cat2Piv1] ^= TY33Cat2Piv1
 
pivotalIsomorphism[TY33Cat2Piv1] ^= TY33Cat2Piv1PivotalIsomorphism
 
ring[TY33Cat2Piv1] ^= TY33
 
sphericalCategory[TY33Cat2Piv1] ^= TY33Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[TY33Cat2]][pivotalCategory[#1]] & )[
    TY33Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TY33Cat2]][sphericalCategory[#1]] & )[
    TY33Cat2Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY33Cat2Piv1PivotalIsomorphism] ^= TY33Cat2
 
pivotalCategory[TY33Cat2Piv1PivotalIsomorphism] ^= TY33Cat2Piv1
 
pivotalIsomorphism[TY33Cat2Piv1PivotalIsomorphism] ^= 
   TY33Cat2Piv1PivotalIsomorphism
 
TY33Cat2Piv1PivotalIsomorphism[0] = 1
 
TY33Cat2Piv1PivotalIsomorphism[1] = 1
 
TY33Cat2Piv1PivotalIsomorphism[2] = 1
 
TY33Cat2Piv1PivotalIsomorphism[3] = 1
 
TY33Cat2Piv1PivotalIsomorphism[4] = 1
 
TY33Cat2Piv1PivotalIsomorphism[5] = 1
 
TY33Cat2Piv1PivotalIsomorphism[6] = 1
 
TY33Cat2Piv1PivotalIsomorphism[7] = 1
 
TY33Cat2Piv1PivotalIsomorphism[8] = 1
 
TY33Cat2Piv1PivotalIsomorphism[9] = 1
balancedCategories[TY33Cat2Piv2] ^= {}
 
fusionCategory[TY33Cat2Piv2] ^= TY33Cat2
 
TY33Cat2Piv2 /: modularCategory[TY33Cat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY33Cat2Piv2] ^= TY33Cat2Piv2
 
pivotalIsomorphism[TY33Cat2Piv2] ^= TY33Cat2Piv2PivotalIsomorphism
 
ring[TY33Cat2Piv2] ^= TY33
 
sphericalCategory[TY33Cat2Piv2] ^= TY33Cat2Piv2
 
(pivotalCategoryIndex[fusionCategory[TY33Cat2]][pivotalCategory[#1]] & )[
    TY33Cat2Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TY33Cat2]][sphericalCategory[#1]] & )[
    TY33Cat2Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY33Cat2Piv2PivotalIsomorphism] ^= TY33Cat2
 
pivotalCategory[TY33Cat2Piv2PivotalIsomorphism] ^= TY33Cat2Piv2
 
pivotalIsomorphism[TY33Cat2Piv2PivotalIsomorphism] ^= 
   TY33Cat2Piv2PivotalIsomorphism
 
TY33Cat2Piv2PivotalIsomorphism[0] = 1
 
TY33Cat2Piv2PivotalIsomorphism[1] = 1
 
TY33Cat2Piv2PivotalIsomorphism[2] = 1
 
TY33Cat2Piv2PivotalIsomorphism[3] = 1
 
TY33Cat2Piv2PivotalIsomorphism[4] = 1
 
TY33Cat2Piv2PivotalIsomorphism[5] = 1
 
TY33Cat2Piv2PivotalIsomorphism[6] = 1
 
TY33Cat2Piv2PivotalIsomorphism[7] = 1
 
TY33Cat2Piv2PivotalIsomorphism[8] = 1
 
TY33Cat2Piv2PivotalIsomorphism[9] = -1
balancedCategories[TY33Cat3] ^= {}
 
braidedCategories[TY33Cat3] ^= {}
 
coeval[TY33Cat3] ^= 1/sixJFunction[TY33Cat3][#1, dual[ring[TY33Cat3]][#1], 
      #1, #1, 0, 0] & 
 
eval[TY33Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TY33Cat3] ^= TY33Cat3FMatrixFunction
 
fusionCategory[TY33Cat3] ^= TY33Cat3
 
TY33Cat3 /: modularCategory[TY33Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TY33Cat3] ^= {TY33Cat3Piv1, TY33Cat3Piv2}
 
TY33Cat3 /: pivotalCategory[TY33Cat3, 1] = TY33Cat3Piv1
 
TY33Cat3 /: pivotalCategory[TY33Cat3, 2] = TY33Cat3Piv2
 
TY33Cat3 /: pivotalCategory[TY33Cat3, {1, 1, 1, 1, 1, 1, 1, 1, 1, -1}] = 
    TY33Cat3Piv2
 
TY33Cat3 /: pivotalCategory[TY33Cat3, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}] = 
    TY33Cat3Piv1
 
ring[TY33Cat3] ^= TY33
 
TY33Cat3 /: sphericalCategory[TY33Cat3, 1] = TY33Cat3Piv1
 
TY33Cat3 /: sphericalCategory[TY33Cat3, 2] = TY33Cat3Piv2
 
fusionCategoryIndex[TY33][TY33Cat3] ^= 3
fMatrixFunction[TY33Cat3FMatrixFunction] ^= TY33Cat3FMatrixFunction
 
fusionCategory[TY33Cat3FMatrixFunction] ^= TY33Cat3
 
ring[TY33Cat3FMatrixFunction] ^= TY33
 
TY33Cat3FMatrixFunction[1, 9, 1, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[1, 9, 2, 9] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[1, 9, 3, 9] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[1, 9, 5, 9] = {{-(-1)^(1/3)}}
 
TY33Cat3FMatrixFunction[1, 9, 6, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[1, 9, 7, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[2, 9, 1, 9] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[2, 9, 2, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[2, 9, 3, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[2, 9, 5, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[2, 9, 6, 9] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[2, 9, 7, 9] = {{-(-1)^(1/3)}}
 
TY33Cat3FMatrixFunction[3, 9, 1, 9] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[3, 9, 2, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[3, 9, 3, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[3, 9, 4, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[3, 9, 6, 9] = {{-(-1)^(1/3)}}
 
TY33Cat3FMatrixFunction[3, 9, 8, 9] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[4, 9, 3, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[4, 9, 4, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[4, 9, 5, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[4, 9, 6, 9] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[4, 9, 7, 9] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[4, 9, 8, 9] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[5, 9, 1, 9] = {{-(-1)^(1/3)}}
 
TY33Cat3FMatrixFunction[5, 9, 2, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[5, 9, 4, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[5, 9, 5, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[5, 9, 7, 9] = {{-(-1)^(1/3)}}
 
TY33Cat3FMatrixFunction[5, 9, 8, 9] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[6, 9, 1, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[6, 9, 2, 9] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[6, 9, 3, 9] = {{-(-1)^(1/3)}}
 
TY33Cat3FMatrixFunction[6, 9, 4, 9] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[6, 9, 6, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[6, 9, 8, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[7, 9, 1, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[7, 9, 2, 9] = {{-(-1)^(1/3)}}
 
TY33Cat3FMatrixFunction[7, 9, 4, 9] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[7, 9, 5, 9] = {{-(-1)^(1/3)}}
 
TY33Cat3FMatrixFunction[7, 9, 7, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[7, 9, 8, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[8, 9, 3, 9] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[8, 9, 4, 9] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[8, 9, 5, 9] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[8, 9, 6, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[8, 9, 7, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[8, 9, 8, 9] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 1, 9, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 1, 9, 2] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[9, 1, 9, 3] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[9, 1, 9, 5] = {{-(-1)^(1/3)}}
 
TY33Cat3FMatrixFunction[9, 1, 9, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 1, 9, 7] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 2, 9, 1] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[9, 2, 9, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 2, 9, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 2, 9, 5] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 2, 9, 6] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[9, 2, 9, 7] = {{-(-1)^(1/3)}}
 
TY33Cat3FMatrixFunction[9, 3, 9, 1] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[9, 3, 9, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 3, 9, 3] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 3, 9, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 3, 9, 6] = {{-(-1)^(1/3)}}
 
TY33Cat3FMatrixFunction[9, 3, 9, 8] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[9, 4, 9, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 4, 9, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 4, 9, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 4, 9, 6] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[9, 4, 9, 7] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[9, 4, 9, 8] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[9, 5, 9, 1] = {{-(-1)^(1/3)}}
 
TY33Cat3FMatrixFunction[9, 5, 9, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 5, 9, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 5, 9, 5] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 5, 9, 7] = {{-(-1)^(1/3)}}
 
TY33Cat3FMatrixFunction[9, 5, 9, 8] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[9, 6, 9, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 6, 9, 2] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[9, 6, 9, 3] = {{-(-1)^(1/3)}}
 
TY33Cat3FMatrixFunction[9, 6, 9, 4] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[9, 6, 9, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 6, 9, 8] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 7, 9, 1] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 7, 9, 2] = {{-(-1)^(1/3)}}
 
TY33Cat3FMatrixFunction[9, 7, 9, 4] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[9, 7, 9, 5] = {{-(-1)^(1/3)}}
 
TY33Cat3FMatrixFunction[9, 7, 9, 7] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 7, 9, 8] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 8, 9, 3] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[9, 8, 9, 4] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[9, 8, 9, 5] = {{(-1)^(2/3)}}
 
TY33Cat3FMatrixFunction[9, 8, 9, 6] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 8, 9, 7] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 8, 9, 8] = {{(-I/2)*(-I + Sqrt[3])}}
 
TY33Cat3FMatrixFunction[9, 9, 9, 9] = {{1/3, 1/3, 1/3, 1/3, 1/3, 1/3, 1/3, 
     1/3, 1/3}, {1/3, (-1)^(2/3)/3, (-I/6)*(-I + Sqrt[3]), 
     (-I/6)*(-I + Sqrt[3]), 1/3, (I/6)*(I + Sqrt[3]), (-1)^(2/3)/3, 
     -(-1)^(1/3)/3, 1/3}, {1/3, (-I/6)*(-I + Sqrt[3]), (-1)^(2/3)/3, 
     (-1)^(2/3)/3, 1/3, -(-1)^(1/3)/3, (-I/6)*(-I + Sqrt[3]), 
     (I/6)*(I + Sqrt[3]), 1/3}, {1/3, (-I/6)*(-I + Sqrt[3]), (-1)^(2/3)/3, 
     -(-1)^(1/3)/3, (-1)^(2/3)/3, 1/3, (I/6)*(I + Sqrt[3]), 1/3, 
     (-I/6)*(-I + Sqrt[3])}, {1/3, 1/3, 1/3, (-1)^(2/3)/3, (-1)^(2/3)/3, 
     (-1)^(2/3)/3, (-I/6)*(-I + Sqrt[3]), (-I/6)*(-I + Sqrt[3]), 
     (-I/6)*(-I + Sqrt[3])}, {1/3, (I/6)*(I + Sqrt[3]), -(-1)^(1/3)/3, 1/3, 
     (-1)^(2/3)/3, -(-1)^(1/3)/3, 1/3, (I/6)*(I + Sqrt[3]), 
     (-I/6)*(-I + Sqrt[3])}, {1/3, (-1)^(2/3)/3, (-I/6)*(-I + Sqrt[3]), 
     (I/6)*(I + Sqrt[3]), (-I/6)*(-I + Sqrt[3]), 1/3, -(-1)^(1/3)/3, 1/3, 
     (-1)^(2/3)/3}, {1/3, -(-1)^(1/3)/3, (I/6)*(I + Sqrt[3]), 1/3, 
     (-I/6)*(-I + Sqrt[3]), (I/6)*(I + Sqrt[3]), 1/3, -(-1)^(1/3)/3, 
     (-1)^(2/3)/3}, {1/3, 1/3, 1/3, (-I/6)*(-I + Sqrt[3]), 
     (-I/6)*(-I + Sqrt[3]), (-I/6)*(-I + Sqrt[3]), (-1)^(2/3)/3, 
     (-1)^(2/3)/3, (-1)^(2/3)/3}}
 
TY33Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY33Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TY33Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY33Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TY33Cat3Piv1] ^= {}
 
fusionCategory[TY33Cat3Piv1] ^= TY33Cat3
 
TY33Cat3Piv1 /: modularCategory[TY33Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY33Cat3Piv1] ^= TY33Cat3Piv1
 
pivotalIsomorphism[TY33Cat3Piv1] ^= TY33Cat3Piv1PivotalIsomorphism
 
ring[TY33Cat3Piv1] ^= TY33
 
sphericalCategory[TY33Cat3Piv1] ^= TY33Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[TY33Cat3]][pivotalCategory[#1]] & )[
    TY33Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TY33Cat3]][sphericalCategory[#1]] & )[
    TY33Cat3Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY33Cat3Piv1PivotalIsomorphism] ^= TY33Cat3
 
pivotalCategory[TY33Cat3Piv1PivotalIsomorphism] ^= TY33Cat3Piv1
 
pivotalIsomorphism[TY33Cat3Piv1PivotalIsomorphism] ^= 
   TY33Cat3Piv1PivotalIsomorphism
 
TY33Cat3Piv1PivotalIsomorphism[0] = 1
 
TY33Cat3Piv1PivotalIsomorphism[1] = 1
 
TY33Cat3Piv1PivotalIsomorphism[2] = 1
 
TY33Cat3Piv1PivotalIsomorphism[3] = 1
 
TY33Cat3Piv1PivotalIsomorphism[4] = 1
 
TY33Cat3Piv1PivotalIsomorphism[5] = 1
 
TY33Cat3Piv1PivotalIsomorphism[6] = 1
 
TY33Cat3Piv1PivotalIsomorphism[7] = 1
 
TY33Cat3Piv1PivotalIsomorphism[8] = 1
 
TY33Cat3Piv1PivotalIsomorphism[9] = 1
balancedCategories[TY33Cat3Piv2] ^= {}
 
fusionCategory[TY33Cat3Piv2] ^= TY33Cat3
 
TY33Cat3Piv2 /: modularCategory[TY33Cat3Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY33Cat3Piv2] ^= TY33Cat3Piv2
 
pivotalIsomorphism[TY33Cat3Piv2] ^= TY33Cat3Piv2PivotalIsomorphism
 
ring[TY33Cat3Piv2] ^= TY33
 
sphericalCategory[TY33Cat3Piv2] ^= TY33Cat3Piv2
 
(pivotalCategoryIndex[fusionCategory[TY33Cat3]][pivotalCategory[#1]] & )[
    TY33Cat3Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TY33Cat3]][sphericalCategory[#1]] & )[
    TY33Cat3Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY33Cat3Piv2PivotalIsomorphism] ^= TY33Cat3
 
pivotalCategory[TY33Cat3Piv2PivotalIsomorphism] ^= TY33Cat3Piv2
 
pivotalIsomorphism[TY33Cat3Piv2PivotalIsomorphism] ^= 
   TY33Cat3Piv2PivotalIsomorphism
 
TY33Cat3Piv2PivotalIsomorphism[0] = 1
 
TY33Cat3Piv2PivotalIsomorphism[1] = 1
 
TY33Cat3Piv2PivotalIsomorphism[2] = 1
 
TY33Cat3Piv2PivotalIsomorphism[3] = 1
 
TY33Cat3Piv2PivotalIsomorphism[4] = 1
 
TY33Cat3Piv2PivotalIsomorphism[5] = 1
 
TY33Cat3Piv2PivotalIsomorphism[6] = 1
 
TY33Cat3Piv2PivotalIsomorphism[7] = 1
 
TY33Cat3Piv2PivotalIsomorphism[8] = 1
 
TY33Cat3Piv2PivotalIsomorphism[9] = -1
balancedCategories[TY33Cat4] ^= {}
 
braidedCategories[TY33Cat4] ^= {}
 
coeval[TY33Cat4] ^= 1/sixJFunction[TY33Cat4][#1, dual[ring[TY33Cat4]][#1], 
      #1, #1, 0, 0] & 
 
eval[TY33Cat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[TY33Cat4] ^= TY33Cat4FMatrixFunction
 
fusionCategory[TY33Cat4] ^= TY33Cat4
 
TY33Cat4 /: modularCategory[TY33Cat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[TY33Cat4] ^= {TY33Cat4Piv1, TY33Cat4Piv2}
 
TY33Cat4 /: pivotalCategory[TY33Cat4, 1] = TY33Cat4Piv1
 
TY33Cat4 /: pivotalCategory[TY33Cat4, 2] = TY33Cat4Piv2
 
TY33Cat4 /: pivotalCategory[TY33Cat4, {1, 1, 1, 1, 1, 1, 1, 1, 1, -1}] = 
    TY33Cat4Piv2
 
TY33Cat4 /: pivotalCategory[TY33Cat4, {1, 1, 1, 1, 1, 1, 1, 1, 1, 1}] = 
    TY33Cat4Piv1
 
ring[TY33Cat4] ^= TY33
 
TY33Cat4 /: sphericalCategory[TY33Cat4, 1] = TY33Cat4Piv1
 
TY33Cat4 /: sphericalCategory[TY33Cat4, 2] = TY33Cat4Piv2
 
fusionCategoryIndex[TY33][TY33Cat4] ^= 4
fMatrixFunction[TY33Cat4FMatrixFunction] ^= TY33Cat4FMatrixFunction
 
fusionCategory[TY33Cat4FMatrixFunction] ^= TY33Cat4
 
ring[TY33Cat4FMatrixFunction] ^= TY33
 
TY33Cat4FMatrixFunction[1, 9, 1, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[1, 9, 2, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[1, 9, 3, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[1, 9, 5, 9] = {{(-1)^(2/3)}}
 
TY33Cat4FMatrixFunction[1, 9, 6, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[1, 9, 7, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[2, 9, 1, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[2, 9, 2, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[2, 9, 3, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[2, 9, 5, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[2, 9, 6, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[2, 9, 7, 9] = {{(-1)^(2/3)}}
 
TY33Cat4FMatrixFunction[3, 9, 1, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[3, 9, 2, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[3, 9, 3, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[3, 9, 4, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[3, 9, 6, 9] = {{(-1)^(2/3)}}
 
TY33Cat4FMatrixFunction[3, 9, 8, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[4, 9, 3, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[4, 9, 4, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[4, 9, 5, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[4, 9, 6, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[4, 9, 7, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[4, 9, 8, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[5, 9, 1, 9] = {{(-1)^(2/3)}}
 
TY33Cat4FMatrixFunction[5, 9, 2, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[5, 9, 4, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[5, 9, 5, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[5, 9, 7, 9] = {{(-1)^(2/3)}}
 
TY33Cat4FMatrixFunction[5, 9, 8, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[6, 9, 1, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[6, 9, 2, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[6, 9, 3, 9] = {{(-1)^(2/3)}}
 
TY33Cat4FMatrixFunction[6, 9, 4, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[6, 9, 6, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[6, 9, 8, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[7, 9, 1, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[7, 9, 2, 9] = {{(-1)^(2/3)}}
 
TY33Cat4FMatrixFunction[7, 9, 4, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[7, 9, 5, 9] = {{(-1)^(2/3)}}
 
TY33Cat4FMatrixFunction[7, 9, 7, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[7, 9, 8, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[8, 9, 3, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[8, 9, 4, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[8, 9, 5, 9] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[8, 9, 6, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[8, 9, 7, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[8, 9, 8, 9] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[9, 1, 9, 1] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[9, 1, 9, 2] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 1, 9, 3] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 1, 9, 5] = {{(-1)^(2/3)}}
 
TY33Cat4FMatrixFunction[9, 1, 9, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[9, 1, 9, 7] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 2, 9, 1] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 2, 9, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[9, 2, 9, 3] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[9, 2, 9, 5] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 2, 9, 6] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 2, 9, 7] = {{(-1)^(2/3)}}
 
TY33Cat4FMatrixFunction[9, 3, 9, 1] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 3, 9, 2] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[9, 3, 9, 3] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 3, 9, 4] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[9, 3, 9, 6] = {{(-1)^(2/3)}}
 
TY33Cat4FMatrixFunction[9, 3, 9, 8] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 4, 9, 3] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[9, 4, 9, 4] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[9, 4, 9, 5] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[9, 4, 9, 6] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 4, 9, 7] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 4, 9, 8] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 5, 9, 1] = {{(-1)^(2/3)}}
 
TY33Cat4FMatrixFunction[9, 5, 9, 2] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 5, 9, 4] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[9, 5, 9, 5] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 5, 9, 7] = {{(-1)^(2/3)}}
 
TY33Cat4FMatrixFunction[9, 5, 9, 8] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 6, 9, 1] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[9, 6, 9, 2] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 6, 9, 3] = {{(-1)^(2/3)}}
 
TY33Cat4FMatrixFunction[9, 6, 9, 4] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 6, 9, 6] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 6, 9, 8] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[9, 7, 9, 1] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 7, 9, 2] = {{(-1)^(2/3)}}
 
TY33Cat4FMatrixFunction[9, 7, 9, 4] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 7, 9, 5] = {{(-1)^(2/3)}}
 
TY33Cat4FMatrixFunction[9, 7, 9, 7] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 7, 9, 8] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[9, 8, 9, 3] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 8, 9, 4] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 8, 9, 5] = {{-(-1)^(1/3)}}
 
TY33Cat4FMatrixFunction[9, 8, 9, 6] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[9, 8, 9, 7] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[9, 8, 9, 8] = {{(I/2)*(I + Sqrt[3])}}
 
TY33Cat4FMatrixFunction[9, 9, 9, 9] = {{-1/3, -1/3, -1/3, -1/3, -1/3, -1/3, 
     -1/3, -1/3, -1/3}, {-1/3, (-1)^(1/3)/3, (1 - I*Sqrt[3])/6, 
     (1 - I*Sqrt[3])/6, -1/3, (1 + I*Sqrt[3])/6, (-1)^(1/3)/3, -(-1)^(2/3)/3, 
     -1/3}, {-1/3, (1 - I*Sqrt[3])/6, (-1)^(1/3)/3, (-1)^(1/3)/3, -1/3, 
     -(-1)^(2/3)/3, (1 - I*Sqrt[3])/6, (1 + I*Sqrt[3])/6, -1/3}, 
    {-1/3, (1 - I*Sqrt[3])/6, (-1)^(1/3)/3, -(-1)^(2/3)/3, (-1)^(1/3)/3, 
     -1/3, (1 + I*Sqrt[3])/6, -1/3, (1 - I*Sqrt[3])/6}, 
    {-1/3, -1/3, -1/3, (-1)^(1/3)/3, (-1)^(1/3)/3, (-1)^(1/3)/3, 
     (1 - I*Sqrt[3])/6, (1 - I*Sqrt[3])/6, (1 - I*Sqrt[3])/6}, 
    {-1/3, (1 + I*Sqrt[3])/6, -(-1)^(2/3)/3, -1/3, (-1)^(1/3)/3, 
     -(-1)^(2/3)/3, -1/3, (1 + I*Sqrt[3])/6, (1 - I*Sqrt[3])/6}, 
    {-1/3, (-1)^(1/3)/3, (1 - I*Sqrt[3])/6, (1 + I*Sqrt[3])/6, 
     (1 - I*Sqrt[3])/6, -1/3, -(-1)^(2/3)/3, -1/3, (-1)^(1/3)/3}, 
    {-1/3, -(-1)^(2/3)/3, (1 + I*Sqrt[3])/6, -1/3, (1 - I*Sqrt[3])/6, 
     (1 + I*Sqrt[3])/6, -1/3, -(-1)^(2/3)/3, (-1)^(1/3)/3}, 
    {-1/3, -1/3, -1/3, (1 - I*Sqrt[3])/6, (1 - I*Sqrt[3])/6, 
     (1 - I*Sqrt[3])/6, (-1)^(1/3)/3, (-1)^(1/3)/3, (-1)^(1/3)/3}}
 
TY33Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY33Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
TY33Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[TY33Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[TY33Cat4Piv1] ^= {}
 
fusionCategory[TY33Cat4Piv1] ^= TY33Cat4
 
TY33Cat4Piv1 /: modularCategory[TY33Cat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY33Cat4Piv1] ^= TY33Cat4Piv1
 
pivotalIsomorphism[TY33Cat4Piv1] ^= TY33Cat4Piv1PivotalIsomorphism
 
ring[TY33Cat4Piv1] ^= TY33
 
sphericalCategory[TY33Cat4Piv1] ^= TY33Cat4Piv1
 
(pivotalCategoryIndex[fusionCategory[TY33Cat4]][pivotalCategory[#1]] & )[
    TY33Cat4Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[TY33Cat4]][sphericalCategory[#1]] & )[
    TY33Cat4Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY33Cat4Piv1PivotalIsomorphism] ^= TY33Cat4
 
pivotalCategory[TY33Cat4Piv1PivotalIsomorphism] ^= TY33Cat4Piv1
 
pivotalIsomorphism[TY33Cat4Piv1PivotalIsomorphism] ^= 
   TY33Cat4Piv1PivotalIsomorphism
 
TY33Cat4Piv1PivotalIsomorphism[0] = 1
 
TY33Cat4Piv1PivotalIsomorphism[1] = 1
 
TY33Cat4Piv1PivotalIsomorphism[2] = 1
 
TY33Cat4Piv1PivotalIsomorphism[3] = 1
 
TY33Cat4Piv1PivotalIsomorphism[4] = 1
 
TY33Cat4Piv1PivotalIsomorphism[5] = 1
 
TY33Cat4Piv1PivotalIsomorphism[6] = 1
 
TY33Cat4Piv1PivotalIsomorphism[7] = 1
 
TY33Cat4Piv1PivotalIsomorphism[8] = 1
 
TY33Cat4Piv1PivotalIsomorphism[9] = 1
balancedCategories[TY33Cat4Piv2] ^= {}
 
fusionCategory[TY33Cat4Piv2] ^= TY33Cat4
 
TY33Cat4Piv2 /: modularCategory[TY33Cat4Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[TY33Cat4Piv2] ^= TY33Cat4Piv2
 
pivotalIsomorphism[TY33Cat4Piv2] ^= TY33Cat4Piv2PivotalIsomorphism
 
ring[TY33Cat4Piv2] ^= TY33
 
sphericalCategory[TY33Cat4Piv2] ^= TY33Cat4Piv2
 
(pivotalCategoryIndex[fusionCategory[TY33Cat4]][pivotalCategory[#1]] & )[
    TY33Cat4Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[TY33Cat4]][sphericalCategory[#1]] & )[
    TY33Cat4Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[TY33Cat4Piv2PivotalIsomorphism] ^= TY33Cat4
 
pivotalCategory[TY33Cat4Piv2PivotalIsomorphism] ^= TY33Cat4Piv2
 
pivotalIsomorphism[TY33Cat4Piv2PivotalIsomorphism] ^= 
   TY33Cat4Piv2PivotalIsomorphism
 
TY33Cat4Piv2PivotalIsomorphism[0] = 1
 
TY33Cat4Piv2PivotalIsomorphism[1] = 1
 
TY33Cat4Piv2PivotalIsomorphism[2] = 1
 
TY33Cat4Piv2PivotalIsomorphism[3] = 1
 
TY33Cat4Piv2PivotalIsomorphism[4] = 1
 
TY33Cat4Piv2PivotalIsomorphism[5] = 1
 
TY33Cat4Piv2PivotalIsomorphism[6] = 1
 
TY33Cat4Piv2PivotalIsomorphism[7] = 1
 
TY33Cat4Piv2PivotalIsomorphism[8] = 1
 
TY33Cat4Piv2PivotalIsomorphism[9] = -1
ring[TY33NFunction] ^= TY33
 
TY33NFunction[0, 0, 0] = 1
 
TY33NFunction[0, 0, 1] = 0
 
TY33NFunction[0, 0, 2] = 0
 
TY33NFunction[0, 0, 3] = 0
 
TY33NFunction[0, 0, 4] = 0
 
TY33NFunction[0, 0, 5] = 0
 
TY33NFunction[0, 0, 6] = 0
 
TY33NFunction[0, 0, 7] = 0
 
TY33NFunction[0, 0, 8] = 0
 
TY33NFunction[0, 0, 9] = 0
 
TY33NFunction[0, 1, 0] = 0
 
TY33NFunction[0, 1, 1] = 1
 
TY33NFunction[0, 1, 2] = 0
 
TY33NFunction[0, 1, 3] = 0
 
TY33NFunction[0, 1, 4] = 0
 
TY33NFunction[0, 1, 5] = 0
 
TY33NFunction[0, 1, 6] = 0
 
TY33NFunction[0, 1, 7] = 0
 
TY33NFunction[0, 1, 8] = 0
 
TY33NFunction[0, 1, 9] = 0
 
TY33NFunction[0, 2, 0] = 0
 
TY33NFunction[0, 2, 1] = 0
 
TY33NFunction[0, 2, 2] = 1
 
TY33NFunction[0, 2, 3] = 0
 
TY33NFunction[0, 2, 4] = 0
 
TY33NFunction[0, 2, 5] = 0
 
TY33NFunction[0, 2, 6] = 0
 
TY33NFunction[0, 2, 7] = 0
 
TY33NFunction[0, 2, 8] = 0
 
TY33NFunction[0, 2, 9] = 0
 
TY33NFunction[0, 3, 0] = 0
 
TY33NFunction[0, 3, 1] = 0
 
TY33NFunction[0, 3, 2] = 0
 
TY33NFunction[0, 3, 3] = 1
 
TY33NFunction[0, 3, 4] = 0
 
TY33NFunction[0, 3, 5] = 0
 
TY33NFunction[0, 3, 6] = 0
 
TY33NFunction[0, 3, 7] = 0
 
TY33NFunction[0, 3, 8] = 0
 
TY33NFunction[0, 3, 9] = 0
 
TY33NFunction[0, 4, 0] = 0
 
TY33NFunction[0, 4, 1] = 0
 
TY33NFunction[0, 4, 2] = 0
 
TY33NFunction[0, 4, 3] = 0
 
TY33NFunction[0, 4, 4] = 1
 
TY33NFunction[0, 4, 5] = 0
 
TY33NFunction[0, 4, 6] = 0
 
TY33NFunction[0, 4, 7] = 0
 
TY33NFunction[0, 4, 8] = 0
 
TY33NFunction[0, 4, 9] = 0
 
TY33NFunction[0, 5, 0] = 0
 
TY33NFunction[0, 5, 1] = 0
 
TY33NFunction[0, 5, 2] = 0
 
TY33NFunction[0, 5, 3] = 0
 
TY33NFunction[0, 5, 4] = 0
 
TY33NFunction[0, 5, 5] = 1
 
TY33NFunction[0, 5, 6] = 0
 
TY33NFunction[0, 5, 7] = 0
 
TY33NFunction[0, 5, 8] = 0
 
TY33NFunction[0, 5, 9] = 0
 
TY33NFunction[0, 6, 0] = 0
 
TY33NFunction[0, 6, 1] = 0
 
TY33NFunction[0, 6, 2] = 0
 
TY33NFunction[0, 6, 3] = 0
 
TY33NFunction[0, 6, 4] = 0
 
TY33NFunction[0, 6, 5] = 0
 
TY33NFunction[0, 6, 6] = 1
 
TY33NFunction[0, 6, 7] = 0
 
TY33NFunction[0, 6, 8] = 0
 
TY33NFunction[0, 6, 9] = 0
 
TY33NFunction[0, 7, 0] = 0
 
TY33NFunction[0, 7, 1] = 0
 
TY33NFunction[0, 7, 2] = 0
 
TY33NFunction[0, 7, 3] = 0
 
TY33NFunction[0, 7, 4] = 0
 
TY33NFunction[0, 7, 5] = 0
 
TY33NFunction[0, 7, 6] = 0
 
TY33NFunction[0, 7, 7] = 1
 
TY33NFunction[0, 7, 8] = 0
 
TY33NFunction[0, 7, 9] = 0
 
TY33NFunction[0, 8, 0] = 0
 
TY33NFunction[0, 8, 1] = 0
 
TY33NFunction[0, 8, 2] = 0
 
TY33NFunction[0, 8, 3] = 0
 
TY33NFunction[0, 8, 4] = 0
 
TY33NFunction[0, 8, 5] = 0
 
TY33NFunction[0, 8, 6] = 0
 
TY33NFunction[0, 8, 7] = 0
 
TY33NFunction[0, 8, 8] = 1
 
TY33NFunction[0, 8, 9] = 0
 
TY33NFunction[0, 9, 0] = 0
 
TY33NFunction[0, 9, 1] = 0
 
TY33NFunction[0, 9, 2] = 0
 
TY33NFunction[0, 9, 3] = 0
 
TY33NFunction[0, 9, 4] = 0
 
TY33NFunction[0, 9, 5] = 0
 
TY33NFunction[0, 9, 6] = 0
 
TY33NFunction[0, 9, 7] = 0
 
TY33NFunction[0, 9, 8] = 0
 
TY33NFunction[0, 9, 9] = 1
 
TY33NFunction[1, 0, 0] = 0
 
TY33NFunction[1, 0, 1] = 1
 
TY33NFunction[1, 0, 2] = 0
 
TY33NFunction[1, 0, 3] = 0
 
TY33NFunction[1, 0, 4] = 0
 
TY33NFunction[1, 0, 5] = 0
 
TY33NFunction[1, 0, 6] = 0
 
TY33NFunction[1, 0, 7] = 0
 
TY33NFunction[1, 0, 8] = 0
 
TY33NFunction[1, 0, 9] = 0
 
TY33NFunction[1, 1, 0] = 0
 
TY33NFunction[1, 1, 1] = 0
 
TY33NFunction[1, 1, 2] = 1
 
TY33NFunction[1, 1, 3] = 0
 
TY33NFunction[1, 1, 4] = 0
 
TY33NFunction[1, 1, 5] = 0
 
TY33NFunction[1, 1, 6] = 0
 
TY33NFunction[1, 1, 7] = 0
 
TY33NFunction[1, 1, 8] = 0
 
TY33NFunction[1, 1, 9] = 0
 
TY33NFunction[1, 2, 0] = 1
 
TY33NFunction[1, 2, 1] = 0
 
TY33NFunction[1, 2, 2] = 0
 
TY33NFunction[1, 2, 3] = 0
 
TY33NFunction[1, 2, 4] = 0
 
TY33NFunction[1, 2, 5] = 0
 
TY33NFunction[1, 2, 6] = 0
 
TY33NFunction[1, 2, 7] = 0
 
TY33NFunction[1, 2, 8] = 0
 
TY33NFunction[1, 2, 9] = 0
 
TY33NFunction[1, 3, 0] = 0
 
TY33NFunction[1, 3, 1] = 0
 
TY33NFunction[1, 3, 2] = 0
 
TY33NFunction[1, 3, 3] = 0
 
TY33NFunction[1, 3, 4] = 1
 
TY33NFunction[1, 3, 5] = 0
 
TY33NFunction[1, 3, 6] = 0
 
TY33NFunction[1, 3, 7] = 0
 
TY33NFunction[1, 3, 8] = 0
 
TY33NFunction[1, 3, 9] = 0
 
TY33NFunction[1, 4, 0] = 0
 
TY33NFunction[1, 4, 1] = 0
 
TY33NFunction[1, 4, 2] = 0
 
TY33NFunction[1, 4, 3] = 0
 
TY33NFunction[1, 4, 4] = 0
 
TY33NFunction[1, 4, 5] = 1
 
TY33NFunction[1, 4, 6] = 0
 
TY33NFunction[1, 4, 7] = 0
 
TY33NFunction[1, 4, 8] = 0
 
TY33NFunction[1, 4, 9] = 0
 
TY33NFunction[1, 5, 0] = 0
 
TY33NFunction[1, 5, 1] = 0
 
TY33NFunction[1, 5, 2] = 0
 
TY33NFunction[1, 5, 3] = 1
 
TY33NFunction[1, 5, 4] = 0
 
TY33NFunction[1, 5, 5] = 0
 
TY33NFunction[1, 5, 6] = 0
 
TY33NFunction[1, 5, 7] = 0
 
TY33NFunction[1, 5, 8] = 0
 
TY33NFunction[1, 5, 9] = 0
 
TY33NFunction[1, 6, 0] = 0
 
TY33NFunction[1, 6, 1] = 0
 
TY33NFunction[1, 6, 2] = 0
 
TY33NFunction[1, 6, 3] = 0
 
TY33NFunction[1, 6, 4] = 0
 
TY33NFunction[1, 6, 5] = 0
 
TY33NFunction[1, 6, 6] = 0
 
TY33NFunction[1, 6, 7] = 1
 
TY33NFunction[1, 6, 8] = 0
 
TY33NFunction[1, 6, 9] = 0
 
TY33NFunction[1, 7, 0] = 0
 
TY33NFunction[1, 7, 1] = 0
 
TY33NFunction[1, 7, 2] = 0
 
TY33NFunction[1, 7, 3] = 0
 
TY33NFunction[1, 7, 4] = 0
 
TY33NFunction[1, 7, 5] = 0
 
TY33NFunction[1, 7, 6] = 0
 
TY33NFunction[1, 7, 7] = 0
 
TY33NFunction[1, 7, 8] = 1
 
TY33NFunction[1, 7, 9] = 0
 
TY33NFunction[1, 8, 0] = 0
 
TY33NFunction[1, 8, 1] = 0
 
TY33NFunction[1, 8, 2] = 0
 
TY33NFunction[1, 8, 3] = 0
 
TY33NFunction[1, 8, 4] = 0
 
TY33NFunction[1, 8, 5] = 0
 
TY33NFunction[1, 8, 6] = 1
 
TY33NFunction[1, 8, 7] = 0
 
TY33NFunction[1, 8, 8] = 0
 
TY33NFunction[1, 8, 9] = 0
 
TY33NFunction[1, 9, 0] = 0
 
TY33NFunction[1, 9, 1] = 0
 
TY33NFunction[1, 9, 2] = 0
 
TY33NFunction[1, 9, 3] = 0
 
TY33NFunction[1, 9, 4] = 0
 
TY33NFunction[1, 9, 5] = 0
 
TY33NFunction[1, 9, 6] = 0
 
TY33NFunction[1, 9, 7] = 0
 
TY33NFunction[1, 9, 8] = 0
 
TY33NFunction[1, 9, 9] = 1
 
TY33NFunction[2, 0, 0] = 0
 
TY33NFunction[2, 0, 1] = 0
 
TY33NFunction[2, 0, 2] = 1
 
TY33NFunction[2, 0, 3] = 0
 
TY33NFunction[2, 0, 4] = 0
 
TY33NFunction[2, 0, 5] = 0
 
TY33NFunction[2, 0, 6] = 0
 
TY33NFunction[2, 0, 7] = 0
 
TY33NFunction[2, 0, 8] = 0
 
TY33NFunction[2, 0, 9] = 0
 
TY33NFunction[2, 1, 0] = 1
 
TY33NFunction[2, 1, 1] = 0
 
TY33NFunction[2, 1, 2] = 0
 
TY33NFunction[2, 1, 3] = 0
 
TY33NFunction[2, 1, 4] = 0
 
TY33NFunction[2, 1, 5] = 0
 
TY33NFunction[2, 1, 6] = 0
 
TY33NFunction[2, 1, 7] = 0
 
TY33NFunction[2, 1, 8] = 0
 
TY33NFunction[2, 1, 9] = 0
 
TY33NFunction[2, 2, 0] = 0
 
TY33NFunction[2, 2, 1] = 1
 
TY33NFunction[2, 2, 2] = 0
 
TY33NFunction[2, 2, 3] = 0
 
TY33NFunction[2, 2, 4] = 0
 
TY33NFunction[2, 2, 5] = 0
 
TY33NFunction[2, 2, 6] = 0
 
TY33NFunction[2, 2, 7] = 0
 
TY33NFunction[2, 2, 8] = 0
 
TY33NFunction[2, 2, 9] = 0
 
TY33NFunction[2, 3, 0] = 0
 
TY33NFunction[2, 3, 1] = 0
 
TY33NFunction[2, 3, 2] = 0
 
TY33NFunction[2, 3, 3] = 0
 
TY33NFunction[2, 3, 4] = 0
 
TY33NFunction[2, 3, 5] = 1
 
TY33NFunction[2, 3, 6] = 0
 
TY33NFunction[2, 3, 7] = 0
 
TY33NFunction[2, 3, 8] = 0
 
TY33NFunction[2, 3, 9] = 0
 
TY33NFunction[2, 4, 0] = 0
 
TY33NFunction[2, 4, 1] = 0
 
TY33NFunction[2, 4, 2] = 0
 
TY33NFunction[2, 4, 3] = 1
 
TY33NFunction[2, 4, 4] = 0
 
TY33NFunction[2, 4, 5] = 0
 
TY33NFunction[2, 4, 6] = 0
 
TY33NFunction[2, 4, 7] = 0
 
TY33NFunction[2, 4, 8] = 0
 
TY33NFunction[2, 4, 9] = 0
 
TY33NFunction[2, 5, 0] = 0
 
TY33NFunction[2, 5, 1] = 0
 
TY33NFunction[2, 5, 2] = 0
 
TY33NFunction[2, 5, 3] = 0
 
TY33NFunction[2, 5, 4] = 1
 
TY33NFunction[2, 5, 5] = 0
 
TY33NFunction[2, 5, 6] = 0
 
TY33NFunction[2, 5, 7] = 0
 
TY33NFunction[2, 5, 8] = 0
 
TY33NFunction[2, 5, 9] = 0
 
TY33NFunction[2, 6, 0] = 0
 
TY33NFunction[2, 6, 1] = 0
 
TY33NFunction[2, 6, 2] = 0
 
TY33NFunction[2, 6, 3] = 0
 
TY33NFunction[2, 6, 4] = 0
 
TY33NFunction[2, 6, 5] = 0
 
TY33NFunction[2, 6, 6] = 0
 
TY33NFunction[2, 6, 7] = 0
 
TY33NFunction[2, 6, 8] = 1
 
TY33NFunction[2, 6, 9] = 0
 
TY33NFunction[2, 7, 0] = 0
 
TY33NFunction[2, 7, 1] = 0
 
TY33NFunction[2, 7, 2] = 0
 
TY33NFunction[2, 7, 3] = 0
 
TY33NFunction[2, 7, 4] = 0
 
TY33NFunction[2, 7, 5] = 0
 
TY33NFunction[2, 7, 6] = 1
 
TY33NFunction[2, 7, 7] = 0
 
TY33NFunction[2, 7, 8] = 0
 
TY33NFunction[2, 7, 9] = 0
 
TY33NFunction[2, 8, 0] = 0
 
TY33NFunction[2, 8, 1] = 0
 
TY33NFunction[2, 8, 2] = 0
 
TY33NFunction[2, 8, 3] = 0
 
TY33NFunction[2, 8, 4] = 0
 
TY33NFunction[2, 8, 5] = 0
 
TY33NFunction[2, 8, 6] = 0
 
TY33NFunction[2, 8, 7] = 1
 
TY33NFunction[2, 8, 8] = 0
 
TY33NFunction[2, 8, 9] = 0
 
TY33NFunction[2, 9, 0] = 0
 
TY33NFunction[2, 9, 1] = 0
 
TY33NFunction[2, 9, 2] = 0
 
TY33NFunction[2, 9, 3] = 0
 
TY33NFunction[2, 9, 4] = 0
 
TY33NFunction[2, 9, 5] = 0
 
TY33NFunction[2, 9, 6] = 0
 
TY33NFunction[2, 9, 7] = 0
 
TY33NFunction[2, 9, 8] = 0
 
TY33NFunction[2, 9, 9] = 1
 
TY33NFunction[3, 0, 0] = 0
 
TY33NFunction[3, 0, 1] = 0
 
TY33NFunction[3, 0, 2] = 0
 
TY33NFunction[3, 0, 3] = 1
 
TY33NFunction[3, 0, 4] = 0
 
TY33NFunction[3, 0, 5] = 0
 
TY33NFunction[3, 0, 6] = 0
 
TY33NFunction[3, 0, 7] = 0
 
TY33NFunction[3, 0, 8] = 0
 
TY33NFunction[3, 0, 9] = 0
 
TY33NFunction[3, 1, 0] = 0
 
TY33NFunction[3, 1, 1] = 0
 
TY33NFunction[3, 1, 2] = 0
 
TY33NFunction[3, 1, 3] = 0
 
TY33NFunction[3, 1, 4] = 1
 
TY33NFunction[3, 1, 5] = 0
 
TY33NFunction[3, 1, 6] = 0
 
TY33NFunction[3, 1, 7] = 0
 
TY33NFunction[3, 1, 8] = 0
 
TY33NFunction[3, 1, 9] = 0
 
TY33NFunction[3, 2, 0] = 0
 
TY33NFunction[3, 2, 1] = 0
 
TY33NFunction[3, 2, 2] = 0
 
TY33NFunction[3, 2, 3] = 0
 
TY33NFunction[3, 2, 4] = 0
 
TY33NFunction[3, 2, 5] = 1
 
TY33NFunction[3, 2, 6] = 0
 
TY33NFunction[3, 2, 7] = 0
 
TY33NFunction[3, 2, 8] = 0
 
TY33NFunction[3, 2, 9] = 0
 
TY33NFunction[3, 3, 0] = 0
 
TY33NFunction[3, 3, 1] = 0
 
TY33NFunction[3, 3, 2] = 0
 
TY33NFunction[3, 3, 3] = 0
 
TY33NFunction[3, 3, 4] = 0
 
TY33NFunction[3, 3, 5] = 0
 
TY33NFunction[3, 3, 6] = 1
 
TY33NFunction[3, 3, 7] = 0
 
TY33NFunction[3, 3, 8] = 0
 
TY33NFunction[3, 3, 9] = 0
 
TY33NFunction[3, 4, 0] = 0
 
TY33NFunction[3, 4, 1] = 0
 
TY33NFunction[3, 4, 2] = 0
 
TY33NFunction[3, 4, 3] = 0
 
TY33NFunction[3, 4, 4] = 0
 
TY33NFunction[3, 4, 5] = 0
 
TY33NFunction[3, 4, 6] = 0
 
TY33NFunction[3, 4, 7] = 1
 
TY33NFunction[3, 4, 8] = 0
 
TY33NFunction[3, 4, 9] = 0
 
TY33NFunction[3, 5, 0] = 0
 
TY33NFunction[3, 5, 1] = 0
 
TY33NFunction[3, 5, 2] = 0
 
TY33NFunction[3, 5, 3] = 0
 
TY33NFunction[3, 5, 4] = 0
 
TY33NFunction[3, 5, 5] = 0
 
TY33NFunction[3, 5, 6] = 0
 
TY33NFunction[3, 5, 7] = 0
 
TY33NFunction[3, 5, 8] = 1
 
TY33NFunction[3, 5, 9] = 0
 
TY33NFunction[3, 6, 0] = 1
 
TY33NFunction[3, 6, 1] = 0
 
TY33NFunction[3, 6, 2] = 0
 
TY33NFunction[3, 6, 3] = 0
 
TY33NFunction[3, 6, 4] = 0
 
TY33NFunction[3, 6, 5] = 0
 
TY33NFunction[3, 6, 6] = 0
 
TY33NFunction[3, 6, 7] = 0
 
TY33NFunction[3, 6, 8] = 0
 
TY33NFunction[3, 6, 9] = 0
 
TY33NFunction[3, 7, 0] = 0
 
TY33NFunction[3, 7, 1] = 1
 
TY33NFunction[3, 7, 2] = 0
 
TY33NFunction[3, 7, 3] = 0
 
TY33NFunction[3, 7, 4] = 0
 
TY33NFunction[3, 7, 5] = 0
 
TY33NFunction[3, 7, 6] = 0
 
TY33NFunction[3, 7, 7] = 0
 
TY33NFunction[3, 7, 8] = 0
 
TY33NFunction[3, 7, 9] = 0
 
TY33NFunction[3, 8, 0] = 0
 
TY33NFunction[3, 8, 1] = 0
 
TY33NFunction[3, 8, 2] = 1
 
TY33NFunction[3, 8, 3] = 0
 
TY33NFunction[3, 8, 4] = 0
 
TY33NFunction[3, 8, 5] = 0
 
TY33NFunction[3, 8, 6] = 0
 
TY33NFunction[3, 8, 7] = 0
 
TY33NFunction[3, 8, 8] = 0
 
TY33NFunction[3, 8, 9] = 0
 
TY33NFunction[3, 9, 0] = 0
 
TY33NFunction[3, 9, 1] = 0
 
TY33NFunction[3, 9, 2] = 0
 
TY33NFunction[3, 9, 3] = 0
 
TY33NFunction[3, 9, 4] = 0
 
TY33NFunction[3, 9, 5] = 0
 
TY33NFunction[3, 9, 6] = 0
 
TY33NFunction[3, 9, 7] = 0
 
TY33NFunction[3, 9, 8] = 0
 
TY33NFunction[3, 9, 9] = 1
 
TY33NFunction[4, 0, 0] = 0
 
TY33NFunction[4, 0, 1] = 0
 
TY33NFunction[4, 0, 2] = 0
 
TY33NFunction[4, 0, 3] = 0
 
TY33NFunction[4, 0, 4] = 1
 
TY33NFunction[4, 0, 5] = 0
 
TY33NFunction[4, 0, 6] = 0
 
TY33NFunction[4, 0, 7] = 0
 
TY33NFunction[4, 0, 8] = 0
 
TY33NFunction[4, 0, 9] = 0
 
TY33NFunction[4, 1, 0] = 0
 
TY33NFunction[4, 1, 1] = 0
 
TY33NFunction[4, 1, 2] = 0
 
TY33NFunction[4, 1, 3] = 0
 
TY33NFunction[4, 1, 4] = 0
 
TY33NFunction[4, 1, 5] = 1
 
TY33NFunction[4, 1, 6] = 0
 
TY33NFunction[4, 1, 7] = 0
 
TY33NFunction[4, 1, 8] = 0
 
TY33NFunction[4, 1, 9] = 0
 
TY33NFunction[4, 2, 0] = 0
 
TY33NFunction[4, 2, 1] = 0
 
TY33NFunction[4, 2, 2] = 0
 
TY33NFunction[4, 2, 3] = 1
 
TY33NFunction[4, 2, 4] = 0
 
TY33NFunction[4, 2, 5] = 0
 
TY33NFunction[4, 2, 6] = 0
 
TY33NFunction[4, 2, 7] = 0
 
TY33NFunction[4, 2, 8] = 0
 
TY33NFunction[4, 2, 9] = 0
 
TY33NFunction[4, 3, 0] = 0
 
TY33NFunction[4, 3, 1] = 0
 
TY33NFunction[4, 3, 2] = 0
 
TY33NFunction[4, 3, 3] = 0
 
TY33NFunction[4, 3, 4] = 0
 
TY33NFunction[4, 3, 5] = 0
 
TY33NFunction[4, 3, 6] = 0
 
TY33NFunction[4, 3, 7] = 1
 
TY33NFunction[4, 3, 8] = 0
 
TY33NFunction[4, 3, 9] = 0
 
TY33NFunction[4, 4, 0] = 0
 
TY33NFunction[4, 4, 1] = 0
 
TY33NFunction[4, 4, 2] = 0
 
TY33NFunction[4, 4, 3] = 0
 
TY33NFunction[4, 4, 4] = 0
 
TY33NFunction[4, 4, 5] = 0
 
TY33NFunction[4, 4, 6] = 0
 
TY33NFunction[4, 4, 7] = 0
 
TY33NFunction[4, 4, 8] = 1
 
TY33NFunction[4, 4, 9] = 0
 
TY33NFunction[4, 5, 0] = 0
 
TY33NFunction[4, 5, 1] = 0
 
TY33NFunction[4, 5, 2] = 0
 
TY33NFunction[4, 5, 3] = 0
 
TY33NFunction[4, 5, 4] = 0
 
TY33NFunction[4, 5, 5] = 0
 
TY33NFunction[4, 5, 6] = 1
 
TY33NFunction[4, 5, 7] = 0
 
TY33NFunction[4, 5, 8] = 0
 
TY33NFunction[4, 5, 9] = 0
 
TY33NFunction[4, 6, 0] = 0
 
TY33NFunction[4, 6, 1] = 1
 
TY33NFunction[4, 6, 2] = 0
 
TY33NFunction[4, 6, 3] = 0
 
TY33NFunction[4, 6, 4] = 0
 
TY33NFunction[4, 6, 5] = 0
 
TY33NFunction[4, 6, 6] = 0
 
TY33NFunction[4, 6, 7] = 0
 
TY33NFunction[4, 6, 8] = 0
 
TY33NFunction[4, 6, 9] = 0
 
TY33NFunction[4, 7, 0] = 0
 
TY33NFunction[4, 7, 1] = 0
 
TY33NFunction[4, 7, 2] = 1
 
TY33NFunction[4, 7, 3] = 0
 
TY33NFunction[4, 7, 4] = 0
 
TY33NFunction[4, 7, 5] = 0
 
TY33NFunction[4, 7, 6] = 0
 
TY33NFunction[4, 7, 7] = 0
 
TY33NFunction[4, 7, 8] = 0
 
TY33NFunction[4, 7, 9] = 0
 
TY33NFunction[4, 8, 0] = 1
 
TY33NFunction[4, 8, 1] = 0
 
TY33NFunction[4, 8, 2] = 0
 
TY33NFunction[4, 8, 3] = 0
 
TY33NFunction[4, 8, 4] = 0
 
TY33NFunction[4, 8, 5] = 0
 
TY33NFunction[4, 8, 6] = 0
 
TY33NFunction[4, 8, 7] = 0
 
TY33NFunction[4, 8, 8] = 0
 
TY33NFunction[4, 8, 9] = 0
 
TY33NFunction[4, 9, 0] = 0
 
TY33NFunction[4, 9, 1] = 0
 
TY33NFunction[4, 9, 2] = 0
 
TY33NFunction[4, 9, 3] = 0
 
TY33NFunction[4, 9, 4] = 0
 
TY33NFunction[4, 9, 5] = 0
 
TY33NFunction[4, 9, 6] = 0
 
TY33NFunction[4, 9, 7] = 0
 
TY33NFunction[4, 9, 8] = 0
 
TY33NFunction[4, 9, 9] = 1
 
TY33NFunction[5, 0, 0] = 0
 
TY33NFunction[5, 0, 1] = 0
 
TY33NFunction[5, 0, 2] = 0
 
TY33NFunction[5, 0, 3] = 0
 
TY33NFunction[5, 0, 4] = 0
 
TY33NFunction[5, 0, 5] = 1
 
TY33NFunction[5, 0, 6] = 0
 
TY33NFunction[5, 0, 7] = 0
 
TY33NFunction[5, 0, 8] = 0
 
TY33NFunction[5, 0, 9] = 0
 
TY33NFunction[5, 1, 0] = 0
 
TY33NFunction[5, 1, 1] = 0
 
TY33NFunction[5, 1, 2] = 0
 
TY33NFunction[5, 1, 3] = 1
 
TY33NFunction[5, 1, 4] = 0
 
TY33NFunction[5, 1, 5] = 0
 
TY33NFunction[5, 1, 6] = 0
 
TY33NFunction[5, 1, 7] = 0
 
TY33NFunction[5, 1, 8] = 0
 
TY33NFunction[5, 1, 9] = 0
 
TY33NFunction[5, 2, 0] = 0
 
TY33NFunction[5, 2, 1] = 0
 
TY33NFunction[5, 2, 2] = 0
 
TY33NFunction[5, 2, 3] = 0
 
TY33NFunction[5, 2, 4] = 1
 
TY33NFunction[5, 2, 5] = 0
 
TY33NFunction[5, 2, 6] = 0
 
TY33NFunction[5, 2, 7] = 0
 
TY33NFunction[5, 2, 8] = 0
 
TY33NFunction[5, 2, 9] = 0
 
TY33NFunction[5, 3, 0] = 0
 
TY33NFunction[5, 3, 1] = 0
 
TY33NFunction[5, 3, 2] = 0
 
TY33NFunction[5, 3, 3] = 0
 
TY33NFunction[5, 3, 4] = 0
 
TY33NFunction[5, 3, 5] = 0
 
TY33NFunction[5, 3, 6] = 0
 
TY33NFunction[5, 3, 7] = 0
 
TY33NFunction[5, 3, 8] = 1
 
TY33NFunction[5, 3, 9] = 0
 
TY33NFunction[5, 4, 0] = 0
 
TY33NFunction[5, 4, 1] = 0
 
TY33NFunction[5, 4, 2] = 0
 
TY33NFunction[5, 4, 3] = 0
 
TY33NFunction[5, 4, 4] = 0
 
TY33NFunction[5, 4, 5] = 0
 
TY33NFunction[5, 4, 6] = 1
 
TY33NFunction[5, 4, 7] = 0
 
TY33NFunction[5, 4, 8] = 0
 
TY33NFunction[5, 4, 9] = 0
 
TY33NFunction[5, 5, 0] = 0
 
TY33NFunction[5, 5, 1] = 0
 
TY33NFunction[5, 5, 2] = 0
 
TY33NFunction[5, 5, 3] = 0
 
TY33NFunction[5, 5, 4] = 0
 
TY33NFunction[5, 5, 5] = 0
 
TY33NFunction[5, 5, 6] = 0
 
TY33NFunction[5, 5, 7] = 1
 
TY33NFunction[5, 5, 8] = 0
 
TY33NFunction[5, 5, 9] = 0
 
TY33NFunction[5, 6, 0] = 0
 
TY33NFunction[5, 6, 1] = 0
 
TY33NFunction[5, 6, 2] = 1
 
TY33NFunction[5, 6, 3] = 0
 
TY33NFunction[5, 6, 4] = 0
 
TY33NFunction[5, 6, 5] = 0
 
TY33NFunction[5, 6, 6] = 0
 
TY33NFunction[5, 6, 7] = 0
 
TY33NFunction[5, 6, 8] = 0
 
TY33NFunction[5, 6, 9] = 0
 
TY33NFunction[5, 7, 0] = 1
 
TY33NFunction[5, 7, 1] = 0
 
TY33NFunction[5, 7, 2] = 0
 
TY33NFunction[5, 7, 3] = 0
 
TY33NFunction[5, 7, 4] = 0
 
TY33NFunction[5, 7, 5] = 0
 
TY33NFunction[5, 7, 6] = 0
 
TY33NFunction[5, 7, 7] = 0
 
TY33NFunction[5, 7, 8] = 0
 
TY33NFunction[5, 7, 9] = 0
 
TY33NFunction[5, 8, 0] = 0
 
TY33NFunction[5, 8, 1] = 1
 
TY33NFunction[5, 8, 2] = 0
 
TY33NFunction[5, 8, 3] = 0
 
TY33NFunction[5, 8, 4] = 0
 
TY33NFunction[5, 8, 5] = 0
 
TY33NFunction[5, 8, 6] = 0
 
TY33NFunction[5, 8, 7] = 0
 
TY33NFunction[5, 8, 8] = 0
 
TY33NFunction[5, 8, 9] = 0
 
TY33NFunction[5, 9, 0] = 0
 
TY33NFunction[5, 9, 1] = 0
 
TY33NFunction[5, 9, 2] = 0
 
TY33NFunction[5, 9, 3] = 0
 
TY33NFunction[5, 9, 4] = 0
 
TY33NFunction[5, 9, 5] = 0
 
TY33NFunction[5, 9, 6] = 0
 
TY33NFunction[5, 9, 7] = 0
 
TY33NFunction[5, 9, 8] = 0
 
TY33NFunction[5, 9, 9] = 1
 
TY33NFunction[6, 0, 0] = 0
 
TY33NFunction[6, 0, 1] = 0
 
TY33NFunction[6, 0, 2] = 0
 
TY33NFunction[6, 0, 3] = 0
 
TY33NFunction[6, 0, 4] = 0
 
TY33NFunction[6, 0, 5] = 0
 
TY33NFunction[6, 0, 6] = 1
 
TY33NFunction[6, 0, 7] = 0
 
TY33NFunction[6, 0, 8] = 0
 
TY33NFunction[6, 0, 9] = 0
 
TY33NFunction[6, 1, 0] = 0
 
TY33NFunction[6, 1, 1] = 0
 
TY33NFunction[6, 1, 2] = 0
 
TY33NFunction[6, 1, 3] = 0
 
TY33NFunction[6, 1, 4] = 0
 
TY33NFunction[6, 1, 5] = 0
 
TY33NFunction[6, 1, 6] = 0
 
TY33NFunction[6, 1, 7] = 1
 
TY33NFunction[6, 1, 8] = 0
 
TY33NFunction[6, 1, 9] = 0
 
TY33NFunction[6, 2, 0] = 0
 
TY33NFunction[6, 2, 1] = 0
 
TY33NFunction[6, 2, 2] = 0
 
TY33NFunction[6, 2, 3] = 0
 
TY33NFunction[6, 2, 4] = 0
 
TY33NFunction[6, 2, 5] = 0
 
TY33NFunction[6, 2, 6] = 0
 
TY33NFunction[6, 2, 7] = 0
 
TY33NFunction[6, 2, 8] = 1
 
TY33NFunction[6, 2, 9] = 0
 
TY33NFunction[6, 3, 0] = 1
 
TY33NFunction[6, 3, 1] = 0
 
TY33NFunction[6, 3, 2] = 0
 
TY33NFunction[6, 3, 3] = 0
 
TY33NFunction[6, 3, 4] = 0
 
TY33NFunction[6, 3, 5] = 0
 
TY33NFunction[6, 3, 6] = 0
 
TY33NFunction[6, 3, 7] = 0
 
TY33NFunction[6, 3, 8] = 0
 
TY33NFunction[6, 3, 9] = 0
 
TY33NFunction[6, 4, 0] = 0
 
TY33NFunction[6, 4, 1] = 1
 
TY33NFunction[6, 4, 2] = 0
 
TY33NFunction[6, 4, 3] = 0
 
TY33NFunction[6, 4, 4] = 0
 
TY33NFunction[6, 4, 5] = 0
 
TY33NFunction[6, 4, 6] = 0
 
TY33NFunction[6, 4, 7] = 0
 
TY33NFunction[6, 4, 8] = 0
 
TY33NFunction[6, 4, 9] = 0
 
TY33NFunction[6, 5, 0] = 0
 
TY33NFunction[6, 5, 1] = 0
 
TY33NFunction[6, 5, 2] = 1
 
TY33NFunction[6, 5, 3] = 0
 
TY33NFunction[6, 5, 4] = 0
 
TY33NFunction[6, 5, 5] = 0
 
TY33NFunction[6, 5, 6] = 0
 
TY33NFunction[6, 5, 7] = 0
 
TY33NFunction[6, 5, 8] = 0
 
TY33NFunction[6, 5, 9] = 0
 
TY33NFunction[6, 6, 0] = 0
 
TY33NFunction[6, 6, 1] = 0
 
TY33NFunction[6, 6, 2] = 0
 
TY33NFunction[6, 6, 3] = 1
 
TY33NFunction[6, 6, 4] = 0
 
TY33NFunction[6, 6, 5] = 0
 
TY33NFunction[6, 6, 6] = 0
 
TY33NFunction[6, 6, 7] = 0
 
TY33NFunction[6, 6, 8] = 0
 
TY33NFunction[6, 6, 9] = 0
 
TY33NFunction[6, 7, 0] = 0
 
TY33NFunction[6, 7, 1] = 0
 
TY33NFunction[6, 7, 2] = 0
 
TY33NFunction[6, 7, 3] = 0
 
TY33NFunction[6, 7, 4] = 1
 
TY33NFunction[6, 7, 5] = 0
 
TY33NFunction[6, 7, 6] = 0
 
TY33NFunction[6, 7, 7] = 0
 
TY33NFunction[6, 7, 8] = 0
 
TY33NFunction[6, 7, 9] = 0
 
TY33NFunction[6, 8, 0] = 0
 
TY33NFunction[6, 8, 1] = 0
 
TY33NFunction[6, 8, 2] = 0
 
TY33NFunction[6, 8, 3] = 0
 
TY33NFunction[6, 8, 4] = 0
 
TY33NFunction[6, 8, 5] = 1
 
TY33NFunction[6, 8, 6] = 0
 
TY33NFunction[6, 8, 7] = 0
 
TY33NFunction[6, 8, 8] = 0
 
TY33NFunction[6, 8, 9] = 0
 
TY33NFunction[6, 9, 0] = 0
 
TY33NFunction[6, 9, 1] = 0
 
TY33NFunction[6, 9, 2] = 0
 
TY33NFunction[6, 9, 3] = 0
 
TY33NFunction[6, 9, 4] = 0
 
TY33NFunction[6, 9, 5] = 0
 
TY33NFunction[6, 9, 6] = 0
 
TY33NFunction[6, 9, 7] = 0
 
TY33NFunction[6, 9, 8] = 0
 
TY33NFunction[6, 9, 9] = 1
 
TY33NFunction[7, 0, 0] = 0
 
TY33NFunction[7, 0, 1] = 0
 
TY33NFunction[7, 0, 2] = 0
 
TY33NFunction[7, 0, 3] = 0
 
TY33NFunction[7, 0, 4] = 0
 
TY33NFunction[7, 0, 5] = 0
 
TY33NFunction[7, 0, 6] = 0
 
TY33NFunction[7, 0, 7] = 1
 
TY33NFunction[7, 0, 8] = 0
 
TY33NFunction[7, 0, 9] = 0
 
TY33NFunction[7, 1, 0] = 0
 
TY33NFunction[7, 1, 1] = 0
 
TY33NFunction[7, 1, 2] = 0
 
TY33NFunction[7, 1, 3] = 0
 
TY33NFunction[7, 1, 4] = 0
 
TY33NFunction[7, 1, 5] = 0
 
TY33NFunction[7, 1, 6] = 0
 
TY33NFunction[7, 1, 7] = 0
 
TY33NFunction[7, 1, 8] = 1
 
TY33NFunction[7, 1, 9] = 0
 
TY33NFunction[7, 2, 0] = 0
 
TY33NFunction[7, 2, 1] = 0
 
TY33NFunction[7, 2, 2] = 0
 
TY33NFunction[7, 2, 3] = 0
 
TY33NFunction[7, 2, 4] = 0
 
TY33NFunction[7, 2, 5] = 0
 
TY33NFunction[7, 2, 6] = 1
 
TY33NFunction[7, 2, 7] = 0
 
TY33NFunction[7, 2, 8] = 0
 
TY33NFunction[7, 2, 9] = 0
 
TY33NFunction[7, 3, 0] = 0
 
TY33NFunction[7, 3, 1] = 1
 
TY33NFunction[7, 3, 2] = 0
 
TY33NFunction[7, 3, 3] = 0
 
TY33NFunction[7, 3, 4] = 0
 
TY33NFunction[7, 3, 5] = 0
 
TY33NFunction[7, 3, 6] = 0
 
TY33NFunction[7, 3, 7] = 0
 
TY33NFunction[7, 3, 8] = 0
 
TY33NFunction[7, 3, 9] = 0
 
TY33NFunction[7, 4, 0] = 0
 
TY33NFunction[7, 4, 1] = 0
 
TY33NFunction[7, 4, 2] = 1
 
TY33NFunction[7, 4, 3] = 0
 
TY33NFunction[7, 4, 4] = 0
 
TY33NFunction[7, 4, 5] = 0
 
TY33NFunction[7, 4, 6] = 0
 
TY33NFunction[7, 4, 7] = 0
 
TY33NFunction[7, 4, 8] = 0
 
TY33NFunction[7, 4, 9] = 0
 
TY33NFunction[7, 5, 0] = 1
 
TY33NFunction[7, 5, 1] = 0
 
TY33NFunction[7, 5, 2] = 0
 
TY33NFunction[7, 5, 3] = 0
 
TY33NFunction[7, 5, 4] = 0
 
TY33NFunction[7, 5, 5] = 0
 
TY33NFunction[7, 5, 6] = 0
 
TY33NFunction[7, 5, 7] = 0
 
TY33NFunction[7, 5, 8] = 0
 
TY33NFunction[7, 5, 9] = 0
 
TY33NFunction[7, 6, 0] = 0
 
TY33NFunction[7, 6, 1] = 0
 
TY33NFunction[7, 6, 2] = 0
 
TY33NFunction[7, 6, 3] = 0
 
TY33NFunction[7, 6, 4] = 1
 
TY33NFunction[7, 6, 5] = 0
 
TY33NFunction[7, 6, 6] = 0
 
TY33NFunction[7, 6, 7] = 0
 
TY33NFunction[7, 6, 8] = 0
 
TY33NFunction[7, 6, 9] = 0
 
TY33NFunction[7, 7, 0] = 0
 
TY33NFunction[7, 7, 1] = 0
 
TY33NFunction[7, 7, 2] = 0
 
TY33NFunction[7, 7, 3] = 0
 
TY33NFunction[7, 7, 4] = 0
 
TY33NFunction[7, 7, 5] = 1
 
TY33NFunction[7, 7, 6] = 0
 
TY33NFunction[7, 7, 7] = 0
 
TY33NFunction[7, 7, 8] = 0
 
TY33NFunction[7, 7, 9] = 0
 
TY33NFunction[7, 8, 0] = 0
 
TY33NFunction[7, 8, 1] = 0
 
TY33NFunction[7, 8, 2] = 0
 
TY33NFunction[7, 8, 3] = 1
 
TY33NFunction[7, 8, 4] = 0
 
TY33NFunction[7, 8, 5] = 0
 
TY33NFunction[7, 8, 6] = 0
 
TY33NFunction[7, 8, 7] = 0
 
TY33NFunction[7, 8, 8] = 0
 
TY33NFunction[7, 8, 9] = 0
 
TY33NFunction[7, 9, 0] = 0
 
TY33NFunction[7, 9, 1] = 0
 
TY33NFunction[7, 9, 2] = 0
 
TY33NFunction[7, 9, 3] = 0
 
TY33NFunction[7, 9, 4] = 0
 
TY33NFunction[7, 9, 5] = 0
 
TY33NFunction[7, 9, 6] = 0
 
TY33NFunction[7, 9, 7] = 0
 
TY33NFunction[7, 9, 8] = 0
 
TY33NFunction[7, 9, 9] = 1
 
TY33NFunction[8, 0, 0] = 0
 
TY33NFunction[8, 0, 1] = 0
 
TY33NFunction[8, 0, 2] = 0
 
TY33NFunction[8, 0, 3] = 0
 
TY33NFunction[8, 0, 4] = 0
 
TY33NFunction[8, 0, 5] = 0
 
TY33NFunction[8, 0, 6] = 0
 
TY33NFunction[8, 0, 7] = 0
 
TY33NFunction[8, 0, 8] = 1
 
TY33NFunction[8, 0, 9] = 0
 
TY33NFunction[8, 1, 0] = 0
 
TY33NFunction[8, 1, 1] = 0
 
TY33NFunction[8, 1, 2] = 0
 
TY33NFunction[8, 1, 3] = 0
 
TY33NFunction[8, 1, 4] = 0
 
TY33NFunction[8, 1, 5] = 0
 
TY33NFunction[8, 1, 6] = 1
 
TY33NFunction[8, 1, 7] = 0
 
TY33NFunction[8, 1, 8] = 0
 
TY33NFunction[8, 1, 9] = 0
 
TY33NFunction[8, 2, 0] = 0
 
TY33NFunction[8, 2, 1] = 0
 
TY33NFunction[8, 2, 2] = 0
 
TY33NFunction[8, 2, 3] = 0
 
TY33NFunction[8, 2, 4] = 0
 
TY33NFunction[8, 2, 5] = 0
 
TY33NFunction[8, 2, 6] = 0
 
TY33NFunction[8, 2, 7] = 1
 
TY33NFunction[8, 2, 8] = 0
 
TY33NFunction[8, 2, 9] = 0
 
TY33NFunction[8, 3, 0] = 0
 
TY33NFunction[8, 3, 1] = 0
 
TY33NFunction[8, 3, 2] = 1
 
TY33NFunction[8, 3, 3] = 0
 
TY33NFunction[8, 3, 4] = 0
 
TY33NFunction[8, 3, 5] = 0
 
TY33NFunction[8, 3, 6] = 0
 
TY33NFunction[8, 3, 7] = 0
 
TY33NFunction[8, 3, 8] = 0
 
TY33NFunction[8, 3, 9] = 0
 
TY33NFunction[8, 4, 0] = 1
 
TY33NFunction[8, 4, 1] = 0
 
TY33NFunction[8, 4, 2] = 0
 
TY33NFunction[8, 4, 3] = 0
 
TY33NFunction[8, 4, 4] = 0
 
TY33NFunction[8, 4, 5] = 0
 
TY33NFunction[8, 4, 6] = 0
 
TY33NFunction[8, 4, 7] = 0
 
TY33NFunction[8, 4, 8] = 0
 
TY33NFunction[8, 4, 9] = 0
 
TY33NFunction[8, 5, 0] = 0
 
TY33NFunction[8, 5, 1] = 1
 
TY33NFunction[8, 5, 2] = 0
 
TY33NFunction[8, 5, 3] = 0
 
TY33NFunction[8, 5, 4] = 0
 
TY33NFunction[8, 5, 5] = 0
 
TY33NFunction[8, 5, 6] = 0
 
TY33NFunction[8, 5, 7] = 0
 
TY33NFunction[8, 5, 8] = 0
 
TY33NFunction[8, 5, 9] = 0
 
TY33NFunction[8, 6, 0] = 0
 
TY33NFunction[8, 6, 1] = 0
 
TY33NFunction[8, 6, 2] = 0
 
TY33NFunction[8, 6, 3] = 0
 
TY33NFunction[8, 6, 4] = 0
 
TY33NFunction[8, 6, 5] = 1
 
TY33NFunction[8, 6, 6] = 0
 
TY33NFunction[8, 6, 7] = 0
 
TY33NFunction[8, 6, 8] = 0
 
TY33NFunction[8, 6, 9] = 0
 
TY33NFunction[8, 7, 0] = 0
 
TY33NFunction[8, 7, 1] = 0
 
TY33NFunction[8, 7, 2] = 0
 
TY33NFunction[8, 7, 3] = 1
 
TY33NFunction[8, 7, 4] = 0
 
TY33NFunction[8, 7, 5] = 0
 
TY33NFunction[8, 7, 6] = 0
 
TY33NFunction[8, 7, 7] = 0
 
TY33NFunction[8, 7, 8] = 0
 
TY33NFunction[8, 7, 9] = 0
 
TY33NFunction[8, 8, 0] = 0
 
TY33NFunction[8, 8, 1] = 0
 
TY33NFunction[8, 8, 2] = 0
 
TY33NFunction[8, 8, 3] = 0
 
TY33NFunction[8, 8, 4] = 1
 
TY33NFunction[8, 8, 5] = 0
 
TY33NFunction[8, 8, 6] = 0
 
TY33NFunction[8, 8, 7] = 0
 
TY33NFunction[8, 8, 8] = 0
 
TY33NFunction[8, 8, 9] = 0
 
TY33NFunction[8, 9, 0] = 0
 
TY33NFunction[8, 9, 1] = 0
 
TY33NFunction[8, 9, 2] = 0
 
TY33NFunction[8, 9, 3] = 0
 
TY33NFunction[8, 9, 4] = 0
 
TY33NFunction[8, 9, 5] = 0
 
TY33NFunction[8, 9, 6] = 0
 
TY33NFunction[8, 9, 7] = 0
 
TY33NFunction[8, 9, 8] = 0
 
TY33NFunction[8, 9, 9] = 1
 
TY33NFunction[9, 0, 0] = 0
 
TY33NFunction[9, 0, 1] = 0
 
TY33NFunction[9, 0, 2] = 0
 
TY33NFunction[9, 0, 3] = 0
 
TY33NFunction[9, 0, 4] = 0
 
TY33NFunction[9, 0, 5] = 0
 
TY33NFunction[9, 0, 6] = 0
 
TY33NFunction[9, 0, 7] = 0
 
TY33NFunction[9, 0, 8] = 0
 
TY33NFunction[9, 0, 9] = 1
 
TY33NFunction[9, 1, 0] = 0
 
TY33NFunction[9, 1, 1] = 0
 
TY33NFunction[9, 1, 2] = 0
 
TY33NFunction[9, 1, 3] = 0
 
TY33NFunction[9, 1, 4] = 0
 
TY33NFunction[9, 1, 5] = 0
 
TY33NFunction[9, 1, 6] = 0
 
TY33NFunction[9, 1, 7] = 0
 
TY33NFunction[9, 1, 8] = 0
 
TY33NFunction[9, 1, 9] = 1
 
TY33NFunction[9, 2, 0] = 0
 
TY33NFunction[9, 2, 1] = 0
 
TY33NFunction[9, 2, 2] = 0
 
TY33NFunction[9, 2, 3] = 0
 
TY33NFunction[9, 2, 4] = 0
 
TY33NFunction[9, 2, 5] = 0
 
TY33NFunction[9, 2, 6] = 0
 
TY33NFunction[9, 2, 7] = 0
 
TY33NFunction[9, 2, 8] = 0
 
TY33NFunction[9, 2, 9] = 1
 
TY33NFunction[9, 3, 0] = 0
 
TY33NFunction[9, 3, 1] = 0
 
TY33NFunction[9, 3, 2] = 0
 
TY33NFunction[9, 3, 3] = 0
 
TY33NFunction[9, 3, 4] = 0
 
TY33NFunction[9, 3, 5] = 0
 
TY33NFunction[9, 3, 6] = 0
 
TY33NFunction[9, 3, 7] = 0
 
TY33NFunction[9, 3, 8] = 0
 
TY33NFunction[9, 3, 9] = 1
 
TY33NFunction[9, 4, 0] = 0
 
TY33NFunction[9, 4, 1] = 0
 
TY33NFunction[9, 4, 2] = 0
 
TY33NFunction[9, 4, 3] = 0
 
TY33NFunction[9, 4, 4] = 0
 
TY33NFunction[9, 4, 5] = 0
 
TY33NFunction[9, 4, 6] = 0
 
TY33NFunction[9, 4, 7] = 0
 
TY33NFunction[9, 4, 8] = 0
 
TY33NFunction[9, 4, 9] = 1
 
TY33NFunction[9, 5, 0] = 0
 
TY33NFunction[9, 5, 1] = 0
 
TY33NFunction[9, 5, 2] = 0
 
TY33NFunction[9, 5, 3] = 0
 
TY33NFunction[9, 5, 4] = 0
 
TY33NFunction[9, 5, 5] = 0
 
TY33NFunction[9, 5, 6] = 0
 
TY33NFunction[9, 5, 7] = 0
 
TY33NFunction[9, 5, 8] = 0
 
TY33NFunction[9, 5, 9] = 1
 
TY33NFunction[9, 6, 0] = 0
 
TY33NFunction[9, 6, 1] = 0
 
TY33NFunction[9, 6, 2] = 0
 
TY33NFunction[9, 6, 3] = 0
 
TY33NFunction[9, 6, 4] = 0
 
TY33NFunction[9, 6, 5] = 0
 
TY33NFunction[9, 6, 6] = 0
 
TY33NFunction[9, 6, 7] = 0
 
TY33NFunction[9, 6, 8] = 0
 
TY33NFunction[9, 6, 9] = 1
 
TY33NFunction[9, 7, 0] = 0
 
TY33NFunction[9, 7, 1] = 0
 
TY33NFunction[9, 7, 2] = 0
 
TY33NFunction[9, 7, 3] = 0
 
TY33NFunction[9, 7, 4] = 0
 
TY33NFunction[9, 7, 5] = 0
 
TY33NFunction[9, 7, 6] = 0
 
TY33NFunction[9, 7, 7] = 0
 
TY33NFunction[9, 7, 8] = 0
 
TY33NFunction[9, 7, 9] = 1
 
TY33NFunction[9, 8, 0] = 0
 
TY33NFunction[9, 8, 1] = 0
 
TY33NFunction[9, 8, 2] = 0
 
TY33NFunction[9, 8, 3] = 0
 
TY33NFunction[9, 8, 4] = 0
 
TY33NFunction[9, 8, 5] = 0
 
TY33NFunction[9, 8, 6] = 0
 
TY33NFunction[9, 8, 7] = 0
 
TY33NFunction[9, 8, 8] = 0
 
TY33NFunction[9, 8, 9] = 1
 
TY33NFunction[9, 9, 0] = 1
 
TY33NFunction[9, 9, 1] = 1
 
TY33NFunction[9, 9, 2] = 1
 
TY33NFunction[9, 9, 3] = 1
 
TY33NFunction[9, 9, 4] = 1
 
TY33NFunction[9, 9, 5] = 1
 
TY33NFunction[9, 9, 6] = 1
 
TY33NFunction[9, 9, 7] = 1
 
TY33NFunction[9, 9, 8] = 1
 
TY33NFunction[9, 9, 9] = 0
 
TY33NFunction[a_, b_, c_] := 0


 EndPackage[]