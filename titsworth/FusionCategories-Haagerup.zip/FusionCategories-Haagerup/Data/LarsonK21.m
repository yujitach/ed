BeginPackage["FusionCategories`Data`LarsonK21`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[LarsonK21] ^= {LarsonK21Cat1, LarsonK21Cat2, LarsonK21Cat3, 
    LarsonK21Cat4}
 
LarsonK21 /: fusionCategory[LarsonK21, 1] = LarsonK21Cat1
 
LarsonK21 /: fusionCategory[LarsonK21, 2] = LarsonK21Cat2
 
LarsonK21 /: fusionCategory[LarsonK21, 3] = LarsonK21Cat3
 
LarsonK21 /: fusionCategory[LarsonK21, 4] = LarsonK21Cat4
 
nFunction[LarsonK21] ^= LarsonK21NFunction
 
noMultiplicities[LarsonK21] ^= True
 
rank[LarsonK21] ^= 4
 
ring[LarsonK21] ^= LarsonK21
balancedCategories[LarsonK21Cat1] ^= {}
 
braidedCategories[LarsonK21Cat1] ^= {}
 
coeval[LarsonK21Cat1] ^= 1/sixJFunction[LarsonK21Cat1][#1, 
      dual[ring[LarsonK21Cat1]][#1], #1, #1, 0, 0] & 
 
eval[LarsonK21Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[LarsonK21Cat1] ^= LarsonK21Cat1FMatrixFunction
 
fusionCategory[LarsonK21Cat1] ^= LarsonK21Cat1
 
LarsonK21Cat1 /: modularCategory[LarsonK21Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[LarsonK21Cat1] ^= {LarsonK21Cat1Piv1}
 
LarsonK21Cat1 /: pivotalCategory[LarsonK21Cat1, 1] = LarsonK21Cat1Piv1
 
LarsonK21Cat1 /: pivotalCategory[LarsonK21Cat1, {1, -1, 1, 1}] = 
    LarsonK21Cat1Piv1
 
ring[LarsonK21Cat1] ^= LarsonK21
 
LarsonK21Cat1 /: sphericalCategory[LarsonK21Cat1, 1] = LarsonK21Cat1Piv1
 
fusionCategoryIndex[LarsonK21][LarsonK21Cat1] ^= 1
fMatrixFunction[LarsonK21Cat1FMatrixFunction] ^= LarsonK21Cat1FMatrixFunction
 
fusionCategory[LarsonK21Cat1FMatrixFunction] ^= LarsonK21Cat1
 
ring[LarsonK21Cat1FMatrixFunction] ^= LarsonK21
 
LarsonK21Cat1FMatrixFunction[1, 1, 1, 1] = {{-1}}
 
LarsonK21Cat1FMatrixFunction[1, 1, 3, 3] = {{-1}}
 
LarsonK21Cat1FMatrixFunction[1, 2, 2, 2] = {{(-1)^(1/4)}}
 
LarsonK21Cat1FMatrixFunction[1, 2, 2, 3] = {{-(-1)^(1/4)}}
 
LarsonK21Cat1FMatrixFunction[1, 2, 3, 1] = {{(-1)^(1/4)}}
 
LarsonK21Cat1FMatrixFunction[1, 2, 3, 2] = {{(-1)^(1/4)}}
 
LarsonK21Cat1FMatrixFunction[1, 2, 3, 3] = {{(-1)^(3/4)}}
 
LarsonK21Cat1FMatrixFunction[1, 3, 1, 3] = {{-1}}
 
LarsonK21Cat1FMatrixFunction[1, 3, 2, 1] = {{-1}}
 
LarsonK21Cat1FMatrixFunction[1, 3, 2, 2] = {{(-1)^(3/4)}}
 
LarsonK21Cat1FMatrixFunction[1, 3, 2, 3] = {{(-1)^(3/4)}}
 
LarsonK21Cat1FMatrixFunction[1, 3, 3, 0] = {{-(-1)^(3/4)}}
 
LarsonK21Cat1FMatrixFunction[1, 3, 3, 2] = {{-(-1)^(1/4)}}
 
LarsonK21Cat1FMatrixFunction[1, 3, 3, 3] = {{(-1)^(3/4)}}
 
LarsonK21Cat1FMatrixFunction[2, 1, 2, 0] = {{(-1)^(3/4)}}
 
LarsonK21Cat1FMatrixFunction[2, 1, 2, 3] = {{-I}}
 
LarsonK21Cat1FMatrixFunction[2, 1, 3, 1] = {{I}}
 
LarsonK21Cat1FMatrixFunction[2, 2, 1, 0] = {{(-1)^(1/4)}}
 
LarsonK21Cat1FMatrixFunction[2, 2, 1, 2] = {{(-1)^(1/4)}}
 
LarsonK21Cat1FMatrixFunction[2, 2, 1, 3] = {{-(-1)^(1/4)}}
 
LarsonK21Cat1FMatrixFunction[2, 2, 2, 1] = {{(-1)^(3/4)}}
 
LarsonK21Cat1FMatrixFunction[2, 2, 2, 2] = {{((1 - I) - Sqrt[2])/2, 1}, 
    {1/2 + I/2, ((1 + I) - I*Sqrt[2])/2}}
 
LarsonK21Cat1FMatrixFunction[2, 2, 2, 3] = 
   {{(-1 + I) - (-1)^(3/4), 1 - Sqrt[2], -1 + Sqrt[2]}, 
    {-(-1)^(1/4), (I/2)*((-1 - I) + Sqrt[2]), ((1 + I) - I*Sqrt[2])/2}, 
    {(-1)^(1/4), ((1 + I) - I*Sqrt[2])/2, (I/2)*((-1 - I) + Sqrt[2])}}
 
LarsonK21Cat1FMatrixFunction[2, 2, 3, 2] = 
   {{1 - Sqrt[2], 1 - Sqrt[2], -1 + Sqrt[2]}, 
    {-(-1)^(1/4), ((1 + I) - Sqrt[2])/2, (I/2)*((-1 + I) + Sqrt[2])}, 
    {(-1)^(3/4), ((1 - I) - Sqrt[2])/2, (-I/2)*((-1 - I) + Sqrt[2])}}
 
LarsonK21Cat1FMatrixFunction[2, 2, 3, 3] = 
   {{1/Sqrt[2], (I/2)*((-1 - I) + Sqrt[2])}, {((1 + I) - Sqrt[2])/2, 
     -(-1)^(3/4)}}
 
LarsonK21Cat1FMatrixFunction[2, 3, 1, 1] = {{(-1)^(3/4)}}
 
LarsonK21Cat1FMatrixFunction[2, 3, 1, 2] = {{(-1)^(3/4)}}
 
LarsonK21Cat1FMatrixFunction[2, 3, 1, 3] = {{(-1)^(3/4)}}
 
LarsonK21Cat1FMatrixFunction[2, 3, 2, 1] = {{-(-1)^(1/4)}}
 
LarsonK21Cat1FMatrixFunction[2, 3, 2, 2] = 
   {{-1 + Sqrt[2], 1 - Sqrt[2], 1 - Sqrt[2]}, {-1, ((1 + I) - Sqrt[2])/2, 
     ((1 - I) - Sqrt[2])/2}, {-1, ((1 - I) - Sqrt[2])/2, 
     ((1 + I) - Sqrt[2])/2}}
 
LarsonK21Cat1FMatrixFunction[2, 3, 2, 3] = 
   {{((1 + I) - I*Sqrt[2])/2, 1/2 + I/2}, {1, ((1 - I) - Sqrt[2])/2}}
 
LarsonK21Cat1FMatrixFunction[2, 3, 3, 2] = 
   {{(-1)^(3/4), (I/2)*((-1 - I) + Sqrt[2])}, {((1 + I) - Sqrt[2])/2, 
     -(1/Sqrt[2])}}
 
LarsonK21Cat1FMatrixFunction[2, 3, 3, 3] = 
   {{1 - Sqrt[2], (-1 + I) - (-1)^(3/4), (1/2 + I/2)*(-2 + Sqrt[2])}, 
    {1, (-I/2)*((-1 - I) + Sqrt[2]), (I/2)*((-1 + I) + Sqrt[2])}, 
    {-1, ((1 - I) - Sqrt[2])/2, ((1 + I) - Sqrt[2])/2}}
 
LarsonK21Cat1FMatrixFunction[3, 1, 1, 3] = {{-1}}
 
LarsonK21Cat1FMatrixFunction[3, 1, 2, 1] = {{-I}}
 
LarsonK21Cat1FMatrixFunction[3, 1, 3, 0] = {{(-1)^(1/4)}}
 
LarsonK21Cat1FMatrixFunction[3, 1, 3, 2] = {{-1}}
 
LarsonK21Cat1FMatrixFunction[3, 1, 3, 3] = {{-I}}
 
LarsonK21Cat1FMatrixFunction[3, 2, 1, 1] = {{-1}}
 
LarsonK21Cat1FMatrixFunction[3, 2, 1, 2] = {{(-1)^(1/4)}}
 
LarsonK21Cat1FMatrixFunction[3, 2, 1, 3] = {{(-1)^(3/4)}}
 
LarsonK21Cat1FMatrixFunction[3, 2, 2, 1] = {{-1}}
 
LarsonK21Cat1FMatrixFunction[3, 2, 2, 2] = 
   {{(-1 + I) - (-1)^(3/4), 1 - Sqrt[2], I*(-1 + Sqrt[2])}, 
    {-1, ((1 + I) - Sqrt[2])/2, ((1 - I) - Sqrt[2])/2}, 
    {1, (I/2)*((-1 + I) + Sqrt[2]), (-I/2)*((-1 - I) + Sqrt[2])}}
 
LarsonK21Cat1FMatrixFunction[3, 2, 2, 3] = 
   {{-(-1)^(3/4), ((1 + I) - Sqrt[2])/2}, {(I/2)*((-1 - I) + Sqrt[2]), 
     1/Sqrt[2]}}
 
LarsonK21Cat1FMatrixFunction[3, 2, 3, 1] = {{-(-1)^(1/4)}}
 
LarsonK21Cat1FMatrixFunction[3, 2, 3, 2] = 
   {{((1 - I) - Sqrt[2])/2, -1/2 - I/2}, {-1, ((1 + I) - I*Sqrt[2])/2}}
 
LarsonK21Cat1FMatrixFunction[3, 2, 3, 3] = 
   {{-1 + Sqrt[2], 1 - Sqrt[2], 1 - Sqrt[2]}, {-1, ((1 + I) - Sqrt[2])/2, 
     ((1 - I) - Sqrt[2])/2}, {-1, ((1 - I) - Sqrt[2])/2, 
     ((1 + I) - Sqrt[2])/2}}
 
LarsonK21Cat1FMatrixFunction[3, 3, 1, 0] = {{-1}}
 
LarsonK21Cat1FMatrixFunction[3, 3, 1, 2] = {{-(-1)^(1/4)}}
 
LarsonK21Cat1FMatrixFunction[3, 3, 1, 3] = {{(-1)^(3/4)}}
 
LarsonK21Cat1FMatrixFunction[3, 3, 2, 1] = {{-1}}
 
LarsonK21Cat1FMatrixFunction[3, 3, 2, 2] = 
   {{-(1/Sqrt[2]), ((1 + I) - Sqrt[2])/2}, {(I/2)*((-1 - I) + Sqrt[2]), 
     (-1)^(3/4)}}
 
LarsonK21Cat1FMatrixFunction[3, 3, 2, 3] = 
   {{(1 + I) - (-1)^(1/4), -1 + Sqrt[2], 1 - Sqrt[2]}, 
    {1, (-I/2)*((-1 - I) + Sqrt[2]), ((1 - I) - Sqrt[2])/2}, 
    {I, (I/2)*((-1 + I) + Sqrt[2]), ((1 + I) - Sqrt[2])/2}}
 
LarsonK21Cat1FMatrixFunction[3, 3, 3, 1] = {{(-1)^(3/4)}}
 
LarsonK21Cat1FMatrixFunction[3, 3, 3, 2] = 
   {{(1/2 + I/2)*(-2 + Sqrt[2]), (-1 + I) - (-1)^(3/4), 
     (1 - I) + (-1)^(3/4)}, {1, (I/2)*((-1 - I) + Sqrt[2]), 
     ((1 + I) - I*Sqrt[2])/2}, {-1, ((1 + I) - I*Sqrt[2])/2, 
     (I/2)*((-1 - I) + Sqrt[2])}}
 
LarsonK21Cat1FMatrixFunction[3, 3, 3, 3] = {{((1 + I) - I*Sqrt[2])/2, -1}, 
    {-1/2 - I/2, ((1 - I) - Sqrt[2])/2}}
 
LarsonK21Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[LarsonK21Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
LarsonK21Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[LarsonK21Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[LarsonK21Cat1Piv1] ^= {}
 
fusionCategory[LarsonK21Cat1Piv1] ^= LarsonK21Cat1
 
LarsonK21Cat1Piv1 /: modularCategory[LarsonK21Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[LarsonK21Cat1Piv1] ^= LarsonK21Cat1Piv1
 
pivotalIsomorphism[LarsonK21Cat1Piv1] ^= LarsonK21Cat1Piv1PivotalIsomorphism
 
ring[LarsonK21Cat1Piv1] ^= LarsonK21
 
sphericalCategory[LarsonK21Cat1Piv1] ^= LarsonK21Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[LarsonK21Cat1]][pivotalCategory[#1]] & )[
    LarsonK21Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[LarsonK21Cat1]][
      sphericalCategory[#1]] & )[LarsonK21Cat1Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[LarsonK21Cat1Piv1PivotalIsomorphism] ^= LarsonK21Cat1
 
pivotalCategory[LarsonK21Cat1Piv1PivotalIsomorphism] ^= LarsonK21Cat1Piv1
 
pivotalIsomorphism[LarsonK21Cat1Piv1PivotalIsomorphism] ^= 
   LarsonK21Cat1Piv1PivotalIsomorphism
 
LarsonK21Cat1Piv1PivotalIsomorphism[0] = 1
 
LarsonK21Cat1Piv1PivotalIsomorphism[1] = -1
 
LarsonK21Cat1Piv1PivotalIsomorphism[2] = 1
 
LarsonK21Cat1Piv1PivotalIsomorphism[3] = 1
balancedCategories[LarsonK21Cat2] ^= {}
 
braidedCategories[LarsonK21Cat2] ^= {}
 
coeval[LarsonK21Cat2] ^= 1/sixJFunction[LarsonK21Cat2][#1, 
      dual[ring[LarsonK21Cat2]][#1], #1, #1, 0, 0] & 
 
eval[LarsonK21Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[LarsonK21Cat2] ^= LarsonK21Cat2FMatrixFunction
 
fusionCategory[LarsonK21Cat2] ^= LarsonK21Cat2
 
LarsonK21Cat2 /: modularCategory[LarsonK21Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[LarsonK21Cat2] ^= {LarsonK21Cat2Piv1}
 
LarsonK21Cat2 /: pivotalCategory[LarsonK21Cat2, 1] = LarsonK21Cat2Piv1
 
LarsonK21Cat2 /: pivotalCategory[LarsonK21Cat2, {1, -1, 1, 1}] = 
    LarsonK21Cat2Piv1
 
ring[LarsonK21Cat2] ^= LarsonK21
 
LarsonK21Cat2 /: sphericalCategory[LarsonK21Cat2, 1] = LarsonK21Cat2Piv1
 
fusionCategoryIndex[LarsonK21][LarsonK21Cat2] ^= 2
fMatrixFunction[LarsonK21Cat2FMatrixFunction] ^= LarsonK21Cat2FMatrixFunction
 
fusionCategory[LarsonK21Cat2FMatrixFunction] ^= LarsonK21Cat2
 
ring[LarsonK21Cat2FMatrixFunction] ^= LarsonK21
 
LarsonK21Cat2FMatrixFunction[1, 1, 1, 1] = {{-1}}
 
LarsonK21Cat2FMatrixFunction[1, 1, 3, 3] = {{-1}}
 
LarsonK21Cat2FMatrixFunction[1, 2, 2, 2] = {{-(-1)^(3/4)}}
 
LarsonK21Cat2FMatrixFunction[1, 2, 2, 3] = {{(-1)^(3/4)}}
 
LarsonK21Cat2FMatrixFunction[1, 2, 3, 1] = {{-(-1)^(3/4)}}
 
LarsonK21Cat2FMatrixFunction[1, 2, 3, 2] = {{-(-1)^(3/4)}}
 
LarsonK21Cat2FMatrixFunction[1, 2, 3, 3] = {{-(-1)^(1/4)}}
 
LarsonK21Cat2FMatrixFunction[1, 3, 1, 3] = {{-1}}
 
LarsonK21Cat2FMatrixFunction[1, 3, 2, 1] = {{-1}}
 
LarsonK21Cat2FMatrixFunction[1, 3, 2, 2] = {{-(-1)^(1/4)}}
 
LarsonK21Cat2FMatrixFunction[1, 3, 2, 3] = {{-(-1)^(1/4)}}
 
LarsonK21Cat2FMatrixFunction[1, 3, 3, 0] = {{(-1)^(1/4)}}
 
LarsonK21Cat2FMatrixFunction[1, 3, 3, 2] = {{(-1)^(3/4)}}
 
LarsonK21Cat2FMatrixFunction[1, 3, 3, 3] = {{-(-1)^(1/4)}}
 
LarsonK21Cat2FMatrixFunction[2, 1, 2, 0] = {{-(-1)^(1/4)}}
 
LarsonK21Cat2FMatrixFunction[2, 1, 2, 3] = {{I}}
 
LarsonK21Cat2FMatrixFunction[2, 1, 3, 1] = {{-I}}
 
LarsonK21Cat2FMatrixFunction[2, 2, 1, 0] = {{-(-1)^(3/4)}}
 
LarsonK21Cat2FMatrixFunction[2, 2, 1, 2] = {{-(-1)^(3/4)}}
 
LarsonK21Cat2FMatrixFunction[2, 2, 1, 3] = {{(-1)^(3/4)}}
 
LarsonK21Cat2FMatrixFunction[2, 2, 2, 1] = {{-(-1)^(1/4)}}
 
LarsonK21Cat2FMatrixFunction[2, 2, 2, 2] = {{((1 + I) - Sqrt[2])/2, 1}, 
    {1/2 - I/2, (I/2)*((-1 - I) + Sqrt[2])}}
 
LarsonK21Cat2FMatrixFunction[2, 2, 2, 3] = 
   {{(1/2 + I/2)*(-2 + Sqrt[2]), 1 - Sqrt[2], -1 + Sqrt[2]}, 
    {(-1)^(3/4), ((1 + I) - I*Sqrt[2])/2, (I/2)*((-1 - I) + Sqrt[2])}, 
    {-(-1)^(3/4), (I/2)*((-1 - I) + Sqrt[2]), ((1 + I) - I*Sqrt[2])/2}}
 
LarsonK21Cat2FMatrixFunction[2, 2, 3, 2] = 
   {{1 - Sqrt[2], 1 - Sqrt[2], -1 + Sqrt[2]}, 
    {(-1)^(3/4), ((1 - I) - Sqrt[2])/2, (-I/2)*((-1 - I) + Sqrt[2])}, 
    {-(-1)^(1/4), ((1 + I) - Sqrt[2])/2, (I/2)*((-1 + I) + Sqrt[2])}}
 
LarsonK21Cat2FMatrixFunction[2, 2, 3, 3] = 
   {{1/Sqrt[2], ((1 + I) - I*Sqrt[2])/2}, {((1 - I) - Sqrt[2])/2, (-1)^(1/4)}}
 
LarsonK21Cat2FMatrixFunction[2, 3, 1, 1] = {{-(-1)^(1/4)}}
 
LarsonK21Cat2FMatrixFunction[2, 3, 1, 2] = {{-(-1)^(1/4)}}
 
LarsonK21Cat2FMatrixFunction[2, 3, 1, 3] = {{-(-1)^(1/4)}}
 
LarsonK21Cat2FMatrixFunction[2, 3, 2, 1] = {{(-1)^(3/4)}}
 
LarsonK21Cat2FMatrixFunction[2, 3, 2, 2] = 
   {{-1 + Sqrt[2], 1 - Sqrt[2], 1 - Sqrt[2]}, {-1, ((1 - I) - Sqrt[2])/2, 
     ((1 + I) - Sqrt[2])/2}, {-1, ((1 + I) - Sqrt[2])/2, 
     ((1 - I) - Sqrt[2])/2}}
 
LarsonK21Cat2FMatrixFunction[2, 3, 2, 3] = 
   {{(I/2)*((-1 - I) + Sqrt[2]), 1/2 - I/2}, {1, ((1 + I) - Sqrt[2])/2}}
 
LarsonK21Cat2FMatrixFunction[2, 3, 3, 2] = 
   {{-(-1)^(1/4), ((1 + I) - I*Sqrt[2])/2}, {((1 - I) - Sqrt[2])/2, 
     -(1/Sqrt[2])}}
 
LarsonK21Cat2FMatrixFunction[2, 3, 3, 3] = 
   {{1 - Sqrt[2], (1/2 + I/2)*(-2 + Sqrt[2]), (-1 + I) - (-1)^(3/4)}, 
    {1, (I/2)*((-1 + I) + Sqrt[2]), (-I/2)*((-1 - I) + Sqrt[2])}, 
    {-1, ((1 + I) - Sqrt[2])/2, ((1 - I) - Sqrt[2])/2}}
 
LarsonK21Cat2FMatrixFunction[3, 1, 1, 3] = {{-1}}
 
LarsonK21Cat2FMatrixFunction[3, 1, 2, 1] = {{I}}
 
LarsonK21Cat2FMatrixFunction[3, 1, 3, 0] = {{-(-1)^(3/4)}}
 
LarsonK21Cat2FMatrixFunction[3, 1, 3, 2] = {{-1}}
 
LarsonK21Cat2FMatrixFunction[3, 1, 3, 3] = {{I}}
 
LarsonK21Cat2FMatrixFunction[3, 2, 1, 1] = {{-1}}
 
LarsonK21Cat2FMatrixFunction[3, 2, 1, 2] = {{-(-1)^(3/4)}}
 
LarsonK21Cat2FMatrixFunction[3, 2, 1, 3] = {{-(-1)^(1/4)}}
 
LarsonK21Cat2FMatrixFunction[3, 2, 2, 1] = {{-1}}
 
LarsonK21Cat2FMatrixFunction[3, 2, 2, 2] = 
   {{(1/2 + I/2)*(-2 + Sqrt[2]), 1 - Sqrt[2], (-I)*(-1 + Sqrt[2])}, 
    {-1, ((1 - I) - Sqrt[2])/2, ((1 + I) - Sqrt[2])/2}, 
    {1, (-I/2)*((-1 - I) + Sqrt[2]), (I/2)*((-1 + I) + Sqrt[2])}}
 
LarsonK21Cat2FMatrixFunction[3, 2, 2, 3] = 
   {{(-1)^(1/4), ((1 - I) - Sqrt[2])/2}, {((1 + I) - I*Sqrt[2])/2, 1/Sqrt[2]}}
 
LarsonK21Cat2FMatrixFunction[3, 2, 3, 1] = {{(-1)^(3/4)}}
 
LarsonK21Cat2FMatrixFunction[3, 2, 3, 2] = 
   {{((1 + I) - Sqrt[2])/2, -1/2 + I/2}, {-1, (I/2)*((-1 - I) + Sqrt[2])}}
 
LarsonK21Cat2FMatrixFunction[3, 2, 3, 3] = 
   {{-1 + Sqrt[2], 1 - Sqrt[2], 1 - Sqrt[2]}, {-1, ((1 - I) - Sqrt[2])/2, 
     ((1 + I) - Sqrt[2])/2}, {-1, ((1 + I) - Sqrt[2])/2, 
     ((1 - I) - Sqrt[2])/2}}
 
LarsonK21Cat2FMatrixFunction[3, 3, 1, 0] = {{-1}}
 
LarsonK21Cat2FMatrixFunction[3, 3, 1, 2] = {{(-1)^(3/4)}}
 
LarsonK21Cat2FMatrixFunction[3, 3, 1, 3] = {{-(-1)^(1/4)}}
 
LarsonK21Cat2FMatrixFunction[3, 3, 2, 1] = {{-1}}
 
LarsonK21Cat2FMatrixFunction[3, 3, 2, 2] = 
   {{-(1/Sqrt[2]), ((1 - I) - Sqrt[2])/2}, {((1 + I) - I*Sqrt[2])/2, 
     -(-1)^(1/4)}}
 
LarsonK21Cat2FMatrixFunction[3, 3, 2, 3] = 
   {{(1 - I) + (-1)^(3/4), -1 + Sqrt[2], 1 - Sqrt[2]}, 
    {1, (I/2)*((-1 + I) + Sqrt[2]), ((1 + I) - Sqrt[2])/2}, 
    {-I, (-I/2)*((-1 - I) + Sqrt[2]), ((1 - I) - Sqrt[2])/2}}
 
LarsonK21Cat2FMatrixFunction[3, 3, 3, 1] = {{-(-1)^(1/4)}}
 
LarsonK21Cat2FMatrixFunction[3, 3, 3, 2] = 
   {{(-1 + I) - (-1)^(3/4), (1/2 + I/2)*(-2 + Sqrt[2]), 
     (1 + I) - (-1)^(1/4)}, {1, ((1 + I) - I*Sqrt[2])/2, 
     (I/2)*((-1 - I) + Sqrt[2])}, {-1, (I/2)*((-1 - I) + Sqrt[2]), 
     ((1 + I) - I*Sqrt[2])/2}}
 
LarsonK21Cat2FMatrixFunction[3, 3, 3, 3] = {{(I/2)*((-1 - I) + Sqrt[2]), -1}, 
    {-1/2 + I/2, ((1 + I) - Sqrt[2])/2}}
 
LarsonK21Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[LarsonK21Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
LarsonK21Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[LarsonK21Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[LarsonK21Cat2Piv1] ^= {}
 
fusionCategory[LarsonK21Cat2Piv1] ^= LarsonK21Cat2
 
LarsonK21Cat2Piv1 /: modularCategory[LarsonK21Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[LarsonK21Cat2Piv1] ^= LarsonK21Cat2Piv1
 
pivotalIsomorphism[LarsonK21Cat2Piv1] ^= LarsonK21Cat2Piv1PivotalIsomorphism
 
ring[LarsonK21Cat2Piv1] ^= LarsonK21
 
sphericalCategory[LarsonK21Cat2Piv1] ^= LarsonK21Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[LarsonK21Cat2]][pivotalCategory[#1]] & )[
    LarsonK21Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[LarsonK21Cat2]][
      sphericalCategory[#1]] & )[LarsonK21Cat2Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[LarsonK21Cat2Piv1PivotalIsomorphism] ^= LarsonK21Cat2
 
pivotalCategory[LarsonK21Cat2Piv1PivotalIsomorphism] ^= LarsonK21Cat2Piv1
 
pivotalIsomorphism[LarsonK21Cat2Piv1PivotalIsomorphism] ^= 
   LarsonK21Cat2Piv1PivotalIsomorphism
 
LarsonK21Cat2Piv1PivotalIsomorphism[0] = 1
 
LarsonK21Cat2Piv1PivotalIsomorphism[1] = -1
 
LarsonK21Cat2Piv1PivotalIsomorphism[2] = 1
 
LarsonK21Cat2Piv1PivotalIsomorphism[3] = 1
balancedCategories[LarsonK21Cat3] ^= {}
 
braidedCategories[LarsonK21Cat3] ^= {}
 
coeval[LarsonK21Cat3] ^= 1/sixJFunction[LarsonK21Cat3][#1, 
      dual[ring[LarsonK21Cat3]][#1], #1, #1, 0, 0] & 
 
eval[LarsonK21Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[LarsonK21Cat3] ^= LarsonK21Cat3FMatrixFunction
 
fusionCategory[LarsonK21Cat3] ^= LarsonK21Cat3
 
LarsonK21Cat3 /: modularCategory[LarsonK21Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[LarsonK21Cat3] ^= {LarsonK21Cat3Piv1}
 
LarsonK21Cat3 /: pivotalCategory[LarsonK21Cat3, 1] = LarsonK21Cat3Piv1
 
LarsonK21Cat3 /: pivotalCategory[LarsonK21Cat3, {1, -1, 1, 1}] = 
    LarsonK21Cat3Piv1
 
ring[LarsonK21Cat3] ^= LarsonK21
 
LarsonK21Cat3 /: sphericalCategory[LarsonK21Cat3, 1] = LarsonK21Cat3Piv1
 
fusionCategoryIndex[LarsonK21][LarsonK21Cat3] ^= 3
fMatrixFunction[LarsonK21Cat3FMatrixFunction] ^= LarsonK21Cat3FMatrixFunction
 
fusionCategory[LarsonK21Cat3FMatrixFunction] ^= LarsonK21Cat3
 
ring[LarsonK21Cat3FMatrixFunction] ^= LarsonK21
 
LarsonK21Cat3FMatrixFunction[1, 1, 1, 1] = {{-1}}
 
LarsonK21Cat3FMatrixFunction[1, 1, 3, 3] = {{-1}}
 
LarsonK21Cat3FMatrixFunction[1, 2, 2, 2] = {{(-1)^(3/4)}}
 
LarsonK21Cat3FMatrixFunction[1, 2, 2, 3] = {{-(-1)^(3/4)}}
 
LarsonK21Cat3FMatrixFunction[1, 2, 3, 1] = {{(-1)^(3/4)}}
 
LarsonK21Cat3FMatrixFunction[1, 2, 3, 2] = {{(-1)^(3/4)}}
 
LarsonK21Cat3FMatrixFunction[1, 2, 3, 3] = {{(-1)^(1/4)}}
 
LarsonK21Cat3FMatrixFunction[1, 3, 1, 3] = {{-1}}
 
LarsonK21Cat3FMatrixFunction[1, 3, 2, 1] = {{-1}}
 
LarsonK21Cat3FMatrixFunction[1, 3, 2, 2] = {{(-1)^(1/4)}}
 
LarsonK21Cat3FMatrixFunction[1, 3, 2, 3] = {{(-1)^(1/4)}}
 
LarsonK21Cat3FMatrixFunction[1, 3, 3, 0] = {{-(-1)^(1/4)}}
 
LarsonK21Cat3FMatrixFunction[1, 3, 3, 2] = {{-(-1)^(3/4)}}
 
LarsonK21Cat3FMatrixFunction[1, 3, 3, 3] = {{(-1)^(1/4)}}
 
LarsonK21Cat3FMatrixFunction[2, 1, 2, 0] = {{(-1)^(1/4)}}
 
LarsonK21Cat3FMatrixFunction[2, 1, 2, 3] = {{I}}
 
LarsonK21Cat3FMatrixFunction[2, 1, 3, 1] = {{-I}}
 
LarsonK21Cat3FMatrixFunction[2, 2, 1, 0] = {{(-1)^(3/4)}}
 
LarsonK21Cat3FMatrixFunction[2, 2, 1, 2] = {{(-1)^(3/4)}}
 
LarsonK21Cat3FMatrixFunction[2, 2, 1, 3] = {{-(-1)^(3/4)}}
 
LarsonK21Cat3FMatrixFunction[2, 2, 2, 1] = {{(-1)^(1/4)}}
 
LarsonK21Cat3FMatrixFunction[2, 2, 2, 2] = {{((1 + I) + Sqrt[2])/2, 1}, 
    {1/2 - I/2, (-I/2)*((1 + I) + Sqrt[2])}}
 
LarsonK21Cat3FMatrixFunction[2, 2, 2, 3] = 
   {{(-1/2 - I/2)*(2 + Sqrt[2]), 1 + Sqrt[2], -1 - Sqrt[2]}, 
    {-(-1)^(3/4), ((1 + I) + I*Sqrt[2])/2, (-I/2)*((1 + I) + Sqrt[2])}, 
    {(-1)^(3/4), (-I/2)*((1 + I) + Sqrt[2]), ((1 + I) + I*Sqrt[2])/2}}
 
LarsonK21Cat3FMatrixFunction[2, 2, 3, 2] = 
   {{1 + Sqrt[2], 1 + Sqrt[2], -1 - Sqrt[2]}, 
    {-(-1)^(3/4), ((1 - I) + Sqrt[2])/2, (I/2)*((1 + I) + Sqrt[2])}, 
    {(-1)^(1/4), ((1 + I) + Sqrt[2])/2, (-I/2)*((1 - I) + Sqrt[2])}}
 
LarsonK21Cat3FMatrixFunction[2, 2, 3, 3] = 
   {{-(1/Sqrt[2]), ((1 + I) + I*Sqrt[2])/2}, {((1 - I) + Sqrt[2])/2, 
     -(-1)^(1/4)}}
 
LarsonK21Cat3FMatrixFunction[2, 3, 1, 1] = {{(-1)^(1/4)}}
 
LarsonK21Cat3FMatrixFunction[2, 3, 1, 2] = {{(-1)^(1/4)}}
 
LarsonK21Cat3FMatrixFunction[2, 3, 1, 3] = {{(-1)^(1/4)}}
 
LarsonK21Cat3FMatrixFunction[2, 3, 2, 1] = {{-(-1)^(3/4)}}
 
LarsonK21Cat3FMatrixFunction[2, 3, 2, 2] = 
   {{-1 - Sqrt[2], 1 + Sqrt[2], 1 + Sqrt[2]}, {-1, ((1 - I) + Sqrt[2])/2, 
     ((1 + I) + Sqrt[2])/2}, {-1, ((1 + I) + Sqrt[2])/2, 
     ((1 - I) + Sqrt[2])/2}}
 
LarsonK21Cat3FMatrixFunction[2, 3, 2, 3] = 
   {{(-I/2)*((1 + I) + Sqrt[2]), 1/2 - I/2}, {1, ((1 + I) + Sqrt[2])/2}}
 
LarsonK21Cat3FMatrixFunction[2, 3, 3, 2] = 
   {{(-1)^(1/4), ((1 + I) + I*Sqrt[2])/2}, {((1 - I) + Sqrt[2])/2, 1/Sqrt[2]}}
 
LarsonK21Cat3FMatrixFunction[2, 3, 3, 3] = 
   {{1 + Sqrt[2], (-1/2 - I/2)*(2 + Sqrt[2]), (-1/2 + I/2)*(2 + Sqrt[2])}, 
    {1, (-I/2)*((1 - I) + Sqrt[2]), (I/2)*((1 + I) + Sqrt[2])}, 
    {-1, ((1 + I) + Sqrt[2])/2, ((1 - I) + Sqrt[2])/2}}
 
LarsonK21Cat3FMatrixFunction[3, 1, 1, 3] = {{-1}}
 
LarsonK21Cat3FMatrixFunction[3, 1, 2, 1] = {{I}}
 
LarsonK21Cat3FMatrixFunction[3, 1, 3, 0] = {{(-1)^(3/4)}}
 
LarsonK21Cat3FMatrixFunction[3, 1, 3, 2] = {{-1}}
 
LarsonK21Cat3FMatrixFunction[3, 1, 3, 3] = {{I}}
 
LarsonK21Cat3FMatrixFunction[3, 2, 1, 1] = {{-1}}
 
LarsonK21Cat3FMatrixFunction[3, 2, 1, 2] = {{(-1)^(3/4)}}
 
LarsonK21Cat3FMatrixFunction[3, 2, 1, 3] = {{(-1)^(1/4)}}
 
LarsonK21Cat3FMatrixFunction[3, 2, 2, 1] = {{-1}}
 
LarsonK21Cat3FMatrixFunction[3, 2, 2, 2] = 
   {{(-1/2 - I/2)*(2 + Sqrt[2]), 1 + Sqrt[2], I*(1 + Sqrt[2])}, 
    {-1, ((1 - I) + Sqrt[2])/2, ((1 + I) + Sqrt[2])/2}, 
    {1, (I/2)*((1 + I) + Sqrt[2]), (-I/2)*((1 - I) + Sqrt[2])}}
 
LarsonK21Cat3FMatrixFunction[3, 2, 2, 3] = 
   {{-(-1)^(1/4), ((1 - I) + Sqrt[2])/2}, {((1 + I) + I*Sqrt[2])/2, 
     -(1/Sqrt[2])}}
 
LarsonK21Cat3FMatrixFunction[3, 2, 3, 1] = {{-(-1)^(3/4)}}
 
LarsonK21Cat3FMatrixFunction[3, 2, 3, 2] = 
   {{((1 + I) + Sqrt[2])/2, -1/2 + I/2}, {-1, (-I/2)*((1 + I) + Sqrt[2])}}
 
LarsonK21Cat3FMatrixFunction[3, 2, 3, 3] = 
   {{-1 - Sqrt[2], 1 + Sqrt[2], 1 + Sqrt[2]}, {-1, ((1 - I) + Sqrt[2])/2, 
     ((1 + I) + Sqrt[2])/2}, {-1, ((1 + I) + Sqrt[2])/2, 
     ((1 - I) + Sqrt[2])/2}}
 
LarsonK21Cat3FMatrixFunction[3, 3, 1, 0] = {{-1}}
 
LarsonK21Cat3FMatrixFunction[3, 3, 1, 2] = {{-(-1)^(3/4)}}
 
LarsonK21Cat3FMatrixFunction[3, 3, 1, 3] = {{(-1)^(1/4)}}
 
LarsonK21Cat3FMatrixFunction[3, 3, 2, 1] = {{-1}}
 
LarsonK21Cat3FMatrixFunction[3, 3, 2, 2] = 
   {{1/Sqrt[2], ((1 - I) + Sqrt[2])/2}, {((1 + I) + I*Sqrt[2])/2, (-1)^(1/4)}}
 
LarsonK21Cat3FMatrixFunction[3, 3, 2, 3] = 
   {{(1/2 - I/2)*(2 + Sqrt[2]), -1 - Sqrt[2], 1 + Sqrt[2]}, 
    {1, (-I/2)*((1 - I) + Sqrt[2]), ((1 + I) + Sqrt[2])/2}, 
    {-I, (I/2)*((1 + I) + Sqrt[2]), ((1 - I) + Sqrt[2])/2}}
 
LarsonK21Cat3FMatrixFunction[3, 3, 3, 1] = {{(-1)^(1/4)}}
 
LarsonK21Cat3FMatrixFunction[3, 3, 3, 2] = 
   {{(-1/2 + I/2)*(2 + Sqrt[2]), (-1/2 - I/2)*(2 + Sqrt[2]), 
     (1 + I) + (-1)^(1/4)}, {1, ((1 + I) + I*Sqrt[2])/2, 
     (-I/2)*((1 + I) + Sqrt[2])}, {-1, (-I/2)*((1 + I) + Sqrt[2]), 
     ((1 + I) + I*Sqrt[2])/2}}
 
LarsonK21Cat3FMatrixFunction[3, 3, 3, 3] = {{(-I/2)*((1 + I) + Sqrt[2]), -1}, 
    {-1/2 + I/2, ((1 + I) + Sqrt[2])/2}}
 
LarsonK21Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[LarsonK21Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
LarsonK21Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[LarsonK21Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[LarsonK21Cat3Piv1] ^= {}
 
fusionCategory[LarsonK21Cat3Piv1] ^= LarsonK21Cat3
 
LarsonK21Cat3Piv1 /: modularCategory[LarsonK21Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[LarsonK21Cat3Piv1] ^= LarsonK21Cat3Piv1
 
pivotalIsomorphism[LarsonK21Cat3Piv1] ^= LarsonK21Cat3Piv1PivotalIsomorphism
 
ring[LarsonK21Cat3Piv1] ^= LarsonK21
 
sphericalCategory[LarsonK21Cat3Piv1] ^= LarsonK21Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[LarsonK21Cat3]][pivotalCategory[#1]] & )[
    LarsonK21Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[LarsonK21Cat3]][
      sphericalCategory[#1]] & )[LarsonK21Cat3Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[LarsonK21Cat3Piv1PivotalIsomorphism] ^= LarsonK21Cat3
 
pivotalCategory[LarsonK21Cat3Piv1PivotalIsomorphism] ^= LarsonK21Cat3Piv1
 
pivotalIsomorphism[LarsonK21Cat3Piv1PivotalIsomorphism] ^= 
   LarsonK21Cat3Piv1PivotalIsomorphism
 
LarsonK21Cat3Piv1PivotalIsomorphism[0] = 1
 
LarsonK21Cat3Piv1PivotalIsomorphism[1] = -1
 
LarsonK21Cat3Piv1PivotalIsomorphism[2] = 1
 
LarsonK21Cat3Piv1PivotalIsomorphism[3] = 1
balancedCategories[LarsonK21Cat4] ^= {}
 
braidedCategories[LarsonK21Cat4] ^= {}
 
coeval[LarsonK21Cat4] ^= 1/sixJFunction[LarsonK21Cat4][#1, 
      dual[ring[LarsonK21Cat4]][#1], #1, #1, 0, 0] & 
 
eval[LarsonK21Cat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[LarsonK21Cat4] ^= LarsonK21Cat4FMatrixFunction
 
fusionCategory[LarsonK21Cat4] ^= LarsonK21Cat4
 
LarsonK21Cat4 /: modularCategory[LarsonK21Cat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[LarsonK21Cat4] ^= {LarsonK21Cat4Piv1}
 
LarsonK21Cat4 /: pivotalCategory[LarsonK21Cat4, 1] = LarsonK21Cat4Piv1
 
LarsonK21Cat4 /: pivotalCategory[LarsonK21Cat4, {1, -1, 1, 1}] = 
    LarsonK21Cat4Piv1
 
ring[LarsonK21Cat4] ^= LarsonK21
 
LarsonK21Cat4 /: sphericalCategory[LarsonK21Cat4, 1] = LarsonK21Cat4Piv1
 
fusionCategoryIndex[LarsonK21][LarsonK21Cat4] ^= 4
fMatrixFunction[LarsonK21Cat4FMatrixFunction] ^= LarsonK21Cat4FMatrixFunction
 
fusionCategory[LarsonK21Cat4FMatrixFunction] ^= LarsonK21Cat4
 
ring[LarsonK21Cat4FMatrixFunction] ^= LarsonK21
 
LarsonK21Cat4FMatrixFunction[1, 1, 1, 1] = {{-1}}
 
LarsonK21Cat4FMatrixFunction[1, 1, 3, 3] = {{-1}}
 
LarsonK21Cat4FMatrixFunction[1, 2, 2, 2] = {{-(-1)^(1/4)}}
 
LarsonK21Cat4FMatrixFunction[1, 2, 2, 3] = {{(-1)^(1/4)}}
 
LarsonK21Cat4FMatrixFunction[1, 2, 3, 1] = {{-(-1)^(1/4)}}
 
LarsonK21Cat4FMatrixFunction[1, 2, 3, 2] = {{-(-1)^(1/4)}}
 
LarsonK21Cat4FMatrixFunction[1, 2, 3, 3] = {{-(-1)^(3/4)}}
 
LarsonK21Cat4FMatrixFunction[1, 3, 1, 3] = {{-1}}
 
LarsonK21Cat4FMatrixFunction[1, 3, 2, 1] = {{-1}}
 
LarsonK21Cat4FMatrixFunction[1, 3, 2, 2] = {{-(-1)^(3/4)}}
 
LarsonK21Cat4FMatrixFunction[1, 3, 2, 3] = {{-(-1)^(3/4)}}
 
LarsonK21Cat4FMatrixFunction[1, 3, 3, 0] = {{(-1)^(3/4)}}
 
LarsonK21Cat4FMatrixFunction[1, 3, 3, 2] = {{(-1)^(1/4)}}
 
LarsonK21Cat4FMatrixFunction[1, 3, 3, 3] = {{-(-1)^(3/4)}}
 
LarsonK21Cat4FMatrixFunction[2, 1, 2, 0] = {{-(-1)^(3/4)}}
 
LarsonK21Cat4FMatrixFunction[2, 1, 2, 3] = {{-I}}
 
LarsonK21Cat4FMatrixFunction[2, 1, 3, 1] = {{I}}
 
LarsonK21Cat4FMatrixFunction[2, 2, 1, 0] = {{-(-1)^(1/4)}}
 
LarsonK21Cat4FMatrixFunction[2, 2, 1, 2] = {{-(-1)^(1/4)}}
 
LarsonK21Cat4FMatrixFunction[2, 2, 1, 3] = {{(-1)^(1/4)}}
 
LarsonK21Cat4FMatrixFunction[2, 2, 2, 1] = {{-(-1)^(3/4)}}
 
LarsonK21Cat4FMatrixFunction[2, 2, 2, 2] = {{((1 - I) + Sqrt[2])/2, 1}, 
    {1/2 + I/2, ((1 + I) + I*Sqrt[2])/2}}
 
LarsonK21Cat4FMatrixFunction[2, 2, 2, 3] = 
   {{(-1/2 + I/2)*(2 + Sqrt[2]), 1 + Sqrt[2], -1 - Sqrt[2]}, 
    {(-1)^(1/4), (-I/2)*((1 + I) + Sqrt[2]), ((1 + I) + I*Sqrt[2])/2}, 
    {-(-1)^(1/4), ((1 + I) + I*Sqrt[2])/2, (-I/2)*((1 + I) + Sqrt[2])}}
 
LarsonK21Cat4FMatrixFunction[2, 2, 3, 2] = 
   {{1 + Sqrt[2], 1 + Sqrt[2], -1 - Sqrt[2]}, 
    {(-1)^(1/4), ((1 + I) + Sqrt[2])/2, (-I/2)*((1 - I) + Sqrt[2])}, 
    {-(-1)^(3/4), ((1 - I) + Sqrt[2])/2, (I/2)*((1 + I) + Sqrt[2])}}
 
LarsonK21Cat4FMatrixFunction[2, 2, 3, 3] = 
   {{-(1/Sqrt[2]), (-I/2)*((1 + I) + Sqrt[2])}, {((1 + I) + Sqrt[2])/2, 
     (-1)^(3/4)}}
 
LarsonK21Cat4FMatrixFunction[2, 3, 1, 1] = {{-(-1)^(3/4)}}
 
LarsonK21Cat4FMatrixFunction[2, 3, 1, 2] = {{-(-1)^(3/4)}}
 
LarsonK21Cat4FMatrixFunction[2, 3, 1, 3] = {{-(-1)^(3/4)}}
 
LarsonK21Cat4FMatrixFunction[2, 3, 2, 1] = {{(-1)^(1/4)}}
 
LarsonK21Cat4FMatrixFunction[2, 3, 2, 2] = 
   {{-1 - Sqrt[2], 1 + Sqrt[2], 1 + Sqrt[2]}, {-1, ((1 + I) + Sqrt[2])/2, 
     ((1 - I) + Sqrt[2])/2}, {-1, ((1 - I) + Sqrt[2])/2, 
     ((1 + I) + Sqrt[2])/2}}
 
LarsonK21Cat4FMatrixFunction[2, 3, 2, 3] = 
   {{((1 + I) + I*Sqrt[2])/2, 1/2 + I/2}, {1, ((1 - I) + Sqrt[2])/2}}
 
LarsonK21Cat4FMatrixFunction[2, 3, 3, 2] = 
   {{-(-1)^(3/4), (-I/2)*((1 + I) + Sqrt[2])}, {((1 + I) + Sqrt[2])/2, 
     1/Sqrt[2]}}
 
LarsonK21Cat4FMatrixFunction[2, 3, 3, 3] = 
   {{1 + Sqrt[2], (-1/2 + I/2)*(2 + Sqrt[2]), (-1/2 - I/2)*(2 + Sqrt[2])}, 
    {1, (I/2)*((1 + I) + Sqrt[2]), (-I/2)*((1 - I) + Sqrt[2])}, 
    {-1, ((1 - I) + Sqrt[2])/2, ((1 + I) + Sqrt[2])/2}}
 
LarsonK21Cat4FMatrixFunction[3, 1, 1, 3] = {{-1}}
 
LarsonK21Cat4FMatrixFunction[3, 1, 2, 1] = {{-I}}
 
LarsonK21Cat4FMatrixFunction[3, 1, 3, 0] = {{-(-1)^(1/4)}}
 
LarsonK21Cat4FMatrixFunction[3, 1, 3, 2] = {{-1}}
 
LarsonK21Cat4FMatrixFunction[3, 1, 3, 3] = {{-I}}
 
LarsonK21Cat4FMatrixFunction[3, 2, 1, 1] = {{-1}}
 
LarsonK21Cat4FMatrixFunction[3, 2, 1, 2] = {{-(-1)^(1/4)}}
 
LarsonK21Cat4FMatrixFunction[3, 2, 1, 3] = {{-(-1)^(3/4)}}
 
LarsonK21Cat4FMatrixFunction[3, 2, 2, 1] = {{-1}}
 
LarsonK21Cat4FMatrixFunction[3, 2, 2, 2] = 
   {{(-1/2 + I/2)*(2 + Sqrt[2]), 1 + Sqrt[2], (-I)*(1 + Sqrt[2])}, 
    {-1, ((1 + I) + Sqrt[2])/2, ((1 - I) + Sqrt[2])/2}, 
    {1, (-I/2)*((1 - I) + Sqrt[2]), (I/2)*((1 + I) + Sqrt[2])}}
 
LarsonK21Cat4FMatrixFunction[3, 2, 2, 3] = 
   {{(-1)^(3/4), ((1 + I) + Sqrt[2])/2}, {(-I/2)*((1 + I) + Sqrt[2]), 
     -(1/Sqrt[2])}}
 
LarsonK21Cat4FMatrixFunction[3, 2, 3, 1] = {{(-1)^(1/4)}}
 
LarsonK21Cat4FMatrixFunction[3, 2, 3, 2] = 
   {{((1 - I) + Sqrt[2])/2, -1/2 - I/2}, {-1, ((1 + I) + I*Sqrt[2])/2}}
 
LarsonK21Cat4FMatrixFunction[3, 2, 3, 3] = 
   {{-1 - Sqrt[2], 1 + Sqrt[2], 1 + Sqrt[2]}, {-1, ((1 + I) + Sqrt[2])/2, 
     ((1 - I) + Sqrt[2])/2}, {-1, ((1 - I) + Sqrt[2])/2, 
     ((1 + I) + Sqrt[2])/2}}
 
LarsonK21Cat4FMatrixFunction[3, 3, 1, 0] = {{-1}}
 
LarsonK21Cat4FMatrixFunction[3, 3, 1, 2] = {{(-1)^(1/4)}}
 
LarsonK21Cat4FMatrixFunction[3, 3, 1, 3] = {{-(-1)^(3/4)}}
 
LarsonK21Cat4FMatrixFunction[3, 3, 2, 1] = {{-1}}
 
LarsonK21Cat4FMatrixFunction[3, 3, 2, 2] = 
   {{1/Sqrt[2], ((1 + I) + Sqrt[2])/2}, {(-I/2)*((1 + I) + Sqrt[2]), 
     -(-1)^(3/4)}}
 
LarsonK21Cat4FMatrixFunction[3, 3, 2, 3] = 
   {{(1 + I) + (-1)^(1/4), -1 - Sqrt[2], 1 + Sqrt[2]}, 
    {1, (I/2)*((1 + I) + Sqrt[2]), ((1 - I) + Sqrt[2])/2}, 
    {I, (-I/2)*((1 - I) + Sqrt[2]), ((1 + I) + Sqrt[2])/2}}
 
LarsonK21Cat4FMatrixFunction[3, 3, 3, 1] = {{-(-1)^(3/4)}}
 
LarsonK21Cat4FMatrixFunction[3, 3, 3, 2] = 
   {{(-1/2 - I/2)*(2 + Sqrt[2]), (-1/2 + I/2)*(2 + Sqrt[2]), 
     (1/2 - I/2)*(2 + Sqrt[2])}, {1, (-I/2)*((1 + I) + Sqrt[2]), 
     ((1 + I) + I*Sqrt[2])/2}, {-1, ((1 + I) + I*Sqrt[2])/2, 
     (-I/2)*((1 + I) + Sqrt[2])}}
 
LarsonK21Cat4FMatrixFunction[3, 3, 3, 3] = {{((1 + I) + I*Sqrt[2])/2, -1}, 
    {-1/2 - I/2, ((1 - I) + Sqrt[2])/2}}
 
LarsonK21Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[LarsonK21Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
LarsonK21Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[LarsonK21Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[LarsonK21Cat4Piv1] ^= {}
 
fusionCategory[LarsonK21Cat4Piv1] ^= LarsonK21Cat4
 
LarsonK21Cat4Piv1 /: modularCategory[LarsonK21Cat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[LarsonK21Cat4Piv1] ^= LarsonK21Cat4Piv1
 
pivotalIsomorphism[LarsonK21Cat4Piv1] ^= LarsonK21Cat4Piv1PivotalIsomorphism
 
ring[LarsonK21Cat4Piv1] ^= LarsonK21
 
sphericalCategory[LarsonK21Cat4Piv1] ^= LarsonK21Cat4Piv1
 
(pivotalCategoryIndex[fusionCategory[LarsonK21Cat4]][pivotalCategory[#1]] & )[
    LarsonK21Cat4Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[LarsonK21Cat4]][
      sphericalCategory[#1]] & )[LarsonK21Cat4Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[LarsonK21Cat4Piv1PivotalIsomorphism] ^= LarsonK21Cat4
 
pivotalCategory[LarsonK21Cat4Piv1PivotalIsomorphism] ^= LarsonK21Cat4Piv1
 
pivotalIsomorphism[LarsonK21Cat4Piv1PivotalIsomorphism] ^= 
   LarsonK21Cat4Piv1PivotalIsomorphism
 
LarsonK21Cat4Piv1PivotalIsomorphism[0] = 1
 
LarsonK21Cat4Piv1PivotalIsomorphism[1] = -1
 
LarsonK21Cat4Piv1PivotalIsomorphism[2] = 1
 
LarsonK21Cat4Piv1PivotalIsomorphism[3] = 1
ring[LarsonK21NFunction] ^= LarsonK21
 
LarsonK21NFunction[0, 0, 0] = 1
 
LarsonK21NFunction[0, 0, 1] = 0
 
LarsonK21NFunction[0, 0, 2] = 0
 
LarsonK21NFunction[0, 0, 3] = 0
 
LarsonK21NFunction[0, 1, 0] = 0
 
LarsonK21NFunction[0, 1, 1] = 1
 
LarsonK21NFunction[0, 1, 2] = 0
 
LarsonK21NFunction[0, 1, 3] = 0
 
LarsonK21NFunction[0, 2, 0] = 0
 
LarsonK21NFunction[0, 2, 1] = 0
 
LarsonK21NFunction[0, 2, 2] = 1
 
LarsonK21NFunction[0, 2, 3] = 0
 
LarsonK21NFunction[0, 3, 0] = 0
 
LarsonK21NFunction[0, 3, 1] = 0
 
LarsonK21NFunction[0, 3, 2] = 0
 
LarsonK21NFunction[0, 3, 3] = 1
 
LarsonK21NFunction[1, 0, 0] = 0
 
LarsonK21NFunction[1, 0, 1] = 1
 
LarsonK21NFunction[1, 0, 2] = 0
 
LarsonK21NFunction[1, 0, 3] = 0
 
LarsonK21NFunction[1, 1, 0] = 1
 
LarsonK21NFunction[1, 1, 1] = 0
 
LarsonK21NFunction[1, 1, 2] = 0
 
LarsonK21NFunction[1, 1, 3] = 0
 
LarsonK21NFunction[1, 2, 0] = 0
 
LarsonK21NFunction[1, 2, 1] = 0
 
LarsonK21NFunction[1, 2, 2] = 0
 
LarsonK21NFunction[1, 2, 3] = 1
 
LarsonK21NFunction[1, 3, 0] = 0
 
LarsonK21NFunction[1, 3, 1] = 0
 
LarsonK21NFunction[1, 3, 2] = 1
 
LarsonK21NFunction[1, 3, 3] = 0
 
LarsonK21NFunction[2, 0, 0] = 0
 
LarsonK21NFunction[2, 0, 1] = 0
 
LarsonK21NFunction[2, 0, 2] = 1
 
LarsonK21NFunction[2, 0, 3] = 0
 
LarsonK21NFunction[2, 1, 0] = 0
 
LarsonK21NFunction[2, 1, 1] = 0
 
LarsonK21NFunction[2, 1, 2] = 0
 
LarsonK21NFunction[2, 1, 3] = 1
 
LarsonK21NFunction[2, 2, 0] = 0
 
LarsonK21NFunction[2, 2, 1] = 1
 
LarsonK21NFunction[2, 2, 2] = 1
 
LarsonK21NFunction[2, 2, 3] = 1
 
LarsonK21NFunction[2, 3, 0] = 1
 
LarsonK21NFunction[2, 3, 1] = 0
 
LarsonK21NFunction[2, 3, 2] = 1
 
LarsonK21NFunction[2, 3, 3] = 1
 
LarsonK21NFunction[3, 0, 0] = 0
 
LarsonK21NFunction[3, 0, 1] = 0
 
LarsonK21NFunction[3, 0, 2] = 0
 
LarsonK21NFunction[3, 0, 3] = 1
 
LarsonK21NFunction[3, 1, 0] = 0
 
LarsonK21NFunction[3, 1, 1] = 0
 
LarsonK21NFunction[3, 1, 2] = 1
 
LarsonK21NFunction[3, 1, 3] = 0
 
LarsonK21NFunction[3, 2, 0] = 1
 
LarsonK21NFunction[3, 2, 1] = 0
 
LarsonK21NFunction[3, 2, 2] = 1
 
LarsonK21NFunction[3, 2, 3] = 1
 
LarsonK21NFunction[3, 3, 0] = 0
 
LarsonK21NFunction[3, 3, 1] = 1
 
LarsonK21NFunction[3, 3, 2] = 1
 
LarsonK21NFunction[3, 3, 3] = 1
 
LarsonK21NFunction[FusionCategories`Data`LarsonK21`Private`a_, FusionCategories`Data`LarsonK21`Private`b_, FusionCategories`Data`LarsonK21`Private`c_] := 0


 EndPackage[]
