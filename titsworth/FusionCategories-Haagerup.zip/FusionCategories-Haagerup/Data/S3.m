BeginPackage["FusionCategories`Data`S3`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[S3] ^= {S3Cat1, S3Cat2, S3Cat3, S3Cat4, S3Cat5, S3Cat6}
 
S3 /: fusionCategory[S3, 1] = S3Cat1
 
S3 /: fusionCategory[S3, 2] = S3Cat2
 
S3 /: fusionCategory[S3, 3] = S3Cat3
 
S3 /: fusionCategory[S3, 4] = S3Cat4
 
S3 /: fusionCategory[S3, 5] = S3Cat5
 
S3 /: fusionCategory[S3, 6] = S3Cat6
 
nFunction[S3] ^= S3NFunction
 
noMultiplicities[S3] ^= True
 
rank[S3] ^= 6
 
ring[S3] ^= S3
balancedCategories[S3Cat1] ^= {}
 
braidedCategories[S3Cat1] ^= {}
 
coeval[S3Cat1] ^= 1/sixJFunction[S3Cat1][#1, dual[ring[S3Cat1]][#1], #1, #1, 
      0, 0] & 
 
eval[S3Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[S3Cat1] ^= S3Cat1FMatrixFunction
 
fusionCategory[S3Cat1] ^= S3Cat1
 
S3Cat1 /: modularCategory[S3Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[S3Cat1] ^= {S3Cat1Piv1, S3Cat1Piv2}
 
S3Cat1 /: pivotalCategory[S3Cat1, 1] = S3Cat1Piv1
 
S3Cat1 /: pivotalCategory[S3Cat1, 2] = S3Cat1Piv2
 
S3Cat1 /: pivotalCategory[S3Cat1, {1, -1, -1, -1, 1, 1}] = S3Cat1Piv2
 
S3Cat1 /: pivotalCategory[S3Cat1, {1, 1, 1, 1, 1, 1}] = S3Cat1Piv1
 
ring[S3Cat1] ^= S3
 
S3Cat1 /: sphericalCategory[S3Cat1, 1] = S3Cat1Piv1
 
S3Cat1 /: sphericalCategory[S3Cat1, 2] = S3Cat1Piv2
 
fusionCategoryIndex[S3][S3Cat1] ^= 1
fMatrixFunction[S3Cat1FMatrixFunction] ^= S3Cat1FMatrixFunction
 
fusionCategory[S3Cat1FMatrixFunction] ^= S3Cat1
 
ring[S3Cat1FMatrixFunction] ^= S3
 
S3Cat1FMatrixFunction[1, 1, 1, 1] = {{-1}}
 
S3Cat1FMatrixFunction[1, 1, 4, 4] = {{-1}}
 
S3Cat1FMatrixFunction[1, 1, 5, 5] = {{-1}}
 
S3Cat1FMatrixFunction[1, 3, 2, 3] = {{-1}}
 
S3Cat1FMatrixFunction[1, 4, 1, 5] = {{-1}}
 
S3Cat1FMatrixFunction[1, 4, 3, 4] = {{-1}}
 
S3Cat1FMatrixFunction[1, 4, 5, 1] = {{-1}}
 
S3Cat1FMatrixFunction[1, 5, 1, 4] = {{-1}}
 
S3Cat1FMatrixFunction[1, 5, 4, 1] = {{-1}}
 
S3Cat1FMatrixFunction[2, 2, 2, 2] = {{-1}}
 
S3Cat1FMatrixFunction[2, 2, 4, 4] = {{-1}}
 
S3Cat1FMatrixFunction[2, 2, 5, 5] = {{-1}}
 
S3Cat1FMatrixFunction[2, 3, 1, 3] = {{-1}}
 
S3Cat1FMatrixFunction[2, 4, 2, 5] = {{-1}}
 
S3Cat1FMatrixFunction[2, 4, 5, 2] = {{-1}}
 
S3Cat1FMatrixFunction[2, 5, 2, 4] = {{-1}}
 
S3Cat1FMatrixFunction[2, 5, 3, 5] = {{-1}}
 
S3Cat1FMatrixFunction[2, 5, 4, 2] = {{-1}}
 
S3Cat1FMatrixFunction[3, 1, 3, 2] = {{-1}}
 
S3Cat1FMatrixFunction[3, 2, 3, 1] = {{-1}}
 
S3Cat1FMatrixFunction[3, 3, 3, 3] = {{-1}}
 
S3Cat1FMatrixFunction[3, 3, 4, 4] = {{-1}}
 
S3Cat1FMatrixFunction[3, 3, 5, 5] = {{-1}}
 
S3Cat1FMatrixFunction[3, 4, 2, 4] = {{-1}}
 
S3Cat1FMatrixFunction[3, 4, 5, 3] = {{-1}}
 
S3Cat1FMatrixFunction[3, 5, 1, 5] = {{-1}}
 
S3Cat1FMatrixFunction[3, 5, 4, 3] = {{-1}}
 
S3Cat1FMatrixFunction[4, 1, 1, 4] = {{-1}}
 
S3Cat1FMatrixFunction[4, 1, 4, 1] = {{-1}}
 
S3Cat1FMatrixFunction[4, 2, 2, 4] = {{-1}}
 
S3Cat1FMatrixFunction[4, 2, 4, 2] = {{-1}}
 
S3Cat1FMatrixFunction[4, 2, 5, 3] = {{-1}}
 
S3Cat1FMatrixFunction[4, 3, 3, 4] = {{-1}}
 
S3Cat1FMatrixFunction[4, 3, 5, 1] = {{-1}}
 
S3Cat1FMatrixFunction[4, 4, 5, 4] = {{-1}}
 
S3Cat1FMatrixFunction[4, 5, 1, 1] = {{-1}}
 
S3Cat1FMatrixFunction[4, 5, 2, 2] = {{-1}}
 
S3Cat1FMatrixFunction[4, 5, 3, 3] = {{-1}}
 
S3Cat1FMatrixFunction[4, 5, 5, 5] = {{-1}}
 
S3Cat1FMatrixFunction[5, 1, 1, 5] = {{-1}}
 
S3Cat1FMatrixFunction[5, 1, 4, 3] = {{-1}}
 
S3Cat1FMatrixFunction[5, 1, 5, 1] = {{-1}}
 
S3Cat1FMatrixFunction[5, 2, 2, 5] = {{-1}}
 
S3Cat1FMatrixFunction[5, 2, 5, 2] = {{-1}}
 
S3Cat1FMatrixFunction[5, 3, 3, 5] = {{-1}}
 
S3Cat1FMatrixFunction[5, 3, 4, 2] = {{-1}}
 
S3Cat1FMatrixFunction[5, 4, 1, 1] = {{-1}}
 
S3Cat1FMatrixFunction[5, 4, 2, 2] = {{-1}}
 
S3Cat1FMatrixFunction[5, 4, 3, 3] = {{-1}}
 
S3Cat1FMatrixFunction[5, 4, 4, 4] = {{-1}}
 
S3Cat1FMatrixFunction[5, 5, 4, 5] = {{-1}}
 
S3Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[S3Cat1], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
S3Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[S3Cat1], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[S3Cat1Piv1] ^= {}
 
fusionCategory[S3Cat1Piv1] ^= S3Cat1
 
S3Cat1Piv1 /: modularCategory[S3Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[S3Cat1Piv1] ^= S3Cat1Piv1
 
pivotalIsomorphism[S3Cat1Piv1] ^= S3Cat1Piv1PivotalIsomorphism
 
ring[S3Cat1Piv1] ^= S3
 
sphericalCategory[S3Cat1Piv1] ^= S3Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[S3Cat1]][pivotalCategory[#1]] & )[
    S3Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[S3Cat1]][sphericalCategory[#1]] & )[
    S3Cat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[S3Cat1Piv1PivotalIsomorphism] ^= S3Cat1
 
pivotalCategory[S3Cat1Piv1PivotalIsomorphism] ^= S3Cat1Piv1
 
pivotalIsomorphism[S3Cat1Piv1PivotalIsomorphism] ^= 
   S3Cat1Piv1PivotalIsomorphism
 
S3Cat1Piv1PivotalIsomorphism[0] = 1
 
S3Cat1Piv1PivotalIsomorphism[1] = 1
 
S3Cat1Piv1PivotalIsomorphism[2] = 1
 
S3Cat1Piv1PivotalIsomorphism[3] = 1
 
S3Cat1Piv1PivotalIsomorphism[4] = 1
 
S3Cat1Piv1PivotalIsomorphism[5] = 1
balancedCategories[S3Cat1Piv2] ^= {}
 
fusionCategory[S3Cat1Piv2] ^= S3Cat1
 
S3Cat1Piv2 /: modularCategory[S3Cat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[S3Cat1Piv2] ^= S3Cat1Piv2
 
pivotalIsomorphism[S3Cat1Piv2] ^= S3Cat1Piv2PivotalIsomorphism
 
ring[S3Cat1Piv2] ^= S3
 
sphericalCategory[S3Cat1Piv2] ^= S3Cat1Piv2
 
(pivotalCategoryIndex[fusionCategory[S3Cat1]][pivotalCategory[#1]] & )[
    S3Cat1Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[S3Cat1]][sphericalCategory[#1]] & )[
    S3Cat1Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[S3Cat1Piv2PivotalIsomorphism] ^= S3Cat1
 
pivotalCategory[S3Cat1Piv2PivotalIsomorphism] ^= S3Cat1Piv2
 
pivotalIsomorphism[S3Cat1Piv2PivotalIsomorphism] ^= 
   S3Cat1Piv2PivotalIsomorphism
 
S3Cat1Piv2PivotalIsomorphism[0] = 1
 
S3Cat1Piv2PivotalIsomorphism[1] = -1
 
S3Cat1Piv2PivotalIsomorphism[2] = -1
 
S3Cat1Piv2PivotalIsomorphism[3] = -1
 
S3Cat1Piv2PivotalIsomorphism[4] = 1
 
S3Cat1Piv2PivotalIsomorphism[5] = 1
balancedCategories[S3Cat2] ^= {}
 
braidedCategories[S3Cat2] ^= {}
 
coeval[S3Cat2] ^= 1/sixJFunction[S3Cat2][#1, dual[ring[S3Cat2]][#1], #1, #1, 
      0, 0] & 
 
eval[S3Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[S3Cat2] ^= S3Cat2FMatrixFunction
 
fusionCategory[S3Cat2] ^= S3Cat2
 
S3Cat2 /: modularCategory[S3Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[S3Cat2] ^= {S3Cat2Piv1, S3Cat2Piv2}
 
S3Cat2 /: pivotalCategory[S3Cat2, 1] = S3Cat2Piv1
 
S3Cat2 /: pivotalCategory[S3Cat2, 2] = S3Cat2Piv2
 
S3Cat2 /: pivotalCategory[S3Cat2, {1, -1, -1, -1, 1, 1}] = S3Cat2Piv2
 
S3Cat2 /: pivotalCategory[S3Cat2, {1, 1, 1, 1, 1, 1}] = S3Cat2Piv1
 
ring[S3Cat2] ^= S3
 
S3Cat2 /: sphericalCategory[S3Cat2, 1] = S3Cat2Piv1
 
S3Cat2 /: sphericalCategory[S3Cat2, 2] = S3Cat2Piv2
 
fusionCategoryIndex[S3][S3Cat2] ^= 2
fMatrixFunction[S3Cat2FMatrixFunction] ^= S3Cat2FMatrixFunction
 
fusionCategory[S3Cat2FMatrixFunction] ^= S3Cat2
 
ring[S3Cat2FMatrixFunction] ^= S3
 
S3Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[S3Cat2], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
S3Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[S3Cat2], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[S3Cat2Piv1] ^= {}
 
fusionCategory[S3Cat2Piv1] ^= S3Cat2
 
S3Cat2Piv1 /: modularCategory[S3Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[S3Cat2Piv1] ^= S3Cat2Piv1
 
pivotalIsomorphism[S3Cat2Piv1] ^= S3Cat2Piv1PivotalIsomorphism
 
ring[S3Cat2Piv1] ^= S3
 
sphericalCategory[S3Cat2Piv1] ^= S3Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[S3Cat2]][pivotalCategory[#1]] & )[
    S3Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[S3Cat2]][sphericalCategory[#1]] & )[
    S3Cat2Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[S3Cat2Piv1PivotalIsomorphism] ^= S3Cat2
 
pivotalCategory[S3Cat2Piv1PivotalIsomorphism] ^= S3Cat2Piv1
 
pivotalIsomorphism[S3Cat2Piv1PivotalIsomorphism] ^= 
   S3Cat2Piv1PivotalIsomorphism
 
S3Cat2Piv1PivotalIsomorphism[0] = 1
 
S3Cat2Piv1PivotalIsomorphism[1] = 1
 
S3Cat2Piv1PivotalIsomorphism[2] = 1
 
S3Cat2Piv1PivotalIsomorphism[3] = 1
 
S3Cat2Piv1PivotalIsomorphism[4] = 1
 
S3Cat2Piv1PivotalIsomorphism[5] = 1
balancedCategories[S3Cat2Piv2] ^= {}
 
fusionCategory[S3Cat2Piv2] ^= S3Cat2
 
S3Cat2Piv2 /: modularCategory[S3Cat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[S3Cat2Piv2] ^= S3Cat2Piv2
 
pivotalIsomorphism[S3Cat2Piv2] ^= S3Cat2Piv2PivotalIsomorphism
 
ring[S3Cat2Piv2] ^= S3
 
sphericalCategory[S3Cat2Piv2] ^= S3Cat2Piv2
 
(pivotalCategoryIndex[fusionCategory[S3Cat2]][pivotalCategory[#1]] & )[
    S3Cat2Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[S3Cat2]][sphericalCategory[#1]] & )[
    S3Cat2Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[S3Cat2Piv2PivotalIsomorphism] ^= S3Cat2
 
pivotalCategory[S3Cat2Piv2PivotalIsomorphism] ^= S3Cat2Piv2
 
pivotalIsomorphism[S3Cat2Piv2PivotalIsomorphism] ^= 
   S3Cat2Piv2PivotalIsomorphism
 
S3Cat2Piv2PivotalIsomorphism[0] = 1
 
S3Cat2Piv2PivotalIsomorphism[1] = -1
 
S3Cat2Piv2PivotalIsomorphism[2] = -1
 
S3Cat2Piv2PivotalIsomorphism[3] = -1
 
S3Cat2Piv2PivotalIsomorphism[4] = 1
 
S3Cat2Piv2PivotalIsomorphism[5] = 1
balancedCategories[S3Cat3] ^= {}
 
braidedCategories[S3Cat3] ^= {}
 
coeval[S3Cat3] ^= 1/sixJFunction[S3Cat3][#1, dual[ring[S3Cat3]][#1], #1, #1, 
      0, 0] & 
 
eval[S3Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[S3Cat3] ^= S3Cat3FMatrixFunction
 
fusionCategory[S3Cat3] ^= S3Cat3
 
S3Cat3 /: modularCategory[S3Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[S3Cat3] ^= {S3Cat3Piv1, S3Cat3Piv2}
 
S3Cat3 /: pivotalCategory[S3Cat3, 1] = S3Cat3Piv1
 
S3Cat3 /: pivotalCategory[S3Cat3, 2] = S3Cat3Piv2
 
S3Cat3 /: pivotalCategory[S3Cat3, {1, -1, -1, -1, 1, 1}] = S3Cat3Piv2
 
S3Cat3 /: pivotalCategory[S3Cat3, {1, 1, 1, 1, 1, 1}] = S3Cat3Piv1
 
ring[S3Cat3] ^= S3
 
S3Cat3 /: sphericalCategory[S3Cat3, 1] = S3Cat3Piv1
 
S3Cat3 /: sphericalCategory[S3Cat3, 2] = S3Cat3Piv2
 
fusionCategoryIndex[S3][S3Cat3] ^= 3
fMatrixFunction[S3Cat3FMatrixFunction] ^= S3Cat3FMatrixFunction
 
fusionCategory[S3Cat3FMatrixFunction] ^= S3Cat3
 
ring[S3Cat3FMatrixFunction] ^= S3
 
S3Cat3FMatrixFunction[1, 1, 1, 1] = {{-1}}
 
S3Cat3FMatrixFunction[1, 1, 4, 4] = {{-1}}
 
S3Cat3FMatrixFunction[1, 1, 5, 5] = {{-1}}
 
S3Cat3FMatrixFunction[1, 2, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[1, 3, 2, 3] = {{(1 + I*Sqrt[3])/2}}
 
S3Cat3FMatrixFunction[1, 3, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[1, 4, 1, 5] = {{-1}}
 
S3Cat3FMatrixFunction[1, 4, 3, 4] = {{-1}}
 
S3Cat3FMatrixFunction[1, 4, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[1, 4, 5, 1] = {{-1}}
 
S3Cat3FMatrixFunction[1, 5, 1, 4] = {{-1}}
 
S3Cat3FMatrixFunction[1, 5, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[1, 5, 4, 1] = {{-1}}
 
S3Cat3FMatrixFunction[1, 5, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[2, 1, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[2, 2, 2, 2] = {{-1}}
 
S3Cat3FMatrixFunction[2, 2, 4, 4] = {{-1}}
 
S3Cat3FMatrixFunction[2, 2, 5, 5] = {{-1}}
 
S3Cat3FMatrixFunction[2, 3, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
S3Cat3FMatrixFunction[2, 4, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[2, 4, 2, 5] = {{-1}}
 
S3Cat3FMatrixFunction[2, 4, 5, 2] = {{-1}}
 
S3Cat3FMatrixFunction[2, 5, 2, 4] = {{-1}}
 
S3Cat3FMatrixFunction[2, 5, 3, 5] = {{-1}}
 
S3Cat3FMatrixFunction[2, 5, 4, 2] = {{-1}}
 
S3Cat3FMatrixFunction[2, 5, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[3, 1, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
S3Cat3FMatrixFunction[3, 1, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[3, 2, 3, 1] = {{(1 - I*Sqrt[3])/2}}
 
S3Cat3FMatrixFunction[3, 3, 3, 3] = {{-1}}
 
S3Cat3FMatrixFunction[3, 3, 4, 4] = {{-1}}
 
S3Cat3FMatrixFunction[3, 3, 5, 5] = {{-1}}
 
S3Cat3FMatrixFunction[3, 4, 2, 4] = {{-1}}
 
S3Cat3FMatrixFunction[3, 4, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[3, 4, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[3, 4, 5, 3] = {{-1}}
 
S3Cat3FMatrixFunction[3, 5, 1, 5] = {{-1}}
 
S3Cat3FMatrixFunction[3, 5, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[3, 5, 4, 3] = {{-1}}
 
S3Cat3FMatrixFunction[4, 1, 1, 4] = {{-1}}
 
S3Cat3FMatrixFunction[4, 1, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[4, 1, 4, 1] = {{-1}}
 
S3Cat3FMatrixFunction[4, 1, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[4, 2, 2, 4] = {{-1}}
 
S3Cat3FMatrixFunction[4, 2, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[4, 2, 4, 2] = {{-1}}
 
S3Cat3FMatrixFunction[4, 2, 5, 3] = {{-1}}
 
S3Cat3FMatrixFunction[4, 3, 3, 4] = {{-1}}
 
S3Cat3FMatrixFunction[4, 3, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[4, 3, 5, 1] = {{-1}}
 
S3Cat3FMatrixFunction[4, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[4, 4, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[4, 4, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[4, 4, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
S3Cat3FMatrixFunction[4, 5, 1, 1] = {{-1}}
 
S3Cat3FMatrixFunction[4, 5, 2, 2] = {{-1}}
 
S3Cat3FMatrixFunction[4, 5, 3, 3] = {{-1}}
 
S3Cat3FMatrixFunction[4, 5, 5, 5] = {{-1}}
 
S3Cat3FMatrixFunction[5, 1, 1, 5] = {{-1}}
 
S3Cat3FMatrixFunction[5, 1, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[5, 1, 4, 3] = {{-1}}
 
S3Cat3FMatrixFunction[5, 1, 5, 1] = {{-1}}
 
S3Cat3FMatrixFunction[5, 2, 2, 5] = {{-1}}
 
S3Cat3FMatrixFunction[5, 2, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[5, 2, 5, 2] = {{-1}}
 
S3Cat3FMatrixFunction[5, 3, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[5, 3, 3, 5] = {{-1}}
 
S3Cat3FMatrixFunction[5, 3, 4, 2] = {{-1}}
 
S3Cat3FMatrixFunction[5, 3, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[5, 4, 1, 1] = {{-1}}
 
S3Cat3FMatrixFunction[5, 4, 2, 2] = {{-1}}
 
S3Cat3FMatrixFunction[5, 4, 3, 3] = {{-1}}
 
S3Cat3FMatrixFunction[5, 4, 4, 4] = {{-1}}
 
S3Cat3FMatrixFunction[5, 5, 2, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[5, 5, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[5, 5, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
S3Cat3FMatrixFunction[5, 5, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[S3Cat3], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
S3Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[S3Cat3], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[S3Cat3Piv1] ^= {}
 
fusionCategory[S3Cat3Piv1] ^= S3Cat3
 
S3Cat3Piv1 /: modularCategory[S3Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[S3Cat3Piv1] ^= S3Cat3Piv1
 
pivotalIsomorphism[S3Cat3Piv1] ^= S3Cat3Piv1PivotalIsomorphism
 
ring[S3Cat3Piv1] ^= S3
 
sphericalCategory[S3Cat3Piv1] ^= S3Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[S3Cat3]][pivotalCategory[#1]] & )[
    S3Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[S3Cat3]][sphericalCategory[#1]] & )[
    S3Cat3Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[S3Cat3Piv1PivotalIsomorphism] ^= S3Cat3
 
pivotalCategory[S3Cat3Piv1PivotalIsomorphism] ^= S3Cat3Piv1
 
pivotalIsomorphism[S3Cat3Piv1PivotalIsomorphism] ^= 
   S3Cat3Piv1PivotalIsomorphism
 
S3Cat3Piv1PivotalIsomorphism[0] = 1
 
S3Cat3Piv1PivotalIsomorphism[1] = 1
 
S3Cat3Piv1PivotalIsomorphism[2] = 1
 
S3Cat3Piv1PivotalIsomorphism[3] = 1
 
S3Cat3Piv1PivotalIsomorphism[4] = 1
 
S3Cat3Piv1PivotalIsomorphism[5] = 1
balancedCategories[S3Cat3Piv2] ^= {}
 
fusionCategory[S3Cat3Piv2] ^= S3Cat3
 
S3Cat3Piv2 /: modularCategory[S3Cat3Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[S3Cat3Piv2] ^= S3Cat3Piv2
 
pivotalIsomorphism[S3Cat3Piv2] ^= S3Cat3Piv2PivotalIsomorphism
 
ring[S3Cat3Piv2] ^= S3
 
sphericalCategory[S3Cat3Piv2] ^= S3Cat3Piv2
 
(pivotalCategoryIndex[fusionCategory[S3Cat3]][pivotalCategory[#1]] & )[
    S3Cat3Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[S3Cat3]][sphericalCategory[#1]] & )[
    S3Cat3Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[S3Cat3Piv2PivotalIsomorphism] ^= S3Cat3
 
pivotalCategory[S3Cat3Piv2PivotalIsomorphism] ^= S3Cat3Piv2
 
pivotalIsomorphism[S3Cat3Piv2PivotalIsomorphism] ^= 
   S3Cat3Piv2PivotalIsomorphism
 
S3Cat3Piv2PivotalIsomorphism[0] = 1
 
S3Cat3Piv2PivotalIsomorphism[1] = -1
 
S3Cat3Piv2PivotalIsomorphism[2] = -1
 
S3Cat3Piv2PivotalIsomorphism[3] = -1
 
S3Cat3Piv2PivotalIsomorphism[4] = 1
 
S3Cat3Piv2PivotalIsomorphism[5] = 1
balancedCategories[S3Cat4] ^= {}
 
braidedCategories[S3Cat4] ^= {}
 
coeval[S3Cat4] ^= 1/sixJFunction[S3Cat4][#1, dual[ring[S3Cat4]][#1], #1, #1, 
      0, 0] & 
 
eval[S3Cat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[S3Cat4] ^= S3Cat4FMatrixFunction
 
fusionCategory[S3Cat4] ^= S3Cat4
 
S3Cat4 /: modularCategory[S3Cat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[S3Cat4] ^= {S3Cat4Piv1, S3Cat4Piv2}
 
S3Cat4 /: pivotalCategory[S3Cat4, 1] = S3Cat4Piv1
 
S3Cat4 /: pivotalCategory[S3Cat4, 2] = S3Cat4Piv2
 
S3Cat4 /: pivotalCategory[S3Cat4, {1, -1, -1, -1, 1, 1}] = S3Cat4Piv2
 
S3Cat4 /: pivotalCategory[S3Cat4, {1, 1, 1, 1, 1, 1}] = S3Cat4Piv1
 
ring[S3Cat4] ^= S3
 
S3Cat4 /: sphericalCategory[S3Cat4, 1] = S3Cat4Piv1
 
S3Cat4 /: sphericalCategory[S3Cat4, 2] = S3Cat4Piv2
 
fusionCategoryIndex[S3][S3Cat4] ^= 4
fMatrixFunction[S3Cat4FMatrixFunction] ^= S3Cat4FMatrixFunction
 
fusionCategory[S3Cat4FMatrixFunction] ^= S3Cat4
 
ring[S3Cat4FMatrixFunction] ^= S3
 
S3Cat4FMatrixFunction[1, 1, 1, 1] = {{-1}}
 
S3Cat4FMatrixFunction[1, 1, 4, 4] = {{-1}}
 
S3Cat4FMatrixFunction[1, 1, 5, 5] = {{-1}}
 
S3Cat4FMatrixFunction[1, 2, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[1, 3, 2, 3] = {{(1 - I*Sqrt[3])/2}}
 
S3Cat4FMatrixFunction[1, 3, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[1, 4, 1, 5] = {{-1}}
 
S3Cat4FMatrixFunction[1, 4, 3, 4] = {{-1}}
 
S3Cat4FMatrixFunction[1, 4, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[1, 4, 5, 1] = {{-1}}
 
S3Cat4FMatrixFunction[1, 5, 1, 4] = {{-1}}
 
S3Cat4FMatrixFunction[1, 5, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[1, 5, 4, 1] = {{-1}}
 
S3Cat4FMatrixFunction[1, 5, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[2, 1, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[2, 2, 2, 2] = {{-1}}
 
S3Cat4FMatrixFunction[2, 2, 4, 4] = {{-1}}
 
S3Cat4FMatrixFunction[2, 2, 5, 5] = {{-1}}
 
S3Cat4FMatrixFunction[2, 3, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
S3Cat4FMatrixFunction[2, 4, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[2, 4, 2, 5] = {{-1}}
 
S3Cat4FMatrixFunction[2, 4, 5, 2] = {{-1}}
 
S3Cat4FMatrixFunction[2, 5, 2, 4] = {{-1}}
 
S3Cat4FMatrixFunction[2, 5, 3, 5] = {{-1}}
 
S3Cat4FMatrixFunction[2, 5, 4, 2] = {{-1}}
 
S3Cat4FMatrixFunction[2, 5, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[3, 1, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
S3Cat4FMatrixFunction[3, 1, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[3, 2, 3, 1] = {{(1 + I*Sqrt[3])/2}}
 
S3Cat4FMatrixFunction[3, 3, 3, 3] = {{-1}}
 
S3Cat4FMatrixFunction[3, 3, 4, 4] = {{-1}}
 
S3Cat4FMatrixFunction[3, 3, 5, 5] = {{-1}}
 
S3Cat4FMatrixFunction[3, 4, 2, 4] = {{-1}}
 
S3Cat4FMatrixFunction[3, 4, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[3, 4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[3, 4, 5, 3] = {{-1}}
 
S3Cat4FMatrixFunction[3, 5, 1, 5] = {{-1}}
 
S3Cat4FMatrixFunction[3, 5, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[3, 5, 4, 3] = {{-1}}
 
S3Cat4FMatrixFunction[4, 1, 1, 4] = {{-1}}
 
S3Cat4FMatrixFunction[4, 1, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[4, 1, 4, 1] = {{-1}}
 
S3Cat4FMatrixFunction[4, 1, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[4, 2, 2, 4] = {{-1}}
 
S3Cat4FMatrixFunction[4, 2, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[4, 2, 4, 2] = {{-1}}
 
S3Cat4FMatrixFunction[4, 2, 5, 3] = {{-1}}
 
S3Cat4FMatrixFunction[4, 3, 3, 4] = {{-1}}
 
S3Cat4FMatrixFunction[4, 3, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[4, 3, 5, 1] = {{-1}}
 
S3Cat4FMatrixFunction[4, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[4, 4, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[4, 4, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[4, 4, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
S3Cat4FMatrixFunction[4, 5, 1, 1] = {{-1}}
 
S3Cat4FMatrixFunction[4, 5, 2, 2] = {{-1}}
 
S3Cat4FMatrixFunction[4, 5, 3, 3] = {{-1}}
 
S3Cat4FMatrixFunction[4, 5, 5, 5] = {{-1}}
 
S3Cat4FMatrixFunction[5, 1, 1, 5] = {{-1}}
 
S3Cat4FMatrixFunction[5, 1, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[5, 1, 4, 3] = {{-1}}
 
S3Cat4FMatrixFunction[5, 1, 5, 1] = {{-1}}
 
S3Cat4FMatrixFunction[5, 2, 2, 5] = {{-1}}
 
S3Cat4FMatrixFunction[5, 2, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[5, 2, 5, 2] = {{-1}}
 
S3Cat4FMatrixFunction[5, 3, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[5, 3, 3, 5] = {{-1}}
 
S3Cat4FMatrixFunction[5, 3, 4, 2] = {{-1}}
 
S3Cat4FMatrixFunction[5, 3, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[5, 4, 1, 1] = {{-1}}
 
S3Cat4FMatrixFunction[5, 4, 2, 2] = {{-1}}
 
S3Cat4FMatrixFunction[5, 4, 3, 3] = {{-1}}
 
S3Cat4FMatrixFunction[5, 4, 4, 4] = {{-1}}
 
S3Cat4FMatrixFunction[5, 5, 2, 1] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[5, 5, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[5, 5, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
S3Cat4FMatrixFunction[5, 5, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[S3Cat4], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
S3Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[S3Cat4], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[S3Cat4Piv1] ^= {}
 
fusionCategory[S3Cat4Piv1] ^= S3Cat4
 
S3Cat4Piv1 /: modularCategory[S3Cat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[S3Cat4Piv1] ^= S3Cat4Piv1
 
pivotalIsomorphism[S3Cat4Piv1] ^= S3Cat4Piv1PivotalIsomorphism
 
ring[S3Cat4Piv1] ^= S3
 
sphericalCategory[S3Cat4Piv1] ^= S3Cat4Piv1
 
(pivotalCategoryIndex[fusionCategory[S3Cat4]][pivotalCategory[#1]] & )[
    S3Cat4Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[S3Cat4]][sphericalCategory[#1]] & )[
    S3Cat4Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[S3Cat4Piv1PivotalIsomorphism] ^= S3Cat4
 
pivotalCategory[S3Cat4Piv1PivotalIsomorphism] ^= S3Cat4Piv1
 
pivotalIsomorphism[S3Cat4Piv1PivotalIsomorphism] ^= 
   S3Cat4Piv1PivotalIsomorphism
 
S3Cat4Piv1PivotalIsomorphism[0] = 1
 
S3Cat4Piv1PivotalIsomorphism[1] = 1
 
S3Cat4Piv1PivotalIsomorphism[2] = 1
 
S3Cat4Piv1PivotalIsomorphism[3] = 1
 
S3Cat4Piv1PivotalIsomorphism[4] = 1
 
S3Cat4Piv1PivotalIsomorphism[5] = 1
balancedCategories[S3Cat4Piv2] ^= {}
 
fusionCategory[S3Cat4Piv2] ^= S3Cat4
 
S3Cat4Piv2 /: modularCategory[S3Cat4Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[S3Cat4Piv2] ^= S3Cat4Piv2
 
pivotalIsomorphism[S3Cat4Piv2] ^= S3Cat4Piv2PivotalIsomorphism
 
ring[S3Cat4Piv2] ^= S3
 
sphericalCategory[S3Cat4Piv2] ^= S3Cat4Piv2
 
(pivotalCategoryIndex[fusionCategory[S3Cat4]][pivotalCategory[#1]] & )[
    S3Cat4Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[S3Cat4]][sphericalCategory[#1]] & )[
    S3Cat4Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[S3Cat4Piv2PivotalIsomorphism] ^= S3Cat4
 
pivotalCategory[S3Cat4Piv2PivotalIsomorphism] ^= S3Cat4Piv2
 
pivotalIsomorphism[S3Cat4Piv2PivotalIsomorphism] ^= 
   S3Cat4Piv2PivotalIsomorphism
 
S3Cat4Piv2PivotalIsomorphism[0] = 1
 
S3Cat4Piv2PivotalIsomorphism[1] = -1
 
S3Cat4Piv2PivotalIsomorphism[2] = -1
 
S3Cat4Piv2PivotalIsomorphism[3] = -1
 
S3Cat4Piv2PivotalIsomorphism[4] = 1
 
S3Cat4Piv2PivotalIsomorphism[5] = 1
balancedCategories[S3Cat5] ^= {}
 
braidedCategories[S3Cat5] ^= {}
 
coeval[S3Cat5] ^= 1/sixJFunction[S3Cat5][#1, dual[ring[S3Cat5]][#1], #1, #1, 
      0, 0] & 
 
eval[S3Cat5] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[S3Cat5] ^= S3Cat5FMatrixFunction
 
fusionCategory[S3Cat5] ^= S3Cat5
 
S3Cat5 /: modularCategory[S3Cat5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[S3Cat5] ^= {S3Cat5Piv1, S3Cat5Piv2}
 
S3Cat5 /: pivotalCategory[S3Cat5, 1] = S3Cat5Piv1
 
S3Cat5 /: pivotalCategory[S3Cat5, 2] = S3Cat5Piv2
 
S3Cat5 /: pivotalCategory[S3Cat5, {1, -1, -1, -1, 1, 1}] = S3Cat5Piv2
 
S3Cat5 /: pivotalCategory[S3Cat5, {1, 1, 1, 1, 1, 1}] = S3Cat5Piv1
 
ring[S3Cat5] ^= S3
 
S3Cat5 /: sphericalCategory[S3Cat5, 1] = S3Cat5Piv1
 
S3Cat5 /: sphericalCategory[S3Cat5, 2] = S3Cat5Piv2
 
fusionCategoryIndex[S3][S3Cat5] ^= 5
fMatrixFunction[S3Cat5FMatrixFunction] ^= S3Cat5FMatrixFunction
 
fusionCategory[S3Cat5FMatrixFunction] ^= S3Cat5
 
ring[S3Cat5FMatrixFunction] ^= S3
 
S3Cat5FMatrixFunction[1, 2, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[1, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[1, 3, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[1, 4, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[1, 5, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[1, 5, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[2, 1, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[2, 3, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[2, 4, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[2, 5, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[3, 1, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[3, 1, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[3, 2, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[3, 4, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[3, 4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[3, 5, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[4, 1, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[4, 1, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[4, 2, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[4, 3, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[4, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[4, 4, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[4, 4, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[4, 4, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[5, 1, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[5, 2, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[5, 3, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[5, 3, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[5, 5, 2, 1] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[5, 5, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[5, 5, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[5, 5, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat5FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[S3Cat5], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
S3Cat5FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[S3Cat5], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[S3Cat5Piv1] ^= {}
 
fusionCategory[S3Cat5Piv1] ^= S3Cat5
 
S3Cat5Piv1 /: modularCategory[S3Cat5Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[S3Cat5Piv1] ^= S3Cat5Piv1
 
pivotalIsomorphism[S3Cat5Piv1] ^= S3Cat5Piv1PivotalIsomorphism
 
ring[S3Cat5Piv1] ^= S3
 
sphericalCategory[S3Cat5Piv1] ^= S3Cat5Piv1
 
(pivotalCategoryIndex[fusionCategory[S3Cat5]][pivotalCategory[#1]] & )[
    S3Cat5Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[S3Cat5]][sphericalCategory[#1]] & )[
    S3Cat5Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[S3Cat5Piv1PivotalIsomorphism] ^= S3Cat5
 
pivotalCategory[S3Cat5Piv1PivotalIsomorphism] ^= S3Cat5Piv1
 
pivotalIsomorphism[S3Cat5Piv1PivotalIsomorphism] ^= 
   S3Cat5Piv1PivotalIsomorphism
 
S3Cat5Piv1PivotalIsomorphism[0] = 1
 
S3Cat5Piv1PivotalIsomorphism[1] = 1
 
S3Cat5Piv1PivotalIsomorphism[2] = 1
 
S3Cat5Piv1PivotalIsomorphism[3] = 1
 
S3Cat5Piv1PivotalIsomorphism[4] = 1
 
S3Cat5Piv1PivotalIsomorphism[5] = 1
balancedCategories[S3Cat5Piv2] ^= {}
 
fusionCategory[S3Cat5Piv2] ^= S3Cat5
 
S3Cat5Piv2 /: modularCategory[S3Cat5Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[S3Cat5Piv2] ^= S3Cat5Piv2
 
pivotalIsomorphism[S3Cat5Piv2] ^= S3Cat5Piv2PivotalIsomorphism
 
ring[S3Cat5Piv2] ^= S3
 
sphericalCategory[S3Cat5Piv2] ^= S3Cat5Piv2
 
(pivotalCategoryIndex[fusionCategory[S3Cat5]][pivotalCategory[#1]] & )[
    S3Cat5Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[S3Cat5]][sphericalCategory[#1]] & )[
    S3Cat5Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[S3Cat5Piv2PivotalIsomorphism] ^= S3Cat5
 
pivotalCategory[S3Cat5Piv2PivotalIsomorphism] ^= S3Cat5Piv2
 
pivotalIsomorphism[S3Cat5Piv2PivotalIsomorphism] ^= 
   S3Cat5Piv2PivotalIsomorphism
 
S3Cat5Piv2PivotalIsomorphism[0] = 1
 
S3Cat5Piv2PivotalIsomorphism[1] = -1
 
S3Cat5Piv2PivotalIsomorphism[2] = -1
 
S3Cat5Piv2PivotalIsomorphism[3] = -1
 
S3Cat5Piv2PivotalIsomorphism[4] = 1
 
S3Cat5Piv2PivotalIsomorphism[5] = 1
balancedCategories[S3Cat6] ^= {}
 
braidedCategories[S3Cat6] ^= {}
 
coeval[S3Cat6] ^= 1/sixJFunction[S3Cat6][#1, dual[ring[S3Cat6]][#1], #1, #1, 
      0, 0] & 
 
eval[S3Cat6] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[S3Cat6] ^= S3Cat6FMatrixFunction
 
fusionCategory[S3Cat6] ^= S3Cat6
 
S3Cat6 /: modularCategory[S3Cat6, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[S3Cat6] ^= {S3Cat6Piv1, S3Cat6Piv2}
 
S3Cat6 /: pivotalCategory[S3Cat6, 1] = S3Cat6Piv1
 
S3Cat6 /: pivotalCategory[S3Cat6, 2] = S3Cat6Piv2
 
S3Cat6 /: pivotalCategory[S3Cat6, {1, -1, -1, -1, 1, 1}] = S3Cat6Piv2
 
S3Cat6 /: pivotalCategory[S3Cat6, {1, 1, 1, 1, 1, 1}] = S3Cat6Piv1
 
ring[S3Cat6] ^= S3
 
S3Cat6 /: sphericalCategory[S3Cat6, 1] = S3Cat6Piv1
 
S3Cat6 /: sphericalCategory[S3Cat6, 2] = S3Cat6Piv2
 
fusionCategoryIndex[S3][S3Cat6] ^= 6
fMatrixFunction[S3Cat6FMatrixFunction] ^= S3Cat6FMatrixFunction
 
fusionCategory[S3Cat6FMatrixFunction] ^= S3Cat6
 
ring[S3Cat6FMatrixFunction] ^= S3
 
S3Cat6FMatrixFunction[1, 2, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[1, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[1, 3, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[1, 4, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[1, 5, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[1, 5, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[2, 1, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[2, 3, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[2, 4, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[2, 5, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[3, 1, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[3, 1, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[3, 2, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[3, 4, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[3, 4, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[3, 5, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[4, 1, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[4, 1, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[4, 2, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[4, 3, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[4, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[4, 4, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[4, 4, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[4, 4, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[5, 1, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[5, 2, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[5, 3, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[5, 3, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[5, 5, 2, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[5, 5, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[5, 5, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[5, 5, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
S3Cat6FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[S3Cat6], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
S3Cat6FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; 
    homDimension[ring[S3Cat6], FusionCategories`Private`o, 
      Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[S3Cat6Piv1] ^= {}
 
fusionCategory[S3Cat6Piv1] ^= S3Cat6
 
S3Cat6Piv1 /: modularCategory[S3Cat6Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[S3Cat6Piv1] ^= S3Cat6Piv1
 
pivotalIsomorphism[S3Cat6Piv1] ^= S3Cat6Piv1PivotalIsomorphism
 
ring[S3Cat6Piv1] ^= S3
 
sphericalCategory[S3Cat6Piv1] ^= S3Cat6Piv1
 
(pivotalCategoryIndex[fusionCategory[S3Cat6]][pivotalCategory[#1]] & )[
    S3Cat6Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[S3Cat6]][sphericalCategory[#1]] & )[
    S3Cat6Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[S3Cat6Piv1PivotalIsomorphism] ^= S3Cat6
 
pivotalCategory[S3Cat6Piv1PivotalIsomorphism] ^= S3Cat6Piv1
 
pivotalIsomorphism[S3Cat6Piv1PivotalIsomorphism] ^= 
   S3Cat6Piv1PivotalIsomorphism
 
S3Cat6Piv1PivotalIsomorphism[0] = 1
 
S3Cat6Piv1PivotalIsomorphism[1] = 1
 
S3Cat6Piv1PivotalIsomorphism[2] = 1
 
S3Cat6Piv1PivotalIsomorphism[3] = 1
 
S3Cat6Piv1PivotalIsomorphism[4] = 1
 
S3Cat6Piv1PivotalIsomorphism[5] = 1
balancedCategories[S3Cat6Piv2] ^= {}
 
fusionCategory[S3Cat6Piv2] ^= S3Cat6
 
S3Cat6Piv2 /: modularCategory[S3Cat6Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[S3Cat6Piv2] ^= S3Cat6Piv2
 
pivotalIsomorphism[S3Cat6Piv2] ^= S3Cat6Piv2PivotalIsomorphism
 
ring[S3Cat6Piv2] ^= S3
 
sphericalCategory[S3Cat6Piv2] ^= S3Cat6Piv2
 
(pivotalCategoryIndex[fusionCategory[S3Cat6]][pivotalCategory[#1]] & )[
    S3Cat6Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[S3Cat6]][sphericalCategory[#1]] & )[
    S3Cat6Piv2] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[S3Cat6Piv2PivotalIsomorphism] ^= S3Cat6
 
pivotalCategory[S3Cat6Piv2PivotalIsomorphism] ^= S3Cat6Piv2
 
pivotalIsomorphism[S3Cat6Piv2PivotalIsomorphism] ^= 
   S3Cat6Piv2PivotalIsomorphism
 
S3Cat6Piv2PivotalIsomorphism[0] = 1
 
S3Cat6Piv2PivotalIsomorphism[1] = -1
 
S3Cat6Piv2PivotalIsomorphism[2] = -1
 
S3Cat6Piv2PivotalIsomorphism[3] = -1
 
S3Cat6Piv2PivotalIsomorphism[4] = 1
 
S3Cat6Piv2PivotalIsomorphism[5] = 1
ring[S3NFunction] ^= S3
 
S3NFunction[0, 0, 0] = 1
 
S3NFunction[0, 0, 1] = 0
 
S3NFunction[0, 0, 2] = 0
 
S3NFunction[0, 0, 3] = 0
 
S3NFunction[0, 0, 4] = 0
 
S3NFunction[0, 0, 5] = 0
 
S3NFunction[0, 1, 0] = 0
 
S3NFunction[0, 1, 1] = 1
 
S3NFunction[0, 1, 2] = 0
 
S3NFunction[0, 1, 3] = 0
 
S3NFunction[0, 1, 4] = 0
 
S3NFunction[0, 1, 5] = 0
 
S3NFunction[0, 2, 0] = 0
 
S3NFunction[0, 2, 1] = 0
 
S3NFunction[0, 2, 2] = 1
 
S3NFunction[0, 2, 3] = 0
 
S3NFunction[0, 2, 4] = 0
 
S3NFunction[0, 2, 5] = 0
 
S3NFunction[0, 3, 0] = 0
 
S3NFunction[0, 3, 1] = 0
 
S3NFunction[0, 3, 2] = 0
 
S3NFunction[0, 3, 3] = 1
 
S3NFunction[0, 3, 4] = 0
 
S3NFunction[0, 3, 5] = 0
 
S3NFunction[0, 4, 0] = 0
 
S3NFunction[0, 4, 1] = 0
 
S3NFunction[0, 4, 2] = 0
 
S3NFunction[0, 4, 3] = 0
 
S3NFunction[0, 4, 4] = 1
 
S3NFunction[0, 4, 5] = 0
 
S3NFunction[0, 5, 0] = 0
 
S3NFunction[0, 5, 1] = 0
 
S3NFunction[0, 5, 2] = 0
 
S3NFunction[0, 5, 3] = 0
 
S3NFunction[0, 5, 4] = 0
 
S3NFunction[0, 5, 5] = 1
 
S3NFunction[1, 0, 0] = 0
 
S3NFunction[1, 0, 1] = 1
 
S3NFunction[1, 0, 2] = 0
 
S3NFunction[1, 0, 3] = 0
 
S3NFunction[1, 0, 4] = 0
 
S3NFunction[1, 0, 5] = 0
 
S3NFunction[1, 1, 0] = 1
 
S3NFunction[1, 1, 1] = 0
 
S3NFunction[1, 1, 2] = 0
 
S3NFunction[1, 1, 3] = 0
 
S3NFunction[1, 1, 4] = 0
 
S3NFunction[1, 1, 5] = 0
 
S3NFunction[1, 2, 0] = 0
 
S3NFunction[1, 2, 1] = 0
 
S3NFunction[1, 2, 2] = 0
 
S3NFunction[1, 2, 3] = 0
 
S3NFunction[1, 2, 4] = 1
 
S3NFunction[1, 2, 5] = 0
 
S3NFunction[1, 3, 0] = 0
 
S3NFunction[1, 3, 1] = 0
 
S3NFunction[1, 3, 2] = 0
 
S3NFunction[1, 3, 3] = 0
 
S3NFunction[1, 3, 4] = 0
 
S3NFunction[1, 3, 5] = 1
 
S3NFunction[1, 4, 0] = 0
 
S3NFunction[1, 4, 1] = 0
 
S3NFunction[1, 4, 2] = 1
 
S3NFunction[1, 4, 3] = 0
 
S3NFunction[1, 4, 4] = 0
 
S3NFunction[1, 4, 5] = 0
 
S3NFunction[1, 5, 0] = 0
 
S3NFunction[1, 5, 1] = 0
 
S3NFunction[1, 5, 2] = 0
 
S3NFunction[1, 5, 3] = 1
 
S3NFunction[1, 5, 4] = 0
 
S3NFunction[1, 5, 5] = 0
 
S3NFunction[2, 0, 0] = 0
 
S3NFunction[2, 0, 1] = 0
 
S3NFunction[2, 0, 2] = 1
 
S3NFunction[2, 0, 3] = 0
 
S3NFunction[2, 0, 4] = 0
 
S3NFunction[2, 0, 5] = 0
 
S3NFunction[2, 1, 0] = 0
 
S3NFunction[2, 1, 1] = 0
 
S3NFunction[2, 1, 2] = 0
 
S3NFunction[2, 1, 3] = 0
 
S3NFunction[2, 1, 4] = 0
 
S3NFunction[2, 1, 5] = 1
 
S3NFunction[2, 2, 0] = 1
 
S3NFunction[2, 2, 1] = 0
 
S3NFunction[2, 2, 2] = 0
 
S3NFunction[2, 2, 3] = 0
 
S3NFunction[2, 2, 4] = 0
 
S3NFunction[2, 2, 5] = 0
 
S3NFunction[2, 3, 0] = 0
 
S3NFunction[2, 3, 1] = 0
 
S3NFunction[2, 3, 2] = 0
 
S3NFunction[2, 3, 3] = 0
 
S3NFunction[2, 3, 4] = 1
 
S3NFunction[2, 3, 5] = 0
 
S3NFunction[2, 4, 0] = 0
 
S3NFunction[2, 4, 1] = 0
 
S3NFunction[2, 4, 2] = 0
 
S3NFunction[2, 4, 3] = 1
 
S3NFunction[2, 4, 4] = 0
 
S3NFunction[2, 4, 5] = 0
 
S3NFunction[2, 5, 0] = 0
 
S3NFunction[2, 5, 1] = 1
 
S3NFunction[2, 5, 2] = 0
 
S3NFunction[2, 5, 3] = 0
 
S3NFunction[2, 5, 4] = 0
 
S3NFunction[2, 5, 5] = 0
 
S3NFunction[3, 0, 0] = 0
 
S3NFunction[3, 0, 1] = 0
 
S3NFunction[3, 0, 2] = 0
 
S3NFunction[3, 0, 3] = 1
 
S3NFunction[3, 0, 4] = 0
 
S3NFunction[3, 0, 5] = 0
 
S3NFunction[3, 1, 0] = 0
 
S3NFunction[3, 1, 1] = 0
 
S3NFunction[3, 1, 2] = 0
 
S3NFunction[3, 1, 3] = 0
 
S3NFunction[3, 1, 4] = 1
 
S3NFunction[3, 1, 5] = 0
 
S3NFunction[3, 2, 0] = 0
 
S3NFunction[3, 2, 1] = 0
 
S3NFunction[3, 2, 2] = 0
 
S3NFunction[3, 2, 3] = 0
 
S3NFunction[3, 2, 4] = 0
 
S3NFunction[3, 2, 5] = 1
 
S3NFunction[3, 3, 0] = 1
 
S3NFunction[3, 3, 1] = 0
 
S3NFunction[3, 3, 2] = 0
 
S3NFunction[3, 3, 3] = 0
 
S3NFunction[3, 3, 4] = 0
 
S3NFunction[3, 3, 5] = 0
 
S3NFunction[3, 4, 0] = 0
 
S3NFunction[3, 4, 1] = 1
 
S3NFunction[3, 4, 2] = 0
 
S3NFunction[3, 4, 3] = 0
 
S3NFunction[3, 4, 4] = 0
 
S3NFunction[3, 4, 5] = 0
 
S3NFunction[3, 5, 0] = 0
 
S3NFunction[3, 5, 1] = 0
 
S3NFunction[3, 5, 2] = 1
 
S3NFunction[3, 5, 3] = 0
 
S3NFunction[3, 5, 4] = 0
 
S3NFunction[3, 5, 5] = 0
 
S3NFunction[4, 0, 0] = 0
 
S3NFunction[4, 0, 1] = 0
 
S3NFunction[4, 0, 2] = 0
 
S3NFunction[4, 0, 3] = 0
 
S3NFunction[4, 0, 4] = 1
 
S3NFunction[4, 0, 5] = 0
 
S3NFunction[4, 1, 0] = 0
 
S3NFunction[4, 1, 1] = 0
 
S3NFunction[4, 1, 2] = 0
 
S3NFunction[4, 1, 3] = 1
 
S3NFunction[4, 1, 4] = 0
 
S3NFunction[4, 1, 5] = 0
 
S3NFunction[4, 2, 0] = 0
 
S3NFunction[4, 2, 1] = 1
 
S3NFunction[4, 2, 2] = 0
 
S3NFunction[4, 2, 3] = 0
 
S3NFunction[4, 2, 4] = 0
 
S3NFunction[4, 2, 5] = 0
 
S3NFunction[4, 3, 0] = 0
 
S3NFunction[4, 3, 1] = 0
 
S3NFunction[4, 3, 2] = 1
 
S3NFunction[4, 3, 3] = 0
 
S3NFunction[4, 3, 4] = 0
 
S3NFunction[4, 3, 5] = 0
 
S3NFunction[4, 4, 0] = 0
 
S3NFunction[4, 4, 1] = 0
 
S3NFunction[4, 4, 2] = 0
 
S3NFunction[4, 4, 3] = 0
 
S3NFunction[4, 4, 4] = 0
 
S3NFunction[4, 4, 5] = 1
 
S3NFunction[4, 5, 0] = 1
 
S3NFunction[4, 5, 1] = 0
 
S3NFunction[4, 5, 2] = 0
 
S3NFunction[4, 5, 3] = 0
 
S3NFunction[4, 5, 4] = 0
 
S3NFunction[4, 5, 5] = 0
 
S3NFunction[5, 0, 0] = 0
 
S3NFunction[5, 0, 1] = 0
 
S3NFunction[5, 0, 2] = 0
 
S3NFunction[5, 0, 3] = 0
 
S3NFunction[5, 0, 4] = 0
 
S3NFunction[5, 0, 5] = 1
 
S3NFunction[5, 1, 0] = 0
 
S3NFunction[5, 1, 1] = 0
 
S3NFunction[5, 1, 2] = 1
 
S3NFunction[5, 1, 3] = 0
 
S3NFunction[5, 1, 4] = 0
 
S3NFunction[5, 1, 5] = 0
 
S3NFunction[5, 2, 0] = 0
 
S3NFunction[5, 2, 1] = 0
 
S3NFunction[5, 2, 2] = 0
 
S3NFunction[5, 2, 3] = 1
 
S3NFunction[5, 2, 4] = 0
 
S3NFunction[5, 2, 5] = 0
 
S3NFunction[5, 3, 0] = 0
 
S3NFunction[5, 3, 1] = 1
 
S3NFunction[5, 3, 2] = 0
 
S3NFunction[5, 3, 3] = 0
 
S3NFunction[5, 3, 4] = 0
 
S3NFunction[5, 3, 5] = 0
 
S3NFunction[5, 4, 0] = 1
 
S3NFunction[5, 4, 1] = 0
 
S3NFunction[5, 4, 2] = 0
 
S3NFunction[5, 4, 3] = 0
 
S3NFunction[5, 4, 4] = 0
 
S3NFunction[5, 4, 5] = 0
 
S3NFunction[5, 5, 0] = 0
 
S3NFunction[5, 5, 1] = 0
 
S3NFunction[5, 5, 2] = 0
 
S3NFunction[5, 5, 3] = 0
 
S3NFunction[5, 5, 4] = 1
 
S3NFunction[5, 5, 5] = 0
 
S3NFunction[FusionCategories`Data`S3`Private`a_, FusionCategories`Data`S3`Private`b_, FusionCategories`Data`S3`Private`c_] := 0


 EndPackage[]
