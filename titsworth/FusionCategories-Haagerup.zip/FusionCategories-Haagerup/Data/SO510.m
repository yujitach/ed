BeginPackage["FusionCategories`Data`SO510`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[SO510] ^= {SO510Cat1, SO510Cat2, SO510Cat3}
 
SO510 /: fusionCategory[SO510, 1] = SO510Cat1
 
SO510 /: fusionCategory[SO510, 2] = SO510Cat2
 
SO510 /: fusionCategory[SO510, 3] = SO510Cat3
 
nFunction[SO510] ^= SO510NFunction
 
noMultiplicities[SO510] ^= True
 
rank[SO510] ^= 4
 
ring[SO510] ^= SO510
balancedCategories[SO510Cat1] ^= {SO510Cat1Bal1, SO510Cat1Bal2, 
    SO510Cat1Bal3, SO510Cat1Bal4, SO510Cat1Bal5}
 
SO510Cat1 /: balancedCategory[SO510Cat1, 1] = SO510Cat1Bal1
 
SO510Cat1 /: balancedCategory[SO510Cat1, 2] = SO510Cat1Bal2
 
SO510Cat1 /: balancedCategory[SO510Cat1, 3] = SO510Cat1Bal3
 
SO510Cat1 /: balancedCategory[SO510Cat1, 4] = SO510Cat1Bal4
 
SO510Cat1 /: balancedCategory[SO510Cat1, 5] = SO510Cat1Bal5
 
braidedCategories[SO510Cat1] ^= {SO510Cat1Brd1, SO510Cat1Brd2, SO510Cat1Brd3, 
    SO510Cat1Brd4, SO510Cat1Brd5}
 
SO510Cat1 /: braidedCategory[SO510Cat1, 1] = SO510Cat1Brd1
 
SO510Cat1 /: braidedCategory[SO510Cat1, 2] = SO510Cat1Brd2
 
SO510Cat1 /: braidedCategory[SO510Cat1, 3] = SO510Cat1Brd3
 
SO510Cat1 /: braidedCategory[SO510Cat1, 4] = SO510Cat1Brd4
 
SO510Cat1 /: braidedCategory[SO510Cat1, 5] = SO510Cat1Brd5
 
coeval[SO510Cat1] ^= 1/sixJFunction[SO510Cat1][#1, dual[ring[SO510Cat1]][#1], 
      #1, #1, 0, 0] & 
 
eval[SO510Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[SO510Cat1] ^= SO510Cat1FMatrixFunction
 
fusionCategory[SO510Cat1] ^= SO510Cat1
 
SO510Cat1 /: modularCategory[SO510Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[SO510Cat1] ^= {SO510Cat1Piv1}
 
SO510Cat1 /: pivotalCategory[SO510Cat1, 1] = SO510Cat1Piv1
 
SO510Cat1 /: pivotalCategory[SO510Cat1, {1, 1, 1, 1}] = SO510Cat1Piv1
 
SO510Cat1 /: ribbonCategory[SO510Cat1, 1] = SO510Cat1Bal1
 
SO510Cat1 /: ribbonCategory[SO510Cat1, 2] = SO510Cat1Bal2
 
SO510Cat1 /: ribbonCategory[SO510Cat1, 3] = SO510Cat1Bal3
 
SO510Cat1 /: ribbonCategory[SO510Cat1, 4] = SO510Cat1Bal4
 
SO510Cat1 /: ribbonCategory[SO510Cat1, 5] = SO510Cat1Bal5
 
ring[SO510Cat1] ^= SO510
 
SO510Cat1 /: sphericalCategory[SO510Cat1, 1] = SO510Cat1Piv1
 
SO510Cat1 /: symmetricCategory[SO510Cat1, 1] = SO510Cat1Brd1
 
fusionCategoryIndex[SO510][SO510Cat1] ^= 1
balancedCategory[SO510Cat1Bal1] ^= SO510Cat1Bal1
 
braidedCategory[SO510Cat1Bal1] ^= SO510Cat1Brd1
 
fusionCategory[SO510Cat1Bal1] ^= SO510Cat1
 
pivotalCategory[SO510Cat1Bal1] ^= SO510Cat1Piv1
 
ribbonCategory[SO510Cat1Bal1] ^= SO510Cat1Bal1
 
ring[SO510Cat1Bal1] ^= SO510
 
sphericalCategory[SO510Cat1Bal1] ^= SO510Cat1Piv1
 
symmetricCategory[SO510Cat1Bal1] ^= SO510Cat1Brd1
 
(balancedCategoryIndex[braidedCategory[SO510Cat1Brd1]][
      balancedCategory[#1]] & )[SO510Cat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[SO510Cat1]][balancedCategory[#1]] & )[
    SO510Cat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[SO510Cat1Piv1]][
      balancedCategory[#1]] & )[SO510Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SO510Cat1Brd1]][ribbonCategory[#1]] & )[
    SO510Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SO510Cat1]][ribbonCategory[#1]] & )[
    SO510Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[SO510Cat1Piv1]][
      ribbonCategory[#1]] & )[SO510Cat1Bal1] ^= 1
balancedCategory[SO510Cat1Bal2] ^= SO510Cat1Bal2
 
braidedCategory[SO510Cat1Bal2] ^= SO510Cat1Brd2
 
fusionCategory[SO510Cat1Bal2] ^= SO510Cat1
 
pivotalCategory[SO510Cat1Bal2] ^= SO510Cat1Piv1
 
ribbonCategory[SO510Cat1Bal2] ^= SO510Cat1Bal2
 
ring[SO510Cat1Bal2] ^= SO510
 
sphericalCategory[SO510Cat1Bal2] ^= SO510Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SO510Cat1Brd2]][
      balancedCategory[#1]] & )[SO510Cat1Bal2] ^= 1
 
(balancedCategoryIndex[fusionCategory[SO510Cat1]][balancedCategory[#1]] & )[
    SO510Cat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[SO510Cat1Piv1]][
      balancedCategory[#1]] & )[SO510Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SO510Cat1Brd2]][ribbonCategory[#1]] & )[
    SO510Cat1Bal2] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SO510Cat1]][ribbonCategory[#1]] & )[
    SO510Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[SO510Cat1Piv1]][
      ribbonCategory[#1]] & )[SO510Cat1Bal2] ^= 2
balancedCategory[SO510Cat1Bal3] ^= SO510Cat1Bal3
 
braidedCategory[SO510Cat1Bal3] ^= SO510Cat1Brd3
 
fusionCategory[SO510Cat1Bal3] ^= SO510Cat1
 
pivotalCategory[SO510Cat1Bal3] ^= SO510Cat1Piv1
 
ribbonCategory[SO510Cat1Bal3] ^= SO510Cat1Bal3
 
ring[SO510Cat1Bal3] ^= SO510
 
sphericalCategory[SO510Cat1Bal3] ^= SO510Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SO510Cat1Brd3]][
      balancedCategory[#1]] & )[SO510Cat1Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[SO510Cat1]][balancedCategory[#1]] & )[
    SO510Cat1Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[SO510Cat1Piv1]][
      balancedCategory[#1]] & )[SO510Cat1Bal3] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SO510Cat1Brd3]][ribbonCategory[#1]] & )[
    SO510Cat1Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SO510Cat1]][ribbonCategory[#1]] & )[
    SO510Cat1Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[SO510Cat1Piv1]][
      ribbonCategory[#1]] & )[SO510Cat1Bal3] ^= 3
balancedCategory[SO510Cat1Bal4] ^= SO510Cat1Bal4
 
braidedCategory[SO510Cat1Bal4] ^= SO510Cat1Brd4
 
fusionCategory[SO510Cat1Bal4] ^= SO510Cat1
 
pivotalCategory[SO510Cat1Bal4] ^= SO510Cat1Piv1
 
ribbonCategory[SO510Cat1Bal4] ^= SO510Cat1Bal4
 
ring[SO510Cat1Bal4] ^= SO510
 
sphericalCategory[SO510Cat1Bal4] ^= SO510Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SO510Cat1Brd4]][
      balancedCategory[#1]] & )[SO510Cat1Bal4] ^= 1
 
(balancedCategoryIndex[fusionCategory[SO510Cat1]][balancedCategory[#1]] & )[
    SO510Cat1Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[SO510Cat1Piv1]][
      balancedCategory[#1]] & )[SO510Cat1Bal4] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SO510Cat1Brd4]][ribbonCategory[#1]] & )[
    SO510Cat1Bal4] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SO510Cat1]][ribbonCategory[#1]] & )[
    SO510Cat1Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[SO510Cat1Piv1]][
      ribbonCategory[#1]] & )[SO510Cat1Bal4] ^= 4
balancedCategory[SO510Cat1Bal5] ^= SO510Cat1Bal5
 
braidedCategory[SO510Cat1Bal5] ^= SO510Cat1Brd5
 
fusionCategory[SO510Cat1Bal5] ^= SO510Cat1
 
pivotalCategory[SO510Cat1Bal5] ^= SO510Cat1Piv1
 
ribbonCategory[SO510Cat1Bal5] ^= SO510Cat1Bal5
 
ring[SO510Cat1Bal5] ^= SO510
 
sphericalCategory[SO510Cat1Bal5] ^= SO510Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SO510Cat1Brd5]][
      balancedCategory[#1]] & )[SO510Cat1Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[SO510Cat1]][balancedCategory[#1]] & )[
    SO510Cat1Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[SO510Cat1Piv1]][
      balancedCategory[#1]] & )[SO510Cat1Bal5] ^= 5
 
(ribbonCategoryIndex[braidedCategory[SO510Cat1Brd5]][ribbonCategory[#1]] & )[
    SO510Cat1Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SO510Cat1]][ribbonCategory[#1]] & )[
    SO510Cat1Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[SO510Cat1Piv1]][
      ribbonCategory[#1]] & )[SO510Cat1Bal5] ^= 5
balancedCategories[SO510Cat1Brd1] ^= {SO510Cat1Bal1}
 
SO510Cat1Brd1 /: balancedCategory[SO510Cat1Brd1, 1] = SO510Cat1Bal1
 
braidedCategory[SO510Cat1Brd1] ^= SO510Cat1Brd1
 
fusionCategory[SO510Cat1Brd1] ^= SO510Cat1
 
SO510Cat1Brd1 /: modularCategory[SO510Cat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SO510Cat1Brd1 /: ribbonCategory[SO510Cat1Brd1, 1] = SO510Cat1Bal1
 
ring[SO510Cat1Brd1] ^= SO510
 
rMatrixFunction[SO510Cat1Brd1] ^= SO510Cat1Brd1RMatrixFunction
 
symmetricCategory[SO510Cat1Brd1] ^= SO510Cat1Brd1
 
(braidedCategoryIndex[fusionCategory[SO510Cat1]][braidedCategory[#1]] & )[
    SO510Cat1Brd1] ^= 1
 
(symmetricCategoryIndex[fusionCategory[SO510Cat1]][symmetricCategory[#1]] & )[
    SO510Cat1Brd1] ^= 1
braidedCategory[SO510Cat1Brd1RMatrixFunction] ^= SO510Cat1Brd1
 
fusionCategory[SO510Cat1Brd1RMatrixFunction] ^= SO510Cat1
 
rMatrixFunction[SO510Cat1Brd1RMatrixFunction] ^= SO510Cat1Brd1RMatrixFunction
 
SO510Cat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[1, 1, 0] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[1, 2, 2] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[1, 3, 3] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[2, 1, 2] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[2, 2, 0] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[2, 2, 1] = {{-1}}
 
SO510Cat1Brd1RMatrixFunction[2, 2, 3] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[2, 3, 2] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[2, 3, 3] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[3, 1, 3] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[3, 2, 2] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[3, 2, 3] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[3, 3, 0] = {{1}}
 
SO510Cat1Brd1RMatrixFunction[3, 3, 1] = {{-1}}
 
SO510Cat1Brd1RMatrixFunction[3, 3, 2] = {{1}}
balancedCategories[SO510Cat1Brd2] ^= {SO510Cat1Bal2}
 
SO510Cat1Brd2 /: balancedCategory[SO510Cat1Brd2, 1] = SO510Cat1Bal2
 
braidedCategory[SO510Cat1Brd2] ^= SO510Cat1Brd2
 
fusionCategory[SO510Cat1Brd2] ^= SO510Cat1
 
SO510Cat1Brd2 /: modularCategory[SO510Cat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SO510Cat1Brd2 /: ribbonCategory[SO510Cat1Brd2, 1] = SO510Cat1Bal2
 
ring[SO510Cat1Brd2] ^= SO510
 
rMatrixFunction[SO510Cat1Brd2] ^= SO510Cat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SO510Cat1]][braidedCategory[#1]] & )[
    SO510Cat1Brd2] ^= 2
braidedCategory[SO510Cat1Brd2RMatrixFunction] ^= SO510Cat1Brd2
 
fusionCategory[SO510Cat1Brd2RMatrixFunction] ^= SO510Cat1
 
rMatrixFunction[SO510Cat1Brd2RMatrixFunction] ^= SO510Cat1Brd2RMatrixFunction
 
SO510Cat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
SO510Cat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
SO510Cat1Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
SO510Cat1Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
SO510Cat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
SO510Cat1Brd2RMatrixFunction[1, 1, 0] = {{1}}
 
SO510Cat1Brd2RMatrixFunction[1, 2, 2] = {{1}}
 
SO510Cat1Brd2RMatrixFunction[1, 3, 3] = {{1}}
 
SO510Cat1Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
SO510Cat1Brd2RMatrixFunction[2, 1, 2] = {{1}}
 
SO510Cat1Brd2RMatrixFunction[2, 2, 0] = {{-(-1)^(3/5)}}
 
SO510Cat1Brd2RMatrixFunction[2, 2, 1] = {{(-1)^(3/5)}}
 
SO510Cat1Brd2RMatrixFunction[2, 2, 3] = {{(-1)^(2/5)}}
 
SO510Cat1Brd2RMatrixFunction[2, 3, 2] = {{-(-1)^(1/5)}}
 
SO510Cat1Brd2RMatrixFunction[2, 3, 3] = {{(-1)^(4/5)}}
 
SO510Cat1Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
SO510Cat1Brd2RMatrixFunction[3, 1, 3] = {{1}}
 
SO510Cat1Brd2RMatrixFunction[3, 2, 2] = {{-(-1)^(1/5)}}
 
SO510Cat1Brd2RMatrixFunction[3, 2, 3] = {{(-1)^(4/5)}}
 
SO510Cat1Brd2RMatrixFunction[3, 3, 0] = {{(-1)^(2/5)}}
 
SO510Cat1Brd2RMatrixFunction[3, 3, 1] = {{-(-1)^(2/5)}}
 
SO510Cat1Brd2RMatrixFunction[3, 3, 2] = {{-(-1)^(3/5)}}
balancedCategories[SO510Cat1Brd3] ^= {SO510Cat1Bal3}
 
SO510Cat1Brd3 /: balancedCategory[SO510Cat1Brd3, 1] = SO510Cat1Bal3
 
braidedCategory[SO510Cat1Brd3] ^= SO510Cat1Brd3
 
fusionCategory[SO510Cat1Brd3] ^= SO510Cat1
 
SO510Cat1Brd3 /: modularCategory[SO510Cat1Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SO510Cat1Brd3 /: ribbonCategory[SO510Cat1Brd3, 1] = SO510Cat1Bal3
 
ring[SO510Cat1Brd3] ^= SO510
 
rMatrixFunction[SO510Cat1Brd3] ^= SO510Cat1Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SO510Cat1]][braidedCategory[#1]] & )[
    SO510Cat1Brd3] ^= 3
braidedCategory[SO510Cat1Brd3RMatrixFunction] ^= SO510Cat1Brd3
 
fusionCategory[SO510Cat1Brd3RMatrixFunction] ^= SO510Cat1
 
rMatrixFunction[SO510Cat1Brd3RMatrixFunction] ^= SO510Cat1Brd3RMatrixFunction
 
SO510Cat1Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
SO510Cat1Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
SO510Cat1Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
SO510Cat1Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
SO510Cat1Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
SO510Cat1Brd3RMatrixFunction[1, 1, 0] = {{1}}
 
SO510Cat1Brd3RMatrixFunction[1, 2, 2] = {{1}}
 
SO510Cat1Brd3RMatrixFunction[1, 3, 3] = {{1}}
 
SO510Cat1Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
SO510Cat1Brd3RMatrixFunction[2, 1, 2] = {{1}}
 
SO510Cat1Brd3RMatrixFunction[2, 2, 0] = {{-(-1)^(1/5)}}
 
SO510Cat1Brd3RMatrixFunction[2, 2, 1] = {{(-1)^(1/5)}}
 
SO510Cat1Brd3RMatrixFunction[2, 2, 3] = {{(-1)^(4/5)}}
 
SO510Cat1Brd3RMatrixFunction[2, 3, 2] = {{(-1)^(2/5)}}
 
SO510Cat1Brd3RMatrixFunction[2, 3, 3] = {{-(-1)^(3/5)}}
 
SO510Cat1Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
SO510Cat1Brd3RMatrixFunction[3, 1, 3] = {{1}}
 
SO510Cat1Brd3RMatrixFunction[3, 2, 2] = {{(-1)^(2/5)}}
 
SO510Cat1Brd3RMatrixFunction[3, 2, 3] = {{-(-1)^(3/5)}}
 
SO510Cat1Brd3RMatrixFunction[3, 3, 0] = {{(-1)^(4/5)}}
 
SO510Cat1Brd3RMatrixFunction[3, 3, 1] = {{-(-1)^(4/5)}}
 
SO510Cat1Brd3RMatrixFunction[3, 3, 2] = {{-(-1)^(1/5)}}
balancedCategories[SO510Cat1Brd4] ^= {SO510Cat1Bal4}
 
SO510Cat1Brd4 /: balancedCategory[SO510Cat1Brd4, 1] = SO510Cat1Bal4
 
braidedCategory[SO510Cat1Brd4] ^= SO510Cat1Brd4
 
fusionCategory[SO510Cat1Brd4] ^= SO510Cat1
 
SO510Cat1Brd4 /: modularCategory[SO510Cat1Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SO510Cat1Brd4 /: ribbonCategory[SO510Cat1Brd4, 1] = SO510Cat1Bal4
 
ring[SO510Cat1Brd4] ^= SO510
 
rMatrixFunction[SO510Cat1Brd4] ^= SO510Cat1Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SO510Cat1]][braidedCategory[#1]] & )[
    SO510Cat1Brd4] ^= 4
braidedCategory[SO510Cat1Brd4RMatrixFunction] ^= SO510Cat1Brd4
 
fusionCategory[SO510Cat1Brd4RMatrixFunction] ^= SO510Cat1
 
rMatrixFunction[SO510Cat1Brd4RMatrixFunction] ^= SO510Cat1Brd4RMatrixFunction
 
SO510Cat1Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
SO510Cat1Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
SO510Cat1Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
SO510Cat1Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
SO510Cat1Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
SO510Cat1Brd4RMatrixFunction[1, 1, 0] = {{1}}
 
SO510Cat1Brd4RMatrixFunction[1, 2, 2] = {{1}}
 
SO510Cat1Brd4RMatrixFunction[1, 3, 3] = {{1}}
 
SO510Cat1Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
SO510Cat1Brd4RMatrixFunction[2, 1, 2] = {{1}}
 
SO510Cat1Brd4RMatrixFunction[2, 2, 0] = {{(-1)^(4/5)}}
 
SO510Cat1Brd4RMatrixFunction[2, 2, 1] = {{-(-1)^(4/5)}}
 
SO510Cat1Brd4RMatrixFunction[2, 2, 3] = {{-(-1)^(1/5)}}
 
SO510Cat1Brd4RMatrixFunction[2, 3, 2] = {{-(-1)^(3/5)}}
 
SO510Cat1Brd4RMatrixFunction[2, 3, 3] = {{(-1)^(2/5)}}
 
SO510Cat1Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
SO510Cat1Brd4RMatrixFunction[3, 1, 3] = {{1}}
 
SO510Cat1Brd4RMatrixFunction[3, 2, 2] = {{-(-1)^(3/5)}}
 
SO510Cat1Brd4RMatrixFunction[3, 2, 3] = {{(-1)^(2/5)}}
 
SO510Cat1Brd4RMatrixFunction[3, 3, 0] = {{-(-1)^(1/5)}}
 
SO510Cat1Brd4RMatrixFunction[3, 3, 1] = {{(-1)^(1/5)}}
 
SO510Cat1Brd4RMatrixFunction[3, 3, 2] = {{(-1)^(4/5)}}
balancedCategories[SO510Cat1Brd5] ^= {SO510Cat1Bal5}
 
SO510Cat1Brd5 /: balancedCategory[SO510Cat1Brd5, 1] = SO510Cat1Bal5
 
braidedCategory[SO510Cat1Brd5] ^= SO510Cat1Brd5
 
fusionCategory[SO510Cat1Brd5] ^= SO510Cat1
 
SO510Cat1Brd5 /: modularCategory[SO510Cat1Brd5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SO510Cat1Brd5 /: ribbonCategory[SO510Cat1Brd5, 1] = SO510Cat1Bal5
 
ring[SO510Cat1Brd5] ^= SO510
 
rMatrixFunction[SO510Cat1Brd5] ^= SO510Cat1Brd5RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SO510Cat1]][braidedCategory[#1]] & )[
    SO510Cat1Brd5] ^= 5
braidedCategory[SO510Cat1Brd5RMatrixFunction] ^= SO510Cat1Brd5
 
fusionCategory[SO510Cat1Brd5RMatrixFunction] ^= SO510Cat1
 
rMatrixFunction[SO510Cat1Brd5RMatrixFunction] ^= SO510Cat1Brd5RMatrixFunction
 
SO510Cat1Brd5RMatrixFunction[0, 0, 0] = {{1}}
 
SO510Cat1Brd5RMatrixFunction[0, 1, 1] = {{1}}
 
SO510Cat1Brd5RMatrixFunction[0, 2, 2] = {{1}}
 
SO510Cat1Brd5RMatrixFunction[0, 3, 3] = {{1}}
 
SO510Cat1Brd5RMatrixFunction[1, 0, 1] = {{1}}
 
SO510Cat1Brd5RMatrixFunction[1, 1, 0] = {{1}}
 
SO510Cat1Brd5RMatrixFunction[1, 2, 2] = {{1}}
 
SO510Cat1Brd5RMatrixFunction[1, 3, 3] = {{1}}
 
SO510Cat1Brd5RMatrixFunction[2, 0, 2] = {{1}}
 
SO510Cat1Brd5RMatrixFunction[2, 1, 2] = {{1}}
 
SO510Cat1Brd5RMatrixFunction[2, 2, 0] = {{(-1)^(2/5)}}
 
SO510Cat1Brd5RMatrixFunction[2, 2, 1] = {{-(-1)^(2/5)}}
 
SO510Cat1Brd5RMatrixFunction[2, 2, 3] = {{-(-1)^(3/5)}}
 
SO510Cat1Brd5RMatrixFunction[2, 3, 2] = {{(-1)^(4/5)}}
 
SO510Cat1Brd5RMatrixFunction[2, 3, 3] = {{-(-1)^(1/5)}}
 
SO510Cat1Brd5RMatrixFunction[3, 0, 3] = {{1}}
 
SO510Cat1Brd5RMatrixFunction[3, 1, 3] = {{1}}
 
SO510Cat1Brd5RMatrixFunction[3, 2, 2] = {{(-1)^(4/5)}}
 
SO510Cat1Brd5RMatrixFunction[3, 2, 3] = {{-(-1)^(1/5)}}
 
SO510Cat1Brd5RMatrixFunction[3, 3, 0] = {{-(-1)^(3/5)}}
 
SO510Cat1Brd5RMatrixFunction[3, 3, 1] = {{(-1)^(3/5)}}
 
SO510Cat1Brd5RMatrixFunction[3, 3, 2] = {{(-1)^(2/5)}}
fMatrixFunction[SO510Cat1FMatrixFunction] ^= SO510Cat1FMatrixFunction
 
fusionCategory[SO510Cat1FMatrixFunction] ^= SO510Cat1
 
ring[SO510Cat1FMatrixFunction] ^= SO510
 
SO510Cat1FMatrixFunction[1, 2, 2, 3] = {{-1}}
 
SO510Cat1FMatrixFunction[1, 2, 3, 2] = {{-1}}
 
SO510Cat1FMatrixFunction[1, 3, 2, 2] = {{-1}}
 
SO510Cat1FMatrixFunction[1, 3, 2, 3] = {{-1}}
 
SO510Cat1FMatrixFunction[1, 3, 3, 0] = {{-1}}
 
SO510Cat1FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
SO510Cat1FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
SO510Cat1FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
SO510Cat1FMatrixFunction[2, 1, 3, 3] = {{-1}}
 
SO510Cat1FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
SO510Cat1FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
SO510Cat1FMatrixFunction[2, 2, 1, 3] = {{-1}}
 
SO510Cat1FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1}, {-1/2, -1/2, 1}, 
    {1/2, -1/2, 0}}
 
SO510Cat1FMatrixFunction[2, 2, 3, 3] = {{1/2, -1/2}, {1/2, 1/2}}
 
SO510Cat1FMatrixFunction[2, 3, 1, 2] = {{-1}}
 
SO510Cat1FMatrixFunction[2, 3, 1, 3] = {{-1}}
 
SO510Cat1FMatrixFunction[2, 3, 2, 1] = {{-1}}
 
SO510Cat1FMatrixFunction[2, 3, 2, 3] = {{0, 1}, {1, 0}}
 
SO510Cat1FMatrixFunction[2, 3, 3, 1] = {{-1}}
 
SO510Cat1FMatrixFunction[2, 3, 3, 2] = {{1, 1}, {-1, 1}}
 
SO510Cat1FMatrixFunction[3, 1, 2, 3] = {{-1}}
 
SO510Cat1FMatrixFunction[3, 1, 3, 0] = {{-1}}
 
SO510Cat1FMatrixFunction[3, 1, 3, 1] = {{-1}}
 
SO510Cat1FMatrixFunction[3, 2, 1, 2] = {{-1}}
 
SO510Cat1FMatrixFunction[3, 2, 2, 3] = {{1, 1}, {1, -1}}
 
SO510Cat1FMatrixFunction[3, 2, 3, 1] = {{-1}}
 
SO510Cat1FMatrixFunction[3, 2, 3, 2] = {{0, 1}, {1, 0}}
 
SO510Cat1FMatrixFunction[3, 3, 2, 1] = {{-1}}
 
SO510Cat1FMatrixFunction[3, 3, 2, 2] = {{1/2, 1/2}, {1/2, -1/2}}
 
SO510Cat1FMatrixFunction[3, 3, 3, 3] = {{1/2, -1/2, 1}, {1/2, -1/2, -1}, 
    {1/2, 1/2, 0}}
 
SO510Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SO510Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
SO510Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SO510Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[SO510Cat1Piv1] ^= {SO510Cat1Bal1, SO510Cat1Bal2, 
    SO510Cat1Bal3, SO510Cat1Bal4, SO510Cat1Bal5}
 
SO510Cat1Piv1 /: balancedCategory[SO510Cat1Piv1, 1] = SO510Cat1Bal1
 
SO510Cat1Piv1 /: balancedCategory[SO510Cat1Piv1, 2] = SO510Cat1Bal2
 
SO510Cat1Piv1 /: balancedCategory[SO510Cat1Piv1, 3] = SO510Cat1Bal3
 
SO510Cat1Piv1 /: balancedCategory[SO510Cat1Piv1, 4] = SO510Cat1Bal4
 
SO510Cat1Piv1 /: balancedCategory[SO510Cat1Piv1, 5] = SO510Cat1Bal5
 
fusionCategory[SO510Cat1Piv1] ^= SO510Cat1
 
SO510Cat1Piv1 /: modularCategory[SO510Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SO510Cat1Piv1] ^= SO510Cat1Piv1
 
pivotalIsomorphism[SO510Cat1Piv1] ^= SO510Cat1Piv1PivotalIsomorphism
 
SO510Cat1Piv1 /: ribbonCategory[SO510Cat1Piv1, 1] = SO510Cat1Bal1
 
SO510Cat1Piv1 /: ribbonCategory[SO510Cat1Piv1, 2] = SO510Cat1Bal2
 
SO510Cat1Piv1 /: ribbonCategory[SO510Cat1Piv1, 3] = SO510Cat1Bal3
 
SO510Cat1Piv1 /: ribbonCategory[SO510Cat1Piv1, 4] = SO510Cat1Bal4
 
SO510Cat1Piv1 /: ribbonCategory[SO510Cat1Piv1, 5] = SO510Cat1Bal5
 
ring[SO510Cat1Piv1] ^= SO510
 
sphericalCategory[SO510Cat1Piv1] ^= SO510Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[SO510Cat1]][pivotalCategory[#1]] & )[
    SO510Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[SO510Cat1]][sphericalCategory[#1]] & )[
    SO510Cat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[SO510Cat1Piv1PivotalIsomorphism] ^= SO510Cat1
 
pivotalCategory[SO510Cat1Piv1PivotalIsomorphism] ^= SO510Cat1Piv1
 
pivotalIsomorphism[SO510Cat1Piv1PivotalIsomorphism] ^= 
   SO510Cat1Piv1PivotalIsomorphism
 
SO510Cat1Piv1PivotalIsomorphism[0] = 1
 
SO510Cat1Piv1PivotalIsomorphism[1] = 1
 
SO510Cat1Piv1PivotalIsomorphism[2] = 1
 
SO510Cat1Piv1PivotalIsomorphism[3] = 1
balancedCategories[SO510Cat2] ^= {}
 
braidedCategories[SO510Cat2] ^= {}
 
coeval[SO510Cat2] ^= 1/sixJFunction[SO510Cat2][#1, dual[ring[SO510Cat2]][#1], 
      #1, #1, 0, 0] & 
 
eval[SO510Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[SO510Cat2] ^= SO510Cat2FMatrixFunction
 
fusionCategory[SO510Cat2] ^= SO510Cat2
 
SO510Cat2 /: modularCategory[SO510Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[SO510Cat2] ^= {SO510Cat2Piv1}
 
SO510Cat2 /: pivotalCategory[SO510Cat2, 1] = SO510Cat2Piv1
 
SO510Cat2 /: pivotalCategory[SO510Cat2, {1, 1, 1, 1}] = SO510Cat2Piv1
 
ring[SO510Cat2] ^= SO510
 
SO510Cat2 /: sphericalCategory[SO510Cat2, 1] = SO510Cat2Piv1
 
fusionCategoryIndex[SO510][SO510Cat2] ^= 2
fMatrixFunction[SO510Cat2FMatrixFunction] ^= SO510Cat2FMatrixFunction
 
fusionCategory[SO510Cat2FMatrixFunction] ^= SO510Cat2
 
ring[SO510Cat2FMatrixFunction] ^= SO510
 
SO510Cat2FMatrixFunction[1, 2, 2, 3] = {{-1}}
 
SO510Cat2FMatrixFunction[1, 2, 3, 2] = {{-1}}
 
SO510Cat2FMatrixFunction[1, 3, 2, 2] = {{-1}}
 
SO510Cat2FMatrixFunction[1, 3, 2, 3] = {{-1}}
 
SO510Cat2FMatrixFunction[1, 3, 3, 0] = {{-1}}
 
SO510Cat2FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
SO510Cat2FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
SO510Cat2FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
SO510Cat2FMatrixFunction[2, 1, 3, 3] = {{-1}}
 
SO510Cat2FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
SO510Cat2FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
SO510Cat2FMatrixFunction[2, 2, 1, 3] = {{-1}}
 
SO510Cat2FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1}, {-1/2, -1/2, 1}, 
    {1/2, -1/2, 0}}
 
SO510Cat2FMatrixFunction[2, 2, 2, 3] = {{-(-1)^(1/5)}}
 
SO510Cat2FMatrixFunction[2, 2, 3, 2] = {{(-1)^(4/5)}}
 
SO510Cat2FMatrixFunction[2, 2, 3, 3] = {{1/2, -1/2}, {1/2, 1/2}}
 
SO510Cat2FMatrixFunction[2, 3, 1, 2] = {{-1}}
 
SO510Cat2FMatrixFunction[2, 3, 1, 3] = {{-1}}
 
SO510Cat2FMatrixFunction[2, 3, 2, 1] = {{-1}}
 
SO510Cat2FMatrixFunction[2, 3, 2, 2] = {{-(-1)^(1/5)}}
 
SO510Cat2FMatrixFunction[2, 3, 2, 3] = {{0, (-1)^(4/5)}, {(-1)^(4/5), 0}}
 
SO510Cat2FMatrixFunction[2, 3, 3, 1] = {{-1}}
 
SO510Cat2FMatrixFunction[2, 3, 3, 2] = {{1, 1}, {-1, 1}}
 
SO510Cat2FMatrixFunction[2, 3, 3, 3] = {{-(-1)^(1/5)}}
 
SO510Cat2FMatrixFunction[3, 1, 2, 3] = {{-1}}
 
SO510Cat2FMatrixFunction[3, 1, 3, 0] = {{-1}}
 
SO510Cat2FMatrixFunction[3, 1, 3, 1] = {{-1}}
 
SO510Cat2FMatrixFunction[3, 2, 1, 2] = {{-1}}
 
SO510Cat2FMatrixFunction[3, 2, 2, 2] = {{(-1)^(4/5)}}
 
SO510Cat2FMatrixFunction[3, 2, 2, 3] = {{1, 1}, {1, -1}}
 
SO510Cat2FMatrixFunction[3, 2, 3, 1] = {{-1}}
 
SO510Cat2FMatrixFunction[3, 2, 3, 2] = {{0, -(-1)^(1/5)}, {-(-1)^(1/5), 0}}
 
SO510Cat2FMatrixFunction[3, 2, 3, 3] = {{(-1)^(4/5)}}
 
SO510Cat2FMatrixFunction[3, 3, 2, 1] = {{-1}}
 
SO510Cat2FMatrixFunction[3, 3, 2, 2] = {{1/2, 1/2}, {1/2, -1/2}}
 
SO510Cat2FMatrixFunction[3, 3, 2, 3] = {{-(-1)^(1/5)}}
 
SO510Cat2FMatrixFunction[3, 3, 3, 2] = {{(-1)^(4/5)}}
 
SO510Cat2FMatrixFunction[3, 3, 3, 3] = {{1/2, -1/2, 1}, {1/2, -1/2, -1}, 
    {1/2, 1/2, 0}}
 
SO510Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SO510Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
SO510Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SO510Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[SO510Cat2Piv1] ^= {}
 
fusionCategory[SO510Cat2Piv1] ^= SO510Cat2
 
SO510Cat2Piv1 /: modularCategory[SO510Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SO510Cat2Piv1] ^= SO510Cat2Piv1
 
pivotalIsomorphism[SO510Cat2Piv1] ^= SO510Cat2Piv1PivotalIsomorphism
 
ring[SO510Cat2Piv1] ^= SO510
 
sphericalCategory[SO510Cat2Piv1] ^= SO510Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[SO510Cat2]][pivotalCategory[#1]] & )[
    SO510Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[SO510Cat2]][sphericalCategory[#1]] & )[
    SO510Cat2Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[SO510Cat2Piv1PivotalIsomorphism] ^= SO510Cat2
 
pivotalCategory[SO510Cat2Piv1PivotalIsomorphism] ^= SO510Cat2Piv1
 
pivotalIsomorphism[SO510Cat2Piv1PivotalIsomorphism] ^= 
   SO510Cat2Piv1PivotalIsomorphism
 
SO510Cat2Piv1PivotalIsomorphism[0] = 1
 
SO510Cat2Piv1PivotalIsomorphism[1] = 1
 
SO510Cat2Piv1PivotalIsomorphism[2] = 1
 
SO510Cat2Piv1PivotalIsomorphism[3] = 1
balancedCategories[SO510Cat3] ^= {}
 
braidedCategories[SO510Cat3] ^= {}
 
coeval[SO510Cat3] ^= 1/sixJFunction[SO510Cat3][#1, dual[ring[SO510Cat3]][#1], 
      #1, #1, 0, 0] & 
 
eval[SO510Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[SO510Cat3] ^= SO510Cat3FMatrixFunction
 
fusionCategory[SO510Cat3] ^= SO510Cat3
 
SO510Cat3 /: modularCategory[SO510Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[SO510Cat3] ^= {SO510Cat3Piv1}
 
SO510Cat3 /: pivotalCategory[SO510Cat3, 1] = SO510Cat3Piv1
 
SO510Cat3 /: pivotalCategory[SO510Cat3, {1, 1, 1, 1}] = SO510Cat3Piv1
 
ring[SO510Cat3] ^= SO510
 
SO510Cat3 /: sphericalCategory[SO510Cat3, 1] = SO510Cat3Piv1
 
fusionCategoryIndex[SO510][SO510Cat3] ^= 3
fMatrixFunction[SO510Cat3FMatrixFunction] ^= SO510Cat3FMatrixFunction
 
fusionCategory[SO510Cat3FMatrixFunction] ^= SO510Cat3
 
ring[SO510Cat3FMatrixFunction] ^= SO510
 
SO510Cat3FMatrixFunction[1, 2, 2, 3] = {{-1}}
 
SO510Cat3FMatrixFunction[1, 2, 3, 2] = {{-1}}
 
SO510Cat3FMatrixFunction[1, 3, 2, 2] = {{-1}}
 
SO510Cat3FMatrixFunction[1, 3, 2, 3] = {{-1}}
 
SO510Cat3FMatrixFunction[1, 3, 3, 0] = {{-1}}
 
SO510Cat3FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
SO510Cat3FMatrixFunction[2, 1, 2, 0] = {{-1}}
 
SO510Cat3FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
SO510Cat3FMatrixFunction[2, 1, 3, 3] = {{-1}}
 
SO510Cat3FMatrixFunction[2, 2, 1, 0] = {{-1}}
 
SO510Cat3FMatrixFunction[2, 2, 1, 1] = {{-1}}
 
SO510Cat3FMatrixFunction[2, 2, 1, 3] = {{-1}}
 
SO510Cat3FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1}, {-1/2, -1/2, 1}, 
    {1/2, -1/2, 0}}
 
SO510Cat3FMatrixFunction[2, 2, 2, 3] = {{(-1)^(2/5)}}
 
SO510Cat3FMatrixFunction[2, 2, 3, 2] = {{-(-1)^(3/5)}}
 
SO510Cat3FMatrixFunction[2, 2, 3, 3] = {{1/2, -1/2}, {1/2, 1/2}}
 
SO510Cat3FMatrixFunction[2, 3, 1, 2] = {{-1}}
 
SO510Cat3FMatrixFunction[2, 3, 1, 3] = {{-1}}
 
SO510Cat3FMatrixFunction[2, 3, 2, 1] = {{-1}}
 
SO510Cat3FMatrixFunction[2, 3, 2, 2] = {{(-1)^(2/5)}}
 
SO510Cat3FMatrixFunction[2, 3, 2, 3] = {{0, -(-1)^(3/5)}, {-(-1)^(3/5), 0}}
 
SO510Cat3FMatrixFunction[2, 3, 3, 1] = {{-1}}
 
SO510Cat3FMatrixFunction[2, 3, 3, 2] = {{1, 1}, {-1, 1}}
 
SO510Cat3FMatrixFunction[2, 3, 3, 3] = {{(-1)^(2/5)}}
 
SO510Cat3FMatrixFunction[3, 1, 2, 3] = {{-1}}
 
SO510Cat3FMatrixFunction[3, 1, 3, 0] = {{-1}}
 
SO510Cat3FMatrixFunction[3, 1, 3, 1] = {{-1}}
 
SO510Cat3FMatrixFunction[3, 2, 1, 2] = {{-1}}
 
SO510Cat3FMatrixFunction[3, 2, 2, 2] = {{-(-1)^(3/5)}}
 
SO510Cat3FMatrixFunction[3, 2, 2, 3] = {{1, 1}, {1, -1}}
 
SO510Cat3FMatrixFunction[3, 2, 3, 1] = {{-1}}
 
SO510Cat3FMatrixFunction[3, 2, 3, 2] = {{0, (-1)^(2/5)}, {(-1)^(2/5), 0}}
 
SO510Cat3FMatrixFunction[3, 2, 3, 3] = {{-(-1)^(3/5)}}
 
SO510Cat3FMatrixFunction[3, 3, 2, 1] = {{-1}}
 
SO510Cat3FMatrixFunction[3, 3, 2, 2] = {{1/2, 1/2}, {1/2, -1/2}}
 
SO510Cat3FMatrixFunction[3, 3, 2, 3] = {{(-1)^(2/5)}}
 
SO510Cat3FMatrixFunction[3, 3, 3, 2] = {{-(-1)^(3/5)}}
 
SO510Cat3FMatrixFunction[3, 3, 3, 3] = {{1/2, -1/2, 1}, {1/2, -1/2, -1}, 
    {1/2, 1/2, 0}}
 
SO510Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SO510Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
SO510Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SO510Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[SO510Cat3Piv1] ^= {}
 
fusionCategory[SO510Cat3Piv1] ^= SO510Cat3
 
SO510Cat3Piv1 /: modularCategory[SO510Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SO510Cat3Piv1] ^= SO510Cat3Piv1
 
pivotalIsomorphism[SO510Cat3Piv1] ^= SO510Cat3Piv1PivotalIsomorphism
 
ring[SO510Cat3Piv1] ^= SO510
 
sphericalCategory[SO510Cat3Piv1] ^= SO510Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[SO510Cat3]][pivotalCategory[#1]] & )[
    SO510Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[SO510Cat3]][sphericalCategory[#1]] & )[
    SO510Cat3Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[SO510Cat3Piv1PivotalIsomorphism] ^= SO510Cat3
 
pivotalCategory[SO510Cat3Piv1PivotalIsomorphism] ^= SO510Cat3Piv1
 
pivotalIsomorphism[SO510Cat3Piv1PivotalIsomorphism] ^= 
   SO510Cat3Piv1PivotalIsomorphism
 
SO510Cat3Piv1PivotalIsomorphism[0] = 1
 
SO510Cat3Piv1PivotalIsomorphism[1] = 1
 
SO510Cat3Piv1PivotalIsomorphism[2] = 1
 
SO510Cat3Piv1PivotalIsomorphism[3] = 1
ring[SO510NFunction] ^= SO510
 
SO510NFunction[0, 0, 0] = 1
 
SO510NFunction[0, 0, 1] = 0
 
SO510NFunction[0, 0, 2] = 0
 
SO510NFunction[0, 0, 3] = 0
 
SO510NFunction[0, 1, 0] = 0
 
SO510NFunction[0, 1, 1] = 1
 
SO510NFunction[0, 1, 2] = 0
 
SO510NFunction[0, 1, 3] = 0
 
SO510NFunction[0, 2, 0] = 0
 
SO510NFunction[0, 2, 1] = 0
 
SO510NFunction[0, 2, 2] = 1
 
SO510NFunction[0, 2, 3] = 0
 
SO510NFunction[0, 3, 0] = 0
 
SO510NFunction[0, 3, 1] = 0
 
SO510NFunction[0, 3, 2] = 0
 
SO510NFunction[0, 3, 3] = 1
 
SO510NFunction[1, 0, 0] = 0
 
SO510NFunction[1, 0, 1] = 1
 
SO510NFunction[1, 0, 2] = 0
 
SO510NFunction[1, 0, 3] = 0
 
SO510NFunction[1, 1, 0] = 1
 
SO510NFunction[1, 1, 1] = 0
 
SO510NFunction[1, 1, 2] = 0
 
SO510NFunction[1, 1, 3] = 0
 
SO510NFunction[1, 2, 0] = 0
 
SO510NFunction[1, 2, 1] = 0
 
SO510NFunction[1, 2, 2] = 1
 
SO510NFunction[1, 2, 3] = 0
 
SO510NFunction[1, 3, 0] = 0
 
SO510NFunction[1, 3, 1] = 0
 
SO510NFunction[1, 3, 2] = 0
 
SO510NFunction[1, 3, 3] = 1
 
SO510NFunction[2, 0, 0] = 0
 
SO510NFunction[2, 0, 1] = 0
 
SO510NFunction[2, 0, 2] = 1
 
SO510NFunction[2, 0, 3] = 0
 
SO510NFunction[2, 1, 0] = 0
 
SO510NFunction[2, 1, 1] = 0
 
SO510NFunction[2, 1, 2] = 1
 
SO510NFunction[2, 1, 3] = 0
 
SO510NFunction[2, 2, 0] = 1
 
SO510NFunction[2, 2, 1] = 1
 
SO510NFunction[2, 2, 2] = 0
 
SO510NFunction[2, 2, 3] = 1
 
SO510NFunction[2, 3, 0] = 0
 
SO510NFunction[2, 3, 1] = 0
 
SO510NFunction[2, 3, 2] = 1
 
SO510NFunction[2, 3, 3] = 1
 
SO510NFunction[3, 0, 0] = 0
 
SO510NFunction[3, 0, 1] = 0
 
SO510NFunction[3, 0, 2] = 0
 
SO510NFunction[3, 0, 3] = 1
 
SO510NFunction[3, 1, 0] = 0
 
SO510NFunction[3, 1, 1] = 0
 
SO510NFunction[3, 1, 2] = 0
 
SO510NFunction[3, 1, 3] = 1
 
SO510NFunction[3, 2, 0] = 0
 
SO510NFunction[3, 2, 1] = 0
 
SO510NFunction[3, 2, 2] = 1
 
SO510NFunction[3, 2, 3] = 1
 
SO510NFunction[3, 3, 0] = 1
 
SO510NFunction[3, 3, 1] = 1
 
SO510NFunction[3, 3, 2] = 1
 
SO510NFunction[3, 3, 3] = 0
 
SO510NFunction[FusionCategories`Data`SO510`Private`a_, FusionCategories`Data`SO510`Private`b_, FusionCategories`Data`SO510`Private`c_] := 0


 EndPackage[]
