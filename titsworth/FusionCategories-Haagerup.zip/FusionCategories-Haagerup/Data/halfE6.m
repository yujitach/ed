BeginPackage["FusionCategories`Data`halfE6`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[halfE6] ^= {halfE6Cat1, halfE6Cat2, halfE6Cat3, halfE6Cat4}
 
halfE6 /: fusionCategory[halfE6, 1] = halfE6Cat1
 
halfE6 /: fusionCategory[halfE6, 2] = halfE6Cat2
 
halfE6 /: fusionCategory[halfE6, 3] = halfE6Cat3
 
halfE6 /: fusionCategory[halfE6, 4] = halfE6Cat4
 
nFunction[halfE6] ^= halfE6NFunction
 
noMultiplicities[halfE6] ^= False
 
rank[halfE6] ^= 3
 
ring[halfE6] ^= halfE6
balancedCategories[halfE6Cat1] ^= {}
 
braidedCategories[halfE6Cat1] ^= {}
 
coeval[halfE6Cat1] ^= 1/sixJFunction[halfE6Cat1][#1, 
      dual[ring[halfE6Cat1]][#1], #1, #1, 0, 0] & 
 
eval[halfE6Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[halfE6Cat1] ^= halfE6Cat1FMatrixFunction
 
fusionCategory[halfE6Cat1] ^= halfE6Cat1
 
halfE6Cat1 /: modularCategory[halfE6Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[halfE6Cat1] ^= {halfE6Cat1Piv1}
 
halfE6Cat1 /: pivotalCategory[halfE6Cat1, 1] = halfE6Cat1Piv1
 
halfE6Cat1 /: pivotalCategory[halfE6Cat1, {1, 1, 1}] = halfE6Cat1Piv1
 
ring[halfE6Cat1] ^= halfE6
 
halfE6Cat1 /: sphericalCategory[halfE6Cat1, 1] = halfE6Cat1Piv1
 
fusionCategoryIndex[halfE6][halfE6Cat1] ^= 1
fMatrixFunction[halfE6Cat1FMatrixFunction] ^= halfE6Cat1FMatrixFunction
 
fusionCategory[halfE6Cat1FMatrixFunction] ^= halfE6Cat1
 
ring[halfE6Cat1FMatrixFunction] ^= halfE6
 
halfE6Cat1FMatrixFunction[1, 2, 1, 2] = {{-1}}
 
halfE6Cat1FMatrixFunction[1, 2, 2, 2] = {{0, I}, {-I, 0}}
 
halfE6Cat1FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
halfE6Cat1FMatrixFunction[2, 1, 2, 2] = {{1, 0}, {0, -1}}
 
halfE6Cat1FMatrixFunction[2, 2, 1, 2] = {{0, 1}, {1, 0}}
 
halfE6Cat1FMatrixFunction[2, 2, 2, 0] = 
   {{(-1/4 - I/4)*(I + Sqrt[3]), (-1/4 - I/4)*(I + Sqrt[3])}, 
    {(-1/4 + I/4)*(I + Sqrt[3]), (1/4 + I/4)*(1 - I*Sqrt[3])}}
 
halfE6Cat1FMatrixFunction[2, 2, 2, 1] = 
   {{(-1/4 + I/4)*(I + Sqrt[3]), (1/4 + I/4)*(1 - I*Sqrt[3])}, 
    {(-1/4 - I/4)*(I + Sqrt[3]), (-1/4 - I/4)*(I + Sqrt[3])}}
 
halfE6Cat1FMatrixFunction[2, 2, 2, 2] = 
   {{(-1 + Sqrt[3])/2, (-1 + Sqrt[3])/2, 1, 1, 1, -1}, 
    {(-1 + Sqrt[3])/2, (1 - Sqrt[3])/2, 1, 1, -1, 1}, 
    {(1/8 + I/8)*((-2 + I) + Sqrt[3]), (1/8 + I/8)*((-2 + I) + Sqrt[3]), 
     ((2 + I) - Sqrt[3])/4, (1 - I*Sqrt[3])/4, ((2 + I) - Sqrt[3])/4, 
     (I/4)*(I + Sqrt[3])}, {(1/8 + I/8)*((1 + 2*I) - I*Sqrt[3]), 
     (1/8 + I/8)*((1 + 2*I) - I*Sqrt[3]), -(-1)^(1/6)/2, 
     (I/4)*((-2 - I) + Sqrt[3]), -(-1)^(1/6)/2, (-I/4)*((-2 - I) + Sqrt[3])}, 
    {(1/8 + I/8)*((1 + 2*I) - I*Sqrt[3]), (-1/8 + I/8)*((-2 + I) + Sqrt[3]), 
     (I/4)*((-2 - I) + Sqrt[3]), -(-1)^(1/6)/2, (-I/4)*((-2 - I) + Sqrt[3]), 
     -(-1)^(1/6)/2}, {(1/8 + I/8)*((-2 + I) + Sqrt[3]), 
     (-1/8 - I/8)*((-2 + I) + Sqrt[3]), (1 - I*Sqrt[3])/4, 
     ((2 + I) - Sqrt[3])/4, (I/4)*(I + Sqrt[3]), ((2 + I) - Sqrt[3])/4}}
 
halfE6Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[halfE6Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
halfE6Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[halfE6Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[halfE6Cat1Piv1] ^= {}
 
fusionCategory[halfE6Cat1Piv1] ^= halfE6Cat1
 
halfE6Cat1Piv1 /: modularCategory[halfE6Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[halfE6Cat1Piv1] ^= halfE6Cat1Piv1
 
pivotalIsomorphism[halfE6Cat1Piv1] ^= halfE6Cat1Piv1PivotalIsomorphism
 
ring[halfE6Cat1Piv1] ^= halfE6
 
sphericalCategory[halfE6Cat1Piv1] ^= halfE6Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[halfE6Cat1]][pivotalCategory[#1]] & )[
    halfE6Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[halfE6Cat1]][
      sphericalCategory[#1]] & )[halfE6Cat1Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[halfE6Cat1Piv1PivotalIsomorphism] ^= halfE6Cat1
 
pivotalCategory[halfE6Cat1Piv1PivotalIsomorphism] ^= halfE6Cat1Piv1
 
pivotalIsomorphism[halfE6Cat1Piv1PivotalIsomorphism] ^= 
   halfE6Cat1Piv1PivotalIsomorphism
 
halfE6Cat1Piv1PivotalIsomorphism[0] = 1
 
halfE6Cat1Piv1PivotalIsomorphism[1] = 1
 
halfE6Cat1Piv1PivotalIsomorphism[2] = 1
balancedCategories[halfE6Cat2] ^= {}
 
braidedCategories[halfE6Cat2] ^= {}
 
coeval[halfE6Cat2] ^= 1/sixJFunction[halfE6Cat2][#1, 
      dual[ring[halfE6Cat2]][#1], #1, #1, 0, 0] & 
 
eval[halfE6Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[halfE6Cat2] ^= halfE6Cat2FMatrixFunction
 
fusionCategory[halfE6Cat2] ^= halfE6Cat2
 
halfE6Cat2 /: modularCategory[halfE6Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[halfE6Cat2] ^= {halfE6Cat2Piv1}
 
halfE6Cat2 /: pivotalCategory[halfE6Cat2, 1] = halfE6Cat2Piv1
 
halfE6Cat2 /: pivotalCategory[halfE6Cat2, {1, 1, 1}] = halfE6Cat2Piv1
 
ring[halfE6Cat2] ^= halfE6
 
halfE6Cat2 /: sphericalCategory[halfE6Cat2, 1] = halfE6Cat2Piv1
 
fusionCategoryIndex[halfE6][halfE6Cat2] ^= 2
fMatrixFunction[halfE6Cat2FMatrixFunction] ^= halfE6Cat2FMatrixFunction
 
fusionCategory[halfE6Cat2FMatrixFunction] ^= halfE6Cat2
 
ring[halfE6Cat2FMatrixFunction] ^= halfE6
 
halfE6Cat2FMatrixFunction[1, 2, 1, 2] = {{-1}}
 
halfE6Cat2FMatrixFunction[1, 2, 2, 2] = {{0, I}, {-I, 0}}
 
halfE6Cat2FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
halfE6Cat2FMatrixFunction[2, 1, 2, 2] = {{1, 0}, {0, -1}}
 
halfE6Cat2FMatrixFunction[2, 2, 1, 2] = {{0, 1}, {1, 0}}
 
halfE6Cat2FMatrixFunction[2, 2, 2, 0] = 
   {{(1/4 + I/4)*(-I + Sqrt[3]), (1/4 + I/4)*(-I + Sqrt[3])}, 
    {(1/4 - I/4)*(-I + Sqrt[3]), (1/4 + I/4)*(1 + I*Sqrt[3])}}
 
halfE6Cat2FMatrixFunction[2, 2, 2, 1] = 
   {{(1/4 - I/4)*(-I + Sqrt[3]), (1/4 + I/4)*(1 + I*Sqrt[3])}, 
    {(1/4 + I/4)*(-I + Sqrt[3]), (1/4 + I/4)*(-I + Sqrt[3])}}
 
halfE6Cat2FMatrixFunction[2, 2, 2, 2] = 
   {{(-1 - Sqrt[3])/2, (-1 - Sqrt[3])/2, 1, 1, 1, -1}, 
    {(-1 - Sqrt[3])/2, (1 + Sqrt[3])/2, 1, 1, -1, 1}, 
    {(-1/8 - I/8)*((2 - I) + Sqrt[3]), (-1/8 - I/8)*((2 - I) + Sqrt[3]), 
     ((2 + I) + Sqrt[3])/4, (1 + I*Sqrt[3])/4, ((2 + I) + Sqrt[3])/4, 
     (-I/4)*(-I + Sqrt[3])}, {(1/8 + I/8)*((1 + 2*I) + I*Sqrt[3]), 
     (1/8 + I/8)*((1 + 2*I) + I*Sqrt[3]), (-I + Sqrt[3])/4, 
     (-I/4)*((2 + I) + Sqrt[3]), (-I + Sqrt[3])/4, 
     (I/4)*((2 + I) + Sqrt[3])}, {(1/8 + I/8)*((1 + 2*I) + I*Sqrt[3]), 
     (1/8 - I/8)*((2 - I) + Sqrt[3]), (-I/4)*((2 + I) + Sqrt[3]), 
     (-I + Sqrt[3])/4, (I/4)*((2 + I) + Sqrt[3]), (-I + Sqrt[3])/4}, 
    {(-1/8 - I/8)*((2 - I) + Sqrt[3]), (1/8 + I/8)*((2 - I) + Sqrt[3]), 
     (1 + I*Sqrt[3])/4, ((2 + I) + Sqrt[3])/4, (-I/4)*(-I + Sqrt[3]), 
     ((2 + I) + Sqrt[3])/4}}
 
halfE6Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[halfE6Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
halfE6Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[halfE6Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[halfE6Cat2Piv1] ^= {}
 
fusionCategory[halfE6Cat2Piv1] ^= halfE6Cat2
 
halfE6Cat2Piv1 /: modularCategory[halfE6Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[halfE6Cat2Piv1] ^= halfE6Cat2Piv1
 
pivotalIsomorphism[halfE6Cat2Piv1] ^= halfE6Cat2Piv1PivotalIsomorphism
 
ring[halfE6Cat2Piv1] ^= halfE6
 
sphericalCategory[halfE6Cat2Piv1] ^= halfE6Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[halfE6Cat2]][pivotalCategory[#1]] & )[
    halfE6Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[halfE6Cat2]][
      sphericalCategory[#1]] & )[halfE6Cat2Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[halfE6Cat2Piv1PivotalIsomorphism] ^= halfE6Cat2
 
pivotalCategory[halfE6Cat2Piv1PivotalIsomorphism] ^= halfE6Cat2Piv1
 
pivotalIsomorphism[halfE6Cat2Piv1PivotalIsomorphism] ^= 
   halfE6Cat2Piv1PivotalIsomorphism
 
halfE6Cat2Piv1PivotalIsomorphism[0] = 1
 
halfE6Cat2Piv1PivotalIsomorphism[1] = 1
 
halfE6Cat2Piv1PivotalIsomorphism[2] = 1
balancedCategories[halfE6Cat3] ^= {}
 
braidedCategories[halfE6Cat3] ^= {}
 
coeval[halfE6Cat3] ^= 1/sixJFunction[halfE6Cat3][#1, 
      dual[ring[halfE6Cat3]][#1], #1, #1, 0, 0] & 
 
eval[halfE6Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[halfE6Cat3] ^= halfE6Cat3FMatrixFunction
 
fusionCategory[halfE6Cat3] ^= halfE6Cat3
 
halfE6Cat3 /: modularCategory[halfE6Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[halfE6Cat3] ^= {halfE6Cat3Piv1}
 
halfE6Cat3 /: pivotalCategory[halfE6Cat3, 1] = halfE6Cat3Piv1
 
halfE6Cat3 /: pivotalCategory[halfE6Cat3, {1, 1, 1}] = halfE6Cat3Piv1
 
ring[halfE6Cat3] ^= halfE6
 
halfE6Cat3 /: sphericalCategory[halfE6Cat3, 1] = halfE6Cat3Piv1
 
fusionCategoryIndex[halfE6][halfE6Cat3] ^= 3
fMatrixFunction[halfE6Cat3FMatrixFunction] ^= halfE6Cat3FMatrixFunction
 
fusionCategory[halfE6Cat3FMatrixFunction] ^= halfE6Cat3
 
ring[halfE6Cat3FMatrixFunction] ^= halfE6
 
halfE6Cat3FMatrixFunction[1, 2, 1, 2] = {{-1}}
 
halfE6Cat3FMatrixFunction[1, 2, 2, 2] = {{0, -I}, {I, 0}}
 
halfE6Cat3FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
halfE6Cat3FMatrixFunction[2, 1, 2, 2] = {{1, 0}, {0, -1}}
 
halfE6Cat3FMatrixFunction[2, 2, 1, 2] = {{0, 1}, {1, 0}}
 
halfE6Cat3FMatrixFunction[2, 2, 2, 0] = 
   {{(1/4 + I/4)*(1 + I*Sqrt[3]), (1/4 + I/4)*(1 + I*Sqrt[3])}, 
    {(-1/4 - I/4)*(-I + Sqrt[3]), (1/4 + I/4)*(-I + Sqrt[3])}}
 
halfE6Cat3FMatrixFunction[2, 2, 2, 1] = 
   {{(-1/4 - I/4)*(-I + Sqrt[3]), (1/4 + I/4)*(-I + Sqrt[3])}, 
    {(1/4 + I/4)*(1 + I*Sqrt[3]), (1/4 + I/4)*(1 + I*Sqrt[3])}}
 
halfE6Cat3FMatrixFunction[2, 2, 2, 2] = 
   {{(-1 + Sqrt[3])/2, (-1 + Sqrt[3])/2, 1, 1, 1, -1}, 
    {(-1 + Sqrt[3])/2, (1 - Sqrt[3])/2, 1, 1, -1, 1}, 
    {(1/8 - I/8)*((-2 - I) + Sqrt[3]), (1/8 - I/8)*((-2 - I) + Sqrt[3]), 
     ((2 - I) - Sqrt[3])/4, (1 + I*Sqrt[3])/4, ((2 - I) - Sqrt[3])/4, 
     (-I/4)*(-I + Sqrt[3])}, {(1/8 + I/8)*((-2 - I) + Sqrt[3]), 
     (1/8 + I/8)*((-2 - I) + Sqrt[3]), (-1)^(5/6)/2, 
     ((1 + 2*I) - I*Sqrt[3])/4, (-1)^(5/6)/2, (I/4)*((-2 + I) + Sqrt[3])}, 
    {(1/8 + I/8)*((-2 - I) + Sqrt[3]), ((1 + 3*I) + Root[36 + #1^4 & , 1, 0])/
      8, ((1 + 2*I) - I*Sqrt[3])/4, (-1)^(5/6)/2, (I/4)*((-2 + I) + Sqrt[3]), 
     (-1)^(5/6)/2}, {(1/8 - I/8)*((-2 - I) + Sqrt[3]), 
     (-1/8 + I/8)*((-2 - I) + Sqrt[3]), (1 + I*Sqrt[3])/4, 
     ((2 - I) - Sqrt[3])/4, (-I/4)*(-I + Sqrt[3]), ((2 - I) - Sqrt[3])/4}}
 
halfE6Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[halfE6Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
halfE6Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[halfE6Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[halfE6Cat3Piv1] ^= {}
 
fusionCategory[halfE6Cat3Piv1] ^= halfE6Cat3
 
halfE6Cat3Piv1 /: modularCategory[halfE6Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[halfE6Cat3Piv1] ^= halfE6Cat3Piv1
 
pivotalIsomorphism[halfE6Cat3Piv1] ^= halfE6Cat3Piv1PivotalIsomorphism
 
ring[halfE6Cat3Piv1] ^= halfE6
 
sphericalCategory[halfE6Cat3Piv1] ^= halfE6Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[halfE6Cat3]][pivotalCategory[#1]] & )[
    halfE6Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[halfE6Cat3]][
      sphericalCategory[#1]] & )[halfE6Cat3Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[halfE6Cat3Piv1PivotalIsomorphism] ^= halfE6Cat3
 
pivotalCategory[halfE6Cat3Piv1PivotalIsomorphism] ^= halfE6Cat3Piv1
 
pivotalIsomorphism[halfE6Cat3Piv1PivotalIsomorphism] ^= 
   halfE6Cat3Piv1PivotalIsomorphism
 
halfE6Cat3Piv1PivotalIsomorphism[0] = 1
 
halfE6Cat3Piv1PivotalIsomorphism[1] = 1
 
halfE6Cat3Piv1PivotalIsomorphism[2] = 1
balancedCategories[halfE6Cat4] ^= {}
 
braidedCategories[halfE6Cat4] ^= {}
 
coeval[halfE6Cat4] ^= 1/sixJFunction[halfE6Cat4][#1, 
      dual[ring[halfE6Cat4]][#1], #1, #1, 0, 0] & 
 
eval[halfE6Cat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[halfE6Cat4] ^= halfE6Cat4FMatrixFunction
 
fusionCategory[halfE6Cat4] ^= halfE6Cat4
 
halfE6Cat4 /: modularCategory[halfE6Cat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[halfE6Cat4] ^= {halfE6Cat4Piv1}
 
halfE6Cat4 /: pivotalCategory[halfE6Cat4, 1] = halfE6Cat4Piv1
 
halfE6Cat4 /: pivotalCategory[halfE6Cat4, {1, 1, 1}] = halfE6Cat4Piv1
 
ring[halfE6Cat4] ^= halfE6
 
halfE6Cat4 /: sphericalCategory[halfE6Cat4, 1] = halfE6Cat4Piv1
 
fusionCategoryIndex[halfE6][halfE6Cat4] ^= 4
fMatrixFunction[halfE6Cat4FMatrixFunction] ^= halfE6Cat4FMatrixFunction
 
fusionCategory[halfE6Cat4FMatrixFunction] ^= halfE6Cat4
 
ring[halfE6Cat4FMatrixFunction] ^= halfE6
 
halfE6Cat4FMatrixFunction[1, 2, 1, 2] = {{-1}}
 
halfE6Cat4FMatrixFunction[1, 2, 2, 2] = {{0, -I}, {I, 0}}
 
halfE6Cat4FMatrixFunction[2, 1, 2, 1] = {{-1}}
 
halfE6Cat4FMatrixFunction[2, 1, 2, 2] = {{1, 0}, {0, -1}}
 
halfE6Cat4FMatrixFunction[2, 2, 1, 2] = {{0, 1}, {1, 0}}
 
halfE6Cat4FMatrixFunction[2, 2, 2, 0] = 
   {{(1/4 + I/4)*(1 - I*Sqrt[3]), (1/4 + I/4)*(1 - I*Sqrt[3])}, 
    {(1/4 + I/4)*(I + Sqrt[3]), (-1/4 - I/4)*(I + Sqrt[3])}}
 
halfE6Cat4FMatrixFunction[2, 2, 2, 1] = 
   {{(1/4 + I/4)*(I + Sqrt[3]), (-1/4 - I/4)*(I + Sqrt[3])}, 
    {(1/4 + I/4)*(1 - I*Sqrt[3]), (1/4 + I/4)*(1 - I*Sqrt[3])}}
 
halfE6Cat4FMatrixFunction[2, 2, 2, 2] = 
   {{(-1 - Sqrt[3])/2, (-1 - Sqrt[3])/2, 1, 1, 1, -1}, 
    {(-1 - Sqrt[3])/2, (1 + Sqrt[3])/2, 1, 1, -1, 1}, 
    {(-1/8 + I/8)*((2 + I) + Sqrt[3]), (-1/8 + I/8)*((2 + I) + Sqrt[3]), 
     ((2 - I) + Sqrt[3])/4, (1 - I*Sqrt[3])/4, ((2 - I) + Sqrt[3])/4, 
     (I/4)*(I + Sqrt[3])}, {(-1/8 - I/8)*((2 + I) + Sqrt[3]), 
     (-1/8 - I/8)*((2 + I) + Sqrt[3]), (I + Sqrt[3])/4, 
     (I/4)*((2 - I) + Sqrt[3]), (I + Sqrt[3])/4, (-I/4)*((2 - I) + Sqrt[3])}, 
    {(-1/8 - I/8)*((2 + I) + Sqrt[3]), (1/8 + I/8)*((2 + I) + Sqrt[3]), 
     (I/4)*((2 - I) + Sqrt[3]), (I + Sqrt[3])/4, (-I/4)*((2 - I) + Sqrt[3]), 
     (I + Sqrt[3])/4}, {(-1/8 + I/8)*((2 + I) + Sqrt[3]), 
     (1/8 - I/8)*((2 + I) + Sqrt[3]), (1 - I*Sqrt[3])/4, 
     ((2 - I) + Sqrt[3])/4, (I/4)*(I + Sqrt[3]), ((2 - I) + Sqrt[3])/4}}
 
halfE6Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[halfE6Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
halfE6Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[halfE6Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[halfE6Cat4Piv1] ^= {}
 
fusionCategory[halfE6Cat4Piv1] ^= halfE6Cat4
 
halfE6Cat4Piv1 /: modularCategory[halfE6Cat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[halfE6Cat4Piv1] ^= halfE6Cat4Piv1
 
pivotalIsomorphism[halfE6Cat4Piv1] ^= halfE6Cat4Piv1PivotalIsomorphism
 
ring[halfE6Cat4Piv1] ^= halfE6
 
sphericalCategory[halfE6Cat4Piv1] ^= halfE6Cat4Piv1
 
(pivotalCategoryIndex[fusionCategory[halfE6Cat4]][pivotalCategory[#1]] & )[
    halfE6Cat4Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[halfE6Cat4]][
      sphericalCategory[#1]] & )[halfE6Cat4Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[halfE6Cat4Piv1PivotalIsomorphism] ^= halfE6Cat4
 
pivotalCategory[halfE6Cat4Piv1PivotalIsomorphism] ^= halfE6Cat4Piv1
 
pivotalIsomorphism[halfE6Cat4Piv1PivotalIsomorphism] ^= 
   halfE6Cat4Piv1PivotalIsomorphism
 
halfE6Cat4Piv1PivotalIsomorphism[0] = 1
 
halfE6Cat4Piv1PivotalIsomorphism[1] = 1
 
halfE6Cat4Piv1PivotalIsomorphism[2] = 1
ring[halfE6NFunction] ^= halfE6
 
halfE6NFunction[0, 0, 0] = 1
 
halfE6NFunction[0, 0, 1] = 0
 
halfE6NFunction[0, 0, 2] = 0
 
halfE6NFunction[0, 1, 0] = 0
 
halfE6NFunction[0, 1, 1] = 1
 
halfE6NFunction[0, 1, 2] = 0
 
halfE6NFunction[0, 2, 0] = 0
 
halfE6NFunction[0, 2, 1] = 0
 
halfE6NFunction[0, 2, 2] = 1
 
halfE6NFunction[1, 0, 0] = 0
 
halfE6NFunction[1, 0, 1] = 1
 
halfE6NFunction[1, 0, 2] = 0
 
halfE6NFunction[1, 1, 0] = 1
 
halfE6NFunction[1, 1, 1] = 0
 
halfE6NFunction[1, 1, 2] = 0
 
halfE6NFunction[1, 2, 0] = 0
 
halfE6NFunction[1, 2, 1] = 0
 
halfE6NFunction[1, 2, 2] = 1
 
halfE6NFunction[2, 0, 0] = 0
 
halfE6NFunction[2, 0, 1] = 0
 
halfE6NFunction[2, 0, 2] = 1
 
halfE6NFunction[2, 1, 0] = 0
 
halfE6NFunction[2, 1, 1] = 0
 
halfE6NFunction[2, 1, 2] = 1
 
halfE6NFunction[2, 2, 0] = 1
 
halfE6NFunction[2, 2, 1] = 1
 
halfE6NFunction[2, 2, 2] = 2
 
halfE6NFunction[FusionCategories`Data`halfE6`Private`a_, FusionCategories`Data`halfE6`Private`b_, FusionCategories`Data`halfE6`Private`c_] := 0


 EndPackage[]
