BeginPackage["FusionCategories`Data`SOlevel23`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[SOlevel23] ^= {SOlevel23Cat1, SOlevel23Cat2}
 
SOlevel23 /: fusionCategory[SOlevel23, 1] = SOlevel23Cat1
 
SOlevel23 /: fusionCategory[SOlevel23, 2] = SOlevel23Cat2
 
nFunction[SOlevel23] ^= SOlevel23NFunction
 
noMultiplicities[SOlevel23] ^= True
 
rank[SOlevel23] ^= 5
 
ring[SOlevel23] ^= SOlevel23
balancedCategories[SOlevel23Cat1] ^= {SOlevel23Cat1Bal1, SOlevel23Cat1Bal2, 
    SOlevel23Cat1Bal3, SOlevel23Cat1Bal4, SOlevel23Cat1Bal5, 
    SOlevel23Cat1Bal6, SOlevel23Cat1Bal7, SOlevel23Cat1Bal8}
 
SOlevel23Cat1 /: balancedCategory[SOlevel23Cat1, 1] = SOlevel23Cat1Bal1
 
SOlevel23Cat1 /: balancedCategory[SOlevel23Cat1, 2] = SOlevel23Cat1Bal2
 
SOlevel23Cat1 /: balancedCategory[SOlevel23Cat1, 3] = SOlevel23Cat1Bal3
 
SOlevel23Cat1 /: balancedCategory[SOlevel23Cat1, 4] = SOlevel23Cat1Bal4
 
SOlevel23Cat1 /: balancedCategory[SOlevel23Cat1, 5] = SOlevel23Cat1Bal5
 
SOlevel23Cat1 /: balancedCategory[SOlevel23Cat1, 6] = SOlevel23Cat1Bal6
 
SOlevel23Cat1 /: balancedCategory[SOlevel23Cat1, 7] = SOlevel23Cat1Bal7
 
SOlevel23Cat1 /: balancedCategory[SOlevel23Cat1, 8] = SOlevel23Cat1Bal8
 
braidedCategories[SOlevel23Cat1] ^= {SOlevel23Cat1Brd1, SOlevel23Cat1Brd2, 
    SOlevel23Cat1Brd3, SOlevel23Cat1Brd4}
 
SOlevel23Cat1 /: braidedCategory[SOlevel23Cat1, 1] = SOlevel23Cat1Brd1
 
SOlevel23Cat1 /: braidedCategory[SOlevel23Cat1, 2] = SOlevel23Cat1Brd2
 
SOlevel23Cat1 /: braidedCategory[SOlevel23Cat1, 3] = SOlevel23Cat1Brd3
 
SOlevel23Cat1 /: braidedCategory[SOlevel23Cat1, 4] = SOlevel23Cat1Brd4
 
coeval[SOlevel23Cat1] ^= 1/sixJFunction[SOlevel23Cat1][#1, 
      dual[ring[SOlevel23Cat1]][#1], #1, #1, 0, 0] & 
 
eval[SOlevel23Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[SOlevel23Cat1] ^= SOlevel23Cat1FMatrixFunction
 
fusionCategory[SOlevel23Cat1] ^= SOlevel23Cat1
 
SOlevel23Cat1 /: modularCategory[SOlevel23Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[SOlevel23Cat1] ^= {SOlevel23Cat1Piv1, SOlevel23Cat1Piv2}
 
SOlevel23Cat1 /: pivotalCategory[SOlevel23Cat1, 1] = SOlevel23Cat1Piv1
 
SOlevel23Cat1 /: pivotalCategory[SOlevel23Cat1, 2] = SOlevel23Cat1Piv2
 
SOlevel23Cat1 /: pivotalCategory[SOlevel23Cat1, {1, 1, -1, -1, 1}] = 
    SOlevel23Cat1Piv2
 
SOlevel23Cat1 /: pivotalCategory[SOlevel23Cat1, {1, 1, 1, 1, 1}] = 
    SOlevel23Cat1Piv1
 
SOlevel23Cat1 /: ribbonCategory[SOlevel23Cat1, 1] = SOlevel23Cat1Bal1
 
SOlevel23Cat1 /: ribbonCategory[SOlevel23Cat1, 2] = SOlevel23Cat1Bal2
 
SOlevel23Cat1 /: ribbonCategory[SOlevel23Cat1, 3] = SOlevel23Cat1Bal3
 
SOlevel23Cat1 /: ribbonCategory[SOlevel23Cat1, 4] = SOlevel23Cat1Bal4
 
SOlevel23Cat1 /: ribbonCategory[SOlevel23Cat1, 5] = SOlevel23Cat1Bal5
 
SOlevel23Cat1 /: ribbonCategory[SOlevel23Cat1, 6] = SOlevel23Cat1Bal6
 
SOlevel23Cat1 /: ribbonCategory[SOlevel23Cat1, 7] = SOlevel23Cat1Bal7
 
SOlevel23Cat1 /: ribbonCategory[SOlevel23Cat1, 8] = SOlevel23Cat1Bal8
 
ring[SOlevel23Cat1] ^= SOlevel23
 
SOlevel23Cat1 /: sphericalCategory[SOlevel23Cat1, 1] = SOlevel23Cat1Piv1
 
SOlevel23Cat1 /: sphericalCategory[SOlevel23Cat1, 2] = SOlevel23Cat1Piv2
 
fusionCategoryIndex[SOlevel23][SOlevel23Cat1] ^= 1
balancedCategory[SOlevel23Cat1Bal1] ^= SOlevel23Cat1Bal1
 
braidedCategory[SOlevel23Cat1Bal1] ^= SOlevel23Cat1Brd1
 
fusionCategory[SOlevel23Cat1Bal1] ^= SOlevel23Cat1
 
pivotalCategory[SOlevel23Cat1Bal1] ^= SOlevel23Cat1Piv1
 
ribbonCategory[SOlevel23Cat1Bal1] ^= SOlevel23Cat1Bal1
 
ring[SOlevel23Cat1Bal1] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat1Bal1] ^= SOlevel23Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel23Cat1Brd1]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel23Cat1]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[SOlevel23Cat1Piv1]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SOlevel23Cat1Brd1]][
      ribbonCategory[#1]] & )[SOlevel23Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel23Cat1]][ribbonCategory[#1]] & )[
    SOlevel23Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[SOlevel23Cat1Piv1]][
      ribbonCategory[#1]] & )[SOlevel23Cat1Bal1] ^= 1
balancedCategory[SOlevel23Cat1Bal2] ^= SOlevel23Cat1Bal2
 
braidedCategory[SOlevel23Cat1Bal2] ^= SOlevel23Cat1Brd1
 
fusionCategory[SOlevel23Cat1Bal2] ^= SOlevel23Cat1
 
pivotalCategory[SOlevel23Cat1Bal2] ^= SOlevel23Cat1Piv2
 
ribbonCategory[SOlevel23Cat1Bal2] ^= SOlevel23Cat1Bal2
 
ring[SOlevel23Cat1Bal2] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat1Bal2] ^= SOlevel23Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel23Cat1Brd1]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel23Cat1]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[SOlevel23Cat1Piv2]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SOlevel23Cat1Brd1]][
      ribbonCategory[#1]] & )[SOlevel23Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel23Cat1]][ribbonCategory[#1]] & )[
    SOlevel23Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[SOlevel23Cat1Piv2]][
      ribbonCategory[#1]] & )[SOlevel23Cat1Bal2] ^= 1
balancedCategory[SOlevel23Cat1Bal3] ^= SOlevel23Cat1Bal3
 
braidedCategory[SOlevel23Cat1Bal3] ^= SOlevel23Cat1Brd2
 
fusionCategory[SOlevel23Cat1Bal3] ^= SOlevel23Cat1
 
pivotalCategory[SOlevel23Cat1Bal3] ^= SOlevel23Cat1Piv1
 
ribbonCategory[SOlevel23Cat1Bal3] ^= SOlevel23Cat1Bal3
 
ring[SOlevel23Cat1Bal3] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat1Bal3] ^= SOlevel23Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel23Cat1Brd2]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel23Cat1]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[SOlevel23Cat1Piv1]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SOlevel23Cat1Brd2]][
      ribbonCategory[#1]] & )[SOlevel23Cat1Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel23Cat1]][ribbonCategory[#1]] & )[
    SOlevel23Cat1Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[SOlevel23Cat1Piv1]][
      ribbonCategory[#1]] & )[SOlevel23Cat1Bal3] ^= 2
balancedCategory[SOlevel23Cat1Bal4] ^= SOlevel23Cat1Bal4
 
braidedCategory[SOlevel23Cat1Bal4] ^= SOlevel23Cat1Brd2
 
fusionCategory[SOlevel23Cat1Bal4] ^= SOlevel23Cat1
 
pivotalCategory[SOlevel23Cat1Bal4] ^= SOlevel23Cat1Piv2
 
ribbonCategory[SOlevel23Cat1Bal4] ^= SOlevel23Cat1Bal4
 
ring[SOlevel23Cat1Bal4] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat1Bal4] ^= SOlevel23Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel23Cat1Brd2]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel23Cat1]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[SOlevel23Cat1Piv2]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SOlevel23Cat1Brd2]][
      ribbonCategory[#1]] & )[SOlevel23Cat1Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel23Cat1]][ribbonCategory[#1]] & )[
    SOlevel23Cat1Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[SOlevel23Cat1Piv2]][
      ribbonCategory[#1]] & )[SOlevel23Cat1Bal4] ^= 2
balancedCategory[SOlevel23Cat1Bal5] ^= SOlevel23Cat1Bal5
 
braidedCategory[SOlevel23Cat1Bal5] ^= SOlevel23Cat1Brd3
 
fusionCategory[SOlevel23Cat1Bal5] ^= SOlevel23Cat1
 
pivotalCategory[SOlevel23Cat1Bal5] ^= SOlevel23Cat1Piv1
 
ribbonCategory[SOlevel23Cat1Bal5] ^= SOlevel23Cat1Bal5
 
ring[SOlevel23Cat1Bal5] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat1Bal5] ^= SOlevel23Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel23Cat1Brd3]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel23Cat1]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[SOlevel23Cat1Piv1]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal5] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SOlevel23Cat1Brd3]][
      ribbonCategory[#1]] & )[SOlevel23Cat1Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel23Cat1]][ribbonCategory[#1]] & )[
    SOlevel23Cat1Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[SOlevel23Cat1Piv1]][
      ribbonCategory[#1]] & )[SOlevel23Cat1Bal5] ^= 3
balancedCategory[SOlevel23Cat1Bal6] ^= SOlevel23Cat1Bal6
 
braidedCategory[SOlevel23Cat1Bal6] ^= SOlevel23Cat1Brd3
 
fusionCategory[SOlevel23Cat1Bal6] ^= SOlevel23Cat1
 
pivotalCategory[SOlevel23Cat1Bal6] ^= SOlevel23Cat1Piv2
 
ribbonCategory[SOlevel23Cat1Bal6] ^= SOlevel23Cat1Bal6
 
ring[SOlevel23Cat1Bal6] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat1Bal6] ^= SOlevel23Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel23Cat1Brd3]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel23Cat1]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[SOlevel23Cat1Piv2]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal6] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SOlevel23Cat1Brd3]][
      ribbonCategory[#1]] & )[SOlevel23Cat1Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel23Cat1]][ribbonCategory[#1]] & )[
    SOlevel23Cat1Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[SOlevel23Cat1Piv2]][
      ribbonCategory[#1]] & )[SOlevel23Cat1Bal6] ^= 3
balancedCategory[SOlevel23Cat1Bal7] ^= SOlevel23Cat1Bal7
 
braidedCategory[SOlevel23Cat1Bal7] ^= SOlevel23Cat1Brd4
 
fusionCategory[SOlevel23Cat1Bal7] ^= SOlevel23Cat1
 
pivotalCategory[SOlevel23Cat1Bal7] ^= SOlevel23Cat1Piv1
 
ribbonCategory[SOlevel23Cat1Bal7] ^= SOlevel23Cat1Bal7
 
ring[SOlevel23Cat1Bal7] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat1Bal7] ^= SOlevel23Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel23Cat1Brd4]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel23Cat1]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[SOlevel23Cat1Piv1]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal7] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SOlevel23Cat1Brd4]][
      ribbonCategory[#1]] & )[SOlevel23Cat1Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel23Cat1]][ribbonCategory[#1]] & )[
    SOlevel23Cat1Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[SOlevel23Cat1Piv1]][
      ribbonCategory[#1]] & )[SOlevel23Cat1Bal7] ^= 4
balancedCategory[SOlevel23Cat1Bal8] ^= SOlevel23Cat1Bal8
 
braidedCategory[SOlevel23Cat1Bal8] ^= SOlevel23Cat1Brd4
 
fusionCategory[SOlevel23Cat1Bal8] ^= SOlevel23Cat1
 
pivotalCategory[SOlevel23Cat1Bal8] ^= SOlevel23Cat1Piv2
 
ribbonCategory[SOlevel23Cat1Bal8] ^= SOlevel23Cat1Bal8
 
ring[SOlevel23Cat1Bal8] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat1Bal8] ^= SOlevel23Cat1Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel23Cat1Brd4]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel23Cat1]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[SOlevel23Cat1Piv2]][
      balancedCategory[#1]] & )[SOlevel23Cat1Bal8] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SOlevel23Cat1Brd4]][
      ribbonCategory[#1]] & )[SOlevel23Cat1Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel23Cat1]][ribbonCategory[#1]] & )[
    SOlevel23Cat1Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[SOlevel23Cat1Piv2]][
      ribbonCategory[#1]] & )[SOlevel23Cat1Bal8] ^= 4
balancedCategories[SOlevel23Cat1Brd1] ^= {SOlevel23Cat1Bal1, 
    SOlevel23Cat1Bal2}
 
SOlevel23Cat1Brd1 /: balancedCategory[SOlevel23Cat1Brd1, 1] = 
    SOlevel23Cat1Bal1
 
SOlevel23Cat1Brd1 /: balancedCategory[SOlevel23Cat1Brd1, 2] = 
    SOlevel23Cat1Bal2
 
braidedCategory[SOlevel23Cat1Brd1] ^= SOlevel23Cat1Brd1
 
fusionCategory[SOlevel23Cat1Brd1] ^= SOlevel23Cat1
 
SOlevel23Cat1Brd1 /: modularCategory[SOlevel23Cat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel23Cat1Brd1 /: ribbonCategory[SOlevel23Cat1Brd1, 1] = SOlevel23Cat1Bal1
 
SOlevel23Cat1Brd1 /: ribbonCategory[SOlevel23Cat1Brd1, 2] = SOlevel23Cat1Bal2
 
ring[SOlevel23Cat1Brd1] ^= SOlevel23
 
rMatrixFunction[SOlevel23Cat1Brd1] ^= SOlevel23Cat1Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel23Cat1]][braidedCategory[#1]] & )[
    SOlevel23Cat1Brd1] ^= 1
braidedCategory[SOlevel23Cat1Brd1RMatrixFunction] ^= SOlevel23Cat1Brd1
 
fusionCategory[SOlevel23Cat1Brd1RMatrixFunction] ^= SOlevel23Cat1
 
rMatrixFunction[SOlevel23Cat1Brd1RMatrixFunction] ^= 
   SOlevel23Cat1Brd1RMatrixFunction
 
SOlevel23Cat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel23Cat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel23Cat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel23Cat1Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel23Cat1Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel23Cat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel23Cat1Brd1RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel23Cat1Brd1RMatrixFunction[1, 2, 3] = {{-1}}
 
SOlevel23Cat1Brd1RMatrixFunction[1, 3, 2] = {{-1}}
 
SOlevel23Cat1Brd1RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel23Cat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel23Cat1Brd1RMatrixFunction[2, 1, 3] = {{1}}
 
SOlevel23Cat1Brd1RMatrixFunction[2, 2, 0] = {{-(-1)^(1/4)}}
 
SOlevel23Cat1Brd1RMatrixFunction[2, 2, 4] = {{(-1)^(7/12)}}
 
SOlevel23Cat1Brd1RMatrixFunction[2, 3, 1] = {{-(-1)^(3/4)}}
 
SOlevel23Cat1Brd1RMatrixFunction[2, 3, 4] = {{(-1)^(7/12)}}
 
SOlevel23Cat1Brd1RMatrixFunction[2, 4, 2] = {{-(-1)^(1/6)}}
 
SOlevel23Cat1Brd1RMatrixFunction[2, 4, 3] = {{-(-1)^(1/6)}}
 
SOlevel23Cat1Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel23Cat1Brd1RMatrixFunction[3, 1, 2] = {{1}}
 
SOlevel23Cat1Brd1RMatrixFunction[3, 2, 1] = {{-(-1)^(3/4)}}
 
SOlevel23Cat1Brd1RMatrixFunction[3, 2, 4] = {{-(-1)^(7/12)}}
 
SOlevel23Cat1Brd1RMatrixFunction[3, 3, 0] = {{(-1)^(1/4)}}
 
SOlevel23Cat1Brd1RMatrixFunction[3, 3, 4] = {{-(-1)^(7/12)}}
 
SOlevel23Cat1Brd1RMatrixFunction[3, 4, 2] = {{-(-1)^(1/6)}}
 
SOlevel23Cat1Brd1RMatrixFunction[3, 4, 3] = {{-(-1)^(1/6)}}
 
SOlevel23Cat1Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel23Cat1Brd1RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel23Cat1Brd1RMatrixFunction[4, 2, 2] = {{(-1)^(1/6)}}
 
SOlevel23Cat1Brd1RMatrixFunction[4, 2, 3] = {{-(-1)^(1/6)}}
 
SOlevel23Cat1Brd1RMatrixFunction[4, 3, 2] = {{-(-1)^(1/6)}}
 
SOlevel23Cat1Brd1RMatrixFunction[4, 3, 3] = {{(-1)^(1/6)}}
 
SOlevel23Cat1Brd1RMatrixFunction[4, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
SOlevel23Cat1Brd1RMatrixFunction[4, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
SOlevel23Cat1Brd1RMatrixFunction[4, 4, 4] = {{(-1)^(2/3)}}
balancedCategories[SOlevel23Cat1Brd2] ^= {SOlevel23Cat1Bal3, 
    SOlevel23Cat1Bal4}
 
SOlevel23Cat1Brd2 /: balancedCategory[SOlevel23Cat1Brd2, 1] = 
    SOlevel23Cat1Bal3
 
SOlevel23Cat1Brd2 /: balancedCategory[SOlevel23Cat1Brd2, 2] = 
    SOlevel23Cat1Bal4
 
braidedCategory[SOlevel23Cat1Brd2] ^= SOlevel23Cat1Brd2
 
fusionCategory[SOlevel23Cat1Brd2] ^= SOlevel23Cat1
 
SOlevel23Cat1Brd2 /: modularCategory[SOlevel23Cat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel23Cat1Brd2 /: ribbonCategory[SOlevel23Cat1Brd2, 1] = SOlevel23Cat1Bal3
 
SOlevel23Cat1Brd2 /: ribbonCategory[SOlevel23Cat1Brd2, 2] = SOlevel23Cat1Bal4
 
ring[SOlevel23Cat1Brd2] ^= SOlevel23
 
rMatrixFunction[SOlevel23Cat1Brd2] ^= SOlevel23Cat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel23Cat1]][braidedCategory[#1]] & )[
    SOlevel23Cat1Brd2] ^= 2
braidedCategory[SOlevel23Cat1Brd2RMatrixFunction] ^= SOlevel23Cat1Brd2
 
fusionCategory[SOlevel23Cat1Brd2RMatrixFunction] ^= SOlevel23Cat1
 
rMatrixFunction[SOlevel23Cat1Brd2RMatrixFunction] ^= 
   SOlevel23Cat1Brd2RMatrixFunction
 
SOlevel23Cat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel23Cat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel23Cat1Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel23Cat1Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel23Cat1Brd2RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel23Cat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel23Cat1Brd2RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel23Cat1Brd2RMatrixFunction[1, 2, 3] = {{-1}}
 
SOlevel23Cat1Brd2RMatrixFunction[1, 3, 2] = {{-1}}
 
SOlevel23Cat1Brd2RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel23Cat1Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel23Cat1Brd2RMatrixFunction[2, 1, 3] = {{1}}
 
SOlevel23Cat1Brd2RMatrixFunction[2, 2, 0] = {{(-1)^(1/4)}}
 
SOlevel23Cat1Brd2RMatrixFunction[2, 2, 4] = {{-(-1)^(7/12)}}
 
SOlevel23Cat1Brd2RMatrixFunction[2, 3, 1] = {{(-1)^(3/4)}}
 
SOlevel23Cat1Brd2RMatrixFunction[2, 3, 4] = {{-(-1)^(7/12)}}
 
SOlevel23Cat1Brd2RMatrixFunction[2, 4, 2] = {{-(-1)^(1/6)}}
 
SOlevel23Cat1Brd2RMatrixFunction[2, 4, 3] = {{-(-1)^(1/6)}}
 
SOlevel23Cat1Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel23Cat1Brd2RMatrixFunction[3, 1, 2] = {{1}}
 
SOlevel23Cat1Brd2RMatrixFunction[3, 2, 1] = {{(-1)^(3/4)}}
 
SOlevel23Cat1Brd2RMatrixFunction[3, 2, 4] = {{(-1)^(7/12)}}
 
SOlevel23Cat1Brd2RMatrixFunction[3, 3, 0] = {{-(-1)^(1/4)}}
 
SOlevel23Cat1Brd2RMatrixFunction[3, 3, 4] = {{(-1)^(7/12)}}
 
SOlevel23Cat1Brd2RMatrixFunction[3, 4, 2] = {{-(-1)^(1/6)}}
 
SOlevel23Cat1Brd2RMatrixFunction[3, 4, 3] = {{-(-1)^(1/6)}}
 
SOlevel23Cat1Brd2RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel23Cat1Brd2RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel23Cat1Brd2RMatrixFunction[4, 2, 2] = {{(-1)^(1/6)}}
 
SOlevel23Cat1Brd2RMatrixFunction[4, 2, 3] = {{-(-1)^(1/6)}}
 
SOlevel23Cat1Brd2RMatrixFunction[4, 3, 2] = {{-(-1)^(1/6)}}
 
SOlevel23Cat1Brd2RMatrixFunction[4, 3, 3] = {{(-1)^(1/6)}}
 
SOlevel23Cat1Brd2RMatrixFunction[4, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
SOlevel23Cat1Brd2RMatrixFunction[4, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
SOlevel23Cat1Brd2RMatrixFunction[4, 4, 4] = {{(-1)^(2/3)}}
balancedCategories[SOlevel23Cat1Brd3] ^= {SOlevel23Cat1Bal5, 
    SOlevel23Cat1Bal6}
 
SOlevel23Cat1Brd3 /: balancedCategory[SOlevel23Cat1Brd3, 1] = 
    SOlevel23Cat1Bal5
 
SOlevel23Cat1Brd3 /: balancedCategory[SOlevel23Cat1Brd3, 2] = 
    SOlevel23Cat1Bal6
 
braidedCategory[SOlevel23Cat1Brd3] ^= SOlevel23Cat1Brd3
 
fusionCategory[SOlevel23Cat1Brd3] ^= SOlevel23Cat1
 
SOlevel23Cat1Brd3 /: modularCategory[SOlevel23Cat1Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel23Cat1Brd3 /: ribbonCategory[SOlevel23Cat1Brd3, 1] = SOlevel23Cat1Bal5
 
SOlevel23Cat1Brd3 /: ribbonCategory[SOlevel23Cat1Brd3, 2] = SOlevel23Cat1Bal6
 
ring[SOlevel23Cat1Brd3] ^= SOlevel23
 
rMatrixFunction[SOlevel23Cat1Brd3] ^= SOlevel23Cat1Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel23Cat1]][braidedCategory[#1]] & )[
    SOlevel23Cat1Brd3] ^= 3
braidedCategory[SOlevel23Cat1Brd3RMatrixFunction] ^= SOlevel23Cat1Brd3
 
fusionCategory[SOlevel23Cat1Brd3RMatrixFunction] ^= SOlevel23Cat1
 
rMatrixFunction[SOlevel23Cat1Brd3RMatrixFunction] ^= 
   SOlevel23Cat1Brd3RMatrixFunction
 
SOlevel23Cat1Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel23Cat1Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel23Cat1Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel23Cat1Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel23Cat1Brd3RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel23Cat1Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel23Cat1Brd3RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel23Cat1Brd3RMatrixFunction[1, 2, 3] = {{1}}
 
SOlevel23Cat1Brd3RMatrixFunction[1, 3, 2] = {{1}}
 
SOlevel23Cat1Brd3RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel23Cat1Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel23Cat1Brd3RMatrixFunction[2, 1, 3] = {{-1}}
 
SOlevel23Cat1Brd3RMatrixFunction[2, 2, 0] = {{-(-1)^(3/4)}}
 
SOlevel23Cat1Brd3RMatrixFunction[2, 2, 4] = {{(-1)^(5/12)}}
 
SOlevel23Cat1Brd3RMatrixFunction[2, 3, 1] = {{-(-1)^(1/4)}}
 
SOlevel23Cat1Brd3RMatrixFunction[2, 3, 4] = {{-(-1)^(5/12)}}
 
SOlevel23Cat1Brd3RMatrixFunction[2, 4, 2] = {{-(-1)^(5/6)}}
 
SOlevel23Cat1Brd3RMatrixFunction[2, 4, 3] = {{(-1)^(5/6)}}
 
SOlevel23Cat1Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel23Cat1Brd3RMatrixFunction[3, 1, 2] = {{-1}}
 
SOlevel23Cat1Brd3RMatrixFunction[3, 2, 1] = {{-(-1)^(1/4)}}
 
SOlevel23Cat1Brd3RMatrixFunction[3, 2, 4] = {{(-1)^(5/12)}}
 
SOlevel23Cat1Brd3RMatrixFunction[3, 3, 0] = {{(-1)^(3/4)}}
 
SOlevel23Cat1Brd3RMatrixFunction[3, 3, 4] = {{-(-1)^(5/12)}}
 
SOlevel23Cat1Brd3RMatrixFunction[3, 4, 2] = {{(-1)^(5/6)}}
 
SOlevel23Cat1Brd3RMatrixFunction[3, 4, 3] = {{-(-1)^(5/6)}}
 
SOlevel23Cat1Brd3RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel23Cat1Brd3RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel23Cat1Brd3RMatrixFunction[4, 2, 2] = {{(-1)^(5/6)}}
 
SOlevel23Cat1Brd3RMatrixFunction[4, 2, 3] = {{(-1)^(5/6)}}
 
SOlevel23Cat1Brd3RMatrixFunction[4, 3, 2] = {{(-1)^(5/6)}}
 
SOlevel23Cat1Brd3RMatrixFunction[4, 3, 3] = {{(-1)^(5/6)}}
 
SOlevel23Cat1Brd3RMatrixFunction[4, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
SOlevel23Cat1Brd3RMatrixFunction[4, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
SOlevel23Cat1Brd3RMatrixFunction[4, 4, 4] = {{-(-1)^(1/3)}}
balancedCategories[SOlevel23Cat1Brd4] ^= {SOlevel23Cat1Bal7, 
    SOlevel23Cat1Bal8}
 
SOlevel23Cat1Brd4 /: balancedCategory[SOlevel23Cat1Brd4, 1] = 
    SOlevel23Cat1Bal7
 
SOlevel23Cat1Brd4 /: balancedCategory[SOlevel23Cat1Brd4, 2] = 
    SOlevel23Cat1Bal8
 
braidedCategory[SOlevel23Cat1Brd4] ^= SOlevel23Cat1Brd4
 
fusionCategory[SOlevel23Cat1Brd4] ^= SOlevel23Cat1
 
SOlevel23Cat1Brd4 /: modularCategory[SOlevel23Cat1Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel23Cat1Brd4 /: ribbonCategory[SOlevel23Cat1Brd4, 1] = SOlevel23Cat1Bal7
 
SOlevel23Cat1Brd4 /: ribbonCategory[SOlevel23Cat1Brd4, 2] = SOlevel23Cat1Bal8
 
ring[SOlevel23Cat1Brd4] ^= SOlevel23
 
rMatrixFunction[SOlevel23Cat1Brd4] ^= SOlevel23Cat1Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel23Cat1]][braidedCategory[#1]] & )[
    SOlevel23Cat1Brd4] ^= 4
braidedCategory[SOlevel23Cat1Brd4RMatrixFunction] ^= SOlevel23Cat1Brd4
 
fusionCategory[SOlevel23Cat1Brd4RMatrixFunction] ^= SOlevel23Cat1
 
rMatrixFunction[SOlevel23Cat1Brd4RMatrixFunction] ^= 
   SOlevel23Cat1Brd4RMatrixFunction
 
SOlevel23Cat1Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel23Cat1Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel23Cat1Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel23Cat1Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel23Cat1Brd4RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel23Cat1Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel23Cat1Brd4RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel23Cat1Brd4RMatrixFunction[1, 2, 3] = {{1}}
 
SOlevel23Cat1Brd4RMatrixFunction[1, 3, 2] = {{1}}
 
SOlevel23Cat1Brd4RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel23Cat1Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel23Cat1Brd4RMatrixFunction[2, 1, 3] = {{-1}}
 
SOlevel23Cat1Brd4RMatrixFunction[2, 2, 0] = {{(-1)^(3/4)}}
 
SOlevel23Cat1Brd4RMatrixFunction[2, 2, 4] = {{-(-1)^(5/12)}}
 
SOlevel23Cat1Brd4RMatrixFunction[2, 3, 1] = {{(-1)^(1/4)}}
 
SOlevel23Cat1Brd4RMatrixFunction[2, 3, 4] = {{(-1)^(5/12)}}
 
SOlevel23Cat1Brd4RMatrixFunction[2, 4, 2] = {{-(-1)^(5/6)}}
 
SOlevel23Cat1Brd4RMatrixFunction[2, 4, 3] = {{(-1)^(5/6)}}
 
SOlevel23Cat1Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel23Cat1Brd4RMatrixFunction[3, 1, 2] = {{-1}}
 
SOlevel23Cat1Brd4RMatrixFunction[3, 2, 1] = {{(-1)^(1/4)}}
 
SOlevel23Cat1Brd4RMatrixFunction[3, 2, 4] = {{-(-1)^(5/12)}}
 
SOlevel23Cat1Brd4RMatrixFunction[3, 3, 0] = {{-(-1)^(3/4)}}
 
SOlevel23Cat1Brd4RMatrixFunction[3, 3, 4] = {{(-1)^(5/12)}}
 
SOlevel23Cat1Brd4RMatrixFunction[3, 4, 2] = {{(-1)^(5/6)}}
 
SOlevel23Cat1Brd4RMatrixFunction[3, 4, 3] = {{-(-1)^(5/6)}}
 
SOlevel23Cat1Brd4RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel23Cat1Brd4RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel23Cat1Brd4RMatrixFunction[4, 2, 2] = {{(-1)^(5/6)}}
 
SOlevel23Cat1Brd4RMatrixFunction[4, 2, 3] = {{(-1)^(5/6)}}
 
SOlevel23Cat1Brd4RMatrixFunction[4, 3, 2] = {{(-1)^(5/6)}}
 
SOlevel23Cat1Brd4RMatrixFunction[4, 3, 3] = {{(-1)^(5/6)}}
 
SOlevel23Cat1Brd4RMatrixFunction[4, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
SOlevel23Cat1Brd4RMatrixFunction[4, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
SOlevel23Cat1Brd4RMatrixFunction[4, 4, 4] = {{-(-1)^(1/3)}}
fMatrixFunction[SOlevel23Cat1FMatrixFunction] ^= SOlevel23Cat1FMatrixFunction
 
fusionCategory[SOlevel23Cat1FMatrixFunction] ^= SOlevel23Cat1
 
ring[SOlevel23Cat1FMatrixFunction] ^= SOlevel23
 
SOlevel23Cat1FMatrixFunction[1, 2, 4, 2] = {{I}}
 
SOlevel23Cat1FMatrixFunction[1, 2, 4, 3] = {{-I}}
 
SOlevel23Cat1FMatrixFunction[1, 3, 4, 2] = {{I}}
 
SOlevel23Cat1FMatrixFunction[1, 3, 4, 3] = {{-I}}
 
SOlevel23Cat1FMatrixFunction[1, 4, 2, 2] = {{I}}
 
SOlevel23Cat1FMatrixFunction[1, 4, 2, 3] = {{-I}}
 
SOlevel23Cat1FMatrixFunction[1, 4, 3, 2] = {{I}}
 
SOlevel23Cat1FMatrixFunction[1, 4, 3, 3] = {{-I}}
 
SOlevel23Cat1FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
SOlevel23Cat1FMatrixFunction[2, 1, 2, 1] = {{I}}
 
SOlevel23Cat1FMatrixFunction[2, 1, 3, 0] = {{-I}}
 
SOlevel23Cat1FMatrixFunction[2, 2, 1, 1] = {{I}}
 
SOlevel23Cat1FMatrixFunction[2, 2, 2, 2] = {{1/Sqrt[3], Sqrt[2/3]}, 
    {I*Sqrt[2/3], (-I)/Sqrt[3]}}
 
SOlevel23Cat1FMatrixFunction[2, 2, 3, 3] = {{I/Sqrt[3], Sqrt[2/3]}, 
    {-Sqrt[2/3], (-I)/Sqrt[3]}}
 
SOlevel23Cat1FMatrixFunction[2, 2, 4, 4] = {{I/Sqrt[2], (-I)/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
SOlevel23Cat1FMatrixFunction[2, 3, 1, 0] = {{-I}}
 
SOlevel23Cat1FMatrixFunction[2, 3, 2, 3] = {{(-I)/Sqrt[3], (-I)*Sqrt[2/3]}, 
    {I*Sqrt[2/3], (-I)/Sqrt[3]}}
 
SOlevel23Cat1FMatrixFunction[2, 3, 3, 2] = {{1/Sqrt[3], I*Sqrt[2/3]}, 
    {Sqrt[2/3], (-I)/Sqrt[3]}}
 
SOlevel23Cat1FMatrixFunction[2, 3, 4, 0] = {{-1}}
 
SOlevel23Cat1FMatrixFunction[2, 3, 4, 1] = {{-1}}
 
SOlevel23Cat1FMatrixFunction[2, 3, 4, 4] = {{1/Sqrt[2], (-I)/Sqrt[2]}, 
    {I/Sqrt[2], -(1/Sqrt[2])}}
 
SOlevel23Cat1FMatrixFunction[2, 4, 1, 2] = {{-I}}
 
SOlevel23Cat1FMatrixFunction[2, 4, 1, 3] = {{I}}
 
SOlevel23Cat1FMatrixFunction[2, 4, 2, 0] = {{-I}}
 
SOlevel23Cat1FMatrixFunction[2, 4, 2, 4] = {{I/2, (-I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], I/2}}
 
SOlevel23Cat1FMatrixFunction[2, 4, 3, 0] = {{I}}
 
SOlevel23Cat1FMatrixFunction[2, 4, 3, 4] = {{Sqrt[3]/2, 1/2}, 
    {-1/2, Sqrt[3]/2}}
 
SOlevel23Cat1FMatrixFunction[2, 4, 4, 2] = {{(-I)/Sqrt[2], 1/Sqrt[2]}, 
    {I/Sqrt[2], 1/Sqrt[2]}}
 
SOlevel23Cat1FMatrixFunction[2, 4, 4, 3] = {{1/Sqrt[2], I/Sqrt[2]}, 
    {(-I)/Sqrt[2], -(1/Sqrt[2])}}
 
SOlevel23Cat1FMatrixFunction[3, 1, 2, 0] = {{I}}
 
SOlevel23Cat1FMatrixFunction[3, 1, 3, 1] = {{-I}}
 
SOlevel23Cat1FMatrixFunction[3, 2, 1, 0] = {{I}}
 
SOlevel23Cat1FMatrixFunction[3, 2, 2, 3] = {{1/Sqrt[3], (-I)*Sqrt[2/3]}, 
    {-Sqrt[2/3], (-I)/Sqrt[3]}}
 
SOlevel23Cat1FMatrixFunction[3, 2, 3, 2] = {{I/Sqrt[3], I*Sqrt[2/3]}, 
    {I*Sqrt[2/3], (-I)/Sqrt[3]}}
 
SOlevel23Cat1FMatrixFunction[3, 2, 4, 4] = {{I/Sqrt[2], I/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
SOlevel23Cat1FMatrixFunction[3, 3, 1, 1] = {{-I}}
 
SOlevel23Cat1FMatrixFunction[3, 3, 2, 2] = {{(-I)/Sqrt[3], Sqrt[2/3]}, 
    {Sqrt[2/3], (-I)/Sqrt[3]}}
 
SOlevel23Cat1FMatrixFunction[3, 3, 3, 3] = {{1/Sqrt[3], Sqrt[2/3]}, 
    {I*Sqrt[2/3], (-I)/Sqrt[3]}}
 
SOlevel23Cat1FMatrixFunction[3, 3, 4, 0] = {{-1}}
 
SOlevel23Cat1FMatrixFunction[3, 3, 4, 1] = {{-1}}
 
SOlevel23Cat1FMatrixFunction[3, 3, 4, 4] = {{1/Sqrt[2], I/Sqrt[2]}, 
    {I/Sqrt[2], 1/Sqrt[2]}}
 
SOlevel23Cat1FMatrixFunction[3, 4, 1, 2] = {{-I}}
 
SOlevel23Cat1FMatrixFunction[3, 4, 1, 3] = {{I}}
 
SOlevel23Cat1FMatrixFunction[3, 4, 2, 0] = {{I}}
 
SOlevel23Cat1FMatrixFunction[3, 4, 2, 1] = {{-1}}
 
SOlevel23Cat1FMatrixFunction[3, 4, 2, 4] = {{Sqrt[3]/2, 1/2}, 
    {-1/2, Sqrt[3]/2}}
 
SOlevel23Cat1FMatrixFunction[3, 4, 3, 0] = {{-I}}
 
SOlevel23Cat1FMatrixFunction[3, 4, 3, 1] = {{-1}}
 
SOlevel23Cat1FMatrixFunction[3, 4, 3, 4] = {{I/2, (-I/2)*Sqrt[3]}, 
    {(I/2)*Sqrt[3], I/2}}
 
SOlevel23Cat1FMatrixFunction[3, 4, 4, 2] = {{(-I)/Sqrt[2], 1/Sqrt[2]}, 
    {(-I)/Sqrt[2], -(1/Sqrt[2])}}
 
SOlevel23Cat1FMatrixFunction[3, 4, 4, 3] = {{1/Sqrt[2], I/Sqrt[2]}, 
    {I/Sqrt[2], 1/Sqrt[2]}}
 
SOlevel23Cat1FMatrixFunction[4, 1, 4, 0] = {{-1}}
 
SOlevel23Cat1FMatrixFunction[4, 1, 4, 1] = {{-1}}
 
SOlevel23Cat1FMatrixFunction[4, 2, 1, 2] = {{-I}}
 
SOlevel23Cat1FMatrixFunction[4, 2, 1, 3] = {{I}}
 
SOlevel23Cat1FMatrixFunction[4, 2, 2, 0] = {{I}}
 
SOlevel23Cat1FMatrixFunction[4, 2, 2, 4] = {{1/Sqrt[2], (-I)/Sqrt[2]}, 
    {-(1/Sqrt[2]), (-I)/Sqrt[2]}}
 
SOlevel23Cat1FMatrixFunction[4, 2, 3, 0] = {{I}}
 
SOlevel23Cat1FMatrixFunction[4, 2, 3, 1] = {{-1}}
 
SOlevel23Cat1FMatrixFunction[4, 2, 3, 4] = {{I/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], I/Sqrt[2]}}
 
SOlevel23Cat1FMatrixFunction[4, 2, 4, 2] = {{-1/2, Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
SOlevel23Cat1FMatrixFunction[4, 2, 4, 3] = {{(I/2)*Sqrt[3], I/2}, 
    {-I/2, (I/2)*Sqrt[3]}}
 
SOlevel23Cat1FMatrixFunction[4, 3, 1, 2] = {{-I}}
 
SOlevel23Cat1FMatrixFunction[4, 3, 1, 3] = {{I}}
 
SOlevel23Cat1FMatrixFunction[4, 3, 2, 0] = {{-I}}
 
SOlevel23Cat1FMatrixFunction[4, 3, 2, 1] = {{-1}}
 
SOlevel23Cat1FMatrixFunction[4, 3, 2, 4] = {{1/Sqrt[2], (-I)/Sqrt[2]}, 
    {-(1/Sqrt[2]), (-I)/Sqrt[2]}}
 
SOlevel23Cat1FMatrixFunction[4, 3, 3, 0] = {{-I}}
 
SOlevel23Cat1FMatrixFunction[4, 3, 3, 4] = {{I/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], I/Sqrt[2]}}
 
SOlevel23Cat1FMatrixFunction[4, 3, 4, 2] = {{(I/2)*Sqrt[3], I/2}, 
    {-I/2, (I/2)*Sqrt[3]}}
 
SOlevel23Cat1FMatrixFunction[4, 3, 4, 3] = {{-1/2, Sqrt[3]/2}, 
    {-Sqrt[3]/2, -1/2}}
 
SOlevel23Cat1FMatrixFunction[4, 4, 1, 0] = {{-1}}
 
SOlevel23Cat1FMatrixFunction[4, 4, 1, 1] = {{-1}}
 
SOlevel23Cat1FMatrixFunction[4, 4, 1, 4] = {{-1}}
 
SOlevel23Cat1FMatrixFunction[4, 4, 2, 2] = {{(-I)/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), (-I)/Sqrt[2]}}
 
SOlevel23Cat1FMatrixFunction[4, 4, 2, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {(-I)/Sqrt[2], I/Sqrt[2]}}
 
SOlevel23Cat1FMatrixFunction[4, 4, 3, 2] = {{I/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], I/Sqrt[2]}}
 
SOlevel23Cat1FMatrixFunction[4, 4, 3, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {I/Sqrt[2], (-I)/Sqrt[2]}}
 
SOlevel23Cat1FMatrixFunction[4, 4, 4, 1] = {{-1}}
 
SOlevel23Cat1FMatrixFunction[4, 4, 4, 4] = {{1/2, 1/2, I/Sqrt[2]}, 
    {-1/2, -1/2, I/Sqrt[2]}, {(-I)/Sqrt[2], I/Sqrt[2], 0}}
 
SOlevel23Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SOlevel23Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
SOlevel23Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SOlevel23Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[SOlevel23Cat1Piv1] ^= {SOlevel23Cat1Bal1, 
    SOlevel23Cat1Bal3, SOlevel23Cat1Bal5, SOlevel23Cat1Bal7}
 
SOlevel23Cat1Piv1 /: balancedCategory[SOlevel23Cat1Piv1, 1] = 
    SOlevel23Cat1Bal1
 
SOlevel23Cat1Piv1 /: balancedCategory[SOlevel23Cat1Piv1, 2] = 
    SOlevel23Cat1Bal3
 
SOlevel23Cat1Piv1 /: balancedCategory[SOlevel23Cat1Piv1, 3] = 
    SOlevel23Cat1Bal5
 
SOlevel23Cat1Piv1 /: balancedCategory[SOlevel23Cat1Piv1, 4] = 
    SOlevel23Cat1Bal7
 
fusionCategory[SOlevel23Cat1Piv1] ^= SOlevel23Cat1
 
SOlevel23Cat1Piv1 /: modularCategory[SOlevel23Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SOlevel23Cat1Piv1] ^= SOlevel23Cat1Piv1
 
pivotalIsomorphism[SOlevel23Cat1Piv1] ^= SOlevel23Cat1Piv1PivotalIsomorphism
 
SOlevel23Cat1Piv1 /: ribbonCategory[SOlevel23Cat1Piv1, 1] = SOlevel23Cat1Bal1
 
SOlevel23Cat1Piv1 /: ribbonCategory[SOlevel23Cat1Piv1, 2] = SOlevel23Cat1Bal3
 
SOlevel23Cat1Piv1 /: ribbonCategory[SOlevel23Cat1Piv1, 3] = SOlevel23Cat1Bal5
 
SOlevel23Cat1Piv1 /: ribbonCategory[SOlevel23Cat1Piv1, 4] = SOlevel23Cat1Bal7
 
ring[SOlevel23Cat1Piv1] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat1Piv1] ^= SOlevel23Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[SOlevel23Cat1]][pivotalCategory[#1]] & )[
    SOlevel23Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[SOlevel23Cat1]][
      sphericalCategory[#1]] & )[SOlevel23Cat1Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[SOlevel23Cat1Piv1PivotalIsomorphism] ^= SOlevel23Cat1
 
pivotalCategory[SOlevel23Cat1Piv1PivotalIsomorphism] ^= SOlevel23Cat1Piv1
 
pivotalIsomorphism[SOlevel23Cat1Piv1PivotalIsomorphism] ^= 
   SOlevel23Cat1Piv1PivotalIsomorphism
 
SOlevel23Cat1Piv1PivotalIsomorphism[0] = 1
 
SOlevel23Cat1Piv1PivotalIsomorphism[1] = 1
 
SOlevel23Cat1Piv1PivotalIsomorphism[2] = 1
 
SOlevel23Cat1Piv1PivotalIsomorphism[3] = 1
 
SOlevel23Cat1Piv1PivotalIsomorphism[4] = 1
balancedCategories[SOlevel23Cat1Piv2] ^= {SOlevel23Cat1Bal2, 
    SOlevel23Cat1Bal4, SOlevel23Cat1Bal6, SOlevel23Cat1Bal8}
 
SOlevel23Cat1Piv2 /: balancedCategory[SOlevel23Cat1Piv2, 1] = 
    SOlevel23Cat1Bal2
 
SOlevel23Cat1Piv2 /: balancedCategory[SOlevel23Cat1Piv2, 2] = 
    SOlevel23Cat1Bal4
 
SOlevel23Cat1Piv2 /: balancedCategory[SOlevel23Cat1Piv2, 3] = 
    SOlevel23Cat1Bal6
 
SOlevel23Cat1Piv2 /: balancedCategory[SOlevel23Cat1Piv2, 4] = 
    SOlevel23Cat1Bal8
 
fusionCategory[SOlevel23Cat1Piv2] ^= SOlevel23Cat1
 
SOlevel23Cat1Piv2 /: modularCategory[SOlevel23Cat1Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SOlevel23Cat1Piv2] ^= SOlevel23Cat1Piv2
 
pivotalIsomorphism[SOlevel23Cat1Piv2] ^= SOlevel23Cat1Piv2PivotalIsomorphism
 
SOlevel23Cat1Piv2 /: ribbonCategory[SOlevel23Cat1Piv2, 1] = SOlevel23Cat1Bal2
 
SOlevel23Cat1Piv2 /: ribbonCategory[SOlevel23Cat1Piv2, 2] = SOlevel23Cat1Bal4
 
SOlevel23Cat1Piv2 /: ribbonCategory[SOlevel23Cat1Piv2, 3] = SOlevel23Cat1Bal6
 
SOlevel23Cat1Piv2 /: ribbonCategory[SOlevel23Cat1Piv2, 4] = SOlevel23Cat1Bal8
 
ring[SOlevel23Cat1Piv2] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat1Piv2] ^= SOlevel23Cat1Piv2
 
(pivotalCategoryIndex[fusionCategory[SOlevel23Cat1]][pivotalCategory[#1]] & )[
    SOlevel23Cat1Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[SOlevel23Cat1]][
      sphericalCategory[#1]] & )[SOlevel23Cat1Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[SOlevel23Cat1Piv2PivotalIsomorphism] ^= SOlevel23Cat1
 
pivotalCategory[SOlevel23Cat1Piv2PivotalIsomorphism] ^= SOlevel23Cat1Piv2
 
pivotalIsomorphism[SOlevel23Cat1Piv2PivotalIsomorphism] ^= 
   SOlevel23Cat1Piv2PivotalIsomorphism
 
SOlevel23Cat1Piv2PivotalIsomorphism[0] = 1
 
SOlevel23Cat1Piv2PivotalIsomorphism[1] = 1
 
SOlevel23Cat1Piv2PivotalIsomorphism[2] = -1
 
SOlevel23Cat1Piv2PivotalIsomorphism[3] = -1
 
SOlevel23Cat1Piv2PivotalIsomorphism[4] = 1
balancedCategories[SOlevel23Cat2] ^= {SOlevel23Cat2Bal1, SOlevel23Cat2Bal2, 
    SOlevel23Cat2Bal3, SOlevel23Cat2Bal4, SOlevel23Cat2Bal5, 
    SOlevel23Cat2Bal6, SOlevel23Cat2Bal7, SOlevel23Cat2Bal8}
 
SOlevel23Cat2 /: balancedCategory[SOlevel23Cat2, 1] = SOlevel23Cat2Bal1
 
SOlevel23Cat2 /: balancedCategory[SOlevel23Cat2, 2] = SOlevel23Cat2Bal2
 
SOlevel23Cat2 /: balancedCategory[SOlevel23Cat2, 3] = SOlevel23Cat2Bal3
 
SOlevel23Cat2 /: balancedCategory[SOlevel23Cat2, 4] = SOlevel23Cat2Bal4
 
SOlevel23Cat2 /: balancedCategory[SOlevel23Cat2, 5] = SOlevel23Cat2Bal5
 
SOlevel23Cat2 /: balancedCategory[SOlevel23Cat2, 6] = SOlevel23Cat2Bal6
 
SOlevel23Cat2 /: balancedCategory[SOlevel23Cat2, 7] = SOlevel23Cat2Bal7
 
SOlevel23Cat2 /: balancedCategory[SOlevel23Cat2, 8] = SOlevel23Cat2Bal8
 
braidedCategories[SOlevel23Cat2] ^= {SOlevel23Cat2Brd1, SOlevel23Cat2Brd2, 
    SOlevel23Cat2Brd3, SOlevel23Cat2Brd4}
 
SOlevel23Cat2 /: braidedCategory[SOlevel23Cat2, 1] = SOlevel23Cat2Brd1
 
SOlevel23Cat2 /: braidedCategory[SOlevel23Cat2, 2] = SOlevel23Cat2Brd2
 
SOlevel23Cat2 /: braidedCategory[SOlevel23Cat2, 3] = SOlevel23Cat2Brd3
 
SOlevel23Cat2 /: braidedCategory[SOlevel23Cat2, 4] = SOlevel23Cat2Brd4
 
coeval[SOlevel23Cat2] ^= 1/sixJFunction[SOlevel23Cat2][#1, 
      dual[ring[SOlevel23Cat2]][#1], #1, #1, 0, 0] & 
 
eval[SOlevel23Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[SOlevel23Cat2] ^= SOlevel23Cat2FMatrixFunction
 
fusionCategory[SOlevel23Cat2] ^= SOlevel23Cat2
 
SOlevel23Cat2 /: modularCategory[SOlevel23Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[SOlevel23Cat2] ^= {SOlevel23Cat2Piv1, SOlevel23Cat2Piv2}
 
SOlevel23Cat2 /: pivotalCategory[SOlevel23Cat2, 1] = SOlevel23Cat2Piv1
 
SOlevel23Cat2 /: pivotalCategory[SOlevel23Cat2, 2] = SOlevel23Cat2Piv2
 
SOlevel23Cat2 /: pivotalCategory[SOlevel23Cat2, {1, 1, -1, -1, 1}] = 
    SOlevel23Cat2Piv2
 
SOlevel23Cat2 /: pivotalCategory[SOlevel23Cat2, {1, 1, 1, 1, 1}] = 
    SOlevel23Cat2Piv1
 
SOlevel23Cat2 /: ribbonCategory[SOlevel23Cat2, 1] = SOlevel23Cat2Bal1
 
SOlevel23Cat2 /: ribbonCategory[SOlevel23Cat2, 2] = SOlevel23Cat2Bal2
 
SOlevel23Cat2 /: ribbonCategory[SOlevel23Cat2, 3] = SOlevel23Cat2Bal3
 
SOlevel23Cat2 /: ribbonCategory[SOlevel23Cat2, 4] = SOlevel23Cat2Bal4
 
SOlevel23Cat2 /: ribbonCategory[SOlevel23Cat2, 5] = SOlevel23Cat2Bal5
 
SOlevel23Cat2 /: ribbonCategory[SOlevel23Cat2, 6] = SOlevel23Cat2Bal6
 
SOlevel23Cat2 /: ribbonCategory[SOlevel23Cat2, 7] = SOlevel23Cat2Bal7
 
SOlevel23Cat2 /: ribbonCategory[SOlevel23Cat2, 8] = SOlevel23Cat2Bal8
 
ring[SOlevel23Cat2] ^= SOlevel23
 
SOlevel23Cat2 /: sphericalCategory[SOlevel23Cat2, 1] = SOlevel23Cat2Piv1
 
SOlevel23Cat2 /: sphericalCategory[SOlevel23Cat2, 2] = SOlevel23Cat2Piv2
 
fusionCategoryIndex[SOlevel23][SOlevel23Cat2] ^= 2
balancedCategory[SOlevel23Cat2Bal1] ^= SOlevel23Cat2Bal1
 
braidedCategory[SOlevel23Cat2Bal1] ^= SOlevel23Cat2Brd1
 
fusionCategory[SOlevel23Cat2Bal1] ^= SOlevel23Cat2
 
pivotalCategory[SOlevel23Cat2Bal1] ^= SOlevel23Cat2Piv1
 
ribbonCategory[SOlevel23Cat2Bal1] ^= SOlevel23Cat2Bal1
 
ring[SOlevel23Cat2Bal1] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat2Bal1] ^= SOlevel23Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel23Cat2Brd1]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel23Cat2]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[SOlevel23Cat2Piv1]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SOlevel23Cat2Brd1]][
      ribbonCategory[#1]] & )[SOlevel23Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel23Cat2]][ribbonCategory[#1]] & )[
    SOlevel23Cat2Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[SOlevel23Cat2Piv1]][
      ribbonCategory[#1]] & )[SOlevel23Cat2Bal1] ^= 1
balancedCategory[SOlevel23Cat2Bal2] ^= SOlevel23Cat2Bal2
 
braidedCategory[SOlevel23Cat2Bal2] ^= SOlevel23Cat2Brd1
 
fusionCategory[SOlevel23Cat2Bal2] ^= SOlevel23Cat2
 
pivotalCategory[SOlevel23Cat2Bal2] ^= SOlevel23Cat2Piv2
 
ribbonCategory[SOlevel23Cat2Bal2] ^= SOlevel23Cat2Bal2
 
ring[SOlevel23Cat2Bal2] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat2Bal2] ^= SOlevel23Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel23Cat2Brd1]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal2] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel23Cat2]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[SOlevel23Cat2Piv2]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal2] ^= 1
 
(ribbonCategoryIndex[braidedCategory[SOlevel23Cat2Brd1]][
      ribbonCategory[#1]] & )[SOlevel23Cat2Bal2] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel23Cat2]][ribbonCategory[#1]] & )[
    SOlevel23Cat2Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[SOlevel23Cat2Piv2]][
      ribbonCategory[#1]] & )[SOlevel23Cat2Bal2] ^= 1
balancedCategory[SOlevel23Cat2Bal3] ^= SOlevel23Cat2Bal3
 
braidedCategory[SOlevel23Cat2Bal3] ^= SOlevel23Cat2Brd2
 
fusionCategory[SOlevel23Cat2Bal3] ^= SOlevel23Cat2
 
pivotalCategory[SOlevel23Cat2Bal3] ^= SOlevel23Cat2Piv1
 
ribbonCategory[SOlevel23Cat2Bal3] ^= SOlevel23Cat2Bal3
 
ring[SOlevel23Cat2Bal3] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat2Bal3] ^= SOlevel23Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel23Cat2Brd2]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel23Cat2]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[SOlevel23Cat2Piv1]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal3] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SOlevel23Cat2Brd2]][
      ribbonCategory[#1]] & )[SOlevel23Cat2Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel23Cat2]][ribbonCategory[#1]] & )[
    SOlevel23Cat2Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[SOlevel23Cat2Piv1]][
      ribbonCategory[#1]] & )[SOlevel23Cat2Bal3] ^= 2
balancedCategory[SOlevel23Cat2Bal4] ^= SOlevel23Cat2Bal4
 
braidedCategory[SOlevel23Cat2Bal4] ^= SOlevel23Cat2Brd2
 
fusionCategory[SOlevel23Cat2Bal4] ^= SOlevel23Cat2
 
pivotalCategory[SOlevel23Cat2Bal4] ^= SOlevel23Cat2Piv2
 
ribbonCategory[SOlevel23Cat2Bal4] ^= SOlevel23Cat2Bal4
 
ring[SOlevel23Cat2Bal4] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat2Bal4] ^= SOlevel23Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel23Cat2Brd2]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal4] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel23Cat2]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[SOlevel23Cat2Piv2]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal4] ^= 2
 
(ribbonCategoryIndex[braidedCategory[SOlevel23Cat2Brd2]][
      ribbonCategory[#1]] & )[SOlevel23Cat2Bal4] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel23Cat2]][ribbonCategory[#1]] & )[
    SOlevel23Cat2Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[SOlevel23Cat2Piv2]][
      ribbonCategory[#1]] & )[SOlevel23Cat2Bal4] ^= 2
balancedCategory[SOlevel23Cat2Bal5] ^= SOlevel23Cat2Bal5
 
braidedCategory[SOlevel23Cat2Bal5] ^= SOlevel23Cat2Brd3
 
fusionCategory[SOlevel23Cat2Bal5] ^= SOlevel23Cat2
 
pivotalCategory[SOlevel23Cat2Bal5] ^= SOlevel23Cat2Piv1
 
ribbonCategory[SOlevel23Cat2Bal5] ^= SOlevel23Cat2Bal5
 
ring[SOlevel23Cat2Bal5] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat2Bal5] ^= SOlevel23Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel23Cat2Brd3]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel23Cat2]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[SOlevel23Cat2Piv1]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal5] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SOlevel23Cat2Brd3]][
      ribbonCategory[#1]] & )[SOlevel23Cat2Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel23Cat2]][ribbonCategory[#1]] & )[
    SOlevel23Cat2Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[SOlevel23Cat2Piv1]][
      ribbonCategory[#1]] & )[SOlevel23Cat2Bal5] ^= 3
balancedCategory[SOlevel23Cat2Bal6] ^= SOlevel23Cat2Bal6
 
braidedCategory[SOlevel23Cat2Bal6] ^= SOlevel23Cat2Brd3
 
fusionCategory[SOlevel23Cat2Bal6] ^= SOlevel23Cat2
 
pivotalCategory[SOlevel23Cat2Bal6] ^= SOlevel23Cat2Piv2
 
ribbonCategory[SOlevel23Cat2Bal6] ^= SOlevel23Cat2Bal6
 
ring[SOlevel23Cat2Bal6] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat2Bal6] ^= SOlevel23Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel23Cat2Brd3]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal6] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel23Cat2]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal6] ^= 6
 
(balancedCategoryIndex[pivotalCategory[SOlevel23Cat2Piv2]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal6] ^= 3
 
(ribbonCategoryIndex[braidedCategory[SOlevel23Cat2Brd3]][
      ribbonCategory[#1]] & )[SOlevel23Cat2Bal6] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel23Cat2]][ribbonCategory[#1]] & )[
    SOlevel23Cat2Bal6] ^= 6
 
(ribbonCategoryIndex[sphericalCategory[SOlevel23Cat2Piv2]][
      ribbonCategory[#1]] & )[SOlevel23Cat2Bal6] ^= 3
balancedCategory[SOlevel23Cat2Bal7] ^= SOlevel23Cat2Bal7
 
braidedCategory[SOlevel23Cat2Bal7] ^= SOlevel23Cat2Brd4
 
fusionCategory[SOlevel23Cat2Bal7] ^= SOlevel23Cat2
 
pivotalCategory[SOlevel23Cat2Bal7] ^= SOlevel23Cat2Piv1
 
ribbonCategory[SOlevel23Cat2Bal7] ^= SOlevel23Cat2Bal7
 
ring[SOlevel23Cat2Bal7] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat2Bal7] ^= SOlevel23Cat2Piv1
 
(balancedCategoryIndex[braidedCategory[SOlevel23Cat2Brd4]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal7] ^= 1
 
(balancedCategoryIndex[fusionCategory[SOlevel23Cat2]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal7] ^= 7
 
(balancedCategoryIndex[pivotalCategory[SOlevel23Cat2Piv1]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal7] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SOlevel23Cat2Brd4]][
      ribbonCategory[#1]] & )[SOlevel23Cat2Bal7] ^= 1
 
(ribbonCategoryIndex[fusionCategory[SOlevel23Cat2]][ribbonCategory[#1]] & )[
    SOlevel23Cat2Bal7] ^= 7
 
(ribbonCategoryIndex[sphericalCategory[SOlevel23Cat2Piv1]][
      ribbonCategory[#1]] & )[SOlevel23Cat2Bal7] ^= 4
balancedCategory[SOlevel23Cat2Bal8] ^= SOlevel23Cat2Bal8
 
braidedCategory[SOlevel23Cat2Bal8] ^= SOlevel23Cat2Brd4
 
fusionCategory[SOlevel23Cat2Bal8] ^= SOlevel23Cat2
 
pivotalCategory[SOlevel23Cat2Bal8] ^= SOlevel23Cat2Piv2
 
ribbonCategory[SOlevel23Cat2Bal8] ^= SOlevel23Cat2Bal8
 
ring[SOlevel23Cat2Bal8] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat2Bal8] ^= SOlevel23Cat2Piv2
 
(balancedCategoryIndex[braidedCategory[SOlevel23Cat2Brd4]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal8] ^= 2
 
(balancedCategoryIndex[fusionCategory[SOlevel23Cat2]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal8] ^= 8
 
(balancedCategoryIndex[pivotalCategory[SOlevel23Cat2Piv2]][
      balancedCategory[#1]] & )[SOlevel23Cat2Bal8] ^= 4
 
(ribbonCategoryIndex[braidedCategory[SOlevel23Cat2Brd4]][
      ribbonCategory[#1]] & )[SOlevel23Cat2Bal8] ^= 2
 
(ribbonCategoryIndex[fusionCategory[SOlevel23Cat2]][ribbonCategory[#1]] & )[
    SOlevel23Cat2Bal8] ^= 8
 
(ribbonCategoryIndex[sphericalCategory[SOlevel23Cat2Piv2]][
      ribbonCategory[#1]] & )[SOlevel23Cat2Bal8] ^= 4
balancedCategories[SOlevel23Cat2Brd1] ^= {SOlevel23Cat2Bal1, 
    SOlevel23Cat2Bal2}
 
SOlevel23Cat2Brd1 /: balancedCategory[SOlevel23Cat2Brd1, 1] = 
    SOlevel23Cat2Bal1
 
SOlevel23Cat2Brd1 /: balancedCategory[SOlevel23Cat2Brd1, 2] = 
    SOlevel23Cat2Bal2
 
braidedCategory[SOlevel23Cat2Brd1] ^= SOlevel23Cat2Brd1
 
fusionCategory[SOlevel23Cat2Brd1] ^= SOlevel23Cat2
 
SOlevel23Cat2Brd1 /: modularCategory[SOlevel23Cat2Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel23Cat2Brd1 /: ribbonCategory[SOlevel23Cat2Brd1, 1] = SOlevel23Cat2Bal1
 
SOlevel23Cat2Brd1 /: ribbonCategory[SOlevel23Cat2Brd1, 2] = SOlevel23Cat2Bal2
 
ring[SOlevel23Cat2Brd1] ^= SOlevel23
 
rMatrixFunction[SOlevel23Cat2Brd1] ^= SOlevel23Cat2Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel23Cat2]][braidedCategory[#1]] & )[
    SOlevel23Cat2Brd1] ^= 1
braidedCategory[SOlevel23Cat2Brd1RMatrixFunction] ^= SOlevel23Cat2Brd1
 
fusionCategory[SOlevel23Cat2Brd1RMatrixFunction] ^= SOlevel23Cat2
 
rMatrixFunction[SOlevel23Cat2Brd1RMatrixFunction] ^= 
   SOlevel23Cat2Brd1RMatrixFunction
 
SOlevel23Cat2Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel23Cat2Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel23Cat2Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel23Cat2Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel23Cat2Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel23Cat2Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel23Cat2Brd1RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel23Cat2Brd1RMatrixFunction[1, 2, 3] = {{1}}
 
SOlevel23Cat2Brd1RMatrixFunction[1, 3, 2] = {{1}}
 
SOlevel23Cat2Brd1RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel23Cat2Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel23Cat2Brd1RMatrixFunction[2, 1, 3] = {{-1}}
 
SOlevel23Cat2Brd1RMatrixFunction[2, 2, 0] = {{-(-1)^(3/4)}}
 
SOlevel23Cat2Brd1RMatrixFunction[2, 2, 4] = {{-(-1)^(1/12)}}
 
SOlevel23Cat2Brd1RMatrixFunction[2, 3, 1] = {{-(-1)^(1/4)}}
 
SOlevel23Cat2Brd1RMatrixFunction[2, 3, 4] = {{(-1)^(1/12)}}
 
SOlevel23Cat2Brd1RMatrixFunction[2, 4, 2] = {{-(-1)^(1/6)}}
 
SOlevel23Cat2Brd1RMatrixFunction[2, 4, 3] = {{(-1)^(1/6)}}
 
SOlevel23Cat2Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel23Cat2Brd1RMatrixFunction[3, 1, 2] = {{-1}}
 
SOlevel23Cat2Brd1RMatrixFunction[3, 2, 1] = {{-(-1)^(1/4)}}
 
SOlevel23Cat2Brd1RMatrixFunction[3, 2, 4] = {{-(-1)^(1/12)}}
 
SOlevel23Cat2Brd1RMatrixFunction[3, 3, 0] = {{(-1)^(3/4)}}
 
SOlevel23Cat2Brd1RMatrixFunction[3, 3, 4] = {{(-1)^(1/12)}}
 
SOlevel23Cat2Brd1RMatrixFunction[3, 4, 2] = {{(-1)^(1/6)}}
 
SOlevel23Cat2Brd1RMatrixFunction[3, 4, 3] = {{-(-1)^(1/6)}}
 
SOlevel23Cat2Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel23Cat2Brd1RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel23Cat2Brd1RMatrixFunction[4, 2, 2] = {{(-1)^(1/6)}}
 
SOlevel23Cat2Brd1RMatrixFunction[4, 2, 3] = {{(-1)^(1/6)}}
 
SOlevel23Cat2Brd1RMatrixFunction[4, 3, 2] = {{(-1)^(1/6)}}
 
SOlevel23Cat2Brd1RMatrixFunction[4, 3, 3] = {{(-1)^(1/6)}}
 
SOlevel23Cat2Brd1RMatrixFunction[4, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
SOlevel23Cat2Brd1RMatrixFunction[4, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
SOlevel23Cat2Brd1RMatrixFunction[4, 4, 4] = {{(-1)^(2/3)}}
balancedCategories[SOlevel23Cat2Brd2] ^= {SOlevel23Cat2Bal3, 
    SOlevel23Cat2Bal4}
 
SOlevel23Cat2Brd2 /: balancedCategory[SOlevel23Cat2Brd2, 1] = 
    SOlevel23Cat2Bal3
 
SOlevel23Cat2Brd2 /: balancedCategory[SOlevel23Cat2Brd2, 2] = 
    SOlevel23Cat2Bal4
 
braidedCategory[SOlevel23Cat2Brd2] ^= SOlevel23Cat2Brd2
 
fusionCategory[SOlevel23Cat2Brd2] ^= SOlevel23Cat2
 
SOlevel23Cat2Brd2 /: modularCategory[SOlevel23Cat2Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel23Cat2Brd2 /: ribbonCategory[SOlevel23Cat2Brd2, 1] = SOlevel23Cat2Bal3
 
SOlevel23Cat2Brd2 /: ribbonCategory[SOlevel23Cat2Brd2, 2] = SOlevel23Cat2Bal4
 
ring[SOlevel23Cat2Brd2] ^= SOlevel23
 
rMatrixFunction[SOlevel23Cat2Brd2] ^= SOlevel23Cat2Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel23Cat2]][braidedCategory[#1]] & )[
    SOlevel23Cat2Brd2] ^= 2
braidedCategory[SOlevel23Cat2Brd2RMatrixFunction] ^= SOlevel23Cat2Brd2
 
fusionCategory[SOlevel23Cat2Brd2RMatrixFunction] ^= SOlevel23Cat2
 
rMatrixFunction[SOlevel23Cat2Brd2RMatrixFunction] ^= 
   SOlevel23Cat2Brd2RMatrixFunction
 
SOlevel23Cat2Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel23Cat2Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel23Cat2Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel23Cat2Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel23Cat2Brd2RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel23Cat2Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel23Cat2Brd2RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel23Cat2Brd2RMatrixFunction[1, 2, 3] = {{1}}
 
SOlevel23Cat2Brd2RMatrixFunction[1, 3, 2] = {{1}}
 
SOlevel23Cat2Brd2RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel23Cat2Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel23Cat2Brd2RMatrixFunction[2, 1, 3] = {{-1}}
 
SOlevel23Cat2Brd2RMatrixFunction[2, 2, 0] = {{(-1)^(3/4)}}
 
SOlevel23Cat2Brd2RMatrixFunction[2, 2, 4] = {{(-1)^(1/12)}}
 
SOlevel23Cat2Brd2RMatrixFunction[2, 3, 1] = {{(-1)^(1/4)}}
 
SOlevel23Cat2Brd2RMatrixFunction[2, 3, 4] = {{-(-1)^(1/12)}}
 
SOlevel23Cat2Brd2RMatrixFunction[2, 4, 2] = {{-(-1)^(1/6)}}
 
SOlevel23Cat2Brd2RMatrixFunction[2, 4, 3] = {{(-1)^(1/6)}}
 
SOlevel23Cat2Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel23Cat2Brd2RMatrixFunction[3, 1, 2] = {{-1}}
 
SOlevel23Cat2Brd2RMatrixFunction[3, 2, 1] = {{(-1)^(1/4)}}
 
SOlevel23Cat2Brd2RMatrixFunction[3, 2, 4] = {{(-1)^(1/12)}}
 
SOlevel23Cat2Brd2RMatrixFunction[3, 3, 0] = {{-(-1)^(3/4)}}
 
SOlevel23Cat2Brd2RMatrixFunction[3, 3, 4] = {{-(-1)^(1/12)}}
 
SOlevel23Cat2Brd2RMatrixFunction[3, 4, 2] = {{(-1)^(1/6)}}
 
SOlevel23Cat2Brd2RMatrixFunction[3, 4, 3] = {{-(-1)^(1/6)}}
 
SOlevel23Cat2Brd2RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel23Cat2Brd2RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel23Cat2Brd2RMatrixFunction[4, 2, 2] = {{(-1)^(1/6)}}
 
SOlevel23Cat2Brd2RMatrixFunction[4, 2, 3] = {{(-1)^(1/6)}}
 
SOlevel23Cat2Brd2RMatrixFunction[4, 3, 2] = {{(-1)^(1/6)}}
 
SOlevel23Cat2Brd2RMatrixFunction[4, 3, 3] = {{(-1)^(1/6)}}
 
SOlevel23Cat2Brd2RMatrixFunction[4, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
SOlevel23Cat2Brd2RMatrixFunction[4, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
SOlevel23Cat2Brd2RMatrixFunction[4, 4, 4] = {{(-1)^(2/3)}}
balancedCategories[SOlevel23Cat2Brd3] ^= {SOlevel23Cat2Bal5, 
    SOlevel23Cat2Bal6}
 
SOlevel23Cat2Brd3 /: balancedCategory[SOlevel23Cat2Brd3, 1] = 
    SOlevel23Cat2Bal5
 
SOlevel23Cat2Brd3 /: balancedCategory[SOlevel23Cat2Brd3, 2] = 
    SOlevel23Cat2Bal6
 
braidedCategory[SOlevel23Cat2Brd3] ^= SOlevel23Cat2Brd3
 
fusionCategory[SOlevel23Cat2Brd3] ^= SOlevel23Cat2
 
SOlevel23Cat2Brd3 /: modularCategory[SOlevel23Cat2Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel23Cat2Brd3 /: ribbonCategory[SOlevel23Cat2Brd3, 1] = SOlevel23Cat2Bal5
 
SOlevel23Cat2Brd3 /: ribbonCategory[SOlevel23Cat2Brd3, 2] = SOlevel23Cat2Bal6
 
ring[SOlevel23Cat2Brd3] ^= SOlevel23
 
rMatrixFunction[SOlevel23Cat2Brd3] ^= SOlevel23Cat2Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel23Cat2]][braidedCategory[#1]] & )[
    SOlevel23Cat2Brd3] ^= 3
braidedCategory[SOlevel23Cat2Brd3RMatrixFunction] ^= SOlevel23Cat2Brd3
 
fusionCategory[SOlevel23Cat2Brd3RMatrixFunction] ^= SOlevel23Cat2
 
rMatrixFunction[SOlevel23Cat2Brd3RMatrixFunction] ^= 
   SOlevel23Cat2Brd3RMatrixFunction
 
SOlevel23Cat2Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel23Cat2Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel23Cat2Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel23Cat2Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel23Cat2Brd3RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel23Cat2Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel23Cat2Brd3RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel23Cat2Brd3RMatrixFunction[1, 2, 3] = {{-1}}
 
SOlevel23Cat2Brd3RMatrixFunction[1, 3, 2] = {{-1}}
 
SOlevel23Cat2Brd3RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel23Cat2Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel23Cat2Brd3RMatrixFunction[2, 1, 3] = {{1}}
 
SOlevel23Cat2Brd3RMatrixFunction[2, 2, 0] = {{-(-1)^(1/4)}}
 
SOlevel23Cat2Brd3RMatrixFunction[2, 2, 4] = {{-(-1)^(11/12)}}
 
SOlevel23Cat2Brd3RMatrixFunction[2, 3, 1] = {{-(-1)^(3/4)}}
 
SOlevel23Cat2Brd3RMatrixFunction[2, 3, 4] = {{-(-1)^(11/12)}}
 
SOlevel23Cat2Brd3RMatrixFunction[2, 4, 2] = {{-(-1)^(5/6)}}
 
SOlevel23Cat2Brd3RMatrixFunction[2, 4, 3] = {{-(-1)^(5/6)}}
 
SOlevel23Cat2Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel23Cat2Brd3RMatrixFunction[3, 1, 2] = {{1}}
 
SOlevel23Cat2Brd3RMatrixFunction[3, 2, 1] = {{-(-1)^(3/4)}}
 
SOlevel23Cat2Brd3RMatrixFunction[3, 2, 4] = {{(-1)^(11/12)}}
 
SOlevel23Cat2Brd3RMatrixFunction[3, 3, 0] = {{(-1)^(1/4)}}
 
SOlevel23Cat2Brd3RMatrixFunction[3, 3, 4] = {{(-1)^(11/12)}}
 
SOlevel23Cat2Brd3RMatrixFunction[3, 4, 2] = {{-(-1)^(5/6)}}
 
SOlevel23Cat2Brd3RMatrixFunction[3, 4, 3] = {{-(-1)^(5/6)}}
 
SOlevel23Cat2Brd3RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel23Cat2Brd3RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel23Cat2Brd3RMatrixFunction[4, 2, 2] = {{(-1)^(5/6)}}
 
SOlevel23Cat2Brd3RMatrixFunction[4, 2, 3] = {{-(-1)^(5/6)}}
 
SOlevel23Cat2Brd3RMatrixFunction[4, 3, 2] = {{-(-1)^(5/6)}}
 
SOlevel23Cat2Brd3RMatrixFunction[4, 3, 3] = {{(-1)^(5/6)}}
 
SOlevel23Cat2Brd3RMatrixFunction[4, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
SOlevel23Cat2Brd3RMatrixFunction[4, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
SOlevel23Cat2Brd3RMatrixFunction[4, 4, 4] = {{-(-1)^(1/3)}}
balancedCategories[SOlevel23Cat2Brd4] ^= {SOlevel23Cat2Bal7, 
    SOlevel23Cat2Bal8}
 
SOlevel23Cat2Brd4 /: balancedCategory[SOlevel23Cat2Brd4, 1] = 
    SOlevel23Cat2Bal7
 
SOlevel23Cat2Brd4 /: balancedCategory[SOlevel23Cat2Brd4, 2] = 
    SOlevel23Cat2Bal8
 
braidedCategory[SOlevel23Cat2Brd4] ^= SOlevel23Cat2Brd4
 
fusionCategory[SOlevel23Cat2Brd4] ^= SOlevel23Cat2
 
SOlevel23Cat2Brd4 /: modularCategory[SOlevel23Cat2Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
SOlevel23Cat2Brd4 /: ribbonCategory[SOlevel23Cat2Brd4, 1] = SOlevel23Cat2Bal7
 
SOlevel23Cat2Brd4 /: ribbonCategory[SOlevel23Cat2Brd4, 2] = SOlevel23Cat2Bal8
 
ring[SOlevel23Cat2Brd4] ^= SOlevel23
 
rMatrixFunction[SOlevel23Cat2Brd4] ^= SOlevel23Cat2Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[SOlevel23Cat2]][braidedCategory[#1]] & )[
    SOlevel23Cat2Brd4] ^= 4
braidedCategory[SOlevel23Cat2Brd4RMatrixFunction] ^= SOlevel23Cat2Brd4
 
fusionCategory[SOlevel23Cat2Brd4RMatrixFunction] ^= SOlevel23Cat2
 
rMatrixFunction[SOlevel23Cat2Brd4RMatrixFunction] ^= 
   SOlevel23Cat2Brd4RMatrixFunction
 
SOlevel23Cat2Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
SOlevel23Cat2Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
SOlevel23Cat2Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
SOlevel23Cat2Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
SOlevel23Cat2Brd4RMatrixFunction[0, 4, 4] = {{1}}
 
SOlevel23Cat2Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
SOlevel23Cat2Brd4RMatrixFunction[1, 1, 0] = {{1}}
 
SOlevel23Cat2Brd4RMatrixFunction[1, 2, 3] = {{-1}}
 
SOlevel23Cat2Brd4RMatrixFunction[1, 3, 2] = {{-1}}
 
SOlevel23Cat2Brd4RMatrixFunction[1, 4, 4] = {{1}}
 
SOlevel23Cat2Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
SOlevel23Cat2Brd4RMatrixFunction[2, 1, 3] = {{1}}
 
SOlevel23Cat2Brd4RMatrixFunction[2, 2, 0] = {{(-1)^(1/4)}}
 
SOlevel23Cat2Brd4RMatrixFunction[2, 2, 4] = {{(-1)^(11/12)}}
 
SOlevel23Cat2Brd4RMatrixFunction[2, 3, 1] = {{(-1)^(3/4)}}
 
SOlevel23Cat2Brd4RMatrixFunction[2, 3, 4] = {{(-1)^(11/12)}}
 
SOlevel23Cat2Brd4RMatrixFunction[2, 4, 2] = {{-(-1)^(5/6)}}
 
SOlevel23Cat2Brd4RMatrixFunction[2, 4, 3] = {{-(-1)^(5/6)}}
 
SOlevel23Cat2Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
SOlevel23Cat2Brd4RMatrixFunction[3, 1, 2] = {{1}}
 
SOlevel23Cat2Brd4RMatrixFunction[3, 2, 1] = {{(-1)^(3/4)}}
 
SOlevel23Cat2Brd4RMatrixFunction[3, 2, 4] = {{-(-1)^(11/12)}}
 
SOlevel23Cat2Brd4RMatrixFunction[3, 3, 0] = {{-(-1)^(1/4)}}
 
SOlevel23Cat2Brd4RMatrixFunction[3, 3, 4] = {{-(-1)^(11/12)}}
 
SOlevel23Cat2Brd4RMatrixFunction[3, 4, 2] = {{-(-1)^(5/6)}}
 
SOlevel23Cat2Brd4RMatrixFunction[3, 4, 3] = {{-(-1)^(5/6)}}
 
SOlevel23Cat2Brd4RMatrixFunction[4, 0, 4] = {{1}}
 
SOlevel23Cat2Brd4RMatrixFunction[4, 1, 4] = {{1}}
 
SOlevel23Cat2Brd4RMatrixFunction[4, 2, 2] = {{(-1)^(5/6)}}
 
SOlevel23Cat2Brd4RMatrixFunction[4, 2, 3] = {{-(-1)^(5/6)}}
 
SOlevel23Cat2Brd4RMatrixFunction[4, 3, 2] = {{-(-1)^(5/6)}}
 
SOlevel23Cat2Brd4RMatrixFunction[4, 3, 3] = {{(-1)^(5/6)}}
 
SOlevel23Cat2Brd4RMatrixFunction[4, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
SOlevel23Cat2Brd4RMatrixFunction[4, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
SOlevel23Cat2Brd4RMatrixFunction[4, 4, 4] = {{-(-1)^(1/3)}}
fMatrixFunction[SOlevel23Cat2FMatrixFunction] ^= SOlevel23Cat2FMatrixFunction
 
fusionCategory[SOlevel23Cat2FMatrixFunction] ^= SOlevel23Cat2
 
ring[SOlevel23Cat2FMatrixFunction] ^= SOlevel23
 
SOlevel23Cat2FMatrixFunction[1, 2, 4, 2] = {{I}}
 
SOlevel23Cat2FMatrixFunction[1, 2, 4, 3] = {{-I}}
 
SOlevel23Cat2FMatrixFunction[1, 3, 4, 2] = {{I}}
 
SOlevel23Cat2FMatrixFunction[1, 3, 4, 3] = {{-I}}
 
SOlevel23Cat2FMatrixFunction[1, 4, 2, 2] = {{I}}
 
SOlevel23Cat2FMatrixFunction[1, 4, 2, 3] = {{-I}}
 
SOlevel23Cat2FMatrixFunction[1, 4, 3, 2] = {{I}}
 
SOlevel23Cat2FMatrixFunction[1, 4, 3, 3] = {{-I}}
 
SOlevel23Cat2FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
SOlevel23Cat2FMatrixFunction[2, 1, 2, 1] = {{I}}
 
SOlevel23Cat2FMatrixFunction[2, 1, 3, 0] = {{-I}}
 
SOlevel23Cat2FMatrixFunction[2, 2, 1, 1] = {{I}}
 
SOlevel23Cat2FMatrixFunction[2, 2, 2, 2] = {{-(1/Sqrt[3]), -Sqrt[2/3]}, 
    {(-I)*Sqrt[2/3], I/Sqrt[3]}}
 
SOlevel23Cat2FMatrixFunction[2, 2, 3, 3] = {{(-I)/Sqrt[3], -Sqrt[2/3]}, 
    {Sqrt[2/3], I/Sqrt[3]}}
 
SOlevel23Cat2FMatrixFunction[2, 2, 4, 4] = {{I/Sqrt[2], (-I)/Sqrt[2]}, 
    {-(1/Sqrt[2]), -(1/Sqrt[2])}}
 
SOlevel23Cat2FMatrixFunction[2, 3, 1, 0] = {{-I}}
 
SOlevel23Cat2FMatrixFunction[2, 3, 2, 3] = {{I/Sqrt[3], I*Sqrt[2/3]}, 
    {(-I)*Sqrt[2/3], I/Sqrt[3]}}
 
SOlevel23Cat2FMatrixFunction[2, 3, 3, 2] = {{-(1/Sqrt[3]), (-I)*Sqrt[2/3]}, 
    {-Sqrt[2/3], I/Sqrt[3]}}
 
SOlevel23Cat2FMatrixFunction[2, 3, 4, 0] = {{-1}}
 
SOlevel23Cat2FMatrixFunction[2, 3, 4, 1] = {{-1}}
 
SOlevel23Cat2FMatrixFunction[2, 3, 4, 4] = {{1/Sqrt[2], (-I)/Sqrt[2]}, 
    {I/Sqrt[2], -(1/Sqrt[2])}}
 
SOlevel23Cat2FMatrixFunction[2, 4, 1, 2] = {{-I}}
 
SOlevel23Cat2FMatrixFunction[2, 4, 1, 3] = {{I}}
 
SOlevel23Cat2FMatrixFunction[2, 4, 2, 0] = {{-I}}
 
SOlevel23Cat2FMatrixFunction[2, 4, 2, 4] = {{I/2, (I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], I/2}}
 
SOlevel23Cat2FMatrixFunction[2, 4, 3, 0] = {{I}}
 
SOlevel23Cat2FMatrixFunction[2, 4, 3, 4] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
SOlevel23Cat2FMatrixFunction[2, 4, 4, 2] = {{(-I)/Sqrt[2], 1/Sqrt[2]}, 
    {I/Sqrt[2], 1/Sqrt[2]}}
 
SOlevel23Cat2FMatrixFunction[2, 4, 4, 3] = {{1/Sqrt[2], I/Sqrt[2]}, 
    {(-I)/Sqrt[2], -(1/Sqrt[2])}}
 
SOlevel23Cat2FMatrixFunction[3, 1, 2, 0] = {{I}}
 
SOlevel23Cat2FMatrixFunction[3, 1, 3, 1] = {{-I}}
 
SOlevel23Cat2FMatrixFunction[3, 2, 1, 0] = {{I}}
 
SOlevel23Cat2FMatrixFunction[3, 2, 2, 3] = {{-(1/Sqrt[3]), I*Sqrt[2/3]}, 
    {Sqrt[2/3], I/Sqrt[3]}}
 
SOlevel23Cat2FMatrixFunction[3, 2, 3, 2] = {{(-I)/Sqrt[3], (-I)*Sqrt[2/3]}, 
    {(-I)*Sqrt[2/3], I/Sqrt[3]}}
 
SOlevel23Cat2FMatrixFunction[3, 2, 4, 4] = {{I/Sqrt[2], I/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
SOlevel23Cat2FMatrixFunction[3, 3, 1, 1] = {{-I}}
 
SOlevel23Cat2FMatrixFunction[3, 3, 2, 2] = {{I/Sqrt[3], -Sqrt[2/3]}, 
    {-Sqrt[2/3], I/Sqrt[3]}}
 
SOlevel23Cat2FMatrixFunction[3, 3, 3, 3] = {{-(1/Sqrt[3]), -Sqrt[2/3]}, 
    {(-I)*Sqrt[2/3], I/Sqrt[3]}}
 
SOlevel23Cat2FMatrixFunction[3, 3, 4, 0] = {{-1}}
 
SOlevel23Cat2FMatrixFunction[3, 3, 4, 1] = {{-1}}
 
SOlevel23Cat2FMatrixFunction[3, 3, 4, 4] = {{1/Sqrt[2], I/Sqrt[2]}, 
    {I/Sqrt[2], 1/Sqrt[2]}}
 
SOlevel23Cat2FMatrixFunction[3, 4, 1, 2] = {{-I}}
 
SOlevel23Cat2FMatrixFunction[3, 4, 1, 3] = {{I}}
 
SOlevel23Cat2FMatrixFunction[3, 4, 2, 0] = {{I}}
 
SOlevel23Cat2FMatrixFunction[3, 4, 2, 1] = {{-1}}
 
SOlevel23Cat2FMatrixFunction[3, 4, 2, 4] = {{-Sqrt[3]/2, 1/2}, 
    {-1/2, -Sqrt[3]/2}}
 
SOlevel23Cat2FMatrixFunction[3, 4, 3, 0] = {{-I}}
 
SOlevel23Cat2FMatrixFunction[3, 4, 3, 1] = {{-1}}
 
SOlevel23Cat2FMatrixFunction[3, 4, 3, 4] = {{I/2, (I/2)*Sqrt[3]}, 
    {(-I/2)*Sqrt[3], I/2}}
 
SOlevel23Cat2FMatrixFunction[3, 4, 4, 2] = {{(-I)/Sqrt[2], 1/Sqrt[2]}, 
    {(-I)/Sqrt[2], -(1/Sqrt[2])}}
 
SOlevel23Cat2FMatrixFunction[3, 4, 4, 3] = {{1/Sqrt[2], I/Sqrt[2]}, 
    {I/Sqrt[2], 1/Sqrt[2]}}
 
SOlevel23Cat2FMatrixFunction[4, 1, 4, 0] = {{-1}}
 
SOlevel23Cat2FMatrixFunction[4, 1, 4, 1] = {{-1}}
 
SOlevel23Cat2FMatrixFunction[4, 2, 1, 2] = {{-I}}
 
SOlevel23Cat2FMatrixFunction[4, 2, 1, 3] = {{I}}
 
SOlevel23Cat2FMatrixFunction[4, 2, 2, 0] = {{I}}
 
SOlevel23Cat2FMatrixFunction[4, 2, 2, 4] = {{1/Sqrt[2], (-I)/Sqrt[2]}, 
    {-(1/Sqrt[2]), (-I)/Sqrt[2]}}
 
SOlevel23Cat2FMatrixFunction[4, 2, 3, 0] = {{I}}
 
SOlevel23Cat2FMatrixFunction[4, 2, 3, 1] = {{-1}}
 
SOlevel23Cat2FMatrixFunction[4, 2, 3, 4] = {{I/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], I/Sqrt[2]}}
 
SOlevel23Cat2FMatrixFunction[4, 2, 4, 2] = {{-1/2, -Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
SOlevel23Cat2FMatrixFunction[4, 2, 4, 3] = {{(-I/2)*Sqrt[3], I/2}, 
    {-I/2, (-I/2)*Sqrt[3]}}
 
SOlevel23Cat2FMatrixFunction[4, 3, 1, 2] = {{-I}}
 
SOlevel23Cat2FMatrixFunction[4, 3, 1, 3] = {{I}}
 
SOlevel23Cat2FMatrixFunction[4, 3, 2, 0] = {{-I}}
 
SOlevel23Cat2FMatrixFunction[4, 3, 2, 1] = {{-1}}
 
SOlevel23Cat2FMatrixFunction[4, 3, 2, 4] = {{1/Sqrt[2], (-I)/Sqrt[2]}, 
    {-(1/Sqrt[2]), (-I)/Sqrt[2]}}
 
SOlevel23Cat2FMatrixFunction[4, 3, 3, 0] = {{-I}}
 
SOlevel23Cat2FMatrixFunction[4, 3, 3, 4] = {{I/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], I/Sqrt[2]}}
 
SOlevel23Cat2FMatrixFunction[4, 3, 4, 2] = {{(-I/2)*Sqrt[3], I/2}, 
    {-I/2, (-I/2)*Sqrt[3]}}
 
SOlevel23Cat2FMatrixFunction[4, 3, 4, 3] = {{-1/2, -Sqrt[3]/2}, 
    {Sqrt[3]/2, -1/2}}
 
SOlevel23Cat2FMatrixFunction[4, 4, 1, 0] = {{-1}}
 
SOlevel23Cat2FMatrixFunction[4, 4, 1, 1] = {{-1}}
 
SOlevel23Cat2FMatrixFunction[4, 4, 1, 4] = {{-1}}
 
SOlevel23Cat2FMatrixFunction[4, 4, 2, 2] = {{(-I)/Sqrt[2], -(1/Sqrt[2])}, 
    {-(1/Sqrt[2]), (-I)/Sqrt[2]}}
 
SOlevel23Cat2FMatrixFunction[4, 4, 2, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {(-I)/Sqrt[2], I/Sqrt[2]}}
 
SOlevel23Cat2FMatrixFunction[4, 4, 3, 2] = {{I/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], I/Sqrt[2]}}
 
SOlevel23Cat2FMatrixFunction[4, 4, 3, 3] = {{-(1/Sqrt[2]), -(1/Sqrt[2])}, 
    {I/Sqrt[2], (-I)/Sqrt[2]}}
 
SOlevel23Cat2FMatrixFunction[4, 4, 4, 1] = {{-1}}
 
SOlevel23Cat2FMatrixFunction[4, 4, 4, 4] = {{1/2, 1/2, I/Sqrt[2]}, 
    {-1/2, -1/2, I/Sqrt[2]}, {(-I)/Sqrt[2], I/Sqrt[2], 0}}
 
SOlevel23Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SOlevel23Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
SOlevel23Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[SOlevel23Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[SOlevel23Cat2Piv1] ^= {SOlevel23Cat2Bal1, 
    SOlevel23Cat2Bal3, SOlevel23Cat2Bal5, SOlevel23Cat2Bal7}
 
SOlevel23Cat2Piv1 /: balancedCategory[SOlevel23Cat2Piv1, 1] = 
    SOlevel23Cat2Bal1
 
SOlevel23Cat2Piv1 /: balancedCategory[SOlevel23Cat2Piv1, 2] = 
    SOlevel23Cat2Bal3
 
SOlevel23Cat2Piv1 /: balancedCategory[SOlevel23Cat2Piv1, 3] = 
    SOlevel23Cat2Bal5
 
SOlevel23Cat2Piv1 /: balancedCategory[SOlevel23Cat2Piv1, 4] = 
    SOlevel23Cat2Bal7
 
fusionCategory[SOlevel23Cat2Piv1] ^= SOlevel23Cat2
 
SOlevel23Cat2Piv1 /: modularCategory[SOlevel23Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SOlevel23Cat2Piv1] ^= SOlevel23Cat2Piv1
 
pivotalIsomorphism[SOlevel23Cat2Piv1] ^= SOlevel23Cat2Piv1PivotalIsomorphism
 
SOlevel23Cat2Piv1 /: ribbonCategory[SOlevel23Cat2Piv1, 1] = SOlevel23Cat2Bal1
 
SOlevel23Cat2Piv1 /: ribbonCategory[SOlevel23Cat2Piv1, 2] = SOlevel23Cat2Bal3
 
SOlevel23Cat2Piv1 /: ribbonCategory[SOlevel23Cat2Piv1, 3] = SOlevel23Cat2Bal5
 
SOlevel23Cat2Piv1 /: ribbonCategory[SOlevel23Cat2Piv1, 4] = SOlevel23Cat2Bal7
 
ring[SOlevel23Cat2Piv1] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat2Piv1] ^= SOlevel23Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[SOlevel23Cat2]][pivotalCategory[#1]] & )[
    SOlevel23Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[SOlevel23Cat2]][
      sphericalCategory[#1]] & )[SOlevel23Cat2Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[SOlevel23Cat2Piv1PivotalIsomorphism] ^= SOlevel23Cat2
 
pivotalCategory[SOlevel23Cat2Piv1PivotalIsomorphism] ^= SOlevel23Cat2Piv1
 
pivotalIsomorphism[SOlevel23Cat2Piv1PivotalIsomorphism] ^= 
   SOlevel23Cat2Piv1PivotalIsomorphism
 
SOlevel23Cat2Piv1PivotalIsomorphism[0] = 1
 
SOlevel23Cat2Piv1PivotalIsomorphism[1] = 1
 
SOlevel23Cat2Piv1PivotalIsomorphism[2] = 1
 
SOlevel23Cat2Piv1PivotalIsomorphism[3] = 1
 
SOlevel23Cat2Piv1PivotalIsomorphism[4] = 1
balancedCategories[SOlevel23Cat2Piv2] ^= {SOlevel23Cat2Bal2, 
    SOlevel23Cat2Bal4, SOlevel23Cat2Bal6, SOlevel23Cat2Bal8}
 
SOlevel23Cat2Piv2 /: balancedCategory[SOlevel23Cat2Piv2, 1] = 
    SOlevel23Cat2Bal2
 
SOlevel23Cat2Piv2 /: balancedCategory[SOlevel23Cat2Piv2, 2] = 
    SOlevel23Cat2Bal4
 
SOlevel23Cat2Piv2 /: balancedCategory[SOlevel23Cat2Piv2, 3] = 
    SOlevel23Cat2Bal6
 
SOlevel23Cat2Piv2 /: balancedCategory[SOlevel23Cat2Piv2, 4] = 
    SOlevel23Cat2Bal8
 
fusionCategory[SOlevel23Cat2Piv2] ^= SOlevel23Cat2
 
SOlevel23Cat2Piv2 /: modularCategory[SOlevel23Cat2Piv2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[SOlevel23Cat2Piv2] ^= SOlevel23Cat2Piv2
 
pivotalIsomorphism[SOlevel23Cat2Piv2] ^= SOlevel23Cat2Piv2PivotalIsomorphism
 
SOlevel23Cat2Piv2 /: ribbonCategory[SOlevel23Cat2Piv2, 1] = SOlevel23Cat2Bal2
 
SOlevel23Cat2Piv2 /: ribbonCategory[SOlevel23Cat2Piv2, 2] = SOlevel23Cat2Bal4
 
SOlevel23Cat2Piv2 /: ribbonCategory[SOlevel23Cat2Piv2, 3] = SOlevel23Cat2Bal6
 
SOlevel23Cat2Piv2 /: ribbonCategory[SOlevel23Cat2Piv2, 4] = SOlevel23Cat2Bal8
 
ring[SOlevel23Cat2Piv2] ^= SOlevel23
 
sphericalCategory[SOlevel23Cat2Piv2] ^= SOlevel23Cat2Piv2
 
(pivotalCategoryIndex[fusionCategory[SOlevel23Cat2]][pivotalCategory[#1]] & )[
    SOlevel23Cat2Piv2] ^= 2
 
(sphericalCategoryIndex[fusionCategory[SOlevel23Cat2]][
      sphericalCategory[#1]] & )[SOlevel23Cat2Piv2] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[SOlevel23Cat2Piv2PivotalIsomorphism] ^= SOlevel23Cat2
 
pivotalCategory[SOlevel23Cat2Piv2PivotalIsomorphism] ^= SOlevel23Cat2Piv2
 
pivotalIsomorphism[SOlevel23Cat2Piv2PivotalIsomorphism] ^= 
   SOlevel23Cat2Piv2PivotalIsomorphism
 
SOlevel23Cat2Piv2PivotalIsomorphism[0] = 1
 
SOlevel23Cat2Piv2PivotalIsomorphism[1] = 1
 
SOlevel23Cat2Piv2PivotalIsomorphism[2] = -1
 
SOlevel23Cat2Piv2PivotalIsomorphism[3] = -1
 
SOlevel23Cat2Piv2PivotalIsomorphism[4] = 1
ring[SOlevel23NFunction] ^= SOlevel23
 
SOlevel23NFunction[0, 0, 0] = 1
 
SOlevel23NFunction[0, 0, 1] = 0
 
SOlevel23NFunction[0, 0, 2] = 0
 
SOlevel23NFunction[0, 0, 3] = 0
 
SOlevel23NFunction[0, 0, 4] = 0
 
SOlevel23NFunction[0, 1, 0] = 0
 
SOlevel23NFunction[0, 1, 1] = 1
 
SOlevel23NFunction[0, 1, 2] = 0
 
SOlevel23NFunction[0, 1, 3] = 0
 
SOlevel23NFunction[0, 1, 4] = 0
 
SOlevel23NFunction[0, 2, 0] = 0
 
SOlevel23NFunction[0, 2, 1] = 0
 
SOlevel23NFunction[0, 2, 2] = 1
 
SOlevel23NFunction[0, 2, 3] = 0
 
SOlevel23NFunction[0, 2, 4] = 0
 
SOlevel23NFunction[0, 3, 0] = 0
 
SOlevel23NFunction[0, 3, 1] = 0
 
SOlevel23NFunction[0, 3, 2] = 0
 
SOlevel23NFunction[0, 3, 3] = 1
 
SOlevel23NFunction[0, 3, 4] = 0
 
SOlevel23NFunction[0, 4, 0] = 0
 
SOlevel23NFunction[0, 4, 1] = 0
 
SOlevel23NFunction[0, 4, 2] = 0
 
SOlevel23NFunction[0, 4, 3] = 0
 
SOlevel23NFunction[0, 4, 4] = 1
 
SOlevel23NFunction[1, 0, 0] = 0
 
SOlevel23NFunction[1, 0, 1] = 1
 
SOlevel23NFunction[1, 0, 2] = 0
 
SOlevel23NFunction[1, 0, 3] = 0
 
SOlevel23NFunction[1, 0, 4] = 0
 
SOlevel23NFunction[1, 1, 0] = 1
 
SOlevel23NFunction[1, 1, 1] = 0
 
SOlevel23NFunction[1, 1, 2] = 0
 
SOlevel23NFunction[1, 1, 3] = 0
 
SOlevel23NFunction[1, 1, 4] = 0
 
SOlevel23NFunction[1, 2, 0] = 0
 
SOlevel23NFunction[1, 2, 1] = 0
 
SOlevel23NFunction[1, 2, 2] = 0
 
SOlevel23NFunction[1, 2, 3] = 1
 
SOlevel23NFunction[1, 2, 4] = 0
 
SOlevel23NFunction[1, 3, 0] = 0
 
SOlevel23NFunction[1, 3, 1] = 0
 
SOlevel23NFunction[1, 3, 2] = 1
 
SOlevel23NFunction[1, 3, 3] = 0
 
SOlevel23NFunction[1, 3, 4] = 0
 
SOlevel23NFunction[1, 4, 0] = 0
 
SOlevel23NFunction[1, 4, 1] = 0
 
SOlevel23NFunction[1, 4, 2] = 0
 
SOlevel23NFunction[1, 4, 3] = 0
 
SOlevel23NFunction[1, 4, 4] = 1
 
SOlevel23NFunction[2, 0, 0] = 0
 
SOlevel23NFunction[2, 0, 1] = 0
 
SOlevel23NFunction[2, 0, 2] = 1
 
SOlevel23NFunction[2, 0, 3] = 0
 
SOlevel23NFunction[2, 0, 4] = 0
 
SOlevel23NFunction[2, 1, 0] = 0
 
SOlevel23NFunction[2, 1, 1] = 0
 
SOlevel23NFunction[2, 1, 2] = 0
 
SOlevel23NFunction[2, 1, 3] = 1
 
SOlevel23NFunction[2, 1, 4] = 0
 
SOlevel23NFunction[2, 2, 0] = 1
 
SOlevel23NFunction[2, 2, 1] = 0
 
SOlevel23NFunction[2, 2, 2] = 0
 
SOlevel23NFunction[2, 2, 3] = 0
 
SOlevel23NFunction[2, 2, 4] = 1
 
SOlevel23NFunction[2, 3, 0] = 0
 
SOlevel23NFunction[2, 3, 1] = 1
 
SOlevel23NFunction[2, 3, 2] = 0
 
SOlevel23NFunction[2, 3, 3] = 0
 
SOlevel23NFunction[2, 3, 4] = 1
 
SOlevel23NFunction[2, 4, 0] = 0
 
SOlevel23NFunction[2, 4, 1] = 0
 
SOlevel23NFunction[2, 4, 2] = 1
 
SOlevel23NFunction[2, 4, 3] = 1
 
SOlevel23NFunction[2, 4, 4] = 0
 
SOlevel23NFunction[3, 0, 0] = 0
 
SOlevel23NFunction[3, 0, 1] = 0
 
SOlevel23NFunction[3, 0, 2] = 0
 
SOlevel23NFunction[3, 0, 3] = 1
 
SOlevel23NFunction[3, 0, 4] = 0
 
SOlevel23NFunction[3, 1, 0] = 0
 
SOlevel23NFunction[3, 1, 1] = 0
 
SOlevel23NFunction[3, 1, 2] = 1
 
SOlevel23NFunction[3, 1, 3] = 0
 
SOlevel23NFunction[3, 1, 4] = 0
 
SOlevel23NFunction[3, 2, 0] = 0
 
SOlevel23NFunction[3, 2, 1] = 1
 
SOlevel23NFunction[3, 2, 2] = 0
 
SOlevel23NFunction[3, 2, 3] = 0
 
SOlevel23NFunction[3, 2, 4] = 1
 
SOlevel23NFunction[3, 3, 0] = 1
 
SOlevel23NFunction[3, 3, 1] = 0
 
SOlevel23NFunction[3, 3, 2] = 0
 
SOlevel23NFunction[3, 3, 3] = 0
 
SOlevel23NFunction[3, 3, 4] = 1
 
SOlevel23NFunction[3, 4, 0] = 0
 
SOlevel23NFunction[3, 4, 1] = 0
 
SOlevel23NFunction[3, 4, 2] = 1
 
SOlevel23NFunction[3, 4, 3] = 1
 
SOlevel23NFunction[3, 4, 4] = 0
 
SOlevel23NFunction[4, 0, 0] = 0
 
SOlevel23NFunction[4, 0, 1] = 0
 
SOlevel23NFunction[4, 0, 2] = 0
 
SOlevel23NFunction[4, 0, 3] = 0
 
SOlevel23NFunction[4, 0, 4] = 1
 
SOlevel23NFunction[4, 1, 0] = 0
 
SOlevel23NFunction[4, 1, 1] = 0
 
SOlevel23NFunction[4, 1, 2] = 0
 
SOlevel23NFunction[4, 1, 3] = 0
 
SOlevel23NFunction[4, 1, 4] = 1
 
SOlevel23NFunction[4, 2, 0] = 0
 
SOlevel23NFunction[4, 2, 1] = 0
 
SOlevel23NFunction[4, 2, 2] = 1
 
SOlevel23NFunction[4, 2, 3] = 1
 
SOlevel23NFunction[4, 2, 4] = 0
 
SOlevel23NFunction[4, 3, 0] = 0
 
SOlevel23NFunction[4, 3, 1] = 0
 
SOlevel23NFunction[4, 3, 2] = 1
 
SOlevel23NFunction[4, 3, 3] = 1
 
SOlevel23NFunction[4, 3, 4] = 0
 
SOlevel23NFunction[4, 4, 0] = 1
 
SOlevel23NFunction[4, 4, 1] = 1
 
SOlevel23NFunction[4, 4, 2] = 0
 
SOlevel23NFunction[4, 4, 3] = 0
 
SOlevel23NFunction[4, 4, 4] = 1
 
SOlevel23NFunction[FusionCategories`Data`SOlevel23`Private`a_, FusionCategories`Data`SOlevel23`Private`b_, FusionCategories`Data`SOlevel23`Private`c_] := 0


 EndPackage[]
