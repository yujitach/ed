BeginPackage["FusionCategories`Data`soOddLevel2`", {"FusionCategories`","FusionCategories`PivotalCategories`", "FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}]

(* Grothendieck Ring Information *)

ring[soOddLevel2[p_Integer]] ^:= soOddLevel2[p]

rank[soOddLevel2[p_Integer]] ^:= p + 4

noMultiplicities[soOddLevel2[p_Integer]] ^:= True

nFunction[soOddLevel2[p_Integer]] ^:= gRing[p]

ring[gRing[p]] ^:= soOddLevel2[p]

ring[nFunction[soOddLevel2[p_Integer]]] ^:= soOddLevel2[p]

ringAutomorphisms[soOddLevel2[p_Integer]]^:=GroupElements[PermutationGroup[Append[Module[{i},Cycles[#]&/@((#[[1]] & /@ gxAutomorphisms[p]) + 4)], Cycles[{{3,4}}]]]]

(* Fusion Category Information *)

fusionCategories[soOddLevel2[p_Integer]] ^:= Join[Table[soOddLevel2Cat[p,r,1],{r, roots[p]}],Table[soOddLevel2Cat[p,r,-1],{r,roots[p]}]]

fusionCategory[soOddLevel2Cat[p_Integer, r_Integer, k_Integer]] /;( MemberQ[roots[p], r] && ( k==1 || k==-1 )) ^:= soOddLevel2Cat[p,r,k]

fusionCategory[soOddLevel2[p_Integer], i_Integer] /;(1<= i <= Length[fusionCategories[soOddLevel2[p]]]) := fusionCategories[soOddLevel2[p]][[i]]

ring[soOddLevel2Cat[p_Integer, r_Integer, k_Integer]] /;( MemberQ[roots[p], r] && ( k==1 || k==-1 )) ^:= soOddLevel2[p]

fMatrixFunction[soOddLevel2Cat[p_Integer, r_Integer, k_Integer]] /;( MemberQ[roots[p], r] && ( k==1 || k==-1 )) ^:= fMat[p,r,k]

fMatrixFunction[fMat[p_Integer, r_Integer, k_Integer, {#1, #2, #3, #4}] &] := fMat[p, r, k, {#1, #2, #3, #4}] &

ring[fMat[p_Integer, r_Integer, k_Integer]] := soOddLevel2[p]

ring[fMat[p_Integer, r_Integer, k_Integer, {#1, #2, #3, #4}] &] := soOddLevel2[p]

ring[fMat[p_Integer, r_Integer, k_Integer, {a_, b_, c_, d_}]] := soOddLevel2[p]

ring[fMatrixFunction[soOddLevel2Cat[p_Integer, r_Integer, k_Integer]]] /; ( MemberQ[roots[p], r] && ( k==1 || k==-1 )) ^:= soOddLevel2[p]

eval[soOddLevel2Cat[p_Integer, r_Integer, k_Integer]]^=FusionCategories`Private`defaultGaugeEval

coeval[soOddLevel2Cat[p_Integer, r_Integer, k_Integer]] ^:= 1/sixJFunction[soOddLevel2Cat[p,r,k]][#1, #1, #1, #1, 0, 0] &

ringAutomorphisms[soOddLevel2Cat[p_Integer,r_Integer,k_Integer]]^:=ringAutomorphisms[soOddLevel2[p]]

(* Pivotal Category Information *)

pivotalCategories[soOddLevel2Cat[p_Integer, r_Integer, k_Integer]] ^:= {soOddLevel2Piv[p,r,k,1], soOddLevel2Piv[p,r,k,-1]}

pivotalCategory[soOddLevel2Piv[p_Integer, r_Integer, k_Integer, z_Integer]]/;(z==1||z==-1) ^:= soOddLevel2Piv[p,r,k,z]

pivotalCategory[soOddLevel2Cat[p_Integer, r_Integer, k_Integer], z_Integer]/;(z==1||z==-1) := soOddLevel2Piv[p,r,k,z] 
pivotalCategory[soOddLevel2Cat[p_Integer, r_Integer, k_Integer], 2] := soOddLevel2Piv[p,r,k,-1] 

pivotalCategoryIndex[soOddLevel2Piv[p_Integer, r_Integer, k_Integer, 1]] ^:= 1
pivotalCategoryIndex[soOddLevel2Piv[p_Integer, r_Integer, k_Integer, -1]] ^:= 2

fusionCategory[soOddLevel2Piv[p_Integer, r_Integer, k_Integer, z_Integer]]/;(z==1||z==-1) ^:= soOddLevel2Cat[p,r,k]

pivotalIsomorphism[soOddLevel2Piv[p_Integer, r_Integer, k_Integer, z_Integer]] ^:= soOddLevel2PivotalIsomorphism[p,r,k,z]

soOddLevel2PivotalIsomorphism[p_Integer, r_Integer, k_Integer, z_Integer][x_?pointedQ] := 1

soOddLevel2PivotalIsomorphism[p_Integer, r_Integer, k_Integer, z_Integer][x_]/; (vectorQ[p,x]) := 1

soOddLevel2PivotalIsomorphism[p_Integer, r_Integer, k_Integer, z_Integer][x_?spinorQ] := z

ringAutomorphisms[soOddLevel2Piv[p_Integer,r_Integer,k_Integer,z_Integer]]^:=ringAutomorphisms[soOddLevel2[p]]

(* Braided Category Information *)

braidedCategories[soOddLevel2Cat[p_Integer, r_Integer, k_Integer]] ^:= {soOddLevel2Brd[p,r,k,1], soOddLevel2Brd[p,r,k,-1]}

braidedCategory[soOddLevel2Brd[p_Integer, r_Integer, k_Integer,l_Integer]]/;(l==1||l==-1) ^:= soOddLevel2Brd[p,r,k,l]

braidedCategory[soOddLevel2Cat[p_Integer, r_Integer, k_Integer], l_Integer]/;(l==1||l==-1) := soOddLevel2Brd[p,r,k,l]
braidedCategory[soOddLevel2Cat[p_Integer, r_Integer, k_Integer],2] := soOddLevel2Brd[p,r,k,-1]

braidedCategoryIndex[soOddLevel2Brd[p_Integer, r_Integer, k_Integer, 1]] ^:= 1
braidedCategoryIndex[soOddLevel2Brd[p_Integer, r_Integer, k_Integer, -1]] ^:= 2

fusionCategory[soOddLevel2Brd[p_Integer, r_Integer, k_Integer,l_Integer]]/;(l==1||l==-1) ^:= soOddLevel2Cat[p,r,k]

rMatrixFunction[soOddLevel2Brd[p_Integer, r_Integer, k_Integer,l_Integer]]/;(l==1||l==-1) ^:= rMat[p,r,k,l]

ringAutomorphisms[soOddLevel2Brd[p_Integer,r_Integer,k_Integer,l_Integer]]^:=ringAutomorphisms[soOddLevel2[p]]

(* Balanced Category Information *)

balancedCategories[soOddLevel2Cat[p_Integer, r_Integer, k_Integer]] ^:= {soOddLevel2Bal[p,r,k,1,1], soOddLevel2Bal[p,r,k,1,-1], soOddLevel2Bal[p,r,k,-1,1], soOddLevel2Bal[p,r,k,-1,-1]}
balancedCategories[soOddLevel2Brd[p_Integer, r_Integer, k_Integer, l_Integer]]/;(l==1||l==-1) ^:= {soOddLevel2Bal[p,r,k,l,1], soOddLevel2Bal[p,r,k,l,-1]}
balancedCategories[soOddLevel2Piv[p_Integer, r_Integer, k_Integer, z_Integer]]/;(z==1||z==-1) ^:= {soOddLevel2Bal[p,r,k,1,z], soOddLevel2Bal[p,r,k,-1,z]}

balancedCategory[soOddLevel2Bal[p_Integer, r_Integer, k_Integer, l_Integer, z_Integer]]/;((l==1||l==-1)&&(z==1||z==-1)) ^:= soOddLevel2Bal[p,r,k,l,z]

balancedCategory[soOddLevel2Piv[p_Integer, r_Integer, k_Integer, z_Integer], l_]/;((l==1||l==-1)&&(z==1||z==-1)) ^:= soOddLevel2Bal[p,r,k,l,z]
balancedCategory[soOddLevel2Piv[p_Integer, r_Integer, k_Integer, z_Integer], 2]/;(z==1||z==-1) := soOddLevel2Bal[p,r,k,-1,z]

balancedCategory[soOddLevel2Brd[p_Integer, r_Integer, k_Integer, l_Integer], z_]/;((l==1||l==-1)&&(z==1||z==-1)) ^:= soOddLevel2Bal[p,r,k,l,z]
balancedCategory[soOddLevel2Brd[p_Integer, r_Integer, k_Integer, l_Integer], 2]/;(l==1||l==-1) := soOddLevel2Bal[p,r,k,l,-1]

balancedCategory[soOddLevel2Cat[p_Integer, r_Integer, k_Integer], l_, z_]/;((l==1||l==-1)&&(z==1||z==-1)) := soOddLevel2Bal[p,r,k,l,z]
balancedCategory[soOddLevel2Cat[p_Integer, r_Integer, k_Integer], 2, z_]/;(z==1||z==-1) := soOddLevel2Bal[p,r,k,-1,z]
balancedCategory[soOddLevel2Cat[p_Integer, r_Integer, k_Integer], l_, 2]/;(l==1||l==-1) := soOddLevel2Bal[p,r,k,l,-1]
balancedCategory[soOddLevel2Cat[p_Integer, r_Integer, k_Integer], 2, 2] := soOddLevel2Bal[p,r,k,-1,-1]

fusionCategory[soOddLevel2Bal[p_Integer, r_Integer, k_Integer, l_Integer, z_Integer]]/;((l==1||l==-1)&&(z==1||z==-1)) ^:= soOddLevel2Cat[p,r,k]
braidedCategory[soOddLevel2Bal[p_Integer, r_Integer, k_Integer, l_Integer, z_Integer]]/;((l==1||l==-1)&&(z==1||z==-1)) ^:= soOddLevel2Brd[p,r,k,l]
pivotalCategory[soOddLevel2Bal[p_Integer, r_Integer, k_Integer, l_Integer, z_Integer]]/;((l==1||l==-1)&&(z==1||z==-1)) ^:= soOddLevel2Piv[p,r,k,z]

ringAutomorphisms[soOddLevel2Bal[p_Integer,r_Integer,k_Integer,l_Integer,z_Integer]]^:=ringAutomorphisms[soOddLevel2[p]]
(* *************************** Generic functions for soOddLevel2 stuff *************************** *)

roots[p_] := Select[Range[2 p + 1], OddQ[#] && GCD[#, 2 p + 1] == 1 &]

(* ***** Grothendieck ring stuff ***** *)
zp[p_Integer, a_Integer] :=  Select[Range[-p, p], Mod[a, 2 p + 1] == Mod[#, 2 p + 1] &][[1]]
zpElements[p_, i_] := DeleteDuplicates[Table[zp[p, i j], {j, -p, p}]]
zpElements[p_] := zpElements[p, 1]
zpxElements[p_, i_] := Select[zpElements[p, i], GCD[#, 2 p + 1] == 1 &]
zpxElements[p_] := zpxElements[p, 1]

g[p_Integer, a_Integer] := Abs[zp[p, a]]
gxElements[p_, i_] := DeleteDuplicates[Table[g[p, i j], {j, Union[Abs[zpxElements[p]]]}]]
gxElements[p_] := gxElements[p, 1]

gxAction[p_, i_] /; (MemberQ[gxElements[p], i]) := Table[g[p, i j], {j, 1, p}]
gxAutomorphism[p_, i_] /; (MemberQ[gxElements[p], i]) := FindPermutation[gxAction[p, 1], gxAction[p, i]]
gxAutomorphisms[p_] := Union[Flatten[Table[gxAutomorphism[p, i], {i, gxElements[p]}]]]

gTab[p_Integer, a_Integer, b_Integer] :=  If[a == b, {g[p, a + a]}, {g[p, a - b], g[p, a + b]}]
gTab[p_Integer] := Table[gTab[p, a, b], {a, Range[p]}, {b, Range[p]}]

pointedQ[x_] := ((x == 0) || (x == 1))
spinorQ[x_] := ((x == 2) || (x == 3))
vectorQ[p_, x_] := ((x > 3) && x < p + 4)

gRing[p_Integer] := gRing[p, #1, #2, #3] &
gRing[p_Integer, {a_, b_, c_}] := gRing[p, a, b, c]
gRing[p_Integer, a_, b_, c_] := 0
gRing[p_Integer, a_, b_, c_] /; ((a < p + 4 && b < p + 4 && c < p + 4)&&((a == 0 && b == c) || (b == 0 && a == c) || (c == 0 && a == b))) := 1
gRing[p_Integer, 1, b_?spinorQ, c_?spinorQ] := Abs[KroneckerDelta[b, c] - 1]
gRing[p_Integer, 1, b_, c_] /; (vectorQ[p, b] && vectorQ[p, c]) :=  KroneckerDelta[b, c]
gRing[p_Integer, a_?(! pointedQ[#] &), 1, c_?(! pointedQ[#] &)] :=  gRing[p, 1, a, c]
gRing[p_Integer, a_?(! pointedQ[#] &), b_?(! pointedQ[#] &), 1] :=  gRing[p, 1, a, b]
gRing[p_Integer, a_?spinorQ, b_?spinorQ, c_] /; vectorQ[p, c] := 1
gRing[p_Integer, a_?spinorQ, b_, c_?spinorQ] /; vectorQ[p, b] := 1
gRing[p_Integer, a_, b_?spinorQ, c_?spinorQ] /; vectorQ[p, a] := 1
gRing[p_Integer, a_, b_, c_] /; (vectorQ[p, a] && vectorQ[p, b] && vectorQ[p, c]) :=  Module[{a0 = a - 3, b0 = b - 3, c0 = c - 3},  If[KroneckerDelta[g[p, a0 + b0], c0] == 1, KroneckerDelta[g[p, a0 + b0], c0], KroneckerDelta[g[p, a0 - b0], c0]]]

(* ***** Fusion Category stuff ***** *)
q[p_Integer] := Exp[(\[Pi] I)/(2 p + 1)]

realQ[x_] := Element[x, Reals]

parameterCondition[w_, x_, y_, z_] := (realQ[w] && realQ[x] && realQ[y] && realQ[z] && (Abs[w] == 1) && (Abs[x] == 1) && (Abs[y] == 1) && (Abs[z] == 1) && (w x y z == -1))

zeta[0, 0] := 0
zeta[0, j_?(# > 0 &)] := 1/2
zeta[i_?(# > 0 &), 0] := 1/2
zeta[i_?(# > 0 &), j_?(# > 0 &)] := 1

vec[x_] := x - 3

XSet[soOddLevel2Cat[p_Integer, r_Integer, k_Integer], perm_Cycles] := Module[{soo = soOddLevel2Cat[p, r, k], i}, Table[Sqrt[2 p + 1]/2^zeta[i, i] (-1)^i^2 Re[J[p, r, k, i, i]], {i, Permute[Range[0, p], perm]}]]
XSet[soOddLevel2Cat[p_Integer, r_Integer, k_Integer]] := XSet[soOddLevel2Cat[p, r, k], Cycles[{{}}]]

XSets[p_Integer] := Join[{{p, #, 1}, XSet[soOddLevel2Cat[p, #, 1]]} & /@ roots[p], {{p, #, -1}, XSet[soOddLevel2Cat[p, #, -1]]} & /@ roots[p]]
XSets[soOddLevel2[p_Integer]] := XSets[p]

monoidalEquivalentQ[soOddLevel2Cat[p1_Integer, r1_Integer, k1_Integer], soOddLevel2Cat[p2_Integer, r2_Integer, k2_Integer]] ^:= Module[{perm, X1 = XSet[soOddLevel2Cat[p1, r1, k1]], X2 = XSet[soOddLevel2Cat[p2, r2, k2]]}, If[((p1 == p2) && (k1 == k2) && MemberQ[roots[p1], r1] && MemberQ[roots[p2], r2] && (Union[X1] === Union[X2])), perm = Cycles[FindPermutation[X1, X2][[1]] + 3]; If[perm === {}, False, MemberQ[ringAutomorphisms[soOddLevel2[p1]], perm], False], False]]

equivalentRoots[p_Integer] := Gather[roots[p], monoidalEquivalentQ[soOddLevel2Cat[p, #1, 1], soOddLevel2Cat[p, #2, 1]] &]

(* General Matrices *)
AMatrix[w_, x_, y_, z_] /; parameterCondition[w, x, y, z] := 1/Sqrt[2] ( {{w, x}, {y, z}} )
BMatrix := PauliMatrix[1];
CMatrix := 1/2 ( {{1, -1, Sqrt[2]}, {-1, 1, Sqrt[2]}, {Sqrt[2], Sqrt[2], 0}} )
DMatrix[p_, r_, t_, w_, x_, y_, z_] /; parameterCondition[w, x, y, z] := ( {{w Re[q[p]^(r t)], x Im[q[p]^(r t)]}, {y Im[q[p]^(r t)], z Re[q[p]^(r t)]}} )
EMatrix[p_, r_, t_, w_, x_, y_, z_] /; parameterCondition[w, x, y, z] := ( {{w Im[q[p]^(r t)], x Re[q[p]^(r t)]}, {y Re[q[p]^(r t)], z Im[q[p]^(r t)]}} )

J[p_, r_, k_, i_, j_] := (2^zeta[i, j] k)/Sqrt[2 p + 1] (q[p]^r)^(i j)

GMatrix[p_, r_, k_] := Table[(-1)^((i - 1) (j - 1)) Im[J[p, r, k, i, j]], {i, 1, p}, {j, 1, p}]
HMatrix[p_, r_, k_] := Table[(-1)^(i j) Re[J[p, r, k, i, j]], {i, 0, p}, {j, 0, p}]
HPMatrix[p_, r_, k_] := Module[{hm = HMatrix[p, r, k]}, Table[(-1)^(2 zeta[i, j] - 1) hm[[i + 1, j + 1]], {i, 0, p}, {j, 0, p}]]

(* Patterns *)

(* epsilon-vector-vector-vector *)
evvv[p_, {a_, b_, c_, d_}] := If[a == 1, evvv[p, b, c, d], Transpose[evvv[p, Permute[{a, b, c, d}, Cycles[{{1, 2, 3, 4}}]]]]]

evvv[p_, b_, c_, d_] /; (c <= b) := {{(-1)^Mod[vec[c], 2]}}
evvv[p_, b_, c_, d_] /; (c > b && d == (g[p, b + c - 6] + 3)) := {{(-1)^Mod[vec[c], 2]}}
evvv[p_, b_, c_, d_] /; (c > b && d == (g[p, b - c] + 3)) := {{(-1)^Mod[vec[c] - 1, 2]}}

(* epsilon-spinor-spinor-vector *)
essv[p_, {a_, b_, c_, d_}] := If[a == 1, essv[p, a, b, c, d], Transpose[essv[p, Permute[{a, b, c, d}, Cycles[{{1, 2, 3, 4}}]]]]]

essv[p_, a_, b_, c_, d_] := {{1}}
essv[p_, a_, b_?spinorQ, c_, d_?spinorQ] /; (b != d) := {{-1}}

(* vector-vector-vector-vector *)
vvvv[p_, {a_, b_, c_, d_}] := vvvv[p, a, b, c, d]

vvvv[p_, a_, b_, c_, d_] := {{1}}
vvvv[p_, a_, b_, c_, d_] /; (a == b && a == c && a == d) := CMatrix
vvvv[p_, a_, b_, c_, d_] /; (a == c && b == d && a != b) := BMatrix
vvvv[p_, a_, b_, c_, d_] /; ((a == b && c == d) && b != d) := Transpose[AMatrix[1, 1, (-1)^Mod[vec[b] - vec[d] + 1 , 2], (-1)^Mod[vec[b] - vec[d], 2]]]
vvvv[p_, a_, b_, c_, d_] /; ((a == d && b == c) && b != d) := AMatrix[1, 1, (-1)^Mod[vec[b] - vec[d] + 1 , 2], (-1)^Mod[vec[b] - vec[d], 2]]

(* vector-vector-spinor-spinor *)

(* Utility *)
vvss[p_, r_, {a_, b_, c_, d_}] := If[vectorQ[p, a] && vectorQ[p, b], vvss[p, r, a, b, c, d], Transpose[vvss[p, r, Permute[{a, b, c, d}, Cycles[{{1, 2, 3, 4}}]]]]]

(* a == b*)

vvss[p_, r_, a_, b_, c_, d_] /; (a == b) := If[c == d, AMatrix[1, 1, 1, -1], Transpose[AMatrix[-1, -1, (-1)^Mod[vec[a], 2], (-1)^Mod[vec[a] + 1 , 2]]]]

(* a!=b *)

vvss[p_, r_, a_, b_, c_, d_] /; (a != b && c == d) := If[Mod[a - b, 2] == 0, Transpose[AMatrix[(-1)^(c), (-1)^(c), 1, -1]], Transpose[AMatrix[1, -1, (-1)^(c), (-1)^(c)]]]
vvss[p_, r_, a_, b_, c_, d_] /; (a != b && c != d && vectorQ[p, b] && c == 2) := (-1)^a Switch[{Mod[vec[b] - vec[a], 2], a < b},
   {0, True}, Transpose[AMatrix[1, 1, -1, 1]],
   {0, False}, AMatrix[-1, -1, -1, 1],
   {1, True}, AMatrix[-1, 1, 1, 1],
   {1, False}, Transpose[AMatrix[1, -1, 1, 1]]]
vvss[p_, r_, a_, b_, c_, d_] /; (a != b && c != d && vectorQ[p, b] && c == 3) := (-1)^b Switch[{Mod[vec[b] - vec[a], 2], b < a},
   {0, True}, Transpose[AMatrix[1, 1, -1, 1]],
   {0, False}, AMatrix[-1, -1, -1, 1],
   {1, True}, AMatrix[-1, 1, 1, 1],
   {1, False}, Transpose[AMatrix[1, -1, 1, 1]]]

(* vector-spinor-vector-spinor *)
vsvs[p_, r_, {a_, b_, c_, d_}] := If[vectorQ[p, a], vsvs[p, r, a, b, c, d], vsvs[p, r, Permute[{a, b, c, d}, Cycles[{{1, 2, 3, 4}}]]]]

vsvs[p_, r_, a_, b_, c_, d_] /; (vectorQ[p, c] && b == d) := (-1)^(b + 1) (-1)^(( vec[a] ) ( vec[c] )) DMatrix[p, r, vec[a] vec[c], -1, (-1)^(vec[a] + vec[c]), (-1)^(vec[a] + vec[c]), 1]
vsvs[p_, r_, a_, b_, c_, d_] /; (vectorQ[p, c] && b != d) := -(-1)^(( vec[a] ) ( vec[c] )) EMatrix[p, r, vec[a] vec[c], (-1)^(vec[a] + vec[c]), 1, 1, (-1)^(vec[a] + vec[c] + 1)]

(* spinor-spinor-spinor-spinor *)
ssss[p_, r_, k_, a_, b_, c_, d_] /; (a == c && b == d) := If[a == b, HMatrix[p, r, k], -HMatrix[p, r, k]]
ssss[p_, r_, k_, a_, b_, c_, d_] /; ((a == b && c == d && b != c) || (b == c && a == d && a != b)) := HPMatrix[p, r, k]
ssss[p_, r_, k_, a_, b_, c_, d_] /; ((b == c && a != d) || (a == b && c != d) || (c == d && a != b)) := If[Length[Select[{a, b, c, d}, # == 2 &]] == 3, GMatrix[p, r, k], -GMatrix[p, r, k]]

(* fMatrices *)
fMat[p_, r_, k_] := fMat[p, r, k, {#1, #2, #3, #4}] &
fMat[p_, r_, k_, {a_, b_, c_, d_}] := fMat[p, r, k, a, b, c, d]
fMat[p_, r_, k_, a_, b_, c_, d_] /; (! admissibleQuad[p, a, b, c, d]) := {{0}}
fMat[p_, r_, k_, a_, b_, c_, d_] := {{1}}

(* Identity Object *)
fMat[p_, r_, k_, 0, b_, c_, d_] := {{gRing[p, b, c, d]}}
fMat[p_, r_, k_, a_, 0, c_, d_] := {{gRing[p, a, c, d]}}
fMat[p_, r_, k_, a_, b_, 0, d_] := {{gRing[p, a, b, d]}}
fMat[p_, r_, k_, a_, b_, c_, 0] := {{gRing[p, a, b, c]}}

(* Z2 object *)
fMat[p_, r_, k_, 1, 1, 1, 1] := {{1}}
fMat[p_, r_, k_, a_, b_, c_, d_] /; (Length[Select[{a, b, c, d}, spinorQ[#] &]] == 2 && Length[Select[{a, b, c, d}, # == 1 &]] == 2) := {{-1}}
fMat[p_, r_, k_, a_, b_, c_, d_] /; (Length[Select[{a, b, c, d}, spinorQ[#] &]] == 2 && Length[Select[{a, b, c, d}, # == 1 &]] == 1) := essv[p, {a, b, c, d}]
fMat[p_, r_, k_, a_, b_, c_, d_] /; (Length[Select[{a, b, c, d}, vectorQ[p, #] &]] == 2 && Length[Select[{a, b, c, d}, # == 1 &]] == 2 && (a == c) && (b == d)) := {{1}}
fMat[p_, r_, k_, a_, b_, c_, d_] /; (Length[Select[{a, b, c, d}, vectorQ[p, #] &]] == 2 && Length[Select[{a, b, c, d}, # == 1 &]] == 2 && (((a == b) && (c == d)) || ((a == d) && (b == c)))) := {{-1}}
fMat[p_, r_, k_, a_, b_, c_, d_] /; (Length[Select[{a, b, c, d}, vectorQ[p, #] &]] == 3 && Length[Select[{a, b, c, d}, # == 1 &]] == 1) := evvv[p, {a, b, c, d}]

(* vector-vector-vector-vector *)
fMat[p_, r_, k_, a_, b_, c_, d_] /; (Length[Select[{a, b, c, d}, vectorQ[p, #] &]] == 4) := vvvv[p, {a, b, c, d}]

(* vector-vector-spinor-spinor *)
fMat[p_, r_, k_, a_, b_, c_, d_] /; ((Length[Select[{a, b, c, d}, spinorQ[#] &]] == 2) && (Length[Select[{a, b, c, d}, vectorQ[p, #] &]] == 2) && (vectorQ[p, a] == vectorQ[p, b] || vectorQ[p, b] == vectorQ[p, c] || vectorQ[p, c] == vectorQ[p, d])) := vvss[p, r, {a, b, c, d}]

(* vector-spinor-vector-spinor *)
fMat[p_, r_, k_, a_, b_, c_, d_] /; ((Length[Select[{a, b, c, d}, spinorQ[#] &]] == 2) && (Length[Select[{a, b, c, d}, vectorQ[p, #] &]] == 2) && (vectorQ[p, a] != vectorQ[p, b] && vectorQ[p, b] != vectorQ[p, c])) := vsvs[p, r, {a, b, c, d}]

(* spinor-spinor-spinor-spinor *)
fMat[p_, r_, k_, a_, b_, c_, d_] /; (Length[Select[{a, b, c, d}, spinorQ[#] &]] == 4) := ssss[p, r, k, a, b, c, d]

(* ***** R-Matrix Stuff ***** *)
rMat::index = "There is not a solution corresponding to `1`";
rMat[p_Integer, r_, k_, l_] := rMat[p, r, k, l, {#1, #2, #3}] &
rMat[p_Integer, r_, k_, l_, {a_, b_, c_}] :=  {{rMat[p, r, k, l, a, b, c]}}
rMat[p_, r_, k_, l_, a_, b_, c_] /; (gRing[p, a, b, c] == 0) := 0
rMat[p_, r_, k_, l_, a_, b_, c_] := Switch[l, 1, rFun[p, r, k, a, b, c], -1, Conjugate[rFun[p, r, k, a, b, c]], _, Message[rMat::index, l]]

rFun[p_, r_, k_, a_, b_, c_] := sigma1[p, a, b, c] sigma2[p, r, a, b, c] (-1)^(hh[p, r, k, a] + hh[p, r, k, b] - hh[p, r, k, c])

hh[p_Integer, r_Integer, k_Integer, 0] := 0
hh[p_Integer, r_Integer, k_Integer, 1] := 1
hh[p_Integer, r_Integer, k_Integer, a_?(spinorQ)] := Module[{sp = If[(Mod[p, 4] == 1 || Mod[p, 4] == 2), 1, -1], sr = If[Mod[r, 8] == 3 || Mod[r, 8] == 5, 1, -1], l = If[a == 2, 2, 6]}, (r (p + k sp + JacobiSymbol[p + (r + 1)/2, r] sr + l))/8]
hh[p_, r_, k_, a_] /; vectorQ[p, a] := Module[{a0 = a - 3}, (r a0 (2 p +1 - a0))/(2 (2 p + 1))]

m4[p_,a_ ,b_]/;vectorQ[p,a]:=Mod[(a-b)+(-1)^p,4]
m4[p_,a_]:=m4[p,a,3]

sigma1[p_,a_,b_,c_]/;gRing[p,a,b,c]==0:=0
sigma1[p_,a_,b_,c_]:=1
sigma1[p_,a_,b_,c_]/;Length[Select[{a,b,c},vectorQ[p,#1]&]]==3:=Module[{tup=Sort[{a-3,b-3,c-3}]},If[(-1)^tup[[1]]==(-1)^tup[[2]]==-1,-1,1]]
sigma1[p_,a_,b_,c_]/;Length[Select[{a,b,c},spinorQ]]==2&&Length[Select[{a,b,c},vectorQ[p,#1]&]]==1:=Module[{l=Select[{a,b,c},vectorQ[p,#]&][[1]]-3},If[OddQ[p],If[(Mod[l,4]==1||Mod[l,4]==2),-1,1],If[(Mod[l,4]==2||Mod[l,4]==3),-1,1]]]

sigma2[p_, r_, a_, b_, c_] := 0
sigma2[p_, r_, a_, b_, c_] /; (gRing[p, a, b, c] == 1) := 1
sigma2[p_, r_, a_, b_, c_] /; (Length[Select[{a, b, c}, spinorQ]] == 2 && (Length[Select[{a, b, c}, vectorQ[p, #] &]] == 1 || MemberQ[{a, b, c}, 1])) := Module[{sp=Select[{a,b,c},spinorQ]}, If[Length[Union[sp]]==2, (-1)^((r - 1)/2),1]]

(*hh[p_, r_, k_, a_] /; vectorQ[p, a] := Module[{a0 = a - 4}, (r (a0+1) (2 p - a0))/(2 (2 p + 1))]*)

EndPackage[]
