BeginPackage["FusionCategories`Data`doubleS3sub6`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[doubleS3sub6] ^= {doubleS3sub6Cat1, doubleS3sub6Cat2, 
    doubleS3sub6Cat3, doubleS3sub6Cat4, doubleS3sub6Cat5}
 
doubleS3sub6 /: fusionCategory[doubleS3sub6, 1] = doubleS3sub6Cat1
 
doubleS3sub6 /: fusionCategory[doubleS3sub6, 2] = doubleS3sub6Cat2
 
doubleS3sub6 /: fusionCategory[doubleS3sub6, 3] = doubleS3sub6Cat3
 
doubleS3sub6 /: fusionCategory[doubleS3sub6, 4] = doubleS3sub6Cat4
 
doubleS3sub6 /: fusionCategory[doubleS3sub6, 5] = doubleS3sub6Cat5
 
nFunction[doubleS3sub6] ^= doubleS3sub6NFunction
 
noMultiplicities[doubleS3sub6] ^= True
 
rank[doubleS3sub6] ^= 6
 
ring[doubleS3sub6] ^= doubleS3sub6
balancedCategories[doubleS3sub6Cat1] ^= {doubleS3sub6Cat1Bal1, 
    doubleS3sub6Cat1Bal2, doubleS3sub6Cat1Bal3, doubleS3sub6Cat1Bal4, 
    doubleS3sub6Cat1Bal5}
 
doubleS3sub6Cat1 /: balancedCategory[doubleS3sub6Cat1, 1] = 
    doubleS3sub6Cat1Bal1
 
doubleS3sub6Cat1 /: balancedCategory[doubleS3sub6Cat1, 2] = 
    doubleS3sub6Cat1Bal2
 
doubleS3sub6Cat1 /: balancedCategory[doubleS3sub6Cat1, 3] = 
    doubleS3sub6Cat1Bal3
 
doubleS3sub6Cat1 /: balancedCategory[doubleS3sub6Cat1, 4] = 
    doubleS3sub6Cat1Bal4
 
doubleS3sub6Cat1 /: balancedCategory[doubleS3sub6Cat1, 5] = 
    doubleS3sub6Cat1Bal5
 
braidedCategories[doubleS3sub6Cat1] ^= {doubleS3sub6Cat1Brd1, 
    doubleS3sub6Cat1Brd2, doubleS3sub6Cat1Brd3, doubleS3sub6Cat1Brd4, 
    doubleS3sub6Cat1Brd5}
 
doubleS3sub6Cat1 /: braidedCategory[doubleS3sub6Cat1, 1] = 
    doubleS3sub6Cat1Brd1
 
doubleS3sub6Cat1 /: braidedCategory[doubleS3sub6Cat1, 2] = 
    doubleS3sub6Cat1Brd2
 
doubleS3sub6Cat1 /: braidedCategory[doubleS3sub6Cat1, 3] = 
    doubleS3sub6Cat1Brd3
 
doubleS3sub6Cat1 /: braidedCategory[doubleS3sub6Cat1, 4] = 
    doubleS3sub6Cat1Brd4
 
doubleS3sub6Cat1 /: braidedCategory[doubleS3sub6Cat1, 5] = 
    doubleS3sub6Cat1Brd5
 
coeval[doubleS3sub6Cat1] ^= 1/sixJFunction[doubleS3sub6Cat1][#1, 
      dual[ring[doubleS3sub6Cat1]][#1], #1, #1, 0, 0] & 
 
eval[doubleS3sub6Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[doubleS3sub6Cat1] ^= doubleS3sub6Cat1FMatrixFunction
 
fusionCategory[doubleS3sub6Cat1] ^= doubleS3sub6Cat1
 
doubleS3sub6Cat1 /: modularCategory[doubleS3sub6Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[doubleS3sub6Cat1] ^= {doubleS3sub6Cat1Piv1}
 
doubleS3sub6Cat1 /: pivotalCategory[doubleS3sub6Cat1, 1] = 
    doubleS3sub6Cat1Piv1
 
doubleS3sub6Cat1 /: pivotalCategory[doubleS3sub6Cat1, {1, 1, 1, 1, 1, 1}] = 
    doubleS3sub6Cat1Piv1
 
doubleS3sub6Cat1 /: ribbonCategory[doubleS3sub6Cat1, 1] = doubleS3sub6Cat1Bal1
 
doubleS3sub6Cat1 /: ribbonCategory[doubleS3sub6Cat1, 2] = doubleS3sub6Cat1Bal2
 
doubleS3sub6Cat1 /: ribbonCategory[doubleS3sub6Cat1, 3] = doubleS3sub6Cat1Bal3
 
doubleS3sub6Cat1 /: ribbonCategory[doubleS3sub6Cat1, 4] = doubleS3sub6Cat1Bal4
 
doubleS3sub6Cat1 /: ribbonCategory[doubleS3sub6Cat1, 5] = doubleS3sub6Cat1Bal5
 
ring[doubleS3sub6Cat1] ^= doubleS3sub6
 
doubleS3sub6Cat1 /: sphericalCategory[doubleS3sub6Cat1, 1] = 
    doubleS3sub6Cat1Piv1
 
doubleS3sub6Cat1 /: symmetricCategory[doubleS3sub6Cat1, 1] = 
    doubleS3sub6Cat1Brd5
 
fusionCategoryIndex[doubleS3sub6][doubleS3sub6Cat1] ^= 1
balancedCategory[doubleS3sub6Cat1Bal1] ^= doubleS3sub6Cat1Bal1
 
braidedCategory[doubleS3sub6Cat1Bal1] ^= doubleS3sub6Cat1Brd1
 
fusionCategory[doubleS3sub6Cat1Bal1] ^= doubleS3sub6Cat1
 
pivotalCategory[doubleS3sub6Cat1Bal1] ^= doubleS3sub6Cat1Piv1
 
ribbonCategory[doubleS3sub6Cat1Bal1] ^= doubleS3sub6Cat1Bal1
 
ring[doubleS3sub6Cat1Bal1] ^= doubleS3sub6
 
sphericalCategory[doubleS3sub6Cat1Bal1] ^= doubleS3sub6Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[doubleS3sub6Cat1Brd1]][
      balancedCategory[#1]] & )[doubleS3sub6Cat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[doubleS3sub6Cat1]][
      balancedCategory[#1]] & )[doubleS3sub6Cat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[doubleS3sub6Cat1Piv1]][
      balancedCategory[#1]] & )[doubleS3sub6Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[doubleS3sub6Cat1Brd1]][
      ribbonCategory[#1]] & )[doubleS3sub6Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[doubleS3sub6Cat1]][
      ribbonCategory[#1]] & )[doubleS3sub6Cat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[doubleS3sub6Cat1Piv1]][
      ribbonCategory[#1]] & )[doubleS3sub6Cat1Bal1] ^= 1
balancedCategory[doubleS3sub6Cat1Bal2] ^= doubleS3sub6Cat1Bal2
 
braidedCategory[doubleS3sub6Cat1Bal2] ^= doubleS3sub6Cat1Brd2
 
fusionCategory[doubleS3sub6Cat1Bal2] ^= doubleS3sub6Cat1
 
pivotalCategory[doubleS3sub6Cat1Bal2] ^= doubleS3sub6Cat1Piv1
 
ribbonCategory[doubleS3sub6Cat1Bal2] ^= doubleS3sub6Cat1Bal2
 
ring[doubleS3sub6Cat1Bal2] ^= doubleS3sub6
 
sphericalCategory[doubleS3sub6Cat1Bal2] ^= doubleS3sub6Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[doubleS3sub6Cat1Brd2]][
      balancedCategory[#1]] & )[doubleS3sub6Cat1Bal2] ^= 1
 
(balancedCategoryIndex[fusionCategory[doubleS3sub6Cat1]][
      balancedCategory[#1]] & )[doubleS3sub6Cat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[doubleS3sub6Cat1Piv1]][
      balancedCategory[#1]] & )[doubleS3sub6Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[braidedCategory[doubleS3sub6Cat1Brd2]][
      ribbonCategory[#1]] & )[doubleS3sub6Cat1Bal2] ^= 1
 
(ribbonCategoryIndex[fusionCategory[doubleS3sub6Cat1]][
      ribbonCategory[#1]] & )[doubleS3sub6Cat1Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[doubleS3sub6Cat1Piv1]][
      ribbonCategory[#1]] & )[doubleS3sub6Cat1Bal2] ^= 2
balancedCategory[doubleS3sub6Cat1Bal3] ^= doubleS3sub6Cat1Bal3
 
braidedCategory[doubleS3sub6Cat1Bal3] ^= doubleS3sub6Cat1Brd3
 
fusionCategory[doubleS3sub6Cat1Bal3] ^= doubleS3sub6Cat1
 
pivotalCategory[doubleS3sub6Cat1Bal3] ^= doubleS3sub6Cat1Piv1
 
ribbonCategory[doubleS3sub6Cat1Bal3] ^= doubleS3sub6Cat1Bal3
 
ring[doubleS3sub6Cat1Bal3] ^= doubleS3sub6
 
sphericalCategory[doubleS3sub6Cat1Bal3] ^= doubleS3sub6Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[doubleS3sub6Cat1Brd3]][
      balancedCategory[#1]] & )[doubleS3sub6Cat1Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[doubleS3sub6Cat1]][
      balancedCategory[#1]] & )[doubleS3sub6Cat1Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[doubleS3sub6Cat1Piv1]][
      balancedCategory[#1]] & )[doubleS3sub6Cat1Bal3] ^= 3
 
(ribbonCategoryIndex[braidedCategory[doubleS3sub6Cat1Brd3]][
      ribbonCategory[#1]] & )[doubleS3sub6Cat1Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[doubleS3sub6Cat1]][
      ribbonCategory[#1]] & )[doubleS3sub6Cat1Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[doubleS3sub6Cat1Piv1]][
      ribbonCategory[#1]] & )[doubleS3sub6Cat1Bal3] ^= 3
balancedCategory[doubleS3sub6Cat1Bal4] ^= doubleS3sub6Cat1Bal4
 
braidedCategory[doubleS3sub6Cat1Bal4] ^= doubleS3sub6Cat1Brd4
 
fusionCategory[doubleS3sub6Cat1Bal4] ^= doubleS3sub6Cat1
 
pivotalCategory[doubleS3sub6Cat1Bal4] ^= doubleS3sub6Cat1Piv1
 
ribbonCategory[doubleS3sub6Cat1Bal4] ^= doubleS3sub6Cat1Bal4
 
ring[doubleS3sub6Cat1Bal4] ^= doubleS3sub6
 
sphericalCategory[doubleS3sub6Cat1Bal4] ^= doubleS3sub6Cat1Piv1
 
(balancedCategoryIndex[braidedCategory[doubleS3sub6Cat1Brd4]][
      balancedCategory[#1]] & )[doubleS3sub6Cat1Bal4] ^= 1
 
(balancedCategoryIndex[fusionCategory[doubleS3sub6Cat1]][
      balancedCategory[#1]] & )[doubleS3sub6Cat1Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[doubleS3sub6Cat1Piv1]][
      balancedCategory[#1]] & )[doubleS3sub6Cat1Bal4] ^= 4
 
(ribbonCategoryIndex[braidedCategory[doubleS3sub6Cat1Brd4]][
      ribbonCategory[#1]] & )[doubleS3sub6Cat1Bal4] ^= 1
 
(ribbonCategoryIndex[fusionCategory[doubleS3sub6Cat1]][
      ribbonCategory[#1]] & )[doubleS3sub6Cat1Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[doubleS3sub6Cat1Piv1]][
      ribbonCategory[#1]] & )[doubleS3sub6Cat1Bal4] ^= 4
balancedCategory[doubleS3sub6Cat1Bal5] ^= doubleS3sub6Cat1Bal5
 
braidedCategory[doubleS3sub6Cat1Bal5] ^= doubleS3sub6Cat1Brd5
 
fusionCategory[doubleS3sub6Cat1Bal5] ^= doubleS3sub6Cat1
 
pivotalCategory[doubleS3sub6Cat1Bal5] ^= doubleS3sub6Cat1Piv1
 
ribbonCategory[doubleS3sub6Cat1Bal5] ^= doubleS3sub6Cat1Bal5
 
ring[doubleS3sub6Cat1Bal5] ^= doubleS3sub6
 
sphericalCategory[doubleS3sub6Cat1Bal5] ^= doubleS3sub6Cat1Piv1
 
symmetricCategory[doubleS3sub6Cat1Bal5] ^= doubleS3sub6Cat1Brd5
 
(balancedCategoryIndex[braidedCategory[doubleS3sub6Cat1Brd5]][
      balancedCategory[#1]] & )[doubleS3sub6Cat1Bal5] ^= 1
 
(balancedCategoryIndex[fusionCategory[doubleS3sub6Cat1]][
      balancedCategory[#1]] & )[doubleS3sub6Cat1Bal5] ^= 5
 
(balancedCategoryIndex[pivotalCategory[doubleS3sub6Cat1Piv1]][
      balancedCategory[#1]] & )[doubleS3sub6Cat1Bal5] ^= 5
 
(ribbonCategoryIndex[braidedCategory[doubleS3sub6Cat1Brd5]][
      ribbonCategory[#1]] & )[doubleS3sub6Cat1Bal5] ^= 1
 
(ribbonCategoryIndex[fusionCategory[doubleS3sub6Cat1]][
      ribbonCategory[#1]] & )[doubleS3sub6Cat1Bal5] ^= 5
 
(ribbonCategoryIndex[sphericalCategory[doubleS3sub6Cat1Piv1]][
      ribbonCategory[#1]] & )[doubleS3sub6Cat1Bal5] ^= 5
balancedCategories[doubleS3sub6Cat1Brd1] ^= {doubleS3sub6Cat1Bal1}
 
doubleS3sub6Cat1Brd1 /: balancedCategory[doubleS3sub6Cat1Brd1, 1] = 
    doubleS3sub6Cat1Bal1
 
braidedCategory[doubleS3sub6Cat1Brd1] ^= doubleS3sub6Cat1Brd1
 
fusionCategory[doubleS3sub6Cat1Brd1] ^= doubleS3sub6Cat1
 
doubleS3sub6Cat1Brd1 /: modularCategory[doubleS3sub6Cat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
doubleS3sub6Cat1Brd1 /: ribbonCategory[doubleS3sub6Cat1Brd1, 1] = 
    doubleS3sub6Cat1Bal1
 
ring[doubleS3sub6Cat1Brd1] ^= doubleS3sub6
 
rMatrixFunction[doubleS3sub6Cat1Brd1] ^= doubleS3sub6Cat1Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[doubleS3sub6Cat1]][
      braidedCategory[#1]] & )[doubleS3sub6Cat1Brd1] ^= 1
braidedCategory[doubleS3sub6Cat1Brd1RMatrixFunction] ^= doubleS3sub6Cat1Brd1
 
fusionCategory[doubleS3sub6Cat1Brd1RMatrixFunction] ^= doubleS3sub6Cat1
 
rMatrixFunction[doubleS3sub6Cat1Brd1RMatrixFunction] ^= 
   doubleS3sub6Cat1Brd1RMatrixFunction
 
doubleS3sub6Cat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[0, 4, 4] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[0, 5, 5] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[1, 1, 0] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[1, 2, 2] = {{-1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[1, 3, 3] = {{-1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[1, 4, 4] = {{-1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[1, 5, 5] = {{-1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[2, 1, 2] = {{-1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[2, 2, 0] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[2, 2, 1] = {{-1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[2, 2, 2] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[2, 3, 4] = {{-(I + Sqrt[3])^2/4}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[2, 3, 5] = {{-4/(I + Sqrt[3])^2}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[2, 4, 3] = {{-4/(I + Sqrt[3])^2}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[2, 4, 5] = {{-(I + Sqrt[3])^2/4}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[2, 5, 3] = {{-(I + Sqrt[3])^2/4}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[2, 5, 4] = {{-4/(I + Sqrt[3])^2}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[3, 1, 3] = {{-1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[3, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[3, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[3, 3, 0] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[3, 3, 1] = {{-1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[3, 3, 3] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[3, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[3, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[3, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[3, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[4, 0, 4] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[4, 1, 4] = {{-1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[4, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[4, 3, 2] = {{-4/(I + Sqrt[3])^2}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[4, 3, 5] = {{-(I + Sqrt[3])^2/4}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[4, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[4, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[4, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[4, 5, 2] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[4, 5, 3] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[5, 0, 5] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[5, 1, 5] = {{-1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[5, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[5, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[5, 3, 2] = {{-(I + Sqrt[3])^2/4}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[5, 3, 4] = {{-4/(I + Sqrt[3])^2}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[5, 4, 2] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[5, 4, 3] = {{1}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[5, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[5, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3sub6Cat1Brd1RMatrixFunction[5, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
balancedCategories[doubleS3sub6Cat1Brd2] ^= {doubleS3sub6Cat1Bal2}
 
doubleS3sub6Cat1Brd2 /: balancedCategory[doubleS3sub6Cat1Brd2, 1] = 
    doubleS3sub6Cat1Bal2
 
braidedCategory[doubleS3sub6Cat1Brd2] ^= doubleS3sub6Cat1Brd2
 
fusionCategory[doubleS3sub6Cat1Brd2] ^= doubleS3sub6Cat1
 
doubleS3sub6Cat1Brd2 /: modularCategory[doubleS3sub6Cat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
doubleS3sub6Cat1Brd2 /: ribbonCategory[doubleS3sub6Cat1Brd2, 1] = 
    doubleS3sub6Cat1Bal2
 
ring[doubleS3sub6Cat1Brd2] ^= doubleS3sub6
 
rMatrixFunction[doubleS3sub6Cat1Brd2] ^= doubleS3sub6Cat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[doubleS3sub6Cat1]][
      braidedCategory[#1]] & )[doubleS3sub6Cat1Brd2] ^= 2
braidedCategory[doubleS3sub6Cat1Brd2RMatrixFunction] ^= doubleS3sub6Cat1Brd2
 
fusionCategory[doubleS3sub6Cat1Brd2RMatrixFunction] ^= doubleS3sub6Cat1
 
rMatrixFunction[doubleS3sub6Cat1Brd2RMatrixFunction] ^= 
   doubleS3sub6Cat1Brd2RMatrixFunction
 
doubleS3sub6Cat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[0, 4, 4] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[0, 5, 5] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[1, 1, 0] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[1, 2, 2] = {{-1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[1, 3, 3] = {{-1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[1, 4, 4] = {{-1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[1, 5, 5] = {{-1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[2, 1, 2] = {{-1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[2, 2, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[2, 2, 1] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[2, 2, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[2, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[2, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[2, 4, 3] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[2, 4, 5] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[2, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[2, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[3, 1, 3] = {{-1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[3, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[3, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[3, 3, 0] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[3, 3, 1] = {{-1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[3, 3, 3] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[3, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[3, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[3, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[3, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[4, 0, 4] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[4, 1, 4] = {{-1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[4, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[4, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[4, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[4, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[4, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[4, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[4, 5, 2] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[4, 5, 3] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[5, 0, 5] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[5, 1, 5] = {{-1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[5, 2, 3] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[5, 2, 4] = {{1}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[5, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[5, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[5, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[5, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[5, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[5, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3sub6Cat1Brd2RMatrixFunction[5, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
balancedCategories[doubleS3sub6Cat1Brd3] ^= {doubleS3sub6Cat1Bal3}
 
doubleS3sub6Cat1Brd3 /: balancedCategory[doubleS3sub6Cat1Brd3, 1] = 
    doubleS3sub6Cat1Bal3
 
braidedCategory[doubleS3sub6Cat1Brd3] ^= doubleS3sub6Cat1Brd3
 
fusionCategory[doubleS3sub6Cat1Brd3] ^= doubleS3sub6Cat1
 
doubleS3sub6Cat1Brd3 /: modularCategory[doubleS3sub6Cat1Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
doubleS3sub6Cat1Brd3 /: ribbonCategory[doubleS3sub6Cat1Brd3, 1] = 
    doubleS3sub6Cat1Bal3
 
ring[doubleS3sub6Cat1Brd3] ^= doubleS3sub6
 
rMatrixFunction[doubleS3sub6Cat1Brd3] ^= doubleS3sub6Cat1Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[doubleS3sub6Cat1]][
      braidedCategory[#1]] & )[doubleS3sub6Cat1Brd3] ^= 3
braidedCategory[doubleS3sub6Cat1Brd3RMatrixFunction] ^= doubleS3sub6Cat1Brd3
 
fusionCategory[doubleS3sub6Cat1Brd3RMatrixFunction] ^= doubleS3sub6Cat1
 
rMatrixFunction[doubleS3sub6Cat1Brd3RMatrixFunction] ^= 
   doubleS3sub6Cat1Brd3RMatrixFunction
 
doubleS3sub6Cat1Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[0, 4, 4] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[0, 5, 5] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[1, 1, 0] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[1, 2, 2] = {{-1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[1, 3, 3] = {{-1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[1, 4, 4] = {{-1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[1, 5, 5] = {{-1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[2, 1, 2] = {{-1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[2, 2, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[2, 2, 1] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[2, 2, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[2, 3, 4] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[2, 3, 5] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[2, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[2, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[2, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[2, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[3, 1, 3] = {{-1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[3, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[3, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[3, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[3, 3, 1] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[3, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[3, 4, 2] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[3, 4, 5] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[3, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[3, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[4, 0, 4] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[4, 1, 4] = {{-1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[4, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[4, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[4, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[4, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[4, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[4, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[4, 5, 2] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[4, 5, 3] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[5, 0, 5] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[5, 1, 5] = {{-1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[5, 2, 3] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[5, 2, 4] = {{1}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[5, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[5, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[5, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[5, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[5, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[5, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3sub6Cat1Brd3RMatrixFunction[5, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
balancedCategories[doubleS3sub6Cat1Brd4] ^= {doubleS3sub6Cat1Bal4}
 
doubleS3sub6Cat1Brd4 /: balancedCategory[doubleS3sub6Cat1Brd4, 1] = 
    doubleS3sub6Cat1Bal4
 
braidedCategory[doubleS3sub6Cat1Brd4] ^= doubleS3sub6Cat1Brd4
 
fusionCategory[doubleS3sub6Cat1Brd4] ^= doubleS3sub6Cat1
 
doubleS3sub6Cat1Brd4 /: modularCategory[doubleS3sub6Cat1Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
doubleS3sub6Cat1Brd4 /: ribbonCategory[doubleS3sub6Cat1Brd4, 1] = 
    doubleS3sub6Cat1Bal4
 
ring[doubleS3sub6Cat1Brd4] ^= doubleS3sub6
 
rMatrixFunction[doubleS3sub6Cat1Brd4] ^= doubleS3sub6Cat1Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[doubleS3sub6Cat1]][
      braidedCategory[#1]] & )[doubleS3sub6Cat1Brd4] ^= 4
braidedCategory[doubleS3sub6Cat1Brd4RMatrixFunction] ^= doubleS3sub6Cat1Brd4
 
fusionCategory[doubleS3sub6Cat1Brd4RMatrixFunction] ^= doubleS3sub6Cat1
 
rMatrixFunction[doubleS3sub6Cat1Brd4RMatrixFunction] ^= 
   doubleS3sub6Cat1Brd4RMatrixFunction
 
doubleS3sub6Cat1Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[0, 4, 4] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[0, 5, 5] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[1, 1, 0] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[1, 2, 2] = {{-1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[1, 3, 3] = {{-1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[1, 4, 4] = {{-1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[1, 5, 5] = {{-1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[2, 1, 2] = {{-1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[2, 2, 0] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[2, 2, 1] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[2, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[2, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[2, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[2, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[2, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[2, 5, 3] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[2, 5, 4] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[3, 1, 3] = {{-1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[3, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[3, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[3, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[3, 3, 1] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[3, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[3, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[3, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[3, 5, 2] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[3, 5, 4] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[4, 0, 4] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[4, 1, 4] = {{-1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[4, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[4, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[4, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[4, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[4, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[4, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[4, 5, 2] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[4, 5, 3] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[5, 0, 5] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[5, 1, 5] = {{-1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[5, 2, 3] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[5, 2, 4] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[5, 3, 2] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[5, 3, 4] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[5, 4, 2] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[5, 4, 3] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[5, 5, 0] = {{1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[5, 5, 1] = {{-1}}
 
doubleS3sub6Cat1Brd4RMatrixFunction[5, 5, 5] = {{1}}
balancedCategories[doubleS3sub6Cat1Brd5] ^= {doubleS3sub6Cat1Bal5}
 
doubleS3sub6Cat1Brd5 /: balancedCategory[doubleS3sub6Cat1Brd5, 1] = 
    doubleS3sub6Cat1Bal5
 
braidedCategory[doubleS3sub6Cat1Brd5] ^= doubleS3sub6Cat1Brd5
 
fusionCategory[doubleS3sub6Cat1Brd5] ^= doubleS3sub6Cat1
 
doubleS3sub6Cat1Brd5 /: modularCategory[doubleS3sub6Cat1Brd5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
doubleS3sub6Cat1Brd5 /: ribbonCategory[doubleS3sub6Cat1Brd5, 1] = 
    doubleS3sub6Cat1Bal5
 
ring[doubleS3sub6Cat1Brd5] ^= doubleS3sub6
 
rMatrixFunction[doubleS3sub6Cat1Brd5] ^= doubleS3sub6Cat1Brd5RMatrixFunction
 
symmetricCategory[doubleS3sub6Cat1Brd5] ^= doubleS3sub6Cat1Brd5
 
(braidedCategoryIndex[fusionCategory[doubleS3sub6Cat1]][
      braidedCategory[#1]] & )[doubleS3sub6Cat1Brd5] ^= 5
 
(symmetricCategoryIndex[fusionCategory[doubleS3sub6Cat1]][
      symmetricCategory[#1]] & )[doubleS3sub6Cat1Brd5] ^= 1
braidedCategory[doubleS3sub6Cat1Brd5RMatrixFunction] ^= doubleS3sub6Cat1Brd5
 
fusionCategory[doubleS3sub6Cat1Brd5RMatrixFunction] ^= doubleS3sub6Cat1
 
rMatrixFunction[doubleS3sub6Cat1Brd5RMatrixFunction] ^= 
   doubleS3sub6Cat1Brd5RMatrixFunction
 
doubleS3sub6Cat1Brd5RMatrixFunction[0, 0, 0] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[0, 1, 1] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[0, 2, 2] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[0, 3, 3] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[0, 4, 4] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[0, 5, 5] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[1, 0, 1] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[1, 1, 0] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[1, 2, 2] = {{-1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[1, 3, 3] = {{-1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[1, 4, 4] = {{-1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[1, 5, 5] = {{-1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[2, 0, 2] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[2, 1, 2] = {{-1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[2, 2, 0] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[2, 2, 1] = {{-1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[2, 2, 2] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[2, 3, 4] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[2, 3, 5] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[2, 4, 3] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[2, 4, 5] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[2, 5, 3] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[2, 5, 4] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[3, 0, 3] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[3, 1, 3] = {{-1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[3, 2, 4] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[3, 2, 5] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[3, 3, 0] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[3, 3, 1] = {{-1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[3, 3, 3] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[3, 4, 2] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[3, 4, 5] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[3, 5, 2] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[3, 5, 4] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[4, 0, 4] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[4, 1, 4] = {{-1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[4, 2, 3] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[4, 2, 5] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[4, 3, 2] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[4, 3, 5] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[4, 4, 0] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[4, 4, 1] = {{-1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[4, 4, 4] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[4, 5, 2] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[4, 5, 3] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[5, 0, 5] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[5, 1, 5] = {{-1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[5, 2, 3] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[5, 2, 4] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[5, 3, 2] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[5, 3, 4] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[5, 4, 2] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[5, 4, 3] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[5, 5, 0] = {{1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[5, 5, 1] = {{-1}}
 
doubleS3sub6Cat1Brd5RMatrixFunction[5, 5, 5] = {{1}}
fMatrixFunction[doubleS3sub6Cat1FMatrixFunction] ^= 
   doubleS3sub6Cat1FMatrixFunction
 
fusionCategory[doubleS3sub6Cat1FMatrixFunction] ^= doubleS3sub6Cat1
 
ring[doubleS3sub6Cat1FMatrixFunction] ^= doubleS3sub6
 
doubleS3sub6Cat1FMatrixFunction[1, 2, 2, 2] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 2, 3, 5] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 2, 4, 3] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 2, 5, 4] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 3, 3, 0] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 3, 3, 3] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 3, 4, 2] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 3, 4, 5] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 3, 5, 4] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 4, 3, 5] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 4, 5, 2] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 4, 5, 3] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 5, 3, 2] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 5, 3, 4] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 5, 4, 3] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 5, 5, 0] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 5, 5, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[1, 5, 5, 5] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[2, 1, 2, 2] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[2, 1, 3, 4] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[2, 1, 4, 5] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[2, 1, 5, 3] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[2, 2, 1, 2] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[2, 2, 2, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
doubleS3sub6Cat1FMatrixFunction[2, 2, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat1FMatrixFunction[2, 2, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat1FMatrixFunction[2, 2, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat1FMatrixFunction[2, 3, 2, 3] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat1FMatrixFunction[2, 3, 3, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat1FMatrixFunction[2, 4, 2, 4] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat1FMatrixFunction[2, 4, 4, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat1FMatrixFunction[2, 4, 5, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[2, 5, 2, 5] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat1FMatrixFunction[2, 5, 3, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[2, 5, 4, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[2, 5, 5, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat1FMatrixFunction[3, 1, 2, 4] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[3, 1, 3, 3] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[3, 1, 4, 5] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[3, 1, 5, 4] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[3, 2, 1, 5] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[3, 2, 2, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat1FMatrixFunction[3, 2, 3, 2] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat1FMatrixFunction[3, 2, 4, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[3, 3, 1, 0] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[3, 3, 1, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[3, 3, 1, 3] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[3, 3, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat1FMatrixFunction[3, 3, 3, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[3, 3, 3, 3] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {-1/2, 1/2, 1/Sqrt[2]}, {1/Sqrt[2], 1/Sqrt[2], 0}}
 
doubleS3sub6Cat1FMatrixFunction[3, 3, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat1FMatrixFunction[3, 3, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat1FMatrixFunction[3, 4, 1, 5] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[3, 4, 3, 4] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat1FMatrixFunction[3, 4, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat1FMatrixFunction[3, 4, 5, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[3, 5, 1, 2] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[3, 5, 1, 4] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[3, 5, 2, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[3, 5, 3, 5] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat1FMatrixFunction[3, 5, 5, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat1FMatrixFunction[4, 1, 2, 5] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[4, 1, 3, 5] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[4, 1, 4, 4] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[4, 1, 5, 3] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[4, 2, 1, 3] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[4, 2, 2, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat1FMatrixFunction[4, 2, 3, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[4, 2, 4, 2] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat1FMatrixFunction[4, 2, 5, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[4, 3, 1, 2] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[4, 3, 1, 5] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[4, 3, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat1FMatrixFunction[4, 3, 4, 3] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat1FMatrixFunction[4, 4, 1, 4] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[4, 4, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat1FMatrixFunction[4, 4, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat1FMatrixFunction[4, 4, 4, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[4, 4, 4, 4] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
doubleS3sub6Cat1FMatrixFunction[4, 4, 5, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat1FMatrixFunction[4, 5, 1, 3] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[4, 5, 2, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[4, 5, 4, 5] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat1FMatrixFunction[4, 5, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat1FMatrixFunction[5, 1, 2, 3] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[5, 1, 3, 4] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[5, 1, 4, 3] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[5, 1, 5, 5] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[5, 2, 1, 4] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[5, 2, 2, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat1FMatrixFunction[5, 2, 4, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[5, 2, 5, 2] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat1FMatrixFunction[5, 3, 1, 4] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[5, 3, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat1FMatrixFunction[5, 3, 5, 3] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat1FMatrixFunction[5, 4, 1, 2] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[5, 4, 1, 3] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[5, 4, 2, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[5, 4, 4, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat1FMatrixFunction[5, 4, 5, 4] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat1FMatrixFunction[5, 5, 1, 0] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[5, 5, 1, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[5, 5, 1, 5] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[5, 5, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat1FMatrixFunction[5, 5, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat1FMatrixFunction[5, 5, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat1FMatrixFunction[5, 5, 5, 1] = {{-1}}
 
doubleS3sub6Cat1FMatrixFunction[5, 5, 5, 5] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {-1/2, 1/2, 1/Sqrt[2]}, {1/Sqrt[2], 1/Sqrt[2], 0}}
 
doubleS3sub6Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3sub6Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
doubleS3sub6Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3sub6Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[doubleS3sub6Cat1Piv1] ^= {doubleS3sub6Cat1Bal1, 
    doubleS3sub6Cat1Bal2, doubleS3sub6Cat1Bal3, doubleS3sub6Cat1Bal4, 
    doubleS3sub6Cat1Bal5}
 
doubleS3sub6Cat1Piv1 /: balancedCategory[doubleS3sub6Cat1Piv1, 1] = 
    doubleS3sub6Cat1Bal1
 
doubleS3sub6Cat1Piv1 /: balancedCategory[doubleS3sub6Cat1Piv1, 2] = 
    doubleS3sub6Cat1Bal2
 
doubleS3sub6Cat1Piv1 /: balancedCategory[doubleS3sub6Cat1Piv1, 3] = 
    doubleS3sub6Cat1Bal3
 
doubleS3sub6Cat1Piv1 /: balancedCategory[doubleS3sub6Cat1Piv1, 4] = 
    doubleS3sub6Cat1Bal4
 
doubleS3sub6Cat1Piv1 /: balancedCategory[doubleS3sub6Cat1Piv1, 5] = 
    doubleS3sub6Cat1Bal5
 
fusionCategory[doubleS3sub6Cat1Piv1] ^= doubleS3sub6Cat1
 
doubleS3sub6Cat1Piv1 /: modularCategory[doubleS3sub6Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[doubleS3sub6Cat1Piv1] ^= doubleS3sub6Cat1Piv1
 
pivotalIsomorphism[doubleS3sub6Cat1Piv1] ^= 
   doubleS3sub6Cat1Piv1PivotalIsomorphism
 
doubleS3sub6Cat1Piv1 /: ribbonCategory[doubleS3sub6Cat1Piv1, 1] = 
    doubleS3sub6Cat1Bal1
 
doubleS3sub6Cat1Piv1 /: ribbonCategory[doubleS3sub6Cat1Piv1, 2] = 
    doubleS3sub6Cat1Bal2
 
doubleS3sub6Cat1Piv1 /: ribbonCategory[doubleS3sub6Cat1Piv1, 3] = 
    doubleS3sub6Cat1Bal3
 
doubleS3sub6Cat1Piv1 /: ribbonCategory[doubleS3sub6Cat1Piv1, 4] = 
    doubleS3sub6Cat1Bal4
 
doubleS3sub6Cat1Piv1 /: ribbonCategory[doubleS3sub6Cat1Piv1, 5] = 
    doubleS3sub6Cat1Bal5
 
ring[doubleS3sub6Cat1Piv1] ^= doubleS3sub6
 
sphericalCategory[doubleS3sub6Cat1Piv1] ^= doubleS3sub6Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[doubleS3sub6Cat1]][
      pivotalCategory[#1]] & )[doubleS3sub6Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[doubleS3sub6Cat1]][
      sphericalCategory[#1]] & )[doubleS3sub6Cat1Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[doubleS3sub6Cat1Piv1PivotalIsomorphism] ^= doubleS3sub6Cat1
 
pivotalCategory[doubleS3sub6Cat1Piv1PivotalIsomorphism] ^= 
   doubleS3sub6Cat1Piv1
 
pivotalIsomorphism[doubleS3sub6Cat1Piv1PivotalIsomorphism] ^= 
   doubleS3sub6Cat1Piv1PivotalIsomorphism
 
doubleS3sub6Cat1Piv1PivotalIsomorphism[0] = 1
 
doubleS3sub6Cat1Piv1PivotalIsomorphism[1] = 1
 
doubleS3sub6Cat1Piv1PivotalIsomorphism[2] = 1
 
doubleS3sub6Cat1Piv1PivotalIsomorphism[3] = 1
 
doubleS3sub6Cat1Piv1PivotalIsomorphism[4] = 1
 
doubleS3sub6Cat1Piv1PivotalIsomorphism[5] = 1
balancedCategories[doubleS3sub6Cat2] ^= {}
 
braidedCategories[doubleS3sub6Cat2] ^= {}
 
coeval[doubleS3sub6Cat2] ^= 1/sixJFunction[doubleS3sub6Cat2][#1, 
      dual[ring[doubleS3sub6Cat2]][#1], #1, #1, 0, 0] & 
 
eval[doubleS3sub6Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[doubleS3sub6Cat2] ^= doubleS3sub6Cat2FMatrixFunction
 
fusionCategory[doubleS3sub6Cat2] ^= doubleS3sub6Cat2
 
doubleS3sub6Cat2 /: modularCategory[doubleS3sub6Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[doubleS3sub6Cat2] ^= {doubleS3sub6Cat2Piv1}
 
doubleS3sub6Cat2 /: pivotalCategory[doubleS3sub6Cat2, 1] = 
    doubleS3sub6Cat2Piv1
 
doubleS3sub6Cat2 /: pivotalCategory[doubleS3sub6Cat2, {1, 1, 1, 1, 1, 1}] = 
    doubleS3sub6Cat2Piv1
 
ring[doubleS3sub6Cat2] ^= doubleS3sub6
 
doubleS3sub6Cat2 /: sphericalCategory[doubleS3sub6Cat2, 1] = 
    doubleS3sub6Cat2Piv1
 
fusionCategoryIndex[doubleS3sub6][doubleS3sub6Cat2] ^= 2
fMatrixFunction[doubleS3sub6Cat2FMatrixFunction] ^= 
   doubleS3sub6Cat2FMatrixFunction
 
fusionCategory[doubleS3sub6Cat2FMatrixFunction] ^= doubleS3sub6Cat2
 
ring[doubleS3sub6Cat2FMatrixFunction] ^= doubleS3sub6
 
doubleS3sub6Cat2FMatrixFunction[1, 2, 2, 2] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 2, 3, 5] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 2, 4, 3] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 2, 5, 4] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 3, 3, 0] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 3, 3, 3] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 3, 4, 2] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 3, 4, 5] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 3, 5, 4] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 4, 3, 5] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 4, 5, 2] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 4, 5, 3] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 5, 3, 2] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 5, 3, 4] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 5, 4, 3] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 5, 5, 0] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 5, 5, 1] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[1, 5, 5, 5] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[2, 1, 2, 2] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[2, 1, 3, 4] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[2, 1, 4, 5] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[2, 1, 5, 3] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[2, 2, 1, 2] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[2, 2, 2, 1] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
doubleS3sub6Cat2FMatrixFunction[2, 2, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat2FMatrixFunction[2, 2, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat2FMatrixFunction[2, 2, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat2FMatrixFunction[2, 3, 2, 3] = {{0, (-I/2)*(-I + Sqrt[3])}, 
    {(-I/2)*(-I + Sqrt[3]), 0}}
 
doubleS3sub6Cat2FMatrixFunction[2, 3, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[2, 3, 3, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat2FMatrixFunction[2, 3, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[2, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[2, 4, 2, 4] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat2FMatrixFunction[2, 4, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[2, 4, 4, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat2FMatrixFunction[2, 4, 5, 1] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[2, 4, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[2, 5, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[2, 5, 2, 5] = {{0, (I/2)*(I + Sqrt[3])}, 
    {(I/2)*(I + Sqrt[3]), 0}}
 
doubleS3sub6Cat2FMatrixFunction[2, 5, 3, 1] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[2, 5, 4, 1] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[2, 5, 5, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat2FMatrixFunction[2, 5, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[2, 5, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[3, 1, 2, 4] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[3, 1, 3, 3] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[3, 1, 4, 5] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[3, 1, 5, 4] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[3, 2, 1, 5] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[3, 2, 2, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat2FMatrixFunction[3, 2, 3, 2] = {{0, (I/2)*(I + Sqrt[3])}, 
    {(I/2)*(I + Sqrt[3]), 0}}
 
doubleS3sub6Cat2FMatrixFunction[3, 2, 4, 1] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[3, 2, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[3, 2, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[3, 2, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[3, 2, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[3, 3, 1, 0] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[3, 3, 1, 1] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[3, 3, 1, 3] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[3, 3, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat2FMatrixFunction[3, 3, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[3, 3, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[3, 3, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[3, 3, 3, 1] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3sub6Cat2FMatrixFunction[3, 3, 3, 3] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {-1/2, 1/2, 1/Sqrt[2]}, {(-1)^(2/3)/Sqrt[2], (-1)^(2/3)/Sqrt[2], 0}}
 
doubleS3sub6Cat2FMatrixFunction[3, 3, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat2FMatrixFunction[3, 3, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[3, 3, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[3, 3, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat2FMatrixFunction[3, 4, 1, 5] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[3, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[3, 4, 3, 4] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat2FMatrixFunction[3, 4, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[3, 4, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat2FMatrixFunction[3, 4, 5, 1] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[3, 5, 1, 2] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[3, 5, 1, 4] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[3, 5, 2, 1] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[3, 5, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[3, 5, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[3, 5, 3, 5] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat2FMatrixFunction[3, 5, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[3, 5, 5, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat2FMatrixFunction[3, 5, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[4, 1, 2, 5] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[4, 1, 3, 5] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[4, 1, 4, 4] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[4, 1, 5, 3] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[4, 2, 1, 3] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[4, 2, 2, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat2FMatrixFunction[4, 2, 3, 1] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[4, 2, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[4, 2, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[4, 2, 4, 2] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat2FMatrixFunction[4, 2, 5, 1] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[4, 2, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[4, 2, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[4, 3, 1, 2] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[4, 3, 1, 5] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[4, 3, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[4, 3, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat2FMatrixFunction[4, 3, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[4, 3, 4, 3] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat2FMatrixFunction[4, 3, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[4, 4, 1, 4] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[4, 4, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat2FMatrixFunction[4, 4, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat2FMatrixFunction[4, 4, 4, 1] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[4, 4, 4, 4] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
doubleS3sub6Cat2FMatrixFunction[4, 4, 5, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat2FMatrixFunction[4, 5, 1, 3] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[4, 5, 2, 1] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[4, 5, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[4, 5, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[4, 5, 4, 5] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat2FMatrixFunction[4, 5, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[4, 5, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat2FMatrixFunction[5, 1, 2, 3] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[5, 1, 3, 4] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[5, 1, 4, 3] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[5, 1, 5, 5] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[5, 2, 1, 4] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[5, 2, 2, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat2FMatrixFunction[5, 2, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 2, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 2, 4, 1] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[5, 2, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 2, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 2, 5, 2] = {{0, (-I/2)*(-I + Sqrt[3])}, 
    {(-I/2)*(-I + Sqrt[3]), 0}}
 
doubleS3sub6Cat2FMatrixFunction[5, 3, 1, 4] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[5, 3, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 3, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 3, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat2FMatrixFunction[5, 3, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 3, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 3, 5, 3] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat2FMatrixFunction[5, 3, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 4, 1, 2] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[5, 4, 1, 3] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[5, 4, 2, 1] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[5, 4, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 4, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 4, 4, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 4, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 4, 5, 4] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat2FMatrixFunction[5, 5, 1, 0] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[5, 5, 1, 1] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[5, 5, 1, 5] = {{-1}}
 
doubleS3sub6Cat2FMatrixFunction[5, 5, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 5, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 5, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat2FMatrixFunction[5, 5, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 5, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 5, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 5, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat2FMatrixFunction[5, 5, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat2FMatrixFunction[5, 5, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3sub6Cat2FMatrixFunction[5, 5, 5, 5] = 
   {{1/2, -1/2, -((-1)^(1/3)/Sqrt[2])}, {-1/2, 1/2, -((-1)^(1/3)/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2], 0}}
 
doubleS3sub6Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3sub6Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
doubleS3sub6Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3sub6Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[doubleS3sub6Cat2Piv1] ^= {}
 
fusionCategory[doubleS3sub6Cat2Piv1] ^= doubleS3sub6Cat2
 
doubleS3sub6Cat2Piv1 /: modularCategory[doubleS3sub6Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[doubleS3sub6Cat2Piv1] ^= doubleS3sub6Cat2Piv1
 
pivotalIsomorphism[doubleS3sub6Cat2Piv1] ^= 
   doubleS3sub6Cat2Piv1PivotalIsomorphism
 
ring[doubleS3sub6Cat2Piv1] ^= doubleS3sub6
 
sphericalCategory[doubleS3sub6Cat2Piv1] ^= doubleS3sub6Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[doubleS3sub6Cat2]][
      pivotalCategory[#1]] & )[doubleS3sub6Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[doubleS3sub6Cat2]][
      sphericalCategory[#1]] & )[doubleS3sub6Cat2Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[doubleS3sub6Cat2Piv1PivotalIsomorphism] ^= doubleS3sub6Cat2
 
pivotalCategory[doubleS3sub6Cat2Piv1PivotalIsomorphism] ^= 
   doubleS3sub6Cat2Piv1
 
pivotalIsomorphism[doubleS3sub6Cat2Piv1PivotalIsomorphism] ^= 
   doubleS3sub6Cat2Piv1PivotalIsomorphism
 
doubleS3sub6Cat2Piv1PivotalIsomorphism[0] = 1
 
doubleS3sub6Cat2Piv1PivotalIsomorphism[1] = 1
 
doubleS3sub6Cat2Piv1PivotalIsomorphism[2] = 1
 
doubleS3sub6Cat2Piv1PivotalIsomorphism[3] = 1
 
doubleS3sub6Cat2Piv1PivotalIsomorphism[4] = 1
 
doubleS3sub6Cat2Piv1PivotalIsomorphism[5] = 1
balancedCategories[doubleS3sub6Cat3] ^= {}
 
braidedCategories[doubleS3sub6Cat3] ^= {}
 
coeval[doubleS3sub6Cat3] ^= 1/sixJFunction[doubleS3sub6Cat3][#1, 
      dual[ring[doubleS3sub6Cat3]][#1], #1, #1, 0, 0] & 
 
eval[doubleS3sub6Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[doubleS3sub6Cat3] ^= doubleS3sub6Cat3FMatrixFunction
 
fusionCategory[doubleS3sub6Cat3] ^= doubleS3sub6Cat3
 
doubleS3sub6Cat3 /: modularCategory[doubleS3sub6Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[doubleS3sub6Cat3] ^= {doubleS3sub6Cat3Piv1}
 
doubleS3sub6Cat3 /: pivotalCategory[doubleS3sub6Cat3, 1] = 
    doubleS3sub6Cat3Piv1
 
doubleS3sub6Cat3 /: pivotalCategory[doubleS3sub6Cat3, {1, 1, 1, 1, 1, 1}] = 
    doubleS3sub6Cat3Piv1
 
ring[doubleS3sub6Cat3] ^= doubleS3sub6
 
doubleS3sub6Cat3 /: sphericalCategory[doubleS3sub6Cat3, 1] = 
    doubleS3sub6Cat3Piv1
 
fusionCategoryIndex[doubleS3sub6][doubleS3sub6Cat3] ^= 3
fMatrixFunction[doubleS3sub6Cat3FMatrixFunction] ^= 
   doubleS3sub6Cat3FMatrixFunction
 
fusionCategory[doubleS3sub6Cat3FMatrixFunction] ^= doubleS3sub6Cat3
 
ring[doubleS3sub6Cat3FMatrixFunction] ^= doubleS3sub6
 
doubleS3sub6Cat3FMatrixFunction[1, 2, 2, 2] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 2, 3, 5] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 2, 4, 3] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 2, 5, 4] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 3, 3, 0] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 3, 3, 3] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 3, 4, 2] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 3, 4, 5] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 3, 5, 4] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 4, 3, 5] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 4, 5, 2] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 4, 5, 3] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 5, 3, 2] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 5, 3, 4] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 5, 4, 3] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 5, 5, 0] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 5, 5, 1] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[1, 5, 5, 5] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[2, 1, 2, 2] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[2, 1, 3, 4] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[2, 1, 4, 5] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[2, 1, 5, 3] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[2, 2, 1, 2] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[2, 2, 2, 1] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
doubleS3sub6Cat3FMatrixFunction[2, 2, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat3FMatrixFunction[2, 2, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat3FMatrixFunction[2, 2, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat3FMatrixFunction[2, 3, 2, 3] = {{0, (I/2)*(I + Sqrt[3])}, 
    {(I/2)*(I + Sqrt[3]), 0}}
 
doubleS3sub6Cat3FMatrixFunction[2, 3, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[2, 3, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[2, 3, 3, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat3FMatrixFunction[2, 3, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[2, 3, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[2, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[2, 4, 2, 4] = {{0, (I/2)*(I + Sqrt[3])}, 
    {(I/2)*(I + Sqrt[3]), 0}}
 
doubleS3sub6Cat3FMatrixFunction[2, 4, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[2, 4, 4, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat3FMatrixFunction[2, 4, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[2, 4, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[2, 4, 5, 1] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[2, 4, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[2, 5, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[2, 5, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[2, 5, 2, 5] = {{0, (I/2)*(I + Sqrt[3])}, 
    {(I/2)*(I + Sqrt[3]), 0}}
 
doubleS3sub6Cat3FMatrixFunction[2, 5, 3, 1] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[2, 5, 4, 1] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[2, 5, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[2, 5, 5, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat3FMatrixFunction[2, 5, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[2, 5, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 1, 2, 4] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[3, 1, 3, 3] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[3, 1, 4, 5] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[3, 1, 5, 4] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[3, 2, 1, 5] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[3, 2, 2, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat3FMatrixFunction[3, 2, 3, 2] = {{0, (-I/2)*(-I + Sqrt[3])}, 
    {(-I/2)*(-I + Sqrt[3]), 0}}
 
doubleS3sub6Cat3FMatrixFunction[3, 2, 4, 1] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[3, 2, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 2, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 2, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 2, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 2, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 2, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 3, 1, 0] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[3, 3, 1, 1] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[3, 3, 1, 3] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[3, 3, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 3, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 3, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 3, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 3, 3, 1] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3sub6Cat3FMatrixFunction[3, 3, 3, 3] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {-1/2, 1/2, 1/Sqrt[2]}, {-((-1)^(1/3)/Sqrt[2]), -((-1)^(1/3)/Sqrt[2]), 0}}
 
doubleS3sub6Cat3FMatrixFunction[3, 3, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat3FMatrixFunction[3, 3, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 3, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 3, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat3FMatrixFunction[3, 4, 1, 5] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[3, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 4, 3, 4] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat3FMatrixFunction[3, 4, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 4, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 4, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 4, 5, 1] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[3, 4, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 5, 1, 2] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[3, 5, 1, 4] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[3, 5, 2, 1] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[3, 5, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 5, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 5, 3, 5] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat3FMatrixFunction[3, 5, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[3, 5, 5, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat3FMatrixFunction[3, 5, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 1, 2, 5] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[4, 1, 3, 5] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[4, 1, 4, 4] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[4, 1, 5, 3] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[4, 2, 1, 3] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[4, 2, 2, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 2, 3, 1] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[4, 2, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 2, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 2, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 2, 4, 2] = {{0, (-I/2)*(-I + Sqrt[3])}, 
    {(-I/2)*(-I + Sqrt[3]), 0}}
 
doubleS3sub6Cat3FMatrixFunction[4, 2, 5, 1] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[4, 2, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 2, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 2, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 3, 1, 2] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[4, 3, 1, 5] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[4, 3, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 3, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat3FMatrixFunction[4, 3, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 3, 4, 3] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat3FMatrixFunction[4, 3, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 3, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 3, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 4, 1, 4] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[4, 4, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 4, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 4, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 4, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 4, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 4, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3sub6Cat3FMatrixFunction[4, 4, 4, 4] = 
   {{1/2, 1/2, -((-1)^(1/3)/Sqrt[2])}, {1/2, 1/2, (-1)^(1/3)/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
doubleS3sub6Cat3FMatrixFunction[4, 4, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 4, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 4, 5, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 5, 1, 3] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[4, 5, 2, 1] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[4, 5, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 5, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 5, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 5, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 5, 4, 5] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat3FMatrixFunction[4, 5, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[4, 5, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat3FMatrixFunction[5, 1, 2, 3] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[5, 1, 3, 4] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[5, 1, 4, 3] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[5, 1, 5, 5] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[5, 2, 1, 4] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[5, 2, 2, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat3FMatrixFunction[5, 2, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 2, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 2, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 2, 4, 1] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[5, 2, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 2, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 2, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 2, 5, 2] = {{0, (-I/2)*(-I + Sqrt[3])}, 
    {(-I/2)*(-I + Sqrt[3]), 0}}
 
doubleS3sub6Cat3FMatrixFunction[5, 3, 1, 4] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[5, 3, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 3, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 3, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat3FMatrixFunction[5, 3, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 3, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 3, 5, 3] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat3FMatrixFunction[5, 3, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 4, 1, 2] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[5, 4, 1, 3] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[5, 4, 2, 1] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[5, 4, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 4, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 4, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 4, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 4, 4, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 4, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 4, 5, 4] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat3FMatrixFunction[5, 5, 1, 0] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[5, 5, 1, 1] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[5, 5, 1, 5] = {{-1}}
 
doubleS3sub6Cat3FMatrixFunction[5, 5, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 5, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 5, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat3FMatrixFunction[5, 5, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 5, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 5, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 5, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat3FMatrixFunction[5, 5, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat3FMatrixFunction[5, 5, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3sub6Cat3FMatrixFunction[5, 5, 5, 5] = 
   {{1/2, -1/2, -((-1)^(1/3)/Sqrt[2])}, {-1/2, 1/2, -((-1)^(1/3)/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2], 0}}
 
doubleS3sub6Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3sub6Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
doubleS3sub6Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3sub6Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[doubleS3sub6Cat3Piv1] ^= {}
 
fusionCategory[doubleS3sub6Cat3Piv1] ^= doubleS3sub6Cat3
 
doubleS3sub6Cat3Piv1 /: modularCategory[doubleS3sub6Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[doubleS3sub6Cat3Piv1] ^= doubleS3sub6Cat3Piv1
 
pivotalIsomorphism[doubleS3sub6Cat3Piv1] ^= 
   doubleS3sub6Cat3Piv1PivotalIsomorphism
 
ring[doubleS3sub6Cat3Piv1] ^= doubleS3sub6
 
sphericalCategory[doubleS3sub6Cat3Piv1] ^= doubleS3sub6Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[doubleS3sub6Cat3]][
      pivotalCategory[#1]] & )[doubleS3sub6Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[doubleS3sub6Cat3]][
      sphericalCategory[#1]] & )[doubleS3sub6Cat3Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[doubleS3sub6Cat3Piv1PivotalIsomorphism] ^= doubleS3sub6Cat3
 
pivotalCategory[doubleS3sub6Cat3Piv1PivotalIsomorphism] ^= 
   doubleS3sub6Cat3Piv1
 
pivotalIsomorphism[doubleS3sub6Cat3Piv1PivotalIsomorphism] ^= 
   doubleS3sub6Cat3Piv1PivotalIsomorphism
 
doubleS3sub6Cat3Piv1PivotalIsomorphism[0] = 1
 
doubleS3sub6Cat3Piv1PivotalIsomorphism[1] = 1
 
doubleS3sub6Cat3Piv1PivotalIsomorphism[2] = 1
 
doubleS3sub6Cat3Piv1PivotalIsomorphism[3] = 1
 
doubleS3sub6Cat3Piv1PivotalIsomorphism[4] = 1
 
doubleS3sub6Cat3Piv1PivotalIsomorphism[5] = 1
balancedCategories[doubleS3sub6Cat4] ^= {}
 
braidedCategories[doubleS3sub6Cat4] ^= {}
 
coeval[doubleS3sub6Cat4] ^= 1/sixJFunction[doubleS3sub6Cat4][#1, 
      dual[ring[doubleS3sub6Cat4]][#1], #1, #1, 0, 0] & 
 
eval[doubleS3sub6Cat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[doubleS3sub6Cat4] ^= doubleS3sub6Cat4FMatrixFunction
 
fusionCategory[doubleS3sub6Cat4] ^= doubleS3sub6Cat4
 
doubleS3sub6Cat4 /: modularCategory[doubleS3sub6Cat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[doubleS3sub6Cat4] ^= {doubleS3sub6Cat4Piv1}
 
doubleS3sub6Cat4 /: pivotalCategory[doubleS3sub6Cat4, 1] = 
    doubleS3sub6Cat4Piv1
 
doubleS3sub6Cat4 /: pivotalCategory[doubleS3sub6Cat4, {1, 1, 1, 1, 1, 1}] = 
    doubleS3sub6Cat4Piv1
 
ring[doubleS3sub6Cat4] ^= doubleS3sub6
 
doubleS3sub6Cat4 /: sphericalCategory[doubleS3sub6Cat4, 1] = 
    doubleS3sub6Cat4Piv1
 
fusionCategoryIndex[doubleS3sub6][doubleS3sub6Cat4] ^= 4
fMatrixFunction[doubleS3sub6Cat4FMatrixFunction] ^= 
   doubleS3sub6Cat4FMatrixFunction
 
fusionCategory[doubleS3sub6Cat4FMatrixFunction] ^= doubleS3sub6Cat4
 
ring[doubleS3sub6Cat4FMatrixFunction] ^= doubleS3sub6
 
doubleS3sub6Cat4FMatrixFunction[1, 2, 2, 2] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 2, 3, 5] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 2, 4, 3] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 2, 5, 4] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 3, 3, 0] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 3, 3, 3] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 3, 4, 2] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 3, 4, 5] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 3, 5, 4] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 4, 3, 5] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 4, 5, 2] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 4, 5, 3] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 5, 3, 2] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 5, 3, 4] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 5, 4, 3] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 5, 5, 0] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 5, 5, 1] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[1, 5, 5, 5] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[2, 1, 2, 2] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[2, 1, 3, 4] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[2, 1, 4, 5] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[2, 1, 5, 3] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[2, 2, 1, 2] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[2, 2, 2, 1] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[2, 2, 2, 2] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
doubleS3sub6Cat4FMatrixFunction[2, 2, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat4FMatrixFunction[2, 2, 4, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat4FMatrixFunction[2, 2, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat4FMatrixFunction[2, 3, 2, 3] = {{0, (-I/2)*(-I + Sqrt[3])}, 
    {(-I/2)*(-I + Sqrt[3]), 0}}
 
doubleS3sub6Cat4FMatrixFunction[2, 3, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[2, 3, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[2, 3, 3, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat4FMatrixFunction[2, 3, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[2, 3, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[2, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[2, 4, 2, 4] = {{0, (-I/2)*(-I + Sqrt[3])}, 
    {(-I/2)*(-I + Sqrt[3]), 0}}
 
doubleS3sub6Cat4FMatrixFunction[2, 4, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[2, 4, 4, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat4FMatrixFunction[2, 4, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[2, 4, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[2, 4, 5, 1] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[2, 4, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[2, 5, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[2, 5, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[2, 5, 2, 5] = {{0, (-I/2)*(-I + Sqrt[3])}, 
    {(-I/2)*(-I + Sqrt[3]), 0}}
 
doubleS3sub6Cat4FMatrixFunction[2, 5, 3, 1] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[2, 5, 4, 1] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[2, 5, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[2, 5, 5, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat4FMatrixFunction[2, 5, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[2, 5, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 1, 2, 4] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[3, 1, 3, 3] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[3, 1, 4, 5] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[3, 1, 5, 4] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[3, 2, 1, 5] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[3, 2, 2, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat4FMatrixFunction[3, 2, 3, 2] = {{0, (I/2)*(I + Sqrt[3])}, 
    {(I/2)*(I + Sqrt[3]), 0}}
 
doubleS3sub6Cat4FMatrixFunction[3, 2, 4, 1] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[3, 2, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 2, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 2, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 2, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 2, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 2, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 3, 1, 0] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[3, 3, 1, 1] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[3, 3, 1, 3] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[3, 3, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 3, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 3, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 3, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 3, 3, 1] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3sub6Cat4FMatrixFunction[3, 3, 3, 3] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {-1/2, 1/2, 1/Sqrt[2]}, {(-1)^(2/3)/Sqrt[2], (-1)^(2/3)/Sqrt[2], 0}}
 
doubleS3sub6Cat4FMatrixFunction[3, 3, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat4FMatrixFunction[3, 3, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 3, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 3, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat4FMatrixFunction[3, 4, 1, 5] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[3, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 4, 3, 4] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat4FMatrixFunction[3, 4, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 4, 4, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 4, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 4, 5, 1] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[3, 4, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 5, 1, 2] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[3, 5, 1, 4] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[3, 5, 2, 1] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[3, 5, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 5, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 5, 3, 5] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat4FMatrixFunction[3, 5, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[3, 5, 5, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat4FMatrixFunction[3, 5, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 1, 2, 5] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[4, 1, 3, 5] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[4, 1, 4, 4] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[4, 1, 5, 3] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[4, 2, 1, 3] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[4, 2, 2, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 2, 3, 1] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[4, 2, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 2, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 2, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 2, 4, 2] = {{0, (I/2)*(I + Sqrt[3])}, 
    {(I/2)*(I + Sqrt[3]), 0}}
 
doubleS3sub6Cat4FMatrixFunction[4, 2, 5, 1] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[4, 2, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 2, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 2, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 3, 1, 2] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[4, 3, 1, 5] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[4, 3, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 3, 3, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat4FMatrixFunction[4, 3, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 3, 4, 3] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat4FMatrixFunction[4, 3, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 3, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 3, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 4, 1, 4] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[4, 4, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 4, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 4, 3, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 4, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 4, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 4, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3sub6Cat4FMatrixFunction[4, 4, 4, 4] = 
   {{1/2, 1/2, (-1)^(2/3)/Sqrt[2]}, {1/2, 1/2, -((-1)^(2/3)/Sqrt[2])}, 
    {1/Sqrt[2], -(1/Sqrt[2]), 0}}
 
doubleS3sub6Cat4FMatrixFunction[4, 4, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 4, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 4, 5, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 5, 1, 3] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[4, 5, 2, 1] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[4, 5, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 5, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 5, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 5, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 5, 4, 5] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat4FMatrixFunction[4, 5, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[4, 5, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat4FMatrixFunction[5, 1, 2, 3] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[5, 1, 3, 4] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[5, 1, 4, 3] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[5, 1, 5, 5] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[5, 2, 1, 4] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[5, 2, 2, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat4FMatrixFunction[5, 2, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 2, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 2, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 2, 4, 1] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[5, 2, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 2, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 2, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 2, 5, 2] = {{0, (I/2)*(I + Sqrt[3])}, 
    {(I/2)*(I + Sqrt[3]), 0}}
 
doubleS3sub6Cat4FMatrixFunction[5, 3, 1, 4] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[5, 3, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 3, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 3, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat4FMatrixFunction[5, 3, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 3, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 3, 5, 3] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat4FMatrixFunction[5, 3, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 4, 1, 2] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[5, 4, 1, 3] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[5, 4, 2, 1] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[5, 4, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 4, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 4, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 4, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 4, 4, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 4, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 4, 5, 4] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat4FMatrixFunction[5, 5, 1, 0] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[5, 5, 1, 1] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[5, 5, 1, 5] = {{-1}}
 
doubleS3sub6Cat4FMatrixFunction[5, 5, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 5, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 5, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat4FMatrixFunction[5, 5, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 5, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 5, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 5, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat4FMatrixFunction[5, 5, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat4FMatrixFunction[5, 5, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3sub6Cat4FMatrixFunction[5, 5, 5, 5] = 
   {{1/2, -1/2, (-1)^(2/3)/Sqrt[2]}, {-1/2, 1/2, (-1)^(2/3)/Sqrt[2]}, 
    {1/Sqrt[2], 1/Sqrt[2], 0}}
 
doubleS3sub6Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3sub6Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
doubleS3sub6Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3sub6Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[doubleS3sub6Cat4Piv1] ^= {}
 
fusionCategory[doubleS3sub6Cat4Piv1] ^= doubleS3sub6Cat4
 
doubleS3sub6Cat4Piv1 /: modularCategory[doubleS3sub6Cat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[doubleS3sub6Cat4Piv1] ^= doubleS3sub6Cat4Piv1
 
pivotalIsomorphism[doubleS3sub6Cat4Piv1] ^= 
   doubleS3sub6Cat4Piv1PivotalIsomorphism
 
ring[doubleS3sub6Cat4Piv1] ^= doubleS3sub6
 
sphericalCategory[doubleS3sub6Cat4Piv1] ^= doubleS3sub6Cat4Piv1
 
(pivotalCategoryIndex[fusionCategory[doubleS3sub6Cat4]][
      pivotalCategory[#1]] & )[doubleS3sub6Cat4Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[doubleS3sub6Cat4]][
      sphericalCategory[#1]] & )[doubleS3sub6Cat4Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[doubleS3sub6Cat4Piv1PivotalIsomorphism] ^= doubleS3sub6Cat4
 
pivotalCategory[doubleS3sub6Cat4Piv1PivotalIsomorphism] ^= 
   doubleS3sub6Cat4Piv1
 
pivotalIsomorphism[doubleS3sub6Cat4Piv1PivotalIsomorphism] ^= 
   doubleS3sub6Cat4Piv1PivotalIsomorphism
 
doubleS3sub6Cat4Piv1PivotalIsomorphism[0] = 1
 
doubleS3sub6Cat4Piv1PivotalIsomorphism[1] = 1
 
doubleS3sub6Cat4Piv1PivotalIsomorphism[2] = 1
 
doubleS3sub6Cat4Piv1PivotalIsomorphism[3] = 1
 
doubleS3sub6Cat4Piv1PivotalIsomorphism[4] = 1
 
doubleS3sub6Cat4Piv1PivotalIsomorphism[5] = 1
balancedCategories[doubleS3sub6Cat5] ^= {}
 
braidedCategories[doubleS3sub6Cat5] ^= {}
 
coeval[doubleS3sub6Cat5] ^= 1/sixJFunction[doubleS3sub6Cat5][#1, 
      dual[ring[doubleS3sub6Cat5]][#1], #1, #1, 0, 0] & 
 
eval[doubleS3sub6Cat5] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[doubleS3sub6Cat5] ^= doubleS3sub6Cat5FMatrixFunction
 
fusionCategory[doubleS3sub6Cat5] ^= doubleS3sub6Cat5
 
doubleS3sub6Cat5 /: modularCategory[doubleS3sub6Cat5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[doubleS3sub6Cat5] ^= {doubleS3sub6Cat5Piv1}
 
doubleS3sub6Cat5 /: pivotalCategory[doubleS3sub6Cat5, 1] = 
    doubleS3sub6Cat5Piv1
 
doubleS3sub6Cat5 /: pivotalCategory[doubleS3sub6Cat5, {1, 1, 1, 1, 1, 1}] = 
    doubleS3sub6Cat5Piv1
 
ring[doubleS3sub6Cat5] ^= doubleS3sub6
 
doubleS3sub6Cat5 /: sphericalCategory[doubleS3sub6Cat5, 1] = 
    doubleS3sub6Cat5Piv1
 
fusionCategoryIndex[doubleS3sub6][doubleS3sub6Cat5] ^= 5
fMatrixFunction[doubleS3sub6Cat5FMatrixFunction] ^= 
   doubleS3sub6Cat5FMatrixFunction
 
fusionCategory[doubleS3sub6Cat5FMatrixFunction] ^= doubleS3sub6Cat5
 
ring[doubleS3sub6Cat5FMatrixFunction] ^= doubleS3sub6
 
doubleS3sub6Cat5FMatrixFunction[1, 2, 2, 2] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 2, 3, 5] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 2, 4, 3] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 2, 5, 4] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 3, 3, 0] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 3, 3, 1] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 3, 3, 3] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 3, 4, 2] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 3, 4, 5] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 3, 5, 4] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 4, 3, 5] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 4, 5, 2] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 4, 5, 3] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 5, 3, 2] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 5, 3, 4] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 5, 4, 3] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 5, 5, 0] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 5, 5, 1] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[1, 5, 5, 5] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[2, 1, 2, 2] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[2, 1, 3, 4] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[2, 1, 4, 5] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[2, 1, 5, 3] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[2, 2, 1, 2] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[2, 2, 2, 0] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 2, 2, 1] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3sub6Cat5FMatrixFunction[2, 2, 2, 2] = 
   {{1/2, 1/2, (-1)^(2/3)/Sqrt[2]}, {1/2, 1/2, -((-1)^(2/3)/Sqrt[2])}, 
    {(-1)^(2/3)/Sqrt[2], -((-1)^(2/3)/Sqrt[2]), 0}}
 
doubleS3sub6Cat5FMatrixFunction[2, 2, 3, 3] = 
   {{(-1)^(2/3)/Sqrt[2], -((-1)^(2/3)/Sqrt[2])}, {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat5FMatrixFunction[2, 2, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 2, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 2, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 2, 4, 4] = 
   {{(-1)^(2/3)/Sqrt[2], (-1)^(2/3)/Sqrt[2]}, {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 2, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 2, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat5FMatrixFunction[2, 3, 2, 3] = 
   {{0, 1}, {(I/2)*(I + Sqrt[3]), 0}}
 
doubleS3sub6Cat5FMatrixFunction[2, 3, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 3, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 3, 3, 2] = 
   {{-((-1)^(1/3)/Sqrt[2]), 1/Sqrt[2]}, {-((-1)^(1/3)/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 3, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 3, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 4, 2, 4] = 
   {{0, 1}, {(I/2)*(I + Sqrt[3]), 0}}
 
doubleS3sub6Cat5FMatrixFunction[2, 4, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 4, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 4, 4, 2] = 
   {{-((-1)^(1/3)/Sqrt[2]), 1/Sqrt[2]}, {-((-1)^(1/3)/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 4, 5, 1] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[2, 4, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 5, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 5, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 5, 2, 5] = {{0, (I/2)*(I + Sqrt[3])}, 
    {(I/2)*(I + Sqrt[3]), 0}}
 
doubleS3sub6Cat5FMatrixFunction[2, 5, 3, 1] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[2, 5, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 5, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 5, 4, 1] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[2, 5, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 5, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 5, 5, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 5, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[2, 5, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 1, 2, 4] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[3, 1, 3, 3] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[3, 1, 4, 5] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[3, 1, 5, 4] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[3, 2, 1, 5] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[3, 2, 2, 3] = 
   {{-((-1)^(1/3)/Sqrt[2]), 1/Sqrt[2]}, {(-1)^(1/3)/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat5FMatrixFunction[3, 2, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 2, 3, 2] = {{0, (-I/2)*(-I + Sqrt[3])}, 
    {1, 0}}
 
doubleS3sub6Cat5FMatrixFunction[3, 2, 4, 1] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[3, 2, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 2, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 2, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 2, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 2, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 3, 1, 0] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[3, 3, 1, 1] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[3, 3, 1, 3] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[3, 3, 2, 2] = 
   {{(-1)^(2/3)/Sqrt[2], (-1)^(2/3)/Sqrt[2]}, {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 3, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 3, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 3, 3, 1] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3sub6Cat5FMatrixFunction[3, 3, 3, 3] = {{1/2, -1/2, 1/Sqrt[2]}, 
    {-1/2, 1/2, 1/Sqrt[2]}, {(-1)^(2/3)/Sqrt[2], (-1)^(2/3)/Sqrt[2], 0}}
 
doubleS3sub6Cat5FMatrixFunction[3, 3, 4, 4] = 
   {{(-1)^(2/3)/Sqrt[2], -((-1)^(2/3)/Sqrt[2])}, {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat5FMatrixFunction[3, 3, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 3, 5, 5] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat5FMatrixFunction[3, 4, 1, 5] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[3, 4, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 4, 3, 4] = {{0, (I/2)*(I + Sqrt[3])}, 
    {(-I/2)*(-I + Sqrt[3]), 0}}
 
doubleS3sub6Cat5FMatrixFunction[3, 4, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 4, 4, 3] = 
   {{-((-1)^(1/3)/Sqrt[2]), 1/Sqrt[2]}, {-((-1)^(1/3)/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 4, 5, 1] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[3, 4, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 5, 1, 2] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[3, 5, 1, 4] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[3, 5, 2, 1] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[3, 5, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 5, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 5, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 5, 3, 5] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat5FMatrixFunction[3, 5, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 5, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 5, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[3, 5, 5, 3] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat5FMatrixFunction[3, 5, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 1, 2, 5] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[4, 1, 3, 5] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[4, 1, 4, 4] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[4, 1, 5, 3] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[4, 2, 1, 3] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[4, 2, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 2, 2, 4] = 
   {{-((-1)^(1/3)/Sqrt[2]), 1/Sqrt[2]}, {-((-1)^(1/3)/Sqrt[2]), -(1/Sqrt[2])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 2, 3, 1] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[4, 2, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 2, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 2, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 2, 4, 2] = {{0, (-I/2)*(-I + Sqrt[3])}, 
    {1, 0}}
 
doubleS3sub6Cat5FMatrixFunction[4, 2, 5, 1] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[4, 2, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 2, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 3, 1, 2] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[4, 3, 1, 5] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[4, 3, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 3, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 3, 3, 4] = 
   {{-((-1)^(1/3)/Sqrt[2]), 1/Sqrt[2]}, {(-1)^(1/3)/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat5FMatrixFunction[4, 3, 4, 3] = {{0, (I/2)*(I + Sqrt[3])}, 
    {(-I/2)*(-I + Sqrt[3]), 0}}
 
doubleS3sub6Cat5FMatrixFunction[4, 3, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 3, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 4, 1, 4] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[4, 4, 2, 2] = 
   {{(-1)^(2/3)/Sqrt[2], (-1)^(2/3)/Sqrt[2]}, {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 4, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 4, 3, 3] = 
   {{(-1)^(2/3)/Sqrt[2], (-1)^(2/3)/Sqrt[2]}, {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 4, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 4, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 4, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
doubleS3sub6Cat5FMatrixFunction[4, 4, 4, 4] = {{1/2, 1/2, 1/Sqrt[2]}, 
    {1/2, 1/2, -(1/Sqrt[2])}, {(-1)^(2/3)/Sqrt[2], -((-1)^(2/3)/Sqrt[2]), 0}}
 
doubleS3sub6Cat5FMatrixFunction[4, 4, 5, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 5, 1, 3] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[4, 5, 2, 1] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[4, 5, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 5, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 5, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 5, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 5, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 5, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 5, 4, 5] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat5FMatrixFunction[4, 5, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[4, 5, 5, 4] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat5FMatrixFunction[5, 1, 2, 3] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[5, 1, 3, 4] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[5, 1, 4, 3] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[5, 1, 5, 5] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[5, 2, 1, 4] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[5, 2, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 2, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 2, 2, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat5FMatrixFunction[5, 2, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 2, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 2, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 2, 4, 1] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[5, 2, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 2, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 2, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 2, 5, 2] = {{0, (-I/2)*(-I + Sqrt[3])}, 
    {(-I/2)*(-I + Sqrt[3]), 0}}
 
doubleS3sub6Cat5FMatrixFunction[5, 3, 1, 4] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[5, 3, 2, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 3, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 3, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 3, 3, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {-(1/Sqrt[2]), 1/Sqrt[2]}}
 
doubleS3sub6Cat5FMatrixFunction[5, 3, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 3, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 3, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 3, 5, 3] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat5FMatrixFunction[5, 3, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 4, 1, 2] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[5, 4, 1, 3] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[5, 4, 2, 1] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[5, 4, 2, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[5, 4, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 4, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 4, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 4, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 4, 4, 5] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 4, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 4, 5, 4] = {{0, 1}, {1, 0}}
 
doubleS3sub6Cat5FMatrixFunction[5, 5, 1, 0] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[5, 5, 1, 1] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[5, 5, 1, 5] = {{-1}}
 
doubleS3sub6Cat5FMatrixFunction[5, 5, 2, 2] = {{1/Sqrt[2], 1/Sqrt[2]}, 
    {1/Sqrt[2], -(1/Sqrt[2])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 5, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 5, 3, 3] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat5FMatrixFunction[5, 5, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 5, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 5, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 5, 4, 4] = {{1/Sqrt[2], -(1/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2]}}
 
doubleS3sub6Cat5FMatrixFunction[5, 5, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
doubleS3sub6Cat5FMatrixFunction[5, 5, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
doubleS3sub6Cat5FMatrixFunction[5, 5, 5, 5] = 
   {{1/2, -1/2, -((-1)^(1/3)/Sqrt[2])}, {-1/2, 1/2, -((-1)^(1/3)/Sqrt[2])}, 
    {1/Sqrt[2], 1/Sqrt[2], 0}}
 
doubleS3sub6Cat5FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3sub6Cat5], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
doubleS3sub6Cat5FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[doubleS3sub6Cat5], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[doubleS3sub6Cat5Piv1] ^= {}
 
fusionCategory[doubleS3sub6Cat5Piv1] ^= doubleS3sub6Cat5
 
doubleS3sub6Cat5Piv1 /: modularCategory[doubleS3sub6Cat5Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[doubleS3sub6Cat5Piv1] ^= doubleS3sub6Cat5Piv1
 
pivotalIsomorphism[doubleS3sub6Cat5Piv1] ^= 
   doubleS3sub6Cat5Piv1PivotalIsomorphism
 
ring[doubleS3sub6Cat5Piv1] ^= doubleS3sub6
 
sphericalCategory[doubleS3sub6Cat5Piv1] ^= doubleS3sub6Cat5Piv1
 
(pivotalCategoryIndex[fusionCategory[doubleS3sub6Cat5]][
      pivotalCategory[#1]] & )[doubleS3sub6Cat5Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[doubleS3sub6Cat5]][
      sphericalCategory[#1]] & )[doubleS3sub6Cat5Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[doubleS3sub6Cat5Piv1PivotalIsomorphism] ^= doubleS3sub6Cat5
 
pivotalCategory[doubleS3sub6Cat5Piv1PivotalIsomorphism] ^= 
   doubleS3sub6Cat5Piv1
 
pivotalIsomorphism[doubleS3sub6Cat5Piv1PivotalIsomorphism] ^= 
   doubleS3sub6Cat5Piv1PivotalIsomorphism
 
doubleS3sub6Cat5Piv1PivotalIsomorphism[0] = 1
 
doubleS3sub6Cat5Piv1PivotalIsomorphism[1] = 1
 
doubleS3sub6Cat5Piv1PivotalIsomorphism[2] = 1
 
doubleS3sub6Cat5Piv1PivotalIsomorphism[3] = 1
 
doubleS3sub6Cat5Piv1PivotalIsomorphism[4] = 1
 
doubleS3sub6Cat5Piv1PivotalIsomorphism[5] = 1
ring[doubleS3sub6NFunction] ^= doubleS3sub6
 
doubleS3sub6NFunction[0, 0, 0] = 1
 
doubleS3sub6NFunction[0, 0, 1] = 0
 
doubleS3sub6NFunction[0, 0, 2] = 0
 
doubleS3sub6NFunction[0, 0, 3] = 0
 
doubleS3sub6NFunction[0, 0, 4] = 0
 
doubleS3sub6NFunction[0, 0, 5] = 0
 
doubleS3sub6NFunction[0, 1, 0] = 0
 
doubleS3sub6NFunction[0, 1, 1] = 1
 
doubleS3sub6NFunction[0, 1, 2] = 0
 
doubleS3sub6NFunction[0, 1, 3] = 0
 
doubleS3sub6NFunction[0, 1, 4] = 0
 
doubleS3sub6NFunction[0, 1, 5] = 0
 
doubleS3sub6NFunction[0, 2, 0] = 0
 
doubleS3sub6NFunction[0, 2, 1] = 0
 
doubleS3sub6NFunction[0, 2, 2] = 1
 
doubleS3sub6NFunction[0, 2, 3] = 0
 
doubleS3sub6NFunction[0, 2, 4] = 0
 
doubleS3sub6NFunction[0, 2, 5] = 0
 
doubleS3sub6NFunction[0, 3, 0] = 0
 
doubleS3sub6NFunction[0, 3, 1] = 0
 
doubleS3sub6NFunction[0, 3, 2] = 0
 
doubleS3sub6NFunction[0, 3, 3] = 1
 
doubleS3sub6NFunction[0, 3, 4] = 0
 
doubleS3sub6NFunction[0, 3, 5] = 0
 
doubleS3sub6NFunction[0, 4, 0] = 0
 
doubleS3sub6NFunction[0, 4, 1] = 0
 
doubleS3sub6NFunction[0, 4, 2] = 0
 
doubleS3sub6NFunction[0, 4, 3] = 0
 
doubleS3sub6NFunction[0, 4, 4] = 1
 
doubleS3sub6NFunction[0, 4, 5] = 0
 
doubleS3sub6NFunction[0, 5, 0] = 0
 
doubleS3sub6NFunction[0, 5, 1] = 0
 
doubleS3sub6NFunction[0, 5, 2] = 0
 
doubleS3sub6NFunction[0, 5, 3] = 0
 
doubleS3sub6NFunction[0, 5, 4] = 0
 
doubleS3sub6NFunction[0, 5, 5] = 1
 
doubleS3sub6NFunction[1, 0, 0] = 0
 
doubleS3sub6NFunction[1, 0, 1] = 1
 
doubleS3sub6NFunction[1, 0, 2] = 0
 
doubleS3sub6NFunction[1, 0, 3] = 0
 
doubleS3sub6NFunction[1, 0, 4] = 0
 
doubleS3sub6NFunction[1, 0, 5] = 0
 
doubleS3sub6NFunction[1, 1, 0] = 1
 
doubleS3sub6NFunction[1, 1, 1] = 0
 
doubleS3sub6NFunction[1, 1, 2] = 0
 
doubleS3sub6NFunction[1, 1, 3] = 0
 
doubleS3sub6NFunction[1, 1, 4] = 0
 
doubleS3sub6NFunction[1, 1, 5] = 0
 
doubleS3sub6NFunction[1, 2, 0] = 0
 
doubleS3sub6NFunction[1, 2, 1] = 0
 
doubleS3sub6NFunction[1, 2, 2] = 1
 
doubleS3sub6NFunction[1, 2, 3] = 0
 
doubleS3sub6NFunction[1, 2, 4] = 0
 
doubleS3sub6NFunction[1, 2, 5] = 0
 
doubleS3sub6NFunction[1, 3, 0] = 0
 
doubleS3sub6NFunction[1, 3, 1] = 0
 
doubleS3sub6NFunction[1, 3, 2] = 0
 
doubleS3sub6NFunction[1, 3, 3] = 1
 
doubleS3sub6NFunction[1, 3, 4] = 0
 
doubleS3sub6NFunction[1, 3, 5] = 0
 
doubleS3sub6NFunction[1, 4, 0] = 0
 
doubleS3sub6NFunction[1, 4, 1] = 0
 
doubleS3sub6NFunction[1, 4, 2] = 0
 
doubleS3sub6NFunction[1, 4, 3] = 0
 
doubleS3sub6NFunction[1, 4, 4] = 1
 
doubleS3sub6NFunction[1, 4, 5] = 0
 
doubleS3sub6NFunction[1, 5, 0] = 0
 
doubleS3sub6NFunction[1, 5, 1] = 0
 
doubleS3sub6NFunction[1, 5, 2] = 0
 
doubleS3sub6NFunction[1, 5, 3] = 0
 
doubleS3sub6NFunction[1, 5, 4] = 0
 
doubleS3sub6NFunction[1, 5, 5] = 1
 
doubleS3sub6NFunction[2, 0, 0] = 0
 
doubleS3sub6NFunction[2, 0, 1] = 0
 
doubleS3sub6NFunction[2, 0, 2] = 1
 
doubleS3sub6NFunction[2, 0, 3] = 0
 
doubleS3sub6NFunction[2, 0, 4] = 0
 
doubleS3sub6NFunction[2, 0, 5] = 0
 
doubleS3sub6NFunction[2, 1, 0] = 0
 
doubleS3sub6NFunction[2, 1, 1] = 0
 
doubleS3sub6NFunction[2, 1, 2] = 1
 
doubleS3sub6NFunction[2, 1, 3] = 0
 
doubleS3sub6NFunction[2, 1, 4] = 0
 
doubleS3sub6NFunction[2, 1, 5] = 0
 
doubleS3sub6NFunction[2, 2, 0] = 1
 
doubleS3sub6NFunction[2, 2, 1] = 1
 
doubleS3sub6NFunction[2, 2, 2] = 1
 
doubleS3sub6NFunction[2, 2, 3] = 0
 
doubleS3sub6NFunction[2, 2, 4] = 0
 
doubleS3sub6NFunction[2, 2, 5] = 0
 
doubleS3sub6NFunction[2, 3, 0] = 0
 
doubleS3sub6NFunction[2, 3, 1] = 0
 
doubleS3sub6NFunction[2, 3, 2] = 0
 
doubleS3sub6NFunction[2, 3, 3] = 0
 
doubleS3sub6NFunction[2, 3, 4] = 1
 
doubleS3sub6NFunction[2, 3, 5] = 1
 
doubleS3sub6NFunction[2, 4, 0] = 0
 
doubleS3sub6NFunction[2, 4, 1] = 0
 
doubleS3sub6NFunction[2, 4, 2] = 0
 
doubleS3sub6NFunction[2, 4, 3] = 1
 
doubleS3sub6NFunction[2, 4, 4] = 0
 
doubleS3sub6NFunction[2, 4, 5] = 1
 
doubleS3sub6NFunction[2, 5, 0] = 0
 
doubleS3sub6NFunction[2, 5, 1] = 0
 
doubleS3sub6NFunction[2, 5, 2] = 0
 
doubleS3sub6NFunction[2, 5, 3] = 1
 
doubleS3sub6NFunction[2, 5, 4] = 1
 
doubleS3sub6NFunction[2, 5, 5] = 0
 
doubleS3sub6NFunction[3, 0, 0] = 0
 
doubleS3sub6NFunction[3, 0, 1] = 0
 
doubleS3sub6NFunction[3, 0, 2] = 0
 
doubleS3sub6NFunction[3, 0, 3] = 1
 
doubleS3sub6NFunction[3, 0, 4] = 0
 
doubleS3sub6NFunction[3, 0, 5] = 0
 
doubleS3sub6NFunction[3, 1, 0] = 0
 
doubleS3sub6NFunction[3, 1, 1] = 0
 
doubleS3sub6NFunction[3, 1, 2] = 0
 
doubleS3sub6NFunction[3, 1, 3] = 1
 
doubleS3sub6NFunction[3, 1, 4] = 0
 
doubleS3sub6NFunction[3, 1, 5] = 0
 
doubleS3sub6NFunction[3, 2, 0] = 0
 
doubleS3sub6NFunction[3, 2, 1] = 0
 
doubleS3sub6NFunction[3, 2, 2] = 0
 
doubleS3sub6NFunction[3, 2, 3] = 0
 
doubleS3sub6NFunction[3, 2, 4] = 1
 
doubleS3sub6NFunction[3, 2, 5] = 1
 
doubleS3sub6NFunction[3, 3, 0] = 1
 
doubleS3sub6NFunction[3, 3, 1] = 1
 
doubleS3sub6NFunction[3, 3, 2] = 0
 
doubleS3sub6NFunction[3, 3, 3] = 1
 
doubleS3sub6NFunction[3, 3, 4] = 0
 
doubleS3sub6NFunction[3, 3, 5] = 0
 
doubleS3sub6NFunction[3, 4, 0] = 0
 
doubleS3sub6NFunction[3, 4, 1] = 0
 
doubleS3sub6NFunction[3, 4, 2] = 1
 
doubleS3sub6NFunction[3, 4, 3] = 0
 
doubleS3sub6NFunction[3, 4, 4] = 0
 
doubleS3sub6NFunction[3, 4, 5] = 1
 
doubleS3sub6NFunction[3, 5, 0] = 0
 
doubleS3sub6NFunction[3, 5, 1] = 0
 
doubleS3sub6NFunction[3, 5, 2] = 1
 
doubleS3sub6NFunction[3, 5, 3] = 0
 
doubleS3sub6NFunction[3, 5, 4] = 1
 
doubleS3sub6NFunction[3, 5, 5] = 0
 
doubleS3sub6NFunction[4, 0, 0] = 0
 
doubleS3sub6NFunction[4, 0, 1] = 0
 
doubleS3sub6NFunction[4, 0, 2] = 0
 
doubleS3sub6NFunction[4, 0, 3] = 0
 
doubleS3sub6NFunction[4, 0, 4] = 1
 
doubleS3sub6NFunction[4, 0, 5] = 0
 
doubleS3sub6NFunction[4, 1, 0] = 0
 
doubleS3sub6NFunction[4, 1, 1] = 0
 
doubleS3sub6NFunction[4, 1, 2] = 0
 
doubleS3sub6NFunction[4, 1, 3] = 0
 
doubleS3sub6NFunction[4, 1, 4] = 1
 
doubleS3sub6NFunction[4, 1, 5] = 0
 
doubleS3sub6NFunction[4, 2, 0] = 0
 
doubleS3sub6NFunction[4, 2, 1] = 0
 
doubleS3sub6NFunction[4, 2, 2] = 0
 
doubleS3sub6NFunction[4, 2, 3] = 1
 
doubleS3sub6NFunction[4, 2, 4] = 0
 
doubleS3sub6NFunction[4, 2, 5] = 1
 
doubleS3sub6NFunction[4, 3, 0] = 0
 
doubleS3sub6NFunction[4, 3, 1] = 0
 
doubleS3sub6NFunction[4, 3, 2] = 1
 
doubleS3sub6NFunction[4, 3, 3] = 0
 
doubleS3sub6NFunction[4, 3, 4] = 0
 
doubleS3sub6NFunction[4, 3, 5] = 1
 
doubleS3sub6NFunction[4, 4, 0] = 1
 
doubleS3sub6NFunction[4, 4, 1] = 1
 
doubleS3sub6NFunction[4, 4, 2] = 0
 
doubleS3sub6NFunction[4, 4, 3] = 0
 
doubleS3sub6NFunction[4, 4, 4] = 1
 
doubleS3sub6NFunction[4, 4, 5] = 0
 
doubleS3sub6NFunction[4, 5, 0] = 0
 
doubleS3sub6NFunction[4, 5, 1] = 0
 
doubleS3sub6NFunction[4, 5, 2] = 1
 
doubleS3sub6NFunction[4, 5, 3] = 1
 
doubleS3sub6NFunction[4, 5, 4] = 0
 
doubleS3sub6NFunction[4, 5, 5] = 0
 
doubleS3sub6NFunction[5, 0, 0] = 0
 
doubleS3sub6NFunction[5, 0, 1] = 0
 
doubleS3sub6NFunction[5, 0, 2] = 0
 
doubleS3sub6NFunction[5, 0, 3] = 0
 
doubleS3sub6NFunction[5, 0, 4] = 0
 
doubleS3sub6NFunction[5, 0, 5] = 1
 
doubleS3sub6NFunction[5, 1, 0] = 0
 
doubleS3sub6NFunction[5, 1, 1] = 0
 
doubleS3sub6NFunction[5, 1, 2] = 0
 
doubleS3sub6NFunction[5, 1, 3] = 0
 
doubleS3sub6NFunction[5, 1, 4] = 0
 
doubleS3sub6NFunction[5, 1, 5] = 1
 
doubleS3sub6NFunction[5, 2, 0] = 0
 
doubleS3sub6NFunction[5, 2, 1] = 0
 
doubleS3sub6NFunction[5, 2, 2] = 0
 
doubleS3sub6NFunction[5, 2, 3] = 1
 
doubleS3sub6NFunction[5, 2, 4] = 1
 
doubleS3sub6NFunction[5, 2, 5] = 0
 
doubleS3sub6NFunction[5, 3, 0] = 0
 
doubleS3sub6NFunction[5, 3, 1] = 0
 
doubleS3sub6NFunction[5, 3, 2] = 1
 
doubleS3sub6NFunction[5, 3, 3] = 0
 
doubleS3sub6NFunction[5, 3, 4] = 1
 
doubleS3sub6NFunction[5, 3, 5] = 0
 
doubleS3sub6NFunction[5, 4, 0] = 0
 
doubleS3sub6NFunction[5, 4, 1] = 0
 
doubleS3sub6NFunction[5, 4, 2] = 1
 
doubleS3sub6NFunction[5, 4, 3] = 1
 
doubleS3sub6NFunction[5, 4, 4] = 0
 
doubleS3sub6NFunction[5, 4, 5] = 0
 
doubleS3sub6NFunction[5, 5, 0] = 1
 
doubleS3sub6NFunction[5, 5, 1] = 1
 
doubleS3sub6NFunction[5, 5, 2] = 0
 
doubleS3sub6NFunction[5, 5, 3] = 0
 
doubleS3sub6NFunction[5, 5, 4] = 0
 
doubleS3sub6NFunction[5, 5, 5] = 1
 
doubleS3sub6NFunction[a_, b_, c_] := 0


 EndPackage[]