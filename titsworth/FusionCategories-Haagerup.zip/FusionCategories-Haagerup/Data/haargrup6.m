BeginPackage["FusionCategories`Data`haargrup6`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[haargrup6] ^= {haargrup6Cat1, haargrup6Cat2, haargrup6Cat3, 
    haargrup6Cat4, haargrup6Cat5, haargrup6Cat6, haargrup6Cat7, haargrup6Cat8}
 
haargrup6 /: fusionCategory[haargrup6, 1] = haargrup6Cat1
 
haargrup6 /: fusionCategory[haargrup6, 2] = haargrup6Cat2
 
haargrup6 /: fusionCategory[haargrup6, 3] = haargrup6Cat3
 
haargrup6 /: fusionCategory[haargrup6, 4] = haargrup6Cat4
 
haargrup6 /: fusionCategory[haargrup6, 5] = haargrup6Cat5
 
haargrup6 /: fusionCategory[haargrup6, 6] = haargrup6Cat6
 
haargrup6 /: fusionCategory[haargrup6, 7] = haargrup6Cat7
 
haargrup6 /: fusionCategory[haargrup6, 8] = haargrup6Cat8
 
nFunction[haargrup6] ^= haargrup6NFunction
 
noMultiplicities[haargrup6] ^= True
 
rank[haargrup6] ^= 6
 
ring[haargrup6] ^= haargrup6
balancedCategories[haargrup6Cat1] ^= {}
 
braidedCategories[haargrup6Cat1] ^= {}
 
coeval[haargrup6Cat1] ^= 1/sixJFunction[haargrup6Cat1][#1, 
      dual[ring[haargrup6Cat1]][#1], #1, #1, 0, 0] & 
 
eval[haargrup6Cat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haargrup6Cat1] ^= haargrup6Cat1FMatrixFunction
 
fusionCategory[haargrup6Cat1] ^= haargrup6Cat1
 
haargrup6Cat1 /: modularCategory[haargrup6Cat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[haargrup6Cat1] ^= {haargrup6Cat1Piv1}
 
haargrup6Cat1 /: pivotalCategory[haargrup6Cat1, 1] = haargrup6Cat1Piv1
 
haargrup6Cat1 /: pivotalCategory[haargrup6Cat1, {1, 1, 1, 1, 1, 1}] = 
    haargrup6Cat1Piv1
 
ring[haargrup6Cat1] ^= haargrup6
 
haargrup6Cat1 /: sphericalCategory[haargrup6Cat1, 1] = haargrup6Cat1Piv1
 
fusionCategoryIndex[haargrup6][haargrup6Cat1] ^= 1
fMatrixFunction[haargrup6Cat1FMatrixFunction] ^= haargrup6Cat1FMatrixFunction
 
fusionCategory[haargrup6Cat1FMatrixFunction] ^= haargrup6Cat1
 
ring[haargrup6Cat1FMatrixFunction] ^= haargrup6
 
haargrup6Cat1FMatrixFunction[1, 3, 2, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[1, 3, 4, 3] = {{-1}}
 
haargrup6Cat1FMatrixFunction[1, 3, 5, 3] = {{-1}}
 
haargrup6Cat1FMatrixFunction[1, 3, 5, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[1, 3, 5, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[1, 4, 1, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[1, 4, 2, 3] = {{-1}}
 
haargrup6Cat1FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[1, 4, 5, 3] = {{-1}}
 
haargrup6Cat1FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[1, 4, 5, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[1, 5, 1, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[2, 3, 1, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[2, 4, 2, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[2, 4, 4, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[2, 4, 5, 3] = {{-1}}
 
haargrup6Cat1FMatrixFunction[2, 4, 5, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[2, 4, 5, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[2, 5, 1, 3] = {{-1}}
 
haargrup6Cat1FMatrixFunction[2, 5, 2, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haargrup6Cat1FMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haargrup6Cat1FMatrixFunction[2, 5, 5, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[2, 5, 5, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[3, 1, 3, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[3, 1, 3, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[3, 1, 4, 1] = {{-1}}
 
haargrup6Cat1FMatrixFunction[3, 1, 4, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[3, 2, 4, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[3, 2, 5, 2] = {{-1}}
 
haargrup6Cat1FMatrixFunction[3, 2, 5, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[3, 2, 5, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[3, 3, 3, 3] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(3 - Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[3, 3, 3, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[3, 3, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haargrup6Cat1FMatrixFunction[3, 3, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[3, 3, 4, 4] = {{(-3 + Sqrt[13])/2, -1, 1, -1}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(3 - Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3}}
 
haargrup6Cat1FMatrixFunction[3, 3, 4, 5] = 
   {{(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[3, 3, 5, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}}
 
haargrup6Cat1FMatrixFunction[3, 3, 5, 4] = 
   {{(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haargrup6Cat1FMatrixFunction[3, 3, 5, 5] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(3 - Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[3, 4, 3, 2] = {{-1}}
 
haargrup6Cat1FMatrixFunction[3, 4, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[3, 4, 3, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haargrup6Cat1FMatrixFunction[3, 4, 3, 5] = {{(-3 + Sqrt[13])/2, 1, -1, 1}, 
    {(-3 + Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}, 
    {(3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haargrup6Cat1FMatrixFunction[3, 4, 4, 3] = {{(-3 + Sqrt[13])/2, 1, -1, 1}, 
    {(3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-3 + Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(3 - Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3}}
 
haargrup6Cat1FMatrixFunction[3, 4, 4, 4] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haargrup6Cat1FMatrixFunction[3, 4, 4, 5] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat1FMatrixFunction[3, 4, 5, 3] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[3, 4, 5, 4] = {{(3 - Sqrt[13])/2, 1, -1, -1}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(3 - Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[3, 4, 5, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}}
 
haargrup6Cat1FMatrixFunction[3, 5, 3, 2] = {{-1}}
 
haargrup6Cat1FMatrixFunction[3, 5, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haargrup6Cat1FMatrixFunction[3, 5, 3, 4] = {{(-3 + Sqrt[13])/2, 1, -1, 1}, 
    {(-3 + Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}, 
    {(3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haargrup6Cat1FMatrixFunction[3, 5, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat1FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
haargrup6Cat1FMatrixFunction[3, 5, 4, 3] = 
   {{(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haargrup6Cat1FMatrixFunction[3, 5, 4, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[3, 5, 4, 5] = {{(3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-2 + Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}}
 
haargrup6Cat1FMatrixFunction[3, 5, 5, 2] = {{-1}}
 
haargrup6Cat1FMatrixFunction[3, 5, 5, 3] = {{(-3 + Sqrt[13])/2, 1, 1, -1}, 
    {(3 - Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-3 + Sqrt[13])/2, (2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[3, 5, 5, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}}
 
haargrup6Cat1FMatrixFunction[3, 5, 5, 5] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[4, 1, 3, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 1, 4, 2] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 1, 4, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 1, 4, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 2, 3, 2] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 2, 4, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 2, 5, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 3, 1, 3] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 3, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[4, 3, 3, 4] = {{(-3 + Sqrt[13])/2, 1, -1, 1}, 
    {(3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-3 + Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(3 - Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3}}
 
haargrup6Cat1FMatrixFunction[4, 3, 3, 5] = 
   {{(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haargrup6Cat1FMatrixFunction[4, 3, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haargrup6Cat1FMatrixFunction[4, 3, 4, 4] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haargrup6Cat1FMatrixFunction[4, 3, 4, 5] = {{(3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}, 
    {(3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(3 - Sqrt[13])/2, (2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[4, 3, 5, 3] = {{(-3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(3 - Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haargrup6Cat1FMatrixFunction[4, 3, 5, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[4, 3, 5, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haargrup6Cat1FMatrixFunction[4, 4, 1, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 4, 3, 3] = {{(-3 + Sqrt[13])/2, -1, 1, -1}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(3 - Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3}}
 
haargrup6Cat1FMatrixFunction[4, 4, 3, 4] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haargrup6Cat1FMatrixFunction[4, 4, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 4, 4, 3] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haargrup6Cat1FMatrixFunction[4, 4, 4, 4] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-2 + Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat1FMatrixFunction[4, 4, 4, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haargrup6Cat1FMatrixFunction[4, 4, 5, 1] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 4, 5, 3] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat1FMatrixFunction[4, 4, 5, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haargrup6Cat1FMatrixFunction[4, 4, 5, 5] = {{(-3 + Sqrt[13])/2, -1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haargrup6Cat1FMatrixFunction[4, 5, 2, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 5, 3, 1] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 5, 3, 2] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 5, 3, 3] = 
   {{(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[4, 5, 3, 4] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat1FMatrixFunction[4, 5, 3, 5] = {{(3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-2 + Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}}
 
haargrup6Cat1FMatrixFunction[4, 5, 4, 1] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 5, 4, 3] = {{(3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}, 
    {(3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(3 - Sqrt[13])/2, (2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[4, 5, 4, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haargrup6Cat1FMatrixFunction[4, 5, 4, 5] = 
   {{(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[4, 5, 5, 1] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 5, 5, 2] = {{-1}}
 
haargrup6Cat1FMatrixFunction[4, 5, 5, 3] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}}
 
haargrup6Cat1FMatrixFunction[4, 5, 5, 4] = {{(-3 + Sqrt[13])/2, 1, 1, 1}, 
    {(3 - Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {(3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-2 + Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haargrup6Cat1FMatrixFunction[4, 5, 5, 5] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat1FMatrixFunction[5, 1, 3, 1] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 1, 3, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 1, 5, 2] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 2, 5, 1] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 3, 1, 3] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 3, 1, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 3, 2, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 3, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}}
 
haargrup6Cat1FMatrixFunction[5, 3, 3, 4] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[5, 3, 3, 5] = {{(-3 + Sqrt[13])/2, 1, 1, -1}, 
    {(3 - Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-3 + Sqrt[13])/2, (2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[5, 3, 4, 3] = {{(-3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(3 - Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (2 - Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haargrup6Cat1FMatrixFunction[5, 3, 4, 4] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat1FMatrixFunction[5, 3, 4, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}}
 
haargrup6Cat1FMatrixFunction[5, 3, 5, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat1FMatrixFunction[5, 3, 5, 4] = {{(3 - Sqrt[13])/2, 1, 1, 1}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-2 + Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-3 + Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}}
 
haargrup6Cat1FMatrixFunction[5, 3, 5, 5] = 
   {{(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[5, 4, 1, 3] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 4, 1, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 4, 2, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 4, 2, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 4, 3, 3] = 
   {{(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haargrup6Cat1FMatrixFunction[5, 4, 3, 4] = {{(3 - Sqrt[13])/2, 1, -1, -1}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(3 - Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[5, 4, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}}
 
haargrup6Cat1FMatrixFunction[5, 4, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[5, 4, 4, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haargrup6Cat1FMatrixFunction[5, 4, 4, 5] = {{(-3 + Sqrt[13])/2, 1, 1, 1}, 
    {(3 - Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {(3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-2 + Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haargrup6Cat1FMatrixFunction[5, 4, 5, 3] = {{(3 - Sqrt[13])/2, 1, 1, 1}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (-2 + Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-3 + Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}}
 
haargrup6Cat1FMatrixFunction[5, 4, 5, 4] = 
   {{(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[5, 4, 5, 5] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat1FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 5, 1, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 5, 2, 4] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 5, 2, 5] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 5, 3, 3] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(3 - Sqrt[13])/2, (2 - Sqrt[13])/3, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[5, 5, 3, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}}
 
haargrup6Cat1FMatrixFunction[5, 5, 3, 5] = 
   {{(1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[5, 5, 4, 1] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 5, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6}}
 
haargrup6Cat1FMatrixFunction[5, 5, 4, 4] = {{(-3 + Sqrt[13])/2, -1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-2 + Sqrt[13])/3}, 
    {(-3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], 
     (2 - Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}}
 
haargrup6Cat1FMatrixFunction[5, 5, 4, 5] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat1FMatrixFunction[5, 5, 5, 1] = {{-1}}
 
haargrup6Cat1FMatrixFunction[5, 5, 5, 3] = 
   {{(1 + Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat1FMatrixFunction[5, 5, 5, 4] = 
   {{(-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-1 - Sqrt[13])/6, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat1FMatrixFunction[5, 5, 5, 5] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], 
     (-2 + Sqrt[13])/3, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12}, 
    {(-3 + Sqrt[13])/2, (-2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 1, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-3 + Sqrt[13])/2, (-5 + Sqrt[13] + Sqrt[6*(1 + Sqrt[13])])/12, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 2, 0], (2 - Sqrt[13])/3}}
 
haargrup6Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haargrup6Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haargrup6Cat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haargrup6Cat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[haargrup6Cat1Piv1] ^= {}
 
fusionCategory[haargrup6Cat1Piv1] ^= haargrup6Cat1
 
haargrup6Cat1Piv1 /: modularCategory[haargrup6Cat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[haargrup6Cat1Piv1] ^= haargrup6Cat1Piv1
 
pivotalIsomorphism[haargrup6Cat1Piv1] ^= haargrup6Cat1Piv1PivotalIsomorphism
 
ring[haargrup6Cat1Piv1] ^= haargrup6
 
sphericalCategory[haargrup6Cat1Piv1] ^= haargrup6Cat1Piv1
 
(pivotalCategoryIndex[fusionCategory[haargrup6Cat1]][pivotalCategory[#1]] & )[
    haargrup6Cat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haargrup6Cat1]][
      sphericalCategory[#1]] & )[haargrup6Cat1Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haargrup6Cat1Piv1PivotalIsomorphism] ^= haargrup6Cat1
 
pivotalCategory[haargrup6Cat1Piv1PivotalIsomorphism] ^= haargrup6Cat1Piv1
 
pivotalIsomorphism[haargrup6Cat1Piv1PivotalIsomorphism] ^= 
   haargrup6Cat1Piv1PivotalIsomorphism
 
haargrup6Cat1Piv1PivotalIsomorphism[0] = 1
 
haargrup6Cat1Piv1PivotalIsomorphism[1] = 1
 
haargrup6Cat1Piv1PivotalIsomorphism[2] = 1
 
haargrup6Cat1Piv1PivotalIsomorphism[3] = 1
 
haargrup6Cat1Piv1PivotalIsomorphism[4] = 1
 
haargrup6Cat1Piv1PivotalIsomorphism[5] = 1
balancedCategories[haargrup6Cat2] ^= {}
 
braidedCategories[haargrup6Cat2] ^= {}
 
coeval[haargrup6Cat2] ^= 1/sixJFunction[haargrup6Cat2][#1, 
      dual[ring[haargrup6Cat2]][#1], #1, #1, 0, 0] & 
 
eval[haargrup6Cat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haargrup6Cat2] ^= haargrup6Cat2FMatrixFunction
 
fusionCategory[haargrup6Cat2] ^= haargrup6Cat2
 
haargrup6Cat2 /: modularCategory[haargrup6Cat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[haargrup6Cat2] ^= {haargrup6Cat2Piv1}
 
haargrup6Cat2 /: pivotalCategory[haargrup6Cat2, 1] = haargrup6Cat2Piv1
 
haargrup6Cat2 /: pivotalCategory[haargrup6Cat2, {1, 1, 1, 1, 1, 1}] = 
    haargrup6Cat2Piv1
 
ring[haargrup6Cat2] ^= haargrup6
 
haargrup6Cat2 /: sphericalCategory[haargrup6Cat2, 1] = haargrup6Cat2Piv1
 
fusionCategoryIndex[haargrup6][haargrup6Cat2] ^= 2
fMatrixFunction[haargrup6Cat2FMatrixFunction] ^= haargrup6Cat2FMatrixFunction
 
fusionCategory[haargrup6Cat2FMatrixFunction] ^= haargrup6Cat2
 
ring[haargrup6Cat2FMatrixFunction] ^= haargrup6
 
haargrup6Cat2FMatrixFunction[1, 3, 2, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[1, 3, 4, 3] = {{-1}}
 
haargrup6Cat2FMatrixFunction[1, 3, 5, 3] = {{-1}}
 
haargrup6Cat2FMatrixFunction[1, 3, 5, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[1, 3, 5, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[1, 4, 1, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[1, 4, 2, 3] = {{-1}}
 
haargrup6Cat2FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[1, 4, 5, 3] = {{-1}}
 
haargrup6Cat2FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[1, 4, 5, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[1, 5, 1, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[2, 3, 1, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[2, 4, 2, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[2, 4, 4, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[2, 4, 5, 3] = {{-1}}
 
haargrup6Cat2FMatrixFunction[2, 4, 5, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[2, 4, 5, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[2, 5, 1, 3] = {{-1}}
 
haargrup6Cat2FMatrixFunction[2, 5, 2, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haargrup6Cat2FMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haargrup6Cat2FMatrixFunction[2, 5, 5, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[2, 5, 5, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[3, 1, 3, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[3, 1, 3, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[3, 1, 4, 1] = {{-1}}
 
haargrup6Cat2FMatrixFunction[3, 1, 4, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[3, 2, 4, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[3, 2, 5, 2] = {{-1}}
 
haargrup6Cat2FMatrixFunction[3, 2, 5, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[3, 2, 5, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[3, 3, 3, 3] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(3 + Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[3, 3, 3, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[3, 3, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haargrup6Cat2FMatrixFunction[3, 3, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[3, 3, 4, 4] = {{(-3 - Sqrt[13])/2, -1, 1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(3 + Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-2 - Sqrt[13])/3}}
 
haargrup6Cat2FMatrixFunction[3, 3, 4, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[3, 3, 5, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}}
 
haargrup6Cat2FMatrixFunction[3, 3, 5, 4] = 
   {{(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[3, 3, 5, 5] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(3 + Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[3, 4, 3, 2] = {{-1}}
 
haargrup6Cat2FMatrixFunction[3, 4, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[3, 4, 3, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haargrup6Cat2FMatrixFunction[3, 4, 3, 5] = {{(-3 - Sqrt[13])/2, 1, -1, 1}, 
    {(-3 - Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[3, 4, 4, 3] = {{(-3 - Sqrt[13])/2, 1, -1, 1}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-2 - Sqrt[13])/3}}
 
haargrup6Cat2FMatrixFunction[3, 4, 4, 4] = 
   {{(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[3, 4, 4, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[3, 4, 5, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[3, 4, 5, 4] = {{(3 + Sqrt[13])/2, 1, -1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(3 + Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[3, 4, 5, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}}
 
haargrup6Cat2FMatrixFunction[3, 5, 3, 2] = {{-1}}
 
haargrup6Cat2FMatrixFunction[3, 5, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haargrup6Cat2FMatrixFunction[3, 5, 3, 4] = {{(-3 - Sqrt[13])/2, 1, -1, 1}, 
    {(-3 - Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[3, 5, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
haargrup6Cat2FMatrixFunction[3, 5, 4, 3] = 
   {{(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[3, 5, 4, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[3, 5, 4, 5] = {{(3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (-2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}}
 
haargrup6Cat2FMatrixFunction[3, 5, 5, 2] = {{-1}}
 
haargrup6Cat2FMatrixFunction[3, 5, 5, 3] = {{(-3 - Sqrt[13])/2, 1, 1, -1}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[3, 5, 5, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}}
 
haargrup6Cat2FMatrixFunction[3, 5, 5, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[4, 1, 3, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 1, 4, 2] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 1, 4, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 1, 4, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 2, 3, 2] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 2, 4, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 2, 5, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 3, 1, 3] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 3, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[4, 3, 3, 4] = {{(-3 - Sqrt[13])/2, 1, -1, 1}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-2 - Sqrt[13])/3}}
 
haargrup6Cat2FMatrixFunction[4, 3, 3, 5] = 
   {{(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[4, 3, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haargrup6Cat2FMatrixFunction[4, 3, 4, 4] = 
   {{(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[4, 3, 4, 5] = {{(3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}, 
    {(3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(3 + Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[4, 3, 5, 3] = {{(-3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[4, 3, 5, 4] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[4, 3, 5, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haargrup6Cat2FMatrixFunction[4, 4, 1, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 4, 3, 3] = {{(-3 - Sqrt[13])/2, -1, 1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(3 + Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-2 - Sqrt[13])/3}}
 
haargrup6Cat2FMatrixFunction[4, 4, 3, 4] = 
   {{(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[4, 4, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 4, 4, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[4, 4, 4, 4] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-2 - Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[4, 4, 4, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haargrup6Cat2FMatrixFunction[4, 4, 5, 1] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 4, 5, 3] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[4, 4, 5, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haargrup6Cat2FMatrixFunction[4, 4, 5, 5] = {{(-3 - Sqrt[13])/2, -1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-2 - Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[4, 5, 2, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 5, 3, 1] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 5, 3, 2] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 5, 3, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[4, 5, 3, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[4, 5, 3, 5] = {{(3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (-2 - Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}}
 
haargrup6Cat2FMatrixFunction[4, 5, 4, 1] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 5, 4, 3] = {{(3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}, 
    {(3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(3 + Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[4, 5, 4, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haargrup6Cat2FMatrixFunction[4, 5, 4, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[4, 5, 5, 1] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 5, 5, 2] = {{-1}}
 
haargrup6Cat2FMatrixFunction[4, 5, 5, 3] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}}
 
haargrup6Cat2FMatrixFunction[4, 5, 5, 4] = {{(-3 - Sqrt[13])/2, 1, 1, 1}, 
    {(3 + Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (-2 - Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[4, 5, 5, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 1, 3, 1] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 1, 3, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 1, 5, 2] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 2, 5, 1] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 3, 1, 3] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 3, 1, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 3, 2, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 3, 3, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}}
 
haargrup6Cat2FMatrixFunction[5, 3, 3, 4] = 
   {{(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 3, 3, 5] = {{(-3 - Sqrt[13])/2, 1, 1, -1}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 3, 4, 3] = {{(-3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (2 + Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 3, 4, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 3, 4, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}}
 
haargrup6Cat2FMatrixFunction[5, 3, 5, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 3, 5, 4] = {{(3 + Sqrt[13])/2, 1, 1, 1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (-2 - Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}}
 
haargrup6Cat2FMatrixFunction[5, 3, 5, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 4, 1, 3] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 4, 1, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 4, 2, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 4, 2, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 4, 3, 3] = 
   {{(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 4, 3, 4] = {{(3 + Sqrt[13])/2, 1, -1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(3 + Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 4, 3, 5] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}}
 
haargrup6Cat2FMatrixFunction[5, 4, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 4, 4, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haargrup6Cat2FMatrixFunction[5, 4, 4, 5] = {{(-3 - Sqrt[13])/2, 1, 1, 1}, 
    {(3 + Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}, 
    {(3 + Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (-2 - Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 4, 5, 3] = {{(3 + Sqrt[13])/2, 1, 1, 1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (-2 - Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}}
 
haargrup6Cat2FMatrixFunction[5, 4, 5, 4] = 
   {{(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 4, 5, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 5, 1, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 5, 2, 4] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 5, 2, 5] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 5, 3, 3] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(3 + Sqrt[13])/2, (2 + Sqrt[13])/3, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 5, 3, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}}
 
haargrup6Cat2FMatrixFunction[5, 5, 3, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 5, 4, 1] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 5, 4, 3] = 
   {{Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6}}
 
haargrup6Cat2FMatrixFunction[5, 5, 4, 4] = {{(-3 - Sqrt[13])/2, -1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-2 - Sqrt[13])/3}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], 
     (2 + Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 5, 4, 5] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6}, 
    {Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 5, 5, 1] = {{-1}}
 
haargrup6Cat2FMatrixFunction[5, 5, 5, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 5, 5, 4] = 
   {{Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6}, 
    {Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat2FMatrixFunction[5, 5, 5, 5] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(3 + Sqrt[13])/2, Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], 
     (-2 - Sqrt[13])/3, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, (-2 - Sqrt[13])/3, 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 3, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, Root[-1 - #1 + 7*#1^2 + 15*#1^3 + 9*#1^4 & , 4, 0], 
     Root[-1 + #1 + 7*#1^2 - 15*#1^3 + 9*#1^4 & , 4, 0], (2 + Sqrt[13])/3}}
 
haargrup6Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haargrup6Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haargrup6Cat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haargrup6Cat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[haargrup6Cat2Piv1] ^= {}
 
fusionCategory[haargrup6Cat2Piv1] ^= haargrup6Cat2
 
haargrup6Cat2Piv1 /: modularCategory[haargrup6Cat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[haargrup6Cat2Piv1] ^= haargrup6Cat2Piv1
 
pivotalIsomorphism[haargrup6Cat2Piv1] ^= haargrup6Cat2Piv1PivotalIsomorphism
 
ring[haargrup6Cat2Piv1] ^= haargrup6
 
sphericalCategory[haargrup6Cat2Piv1] ^= haargrup6Cat2Piv1
 
(pivotalCategoryIndex[fusionCategory[haargrup6Cat2]][pivotalCategory[#1]] & )[
    haargrup6Cat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haargrup6Cat2]][
      sphericalCategory[#1]] & )[haargrup6Cat2Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haargrup6Cat2Piv1PivotalIsomorphism] ^= haargrup6Cat2
 
pivotalCategory[haargrup6Cat2Piv1PivotalIsomorphism] ^= haargrup6Cat2Piv1
 
pivotalIsomorphism[haargrup6Cat2Piv1PivotalIsomorphism] ^= 
   haargrup6Cat2Piv1PivotalIsomorphism
 
haargrup6Cat2Piv1PivotalIsomorphism[0] = 1
 
haargrup6Cat2Piv1PivotalIsomorphism[1] = 1
 
haargrup6Cat2Piv1PivotalIsomorphism[2] = 1
 
haargrup6Cat2Piv1PivotalIsomorphism[3] = 1
 
haargrup6Cat2Piv1PivotalIsomorphism[4] = 1
 
haargrup6Cat2Piv1PivotalIsomorphism[5] = 1
balancedCategories[haargrup6Cat3] ^= {}
 
braidedCategories[haargrup6Cat3] ^= {}
 
coeval[haargrup6Cat3] ^= 1/sixJFunction[haargrup6Cat3][#1, 
      dual[ring[haargrup6Cat3]][#1], #1, #1, 0, 0] & 
 
eval[haargrup6Cat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haargrup6Cat3] ^= haargrup6Cat3FMatrixFunction
 
fusionCategory[haargrup6Cat3] ^= haargrup6Cat3
 
haargrup6Cat3 /: modularCategory[haargrup6Cat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[haargrup6Cat3] ^= {haargrup6Cat3Piv1}
 
haargrup6Cat3 /: pivotalCategory[haargrup6Cat3, 1] = haargrup6Cat3Piv1
 
haargrup6Cat3 /: pivotalCategory[haargrup6Cat3, {1, 1, 1, 1, 1, 1}] = 
    haargrup6Cat3Piv1
 
ring[haargrup6Cat3] ^= haargrup6
 
haargrup6Cat3 /: sphericalCategory[haargrup6Cat3, 1] = haargrup6Cat3Piv1
 
fusionCategoryIndex[haargrup6][haargrup6Cat3] ^= 3
fMatrixFunction[haargrup6Cat3FMatrixFunction] ^= haargrup6Cat3FMatrixFunction
 
fusionCategory[haargrup6Cat3FMatrixFunction] ^= haargrup6Cat3
 
ring[haargrup6Cat3FMatrixFunction] ^= haargrup6
 
haargrup6Cat3FMatrixFunction[1, 3, 2, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[1, 3, 4, 3] = {{-1}}
 
haargrup6Cat3FMatrixFunction[1, 3, 5, 3] = {{-1}}
 
haargrup6Cat3FMatrixFunction[1, 3, 5, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[1, 3, 5, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[1, 4, 1, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[1, 4, 2, 3] = {{-1}}
 
haargrup6Cat3FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[1, 4, 5, 3] = {{-1}}
 
haargrup6Cat3FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[1, 4, 5, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[1, 5, 1, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[2, 3, 1, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[2, 4, 2, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[2, 4, 4, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[2, 4, 5, 3] = {{-1}}
 
haargrup6Cat3FMatrixFunction[2, 4, 5, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[2, 4, 5, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[2, 5, 1, 3] = {{-1}}
 
haargrup6Cat3FMatrixFunction[2, 5, 2, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haargrup6Cat3FMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haargrup6Cat3FMatrixFunction[2, 5, 5, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[2, 5, 5, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[3, 1, 3, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[3, 1, 3, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[3, 1, 4, 1] = {{-1}}
 
haargrup6Cat3FMatrixFunction[3, 1, 4, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[3, 2, 4, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[3, 2, 5, 2] = {{-1}}
 
haargrup6Cat3FMatrixFunction[3, 2, 5, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[3, 2, 5, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[3, 3, 3, 3] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(3 - Sqrt[13])/2, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, (7 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 3, 3, 4] = 
   {{(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 3, 3, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat3FMatrixFunction[3, 3, 4, 3] = 
   {{(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 3, 4, 4] = {{(-3 + Sqrt[13])/2, -1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(3 - Sqrt[13])/2, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 3, 4, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 3, 5, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat3FMatrixFunction[3, 3, 5, 4] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 3, 5, 5] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 4, 3, 2] = {{-1}}
 
haargrup6Cat3FMatrixFunction[3, 4, 3, 3] = 
   {{(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 4, 3, 4] = 
   {{(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat3FMatrixFunction[3, 4, 3, 5] = {{(-3 + Sqrt[13])/2, 1, -1, 1}, 
    {(-3 + Sqrt[13])/2, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 4, 4, 3] = {{(-3 + Sqrt[13])/2, 1, -1, 1}, 
    {(3 - Sqrt[13])/2, (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 4, 4, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 4, 4, 5] = 
   {{(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 4, 5, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 4, 5, 4] = {{(3 - Sqrt[13])/2, 1, -1, -1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 4, 5, 5] = 
   {{(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat3FMatrixFunction[3, 5, 3, 2] = {{-1}}
 
haargrup6Cat3FMatrixFunction[3, 5, 3, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat3FMatrixFunction[3, 5, 3, 4] = {{(-3 + Sqrt[13])/2, 1, -1, 1}, 
    {(-3 + Sqrt[13])/2, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 5, 3, 5] = 
   {{(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
haargrup6Cat3FMatrixFunction[3, 5, 4, 3] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 5, 4, 4] = 
   {{(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 5, 4, 5] = {{(3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (-7 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-7 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 5, 5, 2] = {{-1}}
 
haargrup6Cat3FMatrixFunction[3, 5, 5, 3] = {{(-3 + Sqrt[13])/2, 1, 1, -1}, 
    {(3 - Sqrt[13])/2, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[3, 5, 5, 4] = 
   {{(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat3FMatrixFunction[3, 5, 5, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 1, 3, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 1, 4, 2] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 1, 4, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 1, 4, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 2, 3, 2] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 2, 4, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 2, 5, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 3, 1, 3] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 3, 3, 3] = 
   {{(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 3, 3, 4] = {{(-3 + Sqrt[13])/2, 1, -1, 1}, 
    {(3 - Sqrt[13])/2, (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 3, 3, 5] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 3, 4, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat3FMatrixFunction[4, 3, 4, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 3, 4, 5] = {{(3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 3, 5, 3] = {{(-3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (7 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(3 - Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (1 - Sqrt[13])/6, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 3, 5, 4] = 
   {{(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 3, 5, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat3FMatrixFunction[4, 4, 1, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 4, 3, 3] = {{(-3 + Sqrt[13])/2, -1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(3 - Sqrt[13])/2, (7 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 4, 3, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 4, 3, 5] = 
   {{(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 4, 4, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 4, 4, 4] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(3 - Sqrt[13])/2, (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (-7 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (-7 + Sqrt[13])/6, (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 4, 4, 5] = 
   {{(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat3FMatrixFunction[4, 4, 5, 1] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 4, 5, 3] = 
   {{(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 4, 5, 4] = 
   {{(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat3FMatrixFunction[4, 4, 5, 5] = {{(-3 + Sqrt[13])/2, -1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-7 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 5, 2, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 5, 3, 1] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 5, 3, 2] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 5, 3, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 5, 3, 4] = 
   {{(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 5, 3, 5] = {{(3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (-7 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-7 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 5, 4, 1] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 5, 4, 3] = {{(3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 5, 4, 4] = 
   {{(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat3FMatrixFunction[4, 5, 4, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 5, 5, 1] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 5, 5, 2] = {{-1}}
 
haargrup6Cat3FMatrixFunction[4, 5, 5, 3] = 
   {{(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat3FMatrixFunction[4, 5, 5, 4] = {{(-3 + Sqrt[13])/2, 1, 1, 1}, 
    {(3 - Sqrt[13])/2, (-7 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, (7 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (-7 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[4, 5, 5, 5] = 
   {{(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 1, 3, 1] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 1, 3, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 1, 5, 2] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 2, 5, 1] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 3, 1, 3] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 3, 1, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 3, 2, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 3, 3, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat3FMatrixFunction[5, 3, 3, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 3, 3, 5] = {{(-3 + Sqrt[13])/2, 1, 1, -1}, 
    {(3 - Sqrt[13])/2, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 3, 4, 3] = {{(-3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (7 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(3 - Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (1 - Sqrt[13])/6, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 3, 4, 4] = 
   {{(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 3, 4, 5] = 
   {{(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat3FMatrixFunction[5, 3, 5, 3] = 
   {{(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 3, 5, 4] = {{(3 - Sqrt[13])/2, 1, 1, 1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (-7 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-7 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6, (7 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 3, 5, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 4, 1, 3] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 4, 1, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 4, 2, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 4, 2, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 4, 3, 3] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 4, 3, 4] = {{(3 - Sqrt[13])/2, 1, -1, -1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 4, 3, 5] = 
   {{(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}}
 
haargrup6Cat3FMatrixFunction[5, 4, 4, 3] = 
   {{(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 4, 4, 4] = 
   {{(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat3FMatrixFunction[5, 4, 4, 5] = {{(-3 + Sqrt[13])/2, 1, 1, 1}, 
    {(3 - Sqrt[13])/2, (-7 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, (7 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (-7 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 4, 5, 3] = {{(3 - Sqrt[13])/2, 1, 1, 1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (-7 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-7 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6, (7 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 4, 5, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 4, 5, 5] = 
   {{(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 5, 1, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 5, 2, 4] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 5, 2, 5] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 5, 3, 3] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (7 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (7 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(3 - Sqrt[13])/2, 
     (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 5, 3, 4] = 
   {{(-1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (1 - Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat3FMatrixFunction[5, 5, 3, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], (1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 5, 4, 1] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 5, 4, 3] = 
   {{(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6}, {(1 - Sqrt[13])/6, 
     (1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}}
 
haargrup6Cat3FMatrixFunction[5, 5, 4, 4] = {{(-3 + Sqrt[13])/2, -1, 1, -1}, 
    {(-3 + Sqrt[13])/2, (-7 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (7 - Sqrt[13])/6, (-1 + Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 5, 4, 5] = 
   {{(-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(-1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 5, 5, 1] = {{-1}}
 
haargrup6Cat3FMatrixFunction[5, 5, 5, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0], (-1 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6}, {(1 - Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 3, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 4, 0], 
     (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 5, 5, 4] = 
   {{(-1 + Sqrt[13])/6, (-1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0]}, 
    {(1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 4, 0], 
     (-1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 3, 0], 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[5, 5, 5, 5] = {{(-3 + Sqrt[13])/2, -1, 1, 1}, 
    {(3 - Sqrt[13])/2, (1 - Sqrt[13])/6, (-7 + Sqrt[13])/6, 
     (-1 + Sqrt[13])/6}, {(-3 + Sqrt[13])/2, (-7 + Sqrt[13])/6, 
     (1 - Sqrt[13])/6, (1 - Sqrt[13])/6}, {(-3 + Sqrt[13])/2, 
     (-1 + Sqrt[13])/6, (1 - Sqrt[13])/6, (7 - Sqrt[13])/6}}
 
haargrup6Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haargrup6Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haargrup6Cat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haargrup6Cat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[haargrup6Cat3Piv1] ^= {}
 
fusionCategory[haargrup6Cat3Piv1] ^= haargrup6Cat3
 
haargrup6Cat3Piv1 /: modularCategory[haargrup6Cat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[haargrup6Cat3Piv1] ^= haargrup6Cat3Piv1
 
pivotalIsomorphism[haargrup6Cat3Piv1] ^= haargrup6Cat3Piv1PivotalIsomorphism
 
ring[haargrup6Cat3Piv1] ^= haargrup6
 
sphericalCategory[haargrup6Cat3Piv1] ^= haargrup6Cat3Piv1
 
(pivotalCategoryIndex[fusionCategory[haargrup6Cat3]][pivotalCategory[#1]] & )[
    haargrup6Cat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haargrup6Cat3]][
      sphericalCategory[#1]] & )[haargrup6Cat3Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haargrup6Cat3Piv1PivotalIsomorphism] ^= haargrup6Cat3
 
pivotalCategory[haargrup6Cat3Piv1PivotalIsomorphism] ^= haargrup6Cat3Piv1
 
pivotalIsomorphism[haargrup6Cat3Piv1PivotalIsomorphism] ^= 
   haargrup6Cat3Piv1PivotalIsomorphism
 
haargrup6Cat3Piv1PivotalIsomorphism[0] = 1
 
haargrup6Cat3Piv1PivotalIsomorphism[1] = 1
 
haargrup6Cat3Piv1PivotalIsomorphism[2] = 1
 
haargrup6Cat3Piv1PivotalIsomorphism[3] = 1
 
haargrup6Cat3Piv1PivotalIsomorphism[4] = 1
 
haargrup6Cat3Piv1PivotalIsomorphism[5] = 1
balancedCategories[haargrup6Cat4] ^= {}
 
braidedCategories[haargrup6Cat4] ^= {}
 
coeval[haargrup6Cat4] ^= 1/sixJFunction[haargrup6Cat4][#1, 
      dual[ring[haargrup6Cat4]][#1], #1, #1, 0, 0] & 
 
eval[haargrup6Cat4] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haargrup6Cat4] ^= haargrup6Cat4FMatrixFunction
 
fusionCategory[haargrup6Cat4] ^= haargrup6Cat4
 
haargrup6Cat4 /: modularCategory[haargrup6Cat4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[haargrup6Cat4] ^= {haargrup6Cat4Piv1}
 
haargrup6Cat4 /: pivotalCategory[haargrup6Cat4, 1] = haargrup6Cat4Piv1
 
haargrup6Cat4 /: pivotalCategory[haargrup6Cat4, {1, 1, 1, 1, 1, 1}] = 
    haargrup6Cat4Piv1
 
ring[haargrup6Cat4] ^= haargrup6
 
haargrup6Cat4 /: sphericalCategory[haargrup6Cat4, 1] = haargrup6Cat4Piv1
 
fusionCategoryIndex[haargrup6][haargrup6Cat4] ^= 4
fMatrixFunction[haargrup6Cat4FMatrixFunction] ^= haargrup6Cat4FMatrixFunction
 
fusionCategory[haargrup6Cat4FMatrixFunction] ^= haargrup6Cat4
 
ring[haargrup6Cat4FMatrixFunction] ^= haargrup6
 
haargrup6Cat4FMatrixFunction[1, 3, 2, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[1, 3, 4, 3] = {{-1}}
 
haargrup6Cat4FMatrixFunction[1, 3, 5, 3] = {{-1}}
 
haargrup6Cat4FMatrixFunction[1, 3, 5, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[1, 3, 5, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[1, 4, 1, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[1, 4, 2, 3] = {{-1}}
 
haargrup6Cat4FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[1, 4, 5, 3] = {{-1}}
 
haargrup6Cat4FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[1, 4, 5, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[1, 5, 1, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[2, 3, 1, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[2, 4, 2, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[2, 4, 4, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[2, 4, 5, 3] = {{-1}}
 
haargrup6Cat4FMatrixFunction[2, 4, 5, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[2, 4, 5, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[2, 5, 1, 3] = {{-1}}
 
haargrup6Cat4FMatrixFunction[2, 5, 2, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haargrup6Cat4FMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haargrup6Cat4FMatrixFunction[2, 5, 5, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[2, 5, 5, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[3, 1, 3, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[3, 1, 3, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[3, 1, 4, 1] = {{-1}}
 
haargrup6Cat4FMatrixFunction[3, 1, 4, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[3, 2, 4, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[3, 2, 5, 2] = {{-1}}
 
haargrup6Cat4FMatrixFunction[3, 2, 5, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[3, 2, 5, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[3, 3, 3, 3] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(3 + Sqrt[13])/2, (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6, (7 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 3, 3, 4] = 
   {{(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 3, 3, 5] = 
   {{(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat4FMatrixFunction[3, 3, 4, 3] = 
   {{(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 3, 4, 4] = {{(-3 - Sqrt[13])/2, -1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(3 + Sqrt[13])/2, (7 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, (-7 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 3, 4, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 3, 5, 3] = 
   {{(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat4FMatrixFunction[3, 3, 5, 4] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 3, 5, 5] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     (7 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (7 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 4, 3, 2] = {{-1}}
 
haargrup6Cat4FMatrixFunction[3, 4, 3, 3] = 
   {{(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 4, 3, 4] = 
   {{(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat4FMatrixFunction[3, 4, 3, 5] = {{(-3 - Sqrt[13])/2, 1, -1, 1}, 
    {(-3 - Sqrt[13])/2, (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 4, 4, 3] = {{(-3 - Sqrt[13])/2, 1, -1, 1}, 
    {(3 + Sqrt[13])/2, (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (7 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, (-7 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 4, 4, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 4, 4, 5] = 
   {{(-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 4, 5, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 4, 5, 4] = {{(3 + Sqrt[13])/2, 1, -1, -1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     (7 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (7 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 4, 5, 5] = 
   {{(-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat4FMatrixFunction[3, 5, 3, 2] = {{-1}}
 
haargrup6Cat4FMatrixFunction[3, 5, 3, 3] = 
   {{(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat4FMatrixFunction[3, 5, 3, 4] = {{(-3 - Sqrt[13])/2, 1, -1, 1}, 
    {(-3 - Sqrt[13])/2, (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 5, 3, 5] = 
   {{(1 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 5, 4, 2] = {{-1}}
 
haargrup6Cat4FMatrixFunction[3, 5, 4, 3] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 5, 4, 4] = 
   {{(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 5, 4, 5] = {{(3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (-7 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-7 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 5, 5, 2] = {{-1}}
 
haargrup6Cat4FMatrixFunction[3, 5, 5, 3] = {{(-3 - Sqrt[13])/2, 1, 1, -1}, 
    {(3 + Sqrt[13])/2, (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (7 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (1 + Sqrt[13])/6, 
     (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (7 + Sqrt[13])/6, (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[3, 5, 5, 4] = 
   {{(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat4FMatrixFunction[3, 5, 5, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 1, 3, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 1, 4, 2] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 1, 4, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 1, 4, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 2, 3, 2] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 2, 4, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 2, 5, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 3, 1, 3] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 3, 3, 3] = 
   {{(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 3, 3, 4] = {{(-3 - Sqrt[13])/2, 1, -1, 1}, 
    {(3 + Sqrt[13])/2, (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (7 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, (-7 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 3, 3, 5] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 3, 4, 3] = 
   {{(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat4FMatrixFunction[4, 3, 4, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 3, 4, 5] = {{(3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (7 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, (1 + Sqrt[13])/6, 
     (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (7 + Sqrt[13])/6, (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 3, 5, 3] = {{(-3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (7 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(3 + Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (1 + Sqrt[13])/6, (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 3, 5, 4] = 
   {{(1 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 3, 5, 5] = 
   {{(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat4FMatrixFunction[4, 4, 1, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 4, 3, 3] = {{(-3 - Sqrt[13])/2, -1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(3 + Sqrt[13])/2, (7 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, (-7 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 4, 3, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 4, 3, 5] = 
   {{(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 4, 4, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 4, 4, 4] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(3 + Sqrt[13])/2, (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (-7 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (7 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (-7 - Sqrt[13])/6, (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 4, 4, 5] = 
   {{(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat4FMatrixFunction[4, 4, 5, 1] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 4, 5, 3] = 
   {{(-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 4, 5, 4] = 
   {{(-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat4FMatrixFunction[4, 4, 5, 5] = {{(-3 - Sqrt[13])/2, -1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-7 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6, (-7 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 5, 2, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 5, 3, 1] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 5, 3, 2] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 5, 3, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 5, 3, 4] = 
   {{(-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 5, 3, 5] = {{(3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (-7 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-7 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 5, 4, 1] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 5, 4, 3] = {{(3 + Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (7 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, (1 + Sqrt[13])/6, 
     (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (7 + Sqrt[13])/6, (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 5, 4, 4] = 
   {{(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat4FMatrixFunction[4, 5, 4, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], (-1 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 5, 5, 1] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 5, 5, 2] = {{-1}}
 
haargrup6Cat4FMatrixFunction[4, 5, 5, 3] = 
   {{(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat4FMatrixFunction[4, 5, 5, 4] = {{(-3 - Sqrt[13])/2, 1, 1, 1}, 
    {(3 + Sqrt[13])/2, (-7 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, (7 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (-7 - Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[4, 5, 5, 5] = 
   {{(-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 1, 3, 1] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 1, 3, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 1, 5, 2] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 2, 5, 1] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 3, 1, 3] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 3, 1, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 3, 2, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 3, 3, 3] = 
   {{(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat4FMatrixFunction[5, 3, 3, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 3, 3, 5] = {{(-3 - Sqrt[13])/2, 1, 1, -1}, 
    {(3 + Sqrt[13])/2, (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (7 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (1 + Sqrt[13])/6, 
     (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (7 + Sqrt[13])/6, (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 3, 4, 3] = {{(-3 - Sqrt[13])/2, 1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (7 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(3 + Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (1 + Sqrt[13])/6, (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 3, 4, 4] = 
   {{(-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 3, 4, 5] = 
   {{(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat4FMatrixFunction[5, 3, 5, 3] = 
   {{(1 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 3, 5, 4] = {{(3 + Sqrt[13])/2, 1, 1, 1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (-7 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-7 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6, (7 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 3, 5, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 4, 1, 3] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 4, 1, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 4, 2, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 4, 2, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 4, 3, 3] = 
   {{Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 4, 3, 4] = {{(3 + Sqrt[13])/2, 1, -1, -1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     (7 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (7 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 4, 3, 5] = 
   {{(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}}
 
haargrup6Cat4FMatrixFunction[5, 4, 4, 3] = 
   {{(1 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 4, 4, 4] = 
   {{(-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat4FMatrixFunction[5, 4, 4, 5] = {{(-3 - Sqrt[13])/2, 1, 1, 1}, 
    {(3 + Sqrt[13])/2, (-7 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, (7 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (-7 - Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 4, 5, 3] = {{(3 + Sqrt[13])/2, 1, 1, 1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (-7 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-7 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6, (7 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 4, 5, 4] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 4, 5, 5] = 
   {{(-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 5, 1, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 5, 2, 4] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 5, 2, 5] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 5, 3, 3] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     (7 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (7 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(3 + Sqrt[13])/2, 
     (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 5, 3, 4] = 
   {{(-1 - Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (1 + Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat4FMatrixFunction[5, 5, 3, 5] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], (1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 5, 4, 1] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 5, 4, 3] = 
   {{(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6}, {(1 + Sqrt[13])/6, 
     (1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}}
 
haargrup6Cat4FMatrixFunction[5, 5, 4, 4] = {{(-3 - Sqrt[13])/2, -1, 1, -1}, 
    {(-3 - Sqrt[13])/2, (-7 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6, (-7 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (7 + Sqrt[13])/6, (-1 - Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 5, 4, 5] = 
   {{(-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, 
     Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(-1 - Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 5, 5, 1] = {{-1}}
 
haargrup6Cat4FMatrixFunction[5, 5, 5, 3] = 
   {{Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0], (-1 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6}, {(1 + Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 1, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 2, 0], 
     (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 5, 5, 4] = 
   {{(-1 - Sqrt[13])/6, (-1 - Sqrt[13])/6, 
     Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0]}, 
    {(1 + Sqrt[13])/6, Root[-1 + 5*#1 + #1^2 + 3*#1^3 + 9*#1^4 & , 2, 0], 
     (-1 - Sqrt[13])/6}, {Root[-1 - 5*#1 + #1^2 - 3*#1^3 + 9*#1^4 & , 1, 0], 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[5, 5, 5, 5] = {{(-3 - Sqrt[13])/2, -1, 1, 1}, 
    {(3 + Sqrt[13])/2, (1 + Sqrt[13])/6, (-7 - Sqrt[13])/6, 
     (-1 - Sqrt[13])/6}, {(-3 - Sqrt[13])/2, (-7 - Sqrt[13])/6, 
     (1 + Sqrt[13])/6, (1 + Sqrt[13])/6}, {(-3 - Sqrt[13])/2, 
     (-1 - Sqrt[13])/6, (1 + Sqrt[13])/6, (7 + Sqrt[13])/6}}
 
haargrup6Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haargrup6Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haargrup6Cat4FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haargrup6Cat4], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[haargrup6Cat4Piv1] ^= {}
 
fusionCategory[haargrup6Cat4Piv1] ^= haargrup6Cat4
 
haargrup6Cat4Piv1 /: modularCategory[haargrup6Cat4Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[haargrup6Cat4Piv1] ^= haargrup6Cat4Piv1
 
pivotalIsomorphism[haargrup6Cat4Piv1] ^= haargrup6Cat4Piv1PivotalIsomorphism
 
ring[haargrup6Cat4Piv1] ^= haargrup6
 
sphericalCategory[haargrup6Cat4Piv1] ^= haargrup6Cat4Piv1
 
(pivotalCategoryIndex[fusionCategory[haargrup6Cat4]][pivotalCategory[#1]] & )[
    haargrup6Cat4Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haargrup6Cat4]][
      sphericalCategory[#1]] & )[haargrup6Cat4Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haargrup6Cat4Piv1PivotalIsomorphism] ^= haargrup6Cat4
 
pivotalCategory[haargrup6Cat4Piv1PivotalIsomorphism] ^= haargrup6Cat4Piv1
 
pivotalIsomorphism[haargrup6Cat4Piv1PivotalIsomorphism] ^= 
   haargrup6Cat4Piv1PivotalIsomorphism
 
haargrup6Cat4Piv1PivotalIsomorphism[0] = 1
 
haargrup6Cat4Piv1PivotalIsomorphism[1] = 1
 
haargrup6Cat4Piv1PivotalIsomorphism[2] = 1
 
haargrup6Cat4Piv1PivotalIsomorphism[3] = 1
 
haargrup6Cat4Piv1PivotalIsomorphism[4] = 1
 
haargrup6Cat4Piv1PivotalIsomorphism[5] = 1
balancedCategories[haargrup6Cat5] ^= {}
 
braidedCategories[haargrup6Cat5] ^= {}
 
coeval[haargrup6Cat5] ^= 1/sixJFunction[haargrup6Cat5][#1, 
      dual[ring[haargrup6Cat5]][#1], #1, #1, 0, 0] & 
 
eval[haargrup6Cat5] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haargrup6Cat5] ^= haargrup6Cat5FMatrixFunction
 
fusionCategory[haargrup6Cat5] ^= haargrup6Cat5
 
haargrup6Cat5 /: modularCategory[haargrup6Cat5, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[haargrup6Cat5] ^= {haargrup6Cat5Piv1}
 
haargrup6Cat5 /: pivotalCategory[haargrup6Cat5, 1] = haargrup6Cat5Piv1
 
haargrup6Cat5 /: pivotalCategory[haargrup6Cat5, {1, (-1 + I*Sqrt[3])/2, 
      (-1 - I*Sqrt[3])/2, 1, 1, 1}] = haargrup6Cat5Piv1
 
ring[haargrup6Cat5] ^= haargrup6
 
haargrup6Cat5 /: sphericalCategory[haargrup6Cat5, 1] = haargrup6Cat5Piv1
 
fusionCategoryIndex[haargrup6][haargrup6Cat5] ^= 5
fMatrixFunction[haargrup6Cat5FMatrixFunction] ^= haargrup6Cat5FMatrixFunction
 
fusionCategory[haargrup6Cat5FMatrixFunction] ^= haargrup6Cat5
 
ring[haargrup6Cat5FMatrixFunction] ^= haargrup6
 
haargrup6Cat5FMatrixFunction[1, 1, 1, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 1, 2, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 1, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 1, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 2, 1, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 2, 2, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 2, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 2, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 3, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[1, 3, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 3, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 3, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 3, 4, 3] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[1, 3, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 3, 5, 3] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[1, 3, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[1, 3, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[1, 4, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[1, 4, 2, 3] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[1, 4, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 4, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 4, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 4, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 4, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 4, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haargrup6Cat5FMatrixFunction[1, 4, 5, 3] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haargrup6Cat5FMatrixFunction[1, 4, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[1, 5, 1, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[1, 5, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 5, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 5, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 5, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[1, 5, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 1, 1, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 1, 2, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 1, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 2, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 3, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[2, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 3, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 3, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 3, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 3, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 3, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 3, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 3, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 3, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 3, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 4, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 4, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[2, 4, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 4, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 4, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[2, 4, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 4, 5, 3] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[2, 4, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[2, 4, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[2, 5, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[2, 5, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[2, 5, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 5, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 5, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 5, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haargrup6Cat5FMatrixFunction[2, 5, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haargrup6Cat5FMatrixFunction[2, 5, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[2, 5, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[3, 1, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 1, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 1, 3, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[3, 1, 3, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[3, 1, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[3, 1, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[3, 1, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 1, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 2, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 2, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[3, 2, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[3, 2, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[3, 2, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[3, 3, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 3, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 3, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 3, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 3, 3, 3] = 
   {{(-3 + Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), -1, (1 + I*Sqrt[3])/2}, 
    {(-3 + Sqrt[13])/2, 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 3, 3, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 3, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat5FMatrixFunction[3, 3, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 3, 4, 4] = 
   {{(-3 + Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), (1 + I*Sqrt[3])/2, 
     (I/2)*(I + Sqrt[3])}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {(-3 + Sqrt[13])/2, 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}}
 
haargrup6Cat5FMatrixFunction[3, 3, 4, 5] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haargrup6Cat5FMatrixFunction[3, 3, 5, 4] = 
   {{(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 3, 5, 5] = 
   {{(-3 + Sqrt[13])/2, 1, -1, (1 + I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 4, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 4, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[3, 4, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 4, 3, 4] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat5FMatrixFunction[3, 4, 3, 5] = 
   {{(-3 + Sqrt[13])/2, -1, 1, (1 - I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 4, 4, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], -1, 1, 
     (1 - I*Sqrt[3])/2}, {(-3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 
      0]}, {(3 - Sqrt[13])/2, 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0}}
 
haargrup6Cat5FMatrixFunction[3, 4, 4, 4] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 4, 5, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 4, 5, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], -1, 1, 1}, 
    {(3 - Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 
      0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 1, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(-3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 5, 1, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 5, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 5, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 5, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 5, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[3, 5, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[3, 5, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat5FMatrixFunction[3, 5, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], (1 + I*Sqrt[3])/2, 
     (-I/2)*(-I + Sqrt[3]), -1}, {(3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, {(-3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 5, 3, 5] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 5, 4, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[3, 5, 4, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 6, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 5, 4, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 5, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], (1 + I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}}
 
haargrup6Cat5FMatrixFunction[3, 5, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[3, 5, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], (1 + I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, {(-3 + Sqrt[13])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 
      0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 
        3*#1^7 + #1^8 & , 8, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 5, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0]}}
 
haargrup6Cat5FMatrixFunction[3, 5, 5, 5] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 1, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 1, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 1, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 1, 3, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[4, 1, 4, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[4, 1, 4, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[4, 1, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[4, 1, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 1, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 1, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 1, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 2, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 2, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haargrup6Cat5FMatrixFunction[4, 2, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 2, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 2, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[4, 2, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 2, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 2, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[4, 3, 1, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 3, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[4, 3, 2, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 3, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haargrup6Cat5FMatrixFunction[4, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 3, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], -1, 1, 
     (1 - I*Sqrt[3])/2}, {(-3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}}
 
haargrup6Cat5FMatrixFunction[4, 3, 3, 5] = 
   {{(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 3, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haargrup6Cat5FMatrixFunction[4, 3, 4, 4] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 3, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], (1 - I*Sqrt[3])/2, 
     -1, (I/2)*(I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 3, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 3, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 3, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], (1 + I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 3, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 3, 5, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 5, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 4, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 4, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[4, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 4, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 4, 3, 3] = 
   {{(-3 + Sqrt[13])/2, 1, (1 - I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, 
    {(3 - Sqrt[13])/2, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {(-3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0}}
 
haargrup6Cat5FMatrixFunction[4, 4, 3, 4] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 4, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haargrup6Cat5FMatrixFunction[4, 4, 4, 3] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 4, 4, 4] = {{(-3 + Sqrt[13])/2, 1, -1, -1}, 
    {(-3 + Sqrt[13])/2, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {(3 - Sqrt[13])/2, 0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haargrup6Cat5FMatrixFunction[4, 4, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[4, 4, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 4, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 
        2*#1^5 + 6*#1^6 + 2*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat5FMatrixFunction[4, 4, 5, 5] = 
   {{(-3 + Sqrt[13])/2, (I/2)*(I + Sqrt[3]), (1 - I*Sqrt[3])/2, 
     (I/2)*(I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 
      0], 0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {(3 - Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 5, 1, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 5, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 5, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 5, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[4, 5, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[4, 5, 3, 1] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[4, 5, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[4, 5, 3, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 5, 3, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], (1 - I*Sqrt[3])/2, 
     -1, (I/2)*(I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 2, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}}
 
haargrup6Cat5FMatrixFunction[4, 5, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haargrup6Cat5FMatrixFunction[4, 5, 4, 3] = 
   {{(3 - Sqrt[13])/2, (1 - I*Sqrt[3])/2, -1, (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 5, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haargrup6Cat5FMatrixFunction[4, 5, 4, 5] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 5, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[4, 5, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[4, 5, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 5, 5, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], (1 - I*Sqrt[3])/2, 
     -1, -1}, {(-3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     0}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}}
 
haargrup6Cat5FMatrixFunction[4, 5, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 1, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 1, 3, 1] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[5, 1, 3, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[5, 1, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 1, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haargrup6Cat5FMatrixFunction[5, 1, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[5, 2, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 2, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 2, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 2, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 2, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haargrup6Cat5FMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haargrup6Cat5FMatrixFunction[5, 2, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[5, 2, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 2, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haargrup6Cat5FMatrixFunction[5, 3, 1, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 3, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[5, 3, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[5, 3, 2, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 3, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haargrup6Cat5FMatrixFunction[5, 3, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 3, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haargrup6Cat5FMatrixFunction[5, 3, 3, 4] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 3, 3, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], (1 + I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 3, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 3, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 3, 4, 3] = 
   {{(-3 + Sqrt[13])/2, -1, (1 + I*Sqrt[3])/2, 1}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 3, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 3, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}}
 
haargrup6Cat5FMatrixFunction[5, 3, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 3, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 3, 5, 4] = 
   {{(3 - Sqrt[13])/2, (1 + I*Sqrt[3])/2, (1 - I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, {(-3 + Sqrt[13])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}}
 
haargrup6Cat5FMatrixFunction[5, 3, 5, 5] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 6, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 4, 1, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 4, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[5, 4, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[5, 4, 2, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 4, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[5, 4, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haargrup6Cat5FMatrixFunction[5, 4, 3, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 4, 3, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], (1 - I*Sqrt[3])/2, 
     (I/2)*(I + Sqrt[3]), (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haargrup6Cat5FMatrixFunction[5, 4, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 4, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 4, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 4, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat5FMatrixFunction[5, 4, 4, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], (1 - I*Sqrt[3])/2, 
     -1, -1}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0}, {(-3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 4, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 4, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 4, 5, 3] = 
   {{(3 - Sqrt[13])/2, (1 + I*Sqrt[3])/2, (1 - I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, {(-3 + Sqrt[13])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}}
 
haargrup6Cat5FMatrixFunction[5, 4, 5, 4] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 5, 1, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haargrup6Cat5FMatrixFunction[5, 5, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[5, 5, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 5, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[5, 5, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haargrup6Cat5FMatrixFunction[5, 5, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 5, 3, 3] = 
   {{(-3 + Sqrt[13])/2, (I/2)*(I + Sqrt[3]), -1, (1 - I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 5, 3, 5] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 5, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[5, 5, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 5, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 5, 4, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     (-I/2)*(-I + Sqrt[3]), -1, (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 5, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 5, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 5, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat5FMatrixFunction[5, 5, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat5FMatrixFunction[5, 5, 5, 3] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 5, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}}
 
haargrup6Cat5FMatrixFunction[5, 5, 5, 5] = 
   {{(-3 + Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), -1, (1 - I*Sqrt[3])/2}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {(3 - Sqrt[13])/2, 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0}}
 
haargrup6Cat5FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haargrup6Cat5], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haargrup6Cat5FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haargrup6Cat5], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[haargrup6Cat5Piv1] ^= {}
 
fusionCategory[haargrup6Cat5Piv1] ^= haargrup6Cat5
 
haargrup6Cat5Piv1 /: modularCategory[haargrup6Cat5Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[haargrup6Cat5Piv1] ^= haargrup6Cat5Piv1
 
pivotalIsomorphism[haargrup6Cat5Piv1] ^= haargrup6Cat5Piv1PivotalIsomorphism
 
ring[haargrup6Cat5Piv1] ^= haargrup6
 
sphericalCategory[haargrup6Cat5Piv1] ^= haargrup6Cat5Piv1
 
(pivotalCategoryIndex[fusionCategory[haargrup6Cat5]][pivotalCategory[#1]] & )[
    haargrup6Cat5Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haargrup6Cat5]][
      sphericalCategory[#1]] & )[haargrup6Cat5Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haargrup6Cat5Piv1PivotalIsomorphism] ^= haargrup6Cat5
 
pivotalCategory[haargrup6Cat5Piv1PivotalIsomorphism] ^= haargrup6Cat5Piv1
 
pivotalIsomorphism[haargrup6Cat5Piv1PivotalIsomorphism] ^= 
   haargrup6Cat5Piv1PivotalIsomorphism
 
haargrup6Cat5Piv1PivotalIsomorphism[0] = 1
 
haargrup6Cat5Piv1PivotalIsomorphism[1] = (-1 + I*Sqrt[3])/2
 
haargrup6Cat5Piv1PivotalIsomorphism[2] = (-1 - I*Sqrt[3])/2
 
haargrup6Cat5Piv1PivotalIsomorphism[3] = 1
 
haargrup6Cat5Piv1PivotalIsomorphism[4] = 1
 
haargrup6Cat5Piv1PivotalIsomorphism[5] = 1
balancedCategories[haargrup6Cat6] ^= {}
 
braidedCategories[haargrup6Cat6] ^= {}
 
coeval[haargrup6Cat6] ^= 1/sixJFunction[haargrup6Cat6][#1, 
      dual[ring[haargrup6Cat6]][#1], #1, #1, 0, 0] & 
 
eval[haargrup6Cat6] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haargrup6Cat6] ^= haargrup6Cat6FMatrixFunction
 
fusionCategory[haargrup6Cat6] ^= haargrup6Cat6
 
haargrup6Cat6 /: modularCategory[haargrup6Cat6, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[haargrup6Cat6] ^= {haargrup6Cat6Piv1}
 
haargrup6Cat6 /: pivotalCategory[haargrup6Cat6, 1] = haargrup6Cat6Piv1
 
haargrup6Cat6 /: pivotalCategory[haargrup6Cat6, {1, (-1 + I*Sqrt[3])/2, 
      (-1 - I*Sqrt[3])/2, 1, 1, 1}] = haargrup6Cat6Piv1
 
ring[haargrup6Cat6] ^= haargrup6
 
haargrup6Cat6 /: sphericalCategory[haargrup6Cat6, 1] = haargrup6Cat6Piv1
 
fusionCategoryIndex[haargrup6][haargrup6Cat6] ^= 6
fMatrixFunction[haargrup6Cat6FMatrixFunction] ^= haargrup6Cat6FMatrixFunction
 
fusionCategory[haargrup6Cat6FMatrixFunction] ^= haargrup6Cat6
 
ring[haargrup6Cat6FMatrixFunction] ^= haargrup6
 
haargrup6Cat6FMatrixFunction[1, 1, 1, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 1, 2, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 1, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 1, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 2, 1, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 2, 2, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 2, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 2, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 3, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[1, 3, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 3, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 3, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 3, 4, 3] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[1, 3, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 3, 5, 3] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[1, 3, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[1, 3, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[1, 4, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[1, 4, 2, 3] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[1, 4, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 4, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 4, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 4, 3, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 4, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 4, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haargrup6Cat6FMatrixFunction[1, 4, 5, 3] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haargrup6Cat6FMatrixFunction[1, 4, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[1, 5, 1, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[1, 5, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 5, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 5, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 5, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[1, 5, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 1, 1, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 1, 2, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 1, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 2, 4, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 3, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[2, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 3, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 3, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 3, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 3, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 3, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 3, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 3, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 3, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 3, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 4, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 4, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[2, 4, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 4, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 4, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[2, 4, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 4, 5, 3] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[2, 4, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[2, 4, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[2, 5, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[2, 5, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[2, 5, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 5, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 5, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 5, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haargrup6Cat6FMatrixFunction[2, 5, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haargrup6Cat6FMatrixFunction[2, 5, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[2, 5, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[3, 1, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 1, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 1, 3, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[3, 1, 3, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[3, 1, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[3, 1, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[3, 1, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 1, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 2, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 2, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[3, 2, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[3, 2, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[3, 2, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[3, 3, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 3, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 3, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 3, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 3, 3, 3] = 
   {{(-3 - Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), -1, (1 + I*Sqrt[3])/2}, 
    {(-3 - Sqrt[13])/2, 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 3, 3, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}, 
    {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 3, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat6FMatrixFunction[3, 3, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 3, 4, 4] = 
   {{(-3 - Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), (1 + I*Sqrt[3])/2, 
     (I/2)*(I + Sqrt[3])}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}, 
    {(-3 - Sqrt[13])/2, 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 0}}
 
haargrup6Cat6FMatrixFunction[3, 3, 4, 5] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}, {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat6FMatrixFunction[3, 3, 5, 4] = 
   {{(-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], (-1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 3, 5, 5] = 
   {{(-3 - Sqrt[13])/2, 1, -1, (1 + I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 4, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 4, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[3, 4, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 4, 3, 4] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}, 
    {(-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat6FMatrixFunction[3, 4, 3, 5] = 
   {{(-3 - Sqrt[13])/2, -1, 1, (1 - I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 4, 4, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], -1, 1, 
     (1 - I*Sqrt[3])/2}, {(-3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 
      0]}, {(3 + Sqrt[13])/2, 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0}}
 
haargrup6Cat6FMatrixFunction[3, 4, 4, 4] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 4, 5, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 4, 5, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], -1, 1, 1}, 
    {(3 + Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 
      0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 8, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {(-3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 8, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 5, 1, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 5, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 5, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 5, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 5, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[3, 5, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[3, 5, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}, {(-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat6FMatrixFunction[3, 5, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], (1 + I*Sqrt[3])/2, 
     (-I/2)*(-I + Sqrt[3]), -1}, {(3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 0}, {(-3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 5, 3, 5] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], (-1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {(-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 5, 4, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[3, 5, 4, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 5, 4, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}, {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 5, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], (1 + I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 0}}
 
haargrup6Cat6FMatrixFunction[3, 5, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[3, 5, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], (1 + I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, {(-3 - Sqrt[13])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 
      0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 
        3*#1^7 + #1^8 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 5, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 1, 0]}}
 
haargrup6Cat6FMatrixFunction[3, 5, 5, 5] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 1, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 1, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 1, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 1, 3, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[4, 1, 4, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[4, 1, 4, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[4, 1, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[4, 1, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 1, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 1, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 1, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 2, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 2, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haargrup6Cat6FMatrixFunction[4, 2, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 2, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 2, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[4, 2, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 2, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 2, 5, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[4, 3, 1, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 3, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[4, 3, 2, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 3, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haargrup6Cat6FMatrixFunction[4, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 3, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], -1, 1, 
     (1 - I*Sqrt[3])/2}, {(-3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 0}}
 
haargrup6Cat6FMatrixFunction[4, 3, 3, 5] = 
   {{(-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 3, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}, {(-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat6FMatrixFunction[4, 3, 4, 4] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 3, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], (1 - I*Sqrt[3])/2, 
     -1, (I/2)*(I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      1, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 3, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 3, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 3, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], (1 + I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 3, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 3, 5, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 8, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 4, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 4, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[4, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 4, 2, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 4, 3, 3] = 
   {{(-3 - Sqrt[13])/2, 1, (1 - I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, 
    {(3 + Sqrt[13])/2, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}, {(-3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0}}
 
haargrup6Cat6FMatrixFunction[4, 4, 3, 4] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 4, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haargrup6Cat6FMatrixFunction[4, 4, 4, 3] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 4, 4, 4] = {{(-3 - Sqrt[13])/2, 1, -1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}, 
    {(3 + Sqrt[13])/2, 0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat6FMatrixFunction[4, 4, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[4, 4, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 4, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 
        2*#1^5 + 6*#1^6 + 2*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat6FMatrixFunction[4, 4, 5, 5] = 
   {{(-3 - Sqrt[13])/2, (I/2)*(I + Sqrt[3]), (1 - I*Sqrt[3])/2, 
     (I/2)*(I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 
      0], 0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {(3 + Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 5, 1, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 5, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 5, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 5, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[4, 5, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[4, 5, 3, 1] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[4, 5, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[4, 5, 3, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}, {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 5, 3, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], (1 - I*Sqrt[3])/2, 
     -1, (I/2)*(I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      1, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 3, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {(3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 0}}
 
haargrup6Cat6FMatrixFunction[4, 5, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haargrup6Cat6FMatrixFunction[4, 5, 4, 3] = 
   {{(3 + Sqrt[13])/2, (1 - I*Sqrt[3])/2, -1, (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 5, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {(-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat6FMatrixFunction[4, 5, 4, 5] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 5, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[4, 5, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[4, 5, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 1, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 5, 5, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], (1 - I*Sqrt[3])/2, 
     -1, -1}, {(-3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     0}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}}
 
haargrup6Cat6FMatrixFunction[4, 5, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 1, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 1, 3, 1] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[5, 1, 3, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[5, 1, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 1, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haargrup6Cat6FMatrixFunction[5, 1, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[5, 2, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 2, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 2, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 2, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 2, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haargrup6Cat6FMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haargrup6Cat6FMatrixFunction[5, 2, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[5, 2, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 2, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haargrup6Cat6FMatrixFunction[5, 3, 1, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 3, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[5, 3, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[5, 3, 2, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 3, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haargrup6Cat6FMatrixFunction[5, 3, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 3, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat6FMatrixFunction[5, 3, 3, 4] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 3, 3, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], (1 + I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 3, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 3, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 3, 4, 3] = 
   {{(-3 - Sqrt[13])/2, -1, (1 + I*Sqrt[3])/2, 1}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 3, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 3, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat6FMatrixFunction[5, 3, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 3, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {(-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 3, 5, 4] = 
   {{(3 + Sqrt[13])/2, (1 + I*Sqrt[3])/2, (1 - I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, {(-3 - Sqrt[13])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 0}}
 
haargrup6Cat6FMatrixFunction[5, 3, 5, 5] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 4, 1, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 4, 1, 3] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[5, 4, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[5, 4, 2, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 4, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 4, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[5, 4, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haargrup6Cat6FMatrixFunction[5, 4, 3, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], (-1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 4, 3, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], (1 - I*Sqrt[3])/2, 
     (I/2)*(I + Sqrt[3]), (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat6FMatrixFunction[5, 4, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 4, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 4, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 4, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}, {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat6FMatrixFunction[5, 4, 4, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], (1 - I*Sqrt[3])/2, 
     -1, -1}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0}, {(-3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 4, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 4, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 4, 5, 3] = 
   {{(3 + Sqrt[13])/2, (1 + I*Sqrt[3])/2, (1 - I*Sqrt[3])/2, 
     (1 - I*Sqrt[3])/2}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, {(-3 - Sqrt[13])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 0}}
 
haargrup6Cat6FMatrixFunction[5, 4, 5, 4] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 5, 1, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haargrup6Cat6FMatrixFunction[5, 5, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[5, 5, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 5, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[5, 5, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haargrup6Cat6FMatrixFunction[5, 5, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 5, 3, 3] = 
   {{(-3 - Sqrt[13])/2, (I/2)*(I + Sqrt[3]), -1, (1 - I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 7, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 5, 3, 5] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 5, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[5, 5, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 5, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 7, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 5, 4, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-I/2)*(-I + Sqrt[3]), -1, (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 0}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 5, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}, {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 5, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 5, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat6FMatrixFunction[5, 5, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat6FMatrixFunction[5, 5, 5, 3] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 5, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}}
 
haargrup6Cat6FMatrixFunction[5, 5, 5, 5] = 
   {{(-3 - Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), -1, (1 - I*Sqrt[3])/2}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}, {(3 + Sqrt[13])/2, 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0}}
 
haargrup6Cat6FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haargrup6Cat6], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haargrup6Cat6FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haargrup6Cat6], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[haargrup6Cat6Piv1] ^= {}
 
fusionCategory[haargrup6Cat6Piv1] ^= haargrup6Cat6
 
haargrup6Cat6Piv1 /: modularCategory[haargrup6Cat6Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[haargrup6Cat6Piv1] ^= haargrup6Cat6Piv1
 
pivotalIsomorphism[haargrup6Cat6Piv1] ^= haargrup6Cat6Piv1PivotalIsomorphism
 
ring[haargrup6Cat6Piv1] ^= haargrup6
 
sphericalCategory[haargrup6Cat6Piv1] ^= haargrup6Cat6Piv1
 
(pivotalCategoryIndex[fusionCategory[haargrup6Cat6]][pivotalCategory[#1]] & )[
    haargrup6Cat6Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haargrup6Cat6]][
      sphericalCategory[#1]] & )[haargrup6Cat6Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haargrup6Cat6Piv1PivotalIsomorphism] ^= haargrup6Cat6
 
pivotalCategory[haargrup6Cat6Piv1PivotalIsomorphism] ^= haargrup6Cat6Piv1
 
pivotalIsomorphism[haargrup6Cat6Piv1PivotalIsomorphism] ^= 
   haargrup6Cat6Piv1PivotalIsomorphism
 
haargrup6Cat6Piv1PivotalIsomorphism[0] = 1
 
haargrup6Cat6Piv1PivotalIsomorphism[1] = (-1 + I*Sqrt[3])/2
 
haargrup6Cat6Piv1PivotalIsomorphism[2] = (-1 - I*Sqrt[3])/2
 
haargrup6Cat6Piv1PivotalIsomorphism[3] = 1
 
haargrup6Cat6Piv1PivotalIsomorphism[4] = 1
 
haargrup6Cat6Piv1PivotalIsomorphism[5] = 1
balancedCategories[haargrup6Cat7] ^= {}
 
braidedCategories[haargrup6Cat7] ^= {}
 
coeval[haargrup6Cat7] ^= 1/sixJFunction[haargrup6Cat7][#1, 
      dual[ring[haargrup6Cat7]][#1], #1, #1, 0, 0] & 
 
eval[haargrup6Cat7] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haargrup6Cat7] ^= haargrup6Cat7FMatrixFunction
 
fusionCategory[haargrup6Cat7] ^= haargrup6Cat7
 
haargrup6Cat7 /: modularCategory[haargrup6Cat7, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[haargrup6Cat7] ^= {haargrup6Cat7Piv1}
 
haargrup6Cat7 /: pivotalCategory[haargrup6Cat7, 1] = haargrup6Cat7Piv1
 
haargrup6Cat7 /: pivotalCategory[haargrup6Cat7, {1, (-1 - I*Sqrt[3])/2, 
      (-1 + I*Sqrt[3])/2, 1, 1, 1}] = haargrup6Cat7Piv1
 
ring[haargrup6Cat7] ^= haargrup6
 
haargrup6Cat7 /: sphericalCategory[haargrup6Cat7, 1] = haargrup6Cat7Piv1
 
fusionCategoryIndex[haargrup6][haargrup6Cat7] ^= 7
fMatrixFunction[haargrup6Cat7FMatrixFunction] ^= haargrup6Cat7FMatrixFunction
 
fusionCategory[haargrup6Cat7FMatrixFunction] ^= haargrup6Cat7
 
ring[haargrup6Cat7FMatrixFunction] ^= haargrup6
 
haargrup6Cat7FMatrixFunction[1, 1, 1, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 1, 2, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 1, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 1, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 2, 1, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 2, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 2, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 2, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 3, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[1, 3, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 3, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 3, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 3, 4, 3] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[1, 3, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 3, 5, 3] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[1, 3, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[1, 3, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[1, 4, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[1, 4, 2, 3] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[1, 4, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 4, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 4, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 4, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 4, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 4, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haargrup6Cat7FMatrixFunction[1, 4, 5, 3] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haargrup6Cat7FMatrixFunction[1, 4, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[1, 5, 1, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[1, 5, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 5, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 5, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 5, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[1, 5, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 1, 1, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 1, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 1, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 2, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 3, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[2, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 3, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 3, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 3, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 3, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 3, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 3, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 3, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 3, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 3, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 4, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 4, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[2, 4, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 4, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 4, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 4, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[2, 4, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 4, 5, 3] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[2, 4, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[2, 4, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[2, 5, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[2, 5, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[2, 5, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 5, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 5, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 5, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haargrup6Cat7FMatrixFunction[2, 5, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haargrup6Cat7FMatrixFunction[2, 5, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[2, 5, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[3, 1, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 1, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 1, 3, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[3, 1, 3, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[3, 1, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[3, 1, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[3, 1, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 1, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 2, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 2, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[3, 2, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[3, 2, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[3, 2, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[3, 3, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 3, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 3, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 3, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 3, 3, 3] = 
   {{(-3 + Sqrt[13])/2, (I/2)*(I + Sqrt[3]), -1, (1 - I*Sqrt[3])/2}, 
    {(-3 + Sqrt[13])/2, 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 3, 3, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 3, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haargrup6Cat7FMatrixFunction[3, 3, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 3, 4, 4] = 
   {{(-3 + Sqrt[13])/2, (I/2)*(I + Sqrt[3]), (1 - I*Sqrt[3])/2, 
     (-I/2)*(-I + Sqrt[3])}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {(-3 + Sqrt[13])/2, 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}}
 
haargrup6Cat7FMatrixFunction[3, 3, 4, 5] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat7FMatrixFunction[3, 3, 5, 4] = 
   {{(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 3, 5, 5] = 
   {{(-3 + Sqrt[13])/2, 1, -1, (1 - I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 4, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 4, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[3, 4, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 4, 3, 4] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haargrup6Cat7FMatrixFunction[3, 4, 3, 5] = 
   {{(-3 + Sqrt[13])/2, -1, 1, (1 + I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 4, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 4, 4, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], -1, 1, 
     (1 + I*Sqrt[3])/2}, {(-3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 
      0]}, {(3 - Sqrt[13])/2, 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {(-3 + Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0}}
 
haargrup6Cat7FMatrixFunction[3, 4, 4, 4] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 4, 5, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 4, 5, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], -1, 1, 1}, 
    {(3 - Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 
      0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 2, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(-3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 5, 1, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 5, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 5, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 5, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 5, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[3, 5, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[3, 5, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haargrup6Cat7FMatrixFunction[3, 5, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], (1 - I*Sqrt[3])/2, 
     (I/2)*(I + Sqrt[3]), -1}, {(3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 0}, {(-3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 5, 3, 5] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 5, 4, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[3, 5, 4, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 5, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 5, 4, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 5, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], (1 - I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}}
 
haargrup6Cat7FMatrixFunction[3, 5, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[3, 5, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], (1 - I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, {(-3 + Sqrt[13])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 
      0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 
        3*#1^7 + #1^8 & , 7, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 5, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 4, 0]}}
 
haargrup6Cat7FMatrixFunction[3, 5, 5, 5] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 1, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 1, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 1, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 1, 3, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[4, 1, 4, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[4, 1, 4, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[4, 1, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[4, 1, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 1, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 1, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 1, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 2, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 2, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haargrup6Cat7FMatrixFunction[4, 2, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 2, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 2, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[4, 2, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 2, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 2, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[4, 3, 1, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 3, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[4, 3, 2, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 3, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haargrup6Cat7FMatrixFunction[4, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 3, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], -1, 1, 
     (1 + I*Sqrt[3])/2}, {(-3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}}
 
haargrup6Cat7FMatrixFunction[4, 3, 3, 5] = 
   {{(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 3, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat7FMatrixFunction[4, 3, 4, 4] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 3, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], (1 + I*Sqrt[3])/2, 
     -1, (-I/2)*(-I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 3, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 3, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 3, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], (1 - I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 3, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 3, 5, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 6, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 4, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 4, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[4, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 4, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 4, 3, 3] = 
   {{(-3 + Sqrt[13])/2, 1, (1 + I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, 
    {(3 - Sqrt[13])/2, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {(-3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0}}
 
haargrup6Cat7FMatrixFunction[4, 4, 3, 4] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 4, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haargrup6Cat7FMatrixFunction[4, 4, 4, 3] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 4, 4, 4] = {{(-3 + Sqrt[13])/2, 1, -1, -1}, 
    {(-3 + Sqrt[13])/2, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {(3 - Sqrt[13])/2, 0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat7FMatrixFunction[4, 4, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[4, 4, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 4, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 
        2*#1^5 + 6*#1^6 + 2*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haargrup6Cat7FMatrixFunction[4, 4, 5, 5] = 
   {{(-3 + Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), (1 + I*Sqrt[3])/2, 
     (-I/2)*(-I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 
      0], 0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {(3 - Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 5, 1, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 5, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 5, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 5, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[4, 5, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[4, 5, 3, 1] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[4, 5, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[4, 5, 3, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 5, 3, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], (1 + I*Sqrt[3])/2, 
     -1, (-I/2)*(-I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 1, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}}
 
haargrup6Cat7FMatrixFunction[4, 5, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haargrup6Cat7FMatrixFunction[4, 5, 4, 3] = 
   {{(3 - Sqrt[13])/2, (1 + I*Sqrt[3])/2, -1, (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 5, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat7FMatrixFunction[4, 5, 4, 5] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 5, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[4, 5, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[4, 5, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 5, 5, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], (1 + I*Sqrt[3])/2, 
     -1, -1}, {(-3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     0}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}}
 
haargrup6Cat7FMatrixFunction[4, 5, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 1, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 1, 3, 1] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[5, 1, 3, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[5, 1, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 1, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haargrup6Cat7FMatrixFunction[5, 1, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[5, 2, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 2, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 2, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 2, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 2, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haargrup6Cat7FMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haargrup6Cat7FMatrixFunction[5, 2, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[5, 2, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 2, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haargrup6Cat7FMatrixFunction[5, 3, 1, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 3, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[5, 3, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[5, 3, 2, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 3, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haargrup6Cat7FMatrixFunction[5, 3, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 3, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat7FMatrixFunction[5, 3, 3, 4] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 3, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 3, 3, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], (1 - I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 3, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 3, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 3, 4, 3] = 
   {{(-3 + Sqrt[13])/2, -1, (1 - I*Sqrt[3])/2, 1}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 3, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 3, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}}
 
haargrup6Cat7FMatrixFunction[5, 3, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 3, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {(I/2)*(I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 3, 5, 4] = 
   {{(3 - Sqrt[13])/2, (1 - I*Sqrt[3])/2, (1 + I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, {(-3 + Sqrt[13])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}}
 
haargrup6Cat7FMatrixFunction[5, 3, 5, 5] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 5, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 4, 1, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 4, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[5, 4, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[5, 4, 2, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 4, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[5, 4, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haargrup6Cat7FMatrixFunction[5, 4, 3, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], (I/2)*(I + Sqrt[-7 + 2*Sqrt[13]])}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 4, 3, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], (1 + I*Sqrt[3])/2, 
     (-I/2)*(-I + Sqrt[3]), (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat7FMatrixFunction[5, 4, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 4, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (-I/2)*(-I + Sqrt[-7 + 2*Sqrt[13]]), 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 4, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2}}
 
haargrup6Cat7FMatrixFunction[5, 4, 4, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 2, 0], (1 + I*Sqrt[3])/2, 
     -1, -1}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], 0}, {(-3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 4, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 4, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 4, 5, 3] = 
   {{(3 - Sqrt[13])/2, (1 - I*Sqrt[3])/2, (1 + I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}, {(-3 + Sqrt[13])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}}
 
haargrup6Cat7FMatrixFunction[5, 4, 5, 4] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 5, 1, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haargrup6Cat7FMatrixFunction[5, 5, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[5, 5, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 5, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[5, 5, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haargrup6Cat7FMatrixFunction[5, 5, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 5, 3, 3] = 
   {{(-3 + Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), -1, (1 + I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 2, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 4, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 5, 3, 5] = 
   {{(1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 5, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[5, 5, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 5, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 3, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 5, 4, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], (I/2)*(I + Sqrt[3]), 
     -1, (-I/2)*(-I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      3, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 2, 0]}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 7, 0], 0}, {(3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 5, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 5, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 5, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 5, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat7FMatrixFunction[5, 5, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat7FMatrixFunction[5, 5, 5, 3] = 
   {{(1 + I*Sqrt[-7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 1, 0], (1 + I*Sqrt[-7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 3, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 5, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 3, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     (1 + Root[-3 - 14*#1^2 + #1^4 & , 3, 0])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 8, 0]}}
 
haargrup6Cat7FMatrixFunction[5, 5, 5, 5] = 
   {{(-3 + Sqrt[13])/2, (I/2)*(I + Sqrt[3]), -1, (1 + I*Sqrt[3])/2}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 5, 0]}, {(3 - Sqrt[13])/2, 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 8, 0], 0}}
 
haargrup6Cat7FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haargrup6Cat7], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haargrup6Cat7FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haargrup6Cat7], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[haargrup6Cat7Piv1] ^= {}
 
fusionCategory[haargrup6Cat7Piv1] ^= haargrup6Cat7
 
haargrup6Cat7Piv1 /: modularCategory[haargrup6Cat7Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[haargrup6Cat7Piv1] ^= haargrup6Cat7Piv1
 
pivotalIsomorphism[haargrup6Cat7Piv1] ^= haargrup6Cat7Piv1PivotalIsomorphism
 
ring[haargrup6Cat7Piv1] ^= haargrup6
 
sphericalCategory[haargrup6Cat7Piv1] ^= haargrup6Cat7Piv1
 
(pivotalCategoryIndex[fusionCategory[haargrup6Cat7]][pivotalCategory[#1]] & )[
    haargrup6Cat7Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haargrup6Cat7]][
      sphericalCategory[#1]] & )[haargrup6Cat7Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haargrup6Cat7Piv1PivotalIsomorphism] ^= haargrup6Cat7
 
pivotalCategory[haargrup6Cat7Piv1PivotalIsomorphism] ^= haargrup6Cat7Piv1
 
pivotalIsomorphism[haargrup6Cat7Piv1PivotalIsomorphism] ^= 
   haargrup6Cat7Piv1PivotalIsomorphism
 
haargrup6Cat7Piv1PivotalIsomorphism[0] = 1
 
haargrup6Cat7Piv1PivotalIsomorphism[1] = (-1 - I*Sqrt[3])/2
 
haargrup6Cat7Piv1PivotalIsomorphism[2] = (-1 + I*Sqrt[3])/2
 
haargrup6Cat7Piv1PivotalIsomorphism[3] = 1
 
haargrup6Cat7Piv1PivotalIsomorphism[4] = 1
 
haargrup6Cat7Piv1PivotalIsomorphism[5] = 1
balancedCategories[haargrup6Cat8] ^= {}
 
braidedCategories[haargrup6Cat8] ^= {}
 
coeval[haargrup6Cat8] ^= 1/sixJFunction[haargrup6Cat8][#1, 
      dual[ring[haargrup6Cat8]][#1], #1, #1, 0, 0] & 
 
eval[haargrup6Cat8] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[haargrup6Cat8] ^= haargrup6Cat8FMatrixFunction
 
fusionCategory[haargrup6Cat8] ^= haargrup6Cat8
 
haargrup6Cat8 /: modularCategory[haargrup6Cat8, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[haargrup6Cat8] ^= {haargrup6Cat8Piv1}
 
haargrup6Cat8 /: pivotalCategory[haargrup6Cat8, 1] = haargrup6Cat8Piv1
 
haargrup6Cat8 /: pivotalCategory[haargrup6Cat8, {1, (-1 - I*Sqrt[3])/2, 
      (-1 + I*Sqrt[3])/2, 1, 1, 1}] = haargrup6Cat8Piv1
 
ring[haargrup6Cat8] ^= haargrup6
 
haargrup6Cat8 /: sphericalCategory[haargrup6Cat8, 1] = haargrup6Cat8Piv1
 
fusionCategoryIndex[haargrup6][haargrup6Cat8] ^= 8
fMatrixFunction[haargrup6Cat8FMatrixFunction] ^= haargrup6Cat8FMatrixFunction
 
fusionCategory[haargrup6Cat8FMatrixFunction] ^= haargrup6Cat8
 
ring[haargrup6Cat8FMatrixFunction] ^= haargrup6
 
haargrup6Cat8FMatrixFunction[1, 1, 1, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 1, 2, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 1, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 1, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 2, 1, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 2, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 2, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 2, 5, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 3, 2, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[1, 3, 3, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 3, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 3, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 3, 4, 3] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[1, 3, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 3, 5, 3] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[1, 3, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[1, 3, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[1, 4, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[1, 4, 2, 3] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[1, 4, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 4, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 4, 3, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 4, 3, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 4, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 4, 4, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 4, 4, 4] = {{-1}}
 
haargrup6Cat8FMatrixFunction[1, 4, 5, 3] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[1, 4, 5, 4] = {{-1}}
 
haargrup6Cat8FMatrixFunction[1, 4, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[1, 5, 1, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[1, 5, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 5, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 5, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 5, 5, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[1, 5, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 1, 1, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 1, 2, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 1, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 2, 4, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 3, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[2, 3, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 3, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 3, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 3, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 3, 4, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 3, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 3, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 3, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 3, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 3, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 4, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 4, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[2, 4, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 4, 3, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 4, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 4, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[2, 4, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 4, 5, 3] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[2, 4, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[2, 4, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[2, 5, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[2, 5, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[2, 5, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 5, 3, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 5, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 5, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 5, 4, 3] = {{-1}}
 
haargrup6Cat8FMatrixFunction[2, 5, 5, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[2, 5, 5, 3] = {{-1}}
 
haargrup6Cat8FMatrixFunction[2, 5, 5, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[2, 5, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[3, 1, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 1, 3, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 1, 3, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[3, 1, 3, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[3, 1, 4, 1] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[3, 1, 4, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[3, 1, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 1, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 2, 4, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 2, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[3, 2, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[3, 2, 5, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[3, 2, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[3, 3, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 3, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 3, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 3, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 3, 3, 3] = 
   {{(-3 - Sqrt[13])/2, (I/2)*(I + Sqrt[3]), -1, (1 - I*Sqrt[3])/2}, 
    {(-3 - Sqrt[13])/2, 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 3, 3, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}, 
    {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 3, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat8FMatrixFunction[3, 3, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 3, 4, 4] = 
   {{(-3 - Sqrt[13])/2, (I/2)*(I + Sqrt[3]), (1 - I*Sqrt[3])/2, 
     (-I/2)*(-I + Sqrt[3])}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}, 
    {(-3 - Sqrt[13])/2, 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 0}}
 
haargrup6Cat8FMatrixFunction[3, 3, 4, 5] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}, {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat8FMatrixFunction[3, 3, 5, 4] = 
   {{(-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], (-1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 3, 5, 5] = 
   {{(-3 - Sqrt[13])/2, 1, -1, (1 - I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 4, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 4, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[3, 4, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 4, 3, 4] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}, 
    {(-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat8FMatrixFunction[3, 4, 3, 5] = 
   {{(-3 - Sqrt[13])/2, -1, 1, (1 + I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 4, 4, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 4, 4, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], -1, 1, 
     (1 + I*Sqrt[3])/2}, {(-3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 
      0]}, {(3 + Sqrt[13])/2, 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {(-3 - Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0}}
 
haargrup6Cat8FMatrixFunction[3, 4, 4, 4] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 4, 5, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 1, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 7, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 4, 5, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], -1, 1, 1}, 
    {(3 + Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 
      0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 3, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {(-3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 2, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 5, 1, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 5, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 5, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 5, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 5, 2, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[3, 5, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[3, 5, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}, {(-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat8FMatrixFunction[3, 5, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], (1 - I*Sqrt[3])/2, 
     (I/2)*(I + Sqrt[3]), -1}, {(3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 0}, {(-3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 5, 3, 5] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], (-1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {(-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 5, 4, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[3, 5, 4, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 8, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 5, 4, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}, {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 5, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], (1 - I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 0}}
 
haargrup6Cat8FMatrixFunction[3, 5, 5, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[3, 5, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], (1 - I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, {(-3 - Sqrt[13])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 
      0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 
        3*#1^7 + #1^8 & , 6, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 5, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 7, 0]}}
 
haargrup6Cat8FMatrixFunction[3, 5, 5, 5] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 7, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 1, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 1, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 1, 3, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 1, 3, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[4, 1, 4, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[4, 1, 4, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[4, 1, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[4, 1, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 1, 5, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 1, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 1, 5, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 2, 1, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 2, 3, 2] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[4, 2, 4, 1] = {{-1}}
 
haargrup6Cat8FMatrixFunction[4, 2, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 2, 4, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 2, 4, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[4, 2, 5, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 2, 5, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 2, 5, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[4, 3, 1, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 3, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[4, 3, 2, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 3, 2, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 3, 2, 5] = {{-1}}
 
haargrup6Cat8FMatrixFunction[4, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 3, 3, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], -1, 1, 
     (1 + I*Sqrt[3])/2}, {(-3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 0}}
 
haargrup6Cat8FMatrixFunction[4, 3, 3, 5] = 
   {{(-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 3, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 3, 4, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}, {(-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat8FMatrixFunction[4, 3, 4, 4] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 3, 4, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], (1 + I*Sqrt[3])/2, 
     -1, (-I/2)*(-I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 3, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 3, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 3, 5, 3] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], (1 - I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 3, 5, 4] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 3, 5, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 2, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 4, 1, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 4, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[4, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 4, 2, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 4, 3, 3] = 
   {{(-3 - Sqrt[13])/2, 1, (1 + I*Sqrt[3])/2, (-I/2)*(-I + Sqrt[3])}, 
    {(3 + Sqrt[13])/2, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}, {(-3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0}}
 
haargrup6Cat8FMatrixFunction[4, 4, 3, 4] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 4, 4, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 4, 4, 2] = {{-1}}
 
haargrup6Cat8FMatrixFunction[4, 4, 4, 3] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 4, 4, 4] = {{(-3 - Sqrt[13])/2, 1, -1, -1}, 
    {(-3 - Sqrt[13])/2, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}, 
    {(3 + Sqrt[13])/2, 0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 4, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat8FMatrixFunction[4, 4, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[4, 4, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 4, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 
        2*#1^5 + 6*#1^6 + 2*#1^7 + #1^8 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat8FMatrixFunction[4, 4, 5, 5] = 
   {{(-3 - Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), (1 + I*Sqrt[3])/2, 
     (-I/2)*(-I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 
      0], 0, Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {(3 + Sqrt[13])/2, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 5, 1, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 5, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 5, 1, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 5, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[4, 5, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[4, 5, 3, 1] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[4, 5, 3, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[4, 5, 3, 3] = 
   {{Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}, {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 5, 3, 5] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], (1 + I*Sqrt[3])/2, 
     -1, (-I/2)*(-I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 
        3*#1^7 + #1^8 & , 8, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {(3 + Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 0}}
 
haargrup6Cat8FMatrixFunction[4, 5, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[4, 5, 4, 2] = {{-1}}
 
haargrup6Cat8FMatrixFunction[4, 5, 4, 3] = 
   {{(3 + Sqrt[13])/2, (1 + I*Sqrt[3])/2, -1, (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 5, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {(-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat8FMatrixFunction[4, 5, 4, 5] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 5, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[4, 5, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[4, 5, 5, 3] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 7, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 5, 5, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], (1 + I*Sqrt[3])/2, 
     -1, -1}, {(-3 - Sqrt[13])/2, 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     0}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}}
 
haargrup6Cat8FMatrixFunction[4, 5, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 1, 1, 3] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 1, 3, 1] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[5, 1, 3, 5] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[5, 1, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 1, 4, 4] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 1, 4, 5] = {{-1}}
 
haargrup6Cat8FMatrixFunction[5, 1, 5, 2] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[5, 2, 1, 5] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 2, 2, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 2, 3, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 2, 3, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 2, 4, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 2, 4, 4] = {{-1}}
 
haargrup6Cat8FMatrixFunction[5, 2, 4, 5] = {{-1}}
 
haargrup6Cat8FMatrixFunction[5, 2, 5, 1] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[5, 2, 5, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 2, 5, 4] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 2, 5, 5] = {{-1}}
 
haargrup6Cat8FMatrixFunction[5, 3, 1, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 3, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[5, 3, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[5, 3, 2, 1] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 3, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 3, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[5, 3, 2, 5] = {{-1}}
 
haargrup6Cat8FMatrixFunction[5, 3, 3, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 3, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 3, 3, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat8FMatrixFunction[5, 3, 3, 4] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 7, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 3, 3, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], (1 - I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2, (I/2)*(I + Sqrt[3])}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 3, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 3, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 3, 4, 3] = 
   {{(-3 - Sqrt[13])/2, -1, (1 - I*Sqrt[3])/2, 1}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 0, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 3, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 1, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 3, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat8FMatrixFunction[5, 3, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 3, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 3, 5, 3] = 
   {{Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (-1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {(-1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 3, 5, 4] = 
   {{(3 + Sqrt[13])/2, (1 - I*Sqrt[3])/2, (1 + I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}, {(-3 - Sqrt[13])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 0}}
 
haargrup6Cat8FMatrixFunction[5, 3, 5, 5] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 8, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 4, 1, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 4, 1, 3] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[5, 4, 1, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[5, 4, 2, 0] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 4, 2, 3] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 4, 2, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[5, 4, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[5, 4, 3, 1] = {{-1}}
 
haargrup6Cat8FMatrixFunction[5, 4, 3, 3] = 
   {{Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], (-1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 4, 3, 4] = 
   {{Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], (1 + I*Sqrt[3])/2, 
     (-I/2)*(-I + Sqrt[3]), (-I/2)*(-I + Sqrt[3])}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 4, 3, 5] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat8FMatrixFunction[5, 4, 4, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 4, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 4, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (-1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 4, 4, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}, {(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 
        10*#1^5 + 7*#1^6 + 3*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], (1 + Sqrt[7 + 2*Sqrt[13]])/2}}
 
haargrup6Cat8FMatrixFunction[5, 4, 4, 5] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 3, 0], (1 + I*Sqrt[3])/2, 
     -1, -1}, {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], 0}, {(-3 - Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 4, 5, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 4, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 4, 5, 3] = 
   {{(3 + Sqrt[13])/2, (1 - I*Sqrt[3])/2, (1 + I*Sqrt[3])/2, 
     (1 + I*Sqrt[3])/2}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], 0, Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 4, 0]}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}, {(-3 - Sqrt[13])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 2, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 0}}
 
haargrup6Cat8FMatrixFunction[5, 4, 5, 4] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0]}, {Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 
        10*#1^5 + 7*#1^6 - 3*#1^7 + #1^8 & , 7, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 4, 5, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 2, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 7, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 5, 1, 1] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 5, 1, 3] = {{-1}}
 
haargrup6Cat8FMatrixFunction[5, 5, 1, 4] = {{(1 + I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[5, 5, 1, 5] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 5, 2, 4] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[5, 5, 2, 5] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[5, 5, 3, 1] = {{-1}}
 
haargrup6Cat8FMatrixFunction[5, 5, 3, 2] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 5, 3, 3] = 
   {{(-3 - Sqrt[13])/2, (-I/2)*(-I + Sqrt[3]), -1, (1 + I*Sqrt[3])/2}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0], 0}, 
    {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 2, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 3, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 5, 3, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}, {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 8, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 1, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 5, 3, 5] = 
   {{(1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 8, 0]}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 5, 4, 1] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[5, 5, 4, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 5, 4, 3] = 
   {{Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 1, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0]}, 
    {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 8, 0], Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 
        7*#1^6 - 3*#1^7 + #1^8 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 
        6*#1^6 + 2*#1^7 + #1^8 & , 1, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 5, 4, 4] = 
   {{Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], (I/2)*(I + Sqrt[3]), 
     -1, (-I/2)*(-I + Sqrt[3])}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 
      2, 0], 0, Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 5, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 3, 0]}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 6, 0], 0}, {(3 + Sqrt[13])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], 0, Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 5, 4, 5] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0], Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 6*#1^6 - 2*#1^7 + 
        #1^8 & , 2, 0]}, {Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     (1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}, {(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 5, 5, 0] = {{(-I/2)*(-I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 5, 5, 1] = {{(1 - I*Sqrt[3])/2}}
 
haargrup6Cat8FMatrixFunction[5, 5, 5, 2] = {{(I/2)*(I + Sqrt[3])}}
 
haargrup6Cat8FMatrixFunction[5, 5, 5, 3] = 
   {{(1 - Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0]}, 
    {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 8, 0], (1 - Sqrt[7 + 2*Sqrt[13]])/2}, 
    {Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 6, 0], Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 2*#1^5 + 
        6*#1^6 - 2*#1^7 + #1^8 & , 2, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 5, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 5, 5, 4] = 
   {{Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 3*#1 + 7*#1^2 + 10*#1^3 + 11*#1^4 + 2*#1^5 + 6*#1^6 + 2*#1^7 + 
        #1^8 & , 1, 0]}, {Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 
     (1 + Sqrt[7 + 2*Sqrt[13]])/2, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0]}, {Root[1 - 3*#1 + 7*#1^2 - 10*#1^3 + 11*#1^4 - 
        2*#1^5 + 6*#1^6 - 2*#1^7 + #1^8 & , 8, 0], 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 4, 0], Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 
        7*#1^6 + 3*#1^7 + #1^8 & , 1, 0]}}
 
haargrup6Cat8FMatrixFunction[5, 5, 5, 5] = 
   {{(-3 - Sqrt[13])/2, (I/2)*(I + Sqrt[3]), -1, (1 + I*Sqrt[3])/2}, 
    {Root[1 + 3*#1 + 10*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 3, 0], 0, 
     Root[1 - 2*#1 + 6*#1^2 - 2*#1^3 + 11*#1^4 - 10*#1^5 + 7*#1^6 - 3*#1^7 + 
        #1^8 & , 7, 0]}, {(3 + Sqrt[13])/2, 0, 
     Root[-1 + 2*#1 + 2*#1^2 - 3*#1^3 + #1^4 & , 4, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0]}, {Root[1 - 3*#1 + 10*#1^2 + 3*#1^3 + #1^4 & , 1, 0], 
     Root[-1 - 2*#1 + 2*#1^2 + 3*#1^3 + #1^4 & , 3, 0], 
     Root[1 + 2*#1 + 6*#1^2 + 2*#1^3 + 11*#1^4 + 10*#1^5 + 7*#1^6 + 3*#1^7 + 
        #1^8 & , 1, 0], 0}}
 
haargrup6Cat8FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haargrup6Cat8], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
haargrup6Cat8FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[haargrup6Cat8], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[haargrup6Cat8Piv1] ^= {}
 
fusionCategory[haargrup6Cat8Piv1] ^= haargrup6Cat8
 
haargrup6Cat8Piv1 /: modularCategory[haargrup6Cat8Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[haargrup6Cat8Piv1] ^= haargrup6Cat8Piv1
 
pivotalIsomorphism[haargrup6Cat8Piv1] ^= haargrup6Cat8Piv1PivotalIsomorphism
 
ring[haargrup6Cat8Piv1] ^= haargrup6
 
sphericalCategory[haargrup6Cat8Piv1] ^= haargrup6Cat8Piv1
 
(pivotalCategoryIndex[fusionCategory[haargrup6Cat8]][pivotalCategory[#1]] & )[
    haargrup6Cat8Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[haargrup6Cat8]][
      sphericalCategory[#1]] & )[haargrup6Cat8Piv1] ^= 
   FusionCategories`PivotalCategories`Private`i
fusionCategory[haargrup6Cat8Piv1PivotalIsomorphism] ^= haargrup6Cat8
 
pivotalCategory[haargrup6Cat8Piv1PivotalIsomorphism] ^= haargrup6Cat8Piv1
 
pivotalIsomorphism[haargrup6Cat8Piv1PivotalIsomorphism] ^= 
   haargrup6Cat8Piv1PivotalIsomorphism
 
haargrup6Cat8Piv1PivotalIsomorphism[0] = 1
 
haargrup6Cat8Piv1PivotalIsomorphism[1] = (-1 - I*Sqrt[3])/2
 
haargrup6Cat8Piv1PivotalIsomorphism[2] = (-1 + I*Sqrt[3])/2
 
haargrup6Cat8Piv1PivotalIsomorphism[3] = 1
 
haargrup6Cat8Piv1PivotalIsomorphism[4] = 1
 
haargrup6Cat8Piv1PivotalIsomorphism[5] = 1
ring[haargrup6NFunction] ^= haargrup6
 
haargrup6NFunction[0, 0, 0] = 1
 
haargrup6NFunction[0, 0, 1] = 0
 
haargrup6NFunction[0, 0, 2] = 0
 
haargrup6NFunction[0, 0, 3] = 0
 
haargrup6NFunction[0, 0, 4] = 0
 
haargrup6NFunction[0, 0, 5] = 0
 
haargrup6NFunction[0, 1, 0] = 0
 
haargrup6NFunction[0, 1, 1] = 1
 
haargrup6NFunction[0, 1, 2] = 0
 
haargrup6NFunction[0, 1, 3] = 0
 
haargrup6NFunction[0, 1, 4] = 0
 
haargrup6NFunction[0, 1, 5] = 0
 
haargrup6NFunction[0, 2, 0] = 0
 
haargrup6NFunction[0, 2, 1] = 0
 
haargrup6NFunction[0, 2, 2] = 1
 
haargrup6NFunction[0, 2, 3] = 0
 
haargrup6NFunction[0, 2, 4] = 0
 
haargrup6NFunction[0, 2, 5] = 0
 
haargrup6NFunction[0, 3, 0] = 0
 
haargrup6NFunction[0, 3, 1] = 0
 
haargrup6NFunction[0, 3, 2] = 0
 
haargrup6NFunction[0, 3, 3] = 1
 
haargrup6NFunction[0, 3, 4] = 0
 
haargrup6NFunction[0, 3, 5] = 0
 
haargrup6NFunction[0, 4, 0] = 0
 
haargrup6NFunction[0, 4, 1] = 0
 
haargrup6NFunction[0, 4, 2] = 0
 
haargrup6NFunction[0, 4, 3] = 0
 
haargrup6NFunction[0, 4, 4] = 1
 
haargrup6NFunction[0, 4, 5] = 0
 
haargrup6NFunction[0, 5, 0] = 0
 
haargrup6NFunction[0, 5, 1] = 0
 
haargrup6NFunction[0, 5, 2] = 0
 
haargrup6NFunction[0, 5, 3] = 0
 
haargrup6NFunction[0, 5, 4] = 0
 
haargrup6NFunction[0, 5, 5] = 1
 
haargrup6NFunction[1, 0, 0] = 0
 
haargrup6NFunction[1, 0, 1] = 1
 
haargrup6NFunction[1, 0, 2] = 0
 
haargrup6NFunction[1, 0, 3] = 0
 
haargrup6NFunction[1, 0, 4] = 0
 
haargrup6NFunction[1, 0, 5] = 0
 
haargrup6NFunction[1, 1, 0] = 0
 
haargrup6NFunction[1, 1, 1] = 0
 
haargrup6NFunction[1, 1, 2] = 1
 
haargrup6NFunction[1, 1, 3] = 0
 
haargrup6NFunction[1, 1, 4] = 0
 
haargrup6NFunction[1, 1, 5] = 0
 
haargrup6NFunction[1, 2, 0] = 1
 
haargrup6NFunction[1, 2, 1] = 0
 
haargrup6NFunction[1, 2, 2] = 0
 
haargrup6NFunction[1, 2, 3] = 0
 
haargrup6NFunction[1, 2, 4] = 0
 
haargrup6NFunction[1, 2, 5] = 0
 
haargrup6NFunction[1, 3, 0] = 0
 
haargrup6NFunction[1, 3, 1] = 0
 
haargrup6NFunction[1, 3, 2] = 0
 
haargrup6NFunction[1, 3, 3] = 0
 
haargrup6NFunction[1, 3, 4] = 1
 
haargrup6NFunction[1, 3, 5] = 0
 
haargrup6NFunction[1, 4, 0] = 0
 
haargrup6NFunction[1, 4, 1] = 0
 
haargrup6NFunction[1, 4, 2] = 0
 
haargrup6NFunction[1, 4, 3] = 0
 
haargrup6NFunction[1, 4, 4] = 0
 
haargrup6NFunction[1, 4, 5] = 1
 
haargrup6NFunction[1, 5, 0] = 0
 
haargrup6NFunction[1, 5, 1] = 0
 
haargrup6NFunction[1, 5, 2] = 0
 
haargrup6NFunction[1, 5, 3] = 1
 
haargrup6NFunction[1, 5, 4] = 0
 
haargrup6NFunction[1, 5, 5] = 0
 
haargrup6NFunction[2, 0, 0] = 0
 
haargrup6NFunction[2, 0, 1] = 0
 
haargrup6NFunction[2, 0, 2] = 1
 
haargrup6NFunction[2, 0, 3] = 0
 
haargrup6NFunction[2, 0, 4] = 0
 
haargrup6NFunction[2, 0, 5] = 0
 
haargrup6NFunction[2, 1, 0] = 1
 
haargrup6NFunction[2, 1, 1] = 0
 
haargrup6NFunction[2, 1, 2] = 0
 
haargrup6NFunction[2, 1, 3] = 0
 
haargrup6NFunction[2, 1, 4] = 0
 
haargrup6NFunction[2, 1, 5] = 0
 
haargrup6NFunction[2, 2, 0] = 0
 
haargrup6NFunction[2, 2, 1] = 1
 
haargrup6NFunction[2, 2, 2] = 0
 
haargrup6NFunction[2, 2, 3] = 0
 
haargrup6NFunction[2, 2, 4] = 0
 
haargrup6NFunction[2, 2, 5] = 0
 
haargrup6NFunction[2, 3, 0] = 0
 
haargrup6NFunction[2, 3, 1] = 0
 
haargrup6NFunction[2, 3, 2] = 0
 
haargrup6NFunction[2, 3, 3] = 0
 
haargrup6NFunction[2, 3, 4] = 0
 
haargrup6NFunction[2, 3, 5] = 1
 
haargrup6NFunction[2, 4, 0] = 0
 
haargrup6NFunction[2, 4, 1] = 0
 
haargrup6NFunction[2, 4, 2] = 0
 
haargrup6NFunction[2, 4, 3] = 1
 
haargrup6NFunction[2, 4, 4] = 0
 
haargrup6NFunction[2, 4, 5] = 0
 
haargrup6NFunction[2, 5, 0] = 0
 
haargrup6NFunction[2, 5, 1] = 0
 
haargrup6NFunction[2, 5, 2] = 0
 
haargrup6NFunction[2, 5, 3] = 0
 
haargrup6NFunction[2, 5, 4] = 1
 
haargrup6NFunction[2, 5, 5] = 0
 
haargrup6NFunction[3, 0, 0] = 0
 
haargrup6NFunction[3, 0, 1] = 0
 
haargrup6NFunction[3, 0, 2] = 0
 
haargrup6NFunction[3, 0, 3] = 1
 
haargrup6NFunction[3, 0, 4] = 0
 
haargrup6NFunction[3, 0, 5] = 0
 
haargrup6NFunction[3, 1, 0] = 0
 
haargrup6NFunction[3, 1, 1] = 0
 
haargrup6NFunction[3, 1, 2] = 0
 
haargrup6NFunction[3, 1, 3] = 0
 
haargrup6NFunction[3, 1, 4] = 0
 
haargrup6NFunction[3, 1, 5] = 1
 
haargrup6NFunction[3, 2, 0] = 0
 
haargrup6NFunction[3, 2, 1] = 0
 
haargrup6NFunction[3, 2, 2] = 0
 
haargrup6NFunction[3, 2, 3] = 0
 
haargrup6NFunction[3, 2, 4] = 1
 
haargrup6NFunction[3, 2, 5] = 0
 
haargrup6NFunction[3, 3, 0] = 1
 
haargrup6NFunction[3, 3, 1] = 0
 
haargrup6NFunction[3, 3, 2] = 0
 
haargrup6NFunction[3, 3, 3] = 1
 
haargrup6NFunction[3, 3, 4] = 1
 
haargrup6NFunction[3, 3, 5] = 1
 
haargrup6NFunction[3, 4, 0] = 0
 
haargrup6NFunction[3, 4, 1] = 0
 
haargrup6NFunction[3, 4, 2] = 1
 
haargrup6NFunction[3, 4, 3] = 1
 
haargrup6NFunction[3, 4, 4] = 1
 
haargrup6NFunction[3, 4, 5] = 1
 
haargrup6NFunction[3, 5, 0] = 0
 
haargrup6NFunction[3, 5, 1] = 1
 
haargrup6NFunction[3, 5, 2] = 0
 
haargrup6NFunction[3, 5, 3] = 1
 
haargrup6NFunction[3, 5, 4] = 1
 
haargrup6NFunction[3, 5, 5] = 1
 
haargrup6NFunction[4, 0, 0] = 0
 
haargrup6NFunction[4, 0, 1] = 0
 
haargrup6NFunction[4, 0, 2] = 0
 
haargrup6NFunction[4, 0, 3] = 0
 
haargrup6NFunction[4, 0, 4] = 1
 
haargrup6NFunction[4, 0, 5] = 0
 
haargrup6NFunction[4, 1, 0] = 0
 
haargrup6NFunction[4, 1, 1] = 0
 
haargrup6NFunction[4, 1, 2] = 0
 
haargrup6NFunction[4, 1, 3] = 1
 
haargrup6NFunction[4, 1, 4] = 0
 
haargrup6NFunction[4, 1, 5] = 0
 
haargrup6NFunction[4, 2, 0] = 0
 
haargrup6NFunction[4, 2, 1] = 0
 
haargrup6NFunction[4, 2, 2] = 0
 
haargrup6NFunction[4, 2, 3] = 0
 
haargrup6NFunction[4, 2, 4] = 0
 
haargrup6NFunction[4, 2, 5] = 1
 
haargrup6NFunction[4, 3, 0] = 0
 
haargrup6NFunction[4, 3, 1] = 1
 
haargrup6NFunction[4, 3, 2] = 0
 
haargrup6NFunction[4, 3, 3] = 1
 
haargrup6NFunction[4, 3, 4] = 1
 
haargrup6NFunction[4, 3, 5] = 1
 
haargrup6NFunction[4, 4, 0] = 1
 
haargrup6NFunction[4, 4, 1] = 0
 
haargrup6NFunction[4, 4, 2] = 0
 
haargrup6NFunction[4, 4, 3] = 1
 
haargrup6NFunction[4, 4, 4] = 1
 
haargrup6NFunction[4, 4, 5] = 1
 
haargrup6NFunction[4, 5, 0] = 0
 
haargrup6NFunction[4, 5, 1] = 0
 
haargrup6NFunction[4, 5, 2] = 1
 
haargrup6NFunction[4, 5, 3] = 1
 
haargrup6NFunction[4, 5, 4] = 1
 
haargrup6NFunction[4, 5, 5] = 1
 
haargrup6NFunction[5, 0, 0] = 0
 
haargrup6NFunction[5, 0, 1] = 0
 
haargrup6NFunction[5, 0, 2] = 0
 
haargrup6NFunction[5, 0, 3] = 0
 
haargrup6NFunction[5, 0, 4] = 0
 
haargrup6NFunction[5, 0, 5] = 1
 
haargrup6NFunction[5, 1, 0] = 0
 
haargrup6NFunction[5, 1, 1] = 0
 
haargrup6NFunction[5, 1, 2] = 0
 
haargrup6NFunction[5, 1, 3] = 0
 
haargrup6NFunction[5, 1, 4] = 1
 
haargrup6NFunction[5, 1, 5] = 0
 
haargrup6NFunction[5, 2, 0] = 0
 
haargrup6NFunction[5, 2, 1] = 0
 
haargrup6NFunction[5, 2, 2] = 0
 
haargrup6NFunction[5, 2, 3] = 1
 
haargrup6NFunction[5, 2, 4] = 0
 
haargrup6NFunction[5, 2, 5] = 0
 
haargrup6NFunction[5, 3, 0] = 0
 
haargrup6NFunction[5, 3, 1] = 0
 
haargrup6NFunction[5, 3, 2] = 1
 
haargrup6NFunction[5, 3, 3] = 1
 
haargrup6NFunction[5, 3, 4] = 1
 
haargrup6NFunction[5, 3, 5] = 1
 
haargrup6NFunction[5, 4, 0] = 0
 
haargrup6NFunction[5, 4, 1] = 1
 
haargrup6NFunction[5, 4, 2] = 0
 
haargrup6NFunction[5, 4, 3] = 1
 
haargrup6NFunction[5, 4, 4] = 1
 
haargrup6NFunction[5, 4, 5] = 1
 
haargrup6NFunction[5, 5, 0] = 1
 
haargrup6NFunction[5, 5, 1] = 0
 
haargrup6NFunction[5, 5, 2] = 0
 
haargrup6NFunction[5, 5, 3] = 1
 
haargrup6NFunction[5, 5, 4] = 1
 
haargrup6NFunction[5, 5, 5] = 1
 
haargrup6NFunction[a_, b_, c_] := 0


 EndPackage[]