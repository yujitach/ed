BeginPackage["FusionCategories`Data`DFib`",{"FusionCategories`","FusionCategories`PivotalCategories`","FusionCategories`BraidedCategories`","FusionCategories`RibbonCategories`"}] 

fusionCategories[DFib] ^= {DFibCat1, DFibCat2, DFibCat3}
 
DFib /: fusionCategory[DFib, 1] = DFibCat1
 
DFib /: fusionCategory[DFib, 2] = DFibCat2
 
DFib /: fusionCategory[DFib, 3] = DFibCat3
 
nFunction[DFib] ^= DFibNFunction
 
noMultiplicities[DFib] ^= True
 
rank[DFib] ^= 4
 
ring[DFib] ^= DFib
balancedCategories[DFibCat1] ^= {DFibCat1Bal1, DFibCat1Bal2, DFibCat1Bal3, 
    DFibCat1Bal4}
 
DFibCat1 /: balancedCategory[DFibCat1, 1] = DFibCat1Bal1
 
DFibCat1 /: balancedCategory[DFibCat1, 2] = DFibCat1Bal2
 
DFibCat1 /: balancedCategory[DFibCat1, 3] = DFibCat1Bal3
 
DFibCat1 /: balancedCategory[DFibCat1, 4] = DFibCat1Bal4
 
braidedCategories[DFibCat1] ^= {DFibCat1Brd1, DFibCat1Brd2, DFibCat1Brd3, 
    DFibCat1Brd4}
 
DFibCat1 /: braidedCategory[DFibCat1, 1] = DFibCat1Brd1
 
DFibCat1 /: braidedCategory[DFibCat1, 2] = DFibCat1Brd2
 
DFibCat1 /: braidedCategory[DFibCat1, 3] = DFibCat1Brd3
 
DFibCat1 /: braidedCategory[DFibCat1, 4] = DFibCat1Brd4
 
coeval[DFibCat1] ^= 1/sixJFunction[DFibCat1][#1, dual[ring[DFibCat1]][#1], 
      #1, #1, 0, 0] & 
 
eval[DFibCat1] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[DFibCat1] ^= DFibCat1FMatrixFunction
 
fusionCategory[DFibCat1] ^= DFibCat1
 
DFibCat1 /: modularCategory[DFibCat1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[DFibCat1] ^= {DFibCat1Piv1}
 
DFibCat1 /: pivotalCategory[DFibCat1, 1] = DFibCat1Piv1
 
DFibCat1 /: pivotalCategory[DFibCat1, {1, 1, 1, 1}] = DFibCat1Piv1
 
DFibCat1 /: ribbonCategory[DFibCat1, 1] = DFibCat1Bal1
 
DFibCat1 /: ribbonCategory[DFibCat1, 2] = DFibCat1Bal2
 
DFibCat1 /: ribbonCategory[DFibCat1, 3] = DFibCat1Bal3
 
DFibCat1 /: ribbonCategory[DFibCat1, 4] = DFibCat1Bal4
 
ring[DFibCat1] ^= DFib
 
DFibCat1 /: sphericalCategory[DFibCat1, 1] = DFibCat1Piv1
 
fusionCategoryIndex[DFib][DFibCat1] ^= 1
balancedCategory[DFibCat1Bal1] ^= DFibCat1Bal1
 
braidedCategory[DFibCat1Bal1] ^= DFibCat1Brd1
 
fusionCategory[DFibCat1Bal1] ^= DFibCat1
 
pivotalCategory[DFibCat1Bal1] ^= DFibCat1Piv1
 
ribbonCategory[DFibCat1Bal1] ^= DFibCat1Bal1
 
ring[DFibCat1Bal1] ^= DFib
 
sphericalCategory[DFibCat1Bal1] ^= DFibCat1Piv1
 
(balancedCategoryIndex[braidedCategory[DFibCat1Brd1]][
      balancedCategory[#1]] & )[DFibCat1Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[DFibCat1]][balancedCategory[#1]] & )[
    DFibCat1Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[DFibCat1Piv1]][
      balancedCategory[#1]] & )[DFibCat1Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[DFibCat1Brd1]][ribbonCategory[#1]] & )[
    DFibCat1Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[DFibCat1]][ribbonCategory[#1]] & )[
    DFibCat1Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[DFibCat1Piv1]][ribbonCategory[#1]] & )[
    DFibCat1Bal1] ^= 1
balancedCategory[DFibCat1Bal2] ^= DFibCat1Bal2
 
braidedCategory[DFibCat1Bal2] ^= DFibCat1Brd2
 
fusionCategory[DFibCat1Bal2] ^= DFibCat1
 
pivotalCategory[DFibCat1Bal2] ^= DFibCat1Piv1
 
ribbonCategory[DFibCat1Bal2] ^= DFibCat1Bal2
 
ring[DFibCat1Bal2] ^= DFib
 
sphericalCategory[DFibCat1Bal2] ^= DFibCat1Piv1
 
(balancedCategoryIndex[braidedCategory[DFibCat1Brd2]][
      balancedCategory[#1]] & )[DFibCat1Bal2] ^= 1
 
(balancedCategoryIndex[fusionCategory[DFibCat1]][balancedCategory[#1]] & )[
    DFibCat1Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[DFibCat1Piv1]][
      balancedCategory[#1]] & )[DFibCat1Bal2] ^= 2
 
(ribbonCategoryIndex[braidedCategory[DFibCat1Brd2]][ribbonCategory[#1]] & )[
    DFibCat1Bal2] ^= 1
 
(ribbonCategoryIndex[fusionCategory[DFibCat1]][ribbonCategory[#1]] & )[
    DFibCat1Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[DFibCat1Piv1]][ribbonCategory[#1]] & )[
    DFibCat1Bal2] ^= 2
balancedCategory[DFibCat1Bal3] ^= DFibCat1Bal3
 
braidedCategory[DFibCat1Bal3] ^= DFibCat1Brd3
 
fusionCategory[DFibCat1Bal3] ^= DFibCat1
 
pivotalCategory[DFibCat1Bal3] ^= DFibCat1Piv1
 
ribbonCategory[DFibCat1Bal3] ^= DFibCat1Bal3
 
ring[DFibCat1Bal3] ^= DFib
 
sphericalCategory[DFibCat1Bal3] ^= DFibCat1Piv1
 
(balancedCategoryIndex[braidedCategory[DFibCat1Brd3]][
      balancedCategory[#1]] & )[DFibCat1Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[DFibCat1]][balancedCategory[#1]] & )[
    DFibCat1Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[DFibCat1Piv1]][
      balancedCategory[#1]] & )[DFibCat1Bal3] ^= 3
 
(ribbonCategoryIndex[braidedCategory[DFibCat1Brd3]][ribbonCategory[#1]] & )[
    DFibCat1Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[DFibCat1]][ribbonCategory[#1]] & )[
    DFibCat1Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[DFibCat1Piv1]][ribbonCategory[#1]] & )[
    DFibCat1Bal3] ^= 3
balancedCategory[DFibCat1Bal4] ^= DFibCat1Bal4
 
braidedCategory[DFibCat1Bal4] ^= DFibCat1Brd4
 
fusionCategory[DFibCat1Bal4] ^= DFibCat1
 
pivotalCategory[DFibCat1Bal4] ^= DFibCat1Piv1
 
ribbonCategory[DFibCat1Bal4] ^= DFibCat1Bal4
 
ring[DFibCat1Bal4] ^= DFib
 
sphericalCategory[DFibCat1Bal4] ^= DFibCat1Piv1
 
(balancedCategoryIndex[braidedCategory[DFibCat1Brd4]][
      balancedCategory[#1]] & )[DFibCat1Bal4] ^= 1
 
(balancedCategoryIndex[fusionCategory[DFibCat1]][balancedCategory[#1]] & )[
    DFibCat1Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[DFibCat1Piv1]][
      balancedCategory[#1]] & )[DFibCat1Bal4] ^= 4
 
(ribbonCategoryIndex[braidedCategory[DFibCat1Brd4]][ribbonCategory[#1]] & )[
    DFibCat1Bal4] ^= 1
 
(ribbonCategoryIndex[fusionCategory[DFibCat1]][ribbonCategory[#1]] & )[
    DFibCat1Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[DFibCat1Piv1]][ribbonCategory[#1]] & )[
    DFibCat1Bal4] ^= 4
balancedCategories[DFibCat1Brd1] ^= {DFibCat1Bal1}
 
DFibCat1Brd1 /: balancedCategory[DFibCat1Brd1, 1] = DFibCat1Bal1
 
braidedCategory[DFibCat1Brd1] ^= DFibCat1Brd1
 
fusionCategory[DFibCat1Brd1] ^= DFibCat1
 
DFibCat1Brd1 /: modularCategory[DFibCat1Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
DFibCat1Brd1 /: ribbonCategory[DFibCat1Brd1, 1] = DFibCat1Bal1
 
ring[DFibCat1Brd1] ^= DFib
 
rMatrixFunction[DFibCat1Brd1] ^= DFibCat1Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[DFibCat1]][braidedCategory[#1]] & )[
    DFibCat1Brd1] ^= 1
braidedCategory[DFibCat1Brd1RMatrixFunction] ^= DFibCat1Brd1
 
fusionCategory[DFibCat1Brd1RMatrixFunction] ^= DFibCat1
 
rMatrixFunction[DFibCat1Brd1RMatrixFunction] ^= DFibCat1Brd1RMatrixFunction
 
DFibCat1Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
DFibCat1Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
DFibCat1Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
DFibCat1Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
DFibCat1Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
DFibCat1Brd1RMatrixFunction[1, 1, 0] = {{(-1)^(2/5)}}
 
DFibCat1Brd1RMatrixFunction[1, 1, 1] = {{(-1)^(1/5)}}
 
DFibCat1Brd1RMatrixFunction[1, 2, 3] = {{1}}
 
DFibCat1Brd1RMatrixFunction[1, 3, 2] = {{(-1)^(2/5)}}
 
DFibCat1Brd1RMatrixFunction[1, 3, 3] = {{(-1)^(1/5)}}
 
DFibCat1Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
DFibCat1Brd1RMatrixFunction[2, 1, 3] = {{1}}
 
DFibCat1Brd1RMatrixFunction[2, 2, 0] = {{(-1)^(4/5)}}
 
DFibCat1Brd1RMatrixFunction[2, 2, 2] = {{-(-1)^(2/5)}}
 
DFibCat1Brd1RMatrixFunction[2, 3, 1] = {{(-1)^(4/5)}}
 
DFibCat1Brd1RMatrixFunction[2, 3, 3] = {{-(-1)^(2/5)}}
 
DFibCat1Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
DFibCat1Brd1RMatrixFunction[3, 1, 2] = {{(-1)^(2/5)}}
 
DFibCat1Brd1RMatrixFunction[3, 1, 3] = {{(-1)^(1/5)}}
 
DFibCat1Brd1RMatrixFunction[3, 2, 1] = {{(-1)^(4/5)}}
 
DFibCat1Brd1RMatrixFunction[3, 2, 3] = {{-(-1)^(2/5)}}
 
DFibCat1Brd1RMatrixFunction[3, 3, 0] = {{-(-1)^(1/5)}}
 
DFibCat1Brd1RMatrixFunction[3, 3, 1] = {{-1}}
 
DFibCat1Brd1RMatrixFunction[3, 3, 2] = {{-(-1)^(4/5)}}
 
DFibCat1Brd1RMatrixFunction[3, 3, 3] = {{-(-1)^(3/5)}}
balancedCategories[DFibCat1Brd2] ^= {DFibCat1Bal2}
 
DFibCat1Brd2 /: balancedCategory[DFibCat1Brd2, 1] = DFibCat1Bal2
 
braidedCategory[DFibCat1Brd2] ^= DFibCat1Brd2
 
fusionCategory[DFibCat1Brd2] ^= DFibCat1
 
DFibCat1Brd2 /: modularCategory[DFibCat1Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
DFibCat1Brd2 /: ribbonCategory[DFibCat1Brd2, 1] = DFibCat1Bal2
 
ring[DFibCat1Brd2] ^= DFib
 
rMatrixFunction[DFibCat1Brd2] ^= DFibCat1Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[DFibCat1]][braidedCategory[#1]] & )[
    DFibCat1Brd2] ^= 2
braidedCategory[DFibCat1Brd2RMatrixFunction] ^= DFibCat1Brd2
 
fusionCategory[DFibCat1Brd2RMatrixFunction] ^= DFibCat1
 
rMatrixFunction[DFibCat1Brd2RMatrixFunction] ^= DFibCat1Brd2RMatrixFunction
 
DFibCat1Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
DFibCat1Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
DFibCat1Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
DFibCat1Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
DFibCat1Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
DFibCat1Brd2RMatrixFunction[1, 1, 0] = {{-(-1)^(3/5)}}
 
DFibCat1Brd2RMatrixFunction[1, 1, 1] = {{-(-1)^(4/5)}}
 
DFibCat1Brd2RMatrixFunction[1, 2, 3] = {{1}}
 
DFibCat1Brd2RMatrixFunction[1, 3, 2] = {{-(-1)^(3/5)}}
 
DFibCat1Brd2RMatrixFunction[1, 3, 3] = {{-(-1)^(4/5)}}
 
DFibCat1Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
DFibCat1Brd2RMatrixFunction[2, 1, 3] = {{1}}
 
DFibCat1Brd2RMatrixFunction[2, 2, 0] = {{(-1)^(4/5)}}
 
DFibCat1Brd2RMatrixFunction[2, 2, 2] = {{-(-1)^(2/5)}}
 
DFibCat1Brd2RMatrixFunction[2, 3, 1] = {{(-1)^(4/5)}}
 
DFibCat1Brd2RMatrixFunction[2, 3, 3] = {{-(-1)^(2/5)}}
 
DFibCat1Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
DFibCat1Brd2RMatrixFunction[3, 1, 2] = {{-(-1)^(3/5)}}
 
DFibCat1Brd2RMatrixFunction[3, 1, 3] = {{-(-1)^(4/5)}}
 
DFibCat1Brd2RMatrixFunction[3, 2, 1] = {{(-1)^(4/5)}}
 
DFibCat1Brd2RMatrixFunction[3, 2, 3] = {{-(-1)^(2/5)}}
 
DFibCat1Brd2RMatrixFunction[3, 3, 0] = {{(-1)^(2/5)}}
 
DFibCat1Brd2RMatrixFunction[3, 3, 1] = {{(-1)^(3/5)}}
 
DFibCat1Brd2RMatrixFunction[3, 3, 2] = {{-1}}
 
DFibCat1Brd2RMatrixFunction[3, 3, 3] = {{-(-1)^(1/5)}}
balancedCategories[DFibCat1Brd3] ^= {DFibCat1Bal3}
 
DFibCat1Brd3 /: balancedCategory[DFibCat1Brd3, 1] = DFibCat1Bal3
 
braidedCategory[DFibCat1Brd3] ^= DFibCat1Brd3
 
fusionCategory[DFibCat1Brd3] ^= DFibCat1
 
DFibCat1Brd3 /: modularCategory[DFibCat1Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
DFibCat1Brd3 /: ribbonCategory[DFibCat1Brd3, 1] = DFibCat1Bal3
 
ring[DFibCat1Brd3] ^= DFib
 
rMatrixFunction[DFibCat1Brd3] ^= DFibCat1Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[DFibCat1]][braidedCategory[#1]] & )[
    DFibCat1Brd3] ^= 3
braidedCategory[DFibCat1Brd3RMatrixFunction] ^= DFibCat1Brd3
 
fusionCategory[DFibCat1Brd3RMatrixFunction] ^= DFibCat1
 
rMatrixFunction[DFibCat1Brd3RMatrixFunction] ^= DFibCat1Brd3RMatrixFunction
 
DFibCat1Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
DFibCat1Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
DFibCat1Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
DFibCat1Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
DFibCat1Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
DFibCat1Brd3RMatrixFunction[1, 1, 0] = {{(-1)^(2/5)}}
 
DFibCat1Brd3RMatrixFunction[1, 1, 1] = {{(-1)^(1/5)}}
 
DFibCat1Brd3RMatrixFunction[1, 2, 3] = {{1}}
 
DFibCat1Brd3RMatrixFunction[1, 3, 2] = {{(-1)^(2/5)}}
 
DFibCat1Brd3RMatrixFunction[1, 3, 3] = {{(-1)^(1/5)}}
 
DFibCat1Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
DFibCat1Brd3RMatrixFunction[2, 1, 3] = {{1}}
 
DFibCat1Brd3RMatrixFunction[2, 2, 0] = {{-(-1)^(1/5)}}
 
DFibCat1Brd3RMatrixFunction[2, 2, 2] = {{(-1)^(3/5)}}
 
DFibCat1Brd3RMatrixFunction[2, 3, 1] = {{-(-1)^(1/5)}}
 
DFibCat1Brd3RMatrixFunction[2, 3, 3] = {{(-1)^(3/5)}}
 
DFibCat1Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
DFibCat1Brd3RMatrixFunction[3, 1, 2] = {{(-1)^(2/5)}}
 
DFibCat1Brd3RMatrixFunction[3, 1, 3] = {{(-1)^(1/5)}}
 
DFibCat1Brd3RMatrixFunction[3, 2, 1] = {{-(-1)^(1/5)}}
 
DFibCat1Brd3RMatrixFunction[3, 2, 3] = {{(-1)^(3/5)}}
 
DFibCat1Brd3RMatrixFunction[3, 3, 0] = {{-(-1)^(3/5)}}
 
DFibCat1Brd3RMatrixFunction[3, 3, 1] = {{-(-1)^(2/5)}}
 
DFibCat1Brd3RMatrixFunction[3, 3, 2] = {{-1}}
 
DFibCat1Brd3RMatrixFunction[3, 3, 3] = {{(-1)^(4/5)}}
balancedCategories[DFibCat1Brd4] ^= {DFibCat1Bal4}
 
DFibCat1Brd4 /: balancedCategory[DFibCat1Brd4, 1] = DFibCat1Bal4
 
braidedCategory[DFibCat1Brd4] ^= DFibCat1Brd4
 
fusionCategory[DFibCat1Brd4] ^= DFibCat1
 
DFibCat1Brd4 /: modularCategory[DFibCat1Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
DFibCat1Brd4 /: ribbonCategory[DFibCat1Brd4, 1] = DFibCat1Bal4
 
ring[DFibCat1Brd4] ^= DFib
 
rMatrixFunction[DFibCat1Brd4] ^= DFibCat1Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[DFibCat1]][braidedCategory[#1]] & )[
    DFibCat1Brd4] ^= 4
braidedCategory[DFibCat1Brd4RMatrixFunction] ^= DFibCat1Brd4
 
fusionCategory[DFibCat1Brd4RMatrixFunction] ^= DFibCat1
 
rMatrixFunction[DFibCat1Brd4RMatrixFunction] ^= DFibCat1Brd4RMatrixFunction
 
DFibCat1Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
DFibCat1Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
DFibCat1Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
DFibCat1Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
DFibCat1Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
DFibCat1Brd4RMatrixFunction[1, 1, 0] = {{-(-1)^(3/5)}}
 
DFibCat1Brd4RMatrixFunction[1, 1, 1] = {{-(-1)^(4/5)}}
 
DFibCat1Brd4RMatrixFunction[1, 2, 3] = {{1}}
 
DFibCat1Brd4RMatrixFunction[1, 3, 2] = {{-(-1)^(3/5)}}
 
DFibCat1Brd4RMatrixFunction[1, 3, 3] = {{-(-1)^(4/5)}}
 
DFibCat1Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
DFibCat1Brd4RMatrixFunction[2, 1, 3] = {{1}}
 
DFibCat1Brd4RMatrixFunction[2, 2, 0] = {{-(-1)^(1/5)}}
 
DFibCat1Brd4RMatrixFunction[2, 2, 2] = {{(-1)^(3/5)}}
 
DFibCat1Brd4RMatrixFunction[2, 3, 1] = {{-(-1)^(1/5)}}
 
DFibCat1Brd4RMatrixFunction[2, 3, 3] = {{(-1)^(3/5)}}
 
DFibCat1Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
DFibCat1Brd4RMatrixFunction[3, 1, 2] = {{-(-1)^(3/5)}}
 
DFibCat1Brd4RMatrixFunction[3, 1, 3] = {{-(-1)^(4/5)}}
 
DFibCat1Brd4RMatrixFunction[3, 2, 1] = {{-(-1)^(1/5)}}
 
DFibCat1Brd4RMatrixFunction[3, 2, 3] = {{(-1)^(3/5)}}
 
DFibCat1Brd4RMatrixFunction[3, 3, 0] = {{(-1)^(4/5)}}
 
DFibCat1Brd4RMatrixFunction[3, 3, 1] = {{-1}}
 
DFibCat1Brd4RMatrixFunction[3, 3, 2] = {{(-1)^(1/5)}}
 
DFibCat1Brd4RMatrixFunction[3, 3, 3] = {{(-1)^(2/5)}}
fMatrixFunction[DFibCat1FMatrixFunction] ^= DFibCat1FMatrixFunction
 
fusionCategory[DFibCat1FMatrixFunction] ^= DFibCat1
 
ring[DFibCat1FMatrixFunction] ^= DFib
 
DFibCat1FMatrixFunction[1, 1, 1, 1] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[1, 1, 3, 3] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[1, 3, 1, 3] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[1, 3, 3, 1] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[1, 3, 3, 3] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[2, 2, 2, 2] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[2, 2, 3, 3] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[2, 3, 2, 3] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[2, 3, 3, 2] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[2, 3, 3, 3] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[3, 1, 1, 3] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[3, 1, 3, 1] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[3, 1, 3, 3] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[3, 2, 2, 3] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[3, 2, 3, 2] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[3, 2, 3, 3] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[3, 3, 1, 1] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[3, 3, 1, 3] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[3, 3, 2, 2] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[3, 3, 2, 3] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[3, 3, 3, 1] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[3, 3, 3, 2] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat1FMatrixFunction[3, 3, 3, 3] = {{-1, -1, -1, -1}, 
    {(-1 + Sqrt[5])/2, 1, (-1 + Sqrt[5])/2, 1}, {(-1 - Sqrt[5])/2, 
     (-1 - Sqrt[5])/2, 1, 1}, {1, (1 + Sqrt[5])/2, (1 - Sqrt[5])/2, -1}}
 
DFibCat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[DFibCat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
DFibCat1FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[DFibCat1], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[DFibCat1Piv1] ^= {DFibCat1Bal1, DFibCat1Bal2, 
    DFibCat1Bal3, DFibCat1Bal4}
 
DFibCat1Piv1 /: balancedCategory[DFibCat1Piv1, 1] = DFibCat1Bal1
 
DFibCat1Piv1 /: balancedCategory[DFibCat1Piv1, 2] = DFibCat1Bal2
 
DFibCat1Piv1 /: balancedCategory[DFibCat1Piv1, 3] = DFibCat1Bal3
 
DFibCat1Piv1 /: balancedCategory[DFibCat1Piv1, 4] = DFibCat1Bal4
 
fusionCategory[DFibCat1Piv1] ^= DFibCat1
 
DFibCat1Piv1 /: modularCategory[DFibCat1Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[DFibCat1Piv1] ^= DFibCat1Piv1
 
pivotalIsomorphism[DFibCat1Piv1] ^= DFibCat1Piv1PivotalIsomorphism
 
DFibCat1Piv1 /: ribbonCategory[DFibCat1Piv1, 1] = DFibCat1Bal1
 
DFibCat1Piv1 /: ribbonCategory[DFibCat1Piv1, 2] = DFibCat1Bal2
 
DFibCat1Piv1 /: ribbonCategory[DFibCat1Piv1, 3] = DFibCat1Bal3
 
DFibCat1Piv1 /: ribbonCategory[DFibCat1Piv1, 4] = DFibCat1Bal4
 
ring[DFibCat1Piv1] ^= DFib
 
sphericalCategory[DFibCat1Piv1] ^= DFibCat1Piv1
 
(pivotalCategoryIndex[fusionCategory[DFibCat1]][pivotalCategory[#1]] & )[
    DFibCat1Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[DFibCat1]][sphericalCategory[#1]] & )[
    DFibCat1Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[DFibCat1Piv1PivotalIsomorphism] ^= DFibCat1
 
pivotalCategory[DFibCat1Piv1PivotalIsomorphism] ^= DFibCat1Piv1
 
pivotalIsomorphism[DFibCat1Piv1PivotalIsomorphism] ^= 
   DFibCat1Piv1PivotalIsomorphism
 
DFibCat1Piv1PivotalIsomorphism[0] = 1
 
DFibCat1Piv1PivotalIsomorphism[1] = 1
 
DFibCat1Piv1PivotalIsomorphism[2] = 1
 
DFibCat1Piv1PivotalIsomorphism[3] = 1
balancedCategories[DFibCat2] ^= {DFibCat2Bal1, DFibCat2Bal2, DFibCat2Bal3, 
    DFibCat2Bal4}
 
DFibCat2 /: balancedCategory[DFibCat2, 1] = DFibCat2Bal1
 
DFibCat2 /: balancedCategory[DFibCat2, 2] = DFibCat2Bal2
 
DFibCat2 /: balancedCategory[DFibCat2, 3] = DFibCat2Bal3
 
DFibCat2 /: balancedCategory[DFibCat2, 4] = DFibCat2Bal4
 
braidedCategories[DFibCat2] ^= {DFibCat2Brd1, DFibCat2Brd2, DFibCat2Brd3, 
    DFibCat2Brd4}
 
DFibCat2 /: braidedCategory[DFibCat2, 1] = DFibCat2Brd1
 
DFibCat2 /: braidedCategory[DFibCat2, 2] = DFibCat2Brd2
 
DFibCat2 /: braidedCategory[DFibCat2, 3] = DFibCat2Brd3
 
DFibCat2 /: braidedCategory[DFibCat2, 4] = DFibCat2Brd4
 
coeval[DFibCat2] ^= 1/sixJFunction[DFibCat2][#1, dual[ring[DFibCat2]][#1], 
      #1, #1, 0, 0] & 
 
eval[DFibCat2] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[DFibCat2] ^= DFibCat2FMatrixFunction
 
fusionCategory[DFibCat2] ^= DFibCat2
 
DFibCat2 /: modularCategory[DFibCat2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[DFibCat2] ^= {DFibCat2Piv1}
 
DFibCat2 /: pivotalCategory[DFibCat2, 1] = DFibCat2Piv1
 
DFibCat2 /: pivotalCategory[DFibCat2, {1, 1, 1, 1}] = DFibCat2Piv1
 
DFibCat2 /: ribbonCategory[DFibCat2, 1] = DFibCat2Bal1
 
DFibCat2 /: ribbonCategory[DFibCat2, 2] = DFibCat2Bal2
 
DFibCat2 /: ribbonCategory[DFibCat2, 3] = DFibCat2Bal3
 
DFibCat2 /: ribbonCategory[DFibCat2, 4] = DFibCat2Bal4
 
ring[DFibCat2] ^= DFib
 
DFibCat2 /: sphericalCategory[DFibCat2, 1] = DFibCat2Piv1
 
fusionCategoryIndex[DFib][DFibCat2] ^= 2
balancedCategory[DFibCat2Bal1] ^= DFibCat2Bal1
 
braidedCategory[DFibCat2Bal1] ^= DFibCat2Brd1
 
fusionCategory[DFibCat2Bal1] ^= DFibCat2
 
pivotalCategory[DFibCat2Bal1] ^= DFibCat2Piv1
 
ribbonCategory[DFibCat2Bal1] ^= DFibCat2Bal1
 
ring[DFibCat2Bal1] ^= DFib
 
sphericalCategory[DFibCat2Bal1] ^= DFibCat2Piv1
 
(balancedCategoryIndex[braidedCategory[DFibCat2Brd1]][
      balancedCategory[#1]] & )[DFibCat2Bal1] ^= 1
 
(balancedCategoryIndex[fusionCategory[DFibCat2]][balancedCategory[#1]] & )[
    DFibCat2Bal1] ^= 1
 
(balancedCategoryIndex[pivotalCategory[DFibCat2Piv1]][
      balancedCategory[#1]] & )[DFibCat2Bal1] ^= 1
 
(ribbonCategoryIndex[braidedCategory[DFibCat2Brd1]][ribbonCategory[#1]] & )[
    DFibCat2Bal1] ^= 1
 
(ribbonCategoryIndex[fusionCategory[DFibCat2]][ribbonCategory[#1]] & )[
    DFibCat2Bal1] ^= 1
 
(ribbonCategoryIndex[sphericalCategory[DFibCat2Piv1]][ribbonCategory[#1]] & )[
    DFibCat2Bal1] ^= 1
balancedCategory[DFibCat2Bal2] ^= DFibCat2Bal2
 
braidedCategory[DFibCat2Bal2] ^= DFibCat2Brd2
 
fusionCategory[DFibCat2Bal2] ^= DFibCat2
 
pivotalCategory[DFibCat2Bal2] ^= DFibCat2Piv1
 
ribbonCategory[DFibCat2Bal2] ^= DFibCat2Bal2
 
ring[DFibCat2Bal2] ^= DFib
 
sphericalCategory[DFibCat2Bal2] ^= DFibCat2Piv1
 
(balancedCategoryIndex[braidedCategory[DFibCat2Brd2]][
      balancedCategory[#1]] & )[DFibCat2Bal2] ^= 1
 
(balancedCategoryIndex[fusionCategory[DFibCat2]][balancedCategory[#1]] & )[
    DFibCat2Bal2] ^= 2
 
(balancedCategoryIndex[pivotalCategory[DFibCat2Piv1]][
      balancedCategory[#1]] & )[DFibCat2Bal2] ^= 2
 
(ribbonCategoryIndex[braidedCategory[DFibCat2Brd2]][ribbonCategory[#1]] & )[
    DFibCat2Bal2] ^= 1
 
(ribbonCategoryIndex[fusionCategory[DFibCat2]][ribbonCategory[#1]] & )[
    DFibCat2Bal2] ^= 2
 
(ribbonCategoryIndex[sphericalCategory[DFibCat2Piv1]][ribbonCategory[#1]] & )[
    DFibCat2Bal2] ^= 2
balancedCategory[DFibCat2Bal3] ^= DFibCat2Bal3
 
braidedCategory[DFibCat2Bal3] ^= DFibCat2Brd3
 
fusionCategory[DFibCat2Bal3] ^= DFibCat2
 
pivotalCategory[DFibCat2Bal3] ^= DFibCat2Piv1
 
ribbonCategory[DFibCat2Bal3] ^= DFibCat2Bal3
 
ring[DFibCat2Bal3] ^= DFib
 
sphericalCategory[DFibCat2Bal3] ^= DFibCat2Piv1
 
(balancedCategoryIndex[braidedCategory[DFibCat2Brd3]][
      balancedCategory[#1]] & )[DFibCat2Bal3] ^= 1
 
(balancedCategoryIndex[fusionCategory[DFibCat2]][balancedCategory[#1]] & )[
    DFibCat2Bal3] ^= 3
 
(balancedCategoryIndex[pivotalCategory[DFibCat2Piv1]][
      balancedCategory[#1]] & )[DFibCat2Bal3] ^= 3
 
(ribbonCategoryIndex[braidedCategory[DFibCat2Brd3]][ribbonCategory[#1]] & )[
    DFibCat2Bal3] ^= 1
 
(ribbonCategoryIndex[fusionCategory[DFibCat2]][ribbonCategory[#1]] & )[
    DFibCat2Bal3] ^= 3
 
(ribbonCategoryIndex[sphericalCategory[DFibCat2Piv1]][ribbonCategory[#1]] & )[
    DFibCat2Bal3] ^= 3
balancedCategory[DFibCat2Bal4] ^= DFibCat2Bal4
 
braidedCategory[DFibCat2Bal4] ^= DFibCat2Brd4
 
fusionCategory[DFibCat2Bal4] ^= DFibCat2
 
pivotalCategory[DFibCat2Bal4] ^= DFibCat2Piv1
 
ribbonCategory[DFibCat2Bal4] ^= DFibCat2Bal4
 
ring[DFibCat2Bal4] ^= DFib
 
sphericalCategory[DFibCat2Bal4] ^= DFibCat2Piv1
 
(balancedCategoryIndex[braidedCategory[DFibCat2Brd4]][
      balancedCategory[#1]] & )[DFibCat2Bal4] ^= 1
 
(balancedCategoryIndex[fusionCategory[DFibCat2]][balancedCategory[#1]] & )[
    DFibCat2Bal4] ^= 4
 
(balancedCategoryIndex[pivotalCategory[DFibCat2Piv1]][
      balancedCategory[#1]] & )[DFibCat2Bal4] ^= 4
 
(ribbonCategoryIndex[braidedCategory[DFibCat2Brd4]][ribbonCategory[#1]] & )[
    DFibCat2Bal4] ^= 1
 
(ribbonCategoryIndex[fusionCategory[DFibCat2]][ribbonCategory[#1]] & )[
    DFibCat2Bal4] ^= 4
 
(ribbonCategoryIndex[sphericalCategory[DFibCat2Piv1]][ribbonCategory[#1]] & )[
    DFibCat2Bal4] ^= 4
balancedCategories[DFibCat2Brd1] ^= {DFibCat2Bal1}
 
DFibCat2Brd1 /: balancedCategory[DFibCat2Brd1, 1] = DFibCat2Bal1
 
braidedCategory[DFibCat2Brd1] ^= DFibCat2Brd1
 
fusionCategory[DFibCat2Brd1] ^= DFibCat2
 
DFibCat2Brd1 /: modularCategory[DFibCat2Brd1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
DFibCat2Brd1 /: ribbonCategory[DFibCat2Brd1, 1] = DFibCat2Bal1
 
ring[DFibCat2Brd1] ^= DFib
 
rMatrixFunction[DFibCat2Brd1] ^= DFibCat2Brd1RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[DFibCat2]][braidedCategory[#1]] & )[
    DFibCat2Brd1] ^= 1
braidedCategory[DFibCat2Brd1RMatrixFunction] ^= DFibCat2Brd1
 
fusionCategory[DFibCat2Brd1RMatrixFunction] ^= DFibCat2
 
rMatrixFunction[DFibCat2Brd1RMatrixFunction] ^= DFibCat2Brd1RMatrixFunction
 
DFibCat2Brd1RMatrixFunction[0, 0, 0] = {{1}}
 
DFibCat2Brd1RMatrixFunction[0, 1, 1] = {{1}}
 
DFibCat2Brd1RMatrixFunction[0, 2, 2] = {{1}}
 
DFibCat2Brd1RMatrixFunction[0, 3, 3] = {{1}}
 
DFibCat2Brd1RMatrixFunction[1, 0, 1] = {{1}}
 
DFibCat2Brd1RMatrixFunction[1, 1, 0] = {{(-1)^(2/5)}}
 
DFibCat2Brd1RMatrixFunction[1, 1, 1] = {{(-1)^(1/5)}}
 
DFibCat2Brd1RMatrixFunction[1, 2, 3] = {{1}}
 
DFibCat2Brd1RMatrixFunction[1, 3, 2] = {{(-1)^(2/5)}}
 
DFibCat2Brd1RMatrixFunction[1, 3, 3] = {{(-1)^(1/5)}}
 
DFibCat2Brd1RMatrixFunction[2, 0, 2] = {{1}}
 
DFibCat2Brd1RMatrixFunction[2, 1, 3] = {{1}}
 
DFibCat2Brd1RMatrixFunction[2, 2, 0] = {{-(-1)^(3/5)}}
 
DFibCat2Brd1RMatrixFunction[2, 2, 2] = {{-(-1)^(4/5)}}
 
DFibCat2Brd1RMatrixFunction[2, 3, 1] = {{-(-1)^(3/5)}}
 
DFibCat2Brd1RMatrixFunction[2, 3, 3] = {{-(-1)^(4/5)}}
 
DFibCat2Brd1RMatrixFunction[3, 0, 3] = {{1}}
 
DFibCat2Brd1RMatrixFunction[3, 1, 2] = {{(-1)^(2/5)}}
 
DFibCat2Brd1RMatrixFunction[3, 1, 3] = {{(-1)^(1/5)}}
 
DFibCat2Brd1RMatrixFunction[3, 2, 1] = {{-(-1)^(3/5)}}
 
DFibCat2Brd1RMatrixFunction[3, 2, 3] = {{-(-1)^(4/5)}}
 
DFibCat2Brd1RMatrixFunction[3, 3, 0] = {{1}}
 
DFibCat2Brd1RMatrixFunction[3, 3, 1] = {{-(-1)^(4/5)}}
 
DFibCat2Brd1RMatrixFunction[3, 3, 2] = {{(-1)^(1/5)}}
 
DFibCat2Brd1RMatrixFunction[3, 3, 3] = {{1}}
balancedCategories[DFibCat2Brd2] ^= {DFibCat2Bal2}
 
DFibCat2Brd2 /: balancedCategory[DFibCat2Brd2, 1] = DFibCat2Bal2
 
braidedCategory[DFibCat2Brd2] ^= DFibCat2Brd2
 
fusionCategory[DFibCat2Brd2] ^= DFibCat2
 
DFibCat2Brd2 /: modularCategory[DFibCat2Brd2, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
DFibCat2Brd2 /: ribbonCategory[DFibCat2Brd2, 1] = DFibCat2Bal2
 
ring[DFibCat2Brd2] ^= DFib
 
rMatrixFunction[DFibCat2Brd2] ^= DFibCat2Brd2RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[DFibCat2]][braidedCategory[#1]] & )[
    DFibCat2Brd2] ^= 2
braidedCategory[DFibCat2Brd2RMatrixFunction] ^= DFibCat2Brd2
 
fusionCategory[DFibCat2Brd2RMatrixFunction] ^= DFibCat2
 
rMatrixFunction[DFibCat2Brd2RMatrixFunction] ^= DFibCat2Brd2RMatrixFunction
 
DFibCat2Brd2RMatrixFunction[0, 0, 0] = {{1}}
 
DFibCat2Brd2RMatrixFunction[0, 1, 1] = {{1}}
 
DFibCat2Brd2RMatrixFunction[0, 2, 2] = {{1}}
 
DFibCat2Brd2RMatrixFunction[0, 3, 3] = {{1}}
 
DFibCat2Brd2RMatrixFunction[1, 0, 1] = {{1}}
 
DFibCat2Brd2RMatrixFunction[1, 1, 0] = {{-(-1)^(3/5)}}
 
DFibCat2Brd2RMatrixFunction[1, 1, 1] = {{-(-1)^(4/5)}}
 
DFibCat2Brd2RMatrixFunction[1, 2, 3] = {{1}}
 
DFibCat2Brd2RMatrixFunction[1, 3, 2] = {{-(-1)^(3/5)}}
 
DFibCat2Brd2RMatrixFunction[1, 3, 3] = {{-(-1)^(4/5)}}
 
DFibCat2Brd2RMatrixFunction[2, 0, 2] = {{1}}
 
DFibCat2Brd2RMatrixFunction[2, 1, 3] = {{1}}
 
DFibCat2Brd2RMatrixFunction[2, 2, 0] = {{(-1)^(2/5)}}
 
DFibCat2Brd2RMatrixFunction[2, 2, 2] = {{(-1)^(1/5)}}
 
DFibCat2Brd2RMatrixFunction[2, 3, 1] = {{(-1)^(2/5)}}
 
DFibCat2Brd2RMatrixFunction[2, 3, 3] = {{(-1)^(1/5)}}
 
DFibCat2Brd2RMatrixFunction[3, 0, 3] = {{1}}
 
DFibCat2Brd2RMatrixFunction[3, 1, 2] = {{-(-1)^(3/5)}}
 
DFibCat2Brd2RMatrixFunction[3, 1, 3] = {{-(-1)^(4/5)}}
 
DFibCat2Brd2RMatrixFunction[3, 2, 1] = {{(-1)^(2/5)}}
 
DFibCat2Brd2RMatrixFunction[3, 2, 3] = {{(-1)^(1/5)}}
 
DFibCat2Brd2RMatrixFunction[3, 3, 0] = {{1}}
 
DFibCat2Brd2RMatrixFunction[3, 3, 1] = {{(-1)^(1/5)}}
 
DFibCat2Brd2RMatrixFunction[3, 3, 2] = {{-(-1)^(4/5)}}
 
DFibCat2Brd2RMatrixFunction[3, 3, 3] = {{1}}
balancedCategories[DFibCat2Brd3] ^= {DFibCat2Bal3}
 
DFibCat2Brd3 /: balancedCategory[DFibCat2Brd3, 1] = DFibCat2Bal3
 
braidedCategory[DFibCat2Brd3] ^= DFibCat2Brd3
 
fusionCategory[DFibCat2Brd3] ^= DFibCat2
 
DFibCat2Brd3 /: modularCategory[DFibCat2Brd3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
DFibCat2Brd3 /: ribbonCategory[DFibCat2Brd3, 1] = DFibCat2Bal3
 
ring[DFibCat2Brd3] ^= DFib
 
rMatrixFunction[DFibCat2Brd3] ^= DFibCat2Brd3RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[DFibCat2]][braidedCategory[#1]] & )[
    DFibCat2Brd3] ^= 3
braidedCategory[DFibCat2Brd3RMatrixFunction] ^= DFibCat2Brd3
 
fusionCategory[DFibCat2Brd3RMatrixFunction] ^= DFibCat2
 
rMatrixFunction[DFibCat2Brd3RMatrixFunction] ^= DFibCat2Brd3RMatrixFunction
 
DFibCat2Brd3RMatrixFunction[0, 0, 0] = {{1}}
 
DFibCat2Brd3RMatrixFunction[0, 1, 1] = {{1}}
 
DFibCat2Brd3RMatrixFunction[0, 2, 2] = {{1}}
 
DFibCat2Brd3RMatrixFunction[0, 3, 3] = {{1}}
 
DFibCat2Brd3RMatrixFunction[1, 0, 1] = {{1}}
 
DFibCat2Brd3RMatrixFunction[1, 1, 0] = {{-(-1)^(3/5)}}
 
DFibCat2Brd3RMatrixFunction[1, 1, 1] = {{-(-1)^(4/5)}}
 
DFibCat2Brd3RMatrixFunction[1, 2, 3] = {{1}}
 
DFibCat2Brd3RMatrixFunction[1, 3, 2] = {{-(-1)^(3/5)}}
 
DFibCat2Brd3RMatrixFunction[1, 3, 3] = {{-(-1)^(4/5)}}
 
DFibCat2Brd3RMatrixFunction[2, 0, 2] = {{1}}
 
DFibCat2Brd3RMatrixFunction[2, 1, 3] = {{1}}
 
DFibCat2Brd3RMatrixFunction[2, 2, 0] = {{-(-1)^(3/5)}}
 
DFibCat2Brd3RMatrixFunction[2, 2, 2] = {{-(-1)^(4/5)}}
 
DFibCat2Brd3RMatrixFunction[2, 3, 1] = {{-(-1)^(3/5)}}
 
DFibCat2Brd3RMatrixFunction[2, 3, 3] = {{-(-1)^(4/5)}}
 
DFibCat2Brd3RMatrixFunction[3, 0, 3] = {{1}}
 
DFibCat2Brd3RMatrixFunction[3, 1, 2] = {{-(-1)^(3/5)}}
 
DFibCat2Brd3RMatrixFunction[3, 1, 3] = {{-(-1)^(4/5)}}
 
DFibCat2Brd3RMatrixFunction[3, 2, 1] = {{-(-1)^(3/5)}}
 
DFibCat2Brd3RMatrixFunction[3, 2, 3] = {{-(-1)^(4/5)}}
 
DFibCat2Brd3RMatrixFunction[3, 3, 0] = {{-(-1)^(1/5)}}
 
DFibCat2Brd3RMatrixFunction[3, 3, 1] = {{-(-1)^(2/5)}}
 
DFibCat2Brd3RMatrixFunction[3, 3, 2] = {{-(-1)^(2/5)}}
 
DFibCat2Brd3RMatrixFunction[3, 3, 3] = {{-(-1)^(3/5)}}
balancedCategories[DFibCat2Brd4] ^= {DFibCat2Bal4}
 
DFibCat2Brd4 /: balancedCategory[DFibCat2Brd4, 1] = DFibCat2Bal4
 
braidedCategory[DFibCat2Brd4] ^= DFibCat2Brd4
 
fusionCategory[DFibCat2Brd4] ^= DFibCat2
 
DFibCat2Brd4 /: modularCategory[DFibCat2Brd4, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
DFibCat2Brd4 /: ribbonCategory[DFibCat2Brd4, 1] = DFibCat2Bal4
 
ring[DFibCat2Brd4] ^= DFib
 
rMatrixFunction[DFibCat2Brd4] ^= DFibCat2Brd4RMatrixFunction
 
(braidedCategoryIndex[fusionCategory[DFibCat2]][braidedCategory[#1]] & )[
    DFibCat2Brd4] ^= 4
braidedCategory[DFibCat2Brd4RMatrixFunction] ^= DFibCat2Brd4
 
fusionCategory[DFibCat2Brd4RMatrixFunction] ^= DFibCat2
 
rMatrixFunction[DFibCat2Brd4RMatrixFunction] ^= DFibCat2Brd4RMatrixFunction
 
DFibCat2Brd4RMatrixFunction[0, 0, 0] = {{1}}
 
DFibCat2Brd4RMatrixFunction[0, 1, 1] = {{1}}
 
DFibCat2Brd4RMatrixFunction[0, 2, 2] = {{1}}
 
DFibCat2Brd4RMatrixFunction[0, 3, 3] = {{1}}
 
DFibCat2Brd4RMatrixFunction[1, 0, 1] = {{1}}
 
DFibCat2Brd4RMatrixFunction[1, 1, 0] = {{(-1)^(2/5)}}
 
DFibCat2Brd4RMatrixFunction[1, 1, 1] = {{(-1)^(1/5)}}
 
DFibCat2Brd4RMatrixFunction[1, 2, 3] = {{1}}
 
DFibCat2Brd4RMatrixFunction[1, 3, 2] = {{(-1)^(2/5)}}
 
DFibCat2Brd4RMatrixFunction[1, 3, 3] = {{(-1)^(1/5)}}
 
DFibCat2Brd4RMatrixFunction[2, 0, 2] = {{1}}
 
DFibCat2Brd4RMatrixFunction[2, 1, 3] = {{1}}
 
DFibCat2Brd4RMatrixFunction[2, 2, 0] = {{(-1)^(2/5)}}
 
DFibCat2Brd4RMatrixFunction[2, 2, 2] = {{(-1)^(1/5)}}
 
DFibCat2Brd4RMatrixFunction[2, 3, 1] = {{(-1)^(2/5)}}
 
DFibCat2Brd4RMatrixFunction[2, 3, 3] = {{(-1)^(1/5)}}
 
DFibCat2Brd4RMatrixFunction[3, 0, 3] = {{1}}
 
DFibCat2Brd4RMatrixFunction[3, 1, 2] = {{(-1)^(2/5)}}
 
DFibCat2Brd4RMatrixFunction[3, 1, 3] = {{(-1)^(1/5)}}
 
DFibCat2Brd4RMatrixFunction[3, 2, 1] = {{(-1)^(2/5)}}
 
DFibCat2Brd4RMatrixFunction[3, 2, 3] = {{(-1)^(1/5)}}
 
DFibCat2Brd4RMatrixFunction[3, 3, 0] = {{(-1)^(4/5)}}
 
DFibCat2Brd4RMatrixFunction[3, 3, 1] = {{(-1)^(3/5)}}
 
DFibCat2Brd4RMatrixFunction[3, 3, 2] = {{(-1)^(3/5)}}
 
DFibCat2Brd4RMatrixFunction[3, 3, 3] = {{(-1)^(2/5)}}
fMatrixFunction[DFibCat2FMatrixFunction] ^= DFibCat2FMatrixFunction
 
fusionCategory[DFibCat2FMatrixFunction] ^= DFibCat2
 
ring[DFibCat2FMatrixFunction] ^= DFib
 
DFibCat2FMatrixFunction[1, 1, 1, 1] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[1, 1, 3, 3] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[1, 3, 1, 3] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[1, 3, 3, 1] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[1, 3, 3, 3] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[2, 2, 2, 2] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[2, 2, 3, 3] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[2, 3, 2, 3] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[2, 3, 3, 2] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[2, 3, 3, 3] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[3, 1, 1, 3] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[3, 1, 3, 1] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[3, 1, 3, 3] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[3, 2, 2, 3] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[3, 2, 3, 2] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[3, 2, 3, 3] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[3, 3, 1, 1] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[3, 3, 1, 3] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[3, 3, 2, 2] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[3, 3, 2, 3] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[3, 3, 3, 1] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[3, 3, 3, 2] = {{(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[3, 3, 3, 3] = 
   {{(3 + Sqrt[5])/2, (3 + Sqrt[5])/2, (3 + Sqrt[5])/2, (3 + Sqrt[5])/2}, 
    {(-1 - Sqrt[5])/2, (-3 - Sqrt[5])/2, (-1 - Sqrt[5])/2, (-3 - Sqrt[5])/2}, 
    {(-1 - Sqrt[5])/2, (-1 - Sqrt[5])/2, (-3 - Sqrt[5])/2, (-3 - Sqrt[5])/2}, 
    {1, (1 + Sqrt[5])/2, (1 + Sqrt[5])/2, (3 + Sqrt[5])/2}}
 
DFibCat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[DFibCat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
DFibCat2FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[DFibCat2], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[DFibCat2Piv1] ^= {DFibCat2Bal1, DFibCat2Bal2, 
    DFibCat2Bal3, DFibCat2Bal4}
 
DFibCat2Piv1 /: balancedCategory[DFibCat2Piv1, 1] = DFibCat2Bal1
 
DFibCat2Piv1 /: balancedCategory[DFibCat2Piv1, 2] = DFibCat2Bal2
 
DFibCat2Piv1 /: balancedCategory[DFibCat2Piv1, 3] = DFibCat2Bal3
 
DFibCat2Piv1 /: balancedCategory[DFibCat2Piv1, 4] = DFibCat2Bal4
 
fusionCategory[DFibCat2Piv1] ^= DFibCat2
 
DFibCat2Piv1 /: modularCategory[DFibCat2Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[DFibCat2Piv1] ^= DFibCat2Piv1
 
pivotalIsomorphism[DFibCat2Piv1] ^= DFibCat2Piv1PivotalIsomorphism
 
DFibCat2Piv1 /: ribbonCategory[DFibCat2Piv1, 1] = DFibCat2Bal1
 
DFibCat2Piv1 /: ribbonCategory[DFibCat2Piv1, 2] = DFibCat2Bal2
 
DFibCat2Piv1 /: ribbonCategory[DFibCat2Piv1, 3] = DFibCat2Bal3
 
DFibCat2Piv1 /: ribbonCategory[DFibCat2Piv1, 4] = DFibCat2Bal4
 
ring[DFibCat2Piv1] ^= DFib
 
sphericalCategory[DFibCat2Piv1] ^= DFibCat2Piv1
 
(pivotalCategoryIndex[fusionCategory[DFibCat2]][pivotalCategory[#1]] & )[
    DFibCat2Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[DFibCat2]][sphericalCategory[#1]] & )[
    DFibCat2Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[DFibCat2Piv1PivotalIsomorphism] ^= DFibCat2
 
pivotalCategory[DFibCat2Piv1PivotalIsomorphism] ^= DFibCat2Piv1
 
pivotalIsomorphism[DFibCat2Piv1PivotalIsomorphism] ^= 
   DFibCat2Piv1PivotalIsomorphism
 
DFibCat2Piv1PivotalIsomorphism[0] = 1
 
DFibCat2Piv1PivotalIsomorphism[1] = 1
 
DFibCat2Piv1PivotalIsomorphism[2] = 1
 
DFibCat2Piv1PivotalIsomorphism[3] = 1
balancedCategories[DFibCat3] ^= {}
 
braidedCategories[DFibCat3] ^= {}
 
coeval[DFibCat3] ^= 1/sixJFunction[DFibCat3][#1, dual[ring[DFibCat3]][#1], 
      #1, #1, 0, 0] & 
 
eval[DFibCat3] ^= FusionCategories`Private`defaultGaugeEval
 
fMatrixFunction[DFibCat3] ^= DFibCat3FMatrixFunction
 
fusionCategory[DFibCat3] ^= DFibCat3
 
DFibCat3 /: modularCategory[DFibCat3, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategories[DFibCat3] ^= {DFibCat3Piv1}
 
DFibCat3 /: pivotalCategory[DFibCat3, 1] = DFibCat3Piv1
 
DFibCat3 /: pivotalCategory[DFibCat3, {1, 1, 1, 1}] = DFibCat3Piv1
 
ring[DFibCat3] ^= DFib
 
DFibCat3 /: sphericalCategory[DFibCat3, 1] = DFibCat3Piv1
 
fusionCategoryIndex[DFib][DFibCat3] ^= 3
fMatrixFunction[DFibCat3FMatrixFunction] ^= DFibCat3FMatrixFunction
 
fusionCategory[DFibCat3FMatrixFunction] ^= DFibCat3
 
ring[DFibCat3FMatrixFunction] ^= DFib
 
DFibCat3FMatrixFunction[1, 1, 1, 1] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[1, 1, 3, 3] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[1, 3, 1, 3] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[1, 3, 3, 1] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[1, 3, 3, 3] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[2, 2, 2, 2] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[2, 2, 3, 3] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[2, 3, 2, 3] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[2, 3, 3, 2] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[2, 3, 3, 3] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[3, 1, 1, 3] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[3, 1, 3, 1] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[3, 1, 3, 3] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[3, 2, 2, 3] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[3, 2, 3, 2] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[3, 2, 3, 3] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[3, 3, 1, 1] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[3, 3, 1, 3] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[3, 3, 2, 2] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[3, 3, 2, 3] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[3, 3, 3, 1] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[3, 3, 3, 2] = {{(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[3, 3, 3, 3] = 
   {{(3 - Sqrt[5])/2, (3 - Sqrt[5])/2, (3 - Sqrt[5])/2, (3 - Sqrt[5])/2}, 
    {(-1 + Sqrt[5])/2, (-3 + Sqrt[5])/2, (-1 + Sqrt[5])/2, (-3 + Sqrt[5])/2}, 
    {(-1 + Sqrt[5])/2, (-1 + Sqrt[5])/2, (-3 + Sqrt[5])/2, (-3 + Sqrt[5])/2}, 
    {1, (1 - Sqrt[5])/2, (1 - Sqrt[5])/2, (3 - Sqrt[5])/2}}
 
DFibCat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[DFibCat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     1 = {{1}}
 
DFibCat3FMatrixFunction[FusionCategories`Private`a$_, 
     FusionCategories`Private`b$_, FusionCategories`Private`c$_, 
     FusionCategories`Private`d$_] /; homDimension[ring[DFibCat3], 
      FusionCategories`Private`o, Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`a$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, 
        FusionCategories`Private`b$] \[CircleTimes] 
       Subscript[FusionCategories`Private`o, FusionCategories`Private`c$], 
      Subscript[FusionCategories`Private`o, FusionCategories`Private`d$]] == 
     2 = {{1, 0}, {0, 1}}
balancedCategories[DFibCat3Piv1] ^= {}
 
fusionCategory[DFibCat3Piv1] ^= DFibCat3
 
DFibCat3Piv1 /: modularCategory[DFibCat3Piv1, 1] = 
    FusionCategories`RibbonCategories`Private`p
 
pivotalCategory[DFibCat3Piv1] ^= DFibCat3Piv1
 
pivotalIsomorphism[DFibCat3Piv1] ^= DFibCat3Piv1PivotalIsomorphism
 
ring[DFibCat3Piv1] ^= DFib
 
sphericalCategory[DFibCat3Piv1] ^= DFibCat3Piv1
 
(pivotalCategoryIndex[fusionCategory[DFibCat3]][pivotalCategory[#1]] & )[
    DFibCat3Piv1] ^= 1
 
(sphericalCategoryIndex[fusionCategory[DFibCat3]][sphericalCategory[#1]] & )[
    DFibCat3Piv1] ^= FusionCategories`PivotalCategories`Private`i
fusionCategory[DFibCat3Piv1PivotalIsomorphism] ^= DFibCat3
 
pivotalCategory[DFibCat3Piv1PivotalIsomorphism] ^= DFibCat3Piv1
 
pivotalIsomorphism[DFibCat3Piv1PivotalIsomorphism] ^= 
   DFibCat3Piv1PivotalIsomorphism
 
DFibCat3Piv1PivotalIsomorphism[0] = 1
 
DFibCat3Piv1PivotalIsomorphism[1] = 1
 
DFibCat3Piv1PivotalIsomorphism[2] = 1
 
DFibCat3Piv1PivotalIsomorphism[3] = 1
ring[DFibNFunction] ^= DFib
 
DFibNFunction[0, 0, 0] = 1
 
DFibNFunction[0, 0, 1] = 0
 
DFibNFunction[0, 0, 2] = 0
 
DFibNFunction[0, 0, 3] = 0
 
DFibNFunction[0, 1, 0] = 0
 
DFibNFunction[0, 1, 1] = 1
 
DFibNFunction[0, 1, 2] = 0
 
DFibNFunction[0, 1, 3] = 0
 
DFibNFunction[0, 2, 0] = 0
 
DFibNFunction[0, 2, 1] = 0
 
DFibNFunction[0, 2, 2] = 1
 
DFibNFunction[0, 2, 3] = 0
 
DFibNFunction[0, 3, 0] = 0
 
DFibNFunction[0, 3, 1] = 0
 
DFibNFunction[0, 3, 2] = 0
 
DFibNFunction[0, 3, 3] = 1
 
DFibNFunction[1, 0, 0] = 0
 
DFibNFunction[1, 0, 1] = 1
 
DFibNFunction[1, 0, 2] = 0
 
DFibNFunction[1, 0, 3] = 0
 
DFibNFunction[1, 1, 0] = 1
 
DFibNFunction[1, 1, 1] = 1
 
DFibNFunction[1, 1, 2] = 0
 
DFibNFunction[1, 1, 3] = 0
 
DFibNFunction[1, 2, 0] = 0
 
DFibNFunction[1, 2, 1] = 0
 
DFibNFunction[1, 2, 2] = 0
 
DFibNFunction[1, 2, 3] = 1
 
DFibNFunction[1, 3, 0] = 0
 
DFibNFunction[1, 3, 1] = 0
 
DFibNFunction[1, 3, 2] = 1
 
DFibNFunction[1, 3, 3] = 1
 
DFibNFunction[2, 0, 0] = 0
 
DFibNFunction[2, 0, 1] = 0
 
DFibNFunction[2, 0, 2] = 1
 
DFibNFunction[2, 0, 3] = 0
 
DFibNFunction[2, 1, 0] = 0
 
DFibNFunction[2, 1, 1] = 0
 
DFibNFunction[2, 1, 2] = 0
 
DFibNFunction[2, 1, 3] = 1
 
DFibNFunction[2, 2, 0] = 1
 
DFibNFunction[2, 2, 1] = 0
 
DFibNFunction[2, 2, 2] = 1
 
DFibNFunction[2, 2, 3] = 0
 
DFibNFunction[2, 3, 0] = 0
 
DFibNFunction[2, 3, 1] = 1
 
DFibNFunction[2, 3, 2] = 0
 
DFibNFunction[2, 3, 3] = 1
 
DFibNFunction[3, 0, 0] = 0
 
DFibNFunction[3, 0, 1] = 0
 
DFibNFunction[3, 0, 2] = 0
 
DFibNFunction[3, 0, 3] = 1
 
DFibNFunction[3, 1, 0] = 0
 
DFibNFunction[3, 1, 1] = 0
 
DFibNFunction[3, 1, 2] = 1
 
DFibNFunction[3, 1, 3] = 1
 
DFibNFunction[3, 2, 0] = 0
 
DFibNFunction[3, 2, 1] = 1
 
DFibNFunction[3, 2, 2] = 0
 
DFibNFunction[3, 2, 3] = 1
 
DFibNFunction[3, 3, 0] = 1
 
DFibNFunction[3, 3, 1] = 1
 
DFibNFunction[3, 3, 2] = 1
 
DFibNFunction[3, 3, 3] = 1
 
DFibNFunction[FusionCategories`Data`DFib`Private`a_, FusionCategories`Data`DFib`Private`b_, FusionCategories`Data`DFib`Private`c_] := 0


 EndPackage[]
