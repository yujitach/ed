With[{packagename="FusionCategories"},
  Get@FileNameJoin@{ 
    DirectoryName@FindFile[packagename<>"`"],
    packagename<>".m"}]
